﻿namespace eMOC_PV_DataAccess
{
    public static class DBConstants
    {
        #region Input Parameters
        public static class Input
        {
            public const string P_MU_NUMBER = "P_MU_NUMBER";
            public const string P_ERROR_ID = "P_ERROR_ID";
            public const string P_EXCEPTION = "P_EXCEPTION";
            public const string P_STACK = "P_STACK";
            public const string P_CREATED_BY = "P_CREATED_BY";
            public const string P_KEYWORD = "P_KEYWORD";
            public const string P_ID = "P_ID";
            public const string P_CODE = "P_CODE";
            public const string P_DESCRIPTION = "P_DESCRIPTION";
            public const string P_IS_DIRECTORATE = "P_IS_DIRECTORATE";
            public const string P_IS_ASSET = "P_IS_ASSET";
            public const string P_IS_DELEGATED_ROLE = "P_IS_DELEGATED_ROLE";
            public const string P_IS_SUB_ADMIN = "P_IS_SUB_ADMIN";
            public const string P_IS_SUPER_ADMIN = "P_IS_SUPER_ADMIN";
            public const string P_IS_ACTIVE = "P_IS_ACTIVE";
            public const string P_NAME = "P_NAME";
            public const string P_DISPLAY_NAME = "P_DISPLAY_NAME";
            public const string P_GUID = "P_GUID";
            public const string P_ORDER_NO = "P_ORDER_NO";
            public const string P_SCREEN_CODE = "P_SCREEN_CODE";
            public const string P_ICON = "P_ICON";
            public const string P_URL = "P_URL";
            public const string P_MODULE_ID = "P_MODULE_ID";
            public const string P_RET_TYPE = "P_RET_TYPE";
            public const string P_DIRECTORATE = "P_DIRECTORATE";
            public const string P_ASSET = "P_ASSET";
            public const string P_RRR_NAME = "P_RRR_NAME";
            public const string P_CRRR_NAME = "P_CRRR_NAME";
            
            public const string P_HAZARD_ID = "P_HAZARD_ID";
            public const string P_REQUEST_ID = "P_REQUEST_ID";
            public const string P_WF_TYPE_ID = "P_WF_TYPE_ID";
            public const string P_ROLE_ID = "P_ROLE_ID";
            public const string P_IS_MANDATORY = "P_IS_MANDATORY";
            public const string P_DOC_TYPE = "P_DOC_TYPE";
            public const string P_NOTIFYTO = "P_NOTIFYTO";
            public const string P_COMMENTS = "P_COMMENTS";
            public const string P_MIME_TYPE = "P_MIME_TYPE";
            public const string P_APPROVER = "P_APPROVER";
            public const string P_NEXT_ROLE_ID = "P_NEXT_ROLE_ID";
            
            public const string P_CURRENT_STEP = "P_CURRENT_STEP";
            public const string P_CURRENT_STATUS = "P_CURRENT_STATUS";
            public const string P_WF_ACTION_ID = "P_WF_ACTION_ID";
            public const string P_GENERAL = "P_GENERAL";
            public const string P_DOCUMENTS = "P_DOCUMENTS";
            public const string P_RA_TEAM_MEMBERS = "P_RA_TEAM_MEMBERS";
            public const string P_RISK_ASSESSMENT = "P_RISK_ASSESSMENT";
            public const string P_RA_MATRIX = "P_RA_MATRIX";
            public const string P_CUMULATIVE_RA_MATRIX = "P_CUMULATIVE_RA_MATRIX";
            public const string P_HISTORY = "P_HISTORY";
            public const string P_FIRST = "P_FIRST";
            public const string P_ROWS = "P_ROWS";
            public const string P_FILTER = "P_FILTER";
            public const string P_FULL_RECORD = "P_FULL_RECORD";
            public const string P_SORT_FIELD = "P_SORT_FIELD";
            public const string P_SORT_ORDER = "P_SORT_ORDER";
            public const string P_STATUS = "P_STATUS";
            public const string P_LOGGED_USER = "P_LOGGED_USER";
            public const string P_FACILITIES = "P_FACILITIES";
            public const string P_EMOC_TYPE = "P_EMOC_TYPE";
 
            public const string P_METHOD = "P_METHOD";
            public const string P_API = "P_API";
            public const string P_STATUS_CODE = "P_STATUS_CODE";
            public const string P_IP_ADDRESS = "P_IP_ADDRESS";
            public const string P_HOST_NAME = "P_HOST_NAME";
            public const string P_CLIENT_MACHINE = "P_CLIENT_MACHINE";
            public const string P_SUBJECT = "P_SUBJECT";
            public const string P_BODY = "P_BODY";

            
        }
        #endregion

        #region Output Parameters
        public static class Output
        {
            public const string P_RESPONSE = "P_RESPONSE";
            public const string P_OUTPUT = "P_OUTPUT";
            public const string P_USER_DATA = "P_USER_DATA";
            public const string P_ROLES = "P_ROLES";
            public const string P_MODULE = "P_MODULE";
            public const string P_SCREENS = "P_SCREENS";
            public const string P_GENERAL = "P_GENERAL";
            public const string P_FACILITIES = "P_FACILITIES";
            public const string P_DOCUMENTS = "P_DOCUMENTS";
            public const string P_RA_TEAM_MEMBERS = "P_RA_TEAM_MEMBERS";
            public const string P_RISK_ASSESSMENT = "P_RISK_ASSESSMENT";
            public const string P_BACKUP_APPROVERS = "P_BACKUP_APPROVERS";
            public const string P_TASK = "P_TASK";
            public const string P_APPROVER_HISTORY = "P_APPROVER_HISTORY";
            public const string P_REQUEST_EXTENSION_HISTORY = "P_REQUEST_EXTENSION_HISTORY";
            public const string P_STATUS_CODE = "P_STATUS_CODE";
            public const string P_STATUS_MESSAGE = "P_STATUS_MESSAGE";
            public const string P_CHART1 = "P_CHART1";
            public const string P_CHART2 = "P_CHART2";
            public const string P_CHART3 = "P_CHART3";
            public const string P_CHART4 = "P_CHART4";
            public const string P_CHART5 = "P_CHART5";
            
            public const string P_OID = "P_OID";
            public const string P_OTHER_MOCS = "P_OTHER_MOCS";

            public const string P_OUTPUT_CHART_TYPE = "P_OUTPUT_CHART_TYPE";
            public const string P_OUTPUT_YEAR = "P_OUTPUT_YEAR";
            public const string P_OUTPUT_MONTH = "P_OUTPUT_MONTH";

        }
        #endregion

        #region Stored Procedures
        public static class Procedures
        {
            public const string SP_GET_USER_DETAIL = "SP_GET_USER_DETAIL";
            public const string SP_IS_USER_AUTHORIZED = "SP_IS_USER_AUTHORIZED";
            public const string SP_LOG_ERROR = "SP_LOG_ERROR";
            public const string SP_SEARCH_USERS = "SP_SEARCH_USERS";
            public const string SP_SEARCH_USERS_BY_REFRENCEINDICATOR = "SP_SEARCH_USERS_BY_REFRENCEINDICATOR";
            public const string SP_SEARCH_CMS_PROCEDURE = "SP_SEARCH_CMS_PROCEDURE";
            public const string SP_GET_USER_MENU = "SP_GET_USER_MENU";
            public const string SP_GET_MASTER_ITEMS = "SP_GET_MASTER_ITEMS";
            public const string SP_GET_KPI_SLA = "SP_GET_KPI_SLA";
            
            public const string SP_GET_HELP_DOCUMENTS = "SP_GET_HELP_DOCUMENTS";
            public const string SP_INS_UPD_HELP_DOCUMENTS = "SP_INS_UPD_HELP_DOCUMENTS";
            public const string SP_GET_ROLE = "SP_GET_ROLE";
            public const string SP_INS_UPD_ROLE = "SP_INS_UPD_ROLE";
            public const string SP_GET_MODULE = "SP_GET_MODULE";
            public const string SP_INS_UPD_MODULE = "SP_INS_UPD_MODULE";
            public const string SP_GET_SCREEN = "SP_GET_SCREEN";
            public const string SP_INS_UPD_SCREEN = "SP_INS_UPD_SCREEN";
            public const string SP_GET_RA_CONTROL_TYPE = "SP_GET_RA_CONTROL_TYPE";
            public const string SP_INS_UPD_RA_CONTROL_TYPE = "SP_INS_UPD_RA_CONTROL_TYPE";
            public const string SP_GET_RA_CONTROL_OWNER_ROLE = "SP_GET_RA_CONTROL_OWNER_ROLE";
            public const string SP_RA_GET_ACTIVE_FREQUENCY = "SP_RA_GET_ACTIVE_FREQUENCY";
            public const string SP_INS_UPD_RA_CONTROL_OWNER_ROLE = "SP_INS_UPD_RA_CONTROL_OWNER_ROLE";
            public const string SP_GET_DIRECTORATES = "SP_GET_DIRECTORATES";
            public const string SP_GET_ASSETS = "SP_GET_ASSETS";
            public const string SP_GET_FACILITIES = "SP_GET_FACILITIES";
   
            public const string SP_GET_REASON_VARIANCE = "SP_GET_REASON_VARIANCE";
            public const string SP_INS_UPD_REASON_VARIANCE = "SP_INS_UPD_REASON_VARIANCE";
 
            public const string SP_GET_RA_HAZARD = "SP_GET_RA_HAZARD";
            public const string SP_INS_UPD_RA_HAZARD = "SP_INS_UPD_RA_HAZARD";
            public const string SP_GET_RA_HAZARD_EFFECTS = "SP_GET_RA_HAZARD_EFFECTS";
            public const string SP_INS_UPD_RA_HAZARD_EFFECTS = "SP_INS_UPD_RA_HAZARD_EFFECTS";
            public const string SP_GET_RA_CONTROL_MEASURE = "SP_GET_RA_CONTROL_MEASURE";
            public const string SP_INS_UPD_RA_CONTROL_MEASURE = "SP_INS_UPD_RA_CONTROL_MEASURE";
            public const string SP_GET_WF_STEPS = "SP_GET_WF_STEPS";
            public const string SP_GET_WF_ACTIONS = "SP_GET_WF_ACTIONS";
            public const string SP_GET_WF_STATUS = "SP_GET_WF_STATUS";
            public const string SP_GET_APPROVER_LIST = "SP_GET_APPROVER_LIST";

            public const string SP_GET_REQUEST_DOCUMENT = "SP_GET_REQUEST_DOCUMENT";
            public const string SP_INS_UPD_DOCUMENT = "SP_INS_UPD_DOCUMENT";

            public const string SP_GET_RA_APPROVER = "SP_GET_RA_APPROVER";
            
            public const string SP_INS_UPD_REQUEST = "SP_INS_UPD_REQUEST";
            public const string SP_GET_REQUEST = "SP_GET_REQUEST";
            public const string SP_UPD_APPROVAL_HISTORY = "SP_UPD_APPROVAL_HISTORY";
            public const string SP_GET_APPROVAL_HISTORY = "SP_GET_APPROVAL_HISTORY";
            public const string SP_GET_REQUEST_HISTORY = "SP_GET_REQUEST_HISTORY";
            public const string SP_GET_REQUEST_EXTENSION_HISTORY = "SP_GET_REQUEST_EXTENSION_HISTORY";

            
            public const string SP_GET_ALL_REQUESTS = "SP_GET_ALL_REQUESTS";
            public const string SP_GET_PENDING_WITH_REQUESTS = "SP_GET_PENDING_WITH_REQUESTS";
            
            public const string SP_GET_TASKS = "SP_GET_TASKS";
            public const string SP_GET_TASKS_HISTORY = "SP_GET_TASKS_HISTORY";
            
            public const string SP_GET_OUTBOX_MAIL = "SP_GET_OUTBOX_MAIL";
            public const string SP_VALIDATE_FACILITY_TOC = "SP_VALIDATE_FACILITY_TOC";
            public const string SP_UPD_EMAIL_SENT_STATUS = "SP_UPD_EMAIL_SENT_STATUS";
            public const string SP_GET_OTHER_EMOC_REQUESTS = "SP_GET_OTHER_EMOC_REQUESTS";
            public const string SP_GET_KPI = "SP_GET_KPI";
            public const string SP_GET_CONTROL_CENTER_STATUS = "SP_GET_CONTROL_CENTER_STATUS";
            public const string SP_GET_REQUEST_ID = "SP_GET_REQUEST_ID";
            public const string SP_GET_RISK_ASSESSMENT = "SP_GET_RISK_ASSESSMENT";
            public const string F_IS_OFFSET_REQUEST_EXIST = "F_IS_OFFSET_REQUEST_EXIST";
            public const string SP_GET_EXPIRED_OVERDUE_REQUESTS = "SP_GET_EXPIRED_OVERDUE_REQUESTS";
            public const string SP_GET_CONTACT_US = "SP_GET_CONTACT_US";
            public const string SP_INS_API_LOG = "SP_INS_API_LOG";
            public const string SP_GET_DRAFT_REQUESTS_FOR_DELETION = "SP_GET_DRAFT_REQUESTS_FOR_DELETION";

            public const string SP_GET_EMAIL_TEMPLATE = "SP_GET_EMAIL_TEMPLATE";
            public const string SP_UPD_EMAIL_TEMPLATE = "SP_UPD_EMAIL_TEMPLATE";

            public const string SP_GET_TOTAL_EXPIRED_KPI = "SP_GET_TOTAL_EXPIRED_KPI";
            public const string SP_GET_PIE_CHART_PARAMS = "SP_GET_PIE_CHART_PARAMS";
            public const string SP_GET_QUARTER_BASED_ON_YEAR = "SP_GET_QUARTER_BASED_ON_YEAR";
            public const string SP_GET_PIE_CHART_BY_STATUS = "SP_GET_PIE_CHART_BY_STATUS";
        }
        #endregion
    }
}