﻿using eMOC_PV_Common;
using eMOC_PV_DataAccess.Interface;
using eMOC_PV_Models;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Text;

namespace eMOC_PV_DataAccess.Repository
{
    public class RequestRepository : DataBaseHelper, IRequestRepository
    {

        public RequestRepository(IConfiguration config) : base(config) { }

        #region Workflow Progress Bar (Steps)
        public List<Steps> GetWorkflowSteps(int RequestId = 0, int WorkflowTypeId = 1)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_REQUEST_ID, OracleDbType.Int32, RequestId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_WF_TYPE_ID, OracleDbType.Int32, WorkflowTypeId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_LOGGED_USER, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_WF_STEPS, parameterList);
                return ds.Tables[0] == null ? new() : ds.Tables[0].ToList<Steps>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Workflow Actions
        public List<Actions> GetWorkflowActions(int RequestId = 0, int WorkFlowypeId = 0)
        {
            try
                {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_REQUEST_ID, OracleDbType.Int32, RequestId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_WF_TYPE_ID, OracleDbType.Int32, WorkFlowypeId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_LOGGED_USER, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_WF_ACTIONS, parameterList);
                return ds.Tables[0] == null ? new() : ds.Tables[0].ToList<Actions>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion  

        #region Request Document
        public List<RequestDocument> GetRequestDocument(int Id, int RequestId)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new (DBConstants.Input.P_ID, OracleDbType.Int64, Id, ParameterDirection.Input),
                    new (DBConstants.Input.P_REQUEST_ID, OracleDbType.Int64, RequestId, ParameterDirection.Input),
                    new (DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor,ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_REQUEST_DOCUMENT, parameterList);
                return ds == null ? new() : ds.Tables[0].ToList<RequestDocument>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public RequestDocument SaveRequestDocument(RequestDocument model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new(DBConstants.Input.P_ID, OracleDbType.Int64, model.Id, ParameterDirection.Input),
                    new(DBConstants.Input.P_REQUEST_ID, OracleDbType.Int64, model.RequestId, ParameterDirection.Input),
                 
                    new(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.FileName, ParameterDirection.Input),
                    new(DBConstants.Input.P_COMMENTS, OracleDbType.Varchar2, model.Comment, ParameterDirection.Input),
                    new(DBConstants.Input.P_MIME_TYPE, OracleDbType.Varchar2, model.MimeType, ParameterDirection.Input),
                    new(DBConstants.Input.P_ORDER_NO, OracleDbType.Int16, model.OrderNo, ParameterDirection.Input),
                    new(DBConstants.Input.P_ROLE_ID, OracleDbType.Int32, model.UserRoleId, ParameterDirection.Input),
                    new(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_DOCUMENT, parameterList);
                return ds == null ? new() : ds.Tables[0].ToObject<RequestDocument>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Request
        public Response SaveRequest(Request model)
        {
            try
            {
                
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int64, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_APPROVER, OracleDbType.Varchar2, model.NextApprover, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CURRENT_STEP, OracleDbType.Int64, model.CurrentStepId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CURRENT_STATUS, OracleDbType.Int64, model.WorkflowStatusId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_WF_ACTION_ID, OracleDbType.Int64, model.WorkflowActionId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NEXT_ROLE_ID, OracleDbType.Int64, model.NextApproverRoleId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NOTIFYTO, OracleDbType.Varchar2, model.NotifyTo, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_COMMENTS, OracleDbType.Varchar2, model.Comment, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_GENERAL, OracleDbType.Clob, model.General.ToJson(), ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_DOCUMENTS, OracleDbType.Clob, model.Documents.ToJson(), ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_RA_TEAM_MEMBERS, OracleDbType.Clob, model.RATeamMembers.ToJson(), ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_RISK_ASSESSMENT, OracleDbType.Clob, model.RiskAssessment.ToJson(new List<string>{"RAMatrix","CumulativeRAMatrix"}), ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_RA_MATRIX, OracleDbType.Clob, model.RiskAssessment.RAMatrix, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CUMULATIVE_RA_MATRIX, OracleDbType.Clob, model.RiskAssessment.CumulativeRAMatrix, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_REQUEST, parameterList);
                return ds.Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Request GetRequest(int RequestId)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int64, RequestId, ParameterDirection.Input),
                         new OracleParameter(DBConstants.Input.P_LOGGED_USER, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor,ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_GENERAL, OracleDbType.RefCursor,ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_DOCUMENTS, OracleDbType.RefCursor,ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_RA_TEAM_MEMBERS, OracleDbType.RefCursor,ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_RISK_ASSESSMENT, OracleDbType.RefCursor,ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_BACKUP_APPROVERS, OracleDbType.RefCursor,ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_TASK, OracleDbType.RefCursor,ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_APPROVER_HISTORY, OracleDbType.RefCursor,ParameterDirection.Output),
                       new OracleParameter(DBConstants.Output.P_REQUEST_EXTENSION_HISTORY, OracleDbType.RefCursor,ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_REQUEST, parameterList);
                Request request;
                request = ds.Tables.Count > 0 ? ds.Tables[0].ToObject<Request>() : new();
                request.General = ds.Tables.Count > 1 ? ds.Tables[1].ToObject<General>() : new();
                request.Documents = ds.Tables.Count > 2 ? ds.Tables[2].ToList<RequestDocument>() : new();
                request.RATeamMembers = ds.Tables.Count > 3 ? ds.Tables[3].ToList<RATeamMember>() : new();
                request.RiskAssessment = ds.Tables.Count > 4 ? ds.Tables[4].ToObject<RiskAssessment>() : new();
                request.BackupApprovers = ds.Tables.Count > 5 ? ds.Tables[5].ToList<UserDetail>() :  new();
                request.ActiveTask = ds.Tables.Count > 6 ? ds.Tables[6].ToObject<Tasks>() : new();
                request.ApproverHistory = ds.Tables.Count > 7 ? ds.Tables[7].ToList<ApproverHistory>() : new();
                request.RequestExtensionList = ds.Tables.Count > 8 ? ds.Tables[8].ToList<RequestExtension>() : new();

                return request;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Request GetRequestHistory(decimal Id)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[] {
                    new OracleParameter(DBConstants.Input.P_ID,OracleDbType.Int64, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_REQUEST_HISTORY, parameterList);
                byte[] resObj = (byte[])ds.Tables[0].Rows[0]["History"];
                return Encoding.UTF8.GetString(resObj).ToObject<Request>();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<RequestExtension> GetExtensionHistory(decimal Id)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[] {
                    new OracleParameter(DBConstants.Input.P_ID,OracleDbType.Int64, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_REQUEST_EXTENSION_HISTORY, parameterList);
                return ds.Tables[0].ToList<RequestExtension>();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public List<ApproverHistory> GetApproverHistory(int RequestId)
        {
            OracleParameter[] parameterList = new OracleParameter[]
            {
                new OracleParameter(DBConstants.Input.P_REQUEST_ID, OracleDbType.Int32, RequestId, ParameterDirection.Input),
                new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
            };
            DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_APPROVAL_HISTORY, parameterList);
            return ds.Tables[0].ToList<ApproverHistory>();
        }

        public Response UpdateHistory(decimal RequestId, string history)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_REQUEST_ID, OracleDbType.Int64, RequestId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_HISTORY, OracleDbType.Blob, history.StringToByteArray(), ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                return OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_UPD_APPROVAL_HISTORY, parameterList).Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<AllRequest> GetAllRequests(AllRequestFilter model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_FIRST,OracleDbType.Int32, model.First, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_ROWS,OracleDbType.Int32, model.Rows, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_FILTER,OracleDbType.Clob,model.RequestFilter, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_FULL_RECORD,OracleDbType.Int32,model.FullRecords, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_SORT_FIELD,OracleDbType.Varchar2, string.IsNullOrEmpty(model.SortField)? "Id" : model.SortField, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_SORT_ORDER,OracleDbType.Varchar2, string.IsNullOrEmpty(model.SortOrder)? "Desc" : model.SortOrder, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, model.CreatedBy, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT,OracleDbType.RefCursor,ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_ALL_REQUESTS, parameterList);
                return ds.Tables[0].ToList<AllRequest>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<AllRequest> GetPendingWithRequests(AllRequestFilter model)
        {
            try
           {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_FIRST,OracleDbType.Int32, model.First, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_ROWS,OracleDbType.Int32, model.Rows, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_FILTER,OracleDbType.Clob,model.RequestFilter, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_FULL_RECORD,OracleDbType.Int32,model.FullRecords, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_SORT_FIELD,OracleDbType.Varchar2, string.IsNullOrEmpty(model.SortField)? "Id" : model.SortField, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_SORT_ORDER,OracleDbType.Varchar2, string.IsNullOrEmpty(model.SortOrder)? "Desc" : model.SortOrder, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, model.CreatedBy, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT,OracleDbType.RefCursor,ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_PENDING_WITH_REQUESTS, parameterList);
                return ds.Tables[0].ToList<AllRequest>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Tasks> GetTaskHistory(decimal Id)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_REQUEST_ID,OracleDbType.Int64, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_STATUS, OracleDbType.Int16, 3, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_LOGGED_USER, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_TASKS, parameterList);
                return ds.Tables[0].ToList<Tasks>();
            }
            catch (Exception)
            {
                throw;
            }
        }


        public List<Tasks> GetTaskHistoryByRequestId(decimal Id)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_REQUEST_ID,OracleDbType.Int64, Id, ParameterDirection.Input),
                
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_TASKS_HISTORY, parameterList);
                return ds.Tables[0].ToList<Tasks>();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Email> GetOutboxMails(decimal RequestId = 0)
        {
            try
            {
                OracleParameter[] parameterList = new[]
                {
                    new OracleParameter(DBConstants.Input.P_REQUEST_ID, OracleDbType.Int64, RequestId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_OUTBOX_MAIL, parameterList);
                return ds.Tables[0].ToList<Email>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public bool UpdateEmailSentStatus(decimal Id)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int64, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_STATUS_CODE, OracleDbType.Int32, ParameterDirection.Output)
                };
                OracleHelper.ExecuteNonQuery(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_UPD_EMAIL_SENT_STATUS, parameterList);
                int status = Conversions.ToInt(parameterList[1].Value.ToString());
                return Convert.ToBoolean(status);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Expired & Overdue Requests
        public List<Request> GetExpiredOverdueRequests()
        {
            try
            {
                OracleParameter[] parameterList = new[]
                {
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_EXPIRED_OVERDUE_REQUESTS, parameterList);
                return ds.Tables[0].ToList<Request>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Copy Risk Assessment
        public List<GenericData> GetRequestId(decimal Id)
        {
            try
            {
                OracleParameter[] parameterList = new[]
                {
                    new OracleParameter(DBConstants.Input.P_REQUEST_ID, OracleDbType.Int64, Id, ParameterDirection.Input),
               
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                return OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_REQUEST_ID, parameterList).Tables[0].ToList<GenericData>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public RiskAssessment GetRiskAssessment(decimal RequestId)
        {
            try
            {
                OracleParameter[] parameterList = new[]
                {
                    new OracleParameter(DBConstants.Input.P_REQUEST_ID, OracleDbType.Int64, RequestId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_RISK_ASSESSMENT, parameterList);
                return ds.Tables[0].ToObject<RiskAssessment>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

     

        #region Dashboard
        public dynamic GetDashboardCharts(string FilterString)
        {
            try
            {
                OracleParameter[] parameterList = new[]
                    {
                new OracleParameter(DBConstants.Input.P_FILTER, OracleDbType.Varchar2, FilterString, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_CHART1, OracleDbType.RefCursor, ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_CHART2, OracleDbType.RefCursor, ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_CHART3, OracleDbType.RefCursor, ParameterDirection.Output)
            };
                return OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_KPI, parameterList);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public dynamic GetControlCenterStatus()
        {
            try
            {
                OracleParameter[] parameterList = new[]
                {
                    new OracleParameter(DBConstants.Output.P_CHART1, OracleDbType.RefCursor, ParameterDirection.Output),
                };
                return OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_CONTROL_CENTER_STATUS, parameterList);
            }
            catch (Exception)
            {
                throw;
            }
        }


        public dynamic GetTotalExpiredKPI(string FilterString)
        {
            try
            {
                OracleParameter[] parameterList = new[]
                    {
                   new OracleParameter(DBConstants.Input.P_FILTER, OracleDbType.Varchar2, FilterString, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_CHART1, OracleDbType.RefCursor, ParameterDirection.Output),
            };
                return OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_TOTAL_EXPIRED_KPI, parameterList);
            }
            catch (Exception)
            {
                throw;
            }
        }


        public dynamic GetPieChartParams()
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Output.P_OUTPUT_CHART_TYPE, OracleDbType.RefCursor, ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_OUTPUT_YEAR, OracleDbType.RefCursor, ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_OUTPUT_MONTH, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_PIE_CHART_PARAMS, parameterList);
                return ds.Tables;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public dynamic GetQuarterBasedOnyear(string year)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2,year, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_CHART1, OracleDbType.RefCursor, ParameterDirection.Output),
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_QUARTER_BASED_ON_YEAR, parameterList);
                return ds.Tables;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public dynamic GetPieChartDetailsByStatus(string FilterString)
        {
            try
            {
                OracleParameter[] parameterlist = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_FILTER, OracleDbType.Clob,FilterString,ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_CHART1, OracleDbType.RefCursor, ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_PIE_CHART_BY_STATUS, parameterlist);
                return ds.Tables;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        #endregion




        #region RA Approvers
        public RAApprovers GetRAApprovers(string DirectorateCode,string AssetCode, string RRName, string CRName)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                      new OracleParameter(DBConstants.Input.P_DIRECTORATE, OracleDbType.Varchar2, DirectorateCode, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_ASSET, OracleDbType.Varchar2, AssetCode, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_RRR_NAME, OracleDbType.Varchar2, RRName, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CRRR_NAME, OracleDbType.Varchar2, CRName, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_USER_DATA, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_RA_APPROVER, parameterList);
                RAApprovers res = ds.Tables[0].ToObject<RAApprovers>();
                res.RAApproverUsers = ds.Tables[1].ToList<UserDetail>();
                return res;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion



           #region Draft Requests For Deletion
        public  List<Request> GetDraftRequestsForDeleting()
        {
            try
            {
                OracleParameter[] parameterList = new[]
                {
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_DRAFT_REQUESTS_FOR_DELETION, parameterList);
                return ds.Tables[0].ToList<Request>();
            }
            catch (Exception)
            {
                throw;
            }
        }

     
        #endregion

    }
}
