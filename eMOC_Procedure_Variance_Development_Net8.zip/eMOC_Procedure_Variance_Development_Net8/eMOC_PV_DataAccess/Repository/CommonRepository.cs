﻿using eMOC_PV_Common;
using eMOC_PV_DataAccess.Interface;
using eMOC_PV_Models;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.DirectoryServices.ActiveDirectory;

namespace eMOC_PV_DataAccess.Repository
{
    public class CommonRepository : DataBaseHelper, ICommonRepository
    {
        #region Constructor
        public CommonRepository(IConfiguration config) : base(config)
        { }
        #endregion

        #region User Detail
        public UserDetail GetUserDetail()
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_MU_NUMBER, OracleDbType.Varchar2,Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_USER_DATA, OracleDbType.RefCursor, ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_ROLES, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_USER_DETAIL, parameterList);
                UserDetail userDetail = new();
                if (ds.Tables[0] != null || ds.Tables[0].Rows.Count > 0)
                {
                    userDetail = ds.Tables[0].ToObject<UserDetail>();
                    userDetail.UserRoles = ds.Tables[1].ToList<Roles>();
                    return userDetail;
                }
                else
                    throw new Exception(Global.User.MuNumber + " not found in DWH");
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Is Authorized
        public bool IsAuthorized(string ScreenCode)
        {
                bool Is_Authorized = false;
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_MU_NUMBER, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_SCREEN_CODE, OracleDbType.Varchar2, ScreenCode, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_IS_USER_AUTHORIZED, parameterList);
                Is_Authorized = Conversions.ToInt(ds.Tables[0].Rows[0]["IsAuthorized"]) == 1 ? true : false;

                return Is_Authorized;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion

        #region Log Error
        public void SaveErrorLog(ErrorLog model, string createdBy = null)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ERROR_ID, OracleDbType.Varchar2, model.ErrorId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_EXCEPTION, OracleDbType.Varchar2, model.Exception, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_STACK, OracleDbType.Varchar2, model.StackTrace, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, createdBy == null ? Global.User.MuNumber : createdBy, ParameterDirection.Input)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_LOG_ERROR, parameterList);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region API Log
        public void SaveApiLog(ApiLog model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_METHOD, OracleDbType.Varchar2, model.Method, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_API, OracleDbType.Varchar2, model.Url, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_STATUS_CODE, OracleDbType.Int32, model.StatusCode, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IP_ADDRESS, OracleDbType.Varchar2, model.IPAddress, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_HOST_NAME, OracleDbType.Varchar2, model.HostName, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CLIENT_MACHINE, OracleDbType.Varchar2, model.ClientMachine, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, model.CreatedBy, ParameterDirection.Input)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_API_LOG, parameterList);
            }
            catch (Exception ex)
            {
                Guid errorId = Guid.NewGuid();
                SaveErrorLog(new ErrorLog() { ErrorId = errorId.ToString(), Exception = ex.Message, StackTrace = ex.StackTrace }, model.CreatedBy == null ? "System" : model.CreatedBy);
            }
        }
        #endregion

        #region Search User (Autocomplete)
        public List<UserDetail> SearchUser(string Keyword)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_KEYWORD, OracleDbType.Varchar2, Keyword, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_USER_DATA, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_SEARCH_USERS, parameterList);
                return ds.Tables[0].ToList<UserDetail>(); ;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region User Menu
        public UserMenu GetUserMenu()
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_MU_NUMBER, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_MODULE, OracleDbType.RefCursor, ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_SCREENS, OracleDbType.RefCursor, ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_ROLES, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_USER_MENU, parameterList);
                UserMenu usermenu = new();
                usermenu.ModulesList = ds.Tables[0].ToList<Module>();
                usermenu.ScreensList = ds.Tables[1].ToList<Screen>();
                usermenu.UserRolesList = ds.Tables[2].ToList<Roles>();
                return usermenu;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Help Document
        public HelpDocument SaveHelpDocumemt(HelpDocument model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.FileName, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_DISPLAY_NAME, OracleDbType.Varchar2, model.DisplayName, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_GUID, OracleDbType.Varchar2, model.Guid, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_ORDER_NO, OracleDbType.Int32, model.OrderNo, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int32, model.IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_HELP_DOCUMENTS, parameterList);
                return ds.Tables[0].ToObject<HelpDocument>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public List<HelpDocument> GetHelpDocument(decimal Id = 0, int IsActive = 2)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int32, IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output),
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_HELP_DOCUMENTS, parameterList);
                return ds.Tables[0].ToList<HelpDocument>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Contact Us Information
        public dynamic GetContactUs()
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_CONTACT_US, parameterList);
                return ds.ToJson();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Search User (Autocomplete)
        public List<CMSProcedure> SearchCMSProcedure(string Keyword)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_KEYWORD, OracleDbType.Varchar2, Keyword, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_USER_DATA, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_SEARCH_CMS_PROCEDURE, parameterList);
                return ds.Tables[0].ToList<CMSProcedure>(); ;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion


        #region Get UserList By RefrenceIndicator
        public List<UserDetail> GetUserListByRefrenceIndicator(string Keyword)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_KEYWORD, OracleDbType.Varchar2, Keyword, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_USER_DATA, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_SEARCH_USERS_BY_REFRENCEINDICATOR, parameterList);
                return ds.Tables[0].ToList<UserDetail>(); ;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
