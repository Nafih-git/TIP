﻿using eMOC_PV_Common;
using eMOC_PV_DataAccess.Interface;
using eMOC_PV_Models;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace eMOC_PV_DataAccess.Repository
{
    public class MasterRepository : DataBaseHelper, IMasterRepository
    {
        public MasterRepository(IConfiguration config) : base(config) { }

        #region Master Items
        public List<GenericData> GetMasterItems()
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_MASTER_ITEMS, parameterList);
                return ds.Tables[0].ToList<GenericData>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Roles
        public List<Roles> GetRole(int Id = 0, int IsActive = 2)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int32, IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_ROLES, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_ROLE, parameterList);
                return ds.Tables[0].ToList<Roles>();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Response SaveRole(Roles model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CODE, OracleDbType.Varchar2, model.Code, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_DESCRIPTION, OracleDbType.Varchar2, model.Description, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_DIRECTORATE, OracleDbType.Int16, model.IsDirectorate, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ASSET, OracleDbType.Int16, model.IsAsset, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_DELEGATED_ROLE, OracleDbType.Int16, model.IsDelegatedRole, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_SUB_ADMIN, OracleDbType.Int16, model.IsSBA, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_SUPER_ADMIN, OracleDbType.Int16, model.IsSPA, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_ORDER_NO, OracleDbType.Int16, model.OrderNo, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int16, model.IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_ROLE, parameterList);
                return ds.Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }


        public List<Roles> GetKPISLA()
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_KPI_SLA, parameterList);
                return ds.Tables[0].ToList<Roles>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Modules
        public List<Module> GetModule(int Id = 0, int IsActive = 2)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int32, IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_MODULE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_MODULE, parameterList);
                return ds.Tables[0].ToList<Module>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public Response SaveModule(Module model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_DESCRIPTION, OracleDbType.Varchar2, model.Description, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_ORDER_NO, OracleDbType.Int16, model.OrderNo, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int16, model.IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_ICON, OracleDbType.Varchar2, model.Icon, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_MODULE, parameterList);
                return ds.Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Screen
        public List<Screen> GetScreen(int Id = 0, int IsActive = 2)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int32, IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_SCREENS, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_SCREEN, parameterList);
                return ds.Tables[0].ToList<Screen>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public Response SaveScreen(Screen model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_URL, OracleDbType.Varchar2, model.URL, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_ICON, OracleDbType.Varchar2, model.Icon, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_MODULE_ID, OracleDbType.Int16, model.ModuleId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_SUB_ADMIN, OracleDbType.Int16, model.IsSAOnly, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_SUPER_ADMIN, OracleDbType.Int16, model.IsCAOnly, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_ORDER_NO, OracleDbType.Int16, model.OrderNo, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int16, model.IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_SCREEN, parameterList);
                return ds.Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region RA Control Type
        public List<RAControlType> GetRAControlType(int Id = 0, int IsActive = 2)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int32, IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_RA_CONTROL_TYPE, parameterList);
                return ds.Tables[0].ToList<RAControlType>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public Response SaveRAControlType(RAControlType model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int16, model.IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_RA_CONTROL_TYPE, parameterList);
                return ds.Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region RA Control Owner Role
        public List<RAControlOwnerRole> GetRAControlOwnerRole(int Id = 0, int IsActive = 2, string Name = "", int RetType = 0)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int32, IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_RET_TYPE, OracleDbType.Int32, RetType, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_RA_CONTROL_OWNER_ROLE, parameterList);
                return ds.Tables[0].ToList<RAControlOwnerRole>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public Response SaveRAControlOwnerRole(RAControlOwnerRole model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int16, model.IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_RA_CONTROL_OWNER_ROLE, parameterList);
                return ds.Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Frequency
        //public List<FrequencyList> GetFrequency()
        //{
        //    try
        //    {
        //        OracleParameter[] parameterList = new OracleParameter[]
        //        {
        //            new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
        //        };
        //        DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_RA_GET_ACTIVE_FREQUENCY, parameterList);
        //        return ds.Tables[0].ToList<FrequencyList>();
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //}

        public List<FrequencyList> GetFrequency()
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
            new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_RA_GET_ACTIVE_FREQUENCY, parameterList);

                var result = new List<FrequencyList>();

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    result.Add(new FrequencyList
                    {
                        Id = row["ID"] == DBNull.Value ? 0 : Convert.ToInt32(row["ID"]),
                        Name = row["NAME"]?.ToString(),
                        IsActive = row["IsActive"] == DBNull.Value ? (short)0 : Convert.ToInt16(row["IsActive"])
                    });
                }

                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #region RA Hazard
        public List<RAHazard> GetRAHazard(int Id = 0, int IsActive = 2, string Name = "", int RetType = 0)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int32, IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_RET_TYPE, OracleDbType.Int32, RetType, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_RA_HAZARD, parameterList);
                return ds.Tables[0].ToList<RAHazard>();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Response SaveRAHazard(RAHazard model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int16, model.IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_RA_HAZARD, parameterList);
                return ds.Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region RA Effect of Hazard
        public List<RAHazardEffects> GetRAHazardEffect(int Id = 0, int HazardId = 0, int IsActive = 2, string Name = "", int RetType = 0)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_HAZARD_ID, OracleDbType.Int32, HazardId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int32, IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_RET_TYPE, OracleDbType.Int32, RetType, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_RA_HAZARD_EFFECTS, parameterList);
                return ds.Tables[0].ToList<RAHazardEffects>();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Response SaveRAHazardEffect(RAHazardEffects model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_HAZARD_ID, OracleDbType.Int32, model.HazardId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int16, model.IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_RA_HAZARD_EFFECTS, parameterList);
                return ds.Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region RA Control Measure
        public List<RAControlMeasure> GetRAControlMeasure(int Id = 0, int HazardId = 0, int IsActive = 2, string Name = "", int RetType = 0)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_HAZARD_ID, OracleDbType.Int32, HazardId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int32, IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_RET_TYPE, OracleDbType.Int32, RetType, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_RA_CONTROL_MEASURE, parameterList);
                return ds.Tables[0].ToList<RAControlMeasure>();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Response SaveRAControlMeasure(RAControlMeasure model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_HAZARD_ID, OracleDbType.Int32, model.HazardId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int16, model.IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_RA_CONTROL_MEASURE, parameterList);
                return ds.Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Directorate
        public List<Directorates> GetDirectorates()
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_DIRECTORATES, parameterList);
                return ds.Tables[0].ToList<Directorates>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Asset
        public List<Assets> GetAssets(string Directorate = null)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_DIRECTORATE, OracleDbType.Varchar2, Directorate, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_ASSETS, parameterList);
                return ds.Tables[0].ToList<Assets>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Facility
        public List<Facilities> GetFacilities(string Asset = null, string Directorate = null)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ASSET, OracleDbType.Varchar2, Asset, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_DIRECTORATE, OracleDbType.Varchar2, Directorate, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_FACILITIES, parameterList);
                return ds.Tables[0].ToList<Facilities>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion



        #region Reason For Variance
        public List<ReasonVariance> GetReasonVariance(int Id = 0, int IsActive = 2)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, Id, ParameterDirection.Input),
             
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int32, IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_REASON_VARIANCE, parameterList);
                return ds.Tables[0].ToList<ReasonVariance>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public Response SaveReasonVariance(ReasonVariance model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.Name, ParameterDirection.Input),
               
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int16, model.IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_ORDER_NO, OracleDbType.Int16, model.OrderNo, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_INS_UPD_REASON_VARIANCE, parameterList);
                return ds.Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

       

        

        #region Approvers List
        public List<UserDetail> GetApprovers(int RoleId, string Directorate, string Asset)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ROLE_ID, OracleDbType.Int32, RoleId, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_DIRECTORATE, OracleDbType.Varchar2, Directorate, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_ASSET, OracleDbType.Varchar2, Asset, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_APPROVER_LIST, parameterList);
                return ds.Tables[0].ToList<UserDetail>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Workflow Status
        public List<Status> GetWorkflowStatus()
        {
            try
            {
                OracleParameter[] parameter = { new(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output) };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_WF_STATUS, parameter);
                return ds.Tables[0].ToList<Status>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion


        #region Email Template
        public List<EmailTemplate> GetEmailTemplates(int Id = 0)
        {
            try
            {
                OracleParameter[] parameter = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_GET_EMAIL_TEMPLATE, parameter);
                return ds.Tables[0].ToList<EmailTemplate>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public Response SaveEmailTemplate(EmailTemplate model)
        {
            try
            {
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(DBConstants.Input.P_ID, OracleDbType.Int32, model.Id, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_NAME, OracleDbType.Varchar2, model.Name, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_SUBJECT, OracleDbType.Varchar2, model.Subject, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_BODY, OracleDbType.Varchar2, model.Body, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_IS_ACTIVE, OracleDbType.Int16, model.IsActive, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Input.P_CREATED_BY, OracleDbType.Varchar2, Global.User.MuNumber, ParameterDirection.Input),
                    new OracleParameter(DBConstants.Output.P_RESPONSE, OracleDbType.RefCursor, ParameterDirection.Output)
                };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, DBConstants.Procedures.SP_UPD_EMAIL_TEMPLATE, parameterList);
                return ds.Tables[0].ToObject<Response>();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
