﻿
using eMOC_PV_Common;
using eMOC_PV_DataAccess.Interface;
using eMOC_PV_Models;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace eMOC_PV_DataAccess.Repository
{
    public class UserManagementRepository : DataBaseHelper, IUserManagementRepository
    {
        #region Store Procedures
        private const string SP_GET_ALL_USER_MANAGEMENT = "SP_GET_ALL_USER_MANAGEMENT";
        private const string SP_GET_USER_MANAGEMENT = "SP_GET_USER_MANAGEMENT";
        private const string SP_INS_UPD_USER_MANAGEMENT = "SP_INS_UPD_USER_MANAGEMENT";
        private const string SP_SEARCH_USERS = "SP_SEARCH_USERS";
        public const string SP_GET_ASSETS_FOR_UM = "SP_GET_ASSETS_FOR_UM";
        public const string SP_GET_DIRECTORATES_FOR_UM = "SP_GET_DIRECTORATES_FOR_UM";
        public const string SP_GET_USER_MANAGEMENT_BY_ID = "SP_GET_USER_MANAGEMENT_BY_ID";



        #endregion

        #region Out Parameters
        public const string P_OUTSTATUSMESSAGE = "P_OUTSTATUSMESSAGE";
        public const string P_OUTPUT = "P_OUTPUT";
        #endregion

        #region Parameters
        private const string P_ASSETNAME = "P_ASSETNAME";
        private const string P_DIRECTORATENAME = "P_DIRECTORATENAME";
        private const string P_ROLECODE = "P_ROLECODE";
        private const string P_ID = "P_ID";
        private const string P_ROLEID = "P_ROLEID";
        private const string P_APPROVERS = "P_APPROVERS";
        private const string P_CREATEDBY = "P_CREATEDBY";
        private const string P_LOGEDINUSER = "P_LOGEDINUSER";
        private const string P_KEYWORD = "P_KEYWORD";
        #endregion

        public UserManagementRepository(IConfiguration config) : base(config) { }



        public List<UserManagement> GetAll()
        {
            try
            {
                List<UserManagement> UserManagementList = new List<UserManagement>();
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(P_LOGEDINUSER, Global.User.MuNumber),
                new OracleParameter(P_OUTSTATUSMESSAGE, OracleDbType.RefCursor,ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, SP_GET_ALL_USER_MANAGEMENT, parameterList);
                UserManagementList = ds.Tables[0].ToList<UserManagement>();

                return UserManagementList;
            }
            catch (Exception)
            {
                throw;
            }

        }


        public UserManagement? GetById(int UserManagementId)
        {
            try
            {
                UserManagement UserManagement = null;
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(P_ID, UserManagementId),
                     new OracleParameter(P_OUTSTATUSMESSAGE, OracleDbType.RefCursor,ParameterDirection.Output),
                new OracleParameter(P_OUTPUT, OracleDbType.RefCursor,ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, SP_GET_USER_MANAGEMENT_BY_ID, parameterList);
                UserManagement = ds.Tables[0].ToObject<UserManagement>();
                if (UserManagement != null)
                {
                    UserManagement.UserManagementDetailList = ds.Tables[1].ToList<UserManagementDetail>();
                }

                return UserManagement;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public UserManagement GetByFilters(UserManagement model)
        {
            try
            {
                    UserManagement UserManagement = new UserManagement();
                OracleParameter[] parameterList = new OracleParameter[]
                {
                      new OracleParameter(P_DIRECTORATENAME, model.DirectorateCode),
                     new OracleParameter(P_ASSETNAME, model.AssetCode),
                     new OracleParameter(P_ROLECODE, model.RoleId),
                      new OracleParameter(P_OUTPUT, OracleDbType.RefCursor,ParameterDirection.Output),
                     new OracleParameter(P_OUTSTATUSMESSAGE, OracleDbType.RefCursor,ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, SP_GET_USER_MANAGEMENT, parameterList);
                UserManagement = ds.Tables[0].ToObject<UserManagement>();
                if (UserManagement != null)
                {
                    UserManagement.UserManagementDetailList = ds.Tables[1].ToList<UserManagementDetail>();
                }


                return UserManagement;
            }
            catch (Exception)
            {
                throw;
            }
        }


        public Response Save(UserManagement model)
        {
            try
            {
                UserManagement UserManagement = new UserManagement();
                OracleParameter[] parameterList = new OracleParameter[]
                {
                     new OracleParameter(P_ID, model.Id),
                          new OracleParameter(P_DIRECTORATENAME, model.DirectorateCode),
                     new OracleParameter(P_ASSETNAME, model.AssetCode),
                     new OracleParameter(P_ROLEID, model.RoleId),
                     new OracleParameter(P_APPROVERS, Conversions.ToJson(model.UserManagementDetailList)),
                        new OracleParameter(P_CREATEDBY, Global.User.MuNumber.ToString() ),
                     new OracleParameter(P_OUTSTATUSMESSAGE, OracleDbType.RefCursor,ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, SP_INS_UPD_USER_MANAGEMENT, parameterList);

                Response res = ds.Tables[0].ToObject<Response>();
                return res;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<UserDetail> SearchUser(string keyword)
        {
            try
            {
                List<UserDetail> UserDetailList = new List<UserDetail>();
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(P_KEYWORD, keyword),
                    new OracleParameter(P_OUTSTATUSMESSAGE, OracleDbType.RefCursor,ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, SP_SEARCH_USERS, parameterList);
                UserDetailList = ds.Tables[0].ToList<UserDetail>();

                return UserDetailList;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Directorates> GetDirectorate()
        {
            try
            {
                List<Directorates> list = new List<Directorates>();
                OracleParameter[] parameterList = new OracleParameter[]
               {
                    new OracleParameter(P_LOGEDINUSER,  Global.User.MuNumber),
                new OracleParameter(P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
               };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, SP_GET_DIRECTORATES_FOR_UM, parameterList);
                list = ds.Tables[0].ToList<Directorates>();
                return list;
            }

            catch (Exception)
            {
                throw;
            }

        }
        public List<Assets> GetAssest(string DirectorateName)
        {
            try
            {
                List<Assets> list = new List<Assets>();
                OracleParameter[] parameterList = new OracleParameter[]
               {
                    new OracleParameter(P_DIRECTORATENAME, DirectorateName),
                    new OracleParameter(P_LOGEDINUSER,  Global.User.MuNumber),
                new OracleParameter(P_OUTPUT, OracleDbType.RefCursor, ParameterDirection.Output)
               };
                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, SP_GET_ASSETS_FOR_UM, parameterList);
                list = ds.Tables[0].ToList<Assets>();
                return list;
            }

            catch (Exception)
            {
                throw;
            }

        }
    }
}
