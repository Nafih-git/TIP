﻿
using eMOC_PV_Common;
using eMOC_PV_DataAccess.Interface;
using eMOC_PV_Models;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace eMOC_PV_DataAccess.Repository
{
    public class DelegationRepository : DataBaseHelper, IDelegationRepository
    {
        #region Store Procedures
        private const string SP_GET_ALL_DELEGATION = "SP_GET_ALL_DELEGATION";

        private const string SP_INS_UPD_DELEGATION = "SP_INS_UPD_DELEGATION";

        #endregion

        #region Out Parameters
        public const string P_OUTSTATUSMESSAGE = "P_OUTSTATUSMESSAGE";
        public const string P_OUTPUT = "P_OUTPUT";
        #endregion

        #region Parameters
        private const string P_FROMDATE = "P_FROMDATE";
        private const string P_TODATE = "P_TODATE";
        private const string P_ACTUAL_USER = "P_ACTUAL_USER";
        private const string P_IS_DELETED = "P_IS_DELETED";
        private const string P_ROLEID = "P_ROLEID";
        private const string P_BACKUP_USER = "P_BACKUP_USER";
        private const string P_CREATEDBY = "P_CREATEDBY";
        private const string P_LOGEDINUSER = "P_LOGEDINUSER";
        private const string P_KEYWORD = "P_KEYWORD";
        private const string P_ID = "P_ID";
        
        #endregion

        public DelegationRepository(IConfiguration config) : base(config) { }



        public List<Delegation> GetAll()
        {
            try
            {
                List<Delegation> DelegationList = new List<Delegation>();
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(P_LOGEDINUSER, Global.User.MuNumber),
                new OracleParameter(P_OUTSTATUSMESSAGE, OracleDbType.RefCursor,ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, SP_GET_ALL_DELEGATION, parameterList);
                DelegationList = ds.Tables[0].ToList<Delegation>();

                return DelegationList;
            }
            catch (Exception)
            {
                throw;
            }

        }


        public Delegation? GetById(int DelegationId)
        {
            try
            {
                Delegation Delegation = null;
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(P_ID, DelegationId),
                     new OracleParameter(P_OUTSTATUSMESSAGE, OracleDbType.RefCursor,ParameterDirection.Output),
                new OracleParameter(P_OUTPUT, OracleDbType.RefCursor,ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "SP_GET_USER_MANAGEMENT_BY_ID", parameterList);
                Delegation = ds.Tables[0].ToObject<Delegation>();
              

                return Delegation;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public Delegation GetByFilters(Delegation model)
        {
            try
            {
                Delegation Delegation = new Delegation();
                OracleParameter[] parameterList = new OracleParameter[]
                {
     
                  
                      new OracleParameter(P_OUTPUT, OracleDbType.RefCursor,ParameterDirection.Output),
                     new OracleParameter(P_OUTSTATUSMESSAGE, OracleDbType.RefCursor,ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "s", parameterList);
                Delegation = ds.Tables[0].ToObject<Delegation>();


                return Delegation;
            }
            catch (Exception)
            {
                throw;
            }
        }


        public Response Save(Delegation model)
        {
            try
            {
                Delegation Delegation = new Delegation();
                OracleParameter[] parameterList = new OracleParameter[]
                {
                     new OracleParameter(P_ID, model.Id),
             
                     new OracleParameter(P_ROLEID, model.RoleId),
                     new OracleParameter(P_FROMDATE, model.FromDate),

                     new OracleParameter(P_TODATE, model.ToDate),

                     new OracleParameter(P_ACTUAL_USER, model.ActualUser),
                     new OracleParameter(P_BACKUP_USER, model.BackupUser),

                       new OracleParameter(P_IS_DELETED, model.IsDeleted),

                        new OracleParameter(P_CREATEDBY,  Global.User.MuNumber),
                     new OracleParameter(P_OUTSTATUSMESSAGE, OracleDbType.RefCursor,ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, SP_INS_UPD_DELEGATION, parameterList);

                Response res = ds.Tables[0].ToObject<Response>();
                return res;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<UserDetail> SearchUser(string keyword)
        {
            try
            {
                List<UserDetail> UserDetailList = new List<UserDetail>();
                OracleParameter[] parameterList = new OracleParameter[]
                {
                    new OracleParameter(P_KEYWORD, keyword),
                    new OracleParameter(P_OUTSTATUSMESSAGE, OracleDbType.RefCursor,ParameterDirection.Output),
                };

                DataSet ds = OracleHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "SP_SEARCH_USERS", parameterList);
                UserDetailList = ds.Tables[0].ToList<UserDetail>();

                return UserDetailList;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
