﻿using eMOC_PV_DataAccess.Interface;
using eMOC_PV_DataAccess.Repository;
using Microsoft.Extensions.DependencyInjection;

namespace eMOC_PV_DataAccess
{
    public static class RepositoryDependency
    {
        public static void AddRepositoryDI(IServiceCollection service)
        {
            service.AddTransient<ICommonRepository, CommonRepository>();

            service.AddTransient<IMasterRepository, MasterRepository>();
            service.AddTransient<IUserManagementRepository, UserManagementRepository>();
            service.AddTransient<IRequestRepository, RequestRepository>();
            service.AddTransient<IDelegationRepository, DelegationRepository>();
        }
    }
}
