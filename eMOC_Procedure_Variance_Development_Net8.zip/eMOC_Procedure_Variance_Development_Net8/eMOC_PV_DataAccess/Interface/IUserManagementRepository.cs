﻿using eMOC_PV_Models;

namespace eMOC_PV_DataAccess.Interface
{
    public interface IUserManagementRepository
    {

        UserManagement GetByFilters(UserManagement model);

        List<UserManagement> GetAll();

        UserManagement GetById(int UserManagementId);

        Response Save(UserManagement model);

        List<UserDetail> SearchUser(string keyword);

        List<Assets> GetAssest(string DirectorateName);

        List<Directorates> GetDirectorate();
    }
}
