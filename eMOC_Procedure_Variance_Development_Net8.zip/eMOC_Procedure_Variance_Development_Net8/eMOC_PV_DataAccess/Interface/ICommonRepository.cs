﻿using eMOC_PV_Models;

namespace eMOC_PV_DataAccess.Interface
{
    public interface ICommonRepository
    {
        #region User Detail
        UserDetail GetUserDetail();
        #endregion

        #region Is Authorized
        bool IsAuthorized(string ScreenCode);
        #endregion

        #region Log Error
        void SaveErrorLog(ErrorLog model, string createdBy = null);
        #endregion

        #region API Log
        void SaveApiLog(ApiLog model);
        #endregion

        #region Search User (Autocomplete)
        List<UserDetail> SearchUser(string Keyword);
        #endregion

        #region User Menu
        UserMenu GetUserMenu();
        #endregion

        #region Help Document
        HelpDocument SaveHelpDocumemt(HelpDocument model);
        List<HelpDocument> GetHelpDocument(decimal Id = 0, int IsActive = 2);
        #endregion

        #region Contact Us Information
        public dynamic GetContactUs();
        #endregion

        #region  Search CMS Procedure (Autocomplete)
        List<CMSProcedure> SearchCMSProcedure(string Keyword);
        #endregion

        #region Get UserList By RefrenceIndicator
        List<UserDetail> GetUserListByRefrenceIndicator(string Keyword);
        #endregion
    }
}
