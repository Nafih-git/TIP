﻿using eMOC_PV_Models;

namespace eMOC_PV_DataAccess.Interface
{
    public interface IMasterRepository
    {
        #region Master Items
        List<GenericData> GetMasterItems();
        #endregion

        #region Roles
        List<Roles> GetRole(int Id = 0, int IsActive = 2);
        Response SaveRole(Roles model);


        List<Roles> GetKPISLA();
        
        #endregion

        #region Module
        List<Module> GetModule(int Id = 0, int IsActive = 2);
        Response SaveModule(Module model);
        #endregion

        #region Screen
        List<Screen> GetScreen(int Id = 0, int IsActive = 2);
        Response SaveScreen(Screen model);
        #endregion

        #region RA Control Type
        List<RAControlType> GetRAControlType(int Id = 0, int IsActive = 2);
        Response SaveRAControlType(RAControlType model);
        #endregion

        #region RA Control Owner Role
        List<RAControlOwnerRole> GetRAControlOwnerRole(int Id = 0, int IsActive = 2, string Name = "", int RetType = 0);
        
        Response SaveRAControlOwnerRole(RAControlOwnerRole model);
        #endregion

        #region Frequency
        List<FrequencyList> GetFrequency();
        #endregion

        #region RA Hazard
        List<RAHazard> GetRAHazard(int Id = 0, int IsActive = 2, string Name = "", int RetType = 0);
        Response SaveRAHazard(RAHazard model);
        #endregion

        #region RA Effect of Hazard
        List<RAHazardEffects> GetRAHazardEffect(int Id = 0, int HazardId = 0, int IsActive = 2, string Name = "", int RetType = 0);
        Response SaveRAHazardEffect(RAHazardEffects model);
        #endregion

        #region RA Control Measure
        List<RAControlMeasure> GetRAControlMeasure(int Id = 0, int HazardId = 0, int IsActive = 2, string Name = "", int RetType = 0);
        Response SaveRAControlMeasure(RAControlMeasure model);
        #endregion

        #region Directorates
        List<Directorates> GetDirectorates();
        #endregion

        #region Asset
        List<Assets> GetAssets(string Directorate = null);
        #endregion

        #region Facility
        List<Facilities> GetFacilities(string Asset = null, string Directorate = null);
        #endregion



        #region Reason For Variance
        List<ReasonVariance> GetReasonVariance(int Id = 0, int IsActive = 2);
        Response SaveReasonVariance(ReasonVariance model);
        #endregion

        

        

        #region Approvers List
        List<UserDetail> GetApprovers(int RoleId, string Directorate, string Asset);
        #endregion

        #region Workflow Status
        List<Status> GetWorkflowStatus();
        #endregion


        #region Email Template
        List<EmailTemplate> GetEmailTemplates(int Id = 0);
        Response SaveEmailTemplate(EmailTemplate model);
        #endregion
    }
}
