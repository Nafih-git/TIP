﻿using eMOC_PV_Models;

namespace eMOC_PV_DataAccess.Interface
{
    public interface IRequestRepository
    {
        #region Workflow Progress Bar (Steps)
        List<Steps> GetWorkflowSteps(int RequestId = 0, int WorkflowTypeId = 1);
        #endregion

        #region Workflow Actions
        List<Actions> GetWorkflowActions(int RequestId = 0, int WorkflowTypeId = 1);
        #endregion

        #region Request Document
        List<RequestDocument> GetRequestDocument(int Id, int RequestId);
        RequestDocument SaveRequestDocument(RequestDocument model);
        #endregion

        #region Request
        Response SaveRequest(Request model);
        Request GetRequest(int RequestId);
        Request GetRequestHistory(decimal Id);
        List<ApproverHistory> GetApproverHistory(int RequestId);
        Response UpdateHistory(decimal RequestId, string history);
        List<AllRequest> GetAllRequests(AllRequestFilter model);
        List<AllRequest> GetPendingWithRequests(AllRequestFilter model);
        List<Tasks> GetTaskHistory(decimal Id);

        List<Tasks> GetTaskHistoryByRequestId(decimal Id);
        

        List<Email> GetOutboxMails(decimal RequestId = 0);
        bool UpdateEmailSentStatus(decimal Id);
        List<RequestExtension> GetExtensionHistory(decimal Id);
        #endregion

        #region Expired & Overdue Requests
        public List<Request> GetExpiredOverdueRequests();
        #endregion

        #region Copy Risk Assessment
        List<GenericData> GetRequestId(decimal Id);
        RiskAssessment GetRiskAssessment(decimal RequestId);
        #endregion

      

        #region Dashboard Charts
        dynamic GetDashboardCharts(string FilterString);
        dynamic GetControlCenterStatus();
        dynamic GetTotalExpiredKPI(string FilterString);
        dynamic GetPieChartParams();
        dynamic GetQuarterBasedOnyear(string year);
        dynamic GetPieChartDetailsByStatus(string FilterString);
        #endregion

        #region Approvers
        RAApprovers GetRAApprovers(string DirectorateCode,string AssetCode, string RRName, string CRName);
        #endregion


        #region Draft Requests For Deletion
        List<Request> GetDraftRequestsForDeleting();

        #endregion
    }
}
