﻿using eMOC_PV_Common;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;

namespace eMOC_PV_DataAccess
{
    public class DataBaseHelper
    {

        #region Constructor & Properties
        public DataBaseHelper(IConfiguration config)
        {
            this.config = config;
        }
        private readonly IConfiguration config;
        public string ConnectionString
        {
            get
            {
                try
                {
                    OracleConnectionStringBuilder builder = new();
                    builder.DataSource = config.GetSection("ConnectionString:DS").Value.Decrypt();
                    builder.UserID = config.GetSection("ConnectionString:UID").Value.Decrypt();
                    builder.Password = config.GetSection("ConnectionString:PD").Value.Decrypt();
                    return builder.ConnectionString.ToString();
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }
        #endregion
    }
}
