export const environment = {
  production: true,
  apiUrl: "https://prd890.corp.pdo.om/eMOCPVApi/api/",
};
