export enum ReportTypeEnum {

  ExpiryReport = "expiry-report",
  OverdueReport = "overdue-report",
  ImplementedReport = "implemented-report",
  RejectedReport = "rejected-report",
}