export enum TOCEnum {
  LCR = 1,
  IOC = 2,
  ICCR = 3
}


