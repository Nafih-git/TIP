export enum RequestStepEnum {
  
  R = "R",
  NR = "NR",
  LM = "LM",
  RA = "RA",
  EN = "EN",
  EXT = "EXT",
  EXP = "EXP",
  DEL = "DEL",
}