export enum TempPositionEnum {

  Other = 1000
}