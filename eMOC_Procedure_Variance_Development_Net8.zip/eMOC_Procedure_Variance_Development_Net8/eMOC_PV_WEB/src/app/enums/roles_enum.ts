export enum ReportTypeEnum {

  FunctionalReviewer=3,
  TechnicalApprover = 4,
  DeliveryTeamLead = 6,
  OperationManager = 7,
  Director = 8,
  TechnicalDirector = 9,
  Authorizer=10,
  Endorser = 11,
}
