export enum WorkStatusEnum {
  Drafted = 1,
  Pending_with_Functional_Reviwer,
  Pending_With_RA_Approver,
  Pending_With_Technical_Approveer,
  Pending_With_Endorser,
  Pending_With_Authorizer,
  Pending_with_Implmentor,
  Implemented,
  Closed,
  Expired,
  Rejected,
  Deleted,
  Overdue,
  Pending_for_Rework
}
