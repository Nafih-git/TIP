import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SidenavComponent } from './template/sidenav/sidenav.component';
import { TopnavComponent } from './template/topnav/topnav.component';
import { FooterComponent } from './template/footer/footer.component';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { DialogModule } from 'primeng/dialog';
import { MultiSelectModule } from 'primeng/multiselect';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { WinAuthInterceptor } from './utility/intercepter/winAuth.Interceptor';
import { ErrorService } from './utility/service/error.service';
import { ButtonModule } from 'primeng/button';
import { AuthGuardService } from './utility/service/auth-guard.service';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { IndexComponent } from './home/index/index.component';
import { DelegationComponent } from './delegation/delegation.component';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { TrueFalseValueModule } from './utility/directive/true-false-value/true-false-value.module';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { TooltipModule } from 'primeng/tooltip';
import { CalendarModule } from 'primeng/calendar';
import { DatePipe } from '@angular/common';
import { LoadingSpinnerModule } from './utility/directive/loading-spinner/loading-spinner.module';



@NgModule({
  declarations: [
    AppComponent,
    SidenavComponent,
    TopnavComponent,
    FooterComponent,
    UnauthorizedComponent,
    IndexComponent,
    DelegationComponent,




  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    DialogModule,
    FormsModule,
    AppRoutingModule,
    ToastModule,
    ConfirmDialogModule,
    ButtonModule,
    TableModule,
    DialogModule,
    FormsModule,
    TrueFalseValueModule,
    AutoCompleteModule,
    DropdownModule,
    TooltipModule,
    CalendarModule,
    LoadingSpinnerModule


  ],
  providers: [DatePipe,AuthGuardService,MessageService, ConfirmationService, {
    provide: HTTP_INTERCEPTORS,
    useClass: WinAuthInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
