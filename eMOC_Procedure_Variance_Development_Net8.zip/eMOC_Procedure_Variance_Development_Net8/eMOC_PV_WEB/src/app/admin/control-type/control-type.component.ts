import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { RaControlTypeModel } from '../../models/ra-control-type_model';
import { CommonFunctions } from '../../utility/common/common-functions';
import { HttpService } from '../../utility/http.service';

@Component({
  selector: 'app-control-type',
  templateUrl: './control-type.component.html',
  styleUrls: ['./control-type.component.css']
})
export class ControlTypeComponent implements OnInit {

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  cols: any[] = [
    { field: 'Name', header: 'Control Type', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Active', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'CreatedDate', header: 'Created date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedDate', header: 'Modified date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
  ];

  statuses: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  raControlTypeList: RaControlTypeModel[] = new Array<RaControlTypeModel>();
  raControlType: RaControlTypeModel = new RaControlTypeModel();
  selectedRow: RaControlTypeModel = new RaControlTypeModel();
  loading: boolean = false;
  isSaveClicked: boolean = false;
  displayModal: boolean = false;
  @ViewChild("formRaControlType") formRaControlType!: NgForm;
  @ViewChild("dataTable") table!: any;

  ngOnInit(): void {

    this.GetAllRaControlType();
  }

  GetAllRaControlType() {

    this.loading = true;

    this._HttpService.GetAll("Master/GetAllRaControlType").subscribe(res => {

      this.raControlTypeList = res;

      this.raControlTypeList.forEach(s => {

        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });

      this.loading = false;
    });
  }

  Save() {

    this.isSaveClicked = true;

    if (this.formRaControlType.valid)
      this._HttpService.Post("Master/SaveRaControlType", this.raControlType).subscribe(res => {

        this.GetAllRaControlType();
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;

        this.raControlType = new RaControlTypeModel();
      });
  }

  editTable(row: RaControlTypeModel) {

    this.raControlType = Object.assign({}, row);
    this.displayModal = true;
  }

  Close() {

    this.formRaControlType.reset();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  exportExcel() {

    CommonFunctions.ExportExcel(this.cols, this.raControlTypeList, 'Control Type List');
  }

  exportPdf() {

    CommonFunctions.ExportPdf(this.cols, this.raControlTypeList, 'Control Type List');
  }

  exportCSV() {

    this.table.exportCSV();
  }
}
