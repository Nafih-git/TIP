import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlOwnerComponent } from './control-owner.component';

describe('ControlOwnerComponent', () => {
  let component: ControlOwnerComponent;
  let fixture: ComponentFixture<ControlOwnerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ControlOwnerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlOwnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
