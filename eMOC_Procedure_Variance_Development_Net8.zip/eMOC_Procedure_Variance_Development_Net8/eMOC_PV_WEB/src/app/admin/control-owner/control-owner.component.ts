import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { RaControlOwnerModel } from '../../models/ra-control-owner_model';
import { CommonFunctions } from '../../utility/common/common-functions';
import { HttpService } from '../../utility/http.service';

@Component({
  selector: 'app-control-owner',
  templateUrl: './control-owner.component.html',
  styleUrls: ['./control-owner.component.css']
})
export class ControlOwnerComponent implements OnInit {

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  cols: any[] = [
    { field: 'Name', header: 'Control Owner', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Active', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'CreatedDate', header: 'Created date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedDate', header: 'Modified date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
  ];

  statuses: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  raControlOwnerList: RaControlOwnerModel[] = new Array<RaControlOwnerModel>();
  raControlOwner: RaControlOwnerModel = new RaControlOwnerModel();
  selectedRow: RaControlOwnerModel = new RaControlOwnerModel();
  loading: boolean = false;
  isSaveClicked: boolean = false;
  displayModal: boolean = false;
  @ViewChild("formRaControlOwner") formRaControlOwner!: NgForm;
  @ViewChild("dataTable") table!: any;

  ngOnInit(): void {

    this.GetAllRaControlOwner();
  }

  GetAllRaControlOwner() {

    this.loading = true;

    this._HttpService.GetAll("Master/GetAllRAControlOwnerRole").subscribe(res => {

      this.raControlOwnerList = res;

      this.raControlOwnerList.forEach(s => {

        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });

      this.loading = false;
    });
  }

  Save() {

    this.isSaveClicked = true;

    if (this.formRaControlOwner.valid)
      this._HttpService.Post("Master/SaveRAControlOwnerRole", this.raControlOwner).subscribe(res => {

        this.GetAllRaControlOwner();
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;

        this.raControlOwner = new RaControlOwnerModel();
      });
  }

  editTable(row: RaControlOwnerModel) {

    this.raControlOwner = Object.assign({}, row);
    this.displayModal = true;
  }

  Close() {

    this.formRaControlOwner.reset();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  exportExcel() {

    CommonFunctions.ExportExcel(this.cols, this.raControlOwnerList, 'Control Owner List');
  }

  exportPdf() {

    CommonFunctions.ExportPdf(this.cols, this.raControlOwnerList, 'Control Owner List');
  }

  exportCSV() {

    this.table.exportCSV();
  }
}
