import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { ReasonVarianceModel } from 'src/app/models/reason_varience';
import { CommonFunctions } from 'src/app/utility/common/common-functions';
import { HttpService } from 'src/app/utility/http.service';

@Component({
  selector: 'app-reasonvariance',
  templateUrl: './reasonvariance.component.html',
  styleUrls: ['./reasonvariance.component.css']
})
export class ReasonVarianceComponent implements OnInit {

  constructor(private Http: HttpService, private msg: MessageService) { }
  loading: boolean = false;
  displayModal: boolean = false;
  isSaveClicked: boolean = false;
  selectedEmocType: number | undefined;
  ReasonVarianceList: ReasonVarianceModel[] = new Array<ReasonVarianceModel>();
  ReasonVariance: ReasonVarianceModel = new ReasonVarianceModel();
  selectedRow: ReasonVarianceModel = new ReasonVarianceModel();
  @ViewChild("formReasonVariance") formReasonVariance!: NgForm;
  @ViewChild("dataTable") table!: any;

  cols: any[] = [
      { field: 'Name', header: 'Reason Variance Name', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Active', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'OrderNo', header: 'Order No', width: '130px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedDate', header: 'Created date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedDate', header: 'Modified date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
  ];

  statuses: any[] = [
    { label: 'No', value: 0 },
    { label: 'Yes', value: 1 },
  ];

  ngOnInit(): void {

    this.GetAllReasonVariance();
  }

  GetAllReasonVariance() {
    this.loading = true;
    this.Http.GetAll("Master/GetAllReasonVariance").subscribe(res => {
      this.ReasonVarianceList = res;
      this.ReasonVarianceList.forEach(s => {
        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });
      this.loading = false;
    });
  }



  editTable(row: ReasonVarianceModel) {
    this.ReasonVariance = Object.assign({}, row);
    this.displayModal = true;
  }

  Close() {
    this.formReasonVariance.reset();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  Save() {
    this.isSaveClicked = true;
    if (this.formReasonVariance.valid)
      this.Http.Post("Master/SaveReasonVariance", this.ReasonVariance).subscribe(res => {
        this.GetAllReasonVariance();
        this.msg.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;
        this.ReasonVariance = new ReasonVarianceModel();
      });
  }

  exportExcel() {
    CommonFunctions.ExportExcel(this.cols, this.ReasonVarianceList, 'ReasonVariance List');
  }

  exportPdf() {
    CommonFunctions.ExportPdf(this.cols, this.ReasonVarianceList, 'ReasonVariance List');
  }

  exportCSV() {
    this.table.exportCSV();
  }
}
