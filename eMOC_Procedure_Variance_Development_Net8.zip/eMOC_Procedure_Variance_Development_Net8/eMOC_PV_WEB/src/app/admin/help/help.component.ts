import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { HelpDocumentsModel } from 'src/app/models/help-document_model';
import { CommonFunctions } from 'src/app/utility/common/common-functions';
import { HttpService } from 'src/app/utility/http.service';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.css']
})
export class HelpComponent implements OnInit {

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  @ViewChild("formModule") formModule!: NgForm;
  @ViewChild("dataTable") table!: any;
  isSaving: boolean = false;
  isDownload: boolean = false;
  displayModal: boolean = false;
  loading: boolean = false;
  helpDocumentList: HelpDocumentsModel[] = new Array<HelpDocumentsModel>();
  selectedRow: HelpDocumentsModel = new HelpDocumentsModel();
  helpDocument: HelpDocumentsModel = new HelpDocumentsModel();
  isSaveClicked: boolean = false;

  errorMessage: string = 'Please Fill All Required Fields';

  isActive: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  cols: any[] = [
    { field: 'DisplayName', header: 'Display Name', width: '250px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'FileName', header: 'File Name', width: '250px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'OrderNo', header: 'Order No.', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Active', width: '100px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created By', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedDate', header: 'Created Date', width: '150px', isBadge: false, isDate: true, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedByName', header: 'Modified By', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedDate', header: 'Modified Date', width: '150px', isBadge: false, isDate: true, isSorting: true, isFilter: true, isExportable: true },
  ];

  @ViewChild('fileUpload') fileUpload: any;

  acceptedFiles: string[] = [".pdf", ".doc", ".docx"];
  acceptedFileTypeHint = '';

  ngOnInit(): void {

    this.GetAllowedDocsExtension();
    this.GetAllHelpInfo();
  }

  GetAllHelpInfo() {

    this.helpDocumentList = new Array<HelpDocumentsModel>();

    this._HttpService.GetAll("Common/GetAllHelpDocuments").subscribe(res => {

      this.helpDocumentList = res;

      this.helpDocumentList.forEach(s => {
        if (s.CreatedDate) s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate) s.ModifiedDate = new Date(s.ModifiedDate);
      });

    });
  }

  exportExcel() {

    CommonFunctions.ExportExcel(this.cols, this.helpDocumentList, 'Help Information');
  }

  exportPdf() {

    CommonFunctions.ExportPdf(this.cols, this.helpDocumentList, 'Help Information');
  }

  exportCSV() {

    this.table.exportCSV();
  }

  CustomFilterCallback(filter: (a: any) => void, value: any): void {

    filter(value);
  }

  EditTable(row: HelpDocumentsModel) {

    this.helpDocument = JSON.parse(JSON.stringify(row));
    this.displayModal = true;

    this._HttpService.Get("Common/GetHelpDocumentById", [ this.helpDocument.Id.toString() ]).subscribe(res => {
      this.helpDocument = res;
    });
  }

  DownloadFile(row: HelpDocumentsModel) {
    this.isSaving = true;
    this._HttpService.Get1("Common/DownloadHelpFile", { FileName: row.Guid }).subscribe(res => {
      CommonFunctions.downloadFile("data:" + res.ContentType + ";base64," + res.FileContents, row.MimeType, row.FileName, null);
      this.isSaving = false;
    });
  }

  Close() {

    this.formModule.reset();
    this.displayModal = false;
    this.isSaveClicked = false;
    this.helpDocument = new HelpDocumentsModel();
  }

  Save() {

    this.isSaveClicked = true;

    if (this.formModule.valid) {

      this.isSaving = true;
      var formData = CommonFunctions.convertModelToFormData(this.helpDocument);

      this._HttpService.Post("Common/SaveHelpDocument", formData).subscribe(res => {

        this.GetAllHelpInfo();
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), summary: res.Summary, detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;
        this.isSaving = false;

        this.helpDocument = new HelpDocumentsModel();
      });
    }
  }

  OnSelectEvent(event: any) {

    let regExpr = /(?:\.([^.]+))?$/;

    let ext = regExpr.exec(event.target.files[0].name)![0].toLowerCase().trim();

    let allowFile: boolean = false;

    this.acceptedFiles.forEach(acceptedFile => {

      if(ext == acceptedFile.trim()) {

        allowFile = true;
      }
    });

    if(allowFile) {

      this.helpDocument.File = event.target.files[0];
      this.helpDocument.FileName = event.target.files[0].name;
      this.helpDocument.MimeType = event.target.files[0].type;

      if(this.helpDocument.Id > 0) {

        this.helpDocument.Guid = '';
      }
    }
    else {

      this.helpDocument.File = '';
      this.helpDocument.FileName = '';
      this.helpDocument.MimeType = '';
      this.helpDocument.Guid = '';
    }
  }

  GetAllowedDocsExtension() {

    this._HttpService.GetAll("Common/GetAllowedHelpFileExtensions").subscribe(res => {

      if(res) {

        this.acceptedFileTypeHint = res.AllowedExtension;
        this.acceptedFiles = res.AllowedExtension.split(',');
      }
    });
  }
}
