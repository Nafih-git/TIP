import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { EmocTypeModel } from 'src/app/models/emoc-type_model';
import { CommonFunctions } from 'src/app/utility/common/common-functions';
import { HttpService } from 'src/app/utility/http.service';

@Component({
  selector: 'app-emoc-type',
  templateUrl: './emoc-type.component.html',
  styleUrls: ['./emoc-type.component.css']
})
export class EmocTypeComponent implements OnInit {

  constructor(private Http: HttpService, private msg: MessageService) { }
  loading: boolean = false;
  displayModal: boolean = false;
  isSaveClicked: boolean = false;
  emocTypeList: EmocTypeModel[] = new Array<EmocTypeModel>();
  emocType: EmocTypeModel = new EmocTypeModel();
  selectedRow: EmocTypeModel = new EmocTypeModel();
  @ViewChild("formEmocType") formEmocType!: NgForm;
  @ViewChild("dataTable") table!: any;
  cols: any[] = [
    { field: 'Id', header: 'Id', width: '50px', isBadge: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'Name', header: 'Type Name', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Active', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'OrderNo', header: 'Order No', width: '130px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedDate', header: 'Created date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedDate', header: 'Modified date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
  ];
  statuses: any[] = [
    { label: 'No', value: 0 },
    { label: 'Yes', value: 1 },
  ];

  ngOnInit(): void {
    this.GetAllEmocTypes();
  }

  GetAllEmocTypes() {
    this.loading = true;
    this.Http.GetAll("Master/GetAllEmocTypes").subscribe(res => {
      this.emocTypeList = res;
      this.emocTypeList.forEach(s => {
        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });
      this.loading = false;
    });
  }

  editTable(row: EmocTypeModel) {
    this.emocType = Object.assign({}, row);
    this.displayModal = true;
  }

  Close() {
    this.formEmocType.reset();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  Save() {
    this.isSaveClicked = true;

    if (this.formEmocType.valid)
      this.Http.Post("Master/SaveEmocType", this.emocType).subscribe(res => {

        this.GetAllEmocTypes();
        this.msg.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;
        this.emocType = new EmocTypeModel();
      });
  }

  exportExcel() {
    CommonFunctions.ExportExcel(this.cols, this.emocTypeList, 'emoc Type List');
  }

  exportPdf() {
    CommonFunctions.ExportPdf(this.cols, this.emocTypeList, 'emoc Type List');
  }

  exportCSV() {
    this.table.exportCSV();
  }
}
