import { Component, OnInit,ChangeDetectorRef, AfterContentChecked } from '@angular/core';
import { MessageService, SelectItem } from 'primeng/api';
import { CommonFunctions } from '../../utility/common/common-functions';
import { HttpService } from '../../utility/http.service';
import { UserManagement } from '../../models/usermanagement_model';
import { RolesModel } from '../../models/roles_model';
import { AssetModel } from '../../models/asset_model';
import { LoggedUserService } from '../../utility/service/logged-user.service';
import { UserManagementDetail } from '../../models/UserManagementDetailModel';
import { MessageStatusEnum } from '../../enums/message-status_enum';
import { DirectorateModel } from 'src/app/models/directorate_model';

interface messageStatus {
  success: 1,
  Error: 2
}
@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {

  displayModal: boolean = false;
  selectedUser: UserManagementDetail = new UserManagementDetail();
  UsersList: any;
  selectedRow: any;

  constructor(private _loggedUserService: LoggedUserService, private _HttpService: HttpService, private messageService: MessageService, private changeDetector: ChangeDetectorRef) {

  }


  cols: any[] = [
    { field: 'SNO', header: 'SNo.', width: '50px', isBadge: false, isDate: false, isSorting: false, isFilter: false, isExportable: false },
    { field: 'RoleName', header: 'Display Name', width: '180px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'Approvers', header: 'Approvers', width: '250px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'DirectorateName', header: 'Directorate Name', width: '180px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'AssetName', header: 'Asset Name', width: '180px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created By', width: '180px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedDate', header: 'Created Date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedByName', header: 'Modified By', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedDate', header: 'Modified Date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
  ]

  RoleList: RolesModel[] = new Array<RolesModel>();

  AssetList: AssetModel[] = new Array<AssetModel>();

  DirectorateList: DirectorateModel[] = new Array<DirectorateModel>();
  SelectedRole: RolesModel = new RolesModel();
  UserManagementList: UserManagement[] = new Array<UserManagement>();
  DownloadUserManagementList: UserManagement[] = new Array<UserManagement>();
  loading: boolean = true;

  DataLoading : boolean = false;
  Model: UserManagement = new UserManagement();
  editMode: boolean = false;

  userSearchSubscribe: any;
  assetCode !: string;
  ngOnInit(): void {
    this.GetAllUserManagement();
    this.GetAllRolesForUserManagement();
      //this.GetAsset();
    this.GetDirectorate();
    this.SelectedRole = new RolesModel();
  }
  ngAfterContentChecked(): void {
    this.changeDetector.detectChanges();
  }


  GetAllUserManagement() {
    this.loading = true;
    this._HttpService.GetAll("UserManagement/GetAll").subscribe(res => {

      if (res != null) {
        this.UserManagementList = res;
        this.UserManagementList.forEach(s => {

          if (s.CreatedDate) s.CreatedDate = new Date(s.CreatedDate);
          if (s.ModifiedDate) s.ModifiedDate = new Date(s.ModifiedDate);
        });
      }
      this.loading = false;
    });
  }

  showBasicDialog() {
    this.editMode = false;
    this.displayModal = true;
    this.Model = new UserManagement();
    this.SelectedRole = new RolesModel();
  }
  Save() {

    let errorcount = 0;

    if (this.Model.RId == null || this.Model.RId == 0) {
      errorcount++;
      this.messageService.add({ severity: 'error', detail: 'Select Role' });
    }
    else if (this.SelectedRole.IsDirectorate && (this.Model.DirectorateCode == null || this.Model.DirectorateCode == "")) {
      errorcount++;
      this.messageService.add({ severity: 'error', detail: 'Select Directorate' });
    }

    else if (this.SelectedRole.IsAsset) {
      if (this.Model.DirectorateCode == null || this.Model.DirectorateCode == "") {
        errorcount++;
        this.messageService.add({ severity: 'error', detail: 'Select Directorate' });

      }
      if (this.Model.AssetCode == null || this.Model.AssetCode == "") {
        errorcount++;
        this.messageService.add({ severity: 'error', detail: 'Select Asset' });

      }
    }


    if (errorcount == 0) {


      this._HttpService.Post("UserManagement/Save", this.Model).subscribe(res => {
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        if (this.Model.Id == 0) {

          this.Model.Id = res.Id;
        }
        this.FilterData();
        this.GetAllUserManagement();
      })


    }
  }

  GetAllRolesForUserManagement() {

    this._HttpService.Get("Master/GetAllRolesForUserManagement", []).subscribe(res => { this.RoleList = res; this.loading = false; })
  }



  GetAsset(AssetCode : string = "") {

    this.DataLoading = true;
    this.AssetList = [];

    // this.loading = true;
    this._HttpService.Get("UserManagement/GetAssest", [this.Model.DirectorateCode]).subscribe(res => { this.AssetList = res;

      this.Model.AssetCode = AssetCode;
      this.DataLoading = false;


    })
  }


  GetDirectorate() {

    this._HttpService.GetAll("UserManagement/GetDirectorate").subscribe(res => { this.DirectorateList = res; this.loading = false; })
  }

  GetSelectedRole() {
    this.SelectedRole = this.RoleList.filter(x => x.Id === this.Model.RId)[0];
  }

  RoleChanged(filterdata: boolean = true) {
    if (this.Model.RId != null) {
      this.GetSelectedRole();
      if (filterdata) {
        this.FilterData();
      }
    }
    else {
      this.Model.UserManagementDetailList = [];
      this.SelectedRole = new RolesModel();
    }


  }

  AssetChange() {

    if(!this.editMode){

      this.FilterData();
    }

  }

  DirectorateChange() {
    this.GetAsset();
    if(!this.editMode){

      this.FilterData();
    }

  }

  FilterData() {
this.DataLoading = true;
    // this.loading = true;
    this._HttpService.Post("UserManagement/GetByFilters", this.Model).subscribe(res => {

      if (res != null) {
        this.Model = res;
      }
      else {
        this.Model.UserManagementDetailList = [];
        this.Model.Id = 0;
      }
      this.DataLoading = false;
      // this.loading = false;
    })

  }


  async EditUserManagement(userManagement: UserManagement) {

    this.editMode = true;
    // this.Model = JSON.parse(JSON.stringify(userManagement));
    this._HttpService.Get("UserManagement/GetById", [userManagement.Id.toString()]).subscribe(res => {
      this.Model =new UserManagement();
      this.Model =res;
      console.log(this.Model.AssetCode);



      this.GetSelectedRole();
      if (this.Model.DirectorateCode) {

        this.GetAsset(this.Model.AssetCode);
      }


      // this.Model.AssetCode = assetCode;

      // if (this.Model.AssetCode) {
      //   this.AssetChange()
      // }


       this.displayModal = true;
      // console.log(this.Model.AssetCode);
    })

  }
  AutoComplateUser(event: any) {

    if (this.userSearchSubscribe) {

      this.userSearchSubscribe.unsubscribe();
    }

    this.userSearchSubscribe = this._HttpService.Get("UserManagement/SearchUser", [event.query]).subscribe(res => {

      this.UsersList = res;
      this.loading = false;
    });
  }

  SelectedUser() {
    let filtereduser = null;
    if (this.Model.UserManagementDetailList == null) {
      this.Model.UserManagementDetailList = [];
    }
    else {
      filtereduser = this.Model.UserManagementDetailList.filter(d => d.PersonalNumber === this.selectedUser.PersonalNumber && !d.IsDeleted)[0];

    }


    if (filtereduser == null) {
      this.selectedUser.isAddedFromClent = true;
      this.Model.UserManagementDetailList.push(this.selectedUser);


    }
    else {
      this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "User already exist in the list" });


    }

    this.selectedUser = new UserManagementDetail();
  }

  exportPdf() {
    this.DownloadUserManagementList = JSON.parse(JSON.stringify(this.UserManagementList));

    this.DownloadUserManagementList.forEach(s => {
      s.Approvers = s.Approvers.replace(/<br>/g, "\n");
    });
    CommonFunctions.ExportPdf(this.cols, this.DownloadUserManagementList, 'User Management')
  }
  exportExcel() {

    this.DownloadUserManagementList = JSON.parse(JSON.stringify(this.UserManagementList));

    this.DownloadUserManagementList.forEach(s => {
      s.Approvers = s.Approvers.replace(/<br>/g, "\n");

    });
    CommonFunctions.ExportExcel(this.cols, this.DownloadUserManagementList, 'User Management');

  }
  covert(approver: string[]) {

    return approver.join("</br>");
  }

  RemoveUser(index: any) {

    this.Model.UserManagementDetailList[index].IsDeleted = 1;
  }
  CheckIsLoggedUser(row: any) {
    if (row.isAddedFromClent)
      return true;
    else
      return row.PersonalNumber != this._loggedUserService.loggedUser.PersonalNumber;
  }
}
