import { Input, ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { EmailTemplateModel } from '../../models/email-template_model';
import { CommonFunctions } from '../../utility/common/common-functions';
import { HttpService } from '../../utility/http.service';

@Component({
  selector: 'app-email-template',
  templateUrl: './email-template.component.html',
  styleUrls: ['./email-template.component.css']
})
export class EmailTemplateComponent implements OnInit {

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  displayModal = false;
  isSaveClicked = false;
  loading = false;
  text: string = "";
  emailList: EmailTemplateModel[] = new Array<EmailTemplateModel>();
  email: EmailTemplateModel = new EmailTemplateModel();
  selectedRow: EmailTemplateModel = new EmailTemplateModel();
  @ViewChild("Form") form!: NgForm;
  @ViewChild("dataTable") table!: any;
  public config: any = {
    airMode: false,
    tabDisable: true,
    popover: {
      table: [
        ['add', ['addRowDown', 'addRowUp', 'addColLeft', 'addColRight']],
        ['delete', ['deleteRow', 'deleteCol', 'deleteTable']]
      ],
      image: [
        ['image', ['resizeFull', 'resizeHalf', 'resizeQuarter', 'resizeNone']],
        ['float', ['floatLeft', 'floatRight', 'floatNone']],
        ['remove', ['removeMedia']]
      ],
      link: [['link', ['linkDialogShow', 'unlink']]],
      air: [['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']]]
    },
    height: '200px',
    uploadImagePath: '/api/upload',
    toolbar: [
      ['misc', ['undo', 'redo', 'codeBlock']],
      ['style', ['bold', 'italic', 'underline','clear']],
      ['fontsize', ['fontname', 'fontsize']],
      ['color', ['forecolor','backcolor']],
      ['para', ['ul', 'ol','paragraph','height']],
      ['insert', ['table', 'link', 'hr']],
      ['view', ['codeview', 'help']]
    ],
    fontSizes: ['8', '9', '10', '11', '12', '14', '18', '24', '36', '44', '56', '64', '76', '84', '96'],
    fontNames: ['Arial', 'Times New Roman', 'Inter', 'Comic Sans MS', 'Courier New', 'Roboto', 'Times', 'MangCau', 'BayBuomHep', 'BaiSau', 'BaiHoc', 'CoDien', 'BucThu', 'KeChuyen', 'MayChu', 'ThoiDai', 'ThuPhap-Ivy', 'ThuPhap-ThienAn'],
    codeviewFilter: true,
    codeviewFilterRegex: /<\/*(?:applet|b(?:ase|gsound|link)|embed|frame(?:set)?|ilayer|l(?:ayer|ink)|meta|object|s(?:cript|tyle)|t(?:itle|extarea)|xml|.*onmouseover)[^>]*?>/gi,
    codeviewIframeFilter: true
  };
  statuses: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ]
  cols: any[] = [
    { field: 'Id', header: 'SNo.', width: '50px', isBadge: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'Name', header: 'Name', width: '200px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'Subject', header: 'Subject', width: '400px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'EmailNotificationFor', header: 'Notification For', width: '400px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },

    // { field: 'WorkflowActionName', header: 'Action Name', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Is Active', width: '100px', isBadge: true, isDate: false, isSorting: true, isFilter: true },
    { field: 'CreatedByName', header: 'Created By', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'CreatedDate', header: 'Created Date', width: '150px', isBadge: false, isDate: true, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedByName', header: 'Modified By', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedDate', header: 'Modified Date', width: '150px', isBadge: false, isDate: true, isSorting: true, isFilter: true, isExportable: true },
  ]
  ngOnInit(): void {

    this.GetAllEmail();
  }

  GetAllEmail() {

    this.loading = true;

    this._HttpService.GetAll("Master/GetAllEmailTemplates").subscribe(res => {

      this.emailList = res;
      this.emailList.forEach(s => {

        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });

      this.loading = false;
    });
  }

  Save() {

    this.isSaveClicked = true;

    if (this.form.valid)
      this._HttpService.Post("Master/SaveEmailTemplate", this.email).subscribe(res => {
        this.GetAllEmail();
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;
        this.email = new EmailTemplateModel();
      });
  }

  edit(row: EmailTemplateModel) {
    this.email = Object.assign({}, row);
    this.displayModal = true;
  }

  Close() {

    this.form.reset();
    this.email = new EmailTemplateModel();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  exportExcel() {
    CommonFunctions.ExportExcel(this.cols, this.emailList, 'Email');
  }

  exportPdf() {
    CommonFunctions.ExportPdf(this.cols, this.emailList, 'Email')
  }

  exportCSV() {
    this.table.exportCSV();
  }
}
