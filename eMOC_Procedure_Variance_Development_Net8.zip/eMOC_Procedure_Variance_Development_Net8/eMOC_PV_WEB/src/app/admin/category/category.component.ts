import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { CategoryModel } from 'src/app/models/category_model';
import { EmocTypeModel } from 'src/app/models/emoc-type_model';
import { CommonFunctions } from 'src/app/utility/common/common-functions';
import { HttpService } from 'src/app/utility/http.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  constructor(private Http: HttpService, private msg: MessageService) { }
  loading: boolean = false;
  displayModal: boolean = false;
  isSaveClicked: boolean = false;
  emocTypeList: EmocTypeModel[] = new Array<EmocTypeModel>();
  selectedEmocType: number | undefined;
  categoryList: CategoryModel[] = new Array<CategoryModel>();
  category: CategoryModel = new CategoryModel();
  selectedRow: CategoryModel = new CategoryModel();
  @ViewChild("formCategory") formCategory!: NgForm;
  @ViewChild("dataTable") table!: any;

  cols: any[] = [
    { field: 'Id', header: 'Id', width: '50px', isBadge: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'Name', header: 'Category Name', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'EmocType', header: 'EMOC Type', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Active', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'OrderNo', header: 'Order No', width: '130px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedDate', header: 'Created date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedDate', header: 'Modified date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
  ];

  statuses: any[] = [
    { label: 'No', value: 0 },
    { label: 'Yes', value: 1 },
  ];

  ngOnInit(): void {
    this.GetEmocTypes();
    this.GetAllCategories();
  }

  GetAllCategories() {
    this.loading = true;
    this.Http.GetAll("Master/GetAllCategories").subscribe(res => {
      this.categoryList = res;
      this.categoryList.forEach(s => {
        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });
      this.loading = false;
    });
  }

  GetEmocTypes() {
    this.loading = true;
    this.Http.GetAll("Master/GetActiveEmocTypes").subscribe(res => {
      this.emocTypeList = res;
      this.loading = false;
    });
  }

  editTable(row: CategoryModel) {
    this.category = Object.assign({}, row);
    this.displayModal = true;
  }

  Close() {
    this.formCategory.reset();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  Save() {
    this.isSaveClicked = true;
    if (this.formCategory.valid)
      this.Http.Post("Master/SaveCategory", this.category).subscribe(res => {
        this.GetAllCategories();
        this.msg.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;
        this.category = new CategoryModel();
      });
  }

  exportExcel() {
    CommonFunctions.ExportExcel(this.cols, this.categoryList, 'Category List');
  }

  exportPdf() {
    CommonFunctions.ExportPdf(this.cols, this.categoryList, 'Category List');
  }

  exportCSV() {
    this.table.exportCSV();
  }
}
