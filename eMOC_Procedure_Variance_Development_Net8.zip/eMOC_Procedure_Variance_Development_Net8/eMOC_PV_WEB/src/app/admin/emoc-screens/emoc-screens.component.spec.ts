import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmocScreensComponent } from './emoc-screens.component';

describe('EmocScreensComponent', () => {
  let component: EmocScreensComponent;
  let fixture: ComponentFixture<EmocScreensComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmocScreensComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmocScreensComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
