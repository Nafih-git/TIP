import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService, SelectItem } from 'primeng/api';
import { ModuleModel } from '../../models/module_model';
import { ScreenModels } from '../../models/screen_models';
import { CommonFunctions } from '../../utility/common/common-functions';
import { HttpService } from '../../utility/http.service';

@Component({
  selector: 'app-emoc-screens',
  templateUrl: './emoc-screens.component.html',
  styleUrls: ['./emoc-screens.component.css']
})
export class EmocScreensComponent implements OnInit {

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  loading: boolean = false;
  displayModal: boolean = false;
  isSaveClicked: boolean = false;
  screenList: ScreenModels[] = new Array<ScreenModels>();
  screen: ScreenModels = new ScreenModels();
  @ViewChild("form")  form!: NgForm;
  @ViewChild("dataTable") table!: any;
  selectedScreen: any;

  moduleSelectList: SelectItem[] = new Array<SelectItem>();
  statuses: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  cols: any[] = [
    { field: 'Name', header: 'Name', width: '200px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'URL', header: 'URL', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'Icon', header: 'Icon', width: '80px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'OrderNo', header: 'Order No.', width: '80px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModuleName', header: 'Module Name', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedDate', header: 'Created Date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedDate', header: 'Modified Date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
  ];

  ngOnInit(): void {

    this.GetAllScreens();
    this.GetAllModules();
  }

  GetAllScreens() {

    this.loading = true;
    this._HttpService.GetAll("Master/GetAllScreens").subscribe(res => {

      this.screenList = res;

      this.screenList.forEach(s => {
        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });

      this.loading = false;
    });
  }

  GetAllModules() {

    this._HttpService.GetAll("Master/GetAllModules").subscribe((res: ModuleModel[]) => {

      res.forEach(s => this.moduleSelectList.push({ value: s.Id, label: s.Name }));
    });
  }

  Save() {

    this.isSaveClicked = true;

    if (this.form.valid) {
console.log(this.screen);
      this._HttpService.Post("Master/SaveScreen", this.screen).subscribe(res => {
        this.GetAllScreens()
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;

        this.screen = new ScreenModels();
      });
    }
  }

  Close() {

    this.form.reset();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  edit(row: ScreenModels) {

    this.screen = Object.assign({}, row);
    this.displayModal = true;
  }

  exportExcel() {

    CommonFunctions.ExportExcel(this.cols, this.screenList, 'screen');
  }

  exportPdf() {

    CommonFunctions.ExportPdf(this.cols, this.screenList, 'screen')
  }

  exportCSV() {

    this.table.exportCSV();
  }
}
