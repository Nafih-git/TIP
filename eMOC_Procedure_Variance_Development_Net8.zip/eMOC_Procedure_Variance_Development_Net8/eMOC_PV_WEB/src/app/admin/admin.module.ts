import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableModule } from 'primeng/table';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { CheckboxModule } from 'primeng/checkbox';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CommonModule } from '@angular/common';
import { UserManagementComponent } from './user-management/user-management.component';
import { AdminRoutingModule } from './admin-routing.module';
import { TooltipModule } from 'primeng/tooltip';
import { EMOCMasterComponent } from './e-moc-master/e-moc-master.component';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule } from '@angular/forms';
import { TrueFalseValueModule } from '../utility/directive/true-false-value/true-false-value.module';
import { EmailTemplateComponent } from './email-template/email-template.component';
import { EmocScreensComponent } from './emoc-screens/emoc-screens.component';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { EmocModulesComponent } from './emoc-modules/emoc-modules.component';
import { EmocRoleComponent } from './emoc-role/emoc-role.component';
import { NgxSummernoteModule } from 'ngx-summernote';
import { MultiSelectModule } from 'primeng/multiselect';
import { NumberOnlyModule } from '../utility/directive/numbersOnly/numbersOnly.module';
import { LoadingSpinnerModule } from '../utility/directive/loading-spinner/loading-spinner.module';
import { MessageModule } from 'primeng/message';
import { HelpComponent } from './help/help.component';
import { FileUploadModule } from 'primeng/fileupload';
import { HttpClientModule } from '@angular/common/http';
import { ControlTypeComponent } from './control-type/control-type.component';
import { ControlOwnerComponent } from './control-owner/control-owner.component';
import { RaDatabaseComponent } from './ra-database/ra-database.component';
import { RaHazardComponent } from './ra-hazard/ra-hazard.component';
import { RaEffectOfHazardComponent } from './ra-effect-of-hazard/ra-effect-of-hazard.component';
import { RaControlMeasureComponent } from './ra-control-measure/ra-control-measure.component';
import { PanelModule } from 'primeng/panel';
import { ReasonVarianceComponent } from './reasonvariance/reasonvariance.component';

@NgModule({
  declarations: [
    UserManagementComponent,
    EMOCMasterComponent,
    EmailTemplateComponent,
    EmocScreensComponent,
    EmocModulesComponent,
    EmocRoleComponent,
    HelpComponent,
    ControlTypeComponent,
    ControlOwnerComponent,
    RaDatabaseComponent,
    RaHazardComponent,
    RaEffectOfHazardComponent,
    RaControlMeasureComponent,
    ReasonVarianceComponent,

  ],
  imports: [
    AdminRoutingModule,
    CommonModule,
    TableModule,
    InputTextModule,
    ButtonModule,
    DialogModule,
    CheckboxModule,
    TooltipModule,
    DropdownModule,
    FormsModule,
    TrueFalseValueModule,
    InputTextareaModule,
    AutoCompleteModule,
    NgxSummernoteModule,
    NumberOnlyModule,
    LoadingSpinnerModule,
    MultiSelectModule,
    MessageModule,
    FileUploadModule,
    HttpClientModule,
    PanelModule
  ],
  providers: [],
  bootstrap: []
})
export class AdminModule { }
