import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RaEffectOfHazardComponent } from './ra-effect-of-hazard.component';

describe('RaEffectOfHazardComponent', () => {
  let component: RaEffectOfHazardComponent;
  let fixture: ComponentFixture<RaEffectOfHazardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RaEffectOfHazardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RaEffectOfHazardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
