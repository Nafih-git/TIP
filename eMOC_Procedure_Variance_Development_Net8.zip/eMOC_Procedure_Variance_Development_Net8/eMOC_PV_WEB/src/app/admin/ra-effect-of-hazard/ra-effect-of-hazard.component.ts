import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService, SelectItem } from 'primeng/api';
import { RaHazardModel } from 'src/app/models/ra-hazard_model';
import { RaEffectOfHazardModel } from '../../models/ra-effect-of-hazard_model';
import { CommonFunctions } from '../../utility/common/common-functions';
import { HttpService } from '../../utility/http.service';

@Component({
  selector: 'app-ra-effect-of-hazard',
  templateUrl: './ra-effect-of-hazard.component.html',
  styleUrls: ['./ra-effect-of-hazard.component.css']
})
export class RaEffectOfHazardComponent implements OnInit {

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  raHazardSelectList: SelectItem[] = new Array<SelectItem>();

  cols: any[] = [
    { field: 'Id', header: 'SNo.', width: '50px', isBadge: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'Name', header: 'Effect of Hazard', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'HazardName', header: 'Threat/Hazard', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Active', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'CreatedDate', header: 'Created date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedDate', header: 'Modified date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
  ];

  statuses: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  raEffectOfHazardList: RaEffectOfHazardModel[] = new Array<RaEffectOfHazardModel>();
  raEffectOfHazard: RaEffectOfHazardModel = new RaEffectOfHazardModel();
  selectedRow: RaEffectOfHazardModel = new RaEffectOfHazardModel();
  loading: boolean = false;
  isSaveClicked: boolean = false;
  displayModal: boolean = false;
  @ViewChild("formRaEffectOfHazard") formRaEffectOfHazard!: NgForm;
  @ViewChild("dataTable") table!: any;

  ngOnInit(): void {

    this.GetActiveRAHazards();
    this.GetAllRaEffectOfHazard();
  }

  GetActiveRAHazards() {

    this.raHazardSelectList = new Array<SelectItem>();

    this._HttpService.GetAll("Master/GetActiveRAHazards").subscribe((res: RaHazardModel[]) => {

      res.forEach(s => this.raHazardSelectList.push({ value: s.Id, label: s.Name }));
    });
  }

  GetAllRaEffectOfHazard() {

    this.loading = true;

    this._HttpService.GetAll("Master/GetAllRAHazardEffects").subscribe(res => {

      this.raEffectOfHazardList = res;
      this.raEffectOfHazardList.forEach(s => {

        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });

      this.loading = false;
    });
  }

  Save() {

    this.isSaveClicked = true;

    if (this.formRaEffectOfHazard.valid)
      this._HttpService.Post("Master/SaveRAHazardEffect", this.raEffectOfHazard).subscribe(res => {

        this.GetAllRaEffectOfHazard();
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;

        this.raEffectOfHazard = new RaEffectOfHazardModel();
      });
  }

  editTable(row: RaEffectOfHazardModel) {

    this.raEffectOfHazard = Object.assign({}, row);
    this.displayModal = true;
  }

  Close() {

    this.formRaEffectOfHazard.reset();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  exportExcel() {

    CommonFunctions.ExportExcel(this.cols, this.raEffectOfHazardList, 'Effect of Hazard');
  }

  exportPdf() {

    CommonFunctions.ExportPdf(this.cols, this.raEffectOfHazardList, 'Effect of Hazard');
  }

  exportCSV() {

    this.table.exportCSV();
  }
}