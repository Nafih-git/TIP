import { Component, OnInit, ViewChild } from '@angular/core';
import { RaControlMeasureComponent } from '../ra-control-measure/ra-control-measure.component';
import { RaEffectOfHazardComponent } from '../ra-effect-of-hazard/ra-effect-of-hazard.component';
import { RaHazardComponent } from '../ra-hazard/ra-hazard.component';

@Component({
  selector: 'app-ra-database',
  templateUrl: './ra-database.component.html',
  styleUrls: ['./ra-database.component.css']
})
export class RaDatabaseComponent implements OnInit {

  //RaHazard
  @ViewChild(RaHazardComponent)
  emocRaHazardTemplate!: RaHazardComponent;

  //EffectOfRaHazard
  @ViewChild(RaEffectOfHazardComponent)
  emocRaEffectOfHazardTemplate!: RaEffectOfHazardComponent;

  //ControlMeasure
  @ViewChild(RaControlMeasureComponent)
  emocRaControlMeasureTemplate!: RaControlMeasureComponent;

  constructor() { }

  ngOnInit(): void {
  }

  GetTableData() {

    this.emocRaEffectOfHazardTemplate.GetAllRaEffectOfHazard();
    this.emocRaEffectOfHazardTemplate.GetActiveRAHazards();

    this.emocRaControlMeasureTemplate.GetAllRaControlMeasure();
    this.emocRaControlMeasureTemplate.GetActiveRAHazards();
  }

  ShowModal(masterType: string = '') {

    switch (masterType) {
      case 'HZ': {
        setTimeout(() => {
          this.emocRaHazardTemplate.displayModal = true;
        }, 1);
        break;
      }
      case "EHZ": {
        setTimeout(() => {
          this.emocRaEffectOfHazardTemplate.displayModal = true;
        }, 1);
        break;
      }
      case "CM": {
        setTimeout(() => {
          this.emocRaControlMeasureTemplate.displayModal = true;
        }, 1);
        break;
      }
      default: {
        alert("Not implemented");
        break;
      }
    }
  }
}