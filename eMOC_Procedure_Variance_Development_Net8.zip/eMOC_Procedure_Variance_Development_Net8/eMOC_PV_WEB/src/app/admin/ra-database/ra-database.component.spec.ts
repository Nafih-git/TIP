import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RaDatabaseComponent } from './ra-database.component';

describe('RaDatabaseComponent', () => {
  let component: RaDatabaseComponent;
  let fixture: ComponentFixture<RaDatabaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RaDatabaseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RaDatabaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
