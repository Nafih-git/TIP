import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserManagementComponent } from './user-management/user-management.component';
import { EMOCMasterComponent } from './e-moc-master/e-moc-master.component';
import { RaDatabaseComponent } from './ra-database/ra-database.component';
import { AuthGuardService } from '../utility/service/auth-guard.service';
import { RouteDataEnum } from '../enums/route-data_enum';

const routes: Routes = [
  { path: 'user-managemet', component: UserManagementComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.UserManagement } },
  { path: 'eMOC-master', component: EMOCMasterComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.Master } },
  { path: 'RA-database', component: RaDatabaseComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.RiskAssessment } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
