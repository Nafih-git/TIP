import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { DocumentTypeModel } from 'src/app/models/documentType_model';
import { CommonFunctions } from 'src/app/utility/common/common-functions';
import { HttpService } from 'src/app/utility/http.service';

@Component({
  selector: 'app-document-type',
  templateUrl: './document-type.component.html',
  styleUrls: ['./document-type.component.css']
})
export class DocumentTypeComponent implements OnInit {
  constructor(private Http: HttpService, private msg: MessageService) { }
  loading: boolean = false;
  displayModal: boolean = false;
  isSaveClicked: boolean = false;
  documentTypeList: DocumentTypeModel[] = new Array<DocumentTypeModel>();
  documentType: DocumentTypeModel = new DocumentTypeModel();
  selectedRow: DocumentTypeModel = new DocumentTypeModel();
  @ViewChild("formDocumentType") formDocumentType!: NgForm;
  @ViewChild("dataTable") table!: any;

  cols: any[] = [
    { field: 'Id', header: 'Id', width: '50px', isBadge: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'Name', header: 'Document Type Name', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsMandatory', header: 'Mandatory', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Active', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedDate', header: 'Created date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedDate', header: 'Modified date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
  ];
  statuses: any[] = [
    { label: 'No', value: 0 },
    { label: 'Yes', value: 1 },
  ];
  ngOnInit(): void {
    this.GetAllDocumentTypes();
  }

  GetAllDocumentTypes() {
    this.loading = true;
    this.Http.GetAll("Master/GetAllDocumentTypes").subscribe(res => {
      this.documentTypeList = res;
      this.documentTypeList.forEach(s => {
        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });
      this.loading = false;
    });
  }

  editTable(row: DocumentTypeModel) {
    this.documentType = Object.assign({}, row);
    this.displayModal = true;
  }

  Close() {
    this.documentType = new DocumentTypeModel();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  Save() {
    this.isSaveClicked = true;
    if (this.formDocumentType.valid)
      this.Http.Post("Master/SaveDocumentType", this.documentType).subscribe(res => {

        this.GetAllDocumentTypes();
        this.msg.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;
        this.documentType = new DocumentTypeModel();
      });
  }

  exportExcel() {
    CommonFunctions.ExportExcel(this.cols, this.documentTypeList, 'Document Type List');
  }

  exportPdf() {
    CommonFunctions.ExportPdf(this.cols, this.documentTypeList, 'Document Type List');
  }

  exportCSV() {
    this.table.exportCSV();
  }

}
