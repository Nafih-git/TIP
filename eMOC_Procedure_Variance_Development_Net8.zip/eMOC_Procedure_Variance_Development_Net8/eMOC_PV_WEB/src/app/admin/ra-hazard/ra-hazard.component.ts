import { EventEmitter, Output, ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { RaHazardModel } from '../../models/ra-hazard_model';
import { CommonFunctions } from '../../utility/common/common-functions';
import { HttpService } from '../../utility/http.service';

@Component({
  selector: 'app-ra-hazard',
  templateUrl: './ra-hazard.component.html',
  styleUrls: ['./ra-hazard.component.css']
})
export class RaHazardComponent implements OnInit {

  @Output("GetTableData")
  GetTableData: EventEmitter<any> = new EventEmitter();

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  cols: any[] = [
    { field: 'Id', header: 'SNo.', width: '50px', isBadge: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'Name', header: 'Hazard/Threat', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Active', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'CreatedDate', header: 'Created date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedDate', header: 'Modified date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
  ];

  statuses: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  raHazardList: RaHazardModel[] = new Array<RaHazardModel>();
  raHazard: RaHazardModel = new RaHazardModel();
  selectedRow: RaHazardModel = new RaHazardModel();
  loading: boolean = false;
  isSaveClicked: boolean = false;
  displayModal: boolean = false;
  @ViewChild("formRaHazard") formRaHazard!: NgForm;
  @ViewChild("dataTable") table!: any;

  ngOnInit(): void {

    this.GetAllRaHazard();
  }

  GetAllRaHazard() {

    this.loading = true;

    this._HttpService.GetAll("Master/GetAllRAHazards").subscribe(res => {

      this.raHazardList = res;

      this.raHazardList.forEach(s => {

        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });

      this.loading = false;
    });
  }

  Save() {

    this.isSaveClicked = true;

    if (this.formRaHazard.valid)

      this._HttpService.Post("Master/SaveRAHazard", this.raHazard).subscribe(res => {

        this.GetAllRaHazard();
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;

        this.raHazard = new RaHazardModel();

        this.GetTableData.emit();
      });
  }

  editTable(row: RaHazardModel) {

    this.raHazard = Object.assign({}, row);
    this.displayModal = true;
  }

  Close() {

    this.formRaHazard.reset();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  exportExcel() {

    CommonFunctions.ExportExcel(this.cols, this.raHazardList, 'Hazard List');
  }

  exportPdf() {

    CommonFunctions.ExportPdf(this.cols, this.raHazardList, 'Hazard List');
  }

  exportCSV() {

    this.table.exportCSV();
  }
}