import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RaHazardComponent } from './ra-hazard.component';

describe('RaHazardComponent', () => {
  let component: RaHazardComponent;
  let fixture: ComponentFixture<RaHazardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RaHazardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RaHazardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
