import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmocModulesComponent } from './emoc-modules.component';

describe('EmocModulesComponent', () => {
  let component: EmocModulesComponent;
  let fixture: ComponentFixture<EmocModulesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmocModulesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmocModulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
