
import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { ModuleModel } from '../../models/module_model';
import { ScreenModels } from '../../models/screen_models';
import { CommonFunctions } from '../../utility/common/common-functions';
import { HttpService } from '../../utility/http.service';

@Component({
  selector: 'app-emoc-modules',
  templateUrl: './emoc-modules.component.html',
  styleUrls: ['./emoc-modules.component.css']
})
export class EmocModulesComponent implements OnInit {

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  cols: any[] = [
    { field: 'Name', header: 'Display Name', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'Description', header: 'Description', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'IsActive', header: 'Active', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'OrderNo', header: 'Order No.', width: '130px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'CreatedDate', header: 'Created date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedDate', header: 'Modified date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
  ];

  statuses: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  moduleList: ModuleModel[] = new Array<ModuleModel>();
  module: ModuleModel = new ModuleModel();
  selectedRow: ModuleModel = new ModuleModel();
  loading: boolean = false;
  isSaveClicked: boolean = false;
  displayModal: boolean = false;
  @ViewChild("formModule") formModule!: NgForm;
  @ViewChild("dataTable") table!: any;

  ngOnInit(): void {

    this.GetAllModules();
  }

  GetAllModules() {

    this.loading = true;

    this._HttpService.GetAll("Master/GetAllModules").subscribe(res => {

      this.moduleList = res;

      this.moduleList.forEach(s => {

        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });

      this.loading = false;
    });
  }

  Save() {

    this.isSaveClicked = true;

    if (this.formModule.valid)
      this.module.ScreensList = new Array<ScreenModels>();
      this.module.Collapse = "";
      this._HttpService.Post("Master/SaveModule", this.module).subscribe(res => {

        this.GetAllModules()
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;

        this.module = new ModuleModel();
      });
  }

  editTable(row: ModuleModel) {

    this.module = Object.assign({}, row);
    this.displayModal = true;
  }

  Close() {

    this.formModule.reset();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  exportExcel() {

    CommonFunctions.ExportExcel(this.cols, this.moduleList, 'Modules');
  }

  exportPdf() {

    CommonFunctions.ExportPdf(this.cols, this.moduleList, 'Modules')
  }

  exportCSV() {
    this.table.exportCSV();
  }
}
