import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService, SelectItem } from 'primeng/api';
import { RaHazardModel } from 'src/app/models/ra-hazard_model';
import { RaControlMeasureModel } from '../../models/ra-control-measure_model';
import { CommonFunctions } from '../../utility/common/common-functions';
import { HttpService } from '../../utility/http.service';

@Component({
  selector: 'app-ra-control-measure',
  templateUrl: './ra-control-measure.component.html',
  styleUrls: ['./ra-control-measure.component.css']
})
export class RaControlMeasureComponent implements OnInit {

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  raHazardSelectList: SelectItem[] = new Array<SelectItem>();

  cols: any[] = [
    { field: 'Id', header: 'SNo.', width: '50px', isBadge: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'Name', header: 'Control Measures Required to Reduce Initial Risk', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'HazardName', header: 'Threat/Hazard', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Active', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'CreatedDate', header: 'Created date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true},
    { field: 'ModifiedDate', header: 'Modified date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true},
  ];

  statuses: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  raControlMeasureList: RaControlMeasureModel[] = new Array<RaControlMeasureModel>();
  raControlMeasure: RaControlMeasureModel = new RaControlMeasureModel();
  selectedRow: RaControlMeasureModel = new RaControlMeasureModel();
  loading: boolean = false;
  isSaveClicked: boolean = false;
  displayModal: boolean = false;
  @ViewChild("formRaControlMeasure") formRaControlMeasure!: NgForm;
  @ViewChild("dataTable") table!: any;

  ngOnInit(): void {

    this.GetActiveRAHazards();
    this.GetAllRaControlMeasure();
  }

  GetActiveRAHazards() {

    this.raHazardSelectList = new Array<SelectItem>();

    this._HttpService.GetAll("Master/GetActiveRAHazards").subscribe((res: RaHazardModel[]) => {

      res.forEach(s => this.raHazardSelectList.push({ value: s.Id, label: s.Name }));
    });
  }

  GetAllRaControlMeasure() {

    this.loading = true;

    this._HttpService.GetAll("Master/GetAllRAControlMeasure").subscribe(res => {

      this.raControlMeasureList = res;

      this.raControlMeasureList.forEach(s => {

        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);
        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      });

      this.loading = false;
    });
  }

  Save() {

    this.isSaveClicked = true;

    if (this.formRaControlMeasure.valid)
      this._HttpService.Post("Master/SaveRAControlMeasure", this.raControlMeasure).subscribe(res => {

        this.GetAllRaControlMeasure();
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;

        this.raControlMeasure = new RaControlMeasureModel();
      });
  }

  editTable(row: RaControlMeasureModel) {

    this.raControlMeasure = Object.assign({}, row);
    this.displayModal = true;
  }

  Close() {

    this.formRaControlMeasure.reset();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  exportExcel() {

    CommonFunctions.ExportExcel(this.cols, this.raControlMeasureList, 'Control Measure List');
  }

  exportPdf() {

    CommonFunctions.ExportPdf(this.cols, this.raControlMeasureList, 'Control Measure List');
  }

  exportCSV() {

    this.table.exportCSV();
  }
}