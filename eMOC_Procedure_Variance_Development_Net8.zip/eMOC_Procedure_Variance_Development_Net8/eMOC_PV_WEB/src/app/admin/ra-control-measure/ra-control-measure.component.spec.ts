import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RaControlMeasureComponent } from './ra-control-measure.component';

describe('RaControlMeasureComponent', () => {
  let component: RaControlMeasureComponent;
  let fixture: ComponentFixture<RaControlMeasureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RaControlMeasureComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RaControlMeasureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
