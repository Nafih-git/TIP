import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { HttpService } from 'src/app/utility/http.service';
import { ControlOwnerComponent } from '../control-owner/control-owner.component';
import { ControlTypeComponent } from '../control-type/control-type.component';

import { EmailTemplateComponent } from '../email-template/email-template.component';
import { EmocModulesComponent } from '../emoc-modules/emoc-modules.component';
import { EmocRoleComponent } from '../emoc-role/emoc-role.component';
import { EmocScreensComponent } from '../emoc-screens/emoc-screens.component';

import { HelpComponent } from '../help/help.component';
import { ReasonVarianceComponent } from '../reasonvariance/reasonvariance.component';

@Component({
  selector: 'app-e-moc-master',
  templateUrl: './e-moc-master.component.html',
  styleUrls: ['./e-moc-master.component.css']
})

export class EMOCMasterComponent implements OnInit {

  constructor(private _HttpService: HttpService) { }

  masterType: string = "RL";

  masterTypeList: any[] = [];

  //EmocRole
  @ViewChild(EmocRoleComponent)
  emocRoleTemplate!: EmocRoleComponent;

  //EmocModule
  @ViewChild(EmocModulesComponent)
  emocModuleTemplate!: EmocModulesComponent;

  //EmocScreens
  @ViewChild("screenTemplate")
  emocScreensTemplate!: EmocScreensComponent;

  //EmocControlType
  @ViewChild(ControlTypeComponent)
  emocControlTypeTemplate!: ControlTypeComponent;

  //EmocControlOwner
  @ViewChild(ControlOwnerComponent)
  emocControlOwnerTemplate!: ControlOwnerComponent;


  //Category
  @ViewChild(ReasonVarianceComponent)
  reasonVarianceTemplate!: ReasonVarianceComponent;



  //Help
  @ViewChild(HelpComponent)
  helpTemplate!: HelpComponent;

  //email-template
  @ViewChild("emailTemplate")
  emailTemplate!: EmailTemplateComponent;

  ngOnInit(): void {
    this.getMasterItems();
  }

  getMasterItems() {
    this._HttpService.GetAll("Master/GetMasterItems").subscribe(result => {
      this.masterTypeList = result;

    });
  }

  ShowModal() {
    switch (this.masterType) {
      case 'RL': {
        this.emocRoleTemplate.displayModal = true;
        break;
      }
      case "MDS": {
        this.emocModuleTemplate.displayModal = true;
        break;
      }
      case "SCR": {
        this.emocScreensTemplate.displayModal = true;
        break;
      }
      case "CT": {
        this.emocControlTypeTemplate.displayModal = true;
        break;
      }
      case "CO": {
        this.emocControlOwnerTemplate.displayModal = true;
        break;
      }

      case "RFV": {
        this.reasonVarianceTemplate.displayModal = true;
        break;
      }


      case "HLP": {
        this.helpTemplate.displayModal = true;
        break;
      }
      case "EMT": {
        this.emailTemplate.displayModal = true;
        break;
      }
      default: {
        alert("Not implemented");
        break;
      }
    }
  }

  exportExcel() {
    switch (this.masterType) {
      case 'RL': {
        this.emocRoleTemplate.exportExcel();
        break;
      }
      case 'MDS': {
        this.emocModuleTemplate.exportExcel();
        break;
      }
      case "SCR": {
        this.emocScreensTemplate.exportExcel();
        break;
      }
      case 'CT': {
        this.emocControlTypeTemplate.exportExcel();
        break;
      }
      case 'CO': {
        this.emocControlOwnerTemplate.exportExcel();
        break;
      }

      case "RFV": {
        this.reasonVarianceTemplate.exportExcel();
        break;
      }
      case "HLP": {
        this.helpTemplate.exportExcel();
        break;
      }
      case 'EMT': {
        this.emailTemplate.exportExcel();
        break;
      }
      default: {
        alert("Not implemented")
        break;
      }
    }
  }

  exportPdf() {
    switch (this.masterType) {
      case 'RL': {
        this.emocRoleTemplate.exportPdf();
        break;
      }
      case 'MDS': {
        this.emocModuleTemplate.exportPdf();
        break;
      }
      case "SCR": {
        this.emocScreensTemplate.exportPdf();
        break;
      }
      case 'CT': {
        this.emocControlTypeTemplate.exportPdf();
        break;
      }
      case 'CO': {
        this.emocControlOwnerTemplate.exportPdf();
        break;
      }

      case "RFV": {
        this.reasonVarianceTemplate.exportPdf();
        break;
      }


      case "HLP": {
        this.helpTemplate.exportPdf();
        break;
      }
      case 'EMT': {
        this.emailTemplate.exportPdf();
        break;
      }
      default: {
        alert("Not implemented")
        break;
      }
    }
  }

  exportCSV() {
    switch (this.masterType) {
      case 'RL': {
        this.emocRoleTemplate.exportCSV();
        break;
      }
      case 'MDS': {
        this.emocModuleTemplate.exportCSV();
        break;
      }
      case "SCR": {
        this.emocScreensTemplate.exportCSV();
        break;
      }
      case 'CT': {
        this.emocControlTypeTemplate.exportCSV();
        break;
      }
      case 'CO': {
        this.emocControlOwnerTemplate.exportCSV();
        break;
      }

      case "RFV": {
        this.reasonVarianceTemplate.exportCSV();
        break;
      }


      case "HLP": {
        this.helpTemplate.exportCSV();
        break;
      }
      case 'EMT': {
        this.emailTemplate.exportCSV();
        break;
      }
      default: {
        alert("Not implemented")
        break;
      }
    }
  }

  hideAddButton() {
    return (this.masterType != 'EMT' && this.masterType != 'RL');
  }
}
