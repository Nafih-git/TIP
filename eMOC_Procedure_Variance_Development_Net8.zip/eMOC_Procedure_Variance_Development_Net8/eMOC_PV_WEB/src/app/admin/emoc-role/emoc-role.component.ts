import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { RolesModel } from '../../models/roles_model';
import { CommonFunctions } from '../../utility/common/common-functions';
import { HttpService } from '../../utility/http.service';

@Component({
  selector: 'app-emoc-role',
  templateUrl: './emoc-role.component.html',
  styleUrls: ['./emoc-role.component.css']
})
export class EmocRoleComponent implements OnInit {

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  displayModal: boolean = false;

  stopListening = false;

  statuses: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  selectedRole: any;
  value: string = "";
  loading: boolean = false;
  isSaveClicked: boolean = false;
  @ViewChild("roleForm")
  roleForm!: NgForm;
  @ViewChild("dataTable")
  table!: any;
  roleList: RolesModel[] = new Array<RolesModel>();
  role: RolesModel = new RolesModel();

  cols: any[] = [
    { field: 'Name', header: 'Role Name', width: '200px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'Code', header: ' Role Code', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsDirectorate', header: 'Directorate', width: '110px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsAsset', header: 'Asset', width: '100px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsSBA', header: 'Sub Admin', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsSPA', header: 'Super Admin', width: '130px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsActive', header: 'Active', width: '100px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'IsDelegatedRole', header: 'Is Delegated Role', width: '100px', isBadge: true, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Created by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedDate', header: 'Created Date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedByName', header: 'Modified by', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ModifiedDate', header: 'Modified Date', width: '150px', isDate: true, isBadge: false, isSorting: true, isFilter: true, isExportable: true },
  ];

  ngOnInit(): void {

    this.GetAllRoles();
  }

  GetAllRoles() {

    this.loading = true;
    this._HttpService.GetAll("Master/GetAllRoles").subscribe(res => {

      this.roleList = res;

      this.roleList.forEach(s => {
        if (s.CreatedDate)
          s.CreatedDate = new Date(s.CreatedDate);

        if (s.ModifiedDate)
          s.ModifiedDate = new Date(s.ModifiedDate);
      })
      this.loading = false;
    });
  }

  Save() {

    this.isSaveClicked = true;
    if (this.roleForm.valid) {
      this.role.IsAsset = this.role.IsDirectorate == 1 ? 0 : 1;
      this._HttpService.Post("Master/SaveRole", this.role).subscribe(res => {
        this.GetAllRoles();
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        this.displayModal = false;
        this.isSaveClicked = false;
        this.role = new RolesModel();
      });
    }
  }

  Close() {
    this.role = new RolesModel();
    this.displayModal = false;
    this.isSaveClicked = false;
  }

  exportExcel() {
    CommonFunctions.ExportExcel(this.cols, this.roleList, 'Roles');
  }


  exportPdf() {
    CommonFunctions.ExportPdf(this.cols, this.roleList, 'Roles')
  }

  editTable(row: any) {
    this.role = Object.assign({}, row);
    this.displayModal = true;
  }

  exportCSV() {
    this.table.exportCSV();
  }

  customFilterCallback(filter: (a: any) => void, value: any): void {
    this.stopListening = true;
    filter(value);
    this.stopListening = false;
  }
}
