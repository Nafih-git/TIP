import { HostListener } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router, RouterEvent } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { filter, map, Observable, of } from 'rxjs';
import { ErrorService } from './utility/service/error.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Transfer of Control';
  loading = true;
  constructor(private primengConfig: PrimeNGConfig, private router: Router, public errorService: ErrorService) {
    router.events.subscribe(value => { this.ChangePageHeading() });
  }

  ngOnInit() {

    this.ChangePageHeading();
    this.primengConfig.ripple = true;
    this.router.events.subscribe((e: any) => {
      this.navigationInterceptor(e);

    });
  }

  HideSideNavBar() {

    if (this.router.url.toUpperCase().includes("INDEX")) {
      document.getElementsByTagName('body')[0].classList.add("sidebar-collapse");
    }
    else {
      document.getElementsByTagName('body')[0].classList.remove("sidebar-collapse");
    }
  }

  ChangePageHeading() {
    setTimeout(() => {
      if (document.getElementsByClassName('page-heading') && document.getElementsByClassName('page-heading')[0]) {
        var pageTitle = document.getElementsByClassName('page-heading')[0].innerHTML
        document.title = pageTitle;
      }
    }, 100)

  }

  navigationInterceptor(event: RouterEvent): void {
    if (event instanceof NavigationStart) {
      this.loading = true
    }
    if (event instanceof NavigationEnd) {
      this.loading = false;
      // this.HideSideNavBar();
    }

    // Set loading state to false in both of the below events to hide the spinner in case a request fails
    if (event instanceof NavigationCancel) {
      this.loading = false
    }
    if (event instanceof NavigationError) {
      this.loading = false
    }
  }


}
