import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportsRoutingModule } from './reports-routing.module';
import { ReportComponent } from './report/report.component';

import { TableModule } from 'primeng/table';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { CheckboxModule } from 'primeng/checkbox';
import { TooltipModule } from 'primeng/tooltip';
import { DividerModule } from 'primeng/divider';
import { FieldsetModule } from 'primeng/fieldset';
import { DropdownModule } from 'primeng/dropdown';
import { PanelModule } from 'primeng/panel';
import { FormsModule } from '@angular/forms';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { LoadingSpinnerModule } from '../utility/directive/loading-spinner/loading-spinner.module';
import { FileUploadModule } from 'primeng/fileupload';
import { NumberOnlyModule } from '../utility/directive/numbersOnly/numbersOnly.module';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MenuModule } from 'primeng/menu';
import { PartialModule } from '../partial/partial.module';
import { ListboxModule } from 'primeng/listbox';
import { CalendarModule } from 'primeng/calendar';
import { StepsModule } from 'primeng/steps';
import { MessageModule } from 'primeng/message';
import { TrueFalseValueModule } from '../utility/directive/true-false-value/true-false-value.module';


@NgModule({
  declarations: [
    ReportComponent
  ],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    CommonModule,
    FormsModule,
    TableModule,
    InputTextModule,
    ButtonModule,
    DialogModule,
    CheckboxModule,
    TooltipModule,
    DividerModule,
    FieldsetModule,
    PanelModule,
    DropdownModule,
    ConfirmDialogModule,
    LoadingSpinnerModule,
    FileUploadModule,
    NumberOnlyModule,
    AutoCompleteModule,
    MenuModule,
    PartialModule,
    ListboxModule,
    CalendarModule,
    StepsModule,
    MessageModule,
    TrueFalseValueModule
  ]
})
export class ReportsModule { }
