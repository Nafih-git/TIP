import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RouteDataEnum } from '../enums/route-data_enum';
import { AuthGuardService } from '../utility/service/auth-guard.service';
import { ReportComponent } from './report/report.component';

const routes: Routes = [
  {
    path: 'report/:id', component: ReportComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.ImplementedReport }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }