import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LazyLoadEvent, MenuItem, SelectItem } from 'primeng/api';
import { Menu } from 'primeng/menu';
import { Table } from 'primeng/table';
import { AllRequestFilterModel } from 'src/app/models/all-request-filter_model';
import { Reports } from 'src/app/models/reports_model';
import { AssetModel } from 'src/app/models/asset_model';
import { ApprovalHistoryComponent } from 'src/app/partial/approval-history/approval-history.component';
import { ExtensionHistoryComponent } from 'src/app/partial/extension-history/extension-history.component';
import { TaskHistoryComponent } from 'src/app/partial/task-history/task-history.component';
import { CommonFunctions } from 'src/app/utility/common/common-functions';
import { HttpService } from 'src/app/utility/http.service';
import { FacilityModel } from 'src/app/models/facility_model';
import { DirectorateModel } from 'src/app/models/directorate_model';
import { ReportTypeEnum } from 'src/app/enums/reporttype_enum';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {

  @ViewChild(TaskHistoryComponent) taskHistoryComponent!: TaskHistoryComponent;
  @ViewChild(ApprovalHistoryComponent) approvalHistoryComponent!: ApprovalHistoryComponent;
  @ViewChild(ExtensionHistoryComponent) extensionHistoryComponent!: ExtensionHistoryComponent;
  @ViewChild('dataTable') dataTable!: Table;

  loading: boolean = true;
  allRequestList: Reports[] = new Array<Reports>();
  allRequestExportList: Reports[] = new Array<Reports>();
  selectedRow: Reports = new Reports();
  totalRecords: number = 0;
  allRequestFilter: AllRequestFilterModel = new AllRequestFilterModel();
  directorates: DirectorateModel[] = new Array<DirectorateModel>();
  assets: AssetModel[] = new Array<AssetModel>();
  facilityList: FacilityModel[] = new Array<FacilityModel>();
  reportTypeList: SelectItem[] = new Array<SelectItem>();
  directorate: string = '';
  asset: string = '';
  facility: string = '';
  cols: any[] = [];
  startDate: Date = new Date(new Date().getTime() - (30 * 24 * 60 * 60 * 1000));
  endDate: Date = new Date();
  reportType: string = "";

  userSearchSubscribe: any;
  clearClick: boolean = false;
  ReportTypeEnum() { typeof this.ReportTypeEnum; return ReportTypeEnum };

  InitializeColumns() {

    this.cols = [
      { field: 'Id', header: 'Request No', width: '110px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, IsShow: true, isExportable: true },
      { field: 'CustomStatus', header: 'eMOC Status', width: '250px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, IsShow: true, isExportable: true },
      { field: 'Directorate', header: 'Directorate', width: '100px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, IsShow: true, isExportable: true },
      { field: 'Asset', header: 'Asset', width: '100px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, IsShow: true, isExportable: true },
      { field: 'Facility', header: 'Facilities', width: '150px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, IsShow: true, isExportable: true },
     { field: 'ImplementedDate', header: 'Implemented Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, IsShow: this.reportType == this.ReportTypeEnum().ImplementedReport ? true : false, isExportable: this.reportType == this.ReportTypeEnum().ImplementedReport ? true : false },
      { field: 'ExpiredDate', header: 'Expired Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, IsShow: this.reportType == this.ReportTypeEnum().ExpiryReport ? true : false, isExportable: this.reportType == this.ReportTypeEnum().ExpiryReport ? true : false },
      { field: 'StepName', header: 'Expired With Role', width: '150px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: true, IsShow: this.reportType == this.ReportTypeEnum().ExpiryReport ? true : false, isExportable: this.reportType == this.ReportTypeEnum().ExpiryReport ? true : false },
      { field: 'OverdueDate', header: 'Overdue Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, IsShow: this.reportType == this.ReportTypeEnum().OverdueReport ? true : false, isExportable: this.reportType == this.ReportTypeEnum().OverdueReport ? true : false },
      { field: 'RejectedDate', header: 'Rejected Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, IsShow: this.reportType == this.ReportTypeEnum().RejectedReport ? true : false, isExportable: this.reportType == this.ReportTypeEnum().RejectedReport ? true : false },
      { field: 'FromDate', header: 'From Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, IsShow: true, isExportable: true },
      { field: 'ToDate', header: ' To Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, IsShow: true, isExportable: true },
      { field: 'CreatedByName', header: 'Submitted By', width: '250px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: true, IsShow: true, isExportable: true },
      { field: 'CreatedDate', header: 'Submitted Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, IsShow: true, isExportable: true },
    ];
  }

  displayTaskHistoryModal: boolean = false;
  displayApprovalHistoryModal: boolean = false;
  displayExtensionHistoryModal: boolean = false;

  constructor(private _HttpService: HttpService, private _rout: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      this.reportType = params['id'];
      this.ClearFilter();
    });
    this.GetDirectorates();
    this.InitializeColumns();
  }

  async GetDirectorates() {
    return new Promise(resolve => {
      this._HttpService.GetAll("Master/GetDirectorates").subscribe(res => {
        this.directorates = res;
        resolve("Success");
      });
    });
  }

  GetAsset() {
    this._HttpService.Get1("Master/GetAssets", { Directorate: this.directorate }).subscribe(res => {
      this.assets = res;
    });
  }

  GetFacilities() {
    this._HttpService.Get1("Master/GetFacilities", { Directorate: this.directorate, Asset: this.asset }).subscribe(res => {
      this.facilityList = res;
    });
  }

  GetAllRequests() {
    this.loading = true;
    this._HttpService.Get1('Request/GetAllRequests', { FilterString: JSON.stringify(this.allRequestFilter) }).subscribe(res => {
      if (res) {
        this.allRequestList = res;
        this.totalRecords = this.allRequestList[0]?.TotalRecords ?? 0;
        if (this.totalRecords > 0) {
          this.allRequestList.forEach(s => {
            if (s.CreatedDate) s.CreatedDate = new Date(s.CreatedDate);
            if (s.ModifiedDate) s.ModifiedDate = new Date(s.ModifiedDate);
          });
        }
        this.InitializeColumns();
        this.loading = false;
      }
    });
  }

  GetAllRequestsExport() {
    this.allRequestFilter.FullRecords = 1;
    this._HttpService.Get1('Request/GetAllRequests', { FilterString: JSON.stringify(this.allRequestFilter) }).subscribe(res => {
      if (res) {
        this.allRequestExportList = res;
        this.totalRecords = this.allRequestExportList[0]?.TotalRecords ?? 0;

        if (this.totalRecords > 0) {
          this.allRequestExportList.forEach(s => {
            if (s.CreatedDate) s.CreatedDate = new Date(s.CreatedDate);
            if (s.ModifiedDate) s.ModifiedDate = new Date(s.ModifiedDate);
          });

          console.log(this.allRequestExportList);
          CommonFunctions.ExportExcel(this.cols, this.allRequestExportList, this.reportType);
        }
      }
    });
  }

  NextPage(event: LazyLoadEvent) {
    this.allRequestFilter.First = event.first ?? 0;
    this.allRequestFilter.Rows = event.rows ?? 10;
    this.allRequestFilter.SortField = event.sortField ?? 'Id';

    if (this.clearClick) {
      this.allRequestFilter.SortOrder = 'DESC';
    }
    else {
      this.allRequestFilter.SortOrder = event.sortOrder === 1 ? 'ASC' : 'DESC';
    }

    this.allRequestFilter.FullRecords = 0;
    this.allRequestFilter.RequestFilter = JSON.stringify({
      ReportType: this.reportType,
      Directorate: this.directorate, Asset: this.asset, Facility: this.facility,
      StartDate: this.startDate ? this.startDate.toLocaleDateString() : '', EndDate: this.endDate ? this.endDate.toLocaleDateString() : ''
    });

    this.clearClick = false;
    this.GetAllRequests();
  }

  Filter() {
    this.allRequestFilter = new AllRequestFilterModel();
    this.allRequestFilter.SortField = 'Id';
    this.allRequestFilter.SortOrder = 'DESC';
    this.allRequestFilter.FullRecords = 0;
    this.allRequestFilter.Rows = 10;
    this.allRequestFilter.RequestFilter = JSON.stringify({
      ReportType: this.reportType,
      Directorate: this.directorate, Asset: this.asset, Facility: this.facility,
      StartDate: this.startDate ? this.startDate.toLocaleDateString() : '', EndDate: this.endDate ? this.endDate.toLocaleDateString() : ''
    });
    console.log(this.allRequestFilter.RequestFilter);
    this.GetAllRequests();
  }

  FilterExport() {

    this.Filter();
    this.GetAllRequestsExport();
  }

  ClearFilter() {
    this.allRequestFilter = new AllRequestFilterModel();
    this.allRequestFilter.SortField = "Id";
    this.allRequestFilter.SortOrder = "DESC";

    this.directorate = '';
    this.asset = '';
    this.facility = '';
    this.startDate = new Date(new Date().getTime() - (30 * 24 * 60 * 60 * 1000));
    this.endDate = new Date();
    this.clearClick = true;
    this.Filter();
  }

  ToggleMenu(menu: Menu, event: Event, rowData: Reports) {
    this.selectedRow = rowData;
    menu.toggle(event);
  }

  ViewRequestDetail(event: any) {
    CommonFunctions.GetEditRequestPageInNewTab(this.selectedRow.Id);
  }

  ViewTaskHistory(event: any) {
    this.taskHistoryComponent.GetAllTasks(this.selectedRow.Id);
    this.displayTaskHistoryModal = true;
  }

  ViewApproval(event: any) {
    this.displayApprovalHistoryModal = true;
    this.approvalHistoryComponent.GetApprovalHistory(this.selectedRow.Id, 10);
  }

  ViewExtension(event: any) {
    this.displayExtensionHistoryModal = true;
    // this.extensionHistoryComponent.GetExtensionHistory(this.selectedRow.Id);
  }

  exportExcel() {
    this.FilterExport();
  }

  SelectStartDate() {
    if (!this.endDate || (this.startDate && this.startDate > this.endDate)) {
      this.endDate = this.startDate;
    }
  }

  SelectEndDate() {
    if (!this.startDate || (this.endDate && this.startDate > this.endDate)) {
      this.startDate = this.endDate;
    }
  }
}
