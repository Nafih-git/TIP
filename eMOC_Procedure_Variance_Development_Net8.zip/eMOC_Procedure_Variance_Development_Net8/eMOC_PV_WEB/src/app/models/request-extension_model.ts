export class RequestExtension {

  Id: number = 0;
  EffectiveFromDate!: Date;
  EffectiveToDate!: Date;
  LineManager: string = '';
  LineManagerName: string = '';
  LmChangeReasonId: number = 0;
  RAApprover: string = '';
  RAApproverRoleId: number = 0;
  WorkflowStatusId: number = 0;
  WorkflowStatus: string = '';
  ExtensionVersion: number = 0;
}