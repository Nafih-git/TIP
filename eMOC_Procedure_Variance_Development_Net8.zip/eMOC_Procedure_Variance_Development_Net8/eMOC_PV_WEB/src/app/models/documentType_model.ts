import { AuditModel } from "./audit_model";

export class DocumentTypeModel extends AuditModel {
    Id: number = 0;
    Name: string = "";
    IsMandatory: number = 0;
    IsActive: number = 1;
}