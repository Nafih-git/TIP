export class AuditModel {
  // Id: number = 0;
  CreatedDate !: Date;
  CreatedBy: string = "";
  CreatedByName: string = "";
  ModifiedDate !: Date ;
  TaskAssignedDate !: Date ;

  ModifiedBy: string="";
  ModifiedByName: string = "";
}
