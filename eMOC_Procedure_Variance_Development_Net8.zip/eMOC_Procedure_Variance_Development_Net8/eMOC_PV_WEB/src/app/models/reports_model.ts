import { AllRequestModel } from "./all-request_model";

export class Reports extends AllRequestModel {

  TimeTakenToClose: string = '';
}