import { AuditModel } from "./audit_model";

export class RaControlTypeModel extends AuditModel {
  Id !: number;
  Name !: string;
  IsActive : number = 0;
}