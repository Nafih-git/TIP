import { AuditModel } from "./audit_model";

export class RaControlOwnerModel extends AuditModel {
  Id !: number;
  Name !: string;
  IsActive : number = 0;
}