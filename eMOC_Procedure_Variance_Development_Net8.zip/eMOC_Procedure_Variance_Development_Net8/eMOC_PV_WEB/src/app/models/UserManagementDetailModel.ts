import { UserDetailModel } from "./user-detail_model";

export class UserManagementDetail extends UserDetailModel {
    Id: number=0;
    UserManagementId : number = 0;
    IsActive : number = 0;
    MUNumber : string = "";
  IsDeleted: number = 0;
  isAddedFromClent: boolean = false;
}
