import { AuditModel } from "./audit_model";

export class RaTeamMemberModel extends AuditModel {

  Id: number = 0;
  RequestId: number = 0;
  MuNumber: string | undefined;
  Name: string | undefined;
  JobDescription: string | undefined;
  Competency: string | undefined;
  IsActive: number = 0;
  OrderNo: number = 0;
}