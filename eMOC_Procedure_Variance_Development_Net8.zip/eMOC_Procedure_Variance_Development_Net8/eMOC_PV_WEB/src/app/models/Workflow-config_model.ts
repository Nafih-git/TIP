import { AuditModel } from "./audit_model";
import { UserDetailModel } from "./user-detail_model";

export class WorkflowConfigModel extends AuditModel {
  Id: number = 0;
  Name: string = "";
  CategoryId: number = 0;
  Approver1RoleId: number = 0;
  Approver1RoleName: string = "";
  Approver2RoleId: number = 0;
  Approver2RoleName: string = "";
  Approver3RoleId: number = 0;
  Approver3RoleName: string = "";
  Approver1List: UserDetailModel[] = new Array<UserDetailModel>();
  Approver2List :UserDetailModel[]=new Array<UserDetailModel>();
  Approver3List :UserDetailModel[]=new Array<UserDetailModel>();
}

