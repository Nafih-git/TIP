import { AuditModel } from "./audit_model";

export class LmChangeReasonModel extends AuditModel {
  Id !: number;
  Reason !: string;
  IsActive : number = 0;
  OrderNo !: number;
}