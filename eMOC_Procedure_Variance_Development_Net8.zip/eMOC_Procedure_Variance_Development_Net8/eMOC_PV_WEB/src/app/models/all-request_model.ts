import { AuditModel } from "./audit_model";

export class AllRequestModel extends AuditModel {

  Id: number = 0;
  Directorate: string = "";
  Asset: string = "";
  Facilities: string = "";
  Cockpit: number = 0;
  EmocType: string = "";
  Category: string = "";
  TOC: string = "";
  TOCId: number = 0;
  EffectiveFromDate: Date = new Date();
  EstimatedToDate: Date = new Date();
  ImplementedDate: Date = new Date();
  Justification: string = "";
  WorkflowStatus: string = "";
  WorkflowStatusId: number = 0;
  CustomStatus: string = "";
  PendingWith: string = "";
  PendingWithName: string = "";
  TotalRecords: number = 0;
  Indicator: string = "";
  ExtensionCount : number = 0;
  ProcedureTitle : string ='';
  ProcedureCode : string ='';
  ProcedureDisplayName : string ='';
  IsCMSIntegration : number = 0;
  IsManual : number = 0;
}

