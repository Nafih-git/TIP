import { AuditModel } from "./audit_model";

export class RaEffectOfHazardModel extends AuditModel {

  Id!: number;
  Name!: string;
  HazardId!: number;
  HazardName!: string;
  IsActive: number = 0;
}