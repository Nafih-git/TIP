export class AllRequestFilterForKPIModel {

  ChartType !: number;

  FullRecords !: number;
  RequestFilter !: string;

}
