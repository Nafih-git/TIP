export class DirectorateModel {
    Directorate: string = "";
}