import { AuditModel } from "./audit_model";
import { ScreenModels } from "./screen_models";

export class ModuleModel extends AuditModel {
  Id !: number;
  Name !: string;
  Description !: string;
  IsActive !: number;
  OrderNo !: number;
  ScreensList: ScreenModels[] = new Array<ScreenModels>();
  Collapse !: string;
  Icon !: string;
}
