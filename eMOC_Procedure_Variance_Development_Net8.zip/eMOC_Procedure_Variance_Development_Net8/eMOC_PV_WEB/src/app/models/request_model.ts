import { ApprovalHistory } from "./approval-history_model";
import { AuditModel } from "./audit_model";
import { DocumentsModels } from "./documents_model";
import { FacilityModel } from "./facility_model";
import { RaTeamMemberModel } from "./ra-team-member_model";
import { RequestExtension } from "./request-extension_model";
import { RequestExtensionModel } from "./request_Extension_model";
import { RiskAssessmentOutputModel } from "./risk-assessment-output_model";
import { TaskModel } from "./task_model";
import { UserDetailModel } from "./user-detail_model";

export class RequestModel extends AuditModel {

  Id: number = 0;
  WorkflowActionId: number = 0;
  WorkflowStatusId: number = 0;
  WorkflowStatus: string = "";
  CurrentStepId: number = 1;
  DraftDeletedDate !: Date;
  General: GeneralModel = new GeneralModel();
  RATeamMembers: RaTeamMemberModel[] = new Array<RaTeamMemberModel>();
  RiskAssessment: RiskAssessmentOutputModel = new RiskAssessmentOutputModel();
  ApproverHistory: ApprovalHistory[] = new Array<ApprovalHistory>();
  Documents: DocumentsModels[] = new Array<DocumentsModels>();
  RequestExtensionList: RequestExtensionModel[] = new Array<RequestExtensionModel>();

  RequestExtension !: RequestExtensionModel ;
  Task: TaskModel = new TaskModel();
  ActiveTask : TaskModel = new TaskModel();
  NotifyTo : string ="";
  Comment: string = "";
  NextApprover: string = "";
  Approver: string = "";
  NextApproverRoleId : number = 0;
  NextARID : number = 0;
  ForwardToOther : UserDetailModel = new UserDetailModel();
  CustomStatus : string="";
  BackupApprovers: UserDetailModel[] = new Array<UserDetailModel>();
  IseMOCHistory : boolean = false;


}


export class GeneralModel {
  Directorate: string | undefined;
  Asset: string | undefined;
  Facility: string | undefined;
  ProcedureTitle: string = "";
  ProcedureCode: string = "";
  ProcedureLink: string = "";

  FromDate : Date | null = null ;
  ToDate : Date | null = null;

  ExtensionFromDate : Date | null = null ;
  ExtensionToDate : Date | null = null;
  ImplementedDate : Date | null = null ;
  Justification: string = "";
  Title : string = "";

  Section: string = "";
  FunctionalReviewer: string = "";
  TechnicalApprover: string = "";
  TechnicalApproverName: string = "";
  FunctionalReviewerName: string = "";
  TechnicalApproverRoleName : string = "";
  FunctionalReviewerRoleName : string = "";
  DeviatedAgainst : string = "";
  ReasonVarianceId !:number;
  ReasonVarianceName !:string ;
  ProcedureDisplayName  !:string ;
  Endorser!:string ;
  EndorserName: string = "";
  EndorserRoleName : string = "";
  EndorserRoleId: number = 0;


  RAApprover!:string ;
  RAApproverName: string = "";
  RAApproverRoleName : string = "";
  RAApproverRoleId: number = 0;

  Authorizer!:string ;
  AuthorizerName: string = "";
  AuthorizerRoleName : string = "";
  AuthorizerRoleId: number = 0;

  ActiveTaskId : number = 0;
  IsManual : number = 1;

  LessonLearned: string = "";
  NotifyTo: string = "";

}
