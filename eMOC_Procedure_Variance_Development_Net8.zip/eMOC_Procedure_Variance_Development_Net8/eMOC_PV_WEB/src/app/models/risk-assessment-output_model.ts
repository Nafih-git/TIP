export class RiskAssessmentOutputModel {

  MaxInitialRiskCode!: string | undefined;
  MaxInitialRiskModule!: string | undefined;
  MaxInitialRisk!: string | undefined;
  MaxResidualRiskCode!: string | undefined;
  MaxResidualRiskModule!: string | undefined;
  MaxResidualRisk!: string | undefined;
  CumulativeRAName!: string | undefined;
  RAMatrix!: string | undefined;
  CumulativeRAMatrix!: string | undefined;
}