import { ApprovalHistory } from "./approval-history_model";
import { AuditModel } from "./audit_model";
import { DocumentsModels } from "./documents_model";
import { FacilityModel } from "./facility_model";
import { RaTeamMemberModel } from "./ra-team-member_model";
import { RequestExtension } from "./request-extension_model";
import { RiskAssessmentOutputModel } from "./risk-assessment-output_model";
import { TaskModel } from "./task_model";
import { UserDetailModel } from "./user-detail_model";

export class RequestExtensionModel {
  WorkflowActionId: number = 0;
  WorkflowStatusId: number = 0;
  WorkflowStatus: string = "";
  WorkflowStatusName :string = '';
  WorkflowTypeID: number = 0;
  WorkFlowStepId : number = 0;
  CustomStatus : string ='';
  Status : number = 0;
  StatusName : string = '';
  StatusDate : Date | null = null;
  EffectiveFromDate : Date | null = null ;
  EffectiveToDate : Date | null = null;


  TechnicalApprover: string = "";
  TechnicalApproverName: string = "";

  TechnicalApproverRoleName : string = "";


  Endorser!:string ;
  EndorserName: string = "";
  EndorserRoleName : string = "";
  EndorserRoleId: number = 0;


  Implementer!:string ;
  ImplementerName: string = "";


  Authorizer!:string ;
  AuthorizerName: string = "";
  AuthorizerRoleName : string = "";
  AuthorizerRoleId: number = 0;
  ExtensionVersion : number =0;
}
