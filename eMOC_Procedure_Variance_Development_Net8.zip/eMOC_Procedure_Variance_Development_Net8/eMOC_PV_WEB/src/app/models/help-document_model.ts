import { AuditModel } from "./audit_model";

export class HelpDocumentsModel extends AuditModel {

  Id: number = 0;
  FileName: string = '';
  Guid: string = '';
  DisplayName: string = '';
  OrderNo: number = 0;
  IsActive: number = 0;
  File: any = {};
  MimeType: string = "";
}