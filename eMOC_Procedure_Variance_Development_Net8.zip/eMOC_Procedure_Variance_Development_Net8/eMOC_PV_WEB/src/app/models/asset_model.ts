import { DirectorateModel } from "./directorate_model";

export class AssetModel extends DirectorateModel{
  Asset: string = "";
}