import { AuditModel } from "./audit_model";

export class WorkflowStatusModel extends AuditModel {
  Id: number = 0;
  Name: string = '';
  Description: string = '';
  Code: string = '';
  OrderNo: number = 0;
}