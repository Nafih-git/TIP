
import { AuditModel } from "./audit_model";
export class ScreenModels extends AuditModel
{
  Id: number = 0;
  Name: string = "";
  DisplayName: string = "";
  OrderNo: number | null = null;
  URL: string = "";
  ModuleId: number = 0;
  ModuleName: string = "";
  IsActive: number = 0;
  IsSAOnly: number = 0;
  IsCAOnly: number = 0;
  Icon: string = "";
  Selected: boolean = false;
}
