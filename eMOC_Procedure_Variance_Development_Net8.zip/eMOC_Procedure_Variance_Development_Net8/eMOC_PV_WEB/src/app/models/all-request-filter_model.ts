export class AllRequestFilterModel {

  ReportType: string = "";
  First: number = 0;
  Rows: number = 10;
  SortField: string = '';
  SortOrder: string = 'ASC';
  RequestFilter: string = '';
  FullRecords: number = 0;
  Type: string = "";
}
