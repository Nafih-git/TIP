import { AuditModel } from "./audit_model";

export class TOCModel extends AuditModel{
    Id: number = 0;
    Name: string = "";
    IsActive: number = 0;
    OrderNo: number = 0;
}