import { AuditModel } from "./audit_model";

export class EmailTemplateModel extends AuditModel {
  Id: number = 0;
  Name: string = "";
  Subject: string = "";
  Body: string = "";
  WorkflowActionId!: number;
  WorkflowActionName: string = "";
  NotificationType: number = 0;
  OrderNo!: number;
  IsActive: number = 0;
}
