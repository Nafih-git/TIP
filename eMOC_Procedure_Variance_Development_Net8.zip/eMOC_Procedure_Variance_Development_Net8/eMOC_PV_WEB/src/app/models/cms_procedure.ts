import { AuditModel } from "./audit_model";
export class CMSProcedure extends AuditModel {

    ProcedureTitle: string = "";
    ProcedureCode: string = "";
    DisplayName: string = "";
    FunctionalReviewer: string = "";
    TechnicalApprover: string = "";
    Link: string = "";
    FunctionalReviewerFullName: string = "";
    TechnicalApproverFullName: string = "";

}
