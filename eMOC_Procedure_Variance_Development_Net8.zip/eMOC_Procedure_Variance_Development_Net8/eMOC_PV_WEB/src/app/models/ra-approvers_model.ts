import { UserDetailModel } from "./user-detail_model";

export class RAApprovers {

  ApproverRoId: number = 0;
  ApproverRoName: string = '';
  RAApproverUsers: UserDetailModel[] = new Array<UserDetailModel>();
}