import { AuditModel } from "./audit_model";
export class ReasonVarianceModel extends AuditModel {
    Id: number = 0;
    Name: string = "";
    EmocTypeId: number = 0;
    EmocType: string = "";
    IsActive: number = 0;
    OrderNo: number = 0;
}
