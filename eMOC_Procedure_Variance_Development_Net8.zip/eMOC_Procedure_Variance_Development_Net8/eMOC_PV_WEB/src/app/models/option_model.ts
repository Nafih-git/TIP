export class OptionModel {
  DisplayName: string = "";
  Value: string = "";
}
