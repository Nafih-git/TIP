import { AuditModel } from "./audit_model";

export class DocumentsModels extends AuditModel {

  Id: number = 0;
  RequestId: number = 0;
  FileName: string = "";
  Guid: string = "";
  Comment: string = "";
  MimeType: string = "";
  Extension: string = "";
  OrderNo: number = 0;
  UserRoleId: number = 0;
  UserRoleName: string = "";
  File: any = {};
  StatusCode: number = 0;
}
