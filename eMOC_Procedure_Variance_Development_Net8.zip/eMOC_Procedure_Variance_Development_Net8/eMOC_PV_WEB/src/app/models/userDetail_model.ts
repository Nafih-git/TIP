import { AuditModel } from "./audit_model";
import { RolesModel } from "./roles_model";

export class UserDetailModel extends AuditModel {
  PersonalNumber: string="";
  EmployeeName: string="";
  ConcatenatedEmployeeDetails: string = "";
  ReferenceIndicator: string = "";
  EmailAddress: string = "";
  JobDescription: string = "";
  UserRoles: RolesModel[] = [];
  isAddedFromClent: boolean = false;
}
