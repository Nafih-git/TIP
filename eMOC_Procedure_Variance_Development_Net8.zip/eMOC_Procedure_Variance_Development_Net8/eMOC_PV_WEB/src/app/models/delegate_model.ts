import { AuditModel } from "./audit_model";
import { UserManagementDetail } from "./UserManagementDetailModel";

export class DelegateRole extends AuditModel {
  Id: number=0;

  RoleName: string = "";
  RoleCode: string = "";
  RId: number = 0;
  Approvers !: string;
  FromDate !: Date;
  ToDate !: Date;
  ActualUser: string = "";
  BackupUser: string = "";
  ActualUserName: string = "";
  BackupUserName : string = "";
  DelegateRoleList : Array<DelegateRole> = [];
  IsEditable : number = 0;
  Indicator: string = "";
  IsDeleted : number = 0;
}

