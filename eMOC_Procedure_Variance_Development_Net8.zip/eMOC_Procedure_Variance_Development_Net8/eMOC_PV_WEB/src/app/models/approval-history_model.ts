export class ApprovalHistory {

  Id: number = 0;
  RequestId: number = 0;
  RoleName: string | undefined;
  Decision: string | undefined;
  Comments: string | undefined;
  ActionBy: string | undefined;
  ActionByName: string | undefined;
  ActionDate !: Date ;
  RRRatingName: string | undefined ;
  CRRatingName: string | undefined ;
}
