import { AuditModel } from "./audit_model";

export class RolesModel extends AuditModel {
  Id: number=0;
  Name: string="";
  Description: string="";
  Code: string = "";
  IsAsset: any = 0;
  IsDirectorate: any = 0;
  IsSPA: any = 0;
  IsSBA: any = 0;
  OrderNo: number=0;
  IsActive: number = 0;
  IsDelegatedRole : number = 0;
  ISDR : number = 0;

}
