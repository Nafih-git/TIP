export class TaskModel {

  Id: number = 0;
  RequestId: number = 0;
  AssignedTo: string = '';
  AssignedToName: string = '';
  AssignedToRoleId: number = 0;
  AssignedToRole: string = '';
  AssignedDate: Date = new Date();
  SendbackTo: string = '';
  SendbackToName: string = '';
  SendbackToRoleId: number = 0;
  SendbackToRoleName: number = 0;
  Action: string = '';
  ActionDate: Date = new Date();
  Status: number = 0;
  StatusName: string = '';
  LastTaskId: number = 0;
  LastTaskAction: number = 0;
  AddTask: number = 0;
  ActionBy: string = '';
  ActionByName: string = '';
  ActionByRole: string = '';
  IsBackupUser: boolean = false;
  ActionId: number = 0;
  CustomStatus: string = '';
  SendEmail: boolean = false;
  ActionByOtherUser: number = 0;
  DateDifference: string = '';
  AssignedBy: string = '';
  AssignedByName: string = '';
  AssignedByRole: string = '';
  AssetName: string = '';
  ExtensionVersion: number = 0;
  WorkflowActionId: number = 0;
}