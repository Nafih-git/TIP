export class OtherMOCs {
  Facility: string = "";
  POUrl : string = "";
  PORequests : string = "";
  PORequestsList : any[] = [];
  POMessage : string = "";
  AOUrl : string = "";
  AORequests : string = "";
  AORequestsList : any[] = [];
  AOMessage : string = "";  
}
