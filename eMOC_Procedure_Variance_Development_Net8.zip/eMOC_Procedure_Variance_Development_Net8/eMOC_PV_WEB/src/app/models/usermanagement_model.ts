import { AuditModel } from "./audit_model";
import { UserManagementDetail } from "./UserManagementDetailModel";

export class UserManagement extends AuditModel {
  Id: number=0;
  AssetName: string="";
  AssetCode: string = "";
  AssetNameDesc: string = "";
  DirectorateName: string = ""
  DirectorateCode: string = "";
  DirectorateNameDesc: string = "";
  RoleName: string = "";
  RoleCode: string = "";
  RId: number = 0;
  Approvers !: string;
  UserManagementDetailList !: Array<UserManagementDetail>;
}

