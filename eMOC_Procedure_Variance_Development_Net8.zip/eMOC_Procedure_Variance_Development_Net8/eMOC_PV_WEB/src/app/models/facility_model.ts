import { AssetModel } from "./asset_model";

export class FacilityModel extends AssetModel {
    Facility: string = "";
}