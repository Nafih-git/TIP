import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { UserManagementComponent } from './admin/user-management/user-management.component';
import { IndexComponent } from './home/index/index.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { AuthGuardService as AuthGuard } from './utility/service/auth-guard.service';
import { DelegationComponent } from './delegation/delegation.component';

const routes: Routes = [

  { path: "", redirectTo: "index", pathMatch: 'full' },
  { path: "unauthorized", component: UnauthorizedComponent },
  { path: "index", component: IndexComponent },
  { path: 'admin', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule) },
  { path: 'eMOC-request', loadChildren: () => import('./request/request.module').then(m => m.RequestModule) },
  { path: 'help', loadChildren: () => import('./help/help.module').then(m => m.HelpModule) },
  { path: 'reports', loadChildren: () => import('./reports/reports.module').then(m => m.ReportsModule) },
  { path: "RoleDelegation", component: DelegationComponent },
  { path: 'Pendingwith', loadChildren: () => import('./Pending/pending.module').then(m => m.PendingModule) },

];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules, useHash:true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
