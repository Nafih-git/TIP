import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { TaskModel } from 'src/app/models/task_model';
import { HttpService } from 'src/app/utility/http.service';

@Component({
  selector: 'app-task-history',
  templateUrl: './task-history.component.html',
  styleUrls: ['./task-history.component.css']
})
export class TaskHistoryComponent implements OnInit {

  taskList: TaskModel[] = new Array<TaskModel>();
  selectedRow: TaskModel = new TaskModel();
  loading: boolean = false;
  isActive: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  cols: any[] = [
    { field: 'Id', header: 'ID.', width: '50px', isBadge: false, isDate: false, isSorting: true, isFilter: false },
    { field: 'AssignedToName', header: 'Assigned To', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'AssignedToRole', header: 'Assigned To Role', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    //{ field: 'SendbackToName', header: 'Send Back To', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    //{ field: 'SendbackToRoleName', header: 'Send Back To Role', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'AssignedDate', header: 'Assigned Date', width: '100px', isBadge: false, isDate: true, isSorting: true, isFilter: true },
    { field: 'Action', header: 'Action', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'ActionDate', header: 'Action Date', width: '100px', isBadge: false, isDate: true, isSorting: true, isFilter: true },
    { field: 'StatusName', header: 'Task Status', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    //{ field: 'LastTaskAction', header: 'Last Task', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'ActionByName', header: 'Action By', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    //{ field: 'ActionByRole', header: 'Action By Role', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    //{ field: 'AssignedByName', header: 'Assigned By', width: '150px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    //{ field: 'AssignedByRole', header: 'Assigned By Role', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'DateDifference', header: 'Time Taken', width: '100px', isBadge: false, isDate: false, isSorting: false, isFilter: false }
  ];

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  ngOnInit(): void {
  }

  GetAllTasks(requestId: number) {
    this.loading = true;
    this._HttpService.Get("Request/GetTaskHistory", [requestId.toString()]).subscribe(res => {
      this.taskList = res;

      this.taskList.forEach(s => {
        if (s.AssignedDate) s.AssignedDate = new Date(s.AssignedDate);
        if (s.ActionDate) s.ActionDate = new Date(s.ActionDate);
      });

      this.loading = false;
    });
  }

  customFilterCallback(filter: (a: any) => void, value: any): void {
    filter(value);
  }
}
