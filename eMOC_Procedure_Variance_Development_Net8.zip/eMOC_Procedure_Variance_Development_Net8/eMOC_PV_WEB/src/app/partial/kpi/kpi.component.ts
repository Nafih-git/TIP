import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AllRequestFilterForKPIModel } from 'src/app/models/all-request-filter_for_kpi_model';
import { AllRequestModel } from 'src/app/models/all-request_model';
import { AssetModel } from 'src/app/models/asset_model';
import { DirectorateModel } from 'src/app/models/directorate_model';
import { RolesModel } from 'src/app/models/roles_model';
import { CommonFunctions } from 'src/app/utility/common/common-functions';
import { HttpService } from 'src/app/utility/http.service';

@Component({
  selector: 'app-kpi',
  templateUrl: './kpi.component.html',
  styleUrls: ['./kpi.component.css']
})
export class KpiComponent implements OnInit {

  @ViewChild("dataTable") table!: any;
  stopListening = false;
  statusCode : string='E';
  currentchartType : number = 2;
  stackedOptions: any;
  options: any;

  RequestSummary: any;
  RequestSummaryTitle: string = '';
  RequestSummaryType: number = 0;

  allExtensions: any;
  allExtensionsTitle: string = '';
  allExtensionsType: number = 0;

  InapprovalRequest: any;
  InapprovalRequestTitle: string = '';
  InapprovalRequestType: number = 0;

  Implemented: any;
  ImplementedTitle: string = '';
  ImplementedType: number = 0;


  Expired: any;
  ExpiredTitle: string = '';
  ExpiredType: number = 0;

  TotalExpiredRequest: any;
  TotalExpiredRequestTitle: string = '';
  TotalExpiredRequestType: number = 0;
  TotalExpiredRequestChartType: number = 0;


  ClosureExtension: any;
  ClosureExtensionTitle: string = '';
  ClosureExtensionType: number = 0;

  modalTitle: string = 'Request Details';

  displayModal: boolean = false;
  directorates: DirectorateModel[] = new Array<DirectorateModel>();
  assetlist: AssetModel[] = new Array<AssetModel>();
  directorate: string = '';
  asset: string = '';
  allRequestList: AllRequestModel[] = new Array<AllRequestModel>();
  selectedRequestList: AllRequestModel[] = new Array<AllRequestModel>();
  selectedRow: AllRequestModel = new AllRequestModel();
  allRequestFilterForKPIModel: AllRequestFilterForKPIModel = new AllRequestFilterForKPIModel();
  KPISLA: RolesModel[] = new Array<RolesModel>();
  exportColumns: any[] = [];

  cols: any[] = [
    { field: 'Id', header: 'Request No', width: '110px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: true, isExportable: true,IsShow : true },
    { field: 'Indicator', header: 'Indicator', width: '60px', isBadge: false, isIndicator: true, isDate: false, isSorting: false, isFilter: false, isExportable: false,IsShow : true },
    { field: 'CustomStatus', header: 'eMOC Status', width: '250px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: true, isExportable: true,IsShow : true },
    { field: 'PendingWithName', header: 'Pending With', width: '200px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: true, isExportable: true,IsShow : true },
    { field: 'ProcedureDisplayName', header: 'Procedure', width: '150px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: true, isExportable: true,IsShow : true },

    { field: 'Directorate', header: 'Directorate', width: '100px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, isExportable: true,IsShow : true },
    { field: 'Asset', header: 'Asset', width: '100px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, isExportable: true,IsShow : true },
    { field: 'Facility', header: 'Facility', width: '150px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, isExportable: true,IsShow : true },
    { field: 'ReasonVarianceName', header: 'Reason of VarianceName', width: '150px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, isExportable: true,IsShow : true },
    { field: 'IsCMSIntegration', header: 'CMS Procedure', width: '150px', isBadge: true, isIndicator: false, isDate: false, isSorting: false, isFilter: false, isExportable: true ,IsShow : true},

    { field: 'FromDate', header: 'From Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, isExportable: true,IsShow : true },
    { field: 'ToDate', header: 'To Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, isExportable: true ,IsShow : true},
    { field: 'CreatedByName', header: 'Submitted By', width: '150px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: true, isExportable: true,IsShow : true },
    { field: 'CreatedDate', header: 'Submitted Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, isExportable: true,IsShow : true },
  ];

  loading: boolean = false;
  isLoading: boolean = false;

  pieChartData: any;
  pieChartOptions: any;
  pieChartTitle: string = '';
  pieChartType: number = 0;

  chartTypeList: any[] = [];
  yearList: any[] = [];
  monthList: any[] = [];
  quarterList: any[] = [];

  chartType: number | null = 0;
  year: number | null = 0;
  month: number | null = 0;
  quarter: string | null = "";
  constructor(private _HttpService: HttpService, private _rout: Router) {
    this.GetPieChartParams();

  }

  ngOnInit() {
    this.GetDirectorates();
    this.GetKPISLA();
    const textColor = 'black';
    const textColorSecondary = '#9a9a9a';
    const surfaceBorder = '#f2f2f2';
    this.options = {
      maintainAspectRatio: false,
      aspectRatio: 0.8,
      plugins: {
        legend: {
          labels: {
            color: textColor
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: textColorSecondary,
            font: {
              weight: 500
            }
          },
          grid: {
            color: surfaceBorder,
            drawBorder: false
          }
        },
        y: {
          ticks: {
            color: textColorSecondary
          },
          grid: {
            color: surfaceBorder,
            drawBorder: false
          }
        }

      }
    };
    this.stackedOptions = {

      tooltips: {

        mode: 'index',
        intersect: true
      },
      scales: {

          x: { stacked: true },
          y: { stacked: true }
      },
      responsive: true,
    };

    this.exportColumns = this.cols.map(col => ({ title: col.header, dataKey: col.field }));

    this.LoadKpi();

  }

  async GetDirectorates() {
    return new Promise(resolve => {
      this._HttpService.GetAll("Master/GetDirectorates").subscribe(res => {

        this.directorates = res;
        resolve("Success");
      });
    });
  }


  async GetKPISLA() {
    return new Promise(resolve => {
      this._HttpService.GetAll("Master/GetKPISLA").subscribe(res => {
        this.KPISLA = res;
        resolve("Success");
      });
    });
  }


  GetAsset() {
    this.asset = '';
    return new Promise(resolve => {
      this._HttpService.Get1("Master/GetAssets", { Directorate: this.directorate }).subscribe(res => {
        this.assetlist = res;

        resolve("Success");
      });
    });
  }


  LoadKpi() {
    this.GetTotalExpiredKPI();
    this.isLoading = true;
    let filter: any = {};
    filter.Directorate = this.directorate;
    filter.Asset = this.asset;
    this._HttpService.Get1("Request/GetDashboardCharts", { FilterString: JSON.stringify(filter) }).subscribe(res => {



      this.InapprovalRequest = JSON.parse(res.Table[0].ChartData);
      this.InapprovalRequestTitle = res.Table[0].ChartTitle;
      this.InapprovalRequestType = res.Table[0].ChartType;


      this.RequestSummary = JSON.parse(res.Table1[0].ChartData);
      this.RequestSummaryTitle = res.Table1[0].ChartTitle;
      this.RequestSummaryType = res.Table1[0].ChartType;



      // this.Implemented = JSON.parse(res.Table2[0].ChartData);
      // this.ImplementedTitle = res.Table2[0].ChartTitle;
      // this.ImplementedType = res.Table2[0].ChartType;



      // this.Expired = JSON.parse(res.Table3[0].ChartData);
      // this.ExpiredTitle = res.Table3[0].ChartTitle;
      // this.ExpiredType = res.Table3[0].ChartType;



      this.ClosureExtension = JSON.parse(res.Table2[0].ChartData);
      this.ClosureExtensionTitle = res.Table2[0].ChartTitle;
      this.ClosureExtensionType = res.Table2[0].ChartType;

      this.isLoading = false;
    });
  }


  GetTotalExpiredKPI() {
    this.isLoading = true;
    let filter: any = {};
    filter.Directorate = this.directorate;
    filter.Asset = this.asset;
    filter.FOR_LANDING = 0;
    this._HttpService.Get1("Request/GetTotalExpiredKPI", { FilterString: JSON.stringify(filter) }).subscribe(res => {
      this.TotalExpiredRequest = JSON.parse(res.Table[0].ChartData);
      this.TotalExpiredRequestTitle = res.Table[0].ChartTitle;
      this.TotalExpiredRequestType = res.Table[0].Chart;
      this.TotalExpiredRequestChartType = res.Table[0].ChartType;
      this.isLoading = false;
    });
  }


  Close() {

    this.displayModal = false;
    this.allRequestList = new Array<AllRequestModel>();
  }

  OnFilter(event: any) {

    this.selectedRequestList = event.filteredValue;
  }

  CustomFilterCallback(filter: (a: any) => void, value: any): void {

    filter(value);
  }

  ViewRequest(rowDate: AllRequestModel) {

    CommonFunctions.GetEditRequestPageInNewTab(rowDate.Id);
  }

  GetData(event: any, chartType: number) {
this.currentchartType = chartType;
    switch (chartType) {
      case this.RequestSummaryType: {
        this.modalTitle = this.RequestSummaryTitle;
        this.statusCode = this.RequestSummary.datasets[event.element.datasetIndex].statusCode;
        this.GetAllRequests(chartType, this.RequestSummary.codes[event.element.index], this.statusCode);
        break
      }
      case this.InapprovalRequestType: {
        this.modalTitle = this.InapprovalRequestTitle;
        this.statusCode = this.InapprovalRequest.datasets[event.element.datasetIndex].statusCode;

        this.GetAllRequests(chartType, this.InapprovalRequest.codes[event.element.index], this.statusCode);
        break
      }
      case this.ImplementedType: {
        this.modalTitle = this.ImplementedTitle;
        break
      }
      case this.ExpiredType: {
        this.modalTitle = this.ExpiredTitle;
        break
      }
      case this.ClosureExtensionType: {
        this.modalTitle = this.ClosureExtensionTitle;
        this.statusCode = this.ClosureExtension.datasets[event.element.datasetIndex].statusCode;

        this.GetAllRequests(chartType, this.ClosureExtension.codes[event.element.index], this.statusCode);
        break
      }
      case this.TotalExpiredRequestType: {
        this.modalTitle = this.TotalExpiredRequestTitle;
        this.statusCode = this.TotalExpiredRequest.datasets[event.element.datasetIndex].statusCode;
        this.GetAllRequests(2, this.TotalExpiredRequest.codes[event.element.index], this.statusCode);
        break
      }

    }
  }

  GetAllRequests(chartType: number, assetCode: string, statusCode: string) {

    this.displayModal = true;
    this.loading = true;


    let filter: any = {};
    filter.ChartType = chartType;
    filter.Directorate = this.directorate ? this.directorate : assetCode;
    filter.Asset = this.directorate ? (this.asset ? this.asset : assetCode ) : '';
    filter.Facility = this.asset ? assetCode : '';
    filter.Stage = statusCode;

    if (chartType == 4) {
      var date = this.getDate();
      filter.StartDate = date.from;
      filter.EndDate = date.to;
    }

    this.allRequestFilterForKPIModel.FullRecords = 1;
    this.allRequestFilterForKPIModel.RequestFilter = JSON.stringify(filter);

    this.allRequestList = new Array<AllRequestModel>();
    this.selectedRequestList = new Array<AllRequestModel>();
    this._HttpService.Get1('Request/GetAllRequests', { FilterString: JSON.stringify(this.allRequestFilterForKPIModel) }).subscribe(res => {

      if(res) {

        this.allRequestList = res;
        this.selectedRequestList = res;

        if(this.allRequestList.length > 0) {

          this.allRequestList.forEach(s => {

            if (s.CreatedDate) s.CreatedDate = new Date(s.CreatedDate);
            if (s.ModifiedDate) s.ModifiedDate = new Date(s.ModifiedDate);
          });
        }
      }

      this.loading = false;
    });
  }

  ExportExcel() {

     CommonFunctions.ExportExcel(this.cols, this.selectedRequestList, 'kpi Details');
  }

  ExportCSV() {

    this.table.exportCSV();
  }


  GetPieChartParams() {
    let defaultValue = (arr: any[], key = 'default') => {
      return arr?.find(s => s[key] == 1).value;
    }
    this.isLoading = true;

    this._HttpService.Get("Request/GetPieChartParams", []).subscribe(res => {
   
      this.chartTypeList = res[0]
      this.yearList = res[1];
      this.monthList = res[2];
      setTimeout(() => {
        this.chartType = defaultValue(this.chartTypeList);
        this.year = defaultValue(this.yearList);
        this.month = defaultValue(this.monthList);
        this.GetPieChartByStatus();
      }, 1000)
       
    
      this.isLoading = false;
    });
  }


  GetQuarterBasedOnyear() {

    this.isLoading = true;

    this._HttpService.Get1("Request/GetQuarterBasedOnyear", {year: this.year ? this.year.toString() : "" }).subscribe(res => {
      this.quarterList = res[0];

      this.isLoading = false;
    });
  }

  getDate() {

    var fromDate = null;
    var toDate = null;
    let year: number = this.year ? this.year : 0;
    let month: number = this.month ? this.month : 0;
    let fromDTS = "";
    let toDTS = "";

    switch (this.chartType) {
      case 1: {
        fromDate = new Date(year, 0, 1);
        toDate = new Date(year, 11, 31);
        break;
      }
      case 2: {
        var date = new Date(year, month - 1, 1)
        fromDate = new Date(date.getFullYear(), date.getMonth(), 1);
        toDate = new Date(date.getFullYear(), date.getMonth() + 1, 0);
        break;
      }
      case 3: {
        var datelist = this.quarter ? this.quarter.split("#") : [];
        if (datelist.length > 0) {
          fromDate = new Date(datelist[0]);
          toDate = new Date(datelist[1]);
        }
        break;
      }
      default: {
        fromDate = null;
        toDate = null;
      }
    }
    if (fromDate && toDate) {
      fromDTS = fromDate.toLocaleDateString();
      toDTS = toDate.toLocaleDateString();
    } else {
      fromDTS = '';
      toDTS = '';

    }
    return { from: fromDTS, to: toDTS }
  }


  GetPieChartByStatus() {
    this.isLoading = true;
    let filter: any = {};
    filter.Directorate = this.directorate;
    filter.Asset = this.asset;
    var date = this.getDate();
    filter.StartDate = date.from;
    filter.EndDate = date.to;
    this._HttpService.Get1("Request/GetPieChartByStatus", { FilterString: JSON.stringify(filter) }).subscribe(res => {
      this.pieChartData = JSON.parse(res[0][0].ChartData);
      this.pieChartTitle = res[0][0].ChartTitle;
      this.pieChartType = res[0][0].ChartType;
      this.isLoading = false;
    });
  }

  resetPIEChartParams() {
    this.year = null;
    this.month = null;
    this.quarter = null;
    this.chartType = this.chartType == null ? 0 : this.chartType;
    if (this.chartType == 0)
      this.GetPieChartByStatus();
  }

  yearChange() {
    if (!(this.year && this.year > 0)) {
      this.chartType = 0;
      this.resetPIEChartParams();
      this.GetPieChartByStatus()
    }
    if (this.chartType == 1) this.GetPieChartByStatus();
    else if (this.chartType == 3) this.GetQuarterBasedOnyear();
    else {
      this.month = null;
      this.quarter = null;
    }
  }

  getPIEChartData(event: any) {
    this.modalTitle = this.pieChartTitle;
    this.GetAllRequests(this.pieChartType, '', this.pieChartData.codes[event.element.index]);

  }

  quarterChange() {
    if (this.quarter)
      this.GetPieChartByStatus()
    else {
      this.chartType = 1;
      this.GetPieChartByStatus();
    }
  }
  monthChange() {
    if (this.month)
      this.GetPieChartByStatus()
    else {
      this.chartType = 1;
      this.GetPieChartByStatus();
    }
  }


  // SelectAllRequest(event: any, chartType: number) {

  //   this.modalTitle = this.allRequestTitle;

  //   let requestFilter = JSON.parse(this.allRequestFilterModel.RequestFilter);

  //   if(requestFilter.Asset.trim() == "") {

  //     requestFilter.Asset = this.allRequest.codes[event.element.index];
  //   }
  //   else {

  //     requestFilter.Facility = this.allRequest.codes[event.element.index];
  //   }

  //   requestFilter.ChartType = chartType;

  //   let arf: AllRequestFilterModel = new AllRequestFilterModel();

  //   arf.FullRecords = 1;
  //   arf.RequestFilter = JSON.stringify(requestFilter);

  //   this.GetAllRequests(arf);
  // }

  // SelectSofApproved(event: any, chartType: number) {

  //   this.modalTitle = this.sofApprovedTitle;

  //   let requestFilter = JSON.parse(this.allRequestFilterModel.RequestFilter);

  //   if(requestFilter.Asset.trim() == "") {

  //     requestFilter.Asset = this.sofApproved.codes[event.element.index];
  //   }
  //   else {

  //     requestFilter.Facility = this.sofApproved.codes[event.element.index];
  //   }

  //   requestFilter.ChartType = chartType;

  //   let arf: AllRequestFilterModel = new AllRequestFilterModel();

  //   arf.FullRecords = 1;
  //   arf.RequestFilter = JSON.stringify(requestFilter);

  //   this.GetAllRequests(arf);
  // }

  // SelectSofWithPim(event: any, chartType: number) {

  //   this.modalTitle = this.sofWithPimTitle;

  //   let requestFilter = JSON.parse(this.allRequestFilterModel.RequestFilter);

  //   if(requestFilter.Asset.trim() == "") {

  //     requestFilter.Asset = this.sofWithPim.codes[event.element.index];
  //   }
  //   else {

  //     requestFilter.Facility = this.sofWithPim.codes[event.element.index];
  //   }

  //   requestFilter.ChartType = chartType;

  //   let arf: AllRequestFilterModel = new AllRequestFilterModel();

  //   arf.FullRecords = 1;
  //   arf.RequestFilter = JSON.stringify(requestFilter);

  //   this.GetAllRequests(arf);
  // }


  customFilterCallback(filter: (a: any) => void, value: any): void {
    this.stopListening = true;
    filter(value);
    this.stopListening = false;
  }

  statuses: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];
}



