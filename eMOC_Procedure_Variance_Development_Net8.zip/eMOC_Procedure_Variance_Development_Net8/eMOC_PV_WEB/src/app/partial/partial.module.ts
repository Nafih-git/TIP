import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskHistoryComponent } from './task-history/task-history.component';
import { ApprovalHistoryComponent } from './approval-history/approval-history.component';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { ChartModule } from 'primeng/chart';
import { FormsModule } from '@angular/forms';
import { KpiComponent } from './kpi/kpi.component';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { LoadingSpinnerModule } from '../utility/directive/loading-spinner/loading-spinner.module';
import { TooltipModule } from 'primeng/tooltip';
import { ExtensionHistoryComponent } from './extension-history/extension-history.component';

@NgModule({
  declarations: [
    TaskHistoryComponent,
    ApprovalHistoryComponent,
    KpiComponent,
    ExtensionHistoryComponent
  ],
  exports: [
    TaskHistoryComponent,
    ApprovalHistoryComponent,
    KpiComponent,
    ExtensionHistoryComponent
  ],
  imports: [
    CommonModule,
    TableModule,
    DropdownModule,
    FormsModule,
    ChartModule,
    DialogModule,
    ButtonModule,
    LoadingSpinnerModule,
    TooltipModule
  ]
})
export class PartialModule { }
