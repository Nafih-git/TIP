import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { ApprovalHistory } from 'src/app/models/approval-history_model';
import { HttpService } from 'src/app/utility/http.service';
import { CommonFunctions } from '../../utility/common/common-functions';

@Component({
  selector: 'app-approval-history',
  templateUrl: './approval-history.component.html',
  styleUrls: ['./approval-history.component.css']
})
export class ApprovalHistoryComponent implements OnInit {

  approvalHistoryList: ApprovalHistory[] = new Array<ApprovalHistory>();
  selectedRow: ApprovalHistory = new ApprovalHistory();
  rows: number = 5;
  loading: boolean = false;
  isActive: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  cols: any[] = [
    { field: 'Id', header: 'History ID.', width: '50px', isBadge: false, isDate: false, isSorting: true, isFilter: false },
    { field: 'RoleName', header: 'Role', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'ActionByName', header: 'Action By', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'ActionDate', header: 'Action Date', width: '100px', isBadge: false, isDate: true, isSorting: true, isFilter: true },
    { field: 'Decision', header: 'Decision', width: '250px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'Comments', header: 'Comments', width: '250px', isBadge: false, isDate: false, isSorting: true, isFilter: true },

  ];

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  ngOnInit(): void {
  }

  GetApprovalHistory(requestId: number, rows: number) {
    this.loading = true;
    this.rows = rows;
    this._HttpService.GetAll(`Request/GetApprovalHistoryByRequestId/${requestId}`).subscribe(res => {
      this.approvalHistoryList = res;
      this.loading = false;
    });
  }

  CustomFilterCallback(filter: (a: any) => void, value: any): void {

    filter(value);
  }

  ViewRequestHistoryDetail(rowdata: any) {

    CommonFunctions.GetRequestHistoryPageInNewTab(rowdata.Id);
  }
}
