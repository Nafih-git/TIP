import { Component, Input, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { RequestExtension } from 'src/app/models/request-extension_model';
import { RequestExtensionModel } from 'src/app/models/request_Extension_model';
import { RequestModel } from 'src/app/models/request_model';
import { HttpService } from 'src/app/utility/http.service';

@Component({
  selector: 'app-extension-history',
  templateUrl: './extension-history.component.html',
  styleUrls: ['./extension-history.component.css']
})
export class ExtensionHistoryComponent implements OnInit {
  @Input("request") request: RequestModel = new RequestModel();
  extensionHistoryList: RequestExtensionModel[] = new Array<RequestExtensionModel>();
  selectedRow: RequestExtension = new RequestExtension();
  loading: boolean = false;
  isActive: any[] = [
    { label: 'NO', value: 0 },
    { label: 'YES', value: 1 },
  ];

  cols: any[] = [
    { field: 'ExtensionVersion', header: 'Extension Version', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'EffectiveFromDate', header: 'Effective From', width: '100px', isBadge: false, isDate: true, isSorting: true, isFilter: true },
    { field: 'EffectiveToDate', header: 'Effective To', width: '100px', isBadge: false, isDate: true, isSorting: true, isFilter: true },
    { field: 'TechnicalApproverName', header: 'Technical Approver', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'EndorserName', header: 'Endorser', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'AuthorizerName', header: 'Authorizer', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'ImplementerName', header: 'Implementer', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'StatusName', header: 'Status', width: '100px', isBadge: false, isDate: false, isSorting: true, isFilter: true },
    { field: 'StatusDate', header: 'Status Date', width: '100px', isBadge: false, isDate: true, isSorting: true, isFilter: true },

  ];

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  ngOnInit(): void {

  }

  GetExtensionHistory(requestId: number) {

this.loading = true;

this._HttpService.Get("Request/GetExtensionHistoryByRequestId",[requestId.toString()]).subscribe(res => {

  this.extensionHistoryList = res;
  if(this.extensionHistoryList.length > 0) {
    this.extensionHistoryList.forEach(s => {

      if (s.EffectiveFromDate) s.EffectiveFromDate = new Date(s.EffectiveFromDate);
      if (s.EffectiveToDate) s.EffectiveToDate = new Date(s.EffectiveToDate);
      if (s.StatusDate) s.StatusDate = new Date(s.StatusDate);
    });
  }

  this.loading = false;
});
}


  CustomFilterCallback(filter: (a: any) => void, value: any): void {

    filter(value);
  }
}
