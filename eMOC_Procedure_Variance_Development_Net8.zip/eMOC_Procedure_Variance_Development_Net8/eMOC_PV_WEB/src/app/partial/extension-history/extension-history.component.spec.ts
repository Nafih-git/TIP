import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExtensionHistoryComponent } from './extension-history.component';

describe('ExtensionHistoryComponent', () => {
  let component: ExtensionHistoryComponent;
  let fixture: ComponentFixture<ExtensionHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExtensionHistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExtensionHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
