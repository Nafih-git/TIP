import { Component } from "@angular/core";

@Component({
  selector: 'app-loaded',
  template: `<div class="d-flex justify-content-center">
  <div class="spinner-border" role="status" >
    <span class="sr-only" id="loading"></span>
  </div>
</div>`,
  styles: [`#loading{
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  animation: spin 2s linear infinite;
  }

  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }`]
})
export class SpinnerComponent {

  constructor() {
  }

}
