import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { HttpService } from '../../utility/http.service';
import { CommonFunctions } from '../../utility/common/common-functions';
import { LoggedUserService } from 'src/app/utility/service/logged-user.service';


@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent implements OnInit, OnDestroy {

  constructor(private _router: Router, private _HttpService: HttpService, public _logUserSvc: LoggedUserService) {
    this.GetUserMenu();
  }
  BaseURL = CommonFunctions.GetLandingPage();
  CurrentPageURL: string = "";
  event$: any
  menulist: any[] = [];
  staticText: any;

  ngOnDestroy() {
    this.event$.unsubscribe();
  }

  ngOnInit(): void {
    this.GetStaticText();
    this.event$ =
      this._router.events
        .subscribe(
          (event: NavigationEvent) => {
            if (event instanceof NavigationStart) {
              this.CurrentPageURL = event.url;
              this.highlightMenu(event.url, this.menulist);
            }
          });
  }

  async GetStaticText() {

    this._HttpService.GetStaticText().subscribe(res => {
      this.staticText = res;

    });
  }


  GetUserMenu() {
    this._HttpService.GetAll('Common/GetDynamicMenu').subscribe(res => {
      if (res != undefined || res != null) {
        this.menulist = res?.NavigationMenu;
        this.highlightMenuOnDataload(this.menulist);
      }
    });
  }

  highlightMenu(url: string, menulist: any[], masterMenu: any = {}) {
    menulist.forEach(m => {
      m.ScreensList.forEach((s: { URL: string; IsActive: boolean }) => {
        if (s.URL == url) {
          s.IsActive = true;
          if (masterMenu) masterMenu.IsActive = true;
        }
      });
    });
  }

  highlightMenuOnDataload(menulist: any[]) {
    for (var i = 0; i < menulist.length; i++) {
      for (var j = 0; j < menulist[i].ScreensList.length; j++) {
        if (this.CurrentPageURL.includes(menulist[i].ScreensList[j].URL) || (this.CurrentPageURL == "/" && this.BaseURL == menulist[i].ScreensList[j].URL)) {
          menulist[i].IsActive = true;
          break;
        }
        else {
          menulist[i].IsActive = false;
        }
      }
    }
  }

  menuClick(menu: any) {
    menu.IsActive = true;
  }

  resetMenu(menulist: any[]) {
    menulist.forEach(s => {
      s.IsActive = false;
      if (s.ScreensList && s.ScreensList.length > 0) { this.resetMenu(s.ScreensList); }
    });
  }
}
