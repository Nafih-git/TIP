import { Component, OnInit } from '@angular/core';
import { HttpService } from '../../utility/http.service';
import { CommonFunctions } from '../../utility/common/common-functions';
import { LoggedUserService } from '../../utility/service/logged-user.service';

@Component({
  selector: 'app-topnav',
  templateUrl: './topnav.component.html',
  styleUrls: ['./topnav.component.css']
})
export class TopnavComponent implements OnInit {

  constructor(private _HttpService: HttpService, private _loggedUserService: LoggedUserService) { }
  user: any = {};
  ngOnInit(): void {
    this.getUerDetails();

  }
  getUerDetails() {

    this._HttpService.Get("Common/GetWinAuthAccount", []).subscribe(res => {
      this.user = res;
      this._loggedUserService.loggedUser = res;
      console.log( this._loggedUserService.loggedUser);
    })
  }

  getUerRoles() {
    return  CommonFunctions.ConcateUserRoles(this.user.UserRoles);
  }
  getUserName() {

    return CommonFunctions.GetLoggedInUserName();
  }


}
