import { ChangeDetectorRef, Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ConfirmationService, ConfirmEventType, MessageService } from 'primeng/api';
import { RiskAssessmentModel } from '../../models/risk-assessment_model';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { HttpService } from '../../utility/http.service';
import { CommonFunctions } from '../../utility/common/common-functions';
import { RequestModel } from 'src/app/models/request_model';
import { RequestExtensionModel } from 'src/app/models/request_Extension_model';

@Component({
  selector: 'app-risk-assessment',
  templateUrl: './risk-assessment.component.html',
  styleUrls: ['./risk-assessment.component.css']
})
export class RiskAssessmentComponent implements OnInit {

  constructor(private _HttpService: HttpService,private cdr: ChangeDetectorRef, private confirmationService: ConfirmationService, private messageService: MessageService) { }
  Riskassesments: RiskAssessmentModel[] = new Array<RiskAssessmentModel>();

  CopyRiskassesmentsList: RiskAssessmentModel[] = new Array<RiskAssessmentModel>();
  ToBeDeletedElementType: string = "";
  ToBeDeletedActivityIndex!: number;
  filteredCountries: any[] = [];
  controlTypelist: any[] = [];
  frequencyTypelist: any[] = [];
  userSearchSubscribe: any;
  CopyRequestSearchSubscribe: any;
  userDetails: any;
  CopyRequestList: any;
  CopyRA = false;
  copyrequestno: any;
  DisabledRAMatrixForEditing = false;
  @Input("request") request: RequestModel = new RequestModel();
  @ViewChild('riskAssessment', { static: false }) el!: ElementRef;

  //This line is only applicable for Organizational Change Project (Created by Roomi)
  @Output("ShowRAApprover") ShowRAApprover: EventEmitter<any> = new EventEmitter();

  DisbaledRAMatrix(CurrentStepId : number , WorkflowId : number, Extension : RequestExtensionModel){

    console.log(Extension);
if(Extension ){

  this.DisabledRAMatrixForEditing = true;
}
else{


  if(CurrentStepId > 4) {
    this.DisabledRAMatrixForEditing = true;
  }
  else{
    this.DisabledRAMatrixForEditing = false;

  }

}


  }

  makePdf() {
    html2canvas(this.el.nativeElement, { scale: 3 }).then((canvas) => {
      const imageGeneratedFromTemplate = canvas.toDataURL('image/png');
      const fileWidth = 200;
      const generatedImageHeight = (canvas.height * fileWidth) / canvas.width;
      let PDF = new jsPDF('p', 'mm', 'a4',);
      PDF.addImage(imageGeneratedFromTemplate, 'PNG', 0, 5, fileWidth, generatedImageHeight,);
      PDF.html(this.el.nativeElement.innerHTML)
      PDF.save('Risk Assessment - ' + new Date().toLocaleDateString() + '.pdf');
    });
  }

  ngOnInit(): void {
    this.generateActivity();
    this.GetActiveRAControlOwnerRole();
    this.GetActiveRAControlType();
    this.GetFrequenctType();
    // this.DisabledRAMatrixForEditing = this.DisbaledRAMatrix();
    // alert(this.DisabledRAMatrixForEditing);
  }
  generateActivity() {
    this.IndicatorUI = [
      {
        Indicatorname: "A0", Indicatorclass: "RACatIndicator1", Indicatorseverity: 1,
        IndicatorGuideline: 0,
        IndicatorPeopleDescription: 'No injury or health effect',
        IndicatorAssetDescription: '<b>No damage</b>',
        IndicatorEnvironmentDescription: '<b>No effect</b>',
        IndicatorReputationDescription: '<b>No impact</b>',
        Risk: 'Low',
        Residual_Risk_Id: 1
      },
      {
        Indicatorname: "B0", Indicatorclass: "RACatIndicator1", Indicatorseverity: 2,
        IndicatorGuideline: 0,
        IndicatorPeopleDescription: 'No injury or health effect',
        IndicatorAssetDescription: '<b>No damage</b>',
        IndicatorEnvironmentDescription: '<b>No effect</b>',
        IndicatorReputationDescription: '<b>No impact</b>',
        Risk: 'Low',
        Residual_Risk_Id: 1
      },
      {
        Indicatorname: "C0", Indicatorclass: "RACatIndicator1", Indicatorseverity: 3,
        IndicatorGuideline: 0,
        IndicatorPeopleDescription: 'No injury or health effect',
        IndicatorAssetDescription: '<b>No damage</b>',
        IndicatorEnvironmentDescription: '<b>No effect</b>',
        IndicatorReputationDescription: '<b>No impact</b>',
        Risk: 'Low',
        Residual_Risk_Id: 1
      },
      {
        Indicatorname: "D0", Indicatorclass: "RACatIndicator1", Indicatorseverity: 4,
        IndicatorGuideline: 0,
        IndicatorPeopleDescription: 'No injury or health effect',
        IndicatorAssetDescription: '<b>No damage</b>',
        IndicatorEnvironmentDescription: '<b>No effect</b>',
        IndicatorReputationDescription: '<b>No impact</b>',
        Risk: 'Low',
        Residual_Risk_Id: 1
      },
      {
        Indicatorname: "E0", Indicatorclass: "RACatIndicator1", Indicatorseverity: 5,
        IndicatorGuideline: 0,
        IndicatorPeopleDescription: 'No injury or health effect',
        IndicatorAssetDescription: '<b>No damage</b>',
        IndicatorEnvironmentDescription: '<b>No effect</b>',
        IndicatorReputationDescription: '<b>No impact</b>',
        Risk: 'Low',
        Residual_Risk_Id: 1
      },
      {
        Indicatorname: "A1", Indicatorclass: "RACatIndicator1", Indicatorseverity: 6,
        IndicatorGuideline: 1,
        IndicatorPeopleDescription: '<b>Slight injury or health effect</b> Not affecting work performance and not affecting daily life activities. Examples:<ul><li>First aid cases and medical treatment cases</li><li>Exposure to health hazards that give rise to noticeable discomfort, minor irritation or transient effects reversible after exposure stops </li></ul>',
        IndicatorAssetDescription: '<b>Slight damage</b> Costs less than 10,000 US$. Example:<ul><li>No disruption to operation</li></ul>',
        IndicatorEnvironmentDescription: '<b>Slight effect</b> <br />Slight environmental damage  contained within the premises. Example:<ul><li>Small spill in process area or tank farm area that readily evaporates</li></ul>',
        IndicatorReputationDescription: '<b>Slight impact</b><ul><li>Local public awareness but no discernible concern</li><li>No media coverage</li></ul>',
        Risk: 'Low',
        Residual_Risk_Id: 1
      },
      {
        Indicatorname: "B1", Indicatorclass: "RACatIndicator1", Indicatorseverity: 7,
        IndicatorGuideline: 1,
        IndicatorPeopleDescription: '<b>Slight injury or health effect</b> Not affecting work performance and not affecting daily life activities. Examples:<ul><li>First aid cases and medical treatment cases</li><li>Exposure to health hazards that give rise to noticeable discomfort, minor irritation or transient effects reversible after exposure stops </li></ul>',
        IndicatorAssetDescription: '<b>Slight damage</b> Costs less than 10,000 US$. Example:<ul><li>No disruption to operation</li></ul>',
        IndicatorEnvironmentDescription: '<b>Slight effect</b> <br />Slight environmental damage  contained within the premises. Example:<ul><li>Small spill in process area or tank farm area that readily evaporates</li></ul>',
        IndicatorReputationDescription: '<b>Slight impact</b><ul><li>Local public awareness but no discernible concern</li><li>No media coverage</li></ul>',
        Risk: 'Low',
        Residual_Risk_Id: 1
      },
      {
        Indicatorname: "C1", Indicatorclass: "RACatIndicator2", Indicatorseverity: 9,
        IndicatorGuideline: 1,
        IndicatorPeopleDescription: '<b>Slight injury or health effect</b> Not affecting work performance and not affecting daily life activities. Examples:<ul><li>First aid cases and medical treatment cases</li><li>Exposure to health hazards that give rise to noticeable discomfort, minor irritation or transient effects reversible after exposure stops </li></ul>',
        IndicatorAssetDescription: '<b>Slight damage</b> Costs less than 10,000 US$. Example:<ul><li>No disruption to operation</li></ul>',
        IndicatorEnvironmentDescription: '<b>Slight effect</b> <br />Slight environmental damage  contained within the premises. Example:<ul><li>Small spill in process area or tank farm area that readily evaporates</li></ul>',
        IndicatorReputationDescription: '<b>Slight impact</b><ul><li>Local public awareness but no discernible concern</li><li>No media coverage</li></ul>',
        Risk: 'Medium',
        Residual_Risk_Id: 2

      },
      {
        Indicatorname: "D1", Indicatorclass: "RACatIndicator2", Indicatorseverity: 10,
        IndicatorGuideline: 1,
        IndicatorPeopleDescription: '<b>Slight injury or health effect</b> Not affecting work performance and not affecting daily life activities. Examples:<ul><li>First aid cases and medical treatment cases</li><li>Exposure to health hazards that give rise to noticeable discomfort, minor irritation or transient effects reversible after exposure stops </li></ul>',
        IndicatorAssetDescription: '<b>Slight damage</b> Costs less than 10,000 US$. Example:<ul><li>No disruption to operation</li></ul>',
        IndicatorEnvironmentDescription: '<b>Slight effect</b> <br />Slight environmental damage  contained within the premises. Example:<ul><li>Small spill in process area or tank farm area that readily evaporates</li></ul>',
        IndicatorReputationDescription: '<b>Slight impact</b><ul><li>Local public awareness but no discernible concern</li><li>No media coverage</li></ul>',
        Risk: 'Medium',
        Residual_Risk_Id: 2
      },
      {
        Indicatorname: "E1", Indicatorclass: "RACatIndicator2", Indicatorseverity: 11,
        IndicatorGuideline: 1,
        IndicatorPeopleDescription: '<b>Slight injury or health effect</b> Not affecting work performance and not affecting daily life activities. Examples:<ul><li>First aid cases and medical treatment cases</li><li>Exposure to health hazards that give rise to noticeable discomfort, minor irritation or transient effects reversible after exposure stops </li></ul>',
        IndicatorAssetDescription: '<b>Slight damage</b> Costs less than 10,000 US$. Example:<ul><li>No disruption to operation</li></ul>',
        IndicatorEnvironmentDescription: '<b>Slight effect</b> <br />Slight environmental damage  contained within the premises. Example:<ul><li>Small spill in process area or tank farm area that readily evaporates</li></ul>',
        IndicatorReputationDescription: '<b>Slight impact</b><ul><li>Local public awareness but no discernible concern</li><li>No media coverage</li></ul>',
        Risk: 'Medium',
        Residual_Risk_Id: 2
      },
      {
        Indicatorname: "A2", Indicatorclass: "RACatIndicator1", Indicatorseverity: 8,
        IndicatorGuideline: 2,
        IndicatorPeopleDescription: '<b>Minor injury or health effect</b> Affecting work performance, such as restriction to activities or need to take up to 5 days to fully recover. Or affecting daily life activities for up to 5 days. Or reversible health effects. Examples:<ul><li>Restricted work day cases or lost work day cases resulting in up to 5 calendar days away from work</li><li>Illnesses such as skin irritation or food poisoning.</li></ul>',
        IndicatorAssetDescription: '<b>Minor damage</b> Costs between 10,000 and 100,000 US$. Example:<ul><li>Brief disruption to operation</li></ul>',
        IndicatorEnvironmentDescription: '<b>Minor effect</b><br />Minor environmental damage, but no lasting effect. Examples:<ul><li>Small spill off-site that seeps into the ground</li><li>On-site groundwater contamination</li><li>Complaints from neighbours,</li><li>Single  of statutory or other prescribed limit</li></ul>',
        IndicatorReputationDescription: '<b>Minor impact</b><ul><li>Local public concern</li><li>Local media coverage</li></ul>',
        Risk: 'Low',
        Residual_Risk_Id: 1
      },
      {
        Indicatorname: "B2", Indicatorclass: "RACatIndicator2", Indicatorseverity: 12,
        IndicatorGuideline: 2,
        IndicatorPeopleDescription: '<b>Minor injury or health effect</b>  Affecting work performance, such as restriction to activities or need to take up to 5 days to fully recover. Or affecting daily life activities for up to 5 days. Or reversible health effects. Examples:<ul><li>Restricted work day cases or lost work day cases resulting in up to 5 calendar days away from work</li><li>Illnesses such as skin irritation or food poisoning.</li></ul>',
        IndicatorAssetDescription: '<b>Minor damage</b> Costs between 10,000 and 100,000 US$. Example:<ul><li>Brief disruption to operation</li></ul>',
        IndicatorEnvironmentDescription: '<b>Minor effect</b><br />Minor environmental damage, but no lasting effect. Examples:<ul><li>Small spill off-site that seeps into the ground</li><li>On-site groundwater contamination</li><li>Complaints from neighbours,</li><li>Single  of statutory or other prescribed limit</li></ul>',
        IndicatorReputationDescription: '<b>Minor impact</b><ul><li>Local public concern</li><li>Local media coverage</li></ul>',
        Risk: 'Medium',
        Residual_Risk_Id: 2
      },
      {
        Indicatorname: "C2", Indicatorclass: "RACatIndicator2", Indicatorseverity: 13,
        IndicatorGuideline: 2,
        IndicatorPeopleDescription: '<b>Minor injury or health effect</b>  Affecting work performance, such as restriction to activities or need to take up to 5 days to fully recover. Or affecting daily life activities for up to 5 days. Or reversible health effects. Examples:<ul><li>Restricted work day cases or lost work day cases resulting in up to 5 calendar days away from work</li><li>Illnesses such as skin irritation or food poisoning.</li></ul>',
        IndicatorAssetDescription: '<b>Minor damage</b> Costs between 10,000 and 100,000 US$. Example:<ul><li>Brief disruption to operation</li></ul>',
        IndicatorEnvironmentDescription: '<b>Minor effect</b><br />Minor environmental damage, but no lasting effect. Examples:<ul><li>Small spill off-site that seeps into the ground</li><li>On-site groundwater contamination</li><li>Complaints from neighbours,</li><li>Single  of statutory or other prescribed limit</li></ul>',
        IndicatorReputationDescription: '<b>Minor impact</b><ul><li>Local public concern</li><li>Local media coverage</li></ul>',
        Risk: 'Medium',
        Residual_Risk_Id: 2
      },
      {
        Indicatorname: "D2", Indicatorclass: "RACatIndicator3", Indicatorseverity: 17,
        IndicatorGuideline: 2,
        IndicatorPeopleDescription: '<b>Minor injury or health effect</b>  Affecting work performance, such as restriction to activities or need to take up to 5 days to fully recover. Or affecting daily life activities for up to 5 days. Or reversible health effects. Examples:<ul><li>Restricted work day cases or lost work day cases resulting in up to 5 calendar days away from work</li><li>Illnesses such as skin irritation or food poisoning.</li></ul>',
        IndicatorAssetDescription: '<b>Minor damage</b> Costs between 10,000 and 100,000 US$. Example:<ul><li>Brief disruption to operation</li></ul>',
        IndicatorEnvironmentDescription: '<b>Minor effect</b><br />Minor environmental damage, but no lasting effect. Examples:<ul><li>Small spill off-site that seeps into the ground</li><li>On-site groundwater contamination</li><li>Complaints from neighbours,</li><li>Single  of statutory or other prescribed limit</li></ul>',
        IndicatorReputationDescription: '<b>Minor impact</b><ul><li>Local public concern</li><li>Local media coverage</li></ul>',
        Risk: 'High',
        Residual_Risk_Id: 3
      },
      {
        Indicatorname: "E2", Indicatorclass: "RACatIndicator3", Indicatorseverity: 18,
        IndicatorGuideline: 2,
        IndicatorPeopleDescription: '<b>Minor injury or health effect</b>  Affecting work performance, such as restriction to activities or need to take up to 5 days to fully recover. Or affecting daily life activities for up to 5 days. Or reversible health effects. Examples:<ul><li>Restricted work day cases or lost work day cases resulting in up to 5 calendar days away from work</li><li>Illnesses such as skin irritation or food poisoning.</li></ul>',
        IndicatorAssetDescription: '<b>Minor damage</b> Costs between 10,000 and 100,000 US$. Example:<ul><li>Brief disruption to operation</li></ul>',
        IndicatorEnvironmentDescription: '<b>Minor effect</b><br />Minor environmental damage, but no lasting effect. Examples:<ul><li>Small spill off-site that seeps into the ground</li><li>On-site groundwater contamination</li><li>Complaints from neighbours,</li><li>Single  of statutory or other prescribed limit</li></ul>',
        IndicatorReputationDescription: '<b>Minor impact</b><ul><li>Local public concern</li><li>Local media coverage</li></ul>',
        Risk: 'High',
        Residual_Risk_Id: 3
      },
      {
        Indicatorname: "A3", Indicatorclass: "RACatIndicator2", Indicatorseverity: 14,
        IndicatorGuideline: 3,
        IndicatorPeopleDescription: '<b>Major injury or health effect</b>  Affecting work performance in the longer term, such as absence from work for more than 5 days. Or affecting daily life activities for more than 5 days. Or irreversible damage to health. Examples:<ul><li>Lost Work Day cases resulting in 6 or more calendar days away from work</li><li>Long term disabilities (previously called Permanent Partial Disabilities)</li><li>Illnesses such as sensitisation, noise induced hearing loss, chronic back injury, repetitive strain injury or stress</li></ul>',
        IndicatorAssetDescription: '<b>Moderate damage</b> Costs between 100,000 and 1 million US$. Example:<ul><li>Partial shutdown</li></ul>',
        IndicatorEnvironmentDescription: '<b>Moderate effect</b><br />Limited environmental damage that will persist or require cleaning up. Examples:<ul><li>Spill from a pipeline into soil/sand that requires removal and disposal of a large quantity of soil/sand</li><li>Observed off-site effects or damage, e.g. fish kill or damaged vegetation</li><li>Off-site groundwater contamination</li><li>Complaints from community organisations (or more than 10 complaints from individuals)</li><li>Frequent exceedance of statutory or other prescribed limit, with potential long term effect</li></ul>',
        IndicatorReputationDescription: '<b>Moderate impact</b>  Significant impact in region or country<ul><li>Regional public concern</li><li>Local stakeholders, e.g. community, NGO, industry and government, are aware</li><li>Extensive attention in local media. Some regional or national media coverage.</li></ul>',
        Risk: 'Medium',
        Residual_Risk_Id: 2
      },
      {
        Indicatorname: "B3", Indicatorclass: "RACatIndicator2", Indicatorseverity: 15,
        IndicatorGuideline: 3,
        IndicatorPeopleDescription: '<b>Major injury or health effect</b>  Affecting work performance in the longer term, such as absence from work for more than 5 days. Or affecting daily life activities for more than 5 days. Or irreversible damage to health. Examples:<ul><li>Lost Work Day cases resulting in 6 or more calendar days away from work</li><li>Long term disabilities (previously called Permanent Partial Disabilities)</li><li>Illnesses such as sensitisation, noise induced hearing loss, chronic back injury, repetitive strain injury or stress</li></ul>',
        IndicatorAssetDescription: '<b>Moderate damage</b> Costs between 100,000 and 1 million US$. Example:<ul><li>Partial shutdown</li></ul>',
        IndicatorEnvironmentDescription: '<b>Moderate effect</b><br />Limited environmental damage that will persist or require cleaning up. Examples:<ul><li>Spill from a pipeline into soil/sand that requires removal and disposal of a large quantity of soil/sand</li><li>Observed off-site effects or damage, e.g. fish kill or damaged vegetation</li><li>Off-site groundwater contamination</li><li>Complaints from community organisations (or more than 10 complaints from individuals)</li><li>Frequent exceedance of statutory or other prescribed limit, with potential long term effect</li></ul>',
        IndicatorReputationDescription: '<b>Moderate impact</b>  Significant impact in region or country<ul><li>Regional public concern</li><li>Local stakeholders, e.g. community, NGO, industry and government, are aware</li><li>Extensive attention in local media. Some regional or national media coverage.</li></ul>',
        Risk: 'Medium',
        Residual_Risk_Id: 2
      },
      {
        Indicatorname: "C3", Indicatorclass: "RACatIndicator3", Indicatorseverity: 19,
        IndicatorGuideline: 3,
        IndicatorPeopleDescription: '<b>Major injury or health effect</b>  Affecting work performance in the longer term, such as absence from work for more than 5 days. Or affecting daily life activities for more than 5 days. Or irreversible damage to health. Examples:<ul><li>Lost Work Day cases resulting in 6 or more calendar days away from work</li><li>Long term disabilities (previously called Permanent Partial Disabilities)</li><li>Illnesses such as sensitisation, noise induced hearing loss, chronic back injury, repetitive strain injury or stress</li></ul>',
        IndicatorAssetDescription: '<b>Moderate damage</b> Costs between 100,000 and 1 million US$. Example:<ul><li>Partial shutdown</li></ul>',
        IndicatorEnvironmentDescription: '<b>Moderate effect</b><br />Limited environmental damage that will persist or require cleaning up. Examples:<ul><li>Spill from a pipeline into soil/sand that requires removal and disposal of a large quantity of soil/sand</li><li>Observed off-site effects or damage, e.g. fish kill or damaged vegetation</li><li>Off-site groundwater contamination</li><li>Complaints from community organisations (or more than 10 complaints from individuals)</li><li>Frequent exceedance of statutory or other prescribed limit, with potential long term effect</li></ul>',
        IndicatorReputationDescription: '<b>Moderate impact</b>  Significant impact in region or country<ul><li>Regional public concern</li><li>Local stakeholders, e.g. community, NGO, industry and government, are aware</li><li>Extensive attention in local media. Some regional or national media coverage.</li></ul>',
        Risk: 'High',
        Residual_Risk_Id: 3
      },
      {
        Indicatorname: "D3", Indicatorclass: "RACatIndicator3", Indicatorseverity: 20,
        IndicatorGuideline: 3,
        IndicatorPeopleDescription: '<b>Major injury or health effect</b>  Affecting work performance in the longer term, such as absence from work for more than 5 days. Or affecting daily life activities for more than 5 days. Or irreversible damage to health. Examples:<ul><li>Lost Work Day cases resulting in 6 or more calendar days away from work</li><li>Long term disabilities (previously called Permanent Partial Disabilities)</li><li>Illnesses such as sensitisation, noise induced hearing loss, chronic back injury, repetitive strain injury or stress</li></ul>',
        IndicatorAssetDescription: '<b>Moderate damage</b> Costs between 100,000 and 1 million US$. Example:<ul><li>Partial shutdown</li></ul>',
        IndicatorEnvironmentDescription: '<b>Moderate effect</b><br />Limited environmental damage that will persist or require cleaning up. Examples:<ul><li>Spill from a pipeline into soil/sand that requires removal and disposal of a large quantity of soil/sand</li><li>Observed off-site effects or damage, e.g. fish kill or damaged vegetation</li><li>Off-site groundwater contamination</li><li>Complaints from community organisations (or more than 10 complaints from individuals)</li><li>Frequent exceedance of statutory or other prescribed limit, with potential long term effect</li></ul>',
        IndicatorReputationDescription: '<b>Moderate impact</b>  Significant impact in region or country<ul><li>Regional public concern</li><li>Local stakeholders, e.g. community, NGO, industry and government, are aware</li><li>Extensive attention in local media. Some regional or national media coverage.</li></ul>',
        Risk: 'High',
        Residual_Risk_Id: 3
      },
      {
        Indicatorname: "E3", Indicatorclass: "RACatIndicator4", Indicatorseverity: 25,
        IndicatorGuideline: 3,
        IndicatorPeopleDescription: '<b>Major injury or health effect</b>  Affecting work performance in the longer term, such as absence from work for more than 5 days. Or affecting daily life activities for more than 5 days. Or irreversible damage to health. Examples:<ul><li>Lost Work Day cases resulting in 6 or more calendar days away from work</li><li>Long term disabilities (previously called Permanent Partial Disabilities)</li><li>Illnesses such as sensitisation, noise induced hearing loss, chronic back injury, repetitive strain injury or stress</li></ul>',
        IndicatorAssetDescription: '<b>Moderate damage</b> Costs between 100,000 and 1 million US$. Example:<ul><li>Partial shutdown</li></ul>',
        IndicatorEnvironmentDescription: '<b>Moderate effect</b><br />Limited environmental damage that will persist or require cleaning up. Examples:<ul><li>Spill from a pipeline into soil/sand that requires removal and disposal of a large quantity of soil/sand</li><li>Observed off-site effects or damage, e.g. fish kill or damaged vegetation</li><li>Off-site groundwater contamination</li><li>Complaints from community organisations (or more than 10 complaints from individuals)</li><li>Frequent exceedance of statutory or other prescribed limit, with potential long term effect</li></ul>',
        IndicatorReputationDescription: '<b>Moderate impact</b>  Significant impact in region or country<ul><li>Regional public concern</li><li>Local stakeholders, e.g. community, NGO, industry and government, are aware</li><li>Extensive attention in local media. Some regional or national media coverage.</li></ul>',
        Risk: 'Serious',
        Residual_Risk_Id: 4
      },
      {
        Indicatorname: "A4", Indicatorclass: "RACatIndicator2", Indicatorseverity: 16,
        IndicatorGuideline: 4,
        IndicatorPeopleDescription: '<b>Permanent total disability or up to three fatalities</b>  resulting from injury or occupational illness. Examples:<ul><li>Illnesses such as corrosive burns, asbestosis, silicosis, cancer and serious work related depression.</li><li>Car accident resulting in 1, 2 or 3 fatalities</li></ul>',
        IndicatorAssetDescription: '<b>Major damage</b> Costs between 1 and 10 million US$. Example:<ul><li>Up to two weeks shutdown</li></ul>',
        IndicatorEnvironmentDescription: '<b>Major effect</b><br />Severe environmental damage that will require extensive measures to restore beneficial uses of the environment. Examples:<ul><li>Oil spill at a jetty during tanker (off) loading that ends up on local beaches, requiring clean-up operations</li><li>Off-site groundwater contamination over an extensive area</li><li>Many complaints from community organisations or local authorities.</li><li>Extended exceedance of statutory or other prescribed limits, with potential long term effects</li></ul>',
        IndicatorReputationDescription: '<b>Major impact</b>  Likely to escalate and affect Group reputation<ul><li>National public concern</li><li>Impact on local and national stakeholder relations. National government and NGO involvement with potential for international NGO action.</li><li>Extensive attention in national media. Some international coverage.</li><li>Potential for regulatory action leading to restricted operations or impact on operating licences.</li></ul>',
        Risk: 'Medium',
        Residual_Risk_Id: 2
      },
      {
        Indicatorname: "B4", Indicatorclass: "RACatIndicator3", Indicatorseverity: 21,
        IndicatorGuideline: 4,
        IndicatorPeopleDescription: '<b>Permanent total disability or up to three fatalities</b>  resulting from injury or occupational illness. Examples:<ul><li>Illnesses such as corrosive burns, asbestosis, silicosis, cancer and serious work related depression.</li><li>Car accident resulting in 1, 2 or 3 fatalities</li></ul>',
        IndicatorAssetDescription: '<b>Major damage</b> Costs between 1 and 10 million US$. Example:<ul><li>Up to two weeks shutdown</li></ul>',
        IndicatorEnvironmentDescription: '<b>Major effect</b><br />Severe environmental damage that will require extensive measures to restore beneficial uses of the environment. Examples:<ul><li>Oil spill at a jetty during tanker (off) loading that ends up on local beaches, requiring clean-up operations</li><li>Off-site groundwater contamination over an extensive area</li><li>Many complaints from community organisations or local authorities.</li><li>Extended exceedance of statutory or other prescribed limits, with potential long term effects</li></ul>',
        IndicatorReputationDescription: '<b>Major impact</b>  Likely to escalate and affect Group reputation<ul><li>National public concern</li><li>Impact on local and national stakeholder relations. National government and NGO involvement with potential for international NGO action.</li><li>Extensive attention in national media. Some international coverage.</li><li>Potential for regulatory action leading to restricted operations or impact on operating licences.</li></ul>',
        Risk: 'High',
        Residual_Risk_Id: 3
      },
      {
        Indicatorname: "C4", Indicatorclass: "RACatIndicator3", Indicatorseverity: 22,
        IndicatorGuideline: 4,
        IndicatorPeopleDescription: '<b>Permanent total disability or up to three fatalities</b>  resulting from injury or occupational illness. Examples:<ul><li>Illnesses such as corrosive burns, asbestosis, silicosis, cancer and serious work related depression.</li><li>Car accident resulting in 1, 2 or 3 fatalities</li></ul>',
        IndicatorAssetDescription: '<b>Major damage</b> Costs between 1 and 10 million US$. Example:<ul><li>Up to two weeks shutdown</li></ul>',
        IndicatorEnvironmentDescription: '<b>Major effect</b><br />Severe environmental damage that will require extensive measures to restore beneficial uses of the environment. Examples:<ul><li>Oil spill at a jetty during tanker (off) loading that ends up on local beaches, requiring clean-up operations</li><li>Off-site groundwater contamination over an extensive area</li><li>Many complaints from community organisations or local authorities.</li><li>Extended exceedance of statutory or other prescribed limits, with potential long term effects</li></ul>',
        IndicatorReputationDescription: '<b>Major impact</b>  Likely to escalate and affect Group reputation<ul><li>National public concern</li><li>Impact on local and national stakeholder relations. National government and NGO involvement with potential for international NGO action.</li><li>Extensive attention in national media. Some international coverage.</li><li>Potential for regulatory action leading to restricted operations or impact on operating licences.</li></ul>',
        Risk: 'High',
        Residual_Risk_Id: 3
      },
      {
        Indicatorname: "D4", Indicatorclass: "RACatIndicator4", Indicatorseverity: 26,
        IndicatorGuideline: 4,
        IndicatorPeopleDescription: '<b>Permanent total disability or up to three fatalities</b>  resulting from injury or occupational illness. Examples:<ul><li>Illnesses such as corrosive burns, asbestosis, silicosis, cancer and serious work related depression.</li><li>Car accident resulting in 1, 2 or 3 fatalities</li></ul>',
        IndicatorAssetDescription: '<b>Major damage</b> Costs between 1 and 10 million US$. Example:<ul><li>Up to two weeks shutdown</li></ul>',
        IndicatorEnvironmentDescription: '<b>Major effect</b><br />Severe environmental damage that will require extensive measures to restore beneficial uses of the environment. Examples:<ul><li>Oil spill at a jetty during tanker (off) loading that ends up on local beaches, requiring clean-up operations</li><li>Off-site groundwater contamination over an extensive area</li><li>Many complaints from community organisations or local authorities.</li><li>Extended exceedance of statutory or other prescribed limits, with potential long term effects</li></ul>',
        IndicatorReputationDescription: '<b>Major impact</b>  Likely to escalate and affect Group reputation<ul><li>National public concern</li><li>Impact on local and national stakeholder relations. National government and NGO involvement with potential for international NGO action.</li><li>Extensive attention in national media. Some international coverage.</li><li>Potential for regulatory action leading to restricted operations or impact on operating licences.</li></ul>',
        Risk: 'Serious',
        Residual_Risk_Id: 4
      },
      {
        Indicatorname: "E4", Indicatorclass: "RACatIndicator4", Indicatorseverity: 27,
        IndicatorGuideline: 4,
        IndicatorPeopleDescription: '<b>Permanent total disability or up to three fatalities</b>  resulting from injury or occupational illness. Examples:<ul><li>Illnesses such as corrosive burns, asbestosis, silicosis, cancer and serious work related depression.</li><li>Car accident resulting in 1, 2 or 3 fatalities</li></ul>',
        IndicatorAssetDescription: '<b>Major damage</b> Costs between 1 and 10 million US$. Example:<ul><li>Up to two weeks shutdown</li></ul>',
        IndicatorEnvironmentDescription: '<b>Major effect</b><br />Severe environmental damage that will require extensive measures to restore beneficial uses of the environment. Examples:<ul><li>Oil spill at a jetty during tanker (off) loading that ends up on local beaches, requiring clean-up operations</li><li>Off-site groundwater contamination over an extensive area</li><li>Many complaints from community organisations or local authorities.</li><li>Extended exceedance of statutory or other prescribed limits, with potential long term effects</li></ul>',
        IndicatorReputationDescription: '<b>Major impact</b>  Likely to escalate and affect Group reputation<ul><li>National public concern</li><li>Impact on local and national stakeholder relations. National government and NGO involvement with potential for international NGO action.</li><li>Extensive attention in national media. Some international coverage.</li><li>Potential for regulatory action leading to restricted operations or impact on operating licences.</li></ul>',
        Risk: 'Serious',
        Residual_Risk_Id: 4
      },
      {
        Indicatorname: "A5", Indicatorclass: "RACatIndicator3", Indicatorseverity: 23,
        IndicatorGuideline: 5,
        IndicatorPeopleDescription: '<b>More than three fatalities</b>  resulting from injury or occupational illness. Examples:<ul><li>Multiple asbestosis cases traced to a single exposure situation</li><li>Cancer to a large exposed population</li><li>Major fire or explosion resulting in more than 3 fatalities</li></ul>',
        IndicatorAssetDescription: '<b>Massive damage</b>  Costs in excess of 10 million US$. Example:<ul><li>Substantial or total loss of operation</li></ul>',
        IndicatorEnvironmentDescription: '<b> Massive effect</b><br />Persistent severe environmental damage that will lead to  loss of commercial, recreational use or loss of natural resources over a wide area. Example:<ul><li>Crude oil spillage resulting in pollution of a large part of a river estuary and extensive clean-up and remediation measures</li></ul>',
        IndicatorReputationDescription: '<b>Massive impact</b>  Severe impact on Group reputation<ul><li>International public concern.</li><li>High level of concern amongst governments and action by international NGOs.</li><li>International media attention.</li><li>Significant potential for effect on national/international policies with impact on access to new areas, grants of licences and/or tax legislation.</li></ul>',
        Risk: 'High',
        Residual_Risk_Id: 3
      },
      {
        Indicatorname: "B5", Indicatorclass: "RACatIndicator3", Indicatorseverity: 24,
        IndicatorGuideline: 5,
        IndicatorPeopleDescription: '<b>More than three fatalities</b>  resulting from injury or occupational illness. Examples:<ul><li>Multiple asbestosis cases traced to a single exposure situation</li><li>Cancer to a large exposed population</li><li>Major fire or explosion resulting in more than 3 fatalities</li></ul>',
        IndicatorAssetDescription: '<b>Massive damage</b>  Costs in excess of 10 million US$. Example:<ul><li>Substantial or total loss of operation</li></ul>',
        IndicatorEnvironmentDescription: '<b> Massive effect</b><br />Persistent severe environmental damage that will lead to  loss of commercial, recreational use or loss of natural resources over a wide area. Example:<ul><li>Crude oil spillage resulting in pollution of a large part of a river estuary and extensive clean-up and remediation measures</li></ul>',
        IndicatorReputationDescription: '<b>Massive impact</b>  Severe impact on Group reputation<ul><li>International public concern.</li><li>High level of concern amongst governments and action by international NGOs.</li><li>International media attention.</li><li>Significant potential for effect on national/international policies with impact on access to new areas, grants of licences and/or tax legislation.</li></ul>',
        Risk: 'High',
        Residual_Risk_Id: 3
      },
      {
        Indicatorname: "C5", Indicatorclass: "RACatIndicator4", Indicatorseverity: 28,
        IndicatorGuideline: 5,
        IndicatorPeopleDescription: '<b>More than three fatalities</b>  resulting from injury or occupational illness. Examples:<ul><li>Multiple asbestosis cases traced to a single exposure situation</li><li>Cancer to a large exposed population</li><li>Major fire or explosion resulting in more than 3 fatalities</li></ul>',
        IndicatorAssetDescription: '<b>Massive damage</b>  Costs in excess of 10 million US$. Example:<ul><li>Substantial or total loss of operation</li></ul>',
        IndicatorEnvironmentDescription: '<b> Massive effect</b><br />Persistent severe environmental damage that will lead to  loss of commercial, recreational use or loss of natural resources over a wide area. Example:<ul><li>Crude oil spillage resulting in pollution of a large part of a river estuary and extensive clean-up and remediation measures</li></ul>',
        IndicatorReputationDescription: '<b>Massive impact</b>  Severe impact on Group reputation<ul><li>International public concern.</li><li>High level of concern amongst governments and action by international NGOs.</li><li>International media attention.</li><li>Significant potential for effect on national/international policies with impact on access to new areas, grants of licences and/or tax legislation.</li></ul>',
        Risk: 'Serious'
      },
      {
        Indicatorname: "D5", Indicatorclass: "RACatIndicator4", Indicatorseverity: 29,
        IndicatorGuideline: 5,
        IndicatorPeopleDescription: '<b>More than three fatalities</b>  resulting from injury or occupational illness. Examples:<ul><li>Multiple asbestosis cases traced to a single exposure situation</li><li>Cancer to a large exposed population</li><li>Major fire or explosion resulting in more than 3 fatalities</li></ul>',
        IndicatorAssetDescription: '<b>Massive damage</b>  Costs in excess of 10 million US$. Example:<ul><li>Substantial or total loss of operation</li></ul>',
        IndicatorEnvironmentDescription: '<b> Massive effect</b><br />Persistent severe environmental damage that will lead to  loss of commercial, recreational use or loss of natural resources over a wide area. Example:<ul><li>Crude oil spillage resulting in pollution of a large part of a river estuary and extensive clean-up and remediation measures</li></ul>',
        IndicatorReputationDescription: '<b>Massive impact</b>  Severe impact on Group reputation<ul><li>International public concern.</li><li>High level of concern amongst governments and action by international NGOs.</li><li>International media attention.</li><li>Significant potential for effect on national/international policies with impact on access to new areas, grants of licences and/or tax legislation.</li></ul>',
        Risk: 'Serious',
        Residual_Risk_Id: 4
      },
      {
        Indicatorname: "E5", Indicatorclass: "RACatIndicator4", Indicatorseverity: 30,
        IndicatorGuideline: 5,
        IndicatorPeopleDescription: '<b>More than three fatalities</b>  resulting from injury or occupational illness. Examples:<ul><li>Multiple asbestosis cases traced to a single exposure situation</li><li>Cancer to a large exposed population</li><li>Major fire or explosion resulting in more than 3 fatalities</li></ul>',
        IndicatorAssetDescription: '<b>Massive damage</b>  Costs in excess of 10 million US$. Example:<ul><li>Substantial or total loss of operation</li></ul>',
        IndicatorEnvironmentDescription: '<b> Massive effect</b><br />Persistent severe environmental damage that will lead to  loss of commercial, recreational use or loss of natural resources over a wide area. Example:<ul><li>Crude oil spillage resulting in pollution of a large part of a river estuary and extensive clean-up and remediation measures</li></ul>',
        IndicatorReputationDescription: '<b>Massive impact</b>  Severe impact on Group reputation<ul><li>International public concern.</li><li>High level of concern amongst governments and action by international NGOs.</li><li>International media attention.</li><li>Significant potential for effect on national/international policies with impact on access to new areas, grants of licences and/or tax legislation.</li></ul>',
        Risk: 'Serious',
        Residual_Risk_Id: 4
      }];
    this.Riskassesments.push(new RiskAssessmentModel())
    this.CRAContentListHeader = [
      {
        IsHeading: true,
        IsSubHeading: false,
        Column: [
          { Content: "Risk Mgmnt Process", RowSpan: 2 },
          { Content: "Cumulative Risk Hazards", ColSpan: 13 },
          { Content: "Outcome", RowSpan: 2 },
        ]

      },
      {
        IsHeading: true,
        IsSubHeading: false,
        Column: [
          { Content: "Deviations" },
          { Content: "Perf. Standard Failures" },
          { Content: "Permit to Work" },
          { Content: "Temp. Repairs" },
          { Content: "Temp. Portable Equipment" },
          { Content: "Passing Valves" },
          { Content: "Weeps & Seeps" },
          { Content: "Locked Valves" },
          { Content: "Alarm Overrides" },
          { Content: "Process Overrides" },
          { Content: "Procedure Variance" },
          { Content: "Org. Change" },
          { Content: "Operating Mode" },
        ]

      },


    ]
    this.CRAContentListSubHeader = [
      {
        IsHeading: false,
        IsSubHeading: true,
        Column: [
          { Content: "Tool" },
          { Content: "FSR AI Portal" },
          { Content: "AI Portal" },
          { Content: "eVision" },
          { Content: "CIMS/AI Portal" },
          { Content: "eMoC/AI Portal" },
          { Content: "ODT Register" },
          { Content: "Register" },
          { Content: "eMoC" },
          { Content: "eMoC" },
          { Content: "eMoC/AI Portal" },
          { Content: "eMoC" },
          { Content: "eMoC/AI Portal" },
          { Content: "Standing Instns Ops Waivers CVs + Cascade Controllers in Manual Mode  Process Abnormalities Alarms>6 per hr MOPO compliance" },
          { Content: "Cumulative Risk Outcome", RowSpan: 2 },
        ]

      },
      {
        IsHeading: false,
        IsSubHeading: true,
        Column: [
          { Content: "Ref." },
          { Content: "PR-2410" },
          { Content: "EPAF CM CAM 2/3" },
          { Content: "SP-2329" },
          { Content: "PR-2124" },
          { Content: "PR-1960" },
          { Content: "PR-2049" },
          { Content: "PR-1961" },
          { Content: "PR-1086" },
          { Content: "PR-1001b" },
          { Content: "PR-1001c" },
          { Content: "PR-1001e" },
          { Content: "PR-2379 PR-2168" },
          { Content: "HSE Case" },
        ]

      },
    ]
    this.CRAContentList = [
      {
        Column: [
          { Content: "Additional Risk", Id: null, RowSpan: 5 },
          { Content: "No relevant Deviations", Id: "CRABlue1", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA1" },
          { Content: "No relevant PS Failures	", Id: "CRABlue2", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA2" },
          { Content: "No relevant PTWs", Id: "CRABlue3", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA3" },
          { Content: "No relevant Temporary Repairs", Id: "CRABlue4", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA4" },
          { Content: "No relevant TPEs", Id: "CRABlue5", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA5" },
          { Content: "No relevant Passing Valves", Id: "CRABlue6", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA6" },
          { Content: "No relevant Weeps and Seeps", Id: "CRABlue7", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA7" },
          { Content: "No relevant Locked Valves", Id: "CRABlue8", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA8" },
          { Content: "No relevant Alarm Overrides", Id: "CRABlue9", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA9" },
          { Content: "No relevant Process Overrides", Id: "CRABlue10", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA10" },
          { Content: "No relevant Procedure Variances", Id: "CRABlue11", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA11" },
          { Content: "No relevant Org. Changes", Id: "CRABlue12", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA12" },
          { Content: "No relevant Op. Mode changes", Id: "CRABlue13", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA13" },
          { Content: "All items are ticked and in Blue Zone: Proceed with caution", Id: "CRABlue", Enabled: false, RowSpan: 2, },
        ],
        IsBlueZone: true,
        BlueSelectableTextbox: 13,
        YellowSelectableTextbox: 13
      },
      {
        IsBlueZone: true,
        Column: [
          { Content: "Deviations are low risk", Id: "CRABlue14", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA1" },
          { Content: "PS Failures are present but not relevant", Id: "CRABlue15", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA2" },
          { Content: "PTWs are low risk", Id: "CRABlue15", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA3" },
          { Content: "Temporary Repairs are low risk", Id: "CRABlue16", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA4" },
          { Content: "TPEs are present, but low risk", Id: "CRABlue17", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA5" },
          { Content: "Passing valves are low risk", Id: "CRABlue18", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA6" },
          { Content: "Relevant Weeps and Seeps are low risk", Id: "CRABlue19", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA7" },
          { Content: "Locked valve changes required are low risk", Id: "CRABlue20", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA8" },
          { Content: "Relevant Alarm Overrides are low risk", Id: "CRABlue21", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA9" },
          { Content: "Relevant Process Overrides are low risk", Id: "CRABlue22", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA10" },
          { Content: "Procedure Variances are low risk", Id: "CRABlue23", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA11" },
          { Content: "Org. Changes are low risk", Id: "CRABlue24", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA12" },
          { Content: "Operating mode changes are low risk", Id: "CRABlue25", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA13" },
        ]

      },
      {
        IsYellow: true,
        BlueSelectableTextbox: 13,
        YellowSelectableTextbox: 13,
        Column: [
          { Content: "There is a high-risk Deviation present", Id: "CRARed1", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA1" },
          { Content: "There is a relevant RAM Severity 3-5 PS Failure", Id: "CRARed2", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA2" },
          { Content: "Risk to ongoing work location or activity", Id: "CRARed3", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA3" },
          { Content: "There is a high risk or leaking Temporary Repair", Id: "CRARed4", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA4" },
          { Content: "There is a critical or high-risk TPE in place", Id: "CRARed5", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA5" },
          { Content: "There is one or more critical Passing valves", Id: "CRARed6", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA6" },
          { Content: "There is a high risk Weeps and Seeps", Id: "CRARed7", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA7" },
          { Content: "There are multiple Locked Valve changes required", Id: "CRARed8", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA8" },
          { Content: "There is a critical Alam Override in place", Id: "CRARed9", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA9" },
          { Content: "There is a critical or Red Process Override in place", Id: "CRARed10", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA10" },
          { Content: "There is a critical Procedure Variation in place", Id: "CRARed11", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA11" },
          { Content: "The facility is at or below Minimum Manning", Id: "CRARed12", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA12" },
          { Content: "There are critical Operating Mode variations in place", Id: "CRARed13", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA13" },
          { Content: "One or more items ticked in Orange zone: 1) Minimum TA02 signature required 2) No Delegation allowed 3) Include additional mitigations 4) If risk is not ALARP, then do not proceed", RowSpan: 3, Id: "CRAYellow", Selected: false, Enabled: false, Type: "Yellow" },


        ]


      },
      {
        IsYellow: true,
        BlueSelectableTextbox: 13,
        YellowSelectableTextbox: 13,
        Column: [
          { Content: "There is an FSR Red present", Id: "CRARed14", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA1" },
          { Content: "There is a PS Failure past LAFD", Id: "CRARed15", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA2" },
          { Content: "There is a high risk PTW activity in the area", Id: "CRARed16", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA3" },
          { Content: "There is a relevant overdue Temp. Repair", Id: "CRARed17", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA4" },
          { Content: "There is an overdue TPE in the facility", Id: "CRARed18", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA5" },
          { Content: "There are overdue Passing valves", Id: "CRARed19", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA6" },
          { Content: "There is an overdue Weeps and Seeps item", Id: "CRARed20", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA7" },
          { Content: "There are overdue Locked Valves", Id: "CRARed21", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA8" },
          { Content: "There is one or more expired overrides", Id: "CRARed22", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA9" },
          { Content: "There is an expired process overrides", Id: "CRARed23", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA10" },
          { Content: "There is an expired Procedure Variation", Id: "CRARed24", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA11" },
          { Content: "There are expired Temporary Appointmts", Id: "CRARed25", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA12" },
          { Content: "There are expired or long-term Operating Mode variations", Id: "CRARed26", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA13" },


        ]


      },
      {
        IsYellow: true,
        BlueSelectableTextbox: 13,
        YellowSelectableTextbox: 13,
        Column: [
          { Content: "There is a high number of Deviations present", Id: "CRARed27", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA1" },
          { Content: "There is a high number of relevant  PS Failures present", Id: "CRARed28", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA2" },
          { Content: "There are a high number of PTWs concurrently", Id: "CRARed29", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA3" },
          { Content: "There is a high number of relevant Temp. Repairs", Id: "CRARed30", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA4" },
          { Content: "There is a high number of TPE present in the facility", Id: "CRARed31", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA5" },
          { Content: "There is a high number of relevant passing valves", Id: "CRARed32", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA6" },
          { Content: "There is a high number of weeps and seeps", Id: "CRARed33", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA7" },
          { Content: "Safeguarding system Locked valves changes are required", Id: "CRARed34", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA8" },
          { Content: "There is a high number of alarm overrides", Id: "CRARed35", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA9" },
          { Content: "There is a high number of Process overrides", Id: "CRARed36", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA10" },
          { Content: "There is a high number of Procedure Variations", Id: "CRARed37", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA11" },
          { Content: "There is more than one relevant Temp. Appts", Id: "CRARed38", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA12" },
          { Content: "There is a high number of overall Operating Mode variations present", Id: "CRARed39", Selected: false, Enabled: true, Type: "Yellow", OppositeId: "CRA13" },

        ]


      },
    ]
  }
  deleteRAElement(ElementType: string, activityIndex: number) {
    this.ToBeDeletedElementType = ElementType;
    this.ToBeDeletedActivityIndex = activityIndex;
    this.confirmationPopUp()
    //this.OkConfirmedClicked(ElementType, activityIndex)
  }

  OkConfirmedClicked(ElementType: string, activityIndex: number) {
    //$scope.IsDeleteConfirm = true;

    //if (ElementType == "ReviewDetails") {
    //  ReviewersList.splice(activityIndex, 1);
    //}
    if (ElementType == "Situation/Task") {
      this.delActivity(activityIndex);
    }
    else if (ElementType == "Hazard/Threat") {
      this.delHazard(activityIndex);
    }
    else if (ElementType == "Effect of the Hazard") {
      this.delTreat(activityIndex);
    }
    else if (ElementType == "Groups Affected/Consequence") {
      this.delConsequence(activityIndex);
    }
    else if (ElementType == "Control measures required to reduce Initial Risk") {
      this.delControl(activityIndex);
    }
    //else if (ElementType == "Tag") {
    //  TagDetailList.splice(activityIndex, 1);
    //}
    //else if (ElementType == "Supporting Document") {

    //  var tempdoc = DocumentsList[activityIndex];
    //  DocumentsList.splice(activityIndex, 1);
    //  $scope.Files = $scope.Files.filter(function (item) { return item.TempFileName != tempdoc.TempFileName });
    //  //$scope.Files = $scope.Files.filter(item => (item.TempFileName != tempdoc.TempFileName));

    //}
    //else if (ElementType == "Risk Assessment Team Member") {
    //  RiskAssessmentTeamMemberList.splice(activityIndex, 1);
    //}
    //else if (ElementType == "SAP Z1 Notification") {
    //  SAPZ1NotificationNoList.splice(activityIndex, 1);
    //}

    //This line is only applicable for Organizational Change Project (Created by Roomi)
    //this.ShowRAApprover.emit();
  }


  delActivity(activityIndex: number) {
    var IndexRequiredTobedeleted = [];
    for (var lintIndexCount = 0; lintIndexCount < this.Riskassesments.length; lintIndexCount++) {
      if (activityIndex == lintIndexCount) {
        //condition 1: (current row deletion)
        IndexRequiredTobedeleted.push(lintIndexCount);
      }
      if (lintIndexCount > activityIndex) {

        if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore") {
          IndexRequiredTobedeleted.push(lintIndexCount);
        }
        else {
          break;
        }
      }
    }

    for (var i = IndexRequiredTobedeleted.length - 1; i >= 0; i--)
      this.Riskassesments.splice(IndexRequiredTobedeleted[i], 1);
    this.getMaximumrisk();

  }
  //end

  //Hazard start
  AddHazard(index: number) {

    var hazardObj = new RiskAssessmentModel();
    hazardObj.activityIgnore = "NA_Ignore";
    //alert(index);
    // this.Riskassesments.splice(index + 1, 0, hazardObj);
    var IndextobeAdded = index + 1;
    for (var lintIndexCount = 0; lintIndexCount < this.Riskassesments.length; lintIndexCount++) {
      if (lintIndexCount > index) {
        if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore") {
          IndextobeAdded = lintIndexCount;
        }
        else {
          IndextobeAdded = lintIndexCount - 1;
          break;
        }
      }
    }
    this.Riskassesments.splice(IndextobeAdded + 1, 0, hazardObj);
  }
  delHazard(activityIndex: number) {
    var IndexRequiredTobedeleted = [];
    for (var lintIndexCount = 0; lintIndexCount < this.Riskassesments.length; lintIndexCount++) {
      if (activityIndex == lintIndexCount) {
        //condition 1: (current row deletion)
        if (this.Riskassesments[lintIndexCount].activityIgnore != "NA_Ignore") {
          this.Riskassesments[lintIndexCount].controlIgnore = "NA_Ignore";
          this.Riskassesments[lintIndexCount].treatIgnore = "NA_Ignore";
          this.Riskassesments[lintIndexCount].consequenceIgnore = "NA_Ignore";
          this.Riskassesments[lintIndexCount].hazardIgnore = "NA_Ignore";

          //Clear the control array object values
          this.Riskassesments[lintIndexCount].ResidualhighestRisk = {};
          this.Riskassesments[lintIndexCount].InitialhighestRisk = {};

          this.Riskassesments[lintIndexCount].hazard = "";
          this.Riskassesments[lintIndexCount].treat = "";
          this.Riskassesments[lintIndexCount].consequence = "";
          this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorModule = "";
          this.Riskassesments[lintIndexCount].consequenceAssetsIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequencePeopleIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequenceEnvironmentIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequenceRetutaionIndicatorId = "";


          this.Riskassesments[lintIndexCount].control = "";
          this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorModule = "";
          this.Riskassesments[lintIndexCount].controlsPeopleIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsAssetsIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsEnvironmentIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsRetutaionIndicatorId = "";
          this.Riskassesments[lintIndexCount].activityOwnerdetails = "";
          this.Riskassesments[lintIndexCount].controlType = null;
          this.Riskassesments[lintIndexCount].activityOwner = "";
          this.Riskassesments[lintIndexCount].frequencyType = "";


          //logic to find the next occurance of threat
          if (this.Riskassesments[lintIndexCount + 1] != undefined &&
            this.Riskassesments[lintIndexCount + 1].activityIgnore == "NA_Ignore") {
            var lintNextAppearance = null;
            for (var lintTemp = lintIndexCount + 1; lintTemp < this.Riskassesments.length; lintTemp++) {
              if (this.Riskassesments[lintTemp].hazardIgnore != "NA_Ignore") {
                lintNextAppearance = lintTemp;
                break;
              }

            }

            if (lintNextAppearance != null) {
              this.Riskassesments[lintIndexCount].hazardIgnore = this.Riskassesments[lintNextAppearance].hazardIgnore;
              this.Riskassesments[lintIndexCount].hazard = this.Riskassesments[lintNextAppearance].hazard;
              this.Riskassesments[lintIndexCount].treatIgnore = this.Riskassesments[lintNextAppearance].treatIgnore;
              this.Riskassesments[lintIndexCount].treat = this.Riskassesments[lintNextAppearance].treat;
              this.Riskassesments[lintIndexCount].consequence = this.Riskassesments[lintNextAppearance].consequence;
              this.Riskassesments[lintIndexCount].consequenceIgnore = this.Riskassesments[lintNextAppearance].consequenceIgnore;
              this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorId = this.Riskassesments[lintNextAppearance].consequencemaximumRiskIndicatorId;
              this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorModule = this.Riskassesments[lintNextAppearance].consequencemaximumRiskIndicatorModule;
              this.Riskassesments[lintIndexCount].consequenceAssetsIndicatorId = this.Riskassesments[lintNextAppearance].consequenceAssetsIndicatorId;
              this.Riskassesments[lintIndexCount].consequencePeopleIndicatorId = this.Riskassesments[lintNextAppearance].consequencePeopleIndicatorId;
              this.Riskassesments[lintIndexCount].consequenceEnvironmentIndicatorId = this.Riskassesments[lintNextAppearance].consequenceEnvironmentIndicatorId;
              this.Riskassesments[lintIndexCount].consequenceRetutaionIndicatorId = this.Riskassesments[lintNextAppearance].consequenceRetutaionIndicatorId;
              this.Riskassesments[lintIndexCount].control = this.Riskassesments[lintNextAppearance].control;
              this.Riskassesments[lintIndexCount].controlIgnore = this.Riskassesments[lintNextAppearance].controlIgnore;
              this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorId = this.Riskassesments[lintNextAppearance].controlmaximumRiskIndicatorId;
              this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorModule = this.Riskassesments[lintNextAppearance].controlmaximumRiskIndicatorModule;
              this.Riskassesments[lintIndexCount].controlsPeopleIndicatorId = this.Riskassesments[lintNextAppearance].controlsPeopleIndicatorId;
              this.Riskassesments[lintIndexCount].controlsAssetsIndicatorId = this.Riskassesments[lintNextAppearance].controlsAssetsIndicatorId;
              this.Riskassesments[lintIndexCount].controlsEnvironmentIndicatorId = this.Riskassesments[lintNextAppearance].controlsEnvironmentIndicatorId;
              this.Riskassesments[lintIndexCount].controlsRetutaionIndicatorId = this.Riskassesments[lintNextAppearance].controlsRetutaionIndicatorId;
              //this.Riskassesments[lintIndexCount].hazardAutoPouplate = this.Riskassesments[lintNextAppearance].hazardAutoPouplate;
              this.Riskassesments[lintIndexCount].threatAutoPouplate = this.Riskassesments[lintNextAppearance].threatAutoPouplate;
              this.Riskassesments[lintIndexCount].consequenceAutoPouplate = this.Riskassesments[lintNextAppearance].consequenceAutoPouplate;
              this.Riskassesments[lintIndexCount].controlAutoPouplate = this.Riskassesments[lintNextAppearance].controlAutoPouplate;
              this.Riskassesments[lintIndexCount].activityOwnerdetails = this.Riskassesments[lintNextAppearance].activityOwnerdetails;

              IndexRequiredTobedeleted.push(lintNextAppearance);
            }

          }

        }
        else if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore") {
          IndexRequiredTobedeleted.push(lintIndexCount);
        }
      }
      if (lintIndexCount > activityIndex) {

        if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].hazardIgnore == "NA_Ignore") {
          IndexRequiredTobedeleted.push(lintIndexCount);
        }
        else {
          break;
        }
      }
    }

    for (var i = IndexRequiredTobedeleted.length - 1; i >= 0; i--)
      this.Riskassesments.splice(IndexRequiredTobedeleted[i], 1);

    this.getMaximumrisk();

  }
  //end

  //Treat start
  AddTreat(index: number) {
    var treatObj = new RiskAssessmentModel();
    treatObj.activityIgnore = "NA_Ignore";
    treatObj.hazardIgnore = "NA_Ignore";
    var IndextobeAdded = index + 1;
    for (var lintIndexCount = 0; lintIndexCount < this.Riskassesments.length; lintIndexCount++) {
      if (lintIndexCount > index) {
        if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].hazardIgnore == "NA_Ignore") {
          IndextobeAdded = lintIndexCount;
        }
        else {
          IndextobeAdded = lintIndexCount - 1;
          break;
        }
      }
    }
    this.Riskassesments.splice(IndextobeAdded + 1, 0, treatObj);
    this.getMaximumrisk();
  }
  delTreat(activityIndex: number) {

    var IndexRequiredTobedeleted = [];
    for (var lintIndexCount = 0; lintIndexCount < this.Riskassesments.length; lintIndexCount++) {
      if (activityIndex == lintIndexCount) {
        //condition 1: (current row deletion)
        if (this.Riskassesments[lintIndexCount].activityIgnore != "NA_Ignore"
          || this.Riskassesments[lintIndexCount].hazardIgnore != "NA_Ignore") {
          this.Riskassesments[lintIndexCount].controlIgnore = "NA_Ignore";
          this.Riskassesments[lintIndexCount].treatIgnore = "NA_Ignore";
          this.Riskassesments[lintIndexCount].consequenceIgnore = "NA_Ignore";


          //logic to find the next occurance of threat

          //Clear the control array object values
          this.Riskassesments[lintIndexCount].ResidualhighestRisk = {};
          this.Riskassesments[lintIndexCount].InitialhighestRisk = {};

          this.Riskassesments[lintIndexCount].treat = "";
          this.Riskassesments[lintIndexCount].consequence = "";
          this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorModule = "";
          this.Riskassesments[lintIndexCount].consequenceAssetsIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequencePeopleIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequenceEnvironmentIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequenceRetutaionIndicatorId = "";


          this.Riskassesments[lintIndexCount].control = "";
          this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorModule = "";
          this.Riskassesments[lintIndexCount].controlsPeopleIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsAssetsIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsEnvironmentIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsRetutaionIndicatorId = "";
          this.Riskassesments[lintIndexCount].activityOwnerdetails = "";
          this.Riskassesments[lintIndexCount].controlType = null;
          this.Riskassesments[lintIndexCount].activityOwner = "";
          this.Riskassesments[lintIndexCount].frequencyType = "";

          if (this.Riskassesments[lintIndexCount + 1] != undefined &&
            this.Riskassesments[lintIndexCount + 1].activityIgnore == "NA_Ignore" &&
            this.Riskassesments[lintIndexCount + 1].hazardIgnore == "NA_Ignore") {
            var lintNextAppearance = null;
            for (var lintTemp = lintIndexCount + 1; lintTemp < this.Riskassesments.length; lintTemp++) {
              if (this.Riskassesments[lintTemp].treatIgnore != "NA_Ignore") {
                lintNextAppearance = lintTemp;
                break;
              }

            }

            if (lintNextAppearance != null) {
              this.Riskassesments[lintIndexCount].treatIgnore = this.Riskassesments[lintNextAppearance].treatIgnore;
              this.Riskassesments[lintIndexCount].treat = this.Riskassesments[lintNextAppearance].treat;
              this.Riskassesments[lintIndexCount].consequence = this.Riskassesments[lintNextAppearance].consequence;
              this.Riskassesments[lintIndexCount].consequenceIgnore = this.Riskassesments[lintNextAppearance].consequenceIgnore;
              this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorId = this.Riskassesments[lintNextAppearance].consequencemaximumRiskIndicatorId;
              this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorModule = this.Riskassesments[lintNextAppearance].consequencemaximumRiskIndicatorModule;
              this.Riskassesments[lintIndexCount].consequenceAssetsIndicatorId = this.Riskassesments[lintNextAppearance].consequenceAssetsIndicatorId;
              this.Riskassesments[lintIndexCount].consequencePeopleIndicatorId = this.Riskassesments[lintNextAppearance].consequencePeopleIndicatorId;
              this.Riskassesments[lintIndexCount].consequenceEnvironmentIndicatorId = this.Riskassesments[lintNextAppearance].consequenceEnvironmentIndicatorId;
              this.Riskassesments[lintIndexCount].consequenceRetutaionIndicatorId = this.Riskassesments[lintNextAppearance].consequenceRetutaionIndicatorId;
              this.Riskassesments[lintIndexCount].control = this.Riskassesments[lintNextAppearance].control;
              this.Riskassesments[lintIndexCount].controlIgnore = this.Riskassesments[lintNextAppearance].controlIgnore;
              this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorId = this.Riskassesments[lintNextAppearance].controlmaximumRiskIndicatorId;
              this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorModule = this.Riskassesments[lintNextAppearance].controlmaximumRiskIndicatorModule;
              this.Riskassesments[lintIndexCount].controlsPeopleIndicatorId = this.Riskassesments[lintNextAppearance].controlsPeopleIndicatorId;
              this.Riskassesments[lintIndexCount].controlsAssetsIndicatorId = this.Riskassesments[lintNextAppearance].controlsAssetsIndicatorId;
              this.Riskassesments[lintIndexCount].controlsEnvironmentIndicatorId = this.Riskassesments[lintNextAppearance].controlsEnvironmentIndicatorId;
              this.Riskassesments[lintIndexCount].controlsRetutaionIndicatorId = this.Riskassesments[lintNextAppearance].controlsRetutaionIndicatorId;
              //this.Riskassesments[lintIndexCount].hazardAutoPouplate = this.Riskassesments[lintNextAppearance].hazardAutoPouplate;
              this.Riskassesments[lintIndexCount].threatAutoPouplate = this.Riskassesments[lintNextAppearance].threatAutoPouplate;
              this.Riskassesments[lintIndexCount].consequenceAutoPouplate = this.Riskassesments[lintNextAppearance].consequenceAutoPouplate;
              this.Riskassesments[lintIndexCount].controlAutoPouplate = this.Riskassesments[lintNextAppearance].controlAutoPouplate;
              this.Riskassesments[lintIndexCount].activityOwnerdetails = this.Riskassesments[lintNextAppearance].activityOwnerdetails;

              IndexRequiredTobedeleted.push(lintNextAppearance);
            }

          }

        }
        else if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].hazardIgnore == "NA_Ignore") {
          IndexRequiredTobedeleted.push(lintIndexCount);
        }
      }
      if (lintIndexCount > activityIndex) {

        if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].hazardIgnore == "NA_Ignore" && this.Riskassesments[lintIndexCount].treatIgnore == "NA_Ignore") {
          IndexRequiredTobedeleted.push(lintIndexCount);
        }
        else {
          break;
        }
      }
    }

    for (var i = IndexRequiredTobedeleted.length - 1; i >= 0; i--)
      this.Riskassesments.splice(IndexRequiredTobedeleted[i], 1);
    this.getMaximumrisk();
  }
  //end

  //Consequence  start
  AddConsequence(index: number) {

    var consequenceObj = new RiskAssessmentModel();
    consequenceObj.activityIgnore = "NA_Ignore";
    consequenceObj.hazardIgnore = "NA_Ignore";
    consequenceObj.treatIgnore = "NA_Ignore";
    var IndextobeAdded = index + 1;
    for (var lintIndexCount = 0; lintIndexCount < this.Riskassesments.length; lintIndexCount++) {
      if (lintIndexCount > index) {
        if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].hazardIgnore == "NA_Ignore" && this.Riskassesments[lintIndexCount].treatIgnore == "NA_Ignore") {
          IndextobeAdded = lintIndexCount;
        }
        else {
          IndextobeAdded = lintIndexCount - 1;
          break;
        }
      }
    }
    this.Riskassesments.splice(IndextobeAdded + 1, 0, consequenceObj);
    this.getMaximumrisk();
  }
  delConsequence(activityIndex: number) {

    var IndexRequiredTobedeleted = [];
    for (var lintIndexCount = 0; lintIndexCount < this.Riskassesments.length; lintIndexCount++) {
      if (activityIndex == lintIndexCount) {
        //condition 1: (current row deletion)
        if (this.Riskassesments[lintIndexCount].activityIgnore != "NA_Ignore"
          || this.Riskassesments[lintIndexCount].hazardIgnore != "NA_Ignore" || this.Riskassesments[lintIndexCount].treatIgnore != "NA_Ignore") {
          this.Riskassesments[lintIndexCount].controlIgnore = "NA_Ignore";
          this.Riskassesments[lintIndexCount].consequenceIgnore = "NA_Ignore";
          //Clear the control array object values
          this.Riskassesments[lintIndexCount].ResidualhighestRisk = {};
          this.Riskassesments[lintIndexCount].InitialhighestRisk = {};
          this.Riskassesments[lintIndexCount].consequence = "";
          this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorModule = "";
          this.Riskassesments[lintIndexCount].consequenceAssetsIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequencePeopleIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequenceEnvironmentIndicatorId = "";
          this.Riskassesments[lintIndexCount].consequenceRetutaionIndicatorId = "";


          this.Riskassesments[lintIndexCount].control = "";
          this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorModule = "";
          this.Riskassesments[lintIndexCount].controlsPeopleIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsAssetsIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsEnvironmentIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsRetutaionIndicatorId = "";
          this.Riskassesments[lintIndexCount].activityOwnerdetails = "";
          this.Riskassesments[lintIndexCount].controlType = null;
          this.Riskassesments[lintIndexCount].activityOwner = "";
          this.Riskassesments[lintIndexCount].frequencyType = "";

          //logic to find the next occurance of threat
          if (this.Riskassesments[lintIndexCount + 1] != undefined &&
            this.Riskassesments[lintIndexCount + 1].activityIgnore == "NA_Ignore" &&
            this.Riskassesments[lintIndexCount + 1].hazardIgnore == "NA_Ignore" &&
            this.Riskassesments[lintIndexCount + 1].treatIgnore == "NA_Ignore") {
            var lintNextAppearance = null;
            for (var lintTemp = lintIndexCount + 1; lintTemp < this.Riskassesments.length; lintTemp++) {
              if (this.Riskassesments[lintTemp].consequenceIgnore != "NA_Ignore") {
                lintNextAppearance = lintTemp;
                break;
              }

            }

            if (lintNextAppearance != null) {
              this.Riskassesments[lintIndexCount].consequence = this.Riskassesments[lintNextAppearance].consequence;
              this.Riskassesments[lintIndexCount].consequenceIgnore = this.Riskassesments[lintNextAppearance].consequenceIgnore;
              this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorId = this.Riskassesments[lintNextAppearance].consequencemaximumRiskIndicatorId;
              this.Riskassesments[lintIndexCount].consequencemaximumRiskIndicatorModule = this.Riskassesments[lintNextAppearance].consequencemaximumRiskIndicatorModule;
              this.Riskassesments[lintIndexCount].consequenceAssetsIndicatorId = this.Riskassesments[lintNextAppearance].consequenceAssetsIndicatorId;
              this.Riskassesments[lintIndexCount].consequencePeopleIndicatorId = this.Riskassesments[lintNextAppearance].consequencePeopleIndicatorId;
              this.Riskassesments[lintIndexCount].consequenceEnvironmentIndicatorId = this.Riskassesments[lintNextAppearance].consequenceEnvironmentIndicatorId;
              this.Riskassesments[lintIndexCount].consequenceRetutaionIndicatorId = this.Riskassesments[lintNextAppearance].consequenceRetutaionIndicatorId;
              this.Riskassesments[lintIndexCount].control = this.Riskassesments[lintNextAppearance].control;
              this.Riskassesments[lintIndexCount].controlIgnore = this.Riskassesments[lintNextAppearance].controlIgnore;
              this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorId = this.Riskassesments[lintNextAppearance].controlmaximumRiskIndicatorId;
              this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorModule = this.Riskassesments[lintNextAppearance].controlmaximumRiskIndicatorModule;
              this.Riskassesments[lintIndexCount].controlsPeopleIndicatorId = this.Riskassesments[lintNextAppearance].controlsPeopleIndicatorId;
              this.Riskassesments[lintIndexCount].controlsAssetsIndicatorId = this.Riskassesments[lintNextAppearance].controlsAssetsIndicatorId;
              this.Riskassesments[lintIndexCount].controlsEnvironmentIndicatorId = this.Riskassesments[lintNextAppearance].controlsEnvironmentIndicatorId;
              this.Riskassesments[lintIndexCount].controlsRetutaionIndicatorId = this.Riskassesments[lintNextAppearance].controlsRetutaionIndicatorId;
              //this.Riskassesments[lintIndexCount].hazardAutoPouplate = this.Riskassesments[lintNextAppearance].hazardAutoPouplate;
              this.Riskassesments[lintIndexCount].threatAutoPouplate = this.Riskassesments[lintNextAppearance].threatAutoPouplate;
              this.Riskassesments[lintIndexCount].consequenceAutoPouplate = this.Riskassesments[lintNextAppearance].consequenceAutoPouplate;
              this.Riskassesments[lintIndexCount].controlAutoPouplate = this.Riskassesments[lintNextAppearance].controlAutoPouplate;
              this.Riskassesments[lintIndexCount].activityOwnerdetails = this.Riskassesments[lintNextAppearance].activityOwnerdetails;

              IndexRequiredTobedeleted.push(lintNextAppearance);
            }

          }

        }
        else if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].hazardIgnore == "NA_Ignore" &&
          this.Riskassesments[lintIndexCount].treatIgnore == "NA_Ignore") {
          IndexRequiredTobedeleted.push(lintIndexCount);
        }
      }
      if (lintIndexCount > activityIndex) {

        if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].hazardIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].treatIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].consequenceIgnore == "NA_Ignore") {
          IndexRequiredTobedeleted.push(lintIndexCount);
        }
        else {
          break;
        }
      }
    }

    for (var i = IndexRequiredTobedeleted.length - 1; i >= 0; i--)
      this.Riskassesments.splice(IndexRequiredTobedeleted[i], 1);

    this.getMaximumrisk();
  }
  //end

  //control start
  AddControl(index: number) {
    var controlObj = new RiskAssessmentModel();
    controlObj.activityIgnore = "NA_Ignore";
    controlObj.hazardIgnore = "NA_Ignore";
    controlObj.treatIgnore = "NA_Ignore";
    controlObj.consequenceIgnore = "NA_Ignore";
    var IndextobeAdded = index + 1;
    for (var lintIndexCount = 0; lintIndexCount < this.Riskassesments.length; lintIndexCount++) {
      if (lintIndexCount > index) {
        if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].hazardIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].consequenceIgnore == "NA_Ignore") {
          IndextobeAdded = lintIndexCount;
        }
        else {
          IndextobeAdded = lintIndexCount - 1;
          break;
        }
      }
    }
    //this.Riskassesments.splice(index + 1, 0, controlObj);
    this.Riskassesments.splice(IndextobeAdded + 1, 0, controlObj);
    this.getMaximumrisk();
  }
  delControl(activityIndex: number) {

    var IndexRequiredTobedeleted = [];
    for (var lintIndexCount = 0; lintIndexCount < this.Riskassesments.length; lintIndexCount++) {
      if (activityIndex == lintIndexCount) {
        //condition 1: (current row deletion)
        if (this.Riskassesments[lintIndexCount].activityIgnore != "NA_Ignore"
          || this.Riskassesments[lintIndexCount].hazardIgnore != "NA_Ignore" || this.Riskassesments[lintIndexCount].treatIgnore != "NA_Ignore"
          || this.Riskassesments[lintIndexCount].consequenceIgnore != "NA_Ignore"
        ) {
          this.Riskassesments[lintIndexCount].controlIgnore = "NA_Ignore";
          //Clear the control array object values
          this.Riskassesments[lintIndexCount].ResidualhighestRisk = {};
          this.Riskassesments[lintIndexCount].control = "";
          this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorModule = "";
          this.Riskassesments[lintIndexCount].controlsPeopleIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsAssetsIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsEnvironmentIndicatorId = "";
          this.Riskassesments[lintIndexCount].controlsRetutaionIndicatorId = "";
          this.Riskassesments[lintIndexCount].activityOwnerdetails = "";
          this.Riskassesments[lintIndexCount].controlType = null;
          this.Riskassesments[lintIndexCount].activityOwner = "";
          this.Riskassesments[lintIndexCount].frequencyType = "";


          //logic to find the next occurance of threat
          if (this.Riskassesments[lintIndexCount + 1] != undefined &&
            this.Riskassesments[lintIndexCount + 1].activityIgnore == "NA_Ignore" &&
            this.Riskassesments[lintIndexCount + 1].hazardIgnore == "NA_Ignore" &&
            this.Riskassesments[lintIndexCount + 1].treatIgnore == "NA_Ignore" &&
            this.Riskassesments[lintIndexCount + 1].consequenceIgnore == "NA_Ignore") {
            var lintNextAppearance = null;
            for (var lintTemp = lintIndexCount + 1; lintTemp < this.Riskassesments.length; lintTemp++) {
              if (this.Riskassesments[lintTemp].controlIgnore != "NA_Ignore") {
                lintNextAppearance = lintTemp;
                break;
              }

            }

            if (lintNextAppearance != null) {
              this.Riskassesments[lintIndexCount].control = this.Riskassesments[lintNextAppearance].control;
              this.Riskassesments[lintIndexCount].controlIgnore = this.Riskassesments[lintNextAppearance].controlIgnore;
              this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorId = this.Riskassesments[lintNextAppearance].controlmaximumRiskIndicatorId;
              this.Riskassesments[lintIndexCount].controlmaximumRiskIndicatorModule = this.Riskassesments[lintNextAppearance].controlmaximumRiskIndicatorModule;
              this.Riskassesments[lintIndexCount].controlsPeopleIndicatorId = this.Riskassesments[lintNextAppearance].controlsPeopleIndicatorId;
              this.Riskassesments[lintIndexCount].controlsAssetsIndicatorId = this.Riskassesments[lintNextAppearance].controlsAssetsIndicatorId;
              this.Riskassesments[lintIndexCount].controlsEnvironmentIndicatorId = this.Riskassesments[lintNextAppearance].controlsEnvironmentIndicatorId;
              this.Riskassesments[lintIndexCount].controlsRetutaionIndicatorId = this.Riskassesments[lintNextAppearance].controlsRetutaionIndicatorId;
              //this.Riskassesments[lintIndexCount].hazardAutoPouplate = this.Riskassesments[lintNextAppearance].hazardAutoPouplate;
              this.Riskassesments[lintIndexCount].threatAutoPouplate = this.Riskassesments[lintNextAppearance].threatAutoPouplate;
              this.Riskassesments[lintIndexCount].consequenceAutoPouplate = this.Riskassesments[lintNextAppearance].consequenceAutoPouplate;
              this.Riskassesments[lintIndexCount].controlAutoPouplate = this.Riskassesments[lintNextAppearance].controlAutoPouplate;
              this.Riskassesments[lintIndexCount].activityOwnerdetails = this.Riskassesments[lintNextAppearance].activityOwnerdetails;

              IndexRequiredTobedeleted.push(lintNextAppearance);
            }

          }

        }
        else if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].hazardIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].treatIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].consequenceIgnore == "NA_Ignore") {
          IndexRequiredTobedeleted.push(lintIndexCount);
        }
      }
      if (lintIndexCount > activityIndex) {

        if (this.Riskassesments[lintIndexCount].activityIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].hazardIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].treatIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].consequenceIgnore == "NA_Ignore"
          && this.Riskassesments[lintIndexCount].controlIgnore == "NA_Ignore") {
          IndexRequiredTobedeleted.push(lintIndexCount);
        }
        else {
          break;
        }
      }
    }

    for (var i = IndexRequiredTobedeleted.length - 1; i >= 0; i--)
      this.Riskassesments.splice(IndexRequiredTobedeleted[i], 1);
    this.getMaximumrisk();

  }
  //end
  MaximumRisk = null;
  ConsequenceMaximumRisk: any;
  ControlMaximumRisk: any;
  getMaximumrisk() {
    this.MaximumRisk = null;
    this.ConsequenceMaximumRisk = null;
    this.ControlMaximumRisk = null;

    var arrConsequenceRisksData: any[] = [];
    var arrControlsRisksData: any[] = [];
    this.Riskassesments.forEach((activityKey, activityVal) => {

      if (activityKey.InitialhighestRisk != undefined) {
        if (!activityKey.consequenceIgnore) {
          if (activityKey.InitialhighestRisk.Indicatorclass != undefined) {
            arrConsequenceRisksData.push({
              Indicatorclass: activityKey.InitialhighestRisk.Indicatorclass,
              Indicatorname: activityKey.InitialhighestRisk.Indicatorname,
              Indicatorseverity: activityKey.InitialhighestRisk.Indicatorseverity,
              Indicatortype: activityKey.InitialhighestRisk.Indicatortype,
              IndicatorModule: activityKey.InitialhighestRisk.IndicatorModule
            });
            activityKey.consequencemaximumRiskIndicatorId = activityKey.InitialhighestRisk.Indicatorname;
            activityKey.consequencemaximumRiskIndicatorModule = activityKey.InitialhighestRisk.Indicatortype;
          }
        }
      }


      if (activityKey.ResidualhighestRisk != undefined) {
        if (!activityKey.controlIgnore) {
          if (activityKey.ResidualhighestRisk.Indicatorclass != undefined) {
            arrControlsRisksData.push({
              Indicatorclass: activityKey.ResidualhighestRisk.Indicatorclass,
              Indicatorname: activityKey.ResidualhighestRisk.Indicatorname,
              Indicatorseverity: activityKey.ResidualhighestRisk.Indicatorseverity,
              Indicatortype: activityKey.ResidualhighestRisk.Indicatortype,
              IndicatorModule: activityKey.ResidualhighestRisk.IndicatorModule
            });
            activityKey.controlmaximumRiskIndicatorId = activityKey.ResidualhighestRisk.Indicatorname;
            activityKey.controlmaximumRiskIndicatorModule = activityKey.ResidualhighestRisk.Indicatortype;
          }
        }
      }

    })


    arrConsequenceRisksData.forEach((consKey, consVal) => {
      if (consKey.Indicatortype != undefined && consKey.Indicatortype.toUpperCase() == "PEOPLE") {
        consKey.IndicatorOrder = 1;
      }
      if (consKey.Indicatortype != undefined && consKey.Indicatortype.toUpperCase() == "ASSETS") {
        consKey.IndicatorOrder = 2;
      }
      if (consKey.Indicatortype != undefined && consKey.Indicatortype.toUpperCase() == "ENVIRONMENT") {
        consKey.IndicatorOrder = 3;
      }
      if (consKey.Indicatortype != undefined && consKey.Indicatortype.toUpperCase() == "REPUTATION") {
        consKey.IndicatorOrder = 4;
      }
    })
    arrControlsRisksData.forEach((consKey, consVal) => {
      if (consKey.Indicatortype != undefined && consKey.Indicatortype.toUpperCase() == "PEOPLE") {
        consKey.IndicatorOrder = 1;
      }
      if (consKey.Indicatortype != undefined && consKey.Indicatortype.toUpperCase() == "ASSETS") {
        consKey.IndicatorOrder = 2;
      }
      if (consKey.Indicatortype != undefined && consKey.Indicatortype.toUpperCase() == "ENVIRONMENT") {
        consKey.IndicatorOrder = 3;
      }
      if (consKey.Indicatortype != undefined && consKey.Indicatortype.toUpperCase() == "REPUTATION") {
        consKey.IndicatorOrder = 4;
      }
    })


    arrConsequenceRisksData.sort(
      (b, a) => {
        return (a.IndicatorOrder > b.IndicatorOrder ? -1 : 1);
      });

    arrConsequenceRisksData.sort(
      (a, b) => {
        return (a.Indicatorseverity > b.Indicatorseverity ? -1 : 1);
      });
    if (arrConsequenceRisksData.length > 0) {
      this.ConsequenceMaximumRisk = arrConsequenceRisksData[0];

    }

    arrControlsRisksData.sort(
      (b, a) => {
        return (a.IndicatorOrder > b.IndicatorOrder ? -1 : 1);
      });

    arrControlsRisksData.sort(
      (a, b) => {
        return (a.Indicatorseverity > b.Indicatorseverity ? -1 : 1);
      });
    if (arrControlsRisksData.length > 0) {
      this.ControlMaximumRisk = arrControlsRisksData[0];

    }


  }


  confirmationPopUp() {
    this.confirmationService.confirm({
      message: 'Do you want to delete this record?',
      header: 'Delete Confirmation',
      icon: 'pi pi-info-circle',
      accept: () => {
        this.OkConfirmedClicked(this.ToBeDeletedElementType, this.ToBeDeletedActivityIndex)
        //this.messageService.add({ severity: 'info', summary: 'Confirmed', detail: 'Record deleted' });
      },
      reject: (type: any) => {
        switch (type) {
          case ConfirmEventType.REJECT:
            this.messageService.add({ severity: 'error', summary: 'Rejected', detail: 'You have rejected' });
            break;
          case ConfirmEventType.CANCEL:
            this.messageService.add({ severity: 'warn', summary: 'Cancelled', detail: 'You have cancelled' });
            break;
        }
      }
    });
  }
  //IndicatorModal --- Start
  Indicator: any;
  selectedModule: string = '';
  selectedControl: string = '';
  maximumRiskIndicatorModule: string = '';
  selectedModuleIndicator: string = '';
  IndicatorModal: boolean = false;
  IndicatorUI: any;
  initializeSelectedCode() {
    var selectedCode = { IndicatorId: "", IndicatorGuideline: null, IndicatorDescription: "" }
    return selectedCode;
  }
  showIndicatorModal(consequenceRow: any, selectedControl: string) {
    this.Indicator = consequenceRow;
    this.selectedModule = 'People'; //consequenceRow.maximumRiskIndicatorModule; //Assets/Environment/People/reputation
    this.selectedControl = selectedControl; //control or consequence
    if (consequenceRow.maximumRiskIndicatorModule != undefined && consequenceRow.maximumRiskIndicatorModule != "")
      this.maximumRiskIndicatorModule = consequenceRow.maximumRiskIndicatorModule;
    else
      this.selectedModule = 'People';
    if (selectedControl == 'control') {
      if (this.selectedModule == 'People')
        this.selectedModuleIndicator = 'controlsPeopleIndicatorId';
      if (this.selectedModule == 'Assets')
        this.selectedModuleIndicator = 'controlsAssetsIndicatorId';
      if (this.selectedModule == 'Environment')
        this.selectedModuleIndicator = 'controlsEnvironmentIndicatorId';
      if (this.selectedModule == 'Reputation')
        this.selectedModuleIndicator = 'controlsRetutaionIndicatorId';
    }
    if (selectedControl == 'consequence') {
      if (this.selectedModule == 'People' || this.selectedModule == "")
        this.selectedModuleIndicator = 'consequencePeopleIndicatorId';
      if (this.selectedModule == 'Assets')
        this.selectedModuleIndicator = 'consequenceAssetsIndicatorId';
      if (this.selectedModule == 'Environment')
        this.selectedModuleIndicator = 'consequenceEnvironmentIndicatorId';
      if (this.selectedModule == 'Reputation')
        this.selectedModuleIndicator = 'consequenceRetutaionIndicatorId';
    }
    this.IndicatorModal = true;
    //$('#IndicatorModal').modal({ backdrop: 'static', keyboard: false });

  }
  get_modal_tab_codeVal(consequenceRow: any, selectedModule: string, selectedControl: any) {

    var selectedCode = this.initializeSelectedCode()
    if (selectedControl == 'control') {
      if (selectedModule == 'People')
        selectedCode.IndicatorId = consequenceRow.controlsPeopleIndicatorId;
      if (selectedModule == 'Assets')
        selectedCode.IndicatorId = consequenceRow.controlsAssetsIndicatorId;
      if (selectedModule == 'Environment')
        selectedCode.IndicatorId = consequenceRow.controlsEnvironmentIndicatorId;
      if (selectedModule == 'Reputation')
        selectedCode.IndicatorId = consequenceRow.controlsRetutaionIndicatorId;
    }
    if (selectedControl == 'consequence') {
      if (selectedModule == 'People')
        selectedCode.IndicatorId = consequenceRow.consequencePeopleIndicatorId;
      if (selectedModule == 'Assets')
        selectedCode.IndicatorId = consequenceRow.consequenceAssetsIndicatorId;
      if (selectedModule == 'Environment')
        selectedCode.IndicatorId = consequenceRow.consequenceEnvironmentIndicatorId;
      if (selectedModule == 'Reputation')
        selectedCode.IndicatorId = consequenceRow.consequenceRetutaionIndicatorId;
    }
    if (selectedCode.IndicatorId != undefined && selectedCode.IndicatorId != '') {
      //Code for getting the guide lines
      if (this.filterIndicatorByIndicatorName(selectedCode.IndicatorId).length > 0) {
        selectedCode.IndicatorGuideline = this.filterIndicatorByIndicatorName(selectedCode.IndicatorId)[0].IndicatorGuideline;
        if (selectedModule == "People")
          selectedCode.IndicatorDescription = this.filterIndicatorByIndicatorName(selectedCode.IndicatorId)[0].IndicatorPeopleDescription;
        if (selectedModule == "Assets")
          selectedCode.IndicatorDescription = this.filterIndicatorByIndicatorName(selectedCode.IndicatorId)[0].IndicatorAssetDescription;
        if (selectedModule == "Environment")
          selectedCode.IndicatorDescription = this.filterIndicatorByIndicatorName(selectedCode.IndicatorId)[0].IndicatorEnvironmentDescription;
        if (selectedModule == "Reputation")
          selectedCode.IndicatorDescription = this.filterIndicatorByIndicatorName(selectedCode.IndicatorId)[0].IndicatorReputationDescription;
      }
      selectedCode.IndicatorId = '(' + selectedCode.IndicatorId + ')';
    }
    return selectedCode;
  }
  filterIndicatorByIndicatorName(Indicatorname: string) {
    return this.IndicatorUI.filter((indicator: any) => { return indicator.Indicatorname == Indicatorname });
  }
  modal_tab_click(consequenceRow: any, selectedModule: string, selectedControl: any) {
    this.Indicator = consequenceRow;
    this.selectedModule = selectedModule; //Assets/Environment/People/reputation
    this.selectedControl = selectedControl; //control or consequence
    if (selectedControl == 'control') {
      if (selectedModule == 'People')
        this.selectedModuleIndicator = 'controlsPeopleIndicatorId';
      if (selectedModule == 'Assets')
        this.selectedModuleIndicator = 'controlsAssetsIndicatorId';
      if (selectedModule == 'Environment')
        this.selectedModuleIndicator = 'controlsEnvironmentIndicatorId';
      if (selectedModule == 'Reputation')
        this.selectedModuleIndicator = 'controlsRetutaionIndicatorId';
    }
    if (selectedControl == 'consequence') {
      if (selectedModule == 'People')
        this.selectedModuleIndicator = 'consequencePeopleIndicatorId';
      if (selectedModule == 'Assets')
        this.selectedModuleIndicator = 'consequenceAssetsIndicatorId';
      if (selectedModule == 'Environment')
        this.selectedModuleIndicator = 'consequenceEnvironmentIndicatorId';
      if (selectedModule == 'Reputation')
        this.selectedModuleIndicator = 'consequenceRetutaionIndicatorId';
    }
  }
  Indicator_click(IndicatorCode: string, Indicator: any, selectedModuleIndicator: any, selectedModuleTitle: any) {
    if (selectedModuleIndicator == "consequencePeopleIndicatorId") {
      if (Indicator.consequencePeopleIndicatorId == IndicatorCode) {
        Indicator.consequencePeopleIndicatorId = "";
      }
      else {
        Indicator.consequencePeopleIndicatorId = IndicatorCode;
      }
    }
    else if (selectedModuleIndicator == "consequenceAssetsIndicatorId") {
      //Indicator.consequenceAssetsIndicatorId = IndicatorCode;
      if (Indicator.consequenceAssetsIndicatorId == IndicatorCode) {
        Indicator.consequenceAssetsIndicatorId = "";
      }
      else {
        Indicator.consequenceAssetsIndicatorId = IndicatorCode;
      }
    }
    else if (selectedModuleIndicator == "consequenceEnvironmentIndicatorId") {
      //Indicator.consequenceEnvironmentIndicatorId = IndicatorCode;
      if (Indicator.consequenceEnvironmentIndicatorId == IndicatorCode) {
        Indicator.consequenceEnvironmentIndicatorId = "";
      }
      else {
        Indicator.consequenceEnvironmentIndicatorId = IndicatorCode;
      }
    }
    else if (selectedModuleIndicator == "consequenceRetutaionIndicatorId") {
      //Indicator.consequenceRetutaionIndicatorId = IndicatorCode;
      if (Indicator.consequenceRetutaionIndicatorId == IndicatorCode) {
        Indicator.consequenceRetutaionIndicatorId = "";
      }
      else {
        Indicator.consequenceRetutaionIndicatorId = IndicatorCode;
      }
    }
    else if (selectedModuleIndicator == "controlsPeopleIndicatorId") {
      //Indicator.controlsPeopleIndicatorId = IndicatorCode;
      if (Indicator.controlsPeopleIndicatorId == IndicatorCode) {
        Indicator.controlsPeopleIndicatorId = "";
      }
      else {
        Indicator.controlsPeopleIndicatorId = IndicatorCode;
      }
    }
    else if (selectedModuleIndicator == "controlsAssetsIndicatorId") {
      //Indicator.controlsAssetsIndicatorId = IndicatorCode;
      if (Indicator.controlsAssetsIndicatorId == IndicatorCode) {
        Indicator.controlsAssetsIndicatorId = "";
      }
      else {
        Indicator.controlsAssetsIndicatorId = IndicatorCode;
      }
    }
    else if (selectedModuleIndicator == "controlsEnvironmentIndicatorId") {
      // Indicator.controlsEnvironmentIndicatorId = IndicatorCode;
      if (Indicator.controlsEnvironmentIndicatorId == IndicatorCode) {
        Indicator.controlsEnvironmentIndicatorId = "";
      }
      else {
        Indicator.controlsEnvironmentIndicatorId = IndicatorCode;
      }
    }
    else if (selectedModuleIndicator == "controlsRetutaionIndicatorId") {
      if (Indicator.controlsRetutaionIndicatorId == IndicatorCode) {
        Indicator.controlsRetutaionIndicatorId = "";
      }
      else {
        Indicator.controlsRetutaionIndicatorId = IndicatorCode;
      }
      //Indicator.controlsRetutaionIndicatorId = IndicatorCode;
    }
    this.cdr.detectChanges();




    //This line is only applicable for Organizational Change Project (Created by Roomi)
    //this.ShowRAApprover.emit();
  }
  get_Class_Modal_Selected_Indicator(IndicatorCode: string, Indicator: any, selectedModuleIndicator: any, selectedModuleTitle: string, defaultCSSClass: any) {
    var RAcatSelected = "RAcatSelected";
    if (selectedModuleIndicator == "consequencePeopleIndicatorId" && Indicator.consequencePeopleIndicatorId != undefined
      && Indicator.consequencePeopleIndicatorId != null && Indicator.consequencePeopleIndicatorId == IndicatorCode)
      defaultCSSClass = RAcatSelected;
    else if (selectedModuleIndicator == "consequenceAssetsIndicatorId" && Indicator.consequenceAssetsIndicatorId != undefined
      && Indicator.consequenceAssetsIndicatorId != null && Indicator.consequenceAssetsIndicatorId == IndicatorCode)
      defaultCSSClass = RAcatSelected;
    else if (selectedModuleIndicator == "consequenceEnvironmentIndicatorId" && Indicator.consequenceEnvironmentIndicatorId != undefined
      && Indicator.consequenceEnvironmentIndicatorId != null && Indicator.consequenceEnvironmentIndicatorId == IndicatorCode)
      defaultCSSClass = RAcatSelected;
    else if (selectedModuleIndicator == "consequenceRetutaionIndicatorId" && Indicator.consequenceRetutaionIndicatorId != undefined
      && Indicator.consequenceRetutaionIndicatorId != null && Indicator.consequenceRetutaionIndicatorId == IndicatorCode)
      defaultCSSClass = RAcatSelected;
    else if (selectedModuleIndicator == "controlsPeopleIndicatorId" && Indicator.controlsPeopleIndicatorId != undefined
      && Indicator.controlsPeopleIndicatorId != null && Indicator.controlsPeopleIndicatorId == IndicatorCode)
      defaultCSSClass = RAcatSelected;
    else if (selectedModuleIndicator == "controlsAssetsIndicatorId" && Indicator.controlsAssetsIndicatorId != undefined
      && Indicator.controlsAssetsIndicatorId != null && Indicator.controlsAssetsIndicatorId == IndicatorCode)
      defaultCSSClass = RAcatSelected;
    else if (selectedModuleIndicator == "controlsEnvironmentIndicatorId" && Indicator.controlsEnvironmentIndicatorId != undefined
      && Indicator.controlsEnvironmentIndicatorId != null && Indicator.controlsEnvironmentIndicatorId == IndicatorCode)
      defaultCSSClass = RAcatSelected;
    else if (selectedModuleIndicator == "controlsRetutaionIndicatorId" && Indicator.controlsRetutaionIndicatorId != undefined
      && Indicator.controlsRetutaionIndicatorId != null && Indicator.controlsRetutaionIndicatorId == IndicatorCode)
      defaultCSSClass = RAcatSelected;
    return defaultCSSClass;
  }
  getControlHighestrisk(controlObj: any) {

    var arrAllIndicators = [];
    var IndicatorModule = 'Control';
    if (this.filterIndicatorByIndicatorName(controlObj.controlsPeopleIndicatorId).length > 0) {
      var IndicatorSeverity = this.filterIndicatorByIndicatorName(controlObj.controlsPeopleIndicatorId)[0].Indicatorseverity;
      var Indicatorclass = this.filterIndicatorByIndicatorName(controlObj.controlsPeopleIndicatorId)[0].Indicatorclass;
      arrAllIndicators.push({
        Indicatorname: controlObj.controlsPeopleIndicatorId, Indicatortype: 'People',
        Indicatorseverity: IndicatorSeverity, Indicatorclass: Indicatorclass, IndicatorModule: IndicatorModule
      });
    }
    if (this.filterIndicatorByIndicatorName(controlObj.controlsAssetsIndicatorId).length > 0) {
      var IndicatorSeverity = this.filterIndicatorByIndicatorName(controlObj.controlsAssetsIndicatorId)[0].Indicatorseverity;
      var Indicatorclass = this.filterIndicatorByIndicatorName(controlObj.controlsAssetsIndicatorId)[0].Indicatorclass;
      arrAllIndicators.push({
        Indicatorname: controlObj.controlsAssetsIndicatorId, Indicatortype: 'Assets',
        Indicatorseverity: IndicatorSeverity, Indicatorclass: Indicatorclass, IndicatorModule: IndicatorModule
      });
    }
    if (this.filterIndicatorByIndicatorName(controlObj.controlsEnvironmentIndicatorId).length > 0) {
      var IndicatorSeverity = this.filterIndicatorByIndicatorName(controlObj.controlsEnvironmentIndicatorId)[0].Indicatorseverity;
      var Indicatorclass = this.filterIndicatorByIndicatorName(controlObj.controlsEnvironmentIndicatorId)[0].Indicatorclass;
      arrAllIndicators.push({
        Indicatorname: controlObj.controlsEnvironmentIndicatorId, Indicatortype: 'Environment',
        Indicatorseverity: IndicatorSeverity, Indicatorclass: Indicatorclass, IndicatorModule: IndicatorModule
      });
    }
    if (this.filterIndicatorByIndicatorName(controlObj.controlsRetutaionIndicatorId).length > 0) {
      var IndicatorSeverity = this.filterIndicatorByIndicatorName(controlObj.controlsRetutaionIndicatorId)[0].Indicatorseverity;
      var Indicatorclass = this.filterIndicatorByIndicatorName(controlObj.controlsRetutaionIndicatorId)[0].Indicatorclass;
      arrAllIndicators.push({
        Indicatorname: controlObj.controlsRetutaionIndicatorId, Indicatortype: 'Reputation',
        Indicatorseverity: IndicatorSeverity, Indicatorclass: Indicatorclass, IndicatorModule: IndicatorModule
      });

    }


    arrAllIndicators.sort(
      (a, b) => {
        return (a.Indicatorseverity > b.Indicatorseverity ? -1 : 1);
      });
    if (arrAllIndicators.length > 0) {

      controlObj.ResidualhighestRisk = arrAllIndicators[0];
      //controlObj.maximumRiskIndicatorId = controlObj.highestRisk.Indicatorname;
      //controlObj.maximumRiskIndicatorModule = controlObj.highestRisk.Indicatortype;

      return controlObj.ResidualhighestRisk.Indicatorclass;
    }
    else {
      controlObj.ResidualhighestRisk = {};
      //controlObj.maximumResidualRiskIndicatorId = "";
      //controlObj.maximumResidualRiskIndicatorModule = "";

      return "";
    }
  }
  getConsequenceHighestrisk(consequenceObj: any) {
    var arrAllIndicators = [];
    var IndicatorModule = 'Consequence';
    if (this.filterIndicatorByIndicatorName(consequenceObj.consequencePeopleIndicatorId).length > 0) {
      var IndicatorSeverity = this.filterIndicatorByIndicatorName(consequenceObj.consequencePeopleIndicatorId)[0].Indicatorseverity;
      var Indicatorclass = this.filterIndicatorByIndicatorName(consequenceObj.consequencePeopleIndicatorId)[0].Indicatorclass;
      arrAllIndicators.push({
        Indicatorname: consequenceObj.consequencePeopleIndicatorId, Indicatortype: 'People',
        Indicatorseverity: IndicatorSeverity, Indicatorclass: Indicatorclass, IndicatorModule: IndicatorModule
      });
    }
    if (this.filterIndicatorByIndicatorName(consequenceObj.consequenceAssetsIndicatorId).length > 0) {
      var IndicatorSeverity = this.filterIndicatorByIndicatorName(consequenceObj.consequenceAssetsIndicatorId)[0].Indicatorseverity;
      var Indicatorclass = this.filterIndicatorByIndicatorName(consequenceObj.consequenceAssetsIndicatorId)[0].Indicatorclass;
      arrAllIndicators.push({
        Indicatorname: consequenceObj.consequenceAssetsIndicatorId, Indicatortype: 'Assets',
        Indicatorseverity: IndicatorSeverity, Indicatorclass: Indicatorclass, IndicatorModule: IndicatorModule
      });
    }
    if (this.filterIndicatorByIndicatorName(consequenceObj.consequenceEnvironmentIndicatorId).length > 0) {
      var IndicatorSeverity = this.filterIndicatorByIndicatorName(consequenceObj.consequenceEnvironmentIndicatorId)[0].Indicatorseverity;
      var Indicatorclass = this.filterIndicatorByIndicatorName(consequenceObj.consequenceEnvironmentIndicatorId)[0].Indicatorclass;

      arrAllIndicators.push({
        Indicatorname: consequenceObj.consequenceEnvironmentIndicatorId, Indicatortype: 'Environment',
        Indicatorseverity: IndicatorSeverity, Indicatorclass: Indicatorclass, IndicatorModule: IndicatorModule
      });
    }
    if (this.filterIndicatorByIndicatorName(consequenceObj.consequenceRetutaionIndicatorId).length > 0) {
      var IndicatorSeverity = this.filterIndicatorByIndicatorName(consequenceObj.consequenceRetutaionIndicatorId)[0].Indicatorseverity;
      var Indicatorclass = this.filterIndicatorByIndicatorName(consequenceObj.consequenceRetutaionIndicatorId)[0].Indicatorclass;
      arrAllIndicators.push({
        Indicatorname: consequenceObj.consequenceRetutaionIndicatorId, Indicatortype: 'Reputation',
        Indicatorseverity: IndicatorSeverity, Indicatorclass: Indicatorclass, IndicatorModule: IndicatorModule
      });
    }


    arrAllIndicators.sort(
      (a, b) => {
        return (a.Indicatorseverity > b.Indicatorseverity ? -1 : 1);
      });

    if (arrAllIndicators.length > 0) {
      consequenceObj.InitialhighestRisk = arrAllIndicators[0];
      return consequenceObj.InitialhighestRisk.Indicatorclass;
    }
    else {
      consequenceObj.InitialhighestRisk = {};
      return "";
    }
  }
  //IndicatorModal --- End

  Add_Current_Control(index: number) {
    this.Riskassesments[index].controlIgnore = "";
    this.getMaximumrisk();
  }
  Add_Current_Consequence(index: number) {
    this.Riskassesments[index].controlIgnore = "";
    this.Riskassesments[index].consequenceIgnore = "";
    this.getMaximumrisk();
  }
  Add_Current_Treat(index: number) {
    this.Riskassesments[index].controlIgnore = "";
    this.Riskassesments[index].consequenceIgnore = "";
    this.Riskassesments[index].treatIgnore = "";
    this.getMaximumrisk();
  }
  Add_Current_Hazard(index: number) {
    this.Riskassesments[index].controlIgnore = "";
    this.Riskassesments[index].consequenceIgnore = "";
    this.Riskassesments[index].treatIgnore = "";
    this.Riskassesments[index].hazardIgnore = "";
    this.getMaximumrisk();
  }

  //CUMILATIVE RISK START
  CRAContentList: any[] = [];
  CRAContents: any[] = [];
  CRAContentListHeader: any[] = [];
  CRAContentListSubHeader: any[] = [];

  CRAblueSelected: boolean = false;
  CRAYellowSelected: boolean = false;
  CumulativeRiskAssessmentModal: boolean = false;

  CRAValidationMsg() {
    var text = "";
    this.CRAContentList.forEach((craKey, craIndex) => {

      var CRABlue = craKey.Column.filter((obj: any) => { return obj.Id == 'CRABlue' })[0]
      if (CRABlue != undefined && CRABlue != null && CRABlue.Selected) {
        text = CRABlue.Content
        this.CRAblueSelected = true;
        this.CRAYellowSelected = false;
      }
      else {

        var CRAYellow = craKey.Column.filter((obj: any) => { return obj.Id == 'CRAYellow' })[0]
        if (CRAYellow != undefined && CRAYellow != null && CRAYellow.Selected) {
          text = CRAYellow.Content
          this.CRAYellowSelected = true;
          this.CRAblueSelected = false;
        }

      }

    });
    return text;
  };
  addCumulativePopup() {
    //$scope.GetAllCumulativeRiskAssesmentContent();
    this.CumulativeRiskAssessmentModal = true;
  }
  CalcCumulativeOutcome(row: any) {
    var blueSelected = 0;
    var yellowSelected = 0;
    this.CRAContentList.forEach((craKey, craIndex) => {
      craKey.Column.forEach((obj: any, index: number) => {
        if (obj.Id != row.Id && obj.OppositeId == row.OppositeId) {
          obj.Selected = false;
        }
        if (obj.OppositeId == row.OppositeId && obj.OppositeId != null) {
          obj.Checked = obj.OppositeId == null ? null : row.Selected;
        }
        if (obj.Selected && craKey.IsBlueZone && obj.OppositeId != null) {
          blueSelected = blueSelected + 1;
        }
        if (obj.Selected && craKey.IsYellow && obj.OppositeId != null) {
          yellowSelected = yellowSelected + 1;
        }
      });
    });
    this.CRAContentList.forEach((craKey, craIndex) => {
      var CRABlue = craKey.Column.filter((obj: any) => { return obj.Id == 'CRABlue' })[0]
      if (CRABlue) CRABlue.Selected = blueSelected == this.CRAContentList[0].BlueSelectableTextbox;
      var CRAYellow = craKey.Column.filter((obj: any) => { return obj.Id == 'CRAYellow' })[0]
      if (CRAYellow) CRAYellow.Selected = yellowSelected > 0 ?
        (blueSelected + yellowSelected) == this.CRAContentList[0].YellowSelectableTextbox : false;
    });




    //This line is only applicable for Organizational Change Project (Created by Roomi)
    //this.ShowRAApprover.emit();
  }
  ValidateCRA_clicked() {
    var isValid = true;
    var blueSelected = 0;
    var yellowSelected = 0;
    if (this.CRAContentList == null || this.CRAContentList == undefined || this.CRAContentList.length < 1)
      return !isValid;
    this.CRAContentList.forEach((craKey, craIndex) => {
      craKey.Column.forEach((craKey1: any) => {
        if ((craKey1.Checked == undefined || craKey1.Checked == false) && craKey1.OppositeId != null) isValid = false;
        if (craKey1.OppositeId != null) craKey1.highlightNotSelected = !craKey1.Checked;
      })
    });
    return isValid;
  }
  //CUMILATIVE RISK END

  ValidateRiskAssesment() {
    var arrProcessed = [];
    var arrRawJson = [];

    var arrActivityRows = Object.assign(this.Riskassesments);
    arrActivityRows = [];
    arrActivityRows.forEach((activityKey: any, activityVal: any) => {
      activityKey.activityError = "";
      activityKey.hazardError = "";
      activityKey.consequenceError = "";
      activityKey.threatError = "";
      activityKey.controlError = "";
      activityKey.consequenceRetutaionError = "";
      activityKey.ControlIndicatorError = "";
      activityKey.controlTypeError = "";
      activityKey.activityOwnerError = "";
      activityKey.frequencyTypeError = "";
      activityKey.activityOwnerdetailsError = "";

    });


    arrRawJson.push({ activityRows: arrActivityRows });
    var jsonRawFinal = Object.assign(arrRawJson);

    this.Riskassesments.forEach((activityKey: any, activityVal: any) => {
      //(take towards forward)
      var isIndicatorAdded = false;
      var arrIndicatorStatus = [];
      for (var lintForwardRows = activityVal; lintForwardRows < this.Riskassesments.length; lintForwardRows++) {
        if (this.Riskassesments[lintForwardRows].controlsPeopleIndicatorId !== "" ||
          this.Riskassesments[lintForwardRows].controlsAssetsIndicatorId !== "" ||
          this.Riskassesments[lintForwardRows].controlsEnvironmentIndicatorId !== "" ||
          this.Riskassesments[lintForwardRows].controlsRetutaionIndicatorId !== "") {
          isIndicatorAdded = true;
        }
        arrIndicatorStatus.push(lintForwardRows);
        if (this.Riskassesments[lintForwardRows + 1] != undefined && this.Riskassesments[lintForwardRows + 1].consequenceIgnore != "NA_Ignore") {
          break;
        }
      }

      var lintPosition = 0;
      //(take towards backward)
      //condition 1: Current starting position to consequence ignore
      //condition 2: Next to the starting position is consequence ignore stop there itself
      for (var lintBackwardRows = activityVal; lintBackwardRows >= 0; lintBackwardRows--) {

        if (this.Riskassesments[lintBackwardRows].controlIgnore == "NA_Ignore" ||
          this.Riskassesments[lintBackwardRows].controlsPeopleIndicatorId !== "" ||
          this.Riskassesments[lintBackwardRows].controlsAssetsIndicatorId !== "" ||
          this.Riskassesments[lintBackwardRows].controlsEnvironmentIndicatorId !== "" ||
          this.Riskassesments[lintBackwardRows].controlsRetutaionIndicatorId !== "") {
          isIndicatorAdded = true;
        }
        arrIndicatorStatus.push(lintBackwardRows);

        if (lintPosition == 0 && this.Riskassesments[lintBackwardRows].consequenceIgnore != "NA_Ignore") {
          break;
        }

        //Reached the final position
        if (this.Riskassesments[lintBackwardRows].consequenceIgnore != "NA_Ignore") {
          break;
        }
        lintPosition += 1;
      }

    });


    //Highlight the error
    this.Riskassesments.forEach((activityKey: any, activityVal: any) => {
      activityKey.activityError = activityKey.activityIgnore !== "NA_Ignore" && activityKey.task == "" ? "validation-err" : "";
      activityKey.hazardError = activityKey.hazardIgnore !== "NA_Ignore" && activityKey.hazard == "" ? "validation-err" : "";
      activityKey.consequenceError = activityKey.consequenceIgnore !== "NA_Ignore" && activityKey.consequence == "" ? "validation-err" : "";
      activityKey.threatError = activityKey.treatIgnore !== "NA_Ignore" && activityKey.treat == "" ? "validation-err" : "";
      activityKey.controlError = activityKey.controlIgnore !== "NA_Ignore" && activityKey.control == "" ? "validation-err" : "";

      activityKey.consequenceRetutaionError = activityKey.consequenceIgnore !== "NA_Ignore" && activityKey.consequencePeopleIndicatorId == "" &&
        activityKey.consequenceAssetsIndicatorId == "" &&
        activityKey.consequenceEnvironmentIndicatorId == "" &&
        activityKey.consequenceRetutaionIndicatorId == "" ? "validation-err" : "";

      activityKey.ControlIndicatorError = activityKey.controlIgnore !== "NA_Ignore" && activityKey.controlsPeopleIndicatorId == "" &&
        activityKey.controlsAssetsIndicatorId == "" &&
        activityKey.controlsEnvironmentIndicatorId == "" &&
        activityKey.controlsRetutaionIndicatorId == "" ? "validation-err" : "";


      activityKey.controlTypeError = activityKey.controlIgnore !== "NA_Ignore" && (activityKey.controlType == null || activityKey.controlType == undefined || activityKey.controlType == "") ? "validation-err" : "";
      activityKey.activityOwnerError = activityKey.controlIgnore !== "NA_Ignore" && (activityKey.activityOwner == null || activityKey.activityOwner == undefined || activityKey.activityOwner == "") ? "validation-err" : "";
      activityKey.frequencyTypeError = activityKey.controlIgnore !== "NA_Ignore" && (activityKey.frequencyType == null || activityKey.frequencyType == undefined || activityKey.frequencyType == "") ? "validation-err" : "";
      activityKey.activityOwnerdetailsError = activityKey.controlIgnore !== "NA_Ignore" && (activityKey.activityOwnerdetails == null || activityKey.activityOwnerdetails == undefined || activityKey.activityOwnerdetails == "") ? "validation-err" : "";



      //(take towards forward)
      var isIndicatorAdded = false;
      var arrIndicatorStatus = [];
      for (var lintForwardRows = activityVal; lintForwardRows < this.Riskassesments.length; lintForwardRows++) {
        if (this.Riskassesments[lintForwardRows].controlsPeopleIndicatorId !== "" ||
          this.Riskassesments[lintForwardRows].controlsAssetsIndicatorId !== "" ||
          this.Riskassesments[lintForwardRows].controlsEnvironmentIndicatorId !== "" ||
          this.Riskassesments[lintForwardRows].controlsRetutaionIndicatorId !== "") {
          isIndicatorAdded = true;
        }
        arrIndicatorStatus.push(lintForwardRows);
        if (this.Riskassesments[lintForwardRows + 1] != undefined && this.Riskassesments[lintForwardRows + 1].consequenceIgnore != "NA_Ignore") {
          break;
        }
      }

      var lintPosition = 0;
      //(take towards backward)
      //condition 1: Current starting position to consequence ignore
      //condition 2: Next to the starting position is consequence ignore stop there itself
      for (var lintBackwardRows = activityVal; lintBackwardRows >= 0; lintBackwardRows--) {

        if (this.Riskassesments[lintBackwardRows].controlsPeopleIndicatorId !== "" ||
          this.Riskassesments[lintBackwardRows].controlsAssetsIndicatorId !== "" ||
          this.Riskassesments[lintBackwardRows].controlsEnvironmentIndicatorId !== "" ||
          this.Riskassesments[lintBackwardRows].controlsRetutaionIndicatorId !== "") {
          isIndicatorAdded = true;
        }
        arrIndicatorStatus.push(lintBackwardRows);

        if (lintPosition == 0 && this.Riskassesments[lintBackwardRows].consequenceIgnore != "NA_Ignore") {
          break;
        }

        //Reached the final position
        if (this.Riskassesments[lintBackwardRows].consequenceIgnore != "NA_Ignore") {
          break;
        }
        lintPosition += 1;
      }

      //change the status of control indicator error
      if (isIndicatorAdded) {
        for (var lintIndicatorStatusCount = 0; lintIndicatorStatusCount < arrIndicatorStatus.length; lintIndicatorStatusCount++) {
          if (this.Riskassesments[arrIndicatorStatus[lintIndicatorStatusCount]].ControlIndicatorError != undefined)
            this.Riskassesments[arrIndicatorStatus[lintIndicatorStatusCount]].ControlIndicatorError = "";
        }
      }



    })

    var isError = false;

    this.Riskassesments.forEach((activityKey: any, activityVal: any) => {
      if (activityKey.activityError == "validation-err" ||
        activityKey.hazardError == "validation-err" ||
        activityKey.consequenceError == "validation-err" ||
        activityKey.threatError == "validation-err" ||
        activityKey.controlError == "validation-err" ||
        activityKey.consequenceRetutaionError == "validation-err" ||
        activityKey.ControlIndicatorError == "validation-err" ||
        //activityKey.controlTypeError == "validation-err" ||
        activityKey.frequencyTypeError == "validation-err" ||
        activityKey.activityOwnerError == "validation-err" ||
        activityKey.activityOwnerdetailsError == "validation-err") {
        isError = true;
      }
    })

    return isError

  }


  //pass ControlMaximumRisk.Indicatorname to get MaxResidualRisk
  //pass ConsequenceMaximumRisk.Indicatorname to get MaxInitialRisk
  Get_Risk_Type_Code(IndicatorCode: string) {
    debugger;
    if (IndicatorCode != undefined && IndicatorCode != null) {
      var arrRisks = this.IndicatorUI.filter((Indicator: any) => { return Indicator.Indicatorname == IndicatorCode });
      if (arrRisks.length > 0) {
        return arrRisks[0].Risk;
      }

    }
  }

  // To get CumilativeRiskAssesmentName
  GetselectedCumulativeRating () {
    var CumulativeRating = "";
    var keepGoing = true;
    this.CRAContentList.forEach((craKey: any, craIndex: number) => {
      if (keepGoing) {
        var CRABlue = craKey.Column.filter((obj: any) => { return obj.Id == 'CRABlue' })[0]
        if (CRABlue != undefined && CRABlue.Selected) {
          CumulativeRating = 'Blue';
          keepGoing = false;
        } else {
          CumulativeRating = 'Orange'
          keepGoing = false;
        }
      }
    });
    return CumulativeRating
  }

  //hazard auto complete
  selectedHazard: any
  completeHazard_AutoPopupate(hazardObj: RiskAssessmentModel, hazard: string, indexVal: number) {
    hazard = CommonFunctions.stringtrimStartEnd(hazard);
    if (hazard) {
      this._HttpService.Get("Master/GetRAHazardByName", [hazard.toString()]).subscribe(response => {
        hazardObj.hazardFilteredAutoPopulateDS = [];

        response.forEach((hazard: any) => {
          if (hazard.Name.toLowerCase().indexOf(hazardObj.hazard.toLowerCase()) >= 0) {
            hazardObj.hazardFilteredAutoPopulateDS.push({ HazardName: hazard.Name, HazardId: hazard.Id });
          }
        });
        if (this.selectedHazard != null || this.selectedHazard != undefined)
          this.selectedHazard.HazardId = 0;
      });

    }
  }
  fillHazardTextbox(filteredObj: any, hazardObj: RiskAssessmentModel) {
    hazardObj.hazard = filteredObj.HazardName;
    this.selectedHazard = filteredObj;
    hazardObj.hazardFilteredAutoPopulateDS = [];
  }
  hazard_selected( hazardObj: RiskAssessmentModel) {
    setTimeout(() => {
      hazardObj.hazardFilteredAutoPopulateDS = [];
    },200)
  }

  //treat autocomplete
  completeTreat_AutoPopupate(treatObj: RiskAssessmentModel, indexVal: number) {
    if (treatObj.treat && this.selectedHazard != null) {
      this._HttpService.Get1("Master/GetRAHazardEffectByName", {HazardId:this.selectedHazard.HazardId, EffectName: treatObj.treat}).subscribe((response: any[]) => {
        treatObj.treatFilteredAutoPopulateDS = [];
        response.forEach(treat => {
          if (treat.Name.toLowerCase().indexOf(treatObj.treat.toLowerCase()) >= 0) {
            treatObj.treatFilteredAutoPopulateDS.push({ TreatName: treat.Name, TreatId: treat.Id });
          }
        });
      })
    }
  }
  treat_selected(treatObj: RiskAssessmentModel) {
    setTimeout(() => {
      treatObj.treatFilteredAutoPopulateDS = [];
    }, 200)
  }
  fillTreatTextbox(filteredObj: any, treatObj: RiskAssessmentModel) {
    treatObj.treat = filteredObj.TreatName;
    treatObj.treatFilteredAutoPopulateDS = [];
  }

  //control autocomplete
  completeControl_AutoPopupate(controlObj: RiskAssessmentModel, indexVal: number) {
    if (controlObj.control != '' && controlObj.control != undefined && controlObj.control != null) {
      var hazardId = this.selectedHazard == undefined || this.selectedHazard == null ? 0 : this.selectedHazard.HazardId;
      this._HttpService.Get1("Master/GetRAControlMeasureByName", { HazardId: hazardId, EffectName: controlObj.control }).subscribe((response: any[]) => {
        controlObj.controlFilteredAutoPopulateDS = [];
        response.forEach(control => {
          if (control.Name.toLowerCase().indexOf(controlObj.control.toLowerCase()) >= 0) {
            controlObj.controlFilteredAutoPopulateDS.push({ ControlName: control.Name, ControlId: control.Id });
          }
        })

      })
    }

  }
  control_selected(controlObj: RiskAssessmentModel) {
    //controlObj.controlFilteredAutoPopulateDS = [];
    setTimeout(() => {
      controlObj.controlFilteredAutoPopulateDS = [];
    }, 200)

  }
  fillControlTextbox(filteredObj: any, controlObj: RiskAssessmentModel) {
    controlObj.control = filteredObj.ControlName;
    controlObj.controlFilteredAutoPopulateDS = [];
  }


   ControlOwners_GetAll() {
    //HttpHelper.GetAll("RiskAssesment/GetControlOwners")
    //  .then(function (response) {

    //    if (response.data != undefined && response.data != null) {
    //      $scope.activityOwnerlist = response.data;

    //    }
    //  }, function (error) {
    //    AlertHelper.Error(error.data);
    //    deferred.reject();
    //  });
  }


  GetActiveRAControlType() {
    this._HttpService.GetAll("Master/GetActiveRAControlType").subscribe(res => {
      this.controlTypelist = res;
    });
  }

  GetFrequenctType() {
    this._HttpService.GetAll("Master/GetFrequency").subscribe(res => {
      this.frequencyTypelist = res;
    });
  }


  activityOwnerlist: any[] = [];
  completeActivityOwner_AutoPopupate(controlObj: RiskAssessmentModel) {
    controlObj.activityOwnerlist = [];
    this.activityOwnerlist.forEach(control => {
      if (control != undefined && controlObj != undefined && controlObj.activityOwner != undefined && control.Name.toLowerCase().indexOf(controlObj.activityOwner.toLowerCase()) >= 0) {
        controlObj.activityOwnerlist.push(control);
      }
    });

  }

  GetActiveRAControlOwnerRole() {
    this._HttpService.GetAll("Master/GetActiveRAControlOwnerRole").subscribe(res => {
      this.activityOwnerlist = res;
    });
  }
  activityOwnerdetails_selected(controlObj: RiskAssessmentModel) {
    setTimeout(() => {
      controlObj.activityOwnerlist = [];
    }, 300)

  }
  fillTESTActivityOwnerTextbox(filteredObj: any, controlObj: RiskAssessmentModel) {
    controlObj.activityOwner = filteredObj.Name;
    controlObj.activityOwnerlist = [];
  }

  SearchUser(event: any): void {

    if (this.userSearchSubscribe) {

      this.userSearchSubscribe.unsubscribe();
    }

    this.userSearchSubscribe = this._HttpService.Get("Common/SearchUser", [event.query]).subscribe(res => {

      this.userDetails = res;
    });
  }

  copyRA() {

    this.CopyRA = true;
    this.copyrequestno = '';
  }

  SearchRequestForCopy(event: any): void {
    var requestId = CommonFunctions.removeSpaceFromString(event.query);
    console.log(requestId);
    if (CommonFunctions.containsOnlyNumbers(requestId)) {

      if (this.CopyRequestSearchSubscribe) {

        this.CopyRequestSearchSubscribe.unsubscribe();
      }

      this.CopyRequestSearchSubscribe = this._HttpService.Get("Request/GetRequestId", [event.query]).subscribe(res => {

        this.CopyRequestList = res;
      });
    }
  }

  GetRAByRequestID() {
    debugger;
    console.log(this.copyrequestno)
    this._HttpService.Get("Request/GetRiskAssessmentByRequestId", [this.copyrequestno.Label.toString()]).subscribe(res => {
      if (res.RAMatrix)
        this.CopyRiskassesmentsList = JSON.parse(res.RAMatrix);
      else
        this.CopyRiskassesmentsList = new Array<RiskAssessmentModel>();
      console.log(this.CopyRiskassesmentsList);
    });
  }



  AddToRA() {

    this.Riskassesments = this.Riskassesments.concat(this.CopyRiskassesmentsList);

      this.messageService.add({ severity: CommonFunctions.MessageStatus(0), detail: 'RA has been copied successfully.. please close the popup' });
      this.CopyRiskassesmentsList = [];

      //This line is only applicable for Organizational Change Project (Created by Roomi)
     // this.ShowRAApprover.emit();
  }

    omit_special_char(event: any) {

        if(event.charCode == 47 || event.charCode == 92) return false // Remove Slash and Backslash
        else return true;
    }
}
