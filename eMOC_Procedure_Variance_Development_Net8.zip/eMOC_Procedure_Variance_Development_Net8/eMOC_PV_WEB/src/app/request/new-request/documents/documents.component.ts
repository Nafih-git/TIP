import { Component, Input, OnInit } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { WorkStatusEnum } from 'src/app/enums/workFlow-status_enum';
import { DocumentTypeModel } from 'src/app/models/documentType_model';
import { RequestModel } from 'src/app/models/request_model';
import { DocumentsModels } from '../../../models/documents_model';
import { CommonFunctions } from '../../../utility/common/common-functions';
import { HttpService } from '../../../utility/http.service';
import { LoggedUserService } from '../../../utility/service/logged-user.service';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.css']
})
export class DocumentsComponent implements OnInit {
  @Input() request: RequestModel = new RequestModel();
  constructor(private _loggedUserService: LoggedUserService,private _HttpService: HttpService, private confirmationService: ConfirmationService, private messageService: MessageService) { }

  documentList: DocumentsModels[] = [];
  isSaveClicked: boolean = false;
  disableCtrls: boolean = false;
  acceptedFiles: string = ".ppt, .pptx, .doc, .docx, .xls, .xlsx, .pdf, .txt, .msg";
  DocTypeList : DocumentTypeModel[] = [];
  ngOnInit(): void {

    this.GetAllowedDocsExtension();

  }



  DisableField(): boolean {
    var disable: boolean = true;
    if(this.request.IseMOCHistory){
      disable = true;
    }
    else if (this.request.Id == 0 || this.request.WorkflowStatusId == WorkStatusEnum.Drafted || (this.request.WorkflowStatusId == WorkStatusEnum.Pending_for_Rework)) {
      disable = false;
    }
    return disable;
  }
  GetAllowedDocsExtension() {

    this._HttpService.GetAll("Common/GetAllowedFileExtensions").subscribe(res => {

      this.acceptedFiles = res.AllowedExtension;
    });
  }

  DeleteDocument(row: DocumentsModels, index: number) {

    if (row.Guid != null && row.Guid != "") {

      this.confirmationService.confirm({

        message: 'Selected file will be deleted permanently. Are you sure to proceed?',
        header: 'Delete File',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {

          this.DeleteFile(row);
        },
        reject: (type: any) => {}
      });
    }
    else
      this.documentList.splice(index, 1);
  }

  DeleteFile(row: DocumentsModels) {

    this._HttpService.Post("Common/DeleteFile", row).subscribe(res => {

      this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
    });
  }

  onSelectEvent(row: DocumentsModels, event: any) {

    if (event.currentFiles && event.currentFiles.length > 0) {

      row.File = event.files[0];
      row.FileName = event.files[0].name;
      if (event.files[0].name !== null && event.files[0].name !== undefined && event.files[0].name.endsWith(".msg")) {

        row.MimeType = "application/vnd.ms-outlook";
      }
      else
        row.MimeType = event.files[0].type;
    }
  }

  isValid() {

    var valid = true;
    this.isSaveClicked = true;

    if (this.documentList.length > 0) {

      var data = this.documentList.filter(s => s.Comment == "" || s.FileName == "" || s.FileName == null);

      valid= !(data.length > 0);
    }

    return valid;
  }



  DownloadFile(row: DocumentsModels) {
console.log(row);
    this._HttpService.Get1("Request/DownloadRequestDocument", {FileName : row.Guid}).subscribe(res => {
console.log(res);
      CommonFunctions.downloadFile("data:" + res.ContentType + ";base64," + res.FileContents, row.MimeType, row.FileName, null);
    });
  }
}
