import { AfterViewInit, Input, Output, ViewChild } from '@angular/core';
import { Component, OnInit, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MessageService, SelectItem } from 'primeng/api';
import { Dropdown } from 'primeng/dropdown';
import { WorkStatusEnum } from 'src/app/enums/workFlow-status_enum';
import { AssetModel } from 'src/app/models/asset_model';

import { DirectorateModel } from 'src/app/models/directorate_model';

import { FacilityModel } from 'src/app/models/facility_model';

import { UserDetailModel } from 'src/app/models/user-detail_model';
import { LoggedUserService } from 'src/app/utility/service/logged-user.service';
import { GeneralModel, RequestModel } from '../../../models/request_model';
import { HttpService } from '../../../utility/http.service';
import { ReasonVarianceModel } from 'src/app/models/reason_varience';
import { CMSProcedure } from 'src/app/models/cms_procedure';
import { AutoComplete } from 'primeng/autocomplete';
import { CommonFunctions } from 'src/app/utility/common/common-functions';


@Component({
  selector: 'app-request-general-details',
  templateUrl: './request-general-details.component.html',
  styleUrls: ['./request-general-details.component.css']
})
export class RequestGeneralDetailsComponent implements OnInit {

  @Input() request: RequestModel = new RequestModel();
  @ViewChild('autocomplete')
  autocomplete  = AutoComplete;
  @ViewChild("generalForm") generalForm!: NgForm;
  Workflowsteps: any;
  generalDetails: GeneralModel = new GeneralModel();
  isSaveClicked: boolean = false;
  RAApproverUsers : UserDetailModel[] = [];
  directorateList: DirectorateModel[] = [];
  TechnicalApproverList: DirectorateModel[] = [];
  FunctionalReviwersList: DirectorateModel[] = [];
  loading : boolean = false;
  reasonvarienceList: ReasonVarianceModel[] = [];
  selectedProcedure: CMSProcedure = new CMSProcedure() ;
  cmsProcedureList: CMSProcedure[] = [];
  FunctionalReviewer !:  UserDetailModel;
  TechnicalApprover !:  UserDetailModel;
  raApprover : string = "";
  assetList: AssetModel[] = [];
  cockpitList: any[] = [];
  Approver1List: any[] = [];
  facilityList: FacilityModel[] = [];
  IsVisioFile : boolean = false;
  userList: any[] = [];
  userDetails: UserDetailModel[] = new Array<UserDetailModel>();
  userSearchSubscribe: any;
  procedureSearchSubscribe: any;
  competentMessage: string = '';
  minFromDate: Date = new Date();
  minToDate!: Date;
  maxToDate !: Date;
  facilitystr !: string;
  staticText: any;
  approverRole: string = "";
  approverRoleId: number = 0;
  IsToIOCRequest: boolean = false;
  @Output() GetWorkflowStepsEvent = new EventEmitter<any>();

  @Output() ShowDialogModelEvent = new EventEmitter<any>();
  workStatusEnum() { typeof WorkStatusEnum; return WorkStatusEnum }


  constructor(private _loggedUserService: LoggedUserService, private activatedRoute: ActivatedRoute, private _HttpService: HttpService, private messageService: MessageService) { }

  ngOnInit(): void {

    this.GetStaticText();
    this.GetDirectorate();
    this.GetResonVariance();
    var id = this.activatedRoute.snapshot.paramMap.get('id');
    let requestId = id ? +id : 0;


if(requestId == 0){
  this.GetWorkflowSteps(false);


}

  }


  async GetStaticText() {
    this._HttpService.GetStaticText().subscribe(res => {

      this.staticText = res;

    });
  }


  selectProcedure(event: any) {
this.generalDetails.IsManual = 0;

 if(event){
this.GetFunctionalReviwers(event.FunctionalReviewer);
this.GetTechnicalApprovers(event.TechnicalApprover);
this.generalDetails.ProcedureLink = event.Link;
this.generalDetails.ProcedureTitle = event.ProcedureTitle;
this.generalDetails.ProcedureCode = event.ProcedureCode;
this.generalDetails.ProcedureDisplayName = event.ProcedureTitle;
    }


    this.CheckIsVisioFile(this.generalDetails.ProcedureLink);
  }

  Procedureblur(procedure: any) {
    if(this.generalDetails.IsManual){
      this.generalDetails.ProcedureDisplayName = procedure.toString();
      this.generalDetails.ProcedureTitle = procedure.toString();
    }
  }
  GetTechnicalApprovers(RefrenceIdicator: string) {

      this.loading = true;
      this._HttpService.Get("Common/GetUserListByRefrenceIndicator", [RefrenceIdicator]).subscribe(res => {

        this.TechnicalApproverList = res;

        this.loading = false;

      });



      }
  GetFunctionalReviwers(RefrenceIdicator: string) {

          this.loading = true;
          this._HttpService.Get("Common/GetUserListByRefrenceIndicator", [RefrenceIdicator]).subscribe(res => {

            this.FunctionalReviwersList = res;

            this.loading = false;
          });
          }
  AutoComplateProcedure(event: any) {

    if(event.query){
      this.loading = true;
      if (this.procedureSearchSubscribe) {

        this.procedureSearchSubscribe.unsubscribe();
      }

      this.procedureSearchSubscribe = this._HttpService.Get("Common/SearchCMSProcedure", [event.query]).subscribe(res => {

        this.cmsProcedureList = res;
        this.loading = false;

      });
      return true;
    }
    else{
      return false;
    }

      }


  async GetDirectorate() {
    return new Promise(resolve => {
      this._HttpService.GetAll("Master/GetDirectorates").subscribe(res => {
        this.directorateList = res;
        resolve("Success");
      });
    });
  }

  GetWorkflowSteps(isFromChangeEvent: boolean = true) {

      this._HttpService.Get1("Request/GetWorkflowSteps", { RequestId: this.request.Id }).subscribe(res => {
        this.approverRoleId = res[0].ApproverRoleId;
        this.approverRole = res[0].ApproverRoleName;
        this.Workflowsteps = res;
        this.CallEventEmitter();
      });

  }

  CallEventEmitter() {
    this.GetWorkflowStepsEvent.emit(this.Workflowsteps);
  }

  // async GeteMOCTypes() {
  //   return new Promise(resolve => {
  //     this._HttpService.GetAll("Master/GetActiveEmocTypes").subscribe(res => {
  //       this.eMOCTypesList = res;
  //       resolve("Success");
  //     });
  //   });
  // }

  async GetResonVariance() {
    return new Promise(resolve => {
      this._HttpService.GetAll("Master/GetActiveReasonVariance").subscribe(res => {
        this.reasonvarienceList = res;
        resolve("Success");
      });
    });
  }



   GetAsset(ischangeevent : boolean = true) {
    if(ischangeevent){
      this.generalDetails.Asset = "";

    }

    this.assetList = [];
    this.facilityList = [];


    return new Promise(resolve => {
      this._HttpService.Get1("Master/GetAssets", { Directorate: this.generalDetails.Directorate }).subscribe(res => {
        this.assetList = res;

        resolve("Success");
      });
    });
  }

   GetFacility(ischangeevent : boolean = true) {
    if(ischangeevent){

    }

    this.facilityList = [];

    this._HttpService.Get1("Master/GetFacilities", { Asset: this.generalDetails.Asset, Directorate: this.generalDetails.Directorate }).subscribe(res => {
      this.facilityList = res;
      this.CallEventEmitter();
    });
  }




  SelectStartDate() {
    debugger;
    if (!this.generalDetails.ToDate || (this.generalDetails.FromDate && this.generalDetails.FromDate > this.generalDetails.ToDate)) {
      this.generalDetails.ToDate = this.generalDetails.FromDate;

      this.minToDate = this.generalDetails.FromDate as Date;
      this.maxToDate = new Date();

      this.maxToDate =  new Date((this.generalDetails.FromDate as Date).getTime() +  (180 * 24 * 60 * 60 * 1000)); // 180 Days Validation

      // this.maxToDate.setDate((this.generalDetails.FromDate as Date ).getTime() +  (180 * 24 * 60 * 60 * 1000));
      this.generalDetails.ToDate = this.generalDetails.FromDate as Date;
    }
  }

  SelectEndDate() {
    if (!this.generalDetails.FromDate || (this.generalDetails.ToDate && this.generalDetails.FromDate > this.generalDetails.ToDate)) {
      this.generalDetails.FromDate = this.generalDetails.ToDate;
    }
  }


  SearchUser(event: any): void {

    if (this.userSearchSubscribe) {

      this.userSearchSubscribe.unsubscribe();
    }

    this.userSearchSubscribe = this._HttpService.Get("Common/SearchUser", [event.query]).subscribe(res => {

      this.userDetails = res;
    });
  }

  ChangeMode(){
  this.generalDetails.IsManual = 1;
  this.generalDetails.FunctionalReviewer ='';
  this.generalDetails.TechnicalApprover = ''
  this.generalDetails.ProcedureLink='';
  }
  isValid() {
    debugger;
    this.isSaveClicked = true;
    console.log(this.generalForm.form)
    let isValid = this.generalForm.valid;
    return isValid;
  }

  DisableField(): boolean {
    var disable: boolean = true;
    if(this.request.IseMOCHistory){
      disable = true;
    }
    else if (this.request.Id == 0 || this.request.WorkflowStatusId == WorkStatusEnum.Drafted || (this.request.WorkflowStatusId == WorkStatusEnum.Pending_for_Rework)) {
      disable = false;
    }
    return disable;
  }

  searchUser(event: any): void {

    if (this.userSearchSubscribe) {

      this.userSearchSubscribe.unsubscribe();
    }

    this.userSearchSubscribe = this._HttpService.Get("Common/SearchUser", [event.query]).subscribe(res => {

      this.userDetails = res;
    });
  }

  FunctionalReviewerSelect(event: any) {

    this.generalDetails.FunctionalReviewer = event.PersonalNumber;
  }

  TechnicalApproverSelect(event: any) {

    this.generalDetails.TechnicalApprover = event.PersonalNumber;
  }

  ChangeFunctionalReviewer(){

    this.generalDetails.FunctionalReviewer ='';

    }
    ChangeTechnicalApprover(){

      this.generalDetails.TechnicalApprover = ''

      }

      CheckIsVisioFile(FileName :string){
       this.IsVisioFile = CommonFunctions.IsVisioFile(FileName);

      }

      GoToVisioViewer(FileName: string){
        let VIsioFileName = CommonFunctions.GetVisioFileName(FileName);
        let CMSVisioViwer = this.staticText.VisioViewerForCMS + VIsioFileName;

        window.open(CMSVisioViwer, "_blank");
    }





}
