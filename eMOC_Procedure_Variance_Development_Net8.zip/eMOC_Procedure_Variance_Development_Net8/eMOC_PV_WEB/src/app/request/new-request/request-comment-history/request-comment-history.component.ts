import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-comment-history',
  templateUrl: './request-comment-history.component.html',
  styleUrls: ['./request-comment-history.component.css']
})
export class RequestCommentHistoryComponent implements OnInit {

  commentHistory: any[] = [
    { role: 'Production Coordinator', name: 'Qarni, Mohammed OSO1B', date: '', comment: 'Walk the line please & update LO/LC register' },
    { role: 'OI Coordinator', name: 'Harthy, Abdul Rahim OSO16B', date: '', comment: 'Walk the line please & update LO/LC register' },
    { role: 'Delivery Team Lead (DTL)', name: 'Balushi, Najim OSOB', date: '', comment: 'Walk the line please & update LO/LC register' },
    { role: 'Operation Manager (or Authorised Delegate)', name: 'Harrasi, Ali OSO', date: '', comment: 'Walk the line please & update LO/LC register' },
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
