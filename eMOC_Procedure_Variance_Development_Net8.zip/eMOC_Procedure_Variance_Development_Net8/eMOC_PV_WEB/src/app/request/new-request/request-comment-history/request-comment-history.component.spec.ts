import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestCommentHistoryComponent } from './request-comment-history.component';

describe('RequestCommentHistoryComponent', () => {
  let component: RequestCommentHistoryComponent;
  let fixture: ComponentFixture<RequestCommentHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestCommentHistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestCommentHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});