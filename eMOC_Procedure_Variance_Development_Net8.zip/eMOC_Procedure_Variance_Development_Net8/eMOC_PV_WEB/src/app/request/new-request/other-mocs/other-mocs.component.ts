import { Component, OnInit } from '@angular/core';
import { OtherMOCs } from 'src/app/models/othermoc_model';

@Component({
  selector: 'app-other-mocs',
  templateUrl: './other-mocs.component.html',
  styleUrls: ['./other-mocs.component.css']
})
export class OtherMOCsComponent implements OnInit {
  OthereMOCsList : OtherMOCs[] = [];
  constructor() { 

  }

  ngOnInit(): void {
  }

  GetOtherMOCs(){


  }

  IsHasAnyOtherMOC(){
    let HasOtherMOC = false; 
    this.OthereMOCsList.forEach(obj => {
     
      if(obj.AORequests!="" || obj.PORequests!=""){
        HasOtherMOC= true;
      }
    });
    return HasOtherMOC;
  }
}
