import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherMOCsComponent } from './other-mocs.component';

describe('OtherMOCsComponent', () => {
  let component: OtherMOCsComponent;
  let fixture: ComponentFixture<OtherMOCsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OtherMOCsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherMOCsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
