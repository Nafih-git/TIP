import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { SelectItem } from 'primeng/api';
import { WorkFlowActionEnum } from 'src/app/enums/workFlow-action_enum';
import { WorkStatusEnum } from 'src/app/enums/workFlow-status_enum';
import { RAApprovers } from 'src/app/models/ra-approvers_model';
import { RequestModel } from 'src/app/models/request_model';
import { UserDetailModel } from 'src/app/models/user-detail_model';
import { HttpService } from 'src/app/utility/http.service';
import { LoggedUserService } from 'src/app/utility/service/logged-user.service';

@Component({
  selector: 'app-request-comment',
  templateUrl: './request-comment.component.html',
  styleUrls: ['./request-comment.component.css']
})
export class RequestCommentComponent implements OnInit {
  Implementor: any | undefined;
  notifyTo: string ='';
  requestComment: string = '';
  raApprover: string = '';
  approverRole !: string;
  isSaveClicked: boolean = false;
  showRAApprover: boolean = false;
  raApprovers: RAApprovers = new RAApprovers();
  ApproverList: any[] = [];
  rarequired : boolean = false;
  otherrequired : boolean = false;
  RAApproverList : any[] = [];
  ActionList: SelectItem[] = [ { label: "CLOSE", value: WorkFlowActionEnum.Close }, { label: "EXTEND", value: WorkFlowActionEnum.Extension } ];
  selectedAction: number = WorkFlowActionEnum.Close;
  EffectiveFromDate!: Date;
  EffectiveToDate!: Date;
  directorate: string | undefined = "";
  asset: string | undefined = "";
  approverRoleId !: number;
  RAapproverRoleId !: number;
  Approver !: string;
  RAApprover !: string;
  ForwardToOtherApprover !: string;
  isforwardtoother : boolean = false;
  israapprove : boolean = false;
  workFlowActionEnum() { typeof WorkFlowActionEnum; return WorkFlowActionEnum }
  workStatusEnum() { typeof WorkStatusEnum; return WorkStatusEnum }

  @ViewChild("commentForm") commentForm!: NgForm;
  @Input() request: RequestModel = new RequestModel();

  userDetails: UserDetailModel[] = new Array<UserDetailModel>();
  lineManager: UserDetailModel = new UserDetailModel();
  userSearchSubscribe: any;
  LmChangeReasonId: number = 0;
  IsDraft: boolean = false;
  isReject: boolean = false

action !: number ;
  constructor(private _loggedUserService: LoggedUserService, private _HttpService: HttpService) { }

  ngOnInit(): void {

  }

  ForwardToOther(event: any) {

    this.ForwardToOtherApprover = event.PersonalNumber;
  }

  SelectRAApprover(Approver : string){
    this.RAApprover = Approver;

  }
  SelectApprover(Approver : string){
    this.Approver = Approver;

  }
  isValid(reject: boolean = false) {

    debugger;
    this.isReject = reject;

    let isValid;
    this.isSaveClicked = true;
    if (this.IsDraft || this.isReject) {
      if (this.requestComment) {
        isValid = true;
      }
      else {
        isValid = false;
      }
    }
    else {

      isValid = this.commentForm.valid;
    }
    return isValid;
  }

  searchUser(event: any): void {

    if (this.userSearchSubscribe) {

      this.userSearchSubscribe.unsubscribe();
    }

    this.userSearchSubscribe = this._HttpService.Get("Common/SearchUser", [event.query]).subscribe(res => {

      this.userDetails = res;
    });
  }

  GetApproversList(Directorate: any, Asset: any) {
    // alert(this.approverRoleId);
    this._HttpService.Get1("Master/GetApproversList", { RoleId: this.approverRoleId?? 0, Directorate: Directorate, Asset: Asset }).subscribe(res => {
      this.ApproverList = res;



    });
  }


  HasExtension(){
   let hasextension = false;
  var extensionlst =  this.request?.RequestExtensionList?.filter(e => e.Status == 0);
  if(extensionlst!=null && extensionlst.length > 0){
    hasextension = true;
  }
  return hasextension;
  }

}
