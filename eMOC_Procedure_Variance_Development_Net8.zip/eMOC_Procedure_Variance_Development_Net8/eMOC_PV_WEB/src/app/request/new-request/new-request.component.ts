import { IfStmt, ThisReceiver } from '@angular/compiler';
import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';

import { RAApprovers } from 'src/app/models/ra-approvers_model';
import { RaTeamMemberModel } from 'src/app/models/ra-team-member_model';
import { RiskAssessmentOutputModel } from 'src/app/models/risk-assessment-output_model';
import { UserDetailModel } from 'src/app/models/user-detail_model';
import { ExtensionHistoryComponent } from 'src/app/partial/extension-history/extension-history.component';
import { MessageStatusEnum } from '../../enums/message-status_enum';
import { RequestStepEnum } from '../../enums/request-step_enum';
import { WorkFlowActionEnum } from '../../enums/workFlow-action_enum';
import { WorkStatusEnum } from '../../enums/workFlow-status_enum';
import { DocumentsModels } from '../../models/documents_model';
import { GeneralModel, RequestModel } from '../../models/request_model';
import { ApprovalHistoryComponent } from '../../partial/approval-history/approval-history.component';
import { CommonFunctions } from '../../utility/common/common-functions';
import { HttpService } from '../../utility/http.service';
import { LoggedUserService } from '../../utility/service/logged-user.service';
import { RiskAssessmentComponent } from '../risk-assessment/risk-assessment.component';
import { DocumentsComponent } from './documents/documents.component';
import { RaTeamMembersComponent } from './ra-team-members/ra-team-members.component';
import { RequestCommentComponent } from './request-comment/request-comment.component';
import { RequestGeneralDetailsComponent } from './request-general-details/request-general-details.component';
import { RiskAssessmentModel } from 'src/app/models/risk-assessment_model';
import { CMSProcedure } from 'src/app/models/cms_procedure';
import { RequestExtensionModel } from 'src/app/models/request_Extension_model';
import { TaskModel } from 'src/app/models/task_model';
import { NgForm } from '@angular/forms';
import { DatePipe  } from '@angular/common';
@Component({
  selector: 'app-new-request',
  templateUrl: './new-request.component.html',
  styleUrls: ['./new-request.component.css']
})
export class NewRequestComponent implements OnInit {

  generalDetails: GeneralModel = new GeneralModel();

  @ViewChild(DocumentsComponent)
  documentsComponent!: DocumentsComponent;

  @ViewChild(RaTeamMembersComponent)
  raTeamMembersComponent!: RaTeamMembersComponent;

  @ViewChild(ApprovalHistoryComponent)
  approvalHistoryComponent!: ApprovalHistoryComponent;

  @ViewChild(RequestCommentComponent)
  requestCommentComponent!: RequestCommentComponent;

  @ViewChild(RiskAssessmentComponent)
  riskAssessmentComponent!: RiskAssessmentComponent;

  @ViewChild(ExtensionHistoryComponent)
  extensionHistoryComponent!: ExtensionHistoryComponent;


  @ViewChild(RequestGeneralDetailsComponent)
  requestGeneralDetailsComponent!: RequestGeneralDetailsComponent;

  @ViewChild("RAApproverSelectionForm") RAApproverSelectionForm!: NgForm;



  @ViewChild("OtherDisciplineSelectionDialogForm") OtherDisciplineSelectionDialogForm!: NgForm;

  @ViewChild("ExtensionForm") ExtensionForm!: NgForm;
  @ViewChild("CloseForm") CloseForm!: NgForm;



  message: string = 'Do you want to approve this request?';
  header: string = 'Approve Request';
  IsVisioFile :boolean = false;
  request: RequestModel = new RequestModel();
  requestId: number = 0;
  DraftMessage : string ='';
  RAapproverRoleName: string = '';
  backupUsers: string = '';
  isSaveClicked: boolean = false;
  successDialog: boolean = false;
  closeDialog: boolean = false;
  extensionDialog: boolean = false;
  extensionDialog1: boolean = false;
  OtherDisciplineSelectionDialog: boolean = false;
  RAApproverSelectionDialog: boolean = false;
  isSaving: boolean = false;
  loading: boolean = false;
  saveResponse: any;
  activeStepIndex: number=0;
  copyrequestId: number = 0;
  tocrequestId: number = 0;
  value !: string;
  LessonLearned : string="";
  steps: any[] = [];
  ExtensionminFromDate !: Date;
  ExtensionMaxFromDate !: Date;

  ExtensionminToDate !: Date;
  ExtensionMaxToDate !: Date;
  actionButtons: any = [];
  CurrentUserRoleName  !: string;
  workStatusEnum() { typeof WorkStatusEnum; return WorkStatusEnum }
  workFlowActionEnum() { typeof WorkFlowActionEnum; return WorkFlowActionEnum }
  config: any;
  staticText: any;
  LMNonCompetentApproval: number = 0;

  notifyTo: string = "";


  userList: any[] = [];
  userDetails: UserDetailModel[] = new Array<UserDetailModel>();
  userSearchSubscribe: any;

  constructor(private confirmationService: ConfirmationService, private _loggedUserService: LoggedUserService, private activatedRoute: ActivatedRoute, private _HttpService: HttpService, private messageService: MessageService, private router: Router, private datePipe : DatePipe) { }

  ngOnInit(): void {
    this.GetStaticText();
    this.GetactivatedRoute();




    this.config  = { "leftTime": 3610, "notify": [3600], "required" : false };

  }

  async GetStaticText() {

    this._HttpService.GetStaticText().subscribe(res => {
      this.staticText = res;
    });
  }

  GetactivatedRoute() {
    var id = this.activatedRoute.snapshot.paramMap.get('id');
    let copy_requestid = this.activatedRoute.snapshot.paramMap.get('copy_requestid');

    this.requestId = id ? +id : 0;
    this.copyrequestId = copy_requestid ? +copy_requestid : 0;


    if (this.requestId > 0)
      this.GetRequestById();
    if (this.copyrequestId > 0)
      this.GetRequestForCopy();


    // this.GetWorkflowSteps();
    this.GetWorkflowActions();
  }


  searchUser(event: any): void {

    if (this.userSearchSubscribe) {

      this.userSearchSubscribe.unsubscribe();
    }

    this.userSearchSubscribe = this._HttpService.Get("Common/SearchUser", [event.query]).subscribe(res => {

      this.userDetails = res;
    });
  }

  FunctionalReviewerSelect(event: any) {

    this.generalDetails.FunctionalReviewer = event.PersonalNumber;
  }
  
  ChangeFunctionalReviewer() {

    this.generalDetails.FunctionalReviewer = '';

  }

  GetWorkflowSteps(result: any) {

    if(result)
    {
      this.steps = result;
      console.log(this.steps);
     this.activeStepIndex = result[0].ActiveIndex;
        if (this.requestCommentComponent) {
      this.requestCommentComponent.approverRoleId = result[0].ApproverRoleId;
          this.requestCommentComponent.approverRole = result[0].ApproverRoleName;


          this.requestCommentComponent.directorate = this.requestGeneralDetailsComponent.generalDetails.Directorate;
          this.requestCommentComponent.asset = this.requestGeneralDetailsComponent.generalDetails.Asset;

      this.CurrentUserRoleName = result[0].ApproverRoleName;
        }
    }
  }

  GetWorkflowActions() {
    // **Important** Change TOCId from 1 to the selected Transfer of Control.
    this._HttpService.Get1("Request/GetWorkflowActions", { RequestId: this.requestId, WorkFlowypeId: 1 }).subscribe(result => {
      this.actionButtons = result;
    });
  }


  GetRequestById() {
    this.loading = true;
    this._HttpService.Get("Request/GetRequestById", [this.requestId.toString()]).subscribe((res: RequestModel) => {

      this.request = res;
      console.log(this.request );

      this.backupUsers = Array.prototype.map.call(this.request.BackupApprovers, function (item) { return item.EmployeeName; }).join(', ');

      this.requestGeneralDetailsComponent.generalDetails = res.General;


        this.requestGeneralDetailsComponent.selectedProcedure = new CMSProcedure();
        this.requestGeneralDetailsComponent.selectedProcedure.DisplayName = res.General.ProcedureDisplayName;
      //  this.request.General.ProcedureTitle =  res.General.ProcedureDisplayName;




debugger;
      if(this.request.General.IsManual){
        this.requestGeneralDetailsComponent.FunctionalReviewer = new UserDetailModel();
        this.requestGeneralDetailsComponent.FunctionalReviewer.EmployeeName = this.request.General.FunctionalReviewerName;
        this.requestGeneralDetailsComponent.FunctionalReviewer.PersonalNumber =  this.request.General.FunctionalReviewer;

        this.requestGeneralDetailsComponent.TechnicalApprover = new UserDetailModel();

        this.requestGeneralDetailsComponent.TechnicalApprover.EmployeeName = this.request.General.TechnicalApproverName;
        this.requestGeneralDetailsComponent.TechnicalApprover.PersonalNumber =  this.request.General.TechnicalApprover;
      }

      this.requestGeneralDetailsComponent.request = this.request;

      this.requestCommentComponent.notifyTo = res.NotifyTo;
      this.requestCommentComponent.requestComment = res.Comment;
      this.requestGeneralDetailsComponent.GetWorkflowSteps(false);

      this.documentsComponent.documentList = res.Documents;
      this.raTeamMembersComponent.RATeamMembers = res.RATeamMembers;

      this.approvalHistoryComponent.approvalHistoryList = res.ApproverHistory;
      this.requestGeneralDetailsComponent.GetResonVariance();


      this.requestGeneralDetailsComponent.generalDetails.FromDate = new Date(res.General.FromDate?.toString() ?? '');
      this.requestGeneralDetailsComponent.generalDetails.ToDate = new Date(res.General.ToDate?.toString() ?? '');

      if (res?.RiskAssessment) {
        this.riskAssessmentComponent.Riskassesments = JSON.parse(res?.RiskAssessment?.RAMatrix ?? '');
        this.riskAssessmentComponent.CRAContentList = JSON.parse(res?.RiskAssessment?.CumulativeRAMatrix ?? '');
      }
      else {
         this.riskAssessmentComponent.Riskassesments.push(new RiskAssessmentModel());
      }

      let currentextension = this.GetCurrentExtension();
      this.riskAssessmentComponent.DisbaledRAMatrix(this.request.CurrentStepId,1,currentextension);

      if (this.request.WorkflowStatusId == this.workStatusEnum().Drafted ) {
      this.DraftMessage = "Request Will be deleted automatically on " +   this.datePipe.transform(this.request.DraftDeletedDate,'dd-MMM-yyyy h:mm:ss a');
      }
       if (this.request.WorkflowStatusId == this.workStatusEnum().Pending_with_Functional_Reviwer) {
        this.requestCommentComponent.Approver= this.request.General.RAApprover;
      }
      else if (this.request.WorkflowStatusId == this.workStatusEnum().Pending_With_RA_Approver) {
        this.requestCommentComponent.Approver = this.request.General.TechnicalApprover;
      }
      else if (this.request.WorkflowStatusId == this.workStatusEnum().Pending_With_Technical_Approveer) {
        this.requestCommentComponent.Approver = this.request.General.Endorser;
      }
      else if (this.request.WorkflowStatusId == this.workStatusEnum().Pending_With_Endorser) {
        this.requestCommentComponent.Approver = this.request.General.Authorizer;
      }



      //For reject For rework
      if(this.request.WorkflowStatusId == WorkStatusEnum.Pending_for_Rework || this.request.WorkflowStatusId == WorkStatusEnum.Drafted  )
      {

        //If Request is Not based on CMS Procedure
        if(this.request.General.IsManual)
        {

          this.requestGeneralDetailsComponent.FunctionalReviewer = new UserDetailModel();
          this.requestGeneralDetailsComponent.FunctionalReviewer.PersonalNumber = this.request.General.FunctionalReviewer;
          this.requestGeneralDetailsComponent.FunctionalReviewer.EmployeeName = this.request.General.FunctionalReviewerName;

          this.requestGeneralDetailsComponent.TechnicalApprover = new UserDetailModel();
          this.requestGeneralDetailsComponent.TechnicalApprover.PersonalNumber = this.request.General.TechnicalApprover;
          this.requestGeneralDetailsComponent.TechnicalApprover.EmployeeName = this.request.General.TechnicalApproverName;
        }
        else
        {
          this.requestGeneralDetailsComponent.GetFunctionalReviwers(this.request.General.FunctionalReviewerName?.substring(this.request.General.FunctionalReviewerName?.lastIndexOf(" ")+1, this.request.General.FunctionalReviewerName.length));
          this.requestGeneralDetailsComponent.GetTechnicalApprovers(this.request.General.TechnicalApproverName?.substring(this.request.General.TechnicalApproverName?.lastIndexOf(" ")+1, this.request.General.TechnicalApproverName.length));
        }


      }

      this.requestGeneralDetailsComponent.GetAsset(false);
      this.requestGeneralDetailsComponent.GetFacility(false);

      if(this.request.WorkflowStatusId == WorkStatusEnum.Implemented) {
        // this.request.General.ExtensionFromDate = this.request.General.ToDate;
        // this.ExtensionminToDate = this.request.General.ExtensionFromDate  as Date;


        // this.ExtensionMaxToDate = new Date();
        // //this.ExtensionMaxToDate.setDate(this.ExtensionminToDate.getDate() + 90);
        // this.ExtensionMaxToDate =  new Date(this.ExtensionminToDate.getTime() +  (90 * 24 * 60 * 60 * 1000)); // 90 Days Validation



      }

      debugger;
      // if(this.request?.RequestExtensionList?.length > 0){
      //   this.request.RequestExtension = new RequestExtensionModel();
      //   let extension =this.request.RequestExtensionList.find(c=>c.Status == 0);
      //   if(extension){
      //     this.request.RequestExtension = extension;
      //   }
      // }
      this.extensionHistoryComponent.GetExtensionHistory(this.request.Id);
        setTimeout(() => {
          // if(this.extensionHistoryComponent)
          //   this.extensionHistoryComponent.extensionHistoryList = res.ExtensionHistory;
       if(this.request.WorkflowStatusId == WorkStatusEnum.Pending_with_Functional_Reviwer) {
         // this.ShowRAApprover();
        }
        if(this.request.WorkflowStatusId != WorkStatusEnum.Pending_with_Functional_Reviwer) {
           this.requestCommentComponent.GetApproversList(this.requestGeneralDetailsComponent.generalDetails.Directorate, this.requestGeneralDetailsComponent.generalDetails.Asset)
        }
        }, 1000);


        this.loading = false;
    });
  }


  ShowRAApprover() {
    this.requestCommentComponent.showRAApprover = false;
      this.requestCommentComponent.showRAApprover = true;
debugger;

      this._HttpService.Post("Request/GetRAApprovers", {DirectorateCode: this.request.General.Directorate??'',AssetCode: this.request.General.Asset??'', RRName: this.riskAssessmentComponent.Get_Risk_Type_Code(this.riskAssessmentComponent?.ControlMaximumRisk?.Indicatorname)??'', CRName: this.riskAssessmentComponent.GetselectedCumulativeRating()??'' }).subscribe((res: RAApprovers) => {

        this.requestCommentComponent.RAApproverList = res?.RAApproverUsers;
         this.requestCommentComponent.RAapproverRoleId = res?.ApproverRoId;
         this.RAapproverRoleName = res?.ApproverRoName;
         console.log(res);
      });



  }

  GetRequestForCopy() {
    this._HttpService.Get("Request/GetRequestById", [this.copyrequestId.toString()]).subscribe((res: RequestModel) => {
      this.request = res;
      this.request.Id = 0;

      this.request.General.Directorate = "";
      this.request.General.Asset = "";
      this.request.General.Facility = "";
      this.request.WorkflowStatusId = 0;
      this.request.CurrentStepId = 1;
      this.request.General.ProcedureCode = "";
      this.request.General.ProcedureTitle = "";
      this.request.General.ProcedureLink = "";
      this.request.General.FromDate = null;
      this.request.ActiveTask = new TaskModel();
      this.request.General.ToDate = null;
      this.request.General.TechnicalApprover = "";
      this.request.General.FunctionalReviewer = "";
      this.request.General.IsManual = 1;
      this.request.RequestExtensionList = new Array<RequestExtensionModel>();
      this.request.ApproverHistory = [];
      this.request.Documents = [];
      this.documentsComponent.documentList = [];
      this.request.WorkflowStatus = "";
      this.requestGeneralDetailsComponent.generalDetails = res.General;
      this.requestGeneralDetailsComponent.request = this.request;
      this.requestGeneralDetailsComponent.GetWorkflowSteps(false);
      this.raTeamMembersComponent.RATeamMembers = res.RATeamMembers;

      if (res?.RiskAssessment) {
        this.riskAssessmentComponent.Riskassesments = JSON.parse(res?.RiskAssessment?.RAMatrix ?? '');
        this.riskAssessmentComponent.CRAContentList = JSON.parse(res?.RiskAssessment?.CumulativeRAMatrix ?? '');
      }
      else {
        this.riskAssessmentComponent.Riskassesments = [];
        // this.riskAssessmentComponent.Riskassesments.push(new RiskAssessmentModel());

      }

      if (this.request?.RiskAssessment) {
        this.request.RiskAssessment = new RiskAssessmentOutputModel();
      }


      this.requestGeneralDetailsComponent.generalDetails.FromDate = null;
      this.requestGeneralDetailsComponent.generalDetails.ToDate = null;
      this.requestGeneralDetailsComponent.generalDetails.ImplementedDate = null;
      this.requestGeneralDetailsComponent.IsToIOCRequest = false;

        this.requestGeneralDetailsComponent.GetResonVariance();

    });
  }



  async Draft() {
    this.request.WorkflowActionId = WorkFlowActionEnum.Draft;
    this.header = "Draft Request";
    this.message = 'Do you want to Draft this request? Draft request will be deleted automatically after '+ this.staticText.DraftDays +' days.';
    this.Save(true);
  }

  Submit() {
    debugger;
    this.request.WorkflowActionId = WorkFlowActionEnum.Submit;
    this.request.NextApprover = this.requestGeneralDetailsComponent.generalDetails.FunctionalReviewer;
    this.header = "Save Request";
    this.message = 'Do you want to save this request?';

    this.Save();
  }

  OtherDisciplineSave() {
    debugger;
    this.request.WorkflowActionId = WorkFlowActionEnum.OtherDisciplineSave;
    this.header = "Save Request";
    this.message = 'Do you want to save this request?';
    this.Save();
  }
  Extension() {

    this.request.NextApprover = this.request.General.TechnicalApprover;
    this.header = "Extension Request";
    this.message = 'Do you want to extend this request?';
    this.Save();
  }
  ForwardtoOther() {
    debugger;
    this.requestCommentComponent.isforwardtoother = true;
    this.request.WorkflowActionId = WorkFlowActionEnum.ForwardtoOther;
    this.request.NextApprover = this.request.ForwardToOther.PersonalNumber;
    this.header = "Save Request";
    this.message = 'Do you want to save this request?';
    this.Save();
  }

  async Save(IsDraft: boolean = false) {
    this.MapValueToRequestModel();
    if (this.isValid(IsDraft)) {
      this.confirmationService.confirm({
        message: this.message,
        header: this.header,
        icon: 'pi pi-question-circle',
        accept: async () => {
          this.isSaving = true;
          await this.uploadFiles().then(() => {
            this.SaveRequest();
          });
        },
      });
    }
  }

  CheckIsVisioFile(FileName :string =  this.request.General.ProcedureLink){

    this.IsVisioFile = CommonFunctions.IsVisioFile(FileName);
return this.IsVisioFile;
   }
  MapValueToRequestModel() {
    debugger;
    // if(this.request.General.IsManual){
    //   if(this.requestGeneralDetailsComponent.selectedProcedure.DisplayName != undefined){
    //   this.requestGeneralDetailsComponent.generalDetails.ProcedureTitle = this.requestGeneralDetailsComponent.selectedProcedure.DisplayName.toString();

    //   }
    //   else{
    //     this.requestGeneralDetailsComponent.generalDetails.ProcedureTitle = this.requestGeneralDetailsComponent.selectedProcedure.toString();

    //   }
    // }

    this.request.Id = this.requestId;
    this.request.General = new GeneralModel();
    this.request.Documents = new Array<DocumentsModels>();
    this.request.RATeamMembers = new Array<RaTeamMemberModel>();
    this.request.General = this.requestGeneralDetailsComponent.generalDetails;
    this.request.General.LessonLearned = this.LessonLearned;
    this.request.Documents = this.documentsComponent.documentList;
    this.request.RATeamMembers = this.raTeamMembersComponent.RATeamMembers;
    this.request.Comment = this.requestCommentComponent.requestComment;
debugger;
 if (this.request.WorkflowActionId == WorkFlowActionEnum.Review){
  this.request.NextApprover = this.requestCommentComponent.RAApprover;

 }
  else if(this.request.WorkflowActionId == WorkFlowActionEnum.Approve && this.request.WorkflowStatusId == WorkStatusEnum.Pending_With_RA_Approver){
      this.request.NextApprover = this.request.General.TechnicalApprover;
  }
  else if(!this.request.NextApprover){
    this.request.NextApprover = this.requestCommentComponent.Approver;
  }






debugger;
   if(this.requestCommentComponent.isforwardtoother){
    this.request.NextARID = this.requestCommentComponent.approverRoleId;

   }
   else if (this.request.WorkflowActionId == WorkFlowActionEnum.Review){
    this.request.NextARID = this.requestCommentComponent.RAapproverRoleId;

   }
   else if (this.request.WorkflowActionId != WorkFlowActionEnum.Draft){
    this.request.NextARID = this.requestCommentComponent.approverRoleId;

   }




    if (this.request.RiskAssessment == null) {
      this.request.RiskAssessment = new RiskAssessmentOutputModel();
    }


    if (this.request.WorkflowStatusId == this.workStatusEnum().Pending_With_Endorser) {
      this.request.General.AuthorizerRoleId = this.requestCommentComponent.approverRoleId;
    }
    else if (this.request.WorkflowStatusId == this.workStatusEnum().Pending_With_Technical_Approveer) {
      this.request.General.EndorserRoleId = this.requestCommentComponent.approverRoleId;

    }

    this.request.RiskAssessment.MaxInitialRiskCode = this.riskAssessmentComponent.ConsequenceMaximumRisk?.Indicatorname ?? '';
    this.request.RiskAssessment.MaxInitialRiskModule = this.riskAssessmentComponent.ConsequenceMaximumRisk?.Indicatortype ?? '';
    this.request.RiskAssessment.MaxResidualRiskCode = this.riskAssessmentComponent.ControlMaximumRisk?.Indicatorname ?? '';
    this.request.RiskAssessment.MaxResidualRiskModule = this.riskAssessmentComponent.ControlMaximumRisk?.Indicatortype ?? '';
    this.request.RiskAssessment.MaxInitialRisk = this.riskAssessmentComponent.Get_Risk_Type_Code(this.riskAssessmentComponent.ConsequenceMaximumRisk?.Indicatorname) ?? '';
    this.request.RiskAssessment.MaxResidualRisk = this.riskAssessmentComponent.Get_Risk_Type_Code(this.riskAssessmentComponent.ControlMaximumRisk?.Indicatorname) ?? '';
    this.request.RiskAssessment.CumulativeRAName = this.riskAssessmentComponent.GetselectedCumulativeRating() ?? '';
    this.request.RiskAssessment.RAMatrix = JSON.stringify(this.riskAssessmentComponent?.Riskassesments) ?? '';
    this.request.RiskAssessment.CumulativeRAMatrix = JSON.stringify(this.riskAssessmentComponent?.CRAContentList) ?? '';
    this.request.General.ActiveTaskId = this.request.ActiveTask?.Id;

debugger;

  }

  isValid(IsDraft: boolean = false) {

    this.isSaveClicked = true;
    var isValid = 0;
    var businessValidationerror = 0;

    if (!this.requestGeneralDetailsComponent.isValid()) {

      isValid = isValid + 1;
    }
    this.requestCommentComponent.IsDraft = IsDraft;
    if (!this.requestCommentComponent.isValid(false)) {

      isValid = isValid + 1;
    }

    if (!this.documentsComponent.isValid()) {

      isValid = isValid + 1;
    }

    if (this.riskAssessmentComponent.ValidateRiskAssesment()) {

      isValid = isValid + 1;

      this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Complete Risk Assessment Details" });
    }

    if (this.request.WorkflowActionId == WorkFlowActionEnum.Draft) {

      if (isValid > 0) {

        this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });
      }

    }
    else {


debugger;
      if (this.request.Id > 0 && this.request.WorkflowStatusId == WorkStatusEnum.Pending_with_Functional_Reviwer && this.request?.ActiveTask?.AssignedToRoleId !=5) {
       if(this.requestCommentComponent.israapprove){
        if (this.request.NextApprover == "" || this.request.NextApprover == null || this.request.NextApprover == undefined) {
          this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Select RA Approver"});
          ++businessValidationerror;
        }
       }
       else if(this.requestCommentComponent.isforwardtoother){

        if (this.request.NextApprover == "" || this.request.NextApprover == null || this.request.NextApprover == undefined) {
          this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Select Other Discipline"});
          ++businessValidationerror;
        }
       }

      }

      if (isValid > 0) {

        this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });
      }

  if(this.riskAssessmentComponent.Riskassesments == null || this.riskAssessmentComponent.Riskassesments == undefined || this.riskAssessmentComponent.Riskassesments?.length == 0 )
  {
    isValid = isValid + 1;
    this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn),detail: "Risk Assessment is Required." });

  }

   if (!this.raTeamMembersComponent.isValid()) {

        isValid = isValid + 1;

        this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Minimum " + this.raTeamMembersComponent.staticText?.MinRATeamMemberCount + " Risk Assessment Team " + ((this.raTeamMembersComponent.staticText?.MinRATeamMemberCount > 1) ? "Members" : "Member") + " Required" });
      }

      if (!this.raTeamMembersComponent.isValidKnowledgePerson()) {

        isValid = isValid + 1;
        this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Minimum " + this.raTeamMembersComponent.staticText?.MinRASkilledPersonCount + " Risk Assessment Team " + ((this.raTeamMembersComponent.staticText?.MinRASkilledPersonCount > 1) ? "Members Need" : "Member Needs") + " to be Added With SKILL Competency" });
      }
  //  }

   debugger;



  if (!this.riskAssessmentComponent.ValidateCRA_clicked()) {

    isValid = isValid + 1;

    this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Complete Cumulative Risk Assessment" });
  }

//}

       if (this.riskAssessmentComponent.ValidateRiskAssesment()) {

        isValid = isValid + 1;

        this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Complete Risk Assessment Details" });
      }
    }
    if (businessValidationerror > 0)
      ++isValid;

    return isValid == 0;
  }

  async uploadFiles() {

    return new Promise(resolve => {

      var doc = this.documentsComponent.documentList.length;

      if (doc == 0) resolve("success");

      var i = 0;

      var docList = new Array<DocumentsModels>();

      this.documentsComponent.documentList.forEach(row => {

        row.RequestId = this.request.Id;

        if (row.Id && row.Id > 0) {

          docList.push(row);
          i = i + 1;

          if (doc == i) {

            this.request.Documents = docList;
            resolve("success")
          }
        }
        else {

          var formData = CommonFunctions.convertModelToFormData(row);

          this._HttpService.Post("Request/SaveRequestDocument", formData).subscribe((res: DocumentsModels) => {
            docList.push(res);
            i = i + 1;

            if (doc == i) {

              this.request.Documents = docList;
              resolve("success")
            }
          });
        }
      });
    });
  }

  SaveRequest() {


    console.log(this.request);
    this._HttpService.Post("Request/SaveRequest", this.request).subscribe((res: any) => {

      this.saveResponse = res.Result;

      this.successDialog = true;
      this.isSaving = false;
    },
      (error) => {

        this.isSaving = false;
      }
    );
  }


  isValidExtensionForm() {
    return this.ExtensionForm.valid;
  }
  isValidCloseForm() {
    return this.CloseForm.valid;
  }
  AddDocuments() {

    var loggedUser = "";

    if (this._loggedUserService.loggedUser && this._loggedUserService.loggedUser.EmployeeName)
      loggedUser = this._loggedUserService.loggedUser.EmployeeName;

    let document = { CreatedDate: new Date(), CreatedByName: loggedUser, UserRoleName: "", Comment: "" } as DocumentsModels;
    this.documentsComponent.documentList.push(document);
  }

  AddRaMembers() {

    this.raTeamMembersComponent.displayModal = true;
    this.raTeamMembersComponent.isSaveClicked = false;
  }

  CloseSuccessDialog() {

    this.successDialog = false;
    if (this.saveResponse.StatusCode == 0)
      this.router.navigateByUrl(CommonFunctions.GetAllRequestPage());

  }

  CloseDialog(type : number) {
    if(type==1){
      this.closeDialog = false;
    }
    else if (type==2){
      this.extensionDialog = false
    }
    else if (type==3){
      this.OtherDisciplineSelectionDialog = false
    }
    else if (type==4){
      this.RAApproverSelectionDialog = false
    }

  }

  ShowDialog(data: any) {
    this.isSaving = false;
    this.successDialog = true;
    this.saveResponse = data;
  }

  async Delete() {

    if (this.requestCommentComponent.isValid()) {

      this.request.WorkflowActionId = WorkFlowActionEnum.Delete;

      this.MapValueToRequestModel();

      this.confirmationService.confirm({
        message: 'Do you want to delete this request?',
        header: 'Delete Request',
        icon: 'pi pi-question-circle',
        accept: async () => {

          this.isSaving = true;

          await this.uploadFiles().then(() => {

            this.SaveRequest();
          });
        },
      });
    }
    else {

      this.isSaving = false;
      this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });
    }
  }

  async RejectOrClose(close: boolean = false) {

    var isValid = 0;

    if (!this.requestGeneralDetailsComponent.isValid()) isValid = isValid + 1;
    if (!this.requestCommentComponent.isValid(true)) isValid = isValid + 1;

    if (isValid > 0) {

      this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });
    }
    else {

      var message = '';
      var header = '';

      if (close) {

        this.request.WorkflowActionId = WorkFlowActionEnum.Close;
        message = 'Do you want to close this request?';
        header = 'Close Request';
      }
      else {

        this.request.WorkflowActionId = WorkFlowActionEnum.Reject;
        message = 'Do you want to send back this request?';
        header = 'Send Back Request';
      }

      this.MapValueToRequestModel();

      this.confirmationService.confirm({
        message: message,
        header: header,
        icon: 'pi pi-question-circle',
        accept: async () => {

          this.isSaving = true;

          await this.uploadFiles().then(() => {

            this.SaveRequest();
          });
        },
      });
    }

  }

  async RejectAndClose(close: boolean = false, IsExtension : boolean = false) {

    var isValid = 0;

    if (!this.requestGeneralDetailsComponent.isValid()) isValid = isValid + 1;
    if (!this.requestCommentComponent.isValid(true)) isValid = isValid + 1;

    if (isValid > 0) {

      this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });
    }
    else {

      var message = '';
      var header = '';
      message = 'Do you want to reject and close this request?';
      header = 'Reject Request';
      if(IsExtension){
        header = 'Reject Extension Request';
        message = 'Do you want to reject and close this extension request?';
      }






      this.MapValueToRequestModel();

      this.confirmationService.confirm({
        message: message,
        header: header,
        icon: 'pi pi-question-circle',
        accept: async () => {

          this.isSaving = true;

          await this.uploadFiles().then(() => {

            this.SaveRequest();
          });
        },
      });
    }

  }
  async Implement() {



    this.request.WorkflowActionId = WorkFlowActionEnum.Implement;

    this.MapValueToRequestModel();

    if (this.isValid()) {

      this.confirmationService.confirm({
        message: this.message,
        header: this.header,
        icon: 'pi pi-question-circle',
        accept: async () => {

          this.isSaving = true;

          await this.uploadFiles().then(() => {

            this.SaveRequest();
          });
        },
      });
    }

  }

  async Approve() {
    this.MapValueToRequestModel();
    if (this.isValid()) {
      this.confirmationService.confirm({
        message: this.message,
        header: this.header,
        icon: 'pi pi-question-circle',
        accept: async () => {

          this.isSaving = true;

          await this.uploadFiles().then(() => {

            this.SaveRequest();
          });
        },
      });
    }


  }





  ShowResponseIcon() {

    var icon: string = '';

    if (this.saveResponse) {

      switch (this.saveResponse.StatusCode) {
        case 0: {
          icon = 'pi-check-circle';
          break
        }
        case 1: {
          icon = 'pi-times-circle';
          break
        }
        case 2: {
          icon = 'pi-exclamation-circle';
          break
        }
        default: {
          icon = 'pi-info-circle';
          break
        }
      }
    }

    return icon;
  }

  PopUpAction(ActionId: any) {
    debugger;
     if (ActionId == WorkFlowActionEnum.Review) {
      this.isSaveClicked = true;
          if(this.RAApproverSelectionForm.valid){
            this.request.WorkflowActionId = WorkFlowActionEnum.Review;
            this.requestCommentComponent.rarequired = true;
            this.requestCommentComponent.isforwardtoother = false;
              this.Approve();
          }
          else{

            this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });
          }
    }

    else if (ActionId == WorkFlowActionEnum.ForwardtoOther){

      this.isSaveClicked = true;
      if(this.OtherDisciplineSelectionDialogForm.valid){
        this.request.WorkflowActionId = WorkFlowActionEnum.ForwardtoOther;
        this.requestCommentComponent.otherrequired = true;
        this.requestCommentComponent.rarequired = false;
        this.requestCommentComponent.isforwardtoother = false;
        this.ForwardtoOther();
      }
      else{

        this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });
      }


    }


}


  Action(ActionId: any) {
    debugger;
    if (ActionId == WorkFlowActionEnum.Draft) {
      this.request.WorkflowActionId = WorkFlowActionEnum.Draft;

      this.Draft();
    }
    else if (ActionId == WorkFlowActionEnum.Submit) {
      this.Submit();
    }
    else if (ActionId == WorkFlowActionEnum.OtherDisciplineSave) {
      this.request.WorkflowActionId = WorkFlowActionEnum.OtherDisciplineSave;
      this.OtherDisciplineSave();
    }



    else if (ActionId == WorkFlowActionEnum.Delete) {

      this.Delete();
    }
    else if (ActionId == WorkFlowActionEnum.Approve) {
    this.request.WorkflowActionId = WorkFlowActionEnum.Approve;
      this.requestCommentComponent.isforwardtoother = false;
      this.Approve();
    }

    else if (ActionId == WorkFlowActionEnum.TechnicalApprove) {
      this.request.WorkflowActionId = WorkFlowActionEnum.TechnicalApprove;
        this.requestCommentComponent.isforwardtoother = false;

     let extension = this.GetCurrentExtension();
      if (extension != null){
        this.message = "I technically approve the deviation to standard for the period " +  this.datePipe.transform(extension.EffectiveFromDate,'dd-MMM-yyyy h:mm:ss a') + " to "+ this.datePipe.transform(extension.EffectiveToDate,'dd-MMM-yyyy h:mm:ss a');

      }
      else{
        this.message = "I technically approve the deviation to standard for the period " +  this.datePipe.transform(this.request.General.FromDate,'dd-MMM-yyyy h:mm:ss a') + " to "+ this.datePipe.transform(this.request.General.ToDate,'dd-MMM-yyyy h:mm:ss a');

      }
        this.header = "Technical Approve";
        this.Approve();
      }
    else if (ActionId == WorkFlowActionEnum.Endorse) {
      this.request.WorkflowActionId = WorkFlowActionEnum.Endorse;
      this.message = 'Do you want to Endorse this request?';
      this.header = 'Endorse Request';
        this.Approve();
      }
      else if (ActionId == WorkFlowActionEnum.Authorized) {
        let extension = this.GetCurrentExtension();
        if (extension != null){
          this.message = "I confirm that controls and resources are in place to allow the deviation to standard from " +  this.datePipe.transform(extension.EffectiveFromDate,'dd-MMM-yyyy h:mm:ss a') + " to "+ this.datePipe.transform(extension.EffectiveToDate,'dd-MMM-yyyy h:mm:ss a');

        }
        else{
          this.message = "I confirm that controls and resources are in place to allow the deviation to standard from " +  this.datePipe.transform(this.request.General.FromDate,'dd-MMM-yyyy h:mm:ss a') + " to "+ this.datePipe.transform(this.request.General.ToDate,'dd-MMM-yyyy h:mm:ss a');

        }
        this.header = "Authorized Request";
        this.request.WorkflowActionId = WorkFlowActionEnum.Authorized;

          this.Approve();
        }
    else if (ActionId == WorkFlowActionEnum.Review) {
    this.request.WorkflowActionId = WorkFlowActionEnum.Review;
    if(this.requestCommentComponent.isValid()){
      this.ShowRAApprover();
      this.RAApproverSelectionDialog = true;
    }
    else{

      this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });
    }

    // this.requestCommentComponent.otherrequired = false;
    // this.requestCommentComponent.rarequired = true;

    // this.requestCommentComponent.isforwardtoother = false;
    //   this.Approve();
    }
    else if (ActionId == WorkFlowActionEnum.Reject) {
      this.request.WorkflowActionId = WorkFlowActionEnum.Reject;
      this.RejectOrClose(false);
    }

    else if (ActionId == WorkFlowActionEnum.RejectExtension) {
      this.request.WorkflowActionId = WorkFlowActionEnum.RejectExtension;
      this.RejectAndClose(false, true);
    }
    else if (ActionId == WorkFlowActionEnum.Implement) {
      this.request.WorkflowActionId = WorkFlowActionEnum.Implement;
      this.message = 'Do you want to implement this request?';
      this.header = 'Implement Request';

      this.Implement()
    }
    else if (ActionId == WorkFlowActionEnum.Close) {
      this.isSaveClicked= true;
      if(this.closeDialog){
          if(this.CloseForm.valid){

            this.RejectOrClose(true);
          }
          else{

            this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });
          }



      }
      else{

        if(this.requestCommentComponent.isValid()){
          this.request.WorkflowActionId = WorkFlowActionEnum.Close;

          this.closeDialog = true;
        }
        else{
          this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });

        }

      }



    }
    else if (ActionId == WorkFlowActionEnum.RejectAndClose) {

      this.request.WorkflowActionId = WorkFlowActionEnum.RejectAndClose;
      this.RejectAndClose(true);
    }
    else if (ActionId == WorkFlowActionEnum.ForwardtoOther) {
      // this.request.WorkflowActionId = WorkFlowActionEnum.ForwardtoOther;
      // this.requestCommentComponent.otherrequired = true;
      // this.requestCommentComponent.rarequired = false;
      // this.requestCommentComponent.isforwardtoother = false;
      // this.ForwardtoOther();
      if(this.requestCommentComponent.isValid()){
        this.OtherDisciplineSelectionDialog = true;
      }  else{

        this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });
      }

    }
    else if (ActionId == WorkFlowActionEnum.Extension) {
      this.isSaveClicked= true;
      if(this.isValidExtensionForm()){
        this.request.WorkflowActionId = WorkFlowActionEnum.Extension;
        this.Extension();
      }
      else{
        this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });

      }


    }
    else if (ActionId == WorkFlowActionEnum.Save) {

      if(this.requestCommentComponent.isValid()){
        if(this.requestCommentComponent.action == WorkFlowActionEnum.Close){
          this.closeDialog = true;
        }
        else if(this.requestCommentComponent.action ==WorkFlowActionEnum.Extension ){ // For Extension Action
          this.extensionDialog = true;
          setTimeout(() => {

            this.request.General.ExtensionFromDate = this.request.General.ToDate;
            this.ExtensionminToDate = this.request.General.ExtensionFromDate  as Date;


            this.ExtensionMaxToDate = new Date();
            //this.ExtensionMaxToDate.setDate(this.ExtensionminToDate.getDate() + 90);
            this.ExtensionMaxToDate =  new Date(this.ExtensionminToDate.getTime() +  (90 * 24 * 60 * 60 * 1000)); // 90 Days Validation



          }, 100);

        }
      } else{

        this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Please Fill All Required Fields" });
      }
      //Close Action

    }


  }


  GetCurrentExtension(){
    let extension !: RequestExtensionModel ;
    debugger;
    if(this.request.RequestExtensionList?.length > 0){
      let  extensionlist =  this.request.RequestExtensionList.filter(f=>f.Status == 0);
       if(extensionlist !=null && extensionlist.length > 0){
        extension = extensionlist[0];
       }
    }
    return extension;

  }
}
