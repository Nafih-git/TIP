import { Input, ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MessageService, SelectItem } from 'primeng/api';
import { WorkStatusEnum } from 'src/app/enums/workFlow-status_enum';
import { RequestModel } from 'src/app/models/request_model';
import { UserDetailModel } from 'src/app/models/user-detail_model';
import { RaTeamMemberModel } from '../../../models/ra-team-member_model';
import { HttpService } from '../../../utility/http.service';
import { CommonFunctions } from 'src/app/utility/common/common-functions';
import { MessageStatusEnum } from 'src/app/enums/message-status_enum';

@Component({
  selector: 'app-ra-team-members',
  templateUrl: './ra-team-members.component.html',
  styleUrls: ['./ra-team-members.component.css']
})
export class RaTeamMembersComponent implements OnInit {

  @ViewChild("formRaTeamMember") formRaTeamMember!: NgForm;
  @Input("request") request: RequestModel = new RequestModel();
  @Input("showAction") showAction: boolean = false;

  userDetails: UserDetailModel[] = new Array<UserDetailModel>();
  userDetail: UserDetailModel = new UserDetailModel();
  raTeamMember: RaTeamMemberModel = new RaTeamMemberModel();
  RATeamMembers: RaTeamMemberModel[] = new Array<RaTeamMemberModel>();
  isSaveClicked: boolean = false;
  displayModal: boolean = false;
  userSearchSubscribe: any;
  competentList: SelectItem[] = [ { label: "KNOWLEDGE", value: "KNOWLEDGE" }, { label: "SKILL", value: "SKILL" }, { label: "NONE", value: "NONE" } ];
  staticText: any;
  disableJobDescription: boolean = true;

  workStatusEnum() { typeof WorkStatusEnum; return WorkStatusEnum }

  constructor(private _HttpService: HttpService, private messageService: MessageService) { }

  ngOnInit(): void {

    this.GetStaticText();
  }

  async GetStaticText() {

    this._HttpService.GetStaticText().subscribe(res => {

      this.staticText = res;
    });
  }

  SearchUser(event: any): void {

    if(this.userSearchSubscribe) {

      this.userSearchSubscribe.unsubscribe();
    }

    this.userSearchSubscribe = this._HttpService.Get("Common/SearchUser", [event.query]).subscribe(res => {

      this.userDetails = res;
    });
  }

  GetUserDetails() {

    this.raTeamMember.RequestId = this.request.Id;
    this.raTeamMember.Name = this.userDetail.EmployeeName;
    this.raTeamMember.JobDescription = this.userDetail.JobDescription;
    this.raTeamMember.MuNumber = this.userDetail.PersonalNumber;
    this.raTeamMember.IsActive = 1;

    this.disableJobDescription = this.raTeamMember.JobDescription ? true : false;
  }

  Add() {

    this.isSaveClicked = true;

    if(this.raTeamMember.MuNumber && this.raTeamMember.JobDescription && this.raTeamMember.Competency) {

      let letCurrentMember: RaTeamMemberModel[] = this.RATeamMembers.filter(m => m.MuNumber === this.userDetail.PersonalNumber);

      if(letCurrentMember.length > 0) {

        letCurrentMember[0].Competency = this.raTeamMember.Competency;
        letCurrentMember[0].IsActive = 1;
      }
      else {

        this.RATeamMembers.push(this.raTeamMember);
      }

      this.disableJobDescription = true;

      this.isSaveClicked = false;
      this.raTeamMember = new RaTeamMemberModel();
      this.userDetail = new UserDetailModel();
    }
  }

  DeleteMember(raTeamMember: RaTeamMemberModel, index: number) {

    if(raTeamMember.RequestId > 0) {

      this.RATeamMembers.filter(m => m.MuNumber == raTeamMember.MuNumber??'')[0].IsActive = 0;
    }
    else {

      this.RATeamMembers.splice(index, 1);
    }
  }

  Close() {
    var isValid = 0;
    if (!this.isValid()) {

      isValid = isValid + 1;

      this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Minimum " + this.staticText?.MinRATeamMemberCount + " Risk Assessment Team " + ((this.staticText?.MinRATeamMemberCount > 1) ? "Members" : "Member") + " Required" });
    }

    if (!this.isValidKnowledgePerson()) {

      isValid = isValid + 1;
      this.messageService.add({ severity: CommonFunctions.MessageStatus(MessageStatusEnum.Warn), detail: "Minimum " + this.staticText?.MinRASkilledPersonCount + " Risk Assessment Team " + ((this.staticText?.MinRASkilledPersonCount > 1) ? "Members Need" : "Member Needs") + " to be Added With SKILL Competency" });
    }
    if(isValid != 0){

    }

    else{
      this.raTeamMember = new RaTeamMemberModel();
      this.userDetail = new UserDetailModel();

      this.displayModal = false;
      this.isSaveClicked = false;
    }


  }

  isValid() {

    var valid = true;
    this.isSaveClicked = true;

    if(!(this.RATeamMembers.length >= this.staticText?.MinRATeamMemberCount)) {

      valid = false;
    }

    return valid;
  }

  isValidKnowledgePerson() {

    var valid = false;

    if(this.RATeamMembers.filter(m => m.Competency == 'SKILL').length >= this.staticText?.MinRASkilledPersonCount) {

      valid = true;
    }

    return valid;
  }
}
