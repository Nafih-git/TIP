import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RaTeamMembersComponent } from './ra-team-members.component';

describe('RaTeamMembersComponent', () => {
  let component: RaTeamMembersComponent;
  let fixture: ComponentFixture<RaTeamMembersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RaTeamMembersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RaTeamMembersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
