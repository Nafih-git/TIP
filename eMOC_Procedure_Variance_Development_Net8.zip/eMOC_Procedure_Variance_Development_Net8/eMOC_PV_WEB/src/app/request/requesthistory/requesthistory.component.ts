import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ExtensionHistoryComponent } from 'src/app/partial/extension-history/extension-history.component';
import { WorkFlowActionEnum } from '../../enums/workFlow-action_enum';
import { WorkStatusEnum } from '../../enums/workFlow-status_enum';
import { RequestModel } from '../../models/request_model';
import { ApprovalHistoryComponent } from '../../partial/approval-history/approval-history.component';
import { HttpService } from '../../utility/http.service';
import { LoggedUserService } from '../../utility/service/logged-user.service';
import { RiskAssessmentComponent } from '../risk-assessment/risk-assessment.component';
import { DocumentsComponent } from '../new-request/documents/documents.component';
import { RaTeamMembersComponent } from '../new-request/ra-team-members/ra-team-members.component';
import { RequestCommentComponent } from '../new-request/request-comment/request-comment.component';
import { RequestGeneralDetailsComponent } from '../new-request/request-general-details/request-general-details.component';

import { RiskAssessmentOutputModel } from 'src/app/models/risk-assessment-output_model';
import { CMSProcedure } from 'src/app/models/cms_procedure';
import { UserDetailModel } from 'src/app/models/user-detail_model';
import { RiskAssessmentModel } from 'src/app/models/risk-assessment_model';


@Component({
  selector: 'app-requesthistory',
  templateUrl: './requesthistory.component.html',
  styleUrls: ['./requesthistory.component.css']
})

export class RequesthistoryComponent implements OnInit {


  @ViewChild(DocumentsComponent)
  documentsComponent!: DocumentsComponent;

  @ViewChild(RaTeamMembersComponent)
  raTeamMembersComponent!: RaTeamMembersComponent;



  @ViewChild(RequestCommentComponent)
  requestCommentComponent!: RequestCommentComponent;

  @ViewChild(RiskAssessmentComponent)
  riskAssessmentComponent!: RiskAssessmentComponent;

  @ViewChild(ExtensionHistoryComponent)
  extensionHistoryComponent!: ExtensionHistoryComponent;


  @ViewChild(RequestGeneralDetailsComponent)
  requestGeneralDetailsComponent!: RequestGeneralDetailsComponent;


  steps: any[] = [];
  request: RequestModel = new RequestModel();
  requestId: number = 0;
  backupUsers: string = '';
  activeStepIndex: number = 0;
  CurrentUserRoleName  !: string;

  workStatusEnum() { typeof WorkStatusEnum; return WorkStatusEnum }
  workFlowActionEnum() { typeof WorkFlowActionEnum; return WorkFlowActionEnum }

  staticText: any;


  constructor(private confirmationService: ConfirmationService, private _loggedUserService: LoggedUserService, private activatedRoute: ActivatedRoute, private _HttpService: HttpService, private messageService: MessageService, private router: Router) { }

  ngOnInit(): void {
    this.GetStaticText();
    this.GetactivatedRoute();
  }

  GetWorkflowSteps(result: any) {
    this.steps = result;
    this.activeStepIndex = result[0].ActiveIndex;

  }

  async GetStaticText() {
    this._HttpService.GetStaticText().subscribe(res => {
      this.staticText = res;
    });
  }

  GetactivatedRoute() {
    var id = this.activatedRoute.snapshot.paramMap.get('id');
    this.requestId = id ? + id : 0;
    if (this.requestId > 0)
      this.GetRequestById();
  }



  GetRequestById() {

    this._HttpService.Get("Request/GetRequestHistoryById", [this.requestId.toString()]).subscribe((res: RequestModel) => {

      this.request = res;


      this.backupUsers = Array.prototype.map.call(this.request.BackupApprovers, function (item) { return item.EmployeeName; }).join(', ');

      this.requestGeneralDetailsComponent.generalDetails = res.General;


        this.requestGeneralDetailsComponent.selectedProcedure = new CMSProcedure();
        this.requestGeneralDetailsComponent.selectedProcedure.DisplayName = res.General.ProcedureDisplayName;
      //  this.request.General.ProcedureTitle =  res.General.ProcedureDisplayName;

      if(this.request.General.IsManual){
        this.requestGeneralDetailsComponent.FunctionalReviewer = new UserDetailModel();
        this.requestGeneralDetailsComponent.FunctionalReviewer.EmployeeName = this.request.General.FunctionalReviewerName;
        this.requestGeneralDetailsComponent.FunctionalReviewer.PersonalNumber =  this.request.General.FunctionalReviewer;

        this.requestGeneralDetailsComponent.TechnicalApprover = new UserDetailModel();

        this.requestGeneralDetailsComponent.TechnicalApprover.EmployeeName = this.request.General.TechnicalApproverName;
        this.requestGeneralDetailsComponent.TechnicalApprover.PersonalNumber =  this.request.General.TechnicalApprover;
      }

      this.requestGeneralDetailsComponent.request = this.request;



      this.requestGeneralDetailsComponent.GetWorkflowSteps(false);

      this.documentsComponent.documentList = res.Documents;
      this.raTeamMembersComponent.RATeamMembers = res.RATeamMembers;


      this.requestGeneralDetailsComponent.GetResonVariance();


      this.requestGeneralDetailsComponent.generalDetails.FromDate = new Date(res.General.FromDate?.toString() ?? '');
      this.requestGeneralDetailsComponent.generalDetails.ToDate = new Date(res.General.ToDate?.toString() ?? '');

      if (res?.RiskAssessment) {
        this.riskAssessmentComponent.Riskassesments = JSON.parse(res?.RiskAssessment?.RAMatrix ?? '');
        this.riskAssessmentComponent.CRAContentList = JSON.parse(res?.RiskAssessment?.CumulativeRAMatrix ?? '');
      }
      else {
         this.riskAssessmentComponent.Riskassesments.push(new RiskAssessmentModel());
      }





      //For reject For rework
      if(this.request.WorkflowStatusId == WorkStatusEnum.Pending_for_Rework || this.request.WorkflowStatusId == WorkStatusEnum.Drafted  )
      {

        //If Request is Not based on CMS Procedure
        if(this.request.General.IsManual)
        {

          this.requestGeneralDetailsComponent.FunctionalReviewer = new UserDetailModel();
          this.requestGeneralDetailsComponent.FunctionalReviewer.PersonalNumber = this.request.General.FunctionalReviewer;
          this.requestGeneralDetailsComponent.FunctionalReviewer.EmployeeName = this.request.General.FunctionalReviewerName;

          this.requestGeneralDetailsComponent.TechnicalApprover = new UserDetailModel();
          this.requestGeneralDetailsComponent.TechnicalApprover.PersonalNumber = this.request.General.TechnicalApprover;
          this.requestGeneralDetailsComponent.TechnicalApprover.EmployeeName = this.request.General.TechnicalApproverName;
        }
        else
        {
          this.requestGeneralDetailsComponent.GetFunctionalReviwers(this.request.General.FunctionalReviewerName?.substring(this.request.General.FunctionalReviewerName?.lastIndexOf(" ")+1, this.request.General.FunctionalReviewerName.length));
          this.requestGeneralDetailsComponent.GetTechnicalApprovers(this.request.General.TechnicalApproverName?.substring(this.request.General.TechnicalApproverName?.lastIndexOf(" ")+1, this.request.General.TechnicalApproverName.length));
        }


      }

      this.requestGeneralDetailsComponent.GetAsset(false);
      this.requestGeneralDetailsComponent.GetFacility(false);




      this.extensionHistoryComponent.GetExtensionHistory(this.request.Id);




    });
  }
}
