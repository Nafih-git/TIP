import { NgModule } from '@angular/core';
import { TableModule } from 'primeng/table';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { CheckboxModule } from 'primeng/checkbox';
import { CommonModule } from '@angular/common';
import { TooltipModule } from 'primeng/tooltip';
import { RequestRoutingModule } from './request-routing.module';
import { NewRequestComponent } from './new-request/new-request.component';
import { DividerModule } from 'primeng/divider';
import { FieldsetModule } from 'primeng/fieldset';
import { DropdownModule } from 'primeng/dropdown';
import { PanelModule } from 'primeng/panel';
import { FormsModule } from '@angular/forms';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { RequestGeneralDetailsComponent } from './new-request/request-general-details/request-general-details.component';
import { LoadingSpinnerModule } from '../utility/directive/loading-spinner/loading-spinner.module';
import { DocumentsComponent } from './new-request/documents/documents.component';
import { FileUploadModule } from 'primeng/fileupload';
import { NumberOnlyModule } from '../utility/directive/numbersOnly/numbersOnly.module';
import { RequestCommentComponent } from './new-request/request-comment/request-comment.component';
import { RequestCommentHistoryComponent } from './new-request/request-comment-history/request-comment-history.component';
import { AllRequestsComponent } from './all-requests/all-requests.component';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MenuModule } from 'primeng/menu';
import { PartialModule } from '../partial/partial.module';
import { ListboxModule } from 'primeng/listbox';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CalendarModule } from 'primeng/calendar';
import { StepsModule } from 'primeng/steps';
import { RiskAssessmentComponent } from './risk-assessment/risk-assessment.component';
import { RaTeamMembersComponent } from './new-request/ra-team-members/ra-team-members.component';
import { MessageModule } from 'primeng/message';
import { TrueFalseValueModule } from '../utility/directive/true-false-value/true-false-value.module';
import { RequesthistoryComponent } from './requesthistory/requesthistory.component';
import {MultiSelectModule} from 'primeng/multiselect';



@NgModule({
  declarations: [
    NewRequestComponent,
    RequestGeneralDetailsComponent,
    DocumentsComponent,
    RequestCommentComponent,
    RequestCommentHistoryComponent,
    AllRequestsComponent,
    DashboardComponent,
    RiskAssessmentComponent,
    RaTeamMembersComponent,
    RequesthistoryComponent,


  ],
  imports: [
    RequestRoutingModule,
    CommonModule,
    FormsModule,
    TableModule,
    InputTextModule,
    ButtonModule,
    DialogModule,
    CheckboxModule,
    TooltipModule,
    DividerModule,
    FieldsetModule,
    PanelModule,
    DropdownModule,
    ConfirmDialogModule,
    LoadingSpinnerModule,
    FileUploadModule,
    NumberOnlyModule,
    AutoCompleteModule,
    MenuModule,
    PartialModule,
    ListboxModule,
    CalendarModule,
    StepsModule,
    MessageModule,
    TrueFalseValueModule,
    MultiSelectModule
  ],
  providers: [],
  bootstrap: []
})
export class RequestModule { }
