import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { LazyLoadEvent, MenuItem } from 'primeng/api';
import { Menu } from 'primeng/menu';
import { Table } from 'primeng/table';
import { WorkStatusEnum } from 'src/app/enums/workFlow-status_enum';
import { AllRequestFilterModel } from 'src/app/models/all-request-filter_model';
import { AllRequestModel } from 'src/app/models/all-request_model';
import { AssetModel } from 'src/app/models/asset_model';
import { DirectorateModel } from 'src/app/models/directorate_model';
import { FacilityModel } from 'src/app/models/facility_model';
import { UserDetailModel } from 'src/app/models/userDetail_model';
import { UserManagement } from 'src/app/models/usermanagement_model';
import { WorkflowStatusModel } from 'src/app/models/workflow-status_model';
import { ApprovalHistoryComponent } from 'src/app/partial/approval-history/approval-history.component';
import { ExtensionHistoryComponent } from 'src/app/partial/extension-history/extension-history.component';
import { TaskHistoryComponent } from 'src/app/partial/task-history/task-history.component';
import { CommonFunctions, excelDisclamerPosition } from 'src/app/utility/common/common-functions';
import { HttpService } from 'src/app/utility/http.service';
import { LoggedUserService } from 'src/app/utility/service/logged-user.service';

@Component({
  selector: 'app-all-requests',
  templateUrl: './all-requests.component.html',
  styleUrls: ['./all-requests.component.css']
})
export class AllRequestsComponent implements OnInit {

  @ViewChild(TaskHistoryComponent) taskHistoryComponent!: TaskHistoryComponent;
  @ViewChild(ApprovalHistoryComponent) approvalHistoryComponent!: ApprovalHistoryComponent;
  @ViewChild(ExtensionHistoryComponent) extensionHistoryComponent!: ExtensionHistoryComponent;
  @ViewChild('dataTable') dataTable!: Table;

  loading: boolean = false;
  displayExtensionHistoryModal: boolean = false;
  allRequestList: AllRequestModel[] = new Array<AllRequestModel>();
  allRequestExportList: AllRequestModel[] = new Array<AllRequestModel>();
  selectedRow: AllRequestModel = new AllRequestModel();
  totalRecords: number = 0;
  allRequestFilter: AllRequestFilterModel = new AllRequestFilterModel();
  directorates: DirectorateModel[] = new Array<DirectorateModel>();
  assets: AssetModel[] = new Array<AssetModel>();
  facilityList: FacilityModel[] = new Array<FacilityModel>();
  workflowStatusses: WorkflowStatusModel[] = new Array<WorkflowStatusModel>();

  requestId!: number | null;
  directorate: string = '';
  asset: string = '';
  facility: string = '';
  workflowStatusId: number = 0;
  tocId: number = 0;
  startDate!: Date | null;
  endDate!: Date | null;

  pageHeader: string = "All Requests";
  isMyTaskPage: boolean = false;

  userDetail: UserDetailModel = new UserDetailModel();
  userDetails: UserDetailModel[] = new Array<UserDetailModel>();

  SubmittedByuserDetail: UserDetailModel = new UserDetailModel();
  SubmittedByuserDetails: UserDetailModel[] = new Array<UserDetailModel>();

  userSearchSubscribe: any;
  clearClick: boolean = false;

  cols: any[] = [
    { field: 'Id', header: 'Request No', width: '110px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'Indicator', header: 'Indicator', width: '60px', isBadge: false, isIndicator: true, isDate: false, isSorting: false, isFilter: false, isExportable: false },
    { field: 'CustomStatus', header: 'eMOC Status', width: '250px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'PendingWithName', header: 'Pending With', width: '200px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ProcedureDisplayName', header: 'Procedure', width: '150px', isBadge: false, isIndicator: false, isDate: false, isSorting: false, isFilter: true, isExportable: true },

    { field: 'Directorate', header: 'Directorate', width: '100px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'Asset', header: 'Asset', width: '100px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'Facility', header: 'Facility', width: '150px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'ReasonVarianceName', header: 'Reason of VarianceName', width: '150px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: false, isExportable: true },
    { field: 'IsCMSIntegration', header: 'CMS Procedure', width: '150px', isBadge: true, isIndicator: false, isDate: false, isSorting: false, isFilter: false, isExportable: true },
    { field: 'TaskAssignedDate', header:'Task Assigned Date' , width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, isExportable: true },
    { field: 'FromDate', header: 'From Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ToDate', header: 'To Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, isExportable: true },
    { field: 'ImplementedDate', header: 'Implemented Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedByName', header: 'Submitted By', width: '150px', isBadge: false, isIndicator: false, isDate: false, isSorting: true, isFilter: true, isExportable: true },
    { field: 'CreatedDate', header: 'Submitted Date', width: '150px', isBadge: false, isIndicator: false, isDate: true, isSorting: true, isFilter: true, isExportable: true },
  ];

  items: MenuItem[] = [];

  displayTaskHistoryModal: boolean = false;
  displayApprovalHistoryModal: boolean = false;

  constructor(private _HttpService: HttpService, private _rout: Router, private _logUserSvc: LoggedUserService) { }

  searchUser(event: any): void {
    if (this.userSearchSubscribe) {
      this.userSearchSubscribe.unsubscribe();
    }
    this.userSearchSubscribe = this._HttpService.Get("UserManagement/SearchUser", [event.query]).subscribe(res => {
      this.userDetails = res;
    });
  }


  searchSubmittedByUser(event: any): void {
    if (this.userSearchSubscribe) {
      this.userSearchSubscribe.unsubscribe();
    }
    this.userSearchSubscribe = this._HttpService.Get("UserManagement/SearchUser", [event.query]).subscribe(res => {
      this.SubmittedByuserDetails = res;
    });
  }

  ngOnInit(): void {
    this.GetDirectorates();
    this.GetWorkflowStatus();

    if (this._rout.url == CommonFunctions.GetMyTaskPage()) {
      this.isMyTaskPage = true;
      this.pageHeader = "My Tasks";

      this.userDetail = new UserDetailModel();
      this.SubmittedByuserDetail = new UserDetailModel();
      // this.userDetail.PersonalNumber = this._logUserSvc.loggedUser.PersonalNumber;
      this.Filter();
    }

  }





  async GetDirectorates() {
    return new Promise(resolve => {
      this._HttpService.GetAll("Master/GetDirectorates").subscribe(res => {
        this.directorates = res;
        resolve("Success");
      });
    });
  }

  GetAsset() {

    this._HttpService.Get1("Master/GetAssets", { Directorate: this.directorate }).subscribe(res => {
      this.assets = res;
    });
  }

  GetFacilities() {
    this._HttpService.Get1("Master/GetFacilities", { Directorate: this.directorate, Asset: this.asset }).subscribe(res => {
      this.facilityList = res;
    });
  }

  GetWorkflowStatus() {
    this._HttpService.GetAll("Master/GetWorkflowStatus").subscribe(res => {
      this.workflowStatusses = res;
    });
  }

  GetAllRequests() {
    this.loading = true;
    this._HttpService.Get1('Request/GetAllRequests', { FilterString: JSON.stringify(this.allRequestFilter) }).subscribe(res => {
      if (res) {
        this.allRequestList = res;
        this.totalRecords = this.allRequestList[0]?.TotalRecords ?? 0;

        if (this.isMyTaskPage) this._logUserSvc.loggedUser.TaskCount = this.totalRecords;

        if (this.totalRecords > 0) {

          this.allRequestList.forEach(s => {

            if (s.CreatedDate) s.CreatedDate = new Date(s.CreatedDate);
            if (s.ModifiedDate) s.ModifiedDate = new Date(s.ModifiedDate);
            if (s.ModifiedDate) s.ModifiedDate = new Date(s.ModifiedDate);
          });
        }
console.log(this.allRequestList);
        this.loading = false;
      }
    });
  }

  GetAllRequestsExport() {
    this.allRequestFilter.FullRecords = 1;
    this._HttpService.Get1('Request/GetAllRequests', { FilterString: JSON.stringify(this.allRequestFilter) }).subscribe(res => {
      if (res) {

        this.allRequestExportList = res;
        this.totalRecords = this.allRequestExportList[0]?.TotalRecords ?? 0;

        if (this.totalRecords > 0) {

          this.allRequestExportList.forEach(s => {

            if (s.CreatedDate) s.CreatedDate = new Date(s.CreatedDate);
            if (s.ModifiedDate) s.ModifiedDate = new Date(s.ModifiedDate);
          });
          CommonFunctions.ExportExcel(this.cols, this.allRequestExportList, this.isMyTaskPage ? 'Pending Tasks of ' + this._logUserSvc.loggedUser.EmployeeName : 'All Requests');
        }
      }
    });
  }

  NextPage(event: LazyLoadEvent) {

    this.allRequestFilter.First = event.first ?? 0;
    this.allRequestFilter.Rows = event.rows ?? 10;
    this.allRequestFilter.SortField = event.sortField ?? 'Id';
    // this.allRequestFilter.SortOrder = event.sortOrder === 1 ? 'ASC' : 'DESC';

    if (this.clearClick) {
      this.allRequestFilter.SortOrder = 'DESC';
    }
    else {
      this.allRequestFilter.SortOrder = event.sortOrder === 1 ? 'ASC' : 'DESC';
    }

    this.clearClick = false;

    this.GetAllRequests();
  }

  Filter() {
    this.allRequestFilter = new AllRequestFilterModel();
    this.allRequestFilter.SortField = 'Id';
    this.allRequestFilter.SortOrder = 'DESC';
    this.allRequestFilter.FullRecords = 0;
    this.allRequestFilter.RequestFilter = JSON.stringify({
      RequestId: this.requestId ?? 0,
      Directorate: this.directorate,
      Asset: this.asset,
      Facility: this.facility,
      WorkflowStatusId: this.workflowStatusId ?? 0,
      TocId: this.tocId ?? 0,
      IsMyTask : this.isMyTaskPage == true ? 1:0,
      PendingWith: this.userDetail.PersonalNumber ?? '',
      SubmittedBy: this.SubmittedByuserDetail.PersonalNumber ?? '',
      StartDate: this.startDate ? this.startDate.toLocaleDateString() : '',
      EndDate: this.endDate ? this.endDate.toLocaleDateString() : ''
    });

    console.log(this.allRequestFilter.RequestFilter);
    this.GetAllRequests();
  }

  FilterExport() {

    this.Filter();
    this.GetAllRequestsExport();
  }

  ClearFilter() {

    this.allRequestFilter = new AllRequestFilterModel();

    this.allRequestFilter.SortField = "Id";
    this.allRequestFilter.SortOrder = "DESC";


    this.requestId = null;
    this.directorate = '';
    this.asset = '';
    this.facility = '';
    this.workflowStatusId = 0;
    this.tocId = 0;
    this.startDate = null;
    this.endDate = null;

    this.userDetail = new UserDetailModel();
    this.userDetails = new Array<UserDetailModel>();

    this.SubmittedByuserDetail = new UserDetailModel();
    this.SubmittedByuserDetails = new Array<UserDetailModel>();

    if (this.isMyTaskPage)
      this.userDetail.PersonalNumber = this._logUserSvc.loggedUser.PersonalNumber;

    this.clearClick = true;
    this.Filter();
    // this.dataTable.reset();
  }

  ToggleMenu(menu: Menu, event: Event, rowData: AllRequestModel) {
    this.selectedRow = rowData;
    this.items = [
      { label: 'Edit/View Request ', icon: 'pi pi-fw pi-pencil', command: (event: any) => this.ViewRequestDetail(event) },
      { label: 'Task History', icon: 'pi pi-fw pi-history', command: (event: any) => this.ViewTaskHistory(event) },
      { label: 'Approval History', icon: 'pi pi-fw pi-history', command: (event: any) => this.ViewApproval(event) },
      { label: 'Copy Request ', icon: 'pi pi-copy', command: (event: any) => this.CopyRequestDetail(event) },
    ];

    if (rowData.ExtensionCount > 0) {
      this.items.push({ label: 'Extension History', icon: 'pi pi-fw pi-history', command: (event: any) => this.ViewExtension(event) });
    }

    menu.toggle(event);
  }
  ViewExtension(event: any) {

    this.displayExtensionHistoryModal = true;

    this.extensionHistoryComponent.GetExtensionHistory(this.selectedRow.Id);
  }
  ViewRequestDetail(event: any) {

    //this._rout.navigateByUrl(`/eMOC-request/new-request/${ this.selectedRow.Id }`);
    CommonFunctions.GetEditRequestPageInNewTab(this.selectedRow.Id);
  }

  CopyRequestDetail(event: any) {

    //this._rout.navigateByUrl(`/eMOC-request/new-request/${ this.selectedRow.Id }`);
    CommonFunctions.GetCopyRequestPageInNewTab(this.selectedRow.Id);
  }
  TransferToIOC(event: any) {

    //this._rout.navigateByUrl(`/eMOC-request/new-request/${ this.selectedRow.Id }`);
    CommonFunctions.GetRequestPageInNewTabForIOC(this.selectedRow.Id);
  }

  ViewTaskHistory(event: any) {

    this.taskHistoryComponent.GetAllTasks(this.selectedRow.Id);

    this.displayTaskHistoryModal = true;
  }

  ViewApproval(event: any) {

    this.displayApprovalHistoryModal = true;

    this.approvalHistoryComponent.GetApprovalHistory(this.selectedRow.Id, 10);
  }

  Close(modelType: string) {

    if (modelType == 'TaskHistory') {

      this.displayTaskHistoryModal = false;
    }
    else if (modelType == 'ApprovalHistory') {

      this.displayApprovalHistoryModal = false;
    }
    else if (modelType == 'ExtensionHistory') {

      this.displayExtensionHistoryModal = false;
    }
  }

  exportExcel() {
    this.FilterExport();
  }

  SelectStartDate() {

    if (!this.endDate || (this.startDate && this.startDate > this.endDate)) {

      this.endDate = this.startDate;
    }
  }

  SelectEndDate() {

    if (!this.startDate || (this.endDate && this.startDate > this.endDate)) {

      this.startDate = this.endDate;
    }
  }
}
