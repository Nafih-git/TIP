import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RouteDataEnum } from '../enums/route-data_enum';
import { AuthGuardService } from '../utility/service/auth-guard.service';
import { AllRequestsComponent } from './all-requests/all-requests.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NewRequestComponent } from './new-request/new-request.component';
import { RequesthistoryComponent } from './requesthistory/requesthistory.component';
import { RiskAssessmentComponent } from './risk-assessment/risk-assessment.component';

const routes: Routes = [
  { path: 'RiskAssessment', component: RiskAssessmentComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.Dashboard }},
  { path: 'new-request', component: NewRequestComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.NewRequest } },
  { path: 'all-requests', component: AllRequestsComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.AllRequest } },
  { path: 'my-tasks', component: AllRequestsComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.PendingTasks }},
  { path: 'new-request/:id', component: NewRequestComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.NewRequest } },
  { path: 'copyrequest/:copy_requestid', component: NewRequestComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.NewRequest } },
  { path: 'TOIOC/:toioc_requestid', component: NewRequestComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.NewRequest } },
  { path: 'requesthistory/:id', component: RequesthistoryComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.NewRequest } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RequestRoutingModule { }
