import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpEvent, HttpResponse, HttpRequest, HttpHandler, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { ErrorService } from "../service/error.service";
@Injectable()
export class WinAuthInterceptor implements HttpInterceptor {

  constructor(public errorService: ErrorService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    req = req.clone({ withCredentials: true });
    return next.handle(req)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          if (error.error instanceof ErrorEvent) {
            this.errorService.message = `Error: ${error.error.message}`;
          }
          else {
            if (error.error && error.error.Detail)
              this.errorService.message = error.error.Detail;
            else this.errorService.message = error.status + ' - ' + error.message;
          }
          this.errorService.display = true;
          return throwError(this.errorService.message);

        })
      );
  }
}
