import { NgModule } from '@angular/core';
import { NumberOnlyDirective } from './numbersOnly.directive';

@NgModule({
  declarations: [
    NumberOnlyDirective
  ],
  imports: [

  ],
  exports: [
    NumberOnlyDirective
  ],
  providers: [],
  bootstrap: []
})
export class NumberOnlyModule { }
