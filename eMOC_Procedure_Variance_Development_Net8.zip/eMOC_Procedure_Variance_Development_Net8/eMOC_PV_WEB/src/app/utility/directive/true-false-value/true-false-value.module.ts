import { NgModule } from '@angular/core';
import { TrueFalseValueDirective } from './true-false-value.directive';

@NgModule({
  declarations: [
    TrueFalseValueDirective
  ],
  imports: [
  
  ],
  exports: [
    TrueFalseValueDirective
  ],
  providers: [],
  bootstrap: []
})
export class TrueFalseValueModule { }
