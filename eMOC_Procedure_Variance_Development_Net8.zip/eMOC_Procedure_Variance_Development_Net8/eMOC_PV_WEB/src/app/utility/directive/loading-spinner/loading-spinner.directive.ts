import { ComponentFactoryResolver, HostBinding, TemplateRef, ViewContainerRef } from "@angular/core";
import { ElementRef } from "@angular/core";
import { OnInit } from "@angular/core";
import { Renderer2 } from "@angular/core";
import { Input } from "@angular/core";
import { Directive } from "@angular/core";
import { SpinnerComponent } from "../../../template/spinner/spinner.component";

@Directive({
  selector: '[ngLoaded]'
})
export class LoadingSpinnerDirective {
  @Input() @HostBinding('class.emoc-loading') isLoading = false;
}
