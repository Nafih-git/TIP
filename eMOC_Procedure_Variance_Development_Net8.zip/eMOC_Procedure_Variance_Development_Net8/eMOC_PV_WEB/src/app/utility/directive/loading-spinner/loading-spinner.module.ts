import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { SpinnerComponent } from "../../../template/spinner/spinner.component";
import { LoadingSpinnerDirective } from "./loading-spinner.directive";

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    SpinnerComponent,
    LoadingSpinnerDirective
  ],
  entryComponents: [
    SpinnerComponent
  ],
  exports: [
    LoadingSpinnerDirective
  ]
})
export class LoadingSpinnerModule {
}
