
import * as FileSaver from 'file-saver';
import { WorkSheet } from 'xlsx';
import { MessageStatusEnum } from '../../enums/message-status_enum';
import { RolesModel } from '../../models/roles_model';
import jsPDF from 'jspdf';
import("jspdf");
export enum excelDisclamerPosition {
  none = 0,
  header = 1,
  footer = 2
}


export const CommonFunctions = {
  MessageStatus: (type: number) => {
    switch (type) {
      case MessageStatusEnum.Success: {
        return 'success'
      }
      case MessageStatusEnum.Error: {
        return 'success'
      }
      case MessageStatusEnum.Warn: {
        return 'warn'
      }
      default: {
        return 'info'
      }
    }
  },
  numberToBool: (type: number) => {
    return type == 1;
  },
  BoolToNumber: (type: boolean) => {
    return type ? 1 : 0;
  },
  FormatDateString(_date: any) {

    var Result = "";
    if (_date == null)
      return "";
    if (_date == "")
      return "";



    if (_date.indexOf("-") > 0) {
      if (_date != null) {
        var _Date = new Date(parseInt(_date.substr(6)));
        var date = new Date(_Date);

        Result = ("0" + (date.getMonth() + 1)).slice(-2) + '/' + ("0" + date.getDate()).slice(-2) + '/' + date.getFullYear();

      }
    }
    else if (_date.indexOf("/") == 0) {
      if (_date != null) {
        var date = new Date(eval((_date).replace(/\/Date\((\d+)\)\//gi, "new Date($1)")));

        Result = ("0" + (date.getMonth() + 1)).slice(-2) + '/' + ("0" + date.getDate()).slice(-2) + '/' + date.getFullYear();

      }

    }

    else
      Result = _date;



    if (Result == 'aN/aN/NaN')
      return "";
    else if (Result == '01/01/1')
      return "";
    else if (Result == '01/01/1900')
      return "";
    else
      return Result;
  },
  dateDiff: (date1: any, date2: any) => {
    var olddate1 = new Date(CommonFunctions.FormatDateString(date1));
    var olddate2 = new Date(CommonFunctions.FormatDateString(date2));

    var datediff = olddate2.getTime() - olddate1.getTime(); //store the getTime diff - or +
    return (datediff / (24 * 60 * 60 * 1000)) + 1;
  },
  base64ToArrayBuffer: (_base64Str: string) => {
    var binaryString = window.atob(_base64Str);
    var binaryLen = binaryString.length;
    var bytes = new Uint8Array(binaryLen);
    for (var i = 0; i < binaryLen; i++) {
      var ascii = binaryString.charCodeAt(i);
      bytes[i] = ascii;
    }
    return bytes;
  },
  base64toBlob: (base64Data: string, contentType: string) => {
    contentType = contentType || '';
    let sliceSize = 1024;
    let byteCharacters = atob(base64Data);
    let bytesLength = byteCharacters.length;
    let slicesCount = Math.ceil(bytesLength / sliceSize);
    let byteArrays = new Array(slicesCount);
    for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      let begin = sliceIndex * sliceSize;
      let end = Math.min(begin + sliceSize, bytesLength);

      let bytes = new Array(end - begin);
      for (var offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  },
  GetLoggedInUserDetails: () => {
    let model: any = {};
    if (localStorage.getItem("LoggedUserDetail") != null) {
      model = JSON.parse(localStorage.getItem("LoggedUserDetail") ?? "");
    }
    return model;
  },
  GetLoggedInUserMU: () => {
    var model = CommonFunctions.GetLoggedInUserDetails();
    if (model != null) {
      model = JSON.parse(localStorage.getItem("LoggedUserDetail") ?? "");
      return model.PersonalNumber.split("\\")[1];
    }
    return "";

  },
  GetLoggedInUserName: () => {
    var model = CommonFunctions.GetLoggedInUserDetails();
    if (model != null) {
      return (model.EmployeeName == null || model.EmployeeName == "") ? model.PersonalNumber.split("\\")[1] : model.EmployeeName;
    }
    return "";

  },
  ConcateUserRoles: (UserRoles: RolesModel[]) => {
    var str = "";
    if (UserRoles != null) {
      var list = UserRoles.map(x => x.Name);
      if (list != null) {
        str += "(";
        str += list.join(',');
        str += ")";
      }

    }
    return str;
  },
  ColumnRowMapping: (exportColumns: any[], list: any[]) => {
    return list.map((o: any) => {
      return exportColumns.reduce((newo: any, name: any) => {
        newo[name.dataKey] = o[name.dataKey];
        if (Array.isArray(newo[name.dataKey])) newo[name.dataKey] = newo[name.dataKey].toString();
        return newo;
      }, {});
    });
  },
  // ExportExcelColumnRowMap: (exportColumns: any[], list: any[], fileName: string = "excel") => {
  //   import("xlsx").then(xlsx => {
  //     var data: any[] = CommonFunctions.ColumnRowMapping(exportColumns, list);
  //     var headers: string[] = exportColumns.map(col => col.title);
  //     const worksheet: WorkSheet = xlsx.utils.json_to_sheet(data);
  //     xlsx.utils.sheet_add_aoa(worksheet, [headers]);
  //     const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
  //     const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
  //     CommonFunctions.saveAsExcelFile(excelBuffer, fileName);
  //   });
  // },
  ExportExcel: (cols: any[], list: any[], fileName: string = "excel", disclaimerPosition: excelDisclamerPosition = excelDisclamerPosition.footer) => {
    import("xlsx").then(xlsx => {
      var exportColumns: any[] = cols.filter(c => c.isExportable).map(col => ({ title: col.header, dataKey: col.field }));
      var headers: string[] = exportColumns.map(col => col.title);
      var data: any[] = CommonFunctions.ColumnRowMapping(exportColumns, list);
      const worksheet: WorkSheet = xlsx.utils.json_to_sheet(data);
      xlsx.utils.sheet_add_aoa(worksheet, [headers], { origin: 0 });
      if (disclaimerPosition != excelDisclamerPosition.none) {
        var disclaimer = ["Disclaimer : ", "This document is the property of Petroleum Development Oman, LLC. Neither the whole nor any part of this document may be disclosed to others or reproduced, stored in a retrieval system, or transmitted in any form by any means (electronic, mechanical, reprographic recording or otherwise) without prior written consent of the owner"];
        xlsx.utils.sheet_add_aoa(worksheet, [disclaimer], { origin: disclaimerPosition == excelDisclamerPosition.footer ? -1 : 0 });
        var colmnLength = data.length + 1;
        var headerLength = headers.length - 1;
        var merge = { s: { r: colmnLength, c: 1 }, e: { r: colmnLength, c: headerLength } };
        if (disclaimerPosition == 1) {
          merge = { s: { r: 0, c: 1 }, e: { r: 0, c: headerLength } };
        }
        if (!worksheet['!merges']) worksheet['!merges'] = [];
        worksheet['!merges'].push(merge)
      }

      const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
      CommonFunctions.saveAsExcelFile(excelBuffer, fileName);
    });
  },
  saveAsExcelFile: (buffer: any, fileName: string) => {
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
    });
    FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  },
  ExportPdf: (cols: any[], list: any[], fileName: string = "pdf") => {
    var exportColumns: any[] = cols.filter(c => c.isExportable).map(col => ({ title: col.header, dataKey: col.field }));
    import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
        const doc = new jsPDF.default('p', 'pt');
        (doc as any).autoTable(exportColumns, list);
        doc.save(fileName + '.pdf');
      })
    })
  },
  CheckBoxBoolValueToNumber: ($event: boolean, object: any) => {

  },
  DownloadPDF(bytearray : any){

    var doc = new jsPDF();
    doc.output(bytearray);
  },
  emocClone: (data: any) => {
    return JSON.parse(JSON.stringify(data));
  },
  convertModelArrayToFormData: (model: any, form: any = null, namespace = ''): FormData => {
    let formData = form || new FormData();
    let formKey;
    var index = 0;
    namespace = "[" + (index) + "]";
    for (let propertyName in model) {
      if (!model.hasOwnProperty(propertyName) || !model[propertyName]) continue;
      let formKey = namespace ? `${namespace}[${propertyName}]` : propertyName;
      if (model[propertyName] instanceof Date)
        formData.append(formKey, model[propertyName].toISOString());
      else if (model[propertyName] instanceof Array) {
        model[propertyName].forEach((element: any, index: number) => {
          const tempFormKey = `${formKey}[${(index)}]`;
          CommonFunctions.convertModelToFormData(element, formData, tempFormKey);
        });
      }
      else if (typeof model[propertyName] === 'object' && !(model[propertyName] instanceof File))
        CommonFunctions.convertModelToFormData(model[propertyName], formData, formKey);
      else
        formData.append(formKey, model[propertyName]);
    }
    return formData;
  },
  convertModelToFormData: (model: any, form: any = null, namespace = ''): FormData => {
    let formData = form || new FormData();
    let formKey;

    for (let propertyName in model) {
      if (!model.hasOwnProperty(propertyName) || !model[propertyName]) continue;
      let formKey = namespace ? `${namespace}[${propertyName}]` : propertyName;
      if (model[propertyName] instanceof Date)
        formData.append(formKey, model[propertyName].toISOString());
      else if (model[propertyName] instanceof Array) {
        model[propertyName].forEach((element: any, index: number) => {
          const tempFormKey = `${formKey}[${index}]`;
          CommonFunctions.convertModelToFormData(element, formData, tempFormKey);
        });
      }
      else if (typeof model[propertyName] === 'object' && !(model[propertyName] instanceof File))
        CommonFunctions.convertModelToFormData(model[propertyName], formData, formKey);
      else
        formData.append(formKey, model[propertyName]);
    }
    return formData;
  },
  GetLandingPage: () => {
    return "/eMOC-request/dashboard"
  },
  GetAllRequestPage: () => {
    return "/eMOC-request/all-requests"
  },
  GetMyTaskPage: () => {
    return "/eMOC-request/my-tasks"
  },
  downloadFile: (url: string, type: string, fileName: string, file?: any) => {

    let blob = null;

    if (file) {

      blob = new Blob([file], { type: type });

    } else if (url) {

      blob = CommonFunctions.base64ToBlob(url, type);

    }

    if (blob) {

      const newurl = URL.createObjectURL(blob);



      let link: any = document.createElement("a");

      link.href = newurl;



      //set the visibility hidden so it will not effect on your web-layout

      link.style = "visibility:hidden";

      link.download = fileName;

      //this part will append the anchor tag and remove it after automatic click

      document.body.appendChild(link);

      link.click();

      document.body.removeChild(link);

    }

  },
  base64ToBlob: (base64: any, type = "application/octet-stream") => {

    var binary = atob(base64.split(',')[1]), array = [];

    for (var i = 0; i < binary.length; i++) array.push(binary.charCodeAt(i));

    return new Blob([new Uint8Array(array)], { type: type });

  },
  webSiteOrigin: (): string => {
    return window.location.origin.concat(window.location.pathname);

  },
  GetNewRequestPage: () => {
    return "/eMOC-request/new-request"
  },
  GetCopyRequestPage: () => {
    return "/eMOC-request/copyrequest"
  },
  GetTOIOCRequestPage: () => {
    return "/eMOC-request/TOIOC"
  },
  GetRequestHistoryPage: () => {
    return "/eMOC-request/requesthistory"
  },
  GetEditRequestPageInNewTab: (Id: number) => {
    var url = CommonFunctions.webSiteOrigin().concat(`#${CommonFunctions.GetNewRequestPage()}/${Id}`);
    window.open(url, '_blank');
  },
  GetCopyRequestPageInNewTab: (Id: number) => {
    var url = CommonFunctions.webSiteOrigin().concat(`#${CommonFunctions.GetCopyRequestPage()}/${Id}`);
    window.open(url, '_blank');
  },
  GetRequestPageInNewTabForIOC: (Id: number) => {
    var url = CommonFunctions.webSiteOrigin().concat(`#${CommonFunctions.GetTOIOCRequestPage()}/${Id}`);
    window.open(url, '_blank');
  },
  GetRequestHistoryPageInNewTab: (Id: number) => {
    var url = CommonFunctions.webSiteOrigin().concat(`#${CommonFunctions.GetRequestHistoryPage()}/${Id}`);
    window.open(url, '_blank');
  },
  containsOnlyNumbers: (value: string) => {
    return /^\d+$/.test(value);
  },
 removeSpaceFromString: (value: string) => {
   return value.replace(/\s/g, '');
  },
  stringtrimStartEnd: (value: string) => {
    return value.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
  },
   IsVisioFile: (fileName : string): boolean => {
      var lastDot = fileName.lastIndexOf(".");
      var extension = fileName.substring(lastDot+1);
      console.log(extension);
      if(extension.toLowerCase() == 'vsdx'){

      return true;
      }
      return false;


  },
  GetVisioFileName: (fileName : string): string => {
    var lastDot = fileName.lastIndexOf("/");
    var fileNmae = fileName.substring(lastDot+1);

   return fileNmae;


}
};
