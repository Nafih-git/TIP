import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({
  providedIn: 'root',
})
export class LoggedUserService {
  loggedUser: any;
  loggedUserEvent: Subject<any> = new Subject<any>();

  constructor()
  {
    this.loggedUserEvent.subscribe(data =>{
      this.loggedUser = data;
    });
  }
}
