import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from "@angular/router";
import { map, Observable } from "rxjs";
import { HttpService } from "../http.service";

@Injectable()
export class AuthGuardService implements CanActivate {
  constructor(public router: Router, private _HttpService: HttpService) {
  }
  //canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
  //  return true;
  //  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean>  {
    var dataRoute = route.data as any;
    var data = "";
    if (dataRoute && dataRoute["code"]) {
      data = dataRoute["code"];
    }
    return this._HttpService.Get("Common/IsAuthorized", [data]).pipe(map((response: boolean) => {
      if (!response) {
        this.router.navigateByUrl("/unauthorized");
      }
      return response

    }))
  }
}
