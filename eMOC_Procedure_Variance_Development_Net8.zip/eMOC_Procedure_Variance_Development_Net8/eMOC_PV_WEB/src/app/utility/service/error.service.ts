import { Injectable } from "@angular/core";

@Injectable({
  providedIn: 'root',
})
export class ErrorService {
  display: boolean = false;
  message: string = "";
}
