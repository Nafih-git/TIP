import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { NgZone } from '@angular/core';
import { Injectable } from '@angular/core';
import { MessageService } from 'primeng/api';
import { catchError, Observable, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { ErrorService } from './service/error.service';

@Injectable({
  providedIn: 'root',
})
export class HttpService {

  constructor(private _http: HttpClient, private ngZone: NgZone) { }
    
  GetAll(url: string): Observable<any> {
    return this._http.get(environment.apiUrl.concat(url), { responseType: 'json' })
      .pipe(
      catchError(this.handleError)
    );
  }

  Get(url: string, paramList: string[]): Observable<any> {
    var params = environment.apiUrl.concat(url);
    // paramList.forEach(s => { params = [params, s].join("/") })
    paramList.forEach(s => { params = [params, s.replace(/\//g, '-').replace(/\\/g, '-')].join("/"); })
    return this._http.get(params);
  }

  Get1(api: string, arg: any = null): Observable<any> {
    if (arg) {
      let param = new HttpParams()
      Object.keys(arg).forEach((key: any) => {
        param = param.set(key, arg[key]);
      });
      return this._http.get<any>(environment.apiUrl.concat(api), { params: param });
    }
    else
      return this._http.get<any>(environment.apiUrl.concat(api));
  }

  Post(url: string, params: any): Observable<any> {


    // var headers = new HttpHeaders();
    // headers.append("Access-Control-Allow-Origin","http://localhost:4200")
    // headers.append("Access-Control-Allow-Methods","POST")
    // headers.append("Access-Control-Allow-Headers", "Content-Type")
    // headers.append("Content-Type", "application/json; charset=utf-8")
    return this._http.post(environment.apiUrl.concat(url), params);
  }

  handleError(error: HttpErrorResponse) {
    return throwError(error);
  }

  GetStaticText() {
    return this._http.get("assets/staticText.json");
  }
}
