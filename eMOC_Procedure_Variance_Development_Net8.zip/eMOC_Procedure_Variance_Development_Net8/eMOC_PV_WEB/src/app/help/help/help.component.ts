import { Component, OnInit } from '@angular/core';
import { HelpDocumentsModel } from 'src/app/models/help-document_model';
import { CommonFunctions } from 'src/app/utility/common/common-functions';
import { HttpService } from 'src/app/utility/http.service';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.css']
})
export class HelpComponent implements OnInit {

  helpDocumentList: HelpDocumentsModel[] = new Array<HelpDocumentsModel>();
  isSaving: boolean = false;
  constructor(private _HttpService: HttpService) { }

  ngOnInit(): void {

    this.GetAllHelpInfo();
  }

  GetAllHelpInfo() {

    this.helpDocumentList = new Array<HelpDocumentsModel>();

    this._HttpService.GetAll("Common/GetActiveHelpDocuments").subscribe(res => {

      this.helpDocumentList = res;
    });
  }

  DownloadFile(row: HelpDocumentsModel) {
    this.isSaving = true;
    this._HttpService.Get1("Common/DownloadHelpFile", { FileName: row.Guid }).subscribe(res => {
      CommonFunctions.downloadFile("data:" + res.ContentType + ";base64," + res.FileContents, row.MimeType, row.FileName, null);
      this.isSaving = false;
    });
  }
}
