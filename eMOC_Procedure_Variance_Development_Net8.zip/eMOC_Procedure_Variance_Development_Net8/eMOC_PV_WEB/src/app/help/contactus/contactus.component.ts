import { Component, OnInit } from '@angular/core';
import { HttpService } from 'src/app/utility/http.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {
  SMAXUrl: string = "";
  SMAXCallCenter: string = "";
  techSupport: any = [];
  busiSupport: any = [];
  focalType: string = "";
  tcols: number = 12;
  bcols: number = 12;
  constructor(private http: HttpService) { }

  ngOnInit(): void {
    this.getContactUsInfo();
  }

  getContactUsInfo() {
    this.http.GetAll("Common/GetContactUs").subscribe(res => {
      this.SMAXUrl = res.Table[0].SMAXUrl;
      this.SMAXCallCenter = res.Table[0].SMAXCallCenter;
      this.techSupport = res.Table.filter((item: any) => {
        if (item.DisplayName)
          return item;
      });
      this.tcols = 12 / this.techSupport.length < 3 ? 3 : 12 / this.techSupport.length;
      console.log(this.techSupport)
      this.busiSupport = res.Table1;
      this.focalType = this.busiSupport.length > 0 ? this.busiSupport[0].FocalType : 'T';
      this.bcols = 12 / this.busiSupport.length < 3 ? 3 : 12 / this.busiSupport.length;
    });
  }
}
