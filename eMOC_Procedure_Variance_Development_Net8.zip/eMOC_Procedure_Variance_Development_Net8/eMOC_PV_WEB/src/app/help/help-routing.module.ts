import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RouteDataEnum } from '../enums/route-data_enum';
import { AuthGuardService } from '../utility/service/auth-guard.service';
import { ContactusComponent } from './contactus/contactus.component';
import { HelpComponent } from './help/help.component';

const routes: Routes = [
  { path: 'contact-us', component: ContactusComponent },
  { path: 'help', component: HelpComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.UserGuide }},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HelpRoutingModule { }
