import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HelpRoutingModule } from './help-routing.module';
import { ContactusComponent } from './contactus/contactus.component';
import { HelpComponent } from './help/help.component';
import { ButtonModule } from 'primeng/button';
import { LoadingSpinnerModule } from '../utility/directive/loading-spinner/loading-spinner.module';


@NgModule({
  declarations: [
    ContactusComponent,
    HelpComponent
  ],
  imports: [
    CommonModule,
    HelpRoutingModule,
    ButtonModule,
    LoadingSpinnerModule
  ]
})
export class HelpModule { }
