import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingWithComponent } from './pending-with.component';

describe('PendingWithComponent', () => {
  let component: PendingWithComponent;
  let fixture: ComponentFixture<PendingWithComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PendingWithComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingWithComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
