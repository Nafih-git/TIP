import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RouteDataEnum } from '../enums/route-data_enum';
import { AuthGuardService } from '../utility/service/auth-guard.service';
import { PendingWithComponent } from './pending-with/pending-with.component';


const routes: Routes = [
  {
    path: 'pending/:id', component: PendingWithComponent, canActivate: [AuthGuardService], data: { code: RouteDataEnum.PendingWithFR }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PendingRoutingModule { }
