import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
  bgList: any = [
    { image: "url('assets/img/landing.jpg')" },
    // { image: "url('assets/img/IOC_Front_Aspect.jpg')" },
    // { image: "url('assets/img/IOC_with_cluster_names.jpg')" }
  ];
  background: string = "";
  constructor() {
  }

  ngOnInit(): void {
    this.setRandomBg();
  }

  setRandomBg() {
    this.background = this.bgList[Math.floor(Math.random() * this.bgList.length)].image;
  }
}
