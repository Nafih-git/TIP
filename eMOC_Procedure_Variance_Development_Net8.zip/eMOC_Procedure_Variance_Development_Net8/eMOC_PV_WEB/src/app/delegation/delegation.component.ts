import { Component, OnInit } from '@angular/core';

import { LoggedUserService } from '../utility/service/logged-user.service';
import { HttpService } from '../utility/http.service';
import { MessageService } from 'primeng/api';
import { RolesModel } from '../models/roles_model';

import { DirectorateModel } from '../models/directorate_model';
import { AssetModel } from '../models/asset_model';
import { CommonFunctions } from '../utility/common/common-functions';
import { MessageStatusEnum } from '../enums/message-status_enum';
import { DelegateRole } from '../models/delegate_model';
import { UserDetailModel } from '../models/userDetail_model';

@Component({
  selector: 'app-delegation',
  templateUrl: './delegation.component.html',
  styleUrls: ['./delegation.component.css']
})
export class DelegationComponent implements OnInit {

  displayModal: boolean = false;
  selectedUser: UserDetailModel = new UserDetailModel();
  backupselectedUser: UserDetailModel = new UserDetailModel();
  IsSuperAdmin: boolean = false;
  UsersList: any;
  minToDate!: Date;
  selectedRow: any;
  isSaveClicked : boolean = false;

  constructor(public _loggedUserService: LoggedUserService, private _HttpService: HttpService, private messageService: MessageService) {

  }


  cols: any[] = [

    { field: 'Indicator', header: 'Indicator', width: '60px', isBadge: false, isIndicator: true, isDate: false, isSorting: false, isFilter: false, isExportable: false },
    { field: 'RoleName', header: 'Role Name', width: '180px', isBadge: false, isDate: false,  isIndicator: false,isSorting: true, isFilter: true, isExportable: true },
    { field: 'ActualUserName', header: 'Actual User', width: '180px', isBadge: false, isDate: false,  isIndicator: false,isSorting: true, isFilter: true, isExportable: true },
    { field: 'BackupUserName', header: 'Backup User', width: '250px', isBadge: false, isDate: false,  isIndicator: false,isSorting: true, isFilter: true, isExportable: true },
    { field: 'FromDate', header: 'From Date', width: '150px', isDate: true, isBadge: false, isSorting: true,  isIndicator: false,isFilter: true, isExportable: true },
    { field: 'ToDate', header: 'To Date', width: '150px', isDate: true, isBadge: false, isSorting: true,  isIndicator: false,isFilter: true, isExportable: true },


   { field: 'CreatedByName', header: 'Created By', width: '180px', isBadge: false, isDate: false, isSorting: true, isIndicator: false, isFilter: true, isExportable: true },
    { field: 'CreatedDate', header: 'Created Date', width: '150px', isDate: true, isBadge: false, isSorting: true,  isIndicator: false,isFilter: true, isExportable: true },
    { field: 'ModifiedByName', header: 'Modified By', width: '150px', isBadge: false, isDate: false, isSorting: true, isIndicator: false, isFilter: true, isExportable: true },
    { field: 'ModifiedDate', header: 'Modified Date', width: '150px', isDate: true, isBadge: false, isSorting: true,  isIndicator: false,isFilter: true, isExportable: true },
  ]

  RoleList: RolesModel[] = new Array<RolesModel>();

  AssetList: AssetModel[] = new Array<AssetModel>();

  DirectorateList: DirectorateModel[] = new Array<DirectorateModel>();
  SelectedRole: RolesModel = new RolesModel();
  DelegateRoleList: DelegateRole[] = new Array<DelegateRole>();
  DownloadDelegateRoleList: DelegateRole[] = new Array<DelegateRole>();
  loading: boolean = true;
  Model: DelegateRole = new DelegateRole();
  editMode: boolean = false;
  startDate!: Date | null;
  endDate!: Date | null;
  userSearchSubscribe: any;

  ngOnInit(): void {
    this.GetAllDelegateRole();
    this.GetAllRolesForDelegateRole();
    this.SelectedRole = new RolesModel();
  }

  ngAfterViewInit() : void{



  }

  SelectStartDate() {

      this.minToDate = this.Model.FromDate as Date;

      this.Model.ToDate =  new Date((this.Model.FromDate  as Date).getTime() +  (1 * 24 * 60 * 60 * 1000)); // 1 Day Difference

      // this.Model.ToDate =this.Model.FromDate as Date;

    }


  GetAllDelegateRole() {
this.loading = true;
    this._HttpService.GetAll("Delegation/GetAll").subscribe(res => {

      if (res != null) {
        this.DelegateRoleList = res;
        this.DelegateRoleList.forEach(s => {

          if (s.CreatedDate) s.CreatedDate = new Date(s.CreatedDate);
          if (s.ModifiedDate) s.ModifiedDate = new Date(s.ModifiedDate);
          if (s.FromDate) s.FromDate = new Date(s.FromDate);
          if (s.ToDate) s.ToDate = new Date(s.ToDate);
        });
      }

      this.loading = false;
    });
  }

  CheckIsSuperAdmin(): void {
debugger;
    const result = this._loggedUserService.loggedUser?.UserRoles?.filter((r: { Code: string; })=>r.Code === "SUP");

    result.length > 0 ? this.IsSuperAdmin = true : this.IsSuperAdmin=false;

  }
  showBasicDialog() {
    this.selectedUser = new UserDetailModel();
    this.backupselectedUser = new UserDetailModel();
this.isSaveClicked = false;
    this.CheckIsSuperAdmin();
    if(!this.IsSuperAdmin){
      debugger;

      this.selectedUser.PersonalNumber = this._loggedUserService.loggedUser.PersonalNumber;
      this.selectedUser.EmployeeName = this._loggedUserService.loggedUser.EmployeeName;

    }


    // console.log(this._loggedUserService.loggedUser);
    this.editMode = false;
    this.displayModal = true;
    this.Model = new DelegateRole();
    this.SelectedRole = new RolesModel();
  }
  Save() {
debugger;
this.isSaveClicked = true;
    let errorcount = 0;

    if (this.Model.RId == null || this.Model.RId == 0) {
      errorcount++;
      this.messageService.add({ severity: 'error', detail: 'Select Role' });
    }

    if (this.selectedUser == null || (this.selectedUser.PersonalNumber == null || this.selectedUser.PersonalNumber == "")) {
      errorcount++;
      this.messageService.add({ severity: 'error', detail: 'Select Actual User' });
    }

    if (this.backupselectedUser == null || (this.backupselectedUser.PersonalNumber == null || this.backupselectedUser.PersonalNumber == "")) {
      errorcount++;
      this.messageService.add({ severity: 'error', detail: 'Select Backup User' });
    }
    if (!this.Model.FromDate) {
      errorcount++;
      this.messageService.add({ severity: 'error', detail: 'Select From Date' });
    }
    if (!this.Model.ToDate) {
      errorcount++;
      this.messageService.add({ severity: 'error', detail: 'Select To Date' });
    }

    // else if (this.SelectedRole.IsAsset) {
    //   if (this.Model.DirectorateCode == null || this.Model.DirectorateCode == "") {
    //     errorcount++;
    //     this.messageService.add({ severity: 'error', detail: 'Select Directorate' });

    //   }
    //   if (this.Model.AssetCode == null || this.Model.AssetCode == "") {
    //     errorcount++;
    //     this.messageService.add({ severity: 'error', detail: 'Select Asset' });

    //   }
    // }



    if (errorcount == 0) {

      this.Model.ActualUser = this.selectedUser.PersonalNumber;
      this.Model.BackupUser = this.backupselectedUser.PersonalNumber;

      this._HttpService.Post("Delegation/Save", this.Model).subscribe(res => {
        this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
        if (this.Model.Id == 0) {

          this.Model.Id = res.Id;
        }
        this.displayModal = false;
        // this.FilterData();
        this.GetAllDelegateRole();
      })


    }
  }

  GetAllRolesForDelegateRole() {
    this.loading = true;
    this._HttpService.Get("Master/GetAllRolesForDelegation", []).subscribe(res => { this.RoleList = res; this.loading = false; })
  }







  GetSelectedRole() {
    this.SelectedRole = this.RoleList.filter(x => x.Id === this.Model.RId)[0];
  }

  RoleChanged(filterdata: boolean = true) {
    if (this.Model.RId != null) {
      this.GetSelectedRole();
      // if (filterdata) {
      //   this.FilterData();
      // }
    }
    else {

      this.SelectedRole = new RolesModel();
    }


  }





  FilterData() {

    this._HttpService.Post("Delegation/GetByFilters", this.Model).subscribe(res => {

      if (res != null) {
        this.Model = res;
      }
      else {

        this.Model.Id = 0;
      }

      this.loading = false;
    })

  }


   EditDelegateRole(DelegateRole: DelegateRole) {
    this.editMode = true;

    this.Model = JSON.parse(JSON.stringify(DelegateRole));
debugger;
    this.Model.FromDate = new Date(this.Model.FromDate?.toString()??'');
    this.Model.ToDate = new Date(this.Model.ToDate?.toString()??'');
    this.selectedUser = new UserDetailModel();
    this.selectedUser.PersonalNumber =  this.Model.ActualUser;
    this.selectedUser.EmployeeName = this.Model.ActualUserName;
    this.backupselectedUser = new UserDetailModel();
    this.backupselectedUser.PersonalNumber = this.Model.BackupUser;
    this.backupselectedUser.EmployeeName = this.Model.BackupUserName;

    this.displayModal = true;
  }

  DeleteDelegateRole(DelegateRole: DelegateRole) {


    DelegateRole.IsDeleted = 1;

    this.isSaveClicked = true;
    this._HttpService.Post("Delegation/Save", DelegateRole).subscribe(res => {
      this.messageService.add({ severity: CommonFunctions.MessageStatus(res.StatusCode), detail: res.Detail });
      this.isSaveClicked = false;
      this.GetAllDelegateRole();
    })

  }
  AutoComplateUser(event: any) {
debugger;

    if (this.userSearchSubscribe) {

      this.userSearchSubscribe.unsubscribe();
    }

    this.userSearchSubscribe = this._HttpService.Get("Delegation/SearchUser", [event.query]).subscribe(res => {

      this.UsersList = res;
      this.loading = false;
    });
  }


  exportPdf() {
    this.DownloadDelegateRoleList = JSON.parse(JSON.stringify(this.DelegateRoleList));

    this.DownloadDelegateRoleList.forEach(s => {
      s.Approvers = s.Approvers.replace(/<br>/g, "\n");
    });
    CommonFunctions.ExportPdf(this.cols, this.DownloadDelegateRoleList, 'User Management')
  }
  exportExcel() {

    this.DownloadDelegateRoleList = JSON.parse(JSON.stringify(this.DelegateRoleList));

    this.DownloadDelegateRoleList.forEach(s => {
      s.Approvers = s.Approvers.replace(/<br>/g, "\n");

    });
    CommonFunctions.ExportExcel(this.cols, this.DownloadDelegateRoleList, 'User Management');

  }
  covert(approver: string[]) {

    return approver.join("</br>");
  }

  RemoveUser(index: any) {

    // this.Model.DelegateRoleDetailList[index].IsDeleted = 1;
  }
  CheckIsLoggedUser(row: any) {
    if (row.isAddedFromClent)
      return true;
    else
      return row.PersonalNumber != this._loggedUserService.loggedUser.PersonalNumber;
  }
}
