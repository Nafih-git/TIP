﻿using System.Text.Json.Serialization;

namespace eMOC_PV_Models
{
    public class HelpDocument : Audit
    {
        public decimal Id { get; set; }
        public string FileName { get; set; }
        public string Guid { get; set; }
        public string DisplayName { get; set; }
        public Int16 OrderNo { get; set; }
        public Int16 IsActive { get; set; }
        public string OldGuid { get; set; }
        [JsonIgnore]
        public decimal? StatusCode { get; set; }
        [JsonIgnore]
        public string Summary { get; set; }
        [JsonIgnore]
        public string Detail { get; set; }
    }
}
