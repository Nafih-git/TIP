﻿namespace eMOC_PV_Models
{
    public class ApiLog
    {
        public string Method { get; set; }
        public string Url { get; set; }
        public string RequestBody { get; set; }
        public int StatusCode { get; set; }
        public string ResponseBody { get; set; }
        public string IPAddress { get; set; }
        public string HostName { get; set; }
        public string ClientMachine { get; set; }
        public string CreatedBy { get; set; }
    }
}
