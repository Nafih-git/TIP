﻿
namespace eMOC_PV_Models
{
    public class Status
    {
        public Int16 Id { get; set; }
        public string Name { get; set; }
    }
}
