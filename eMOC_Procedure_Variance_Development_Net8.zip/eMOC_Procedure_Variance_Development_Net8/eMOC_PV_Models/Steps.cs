﻿namespace eMOC_PV_Models
{
    public class Steps
    {
        public int stepId { get; set; }
        public string label { get; set; }
        public string styleClass { get; set; }
        public decimal ActiveIndex { get; set; }
        public decimal ApproverRoleId { get; set; }
        public string ApproverRoleName { get; set; }

        public decimal BackApproverRoleId { get; set; }
        public string BackApproverRoleName { get; set; }
    }
}
