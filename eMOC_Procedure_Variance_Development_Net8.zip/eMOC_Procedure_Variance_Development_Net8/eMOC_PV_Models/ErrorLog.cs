﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class ErrorLog
    {
        public decimal Id { get; set; }
        public string ErrorId { get; set; }
        public string Exception { get; set; }
        public string StackTrace { get; set; }
    }
}
