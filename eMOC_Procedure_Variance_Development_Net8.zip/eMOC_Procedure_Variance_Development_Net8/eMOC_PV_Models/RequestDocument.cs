﻿using System.Text.Json.Serialization;

namespace eMOC_PV_Models
{
    public class RequestDocument : Audit
    {
        public decimal Id { get; set; }
        public decimal RequestId { get; set; }
      
        public string FileName { get; set; }
        public string Guid { get; set; }
        public string Comment { get; set; }
        public string MimeType { get; set; }
        public string Extension { get; set; }
        public decimal OrderNo { get; set; }
        [JsonIgnore]
        public decimal UserRoleId { get; set; }
        public decimal StatusCode { get; set; }
    }
}
