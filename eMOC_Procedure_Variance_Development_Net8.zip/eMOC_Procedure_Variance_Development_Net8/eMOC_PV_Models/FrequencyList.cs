﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class FrequencyList
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Int16 IsActive { get; set; }
    }
   
}
