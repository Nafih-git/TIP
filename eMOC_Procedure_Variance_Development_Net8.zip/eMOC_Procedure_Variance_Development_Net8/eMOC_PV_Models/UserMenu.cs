﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class UserMenu
    {
        public List<Screen> ScreensList { get; set; }
        public List<Module> ModulesList { get; set; }
        public List<Roles> UserRolesList { get; set; }
        public List<Module> NavigationMenu { get; set; }
    }
}
