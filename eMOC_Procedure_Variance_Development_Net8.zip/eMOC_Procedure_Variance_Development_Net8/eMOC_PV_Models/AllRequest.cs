﻿namespace eMOC_PV_Models
{
    public class AllRequest : Audit
    {
        public int SlNo { get; set; }
        public int Id { get; set; }
        public string Directorate { get; set; }
        public string Asset { get; set; }
        public string Facility { get; set; }
        
        public string ReasonVarianceName { get; set; }
      
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public DateTime? ImplementedDate { get; set; }
        public DateTime? ExpiredDate { get; set; }
        public DateTime? OverdueDate { get; set; }
        public DateTime? ClosedDate { get; set; }
        public DateTime? RejectedDate { get; set; }

        public DateTime? TaskAssignedDate { get; set; }
        
        public string WorkflowStatus { get; set; }
        public Int16 WorkflowStatusId { get; set; }
        public string CustomStatus { get; set; }
        public string PendingWith { get; set; }
        public string PendingWithName { get; set; }
        public string Indicator { get; set; }
        public decimal TotalRecords { get; set; }

        public decimal ExtensionCount { get; set; }

        public string ProcedureTitle { get; set; }

        public string ProcedureCode { get; set; }

        private int myVar;

        public int MyProperty
        {
            get { return myVar; }
            set { myVar = value; }
        }


        public string ProcedureDisplayName
        {
            get { 
                if (IsManual == 1) {
                  return  ProcedureTitle;
                }
                else
                {
                    return ProcedureCode + " _ " + ProcedureTitle; ;
                }
            }
    

        }

        public Int16 IsManual { get; set; }


        public Int16 IsCMSIntegration
        {
            get { return (short)(IsManual == 0 ? 1 : 0); }

        }

        public int StepId { get; set; }

        public string StepName { get; set; }

    }
}
