﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Screen : Audit
    {
        public int Id { get; set; }
        public string? Code { get; set; }
        public string? Name { get; set; }
        public string? URL { get; set; }
        public int OrderNo { get; set; }
        public int ModuleId { get; set; }
        public string? ModuleName { get; set; }
        public Int16 IsActive { get; set; }
        public Int16 IsSAOnly { get; set; }
        public Int16 IsCAOnly { get; set; }
        public string? Icon { get; set; }
        public Int16 ShowBadge { get; set; }
        public bool Selected { get; set; }
    }
}
