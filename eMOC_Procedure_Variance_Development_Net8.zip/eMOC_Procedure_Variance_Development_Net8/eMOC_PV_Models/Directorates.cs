﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Directorates
    {
        public string Directorate { get; set; }
    }
}
