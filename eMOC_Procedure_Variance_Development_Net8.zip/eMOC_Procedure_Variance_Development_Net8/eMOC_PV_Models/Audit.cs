﻿using System.Text.Json.Serialization;

namespace eMOC_PV_Models
{
    public class Audit
    {
        [JsonIgnore]
        public decimal SNO { get; set; }
        [JsonIgnore]
        public string? CreatedBy { get; set; }

        public string? CB
        {
            get { return CreatedBy; }
            set { CreatedBy = value; }
        }
        [JsonIgnore]
        public string? CreatedByName { get; set; }
        [JsonIgnore]
        public DateTime? CreatedDate { get; set; }
        [JsonIgnore]
        public string? ModifiedBy { get; set; }
        [JsonIgnore]
        public string? ModifiedByName { get; set; }
        [JsonIgnore]
        public DateTime? ModifiedDate { get; set; }



    }
}
