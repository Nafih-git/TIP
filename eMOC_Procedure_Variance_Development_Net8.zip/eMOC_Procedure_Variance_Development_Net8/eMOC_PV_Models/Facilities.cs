﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Facilities : Assets
    {
        public string Facility { get; set; }
    }
}
