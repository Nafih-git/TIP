﻿using System.Text.Json.Serialization;

namespace eMOC_PV_Models
{
    public class Tasks
    {
        public int Id { get; set; }
        public int RequestId { get; set; }
        public string AssignedTo { get; set; }
        public string? AssignedToName { get; set; }
        [JsonIgnore]
        public string? AssignedToRole { get; set; }
        [JsonIgnore]
        public int? AssignedToRoleId { get; set; }
        public string? AssignedBy { get; set; }
        public string? AssignedByName { get; set; }
        [JsonIgnore]
        public string? AssignedByRole { get; set; }
        public DateTime AssignedDate { get; set; }
        public string? Action { get; set; }
        public string? ActionBy { get; set; }
        public string? ActionByName { get; set; }
        [JsonIgnore]
        public string? ActionByRole { get; set; }
        public DateTime ActionDate { get; set; }
        public Int16 Status { get; set; }
        [JsonIgnore]
        public string StatusName { get; set; }
        [JsonIgnore]
        public string DateDifference { get; set; }
    }
}