﻿namespace eMOC_PV_Models
{
    public class Actions
    {
        public int ConfigId { get; set; }
        public int ActionId { get; set; }
        public string ActionName { get; set; }
        public string ButtonClass { get; set; }
        public string ButtonIcon { get; set; }
    }
}
