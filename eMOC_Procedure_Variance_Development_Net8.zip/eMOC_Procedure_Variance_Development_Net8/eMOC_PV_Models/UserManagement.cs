﻿using System.Text.Json.Serialization;

namespace eMOC_PV_Models
{
    public class UserManagement : Audit
    {
        public decimal Id { get; set; }

        [JsonIgnore]
        public string AssetName { get; set; }

        public string AssetCode { get; set; }
        [JsonIgnore]
        public string AssetNameDesc { get; set; }


        [JsonIgnore]
        public string DirectorateName { get; set; }

        public string DirectorateCode { get; set; }
        [JsonIgnore]
        public string DirectorateNameDesc { get; set; }

        public List<UserManagementDetail>? UserManagementDetailList { get; set; }

        [JsonIgnore]
        public decimal RoleId { get; set; }
        public decimal RId
        {
            get { return RoleId; }
            set { RoleId = value; }
        }

        [JsonIgnore]
        public string RoleName { get; set; }
        [JsonIgnore]
        public string RoleCode { get; set; }

        [JsonIgnore]
        public string Approvers { get; set; }


    }
}
