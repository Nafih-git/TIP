﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace eMOC_PV_Models
{
    public class RequestExtension
    {
        public decimal Id { get; set; }
        public DateTime? EffectiveFromDate { get; set; }
        public DateTime? EffectiveToDate { get; set; }

        public string TechnicalApprover { get; set; }
        [JsonIgnore]
        public string TechnicalApproverName { get; set; }
        [JsonIgnore]
        public string TechnicalApproverRoleName { get; set; }

        [JsonIgnore]

        public int? TechnicalApproverRoleId { get; set; }

        public string ProcedureDisplayName { get; set; }

        [JsonIgnore]
        public string EndorserRoleName { get; set; }

        public string EndorserName { get; set; }

        public string Endorser { get; set; }

        [JsonIgnore]

        public int? EndorserRoleId { get; set; }


        [JsonIgnore]
        public string AuthorizerRoleName { get; set; }

        public string AuthorizerName { get; set; }

        public string Authorizer { get; set; }

        public string ImplementerName { get; set; }

        public string Implementer { get; set; }

        [JsonIgnore]

        public int? AuthorizerRoleId { get; set; }
        public int? WorkflowStatusId { get; set; }
        public string WorkflowStatusName { get; set; }
        public Int16 ExtensionVersion { get; set; }
        public Int16 Status { get; set; }
        public string StatusName { get; set; }

        public DateTime? StatusDate { get; set; }

        public int WorkFlowStepId { get; set; }
        public int WorkflowActionId { get; set; }

        public int WorkflowTypeID { get; set; }
        public string CustomStatus { get; set; }


        public string RAApprover { get; set; }
        [JsonIgnore]
        public string RAApproverName { get; set; }
        [JsonIgnore]
        public string RAApproverRoleName { get; set; }

        [JsonIgnore]

        public int? RAApproverRoleId { get; set; }



        public string FunctionalReviewer { get; set; }
        [JsonIgnore]
        public string FunctionalReviewerName { get; set; }
        [JsonIgnore]
        public string FunctionalReviewerRoleName { get; set; }

        [JsonIgnore]

        public int? FunctionalReviewerRoleId { get; set; }
    }
}
