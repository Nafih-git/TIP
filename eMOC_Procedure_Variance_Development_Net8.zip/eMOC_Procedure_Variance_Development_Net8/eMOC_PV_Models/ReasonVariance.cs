﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class ReasonVariance : Audit
    {
        public Int32 Id { get; set; }
        public string Name { get; set; }
        public Int16 IsActive { get; set; }
        public Int16 OrderNo { get; set; }
    }
}
