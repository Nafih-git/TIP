﻿namespace eMOC_PV_Models
{
    public class RiskAssessment : Audit
    {
        public int Id { get; set; }
        public int RequestId { get; set; }
        public string? MaxInitialRiskCode { get; set; }
        public string? MaxInitialRiskModule { get; set; }
        public string? MaxInitialRisk { get; set; }
        public string? MaxResidualRiskCode { get; set; }
        public string? MaxResidualRiskModule { get; set; }
        public string? MaxResidualRisk { get; set; }
        public string? CumulativeRAName { get; set; }
        public string? RAMatrix { get; set; }
        public string? CumulativeRAMatrix { get; set; }
    }
}
