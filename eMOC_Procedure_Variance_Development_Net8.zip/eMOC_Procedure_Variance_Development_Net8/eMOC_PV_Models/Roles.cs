﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Roles : Audit
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Code { get; set; }
        public Int16 IsAsset { get; set; }
        public Int16 IsDirectorate { get; set; }
        public Int16 IsSBA { get; set; }
        public Int16 IsSPA { get; set; }
        public int OrderNo { get; set; }
        public Int16 IsActive { get; set; }
        

        [JsonIgnore]
        public Int16 IsDelegatedRole { get; set; }

       
        public int Days { get; set; }
        public Int16 ISDR
        {
            get { return IsDelegatedRole; }
            set { IsDelegatedRole = value; }
        }
    }
}
