﻿namespace eMOC_PV_Models
{
    public class UserManagementDetail : UserDetail
    {
        public decimal Id { get; set; }
        public string? MUNumber { get; set; }
        public int? UserManagementId { get; set; }

        public Int16? IsActive { get; set; } = 1;

        public Int16? IsDeleted { get; set; } = 0;
    }
}
