﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class RAControlOwnerRole : Audit
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Int16 IsActive { get; set; }
    }
}
