﻿namespace eMOC_PV_Models
{
    public enum DocTypeEnum
    {
        RequestDocument = 1,
        HelpDocument
    }
}
