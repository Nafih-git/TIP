﻿using System.Text.Json.Serialization;

namespace eMOC_PV_Models
{
    public class Delegation : Audit
    {
        public int Id { get; set; }





        [JsonIgnore]
        public string? RoleName { get; set; }

        [JsonIgnore]
        public int RoleId { get; set; }
        public int RId
        {
            get { return RoleId; }
            set { RoleId = value; }
        }

        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }

        public string? ActualUser { get; set; }

        [JsonIgnore]
        public string? ActualUserName { get; set; }
        public string? BackupUser { get; set; }

        [JsonIgnore]
        public string? BackupUserName { get; set; }
        [JsonIgnore]
        public string? Approvers { get; set; }

        public Int16 IsDeleted { get; set; }

        [JsonIgnore]
        public decimal IsEditable { get; set; }

        [JsonIgnore]
        public string Indicator { get; set; }


    }
}
