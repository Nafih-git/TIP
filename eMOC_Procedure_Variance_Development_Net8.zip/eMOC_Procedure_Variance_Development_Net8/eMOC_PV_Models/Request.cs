﻿using System.Security;
using System.Text.Json.Serialization;

namespace eMOC_PV_Models
{
    public class Request : Audit
    {
        public int Id { get; set; }
        public string NextApprover { get; set; }

 


        [JsonIgnore]
        public int NextApproverRoleId { get; set; } = 0;
        public int NextARID
        {
            get { return NextApproverRoleId; }
            set { NextApproverRoleId = value; }
        }


        public string RAApprover { get; set; }
        [JsonIgnore]
        public string RAApproverName { get; set; }
        [JsonIgnore]
        public string RAApproverRoleName { get; set; }
        [JsonIgnore]
        public DateTime? DraftDeletedDate { get; set; }

        public string Endorser  { get; set; }
        [JsonIgnore]
        public string EndorserName { get; set; }
        [JsonIgnore]
        public string EndorserRoleName { get; set; }


        public string Authorizer { get; set; }
        [JsonIgnore]
        public string AuthorizerName { get; set; }
        [JsonIgnore]
        public string AuthorizerRoleName { get; set; }

        public decimal CurrentStepId { get; set; }
        public int WorkflowActionId { get; set; }
        public int WorkflowStatusId { get; set; }
        public string WorkflowStatus { get; set; }
        public string CustomStatus { get; set; }
        public General General { get; set; }
        public List<RequestDocument> Documents { get; set; }
        public List<RATeamMember> RATeamMembers { get; set; }
        public RiskAssessment RiskAssessment { get; set; }
        public List<UserDetail> BackupApprovers { get; set; }
        public List<ApproverHistory> ApproverHistory { get; set; }
        public List<RequestExtension> RequestExtensionList { get; set; }
        public RequestExtension RequestExtension{ get; set; }
        public int OffsetRequestId { get; set; }
        public string NotifyTo { get; set; }
        public string Comment { get; set; }
        public Tasks ActiveTask { get; set; }
        public List<Steps> Stepper { get; set; }
        public bool IseMOCHistory { get; set; }
    }
    public class General
    {
        public string ProcedureTitle { get; set; }

        public string ProcedureCode { get; set; }
        public string ProcedureLink { get; set; }
        public string Directorate { get; set; }
        public string Asset { get; set; }
        public string Facility { get; set; }
   
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }

        public DateTime? ExtensionFromDate { get; set; }
        public DateTime? ExtensionToDate { get; set; }

        public string Section { get; set; }

        public int? ReasonVarianceId { get; set; }

        public string ReasonVarianceName { get; set; }

        public int WorkFlowId { get; set; } = 1; //Default 1 .. now there is only one workflow exist 
        public string Justification { get; set; }

        public string  DeviatedAgainst { get; set; }
        public DateTime? ImplementedDate { get; set; }

        public string FunctionalReviewer { get; set; }
        //public string NotifyUser { get; set; }
        [JsonIgnore]
        public string FunctionalReviewerName { get; set; }
        [JsonIgnore]
        public string FunctionalReviewerRoleName { get; set; }

        [JsonIgnore]

        public int? FunctionalReviewerRoleId { get; set; }
        public string TechnicalApprover { get; set; }
        [JsonIgnore]
        public string TechnicalApproverName { get; set; }
        [JsonIgnore]
        public string TechnicalApproverRoleName { get; set; }

        [JsonIgnore]

        public int? TechnicalApproverRoleId { get; set; }

        public string ProcedureDisplayName { get; set; }

        [JsonIgnore]
        public string EndorserRoleName { get; set; }

        public string EndorserName { get; set; }

        public string Endorser { get; set; }

        [JsonIgnore]
        public int? EndorserRoleId { get; set; }


        [JsonIgnore]
        public string AuthorizerRoleName { get; set; }

        public string AuthorizerName { get; set; }

        public string Authorizer { get; set; }
        [JsonIgnore]
        public int? AuthorizerRoleId { get; set; }

        public string RAApprover { get; set; }
        [JsonIgnore]
        public string RAApproverName { get; set; }
        [JsonIgnore]
        public string RAApproverRoleName { get; set; }

        public int ActiveTaskId { get; set; }

        public Int16? IsManual { get; set; }

        public string LessonLearned { get; set; }



    }

    public class ApproverHistory
    {
        public int Id { get; set; }
        public int RequestId { get; set; }
        [JsonIgnore]
        public string? RoleName { get; set; }
        public string? Decision { get; set; }
        public string? Comments { get; set; }
        public string? ActionBy { get; set; }
        [JsonIgnore]
        public string? ActionByName { get; set; }
        public DateTime ActionDate { get; set; }


      
    }
}
