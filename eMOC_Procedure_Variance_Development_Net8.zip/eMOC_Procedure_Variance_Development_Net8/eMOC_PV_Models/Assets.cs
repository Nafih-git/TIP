﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Assets : Directorates
    {
        public string Asset { get; set; }
    }
}
