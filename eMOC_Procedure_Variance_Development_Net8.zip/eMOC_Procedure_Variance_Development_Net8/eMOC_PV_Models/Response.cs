﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class Response
    {
        public decimal StatusCode { get; set; }
        public string Severity { get { return Enum.GetName(typeof(Severity), (Int32)StatusCode); } }
        public string Summary { get; set; }
        public string Detail { get; set; }
        public decimal Id { get; set; }
    }
    public enum Severity
    {
        success = 0,
        error,
        warn,
        info,
    }
}
