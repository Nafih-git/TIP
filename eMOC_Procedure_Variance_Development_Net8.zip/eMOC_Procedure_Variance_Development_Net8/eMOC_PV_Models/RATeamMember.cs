﻿
namespace eMOC_PV_Models
{
    public class RATeamMember : Audit
    {
        public int Id { get; set; }
        public int RequestId { get; set; }
        public string MuNumber { get; set; }
        public string Name { get; set; }
        public string JobDescription { get; set; }
        public Int16 IsActive { get; set; }
        public Int16 OrderNo { get; set; }

        public string Competency { get; set; }
    }
}
