﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace eMOC_PV_Models
{
    public class RAApprovers
    {
        [JsonIgnore]
        public decimal ApproverRoId { get; set; }
        [JsonIgnore]
        public string ApproverRoName { get; set; }
        public List<UserDetail> RAApproverUsers { get; set; }

    }

    [DataContract]
    public class RAApproverFilter
    {
        [DataMember]
        public string DirectorateCode { get; set; }
        [DataMember]
        public string AssetCode { get; set; }
        [DataMember]
        public string RRName { get; set; }
        [DataMember]
        public string CRName { get; set; }
    }
    
}
