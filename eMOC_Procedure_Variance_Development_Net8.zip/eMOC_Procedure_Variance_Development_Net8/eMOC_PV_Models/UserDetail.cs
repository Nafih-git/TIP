﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class UserDetail : Audit
    {
        public string? PersonalNumber { get; set; }
        public string? EmployeeName { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public string? ReferenceIndicator { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public string? JobDescription { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public string? EmailAddress { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public List<Roles>? UserRoles { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public string? SupervisorId { get; set; }
        public decimal TaskCount { get; set; }
    }
}
