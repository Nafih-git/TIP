﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class CMSProcedure : Audit
    {
        [System.Text.Json.Serialization.JsonIgnore]
        public string ProcedureTitle { get; set; }
        public string ProcedureCode { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public string DisplayName { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public string FunctionalReviewer { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public string TechnicalApprover { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public string FunctionalReviewerFullName { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public string TechnicalApproverFullName { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public string Link { get; set; }

    }
}
