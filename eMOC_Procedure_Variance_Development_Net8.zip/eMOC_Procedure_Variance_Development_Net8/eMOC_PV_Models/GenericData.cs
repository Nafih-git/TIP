﻿using Newtonsoft.Json;

namespace eMOC_PV_Models
{
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    public class GenericData
    {
        public string Label { get; set; }
        public string Value { get; set; }
        public decimal Code { get; set; }
    }
}
