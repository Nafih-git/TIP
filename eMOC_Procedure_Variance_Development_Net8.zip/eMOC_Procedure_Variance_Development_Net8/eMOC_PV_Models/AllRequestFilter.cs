﻿using System.Runtime.Serialization;

namespace eMOC_PV_Models
{
    [DataContract]
    public class AllRequestFilter
    {
        [DataMember]
        public int First { get; set; }
        [DataMember]
        public int Rows { get; set; }
        [DataMember]
        public string SortField { get; set; }
        [DataMember]
        public string SortOrder { get; set; }
        [DataMember]
        public string RequestFilter { get; set; }
        [DataMember]
        public int FullRecords { get; set; }
        [DataMember]
        public string CreatedBy { get; set; }

        [DataMember]
        public string Type { get; set; }
        [DataMember]
        public string ChartType { get; set; }
        [DataMember]
        public string ReportType { get; set; }

        [DataMember]
        public int IsMyTask { get; set; }

    }
}
