﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eMOC_PV_Models
{
    public class EmailTemplate : Audit
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public Int16 IsActive { get; set; }
        public string WorkflowActionName { get; set; }

        public string EmailNotificationFor { get; set; }

        public Int16 NotificationType { get; set; }
    }
}
