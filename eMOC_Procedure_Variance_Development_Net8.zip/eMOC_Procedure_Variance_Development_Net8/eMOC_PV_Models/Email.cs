﻿namespace eMOC_PV_Models
{
    public class Email
    {
        public int Id { get; set; }
        public int RequestId { get; set; }
        public string Subject { get; set; }
        public string MailBody { get; set; }
        public Int16 SentStatus { get; set; }
        public string RecipientMailId { get; set; }
        public string RecipientName { get; set; }
        public string OriginatorRole { get; set; }
        public string ApproverRole { get; set; }
        public string ApplicationName { get; set; }
        public string ApplicationURL { get; set; }

        public string URL { get; set; }


        public DateTime REQFromDate { get; set; }

        public DateTime REQToDate { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }
        public string ActualUser { get; set; }
        public string BackupUser { get; set; }
        public string RoleName { get; set; }
    }
}
