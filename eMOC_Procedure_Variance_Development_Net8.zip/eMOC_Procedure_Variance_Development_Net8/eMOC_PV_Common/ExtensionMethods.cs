﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace eMOC_PV_Common
{
    public static class ExtensionMethods
    {
        public static bool IsValidFileType(this string FileName, string AllowedFileTypes)
        {
            if (!String.IsNullOrEmpty(FileName))
            {
                string extension = Path.GetExtension(FileName);
                bool result = AllowedFileTypes.Contains(extension.ToLower());
                return result;
            }
            return false;
        }
        public static bool ContainsInvalidChar(this string Path)
        {
            List<string> invalidCharactes = new() { "..", ":", "./", @"..\\", @"..\" };
            return invalidCharactes.Any(x => Path.Contains(x));
        }

        public static bool IsValidPath(this string Name, int category = 0) // 0 = File , 1 = Path
        {
            List<char> invlaidCharList = new();
            if (category == 1) // Get Path Invalid Characters
                invlaidCharList = System.IO.Path.GetInvalidPathChars().ToList();
            if (category == 0) // Get FileName Invalid Characters
                invlaidCharList = System.IO.Path.GetInvalidFileNameChars().ToList();

            // Add Custom Invalid Characters
            invlaidCharList.AddRange(new List<Char>() { '<', '>', ':', '"', '/', '|', '?', '*' });

            if (Name.IndexOfAny(invlaidCharList.ToArray()) >= 0)
                return false;
            else
                return true;
        }

        public static string GetDisplayName(this Enum enumValue)
        {
            return enumValue.GetType()
                            .GetMember(enumValue.ToString())
                            .First()
                            .GetCustomAttribute<DisplayAttribute>()
                            .GetName();
        }

        public static bool PathStartsWithCheck(this string path)
        {
            if (path.StartsWith(@"\\musnas06\web_applications\UOP_EMOC\TOC", StringComparison.Ordinal))
            {
                return true;
            }
            else if (path.StartsWith(@"\\musnas06\web_applications\UOP_EMOC\TOC\", StringComparison.Ordinal))
            {
                return true;
            }
            else if (path.StartsWith(@"\\musnas06\web_applications\UOP_EMOC\", StringComparison.Ordinal))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public class JsonIgnoreProperties : DefaultContractResolver
    {
        private readonly HashSet<string> ignoreProps;
        public JsonIgnoreProperties(IEnumerable<string> propNamesToIgnore)
        {
            this.ignoreProps = new HashSet<string>(propNamesToIgnore);
        }
        protected override JsonProperty CreateProperty(MemberInfo member, MemberSerialization memberSerialization)
        {
            JsonProperty property = base.CreateProperty(member, memberSerialization);
            if (this.ignoreProps.Contains(property.PropertyName))
            {
                property.ShouldSerialize = _ => false;
            }
            return property;
        }
    }
}
