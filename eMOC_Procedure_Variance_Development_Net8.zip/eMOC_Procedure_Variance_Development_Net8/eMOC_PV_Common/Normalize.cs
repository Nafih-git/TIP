﻿using System.Text;

namespace eMOC_PV_Common
{
    public static class Normalize
    {
        /**
        * Remove invalid characters in the string
        *
        * @param  input The string with variables entered by users
        * @return       The clean string
        */
        public static String parse(String input)
        {
            StringBuilder output = new StringBuilder();
            if (input != null)
            {
                for (int i = 0; i < input.Length; ++i) 
                    output.Append(Normalize.parse(input[i]));
            }
            return output.ToString();
        }

        /**
        * Replace the character with a valid character
        *
        * @param  input The character for checking
        * @return       The clean character
        */
        public static char parse(char input)
        {
            int digit = (int)input;
            char output = '\0';
            // From 0 to 9 and :
            for (int i = 48; i <= 58; ++i)
            {
                if (digit == i)
                    output = (char)i;
            }
            // @ and From A to Z
            for (int i = 64; i <= 90; ++i)
            {
                if (digit == i) 
                    output = (char)i;
            }
            // From a to z
            for (int i = 97; i <= 122; ++i)
            {
                if (digit == i)
                    output = (char)i;
            }
            // - . /
            for (int i = 45; i <= 47; ++i)
            {
                if (digit == i)
                    output = (char)i;
            }
            // \
            if (digit == 92)
                output = (char)92;
            // _
            if (digit == 95)
                output = (char)95;
            // ! 33
            for (int i = 32; i <= 33; ++i)
            {
                if (digit == i)
                    output = (char)i;
            }
            //# 35 $ 36 % 37
            for (int i = 35; i <= 37; ++i)
            {
                if (digit == i)
                    output = (char)i;
            }
            // ( = 40,  ) = 41
            if (digit == 40 || digit == 41)
                output = (char)95;
            return output;
        }
    }
}
