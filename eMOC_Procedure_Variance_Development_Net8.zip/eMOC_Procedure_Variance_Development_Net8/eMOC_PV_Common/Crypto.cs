﻿using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;

namespace eMOC_PV_Common
{
    public static class Crypto
    {
        private const string Key = "by9NZe3#0i5w0s$Qufcf4kAI";
        public static string Encrypt(this string plainText)
        {
            if (!String.IsNullOrEmpty(plainText))
            {
                // Get bytes of plaintext string
                byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
                byte[] _key = Encoding.UTF8.GetBytes(Key);

                // Get parameter sizes
                int nonceSize = AesGcm.NonceByteSizes.MaxSize;
                int tagSize = AesGcm.TagByteSizes.MaxSize;
                int cipherSize = plainBytes.Length;

                // We write everything into one big array for easier encoding
                int encryptedDataLength = 4 + nonceSize + 4 + tagSize + cipherSize;
                Span<byte> encryptedData = encryptedDataLength < 1024 ? stackalloc byte[encryptedDataLength] : new byte[encryptedDataLength].AsSpan();

                // Copy parameters
                BinaryPrimitives.WriteInt32LittleEndian(encryptedData.Slice(0, 4), nonceSize);
                BinaryPrimitives.WriteInt32LittleEndian(encryptedData.Slice(4 + nonceSize, 4), tagSize);
                var nonce = encryptedData.Slice(4, nonceSize);
                var tag = encryptedData.Slice(4 + nonceSize + 4, tagSize);
                var cipherBytes = encryptedData.Slice(4 + nonceSize + 4 + tagSize, cipherSize);

                // Generate secure nonce
                RandomNumberGenerator.Fill(nonce);

                // Encrypt
                using var aes = new AesGcm(_key);
                aes.Encrypt(nonce, plainBytes.AsSpan(), cipherBytes, tag);

                // Encode for transmission
                return Convert.ToBase64String(encryptedData);
            }
            return String.Empty;
         
        }
        public static string Decrypt(this string cipher)
        {
            // Decode
            Span<byte> encryptedData = Convert.FromBase64String(cipher).AsSpan();
            byte[] _key = Encoding.UTF8.GetBytes(Key);

            // Extract parameter sizes
            int nonceSize = BinaryPrimitives.ReadInt32LittleEndian(encryptedData.Slice(0, 4));
            int tagSize = BinaryPrimitives.ReadInt32LittleEndian(encryptedData.Slice(4 + nonceSize, 4));
            int cipherSize = encryptedData.Length - 4 - nonceSize - 4 - tagSize;

            // Extract parameters
            var nonce = encryptedData.Slice(4, nonceSize);
            var tag = encryptedData.Slice(4 + nonceSize + 4, tagSize);
            var cipherBytes = encryptedData.Slice(4 + nonceSize + 4 + tagSize, cipherSize);

            // Decrypt
            Span<byte> plainBytes = cipherSize < 1024
                                  ? stackalloc byte[cipherSize]
                                  : new byte[cipherSize];
            using var aes = new AesGcm(_key);
            aes.Decrypt(nonce, cipherBytes, tag, plainBytes);

            // Convert plain bytes back into string
            return Encoding.UTF8.GetString(plainBytes);
        }
    }
}
