﻿using Microsoft.AspNetCore.Http;

namespace eMOC_PV_Common
{
    public class Global
    {
        private static IHttpContextAccessor? httpContextAccessor;
        public static void SetHttpContextAccessor(IHttpContextAccessor _httpContextAccessor)
        {
            httpContextAccessor = _httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
        }

        public static class User
        {
            public static string? CorpName => httpContextAccessor?.HttpContext == null ? "Corp\\System" : httpContextAccessor?.HttpContext?.User?.Identity?.Name;
            public static string? MuNumber => CorpName[(CorpName.LastIndexOf(@"\") + 1)..].ToUpper();
        }
    }
}
