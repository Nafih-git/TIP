﻿using Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Configuration;

namespace eMOC_PV_Common
{
    public class EmailService
    {
        private readonly IConfiguration config;
        private const ExchangeVersion exchangeVersion = ExchangeVersion.Exchange2013_SP1;

        /// <summary>
        /// Email Addresses. Multiple email addresses should be delimited by ;
        /// </summary>
        public string ToAddresses { get; set; }
        /// <summary>
        /// Email Addresses. Multiple email addresses should be delimited by ;
        /// </summary>
        public string CcAddresses { get; set; }
        /// <summary>
        /// Email Addresses. Multiple email addresses should be delimited by ;
        /// </summary>
        public string BccAddresses { get; set; }
        public string AttachmentFileName { get; set; }
        public List<string> To { get; set; }
        public List<string> Cc { get; set; }
        public List<string> Bcc { get; set; }
        public List<string> AttachmentFiles { get; set; }
        public string Subject { get; set; }
        public BodyType MessageBodyType { get; set; } = BodyType.Text;
        public string Message { get; set; }

        public EmailService(IConfiguration _config)
        {
            config = _config;
        }

        public void SendEmail()
        {
            try
            {
                ExchangeService exchange = new(exchangeVersion);
                string SenderAddress = config["AppSettings:EmailSettings:SenderAccount"];
                exchange.Credentials = new WebCredentials(SenderAddress, config["AppSettings:EmailSettings:SenderAccountPd"].Decrypt());
                exchange.Url = new Uri(config["AppSettings:EmailSettings:ExchangeUrl"]);

                EmailMessage message = new(exchange);
                To = !string.IsNullOrEmpty(ToAddresses) ? ToAddresses.Split(';').ToList() : To;
                Cc = !string.IsNullOrEmpty(CcAddresses) ? CcAddresses.Split(';').ToList() : Cc;
                Bcc = !string.IsNullOrEmpty(BccAddresses) ? BccAddresses.Split(';').ToList() : Bcc;
                AttachmentFiles = !string.IsNullOrEmpty(AttachmentFileName) ? AttachmentFileName.Split(';').ToList() : AttachmentFiles;
                if (AttachmentFiles != null)
                {
                    foreach (string file in AttachmentFiles)
                    {
                        message.Attachments.AddFileAttachment(file);
                    }
                }
                if (To.Count > 0)
                    message.ToRecipients.AddRange(To);
                else
                    throw new NullReferenceException("To Email Address not specified");

                if (Cc != null) message.CcRecipients.AddRange(Cc);
                if (Bcc != null) message.BccRecipients.AddRange(Bcc);

                message.Subject = Subject;
                message.Body = new MessageBody(MessageBodyType, Message);
                message.Send();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public void SendEmail(string to, string subject, string message, string attachment = "", BodyType bodyType = BodyType.HTML)
        {
            ToAddresses = to;
            Subject = subject;
            MessageBodyType = bodyType;
            Message = message;
            AttachmentFileName = attachment;
            SendEmail();
        }
    }
}
