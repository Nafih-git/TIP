﻿using eMOC_PV_Models;
using Microsoft.AspNetCore.Http;

namespace eMOC_PV_BusinessLogic.Interface
{
    public interface ICommonService
    {
        #region User Detail
        UserDetail GetUserDetail();
        #endregion

        #region Is Authorized
        bool IsAuthorized(string ScreenCode);
        #endregion

        #region Log Error
        void SaveErrorLog(ErrorLog model);
        #endregion

        #region API Log
        void SaveApiLog(ApiLog model);
        #endregion

        #region Search User (Autocomplete)
        List<UserDetail> SearchUser(string Keyword);
        #endregion

        #region User Menu
        UserMenu GetUserMenu();
        #endregion

        #region Config Values
        string GetConfigValue(string Config);
        #endregion

        #region Help Document
        HelpDocument SaveHelpDocumemt(HelpDocument model, IFormFile file);
        List<HelpDocument> GetHelpDocument(decimal Id = 0, int IsActive = 2);
        #endregion

        #region Download File
        dynamic DownloadFile(DocTypeEnum docType, string FileName); 
        #endregion

        #region Contact Us Information
        public dynamic GetContactUs();
        #endregion

        #region Search CMS Procedure (Autocomplete)
        List<CMSProcedure> SearchCMSProcedure(string Keyword);
        #endregion



        #region Get UserList By RefrenceIndicator
        List<UserDetail> GetUserListByRefrenceIndicator(string Keyword);
        #endregion



    }

}
