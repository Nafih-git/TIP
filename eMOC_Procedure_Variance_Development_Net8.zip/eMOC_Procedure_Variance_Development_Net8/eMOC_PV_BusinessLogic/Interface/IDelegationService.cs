﻿
using eMOC_PV_Models;

namespace eMOC_PV_BusinessLogic.Interface
{
    public interface IDelegationService
    {
        Delegation GetByFilters(Delegation model);

        List<Delegation> GetAll();
        Delegation GetById(int DelegationId);

        Response Save(Delegation model);

        List<UserDetail> SearchUser(string keyword);

    }
}
