﻿using eMOC_PV_Models;
using Microsoft.AspNetCore.Http;

namespace eMOC_PV_BusinessLogic.Interface
{
    public interface IRequestService
    {
        #region Workflow Progress Bar (Steps)
        List<Steps> GetWorkflowSteps(int RequestId = 0, int WorkFlowypeId = 1);
        #endregion

        #region Workflow Actions
        List<Actions> GetWorkflowActions(int RequestId = 0, int WorkFlowypeId = 1);
        #endregion

        #region Request Document
        List<RequestDocument> GetRequestDocument(int Id = 0, int RequestId = 0);
        RequestDocument SaveRequestDocument(RequestDocument model, IFormFile file);
        #endregion

        #region Request
        Task<Response> SaveRequestAsync(Request model);
        Request GetRequest(int RequestId);
        Request GetRequestHistory(decimal Id);
        List<ApproverHistory> GetApproverHistory(int RequestId);
        List<AllRequest> GetAllRequests(string FilterString);

        List<AllRequest> GetPendingWithRequests(string FilterString);
        List<Tasks> GetTaskHistory(decimal Id);

        List<Tasks> GetTaskHistoryByRequestId(decimal Id);
        List<RequestExtension> GetExtensionHistory(decimal Id);
        Task SendEmailNotification(decimal RequestId = 0);

      
        #endregion

        #region Expired & Overdue Requests
        Task ProcessExpiredOverdueRequests();
        #endregion

        #region Copy Risk Assessment
        List<GenericData> GetRequestId(decimal Id);
        RiskAssessment GetRiskAssessment(decimal RequestId);
        #endregion

   

        #region Dashboard Charts
        dynamic GetDashboardCharts(string FilterString);
        dynamic GetControlCenterStatus();
        dynamic GetTotalExpiredKPI(string FilterString);
        dynamic GetPieChartParams();
        dynamic GetQuarterBasedOnyear(string year);
        dynamic GetPieChartDetailsByStatus(string FilterString);
        #endregion

        #region Approvers
        RAApprovers GetRAApprovers(string DirectorateCode , string AssetCode, string RRName, string CRName);
        #endregion

        #region Draft Requests For Deletion
         Task GetDraftRequestsForDeleting();

        #endregion
    }
}
