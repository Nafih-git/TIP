﻿using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_BusinessLogic.Service;
using eMOC_PV_DataAccess;
using Microsoft.Extensions.DependencyInjection;

namespace eMOC_PV_BusinessLogic
{
    public static class DependencyInjection
    {
        public static void RegisterDependencies(IServiceCollection service)
        {
            AddRepositoryDI(service);
            AddServiceDI(service);
        }

        private static void AddServiceDI(IServiceCollection service)
        {
            service.AddTransient<ICommonService, CommonService>();
            service.AddTransient<IMasterService, MasterService>();
            service.AddTransient<IUserManagementService, UserManagementService>();
            service.AddTransient<IRequestService, RequestService>();
            service.AddTransient<IDelegationService, DelegationService>();

        }
        private static void AddRepositoryDI(IServiceCollection service)
        {
            RepositoryDependency.AddRepositoryDI(service);
        }
    }
}
