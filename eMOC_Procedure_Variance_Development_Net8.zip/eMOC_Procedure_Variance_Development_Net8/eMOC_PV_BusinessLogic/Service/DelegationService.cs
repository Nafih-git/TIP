﻿
using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_DataAccess.Interface;
using eMOC_PV_Models;

namespace eMOC_PV_BusinessLogic.Service
{
    public class DelegationService : IDelegationService
    {

        private readonly IDelegationRepository DelegationRepository;


        public DelegationService(IDelegationRepository DelegationRepository)
        {

            this.DelegationRepository = DelegationRepository;

        }

        public List<Delegation> GetAll()
        {
            return DelegationRepository.GetAll();
        }

        public Delegation? GetById(int DelegationId)
        {
            return DelegationRepository.GetById(DelegationId);
        }
        public Delegation GetByFilters(Delegation model)
        {
            return DelegationRepository.GetByFilters(model);
        }

        public Response Save(Delegation model)
        {
            return DelegationRepository.Save(model);
        }

        public List<UserDetail> SearchUser(string keyword)
        {
            return DelegationRepository.SearchUser(keyword);
        }




    }
}
