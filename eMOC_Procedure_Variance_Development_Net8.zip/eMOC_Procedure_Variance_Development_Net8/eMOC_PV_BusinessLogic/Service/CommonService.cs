﻿using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_Common;
using eMOC_PV_DataAccess.Interface;
using eMOC_PV_Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Net;

namespace eMOC_PV_BusinessLogic.Service
{
    public class CommonService : ICommonService
    {
        private readonly ICommonRepository commonRepository;
        private readonly IConfiguration config;

        #region Constructor
        public CommonService(ICommonRepository _commonRepository, IConfiguration _config)
        {
            commonRepository = _commonRepository;
            config = _config;
        }
        #endregion

        #region User Detail
        public UserDetail GetUserDetail()
        {
            return commonRepository.GetUserDetail();
        }
        #endregion

        #region Is Authorized
        public bool IsAuthorized(string ScreenCode)
        {
            return commonRepository.IsAuthorized(ScreenCode);
        }
        #endregion       

        #region Log Error
        public void SaveErrorLog(ErrorLog model)
        {
            commonRepository.SaveErrorLog(model);
        }
        #endregion

        #region API Log
        public void SaveApiLog(ApiLog model)
        {
            commonRepository.SaveApiLog(model);
        }
        #endregion

        #region Search User (Autocomplete)
        public List<UserDetail> SearchUser(string Keyword)
        {
            return commonRepository.SearchUser(Keyword);
        }
        #endregion

        #region User Menu
        public UserMenu GetUserMenu()
        {
            try
            {
                bool isSuperAdmin = false;
                bool IsSubAdmin = false;
                UserMenu navigation = new();
                List<UserMenu> response = new();
                UserMenu model = commonRepository.GetUserMenu();
                if (model != null)
                {
                    isSuperAdmin = model.UserRolesList.Count > 0 && Conversions.ToBool(model?.UserRolesList?.Any(c => c.IsSPA == 1)); //means Super Admin
                    IsSubAdmin = model.UserRolesList.Count > 0 && Conversions.ToBool(model?.UserRolesList?.Any(c => c.IsSBA == 1)); // means Admin per Asset

                    navigation.NavigationMenu = new List<Module>();
                    foreach (var item in model.ModulesList)
                    {
                        Module module = new();
                        module = item;
                        List<Screen> screens;
                        navigation.ModulesList = new List<Module>();
                        screens = model.ScreensList.Where(s => s.ModuleId == item.Id).ToList();
                        if (screens.Count > 0)
                        {
                            if (!isSuperAdmin)
                                screens.RemoveAll(s => s.IsCAOnly == 1 && s.IsSAOnly == 0); // for super admin
                            if (!IsSubAdmin && !isSuperAdmin)
                                screens.RemoveAll(s => s.IsSAOnly == 1 ||  s.IsCAOnly == 1);
                        }
                        module.ScreensList = screens;
                        if (module.ScreensList?.Count > 0)
                            navigation.NavigationMenu.Add(module);
                    }
                }
                return navigation;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region Config Values
        public string GetConfigValue(string Config)
        {
            return config[Config].ToString();
        }
        #endregion

        #region Help Document
        public HelpDocument SaveHelpDocumemt(HelpDocument model, IFormFile file)
        {
            try
            {
                HelpDocument SavedDoc = new();
                if (model != null)
                {
                    SavedDoc = commonRepository.SaveHelpDocumemt(model);
                    if (file != null && SavedDoc.StatusCode == 0 && !string.IsNullOrEmpty(SavedDoc.Guid))
                    {
                        string AllowedFileTypes = config["AppSettings:AllowedHelpDocumentsExtensions"].ToString();
                        if (SavedDoc.Guid.IsValidFileType(AllowedFileTypes))
                        {
                            string path = Path.Combine(config["AppSettings:eMOCNASFolder"], config["AppSettings:HelpDocumentsFolderName"]);
                            if (!Directory.Exists(path))
                                Directory.CreateDirectory(path);
                            try
                            {
                                if (!string.IsNullOrEmpty(SavedDoc.OldGuid))
                                    File.Delete(Path.Combine(path, SavedDoc.OldGuid));

                                using Stream fileStream = new FileStream(Path.Combine(path, SavedDoc.Guid), FileMode.Create);
                                file?.CopyTo(fileStream);
                            }
                            catch (Exception)
                            {
                                SavedDoc.StatusCode = 1;
                                SavedDoc.Summary = "Error while saving Help Document.";
                            }
                        }
                    }
                }
                return SavedDoc;
            }
            catch (Exception)
            {
                return new HelpDocument() { StatusCode = 1, Summary = "Error while saving Help Document." };
            }
        }
        public List<HelpDocument> GetHelpDocument(decimal Id = 0, int IsActive = 2)
        {
            return commonRepository.GetHelpDocument(Id, IsActive);
        }
        #endregion

        #region Download File
        public dynamic DownloadFile(DocTypeEnum docType, string FileName)
        {
            try
            {
                string AllowedFileTypes = GetConfigValue(docType == DocTypeEnum.RequestDocument ? "AppSettings:AllowedDocumentsExtensions" : "AppSettings:AllowedHelpDocumentsExtensions");
                if (FileName.IsValidFileType(AllowedFileTypes) && !Path.IsPathRooted(FileName) && !FileName.ContainsInvalidChar() && FileName.IsValidPath())
                {
                    string parentDir = GetConfigValue("AppSettings:eMOCNASFolder");
                    string subDir = GetConfigValue(docType == DocTypeEnum.RequestDocument ? "AppSettings:DocumentsFolderName" : "AppSettings:HelpDocumentsFolderName");
                    if (parentDir.ContainsInvalidChar() || subDir.ContainsInvalidChar() || !parentDir.IsValidPath(1) || !subDir.IsValidPath(1)) return new Response() { StatusCode = 1, Detail = "Invalid File" };
                    string path = Path.Combine(parentDir, subDir);

                    string sFile = "";
                    if (Path.IsPathRooted(FileName))
                        return new Response() { StatusCode = 1, Detail = "Invalid File Path" };
                    else
                        sFile = Path.Combine(path, FileName);

                    sFile = Normalize.parse(sFile);
                    if (sFile.PathStartsWithCheck() && sFile.ContainsInvalidChar() && !sFile.IsValidPath(1)) return new Response() { StatusCode = 1, Detail = "Invalid File" };
                    if (File.Exists(sFile) && sFile.StartsWith(path) && sFile.IsValidPath(1))
                    {
                        byte[] fileBytes = File.ReadAllBytes(sFile);
                        new FileExtensionContentTypeProvider().TryGetContentType(sFile, out string contentType);
                        return new FileContentResult(fileBytes, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(contentType));
                    }
                    return new Response() { StatusCode = 1, Detail = FileName + " file does not exist." };
                }
                else
                    return new Response() { StatusCode = 1, Detail = "Document Name or Document Type is not in correct format." };
            }
            catch (Exception ex)
            {
                return new Response() { StatusCode = 1, Detail = ex.Message };
            }
        }
        #endregion

        #region Contact Us Information
        public dynamic GetContactUs()
        {
            return commonRepository.GetContactUs();
        }
        #endregion

        #region Search CMS Procedure (Autocomplete)
        public List<CMSProcedure> SearchCMSProcedure(string Keyword)
        {
            return commonRepository.SearchCMSProcedure(Keyword);
        }
        #endregion


        #region Get UserList By RefrenceIndicator
        public List<UserDetail> GetUserListByRefrenceIndicator(string Keyword)
        {
            return commonRepository.GetUserListByRefrenceIndicator(Keyword);
        }


        #endregion


       

    }
}
