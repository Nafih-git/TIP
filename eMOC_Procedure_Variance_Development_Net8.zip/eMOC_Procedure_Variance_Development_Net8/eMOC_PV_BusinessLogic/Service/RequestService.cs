﻿using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_Common;
using eMOC_PV_DataAccess.Interface;
using eMOC_PV_Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace eMOC_PV_BusinessLogic.Service
{
    public class RequestService : IRequestService
    {
        private readonly IRequestRepository requestRepository;
        private readonly ICommonService commonService;
        private readonly IConfiguration config;
        #region Constructor
        public RequestService(IRequestRepository _requestRepository, ICommonService _commonService, IConfiguration _config)
        {
            requestRepository = _requestRepository;
            commonService = _commonService;
            config = _config;
        }
        #endregion

        #region Workflow Progress Bar (Steps)
        public List<Steps> GetWorkflowSteps(int RequestId = 0, int WorkflowTypeId = 1)
        {
            return requestRepository.GetWorkflowSteps(RequestId, WorkflowTypeId);
        }
        #endregion

        #region Workflow Actions
        public List<Actions> GetWorkflowActions(int RequestId = 0, int WorkflowTypeId = 1)
        {
            return requestRepository.GetWorkflowActions(RequestId, WorkflowTypeId);
        }
        #endregion

        #region Request Document
        public List<RequestDocument> GetRequestDocument(int Id = 0, int RequestId = 0)
        {
            return requestRepository.GetRequestDocument(Id, RequestId);
        }
        public RequestDocument SaveRequestDocument(RequestDocument model, IFormFile file)
        {
            try
            {
                RequestDocument SavedDoc = new();
                if (file != null)
                {
                    SavedDoc = requestRepository.SaveRequestDocument(model);
                    if (SavedDoc?.StatusCode == 0 && !string.IsNullOrEmpty(SavedDoc?.Guid))
                    {
                        if (SavedDoc.Guid.IsValidFileType(commonService.GetConfigValue("AppSettings:AllowedDocumentsExtensions")))
                        {
                            string path = Path.Combine(commonService.GetConfigValue("AppSettings:eMOCNASFolder"), commonService.GetConfigValue("AppSettings:DocumentsFolderName"));
                            if (!Directory.Exists(path))
                                Directory.CreateDirectory(path);

                            try
                            {
                                using Stream fileStream = new FileStream(Path.Combine(path, SavedDoc.Guid), FileMode.Create);
                                file?.CopyTo(fileStream);
                            }
                            catch (Exception)
                            {
                                SavedDoc.StatusCode = 1;
                            }
                        }
                        else SavedDoc.StatusCode = 1;
                    }
                    else SavedDoc.StatusCode = 1;
                }
                else SavedDoc.StatusCode = 1;
                return SavedDoc;
            }
            catch (Exception)
            {
                return new() { StatusCode = 1 };
            }
        }
        #endregion

        #region Request
        public async Task<Response> SaveRequestAsync(Request model)
        {
            List<Steps> lsSteps = GetWorkflowSteps(model.Id, model.General.WorkFlowId);
            Response resp = requestRepository.SaveRequest(model);
            if (resp.StatusCode == 0)
            {
                Request savedModel = requestRepository.GetRequest((int)resp.Id);
                savedModel.Stepper = lsSteps;
                savedModel.ApproverHistory = null;
                Response respHistory = requestRepository.UpdateHistory(resp.Id, savedModel.ToJson());

                resp.StatusCode = respHistory.StatusCode > 0 ? 2 : resp.StatusCode;
                resp.Detail += respHistory.StatusCode > 0 ? "\n History not saved." : "";
                await SendEmailNotification(resp.Id);
            }
            return resp;
        }
        public Request GetRequest(int RequestId)
        {
            Request request = requestRepository.GetRequest(RequestId);
            return request;
        }
        public Request GetRequestHistory(decimal Id)
        {
            return requestRepository.GetRequestHistory(Id);
        }
        public List<ApproverHistory> GetApproverHistory(int RequestId)
        {
            return requestRepository.GetApproverHistory(RequestId);
        }
        public List<AllRequest> GetAllRequests(string FilterString)
        {
            AllRequestFilter filter = FilterString.ToObject<AllRequestFilter>();
            if (!String.IsNullOrEmpty(filter?.RequestFilter))
            {
                dynamic d = filter.RequestFilter.ToObject<dynamic>();

                if (d.IsMyTask == 1)
                {
                    d.PendingWith = Global.User.MuNumber;
                    filter.RequestFilter = JsonConvert.SerializeObject(d);
                }
            }
             
            return requestRepository.GetAllRequests(filter);
        }

        public List<AllRequest> GetPendingWithRequests(string FilterString)
        {
            AllRequestFilter filter = FilterString.ToObject<AllRequestFilter>();
            return requestRepository.GetPendingWithRequests(filter);
        }
        public List<Tasks> GetTaskHistory(decimal Id)
        {
            return requestRepository.GetTaskHistory(Id);
        }

        public List<Tasks> GetTaskHistoryByRequestId(decimal Id)
        {
            return requestRepository.GetTaskHistoryByRequestId(Id);
        }
        public List<RequestExtension> GetExtensionHistory(decimal Id)
        {
            return requestRepository.GetExtensionHistory(Id);
        }
        public async Task SendEmailNotification(decimal RequestId = 0)
        {
            EmailService emailService = new(config);
            List<Email> outbox = requestRepository.GetOutboxMails(RequestId);
            foreach (Email mail in outbox)
            {
                mail.Subject = mail.Subject.Replace("##AppName##", mail.ApplicationName);
                mail.Subject = mail.Subject.Replace("##RequestId##", mail.RequestId.ToString());
                mail.MailBody = mail.MailBody.Replace("##AppName##", mail.ApplicationName);
                if (mail.RequestId > 0)
                {
                    mail.MailBody = mail.MailBody.Replace("##RequestId##", mail.RequestId.ToString());
                    mail.MailBody = mail.MailBody.Replace("##ApplicationURL##", String.Concat(mail.ApplicationURL, mail.RequestId));
                }
                else
                {
                
                    mail.MailBody = mail.MailBody.Replace("##URL##",mail.URL);
                }
           
                mail.MailBody = mail.MailBody.Replace("##RecipientName##", mail.RecipientName);
                mail.MailBody = mail.MailBody.Replace("##OriginatorRole##", mail.OriginatorRole);
                mail.MailBody = mail.MailBody.Replace("##ApproverRole##", mail.ApproverRole);

                mail.MailBody = mail.MailBody.Replace("##ActualUser##", mail.ActualUser);
                mail.MailBody = mail.MailBody.Replace("##RoleName##", mail.RoleName);
                mail.MailBody = mail.MailBody.Replace("##FromDate##", Conversions.ToDateTimeString(mail.FromDate.ToString()));
                mail.MailBody = mail.MailBody.Replace("##ToDate##", Conversions.ToDateTimeString(mail.ToDate.ToString()));
                mail.MailBody = mail.MailBody.Replace("##REQFromDate##",Conversions.ToDateTimeString( mail.REQFromDate.ToString()));
                mail.MailBody = mail.MailBody.Replace("##REQToDate##", Conversions.ToDateTimeString(mail.REQToDate.ToString()));

                try
                {
                    await Task.Run(() => emailService.SendEmail(mail.RecipientMailId, mail.Subject, mail.MailBody));
                    await Task.Run(() => requestRepository.UpdateEmailSentStatus(mail.Id));
                }
                catch (Exception)
                {
                }
            }
        }
        #endregion

        #region Expired & Overdue Requests
        public async Task ProcessExpiredOverdueRequests()
        {
            try
            {
                List<Request> requests = requestRepository.GetExpiredOverdueRequests();
                foreach (Request request in requests)
                {
                    Request savedModel = requestRepository.GetRequest(request.Id);
                    savedModel.ApproverHistory = null;
                    await Task.Run(() => requestRepository.UpdateHistory(request.Id, savedModel.ToJson()));
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Copy Risk Assessment
        public List<GenericData> GetRequestId(decimal Id)
        {
            return requestRepository.GetRequestId(Id);
        }
        public RiskAssessment GetRiskAssessment(decimal RequestId)
        {
            return requestRepository.GetRiskAssessment(RequestId);
        }
        #endregion

   
        #region Dashboard Charts
        public dynamic GetDashboardCharts(string FilterString)
        {
            return requestRepository.GetDashboardCharts(FilterString);
        }
        public dynamic GetControlCenterStatus()
        {
            return requestRepository.GetControlCenterStatus();
        }
        public dynamic GetTotalExpiredKPI(string FilterString)
        {
            return requestRepository.GetTotalExpiredKPI(FilterString);
        }
        public dynamic GetPieChartParams()
        {
            return requestRepository.GetPieChartParams();
        }
        public dynamic GetQuarterBasedOnyear(string year)
        {
            return requestRepository.GetQuarterBasedOnyear(year);
        }
        public dynamic GetPieChartDetailsByStatus(string FilterString)
        {
            return requestRepository.GetPieChartDetailsByStatus(FilterString);
        }
        #endregion

        #region Approvers
        public RAApprovers GetRAApprovers(string DirectorateCode ,string AssetCode, string RRName, string CRName)
        {
            return requestRepository.GetRAApprovers(DirectorateCode,AssetCode, RRName,CRName);
        }
        #endregion


        #region Draft Requests For Deletion
        public async Task GetDraftRequestsForDeleting()
        {
            try
            {
                List<Request> requests = requestRepository.GetDraftRequestsForDeleting();
                foreach (Request request in requests)
                {
                    Request savedModel = requestRepository.GetRequest(request.Id);
                    savedModel.ApproverHistory = null;
                    await Task.Run(() => requestRepository.UpdateHistory(request.Id, savedModel.ToJson()));
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
