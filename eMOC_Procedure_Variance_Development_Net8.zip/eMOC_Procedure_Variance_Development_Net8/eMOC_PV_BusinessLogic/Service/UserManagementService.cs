﻿
using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_DataAccess.Interface;
using eMOC_PV_Models;

namespace eMOC_PV_BusinessLogic.Service
{
    public class UserManagementService : IUserManagementService
    {

        private readonly IUserManagementRepository userManagementRepository;


        public UserManagementService(IUserManagementRepository userManagementRepository)
        {

            this.userManagementRepository = userManagementRepository;

        }

        public List<UserManagement> GetAll()
        {
            return userManagementRepository.GetAll();
        }

        public UserManagement? GetById(int UserManagementId)
        {
            return userManagementRepository.GetById(UserManagementId);
        }
        public UserManagement GetByFilters(UserManagement model)
        {
            return userManagementRepository.GetByFilters(model);
        }

        public Response Save(UserManagement model)
        {
            return userManagementRepository.Save(model);
        }

        public List<UserDetail> SearchUser(string keyword)
        {
            return userManagementRepository.SearchUser(keyword);
        }


        public List<Assets> GetAssest(string DirectorateName)
        {
            return userManagementRepository.GetAssest(DirectorateName);
        }

        public List<Directorates> GetDirectorate()
        {
            return userManagementRepository.GetDirectorate();
        }


    }
}
