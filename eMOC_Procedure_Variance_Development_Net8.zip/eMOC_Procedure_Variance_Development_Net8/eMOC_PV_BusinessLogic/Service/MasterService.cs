﻿using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_DataAccess.Interface;
using eMOC_PV_Models;

namespace eMOC_PV_BusinessLogic.Service
{
    public class MasterService : IMasterService
    {
        private readonly IMasterRepository masterRepository;
        private readonly ICommonService commonService;

        #region Constructor
        public MasterService(IMasterRepository _masterRepository, ICommonService _commonService)
        {
            masterRepository = _masterRepository;
            commonService = _commonService;
        }
        #endregion

        #region Master Items
        public List<GenericData> GetMasterItems()
        {
            return masterRepository.GetMasterItems();
        }
        #endregion

        #region Role
        public List<Roles> GetRole(int Id = 0, int IsActive = 2)
        {
            return masterRepository.GetRole(Id, IsActive);
        }

        public Response SaveRole(Roles model)
        {
            return masterRepository.SaveRole(model);
        }

        public List<Roles> GetAllRolesForUserManagement()
        {
            try
            {
                List<Roles> Result = null;
                List<Roles> UserRoles = commonService.GetUserDetail().UserRoles;
                if (UserRoles.Any(r => r.IsSPA == 1))
                {
                    Result = masterRepository.GetRole();

                }
                else if (UserRoles.Any(r => r.IsSBA == 1))
                {
                    Result = masterRepository.GetRole().Where(r => r.IsSPA == 0).ToList();
                }
                return Result;
            }
            catch (Exception)
            {

                throw;
            }
        }


        public List<Roles> GetAllRolesForDelegation()
        {
            try
            {
                List<Roles> Result = null;
                List<Roles> UserRoles = commonService.GetUserDetail().UserRoles;

                Result = masterRepository.GetRole().ToList()?.Where(r => r.IsDelegatedRole == 1).ToList();

                return Result;
            }
            catch (Exception)
            {

                throw;
            }
        }


        public List<Roles> GetKPISLA()
        {
            try
            {
                List<Roles> Result = null;


                Result = masterRepository.GetKPISLA();

                return Result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        #endregion

        #region Module
        public List<Module> GetModule(int Id = 0, int IsActive = 2)
        {
            return masterRepository.GetModule(Id, IsActive);
        }
        public Response SaveModule(Module model)
        {
            return masterRepository.SaveModule(model);
        }
        #endregion

        #region Screen
        public List<Screen> GetScreen(int Id = 0, int IsActive = 2)
        {
            return masterRepository.GetScreen(Id, IsActive);
        }
        public Response SaveScreen(Screen model)
        {
            return masterRepository.SaveScreen(model);
        }
        #endregion

        #region RA Control Type
        public List<RAControlType> GetRAControlType(int Id = 0, int IsActive = 2)
        {
            return masterRepository.GetRAControlType(Id, IsActive);
        }
        public Response SaveRAControlType(RAControlType model)
        {
            return masterRepository.SaveRAControlType(model);
        }
        #endregion

        #region RA Control Owner Role
        public List<RAControlOwnerRole> GetRAControlOwnerRole(int Id = 0, int IsActive = 2, string OwnerRole = "", int RetType = 0)
        {
            return masterRepository.GetRAControlOwnerRole(Id, IsActive, OwnerRole, RetType);
        }

        public Response SaveRAControlOwnerRole(RAControlOwnerRole model)
        {
            return masterRepository.SaveRAControlOwnerRole(model);
        }
        #endregion
        #region Frequency
        public List<FrequencyList> GetFrequency()
        {
            return masterRepository.GetFrequency();
        }
        #endregion
        #region RA Hazard
        public List<RAHazard> GetRAHazard(int Id = 0, int IsActive = 2, string Name = "", int RetType = 0)
        {
            return masterRepository.GetRAHazard(Id, IsActive, Name, RetType);
        }

        public Response SaveRAHazard(RAHazard model)
        {
            return masterRepository.SaveRAHazard(model);
        }
        #endregion

        #region RA Effect of Hazard
        public List<RAHazardEffects> GetRAHazardEffect(int Id = 0, int HazardId = 0, int IsActive = 2, string Name = "", int RetType = 0)
        {
            return masterRepository.GetRAHazardEffect(Id, HazardId, IsActive, Name, RetType);
        }

        public Response SaveRAHazardEffect(RAHazardEffects model)
        {
            return masterRepository.SaveRAHazardEffect(model);
        }
        #endregion

        #region RA Control Measure
        public List<RAControlMeasure> GetRAControlMeasure(int Id = 0, int HazardId = 0, int IsActive = 2, string Name = "", int RetType = 0)
        {
            return masterRepository.GetRAControlMeasure(Id, HazardId, IsActive, Name, RetType);
        }

        public Response SaveRAControlMeasure(RAControlMeasure model)
        {
            return masterRepository.SaveRAControlMeasure(model);
        }
        #endregion

        #region Directorates
        public List<Directorates> GetDirectorates()
        {
            return masterRepository.GetDirectorates();
        }
        #endregion

        #region Asset
        public List<Assets> GetAssets(string Directorate = null)
        {
            return masterRepository.GetAssets(Directorate);
        }
        #endregion

        #region Facility
        public List<Facilities> GetFacilities(string Asset = null, string Directorate = null)
        {
            return masterRepository.GetFacilities(Asset, Directorate);
        }
        #endregion



        #region Reason For Variance
        public List<ReasonVariance> GetReasonVariance(int Id = 0, int IsActive = 2)
        {
            return masterRepository.GetReasonVariance(Id, IsActive);
        }
        public Response SaveReasonVariance(ReasonVariance model)
        {
            return masterRepository.SaveReasonVariance(model);
        }
        #endregion

        

        

        #region Approvers List
        public List<UserDetail> GetApprovers(int RoleId, string Directorate, string Asset)
        {
            return masterRepository.GetApprovers(RoleId, Directorate, Asset);
        }
        #endregion

        #region Workflow Status
        public List<Status> GetWorkflowStatus()
        {
            return masterRepository.GetWorkflowStatus();
        }
        #endregion


        #region Email template
        public List<EmailTemplate> GetEmailTemplates(int Id = 0)
        {
            return masterRepository.GetEmailTemplates(Id);
        }
        public Response SaveEmailTemplate(EmailTemplate model)
        {
            return masterRepository.SaveEmailTemplate(model);
        }
        #endregion
    }
}
