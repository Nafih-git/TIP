﻿using eMOC_PV_BusinessLogic.Interface;

namespace eMOC_PV_API.JobScheduler
{
    public class SchedulerService : IHostedService, IDisposable
    {
        private Timer? timer = null;
        private readonly IConfiguration config;
        private readonly IRequestService requestservice;

        public SchedulerService(IConfiguration _config, IRequestService _requestservice)
        {
            config = _config;
            requestservice = _requestservice;
        }
        public Task StartAsync(CancellationToken cancellationToken)
        {
            timer = new Timer(DoWork, null, TimeSpan.Zero, TimeSpan.FromMinutes(1));
            return Task.CompletedTask;
        }
        public async void DoWork(object? state)
        {
            try
            {
                await requestservice.ProcessExpiredOverdueRequests();
                await requestservice.SendEmailNotification();
                await requestservice.GetDraftRequestsForDeleting();
            }
            catch (Exception)
            {
            }
        }
        public Task StopAsync(CancellationToken cancellationToken)
        {
            timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }
        public void Dispose()
        {
            timer?.Dispose();
        }
    }
}
