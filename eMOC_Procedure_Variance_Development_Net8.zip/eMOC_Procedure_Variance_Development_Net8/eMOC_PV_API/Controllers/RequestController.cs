﻿using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_BusinessLogic.Service;
using eMOC_PV_Models;
using Microsoft.AspNetCore.Mvc;

namespace eMOC_TOC_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RequestController : ControllerBase
    {
        private readonly IRequestService requestService;
        private readonly ICommonService commonService;
        public RequestController(IRequestService _requestService, ICommonService _commonService)
        {
            requestService = _requestService;
            commonService = _commonService;
        }

        #region Workflow Progress Bar (Steps)
        [HttpGet("GetWorkflowSteps")]
        public IActionResult GetWorkflowSteps(int RequestId = 0, int WorkflowTypeId = 1)
        {
            //          RequestId = 30;
            return Ok(requestService.GetWorkflowSteps(RequestId, WorkflowTypeId));
        }
        #endregion

        #region Workflow Actions
        [HttpGet("GetWorkflowActions")]
        public IActionResult GetWorkflowActions(int RequestId = 0, int WorkFlowypeId = 1)
        {
            return Ok(requestService.GetWorkflowActions(RequestId, WorkFlowypeId));
        }
        #endregion

        #region Request Document
        [HttpGet("GetDocumentById/{DocumentId}")]
        public IActionResult GetDocumentById(int DocumentId)
        {
            return Ok(requestService.GetRequestDocument(DocumentId).FirstOrDefault());
        }

        [HttpGet("GetDocumentByRequestId/{RequestId}")]
        public IActionResult GetDocumentByRequestId(int RequestId)
        {
            return Ok(requestService.GetRequestDocument(RequestId: RequestId));
        }

        [HttpPost("SaveRequestDocument")]
        public IActionResult SaveRequestDocument([FromForm] RequestDocument model)
        {
            IFormFile file = Request.Form.Files.FirstOrDefault();
            return Ok(requestService.SaveRequestDocument(model, file));
        }

        [HttpGet("DownloadRequestDocument")]
        public IActionResult DownloadRequestDocument(string FileName)
        {
            return Ok(commonService.DownloadFile(DocTypeEnum.RequestDocument, FileName));
        }
        #endregion

        #region Request
        [HttpPost("SaveRequest")]
        public IActionResult SaveRequest([FromBody] Request model)
        {
            return Ok(requestService.SaveRequestAsync(model));
        }

        [HttpGet("GetRequestById/{RequestId}")]
        public IActionResult GetRequestById(int RequestId)
        {
            return Ok(requestService.GetRequest(RequestId));
        }

        [HttpGet("GetRequestHistoryById/{HistoryId}")]
        public IActionResult GetRequestHistoryById(decimal HistoryId)
        {
            return Ok(requestService.GetRequestHistory(HistoryId));
        }

        [HttpGet("GetAllRequests")]
        public IActionResult GetAllRequest(string FilterString)
        {

            dynamic res = requestService.GetAllRequests(FilterString);
             return Ok(res);
        }

        [HttpGet("GetPendingWithRequests")]
        public IActionResult GetPendingWithRequests(string FilterString)
        {
            return Ok(requestService.GetPendingWithRequests(FilterString));
        }

        [HttpGet("GetApprovalHistoryByRequestId/{RequestId}")]
        public IActionResult GetApprovalHistoryByRequestId(int RequestId)
        {
            return Ok(requestService.GetApproverHistory(RequestId));
        }

        [HttpGet("GetTaskHistoryByRequestId/{RequestId}")]
        public IActionResult GetTaskHistoryByRequestId(decimal RequestId)
        {
            return Ok(requestService.GetTaskHistory(RequestId));
        }


        [HttpGet("GetTaskHistory/{RequestId}")]
        public IActionResult GetTaskHistory(decimal RequestId)
        {
            return Ok(requestService.GetTaskHistoryByRequestId(RequestId));
        }
        [HttpGet("GetExtensionHistoryByRequestId/{RequestId}")]
        public IActionResult GetExtensionHistoryByRequestId(decimal RequestId)
        {
            return Ok(requestService.GetExtensionHistory(RequestId));
        }

        #endregion

        #region Copy Risk Assessment
        [HttpGet("GetRequestId/{Id}")]
        public IActionResult GetRequestId(decimal Id)
        {
            return Ok(requestService.GetRequestId(Id));
        }

        [HttpGet("GetRiskAssessmentByRequestId/{RequestId}")]
        public IActionResult GetRiskAssessmentByRequestId(decimal RequestId)
        {
            return Ok(requestService.GetRiskAssessment(RequestId));
        }
        #endregion


        #region Dashboard Charts
        [HttpGet("GetDashboardCharts")]
        public IActionResult GetDashboardCharts(string FilterString)
        {
            dynamic res = requestService.GetDashboardCharts(FilterString);
            return Ok(res);
        }
        [HttpGet("GetControlCenterStatus")]
        public IActionResult GetControlCenterStatus()
        {
            return Ok(requestService.GetControlCenterStatus());
        }
        [HttpGet("GetTotalExpiredKPI")]
        public IActionResult GetTotalExpiredKPI(string FilterString)
        {
            dynamic res = requestService.GetTotalExpiredKPI(FilterString);
            return Ok(res);
        }
        [HttpGet("GetPieChartParams")]
        public IActionResult GetPieChartParams()
        {
            return Ok(requestService.GetPieChartParams());
        }
        [HttpGet("GetQuarterBasedOnyear")]
        public IActionResult GetQuarterBasedOnyear(string year)
        {
            dynamic res = requestService.GetQuarterBasedOnyear(year);
            return Ok(res);
        }
        [HttpGet("GetPieChartByStatus")]
        public IActionResult GetPieChartDetailsByStatus(string FilterString)
        {
            dynamic res = requestService.GetPieChartDetailsByStatus(FilterString);
            return Ok(res);
        }
        #endregion

        #region Approvers
        [HttpPost("GetRAApprovers")]
        public IActionResult GetRAApprovers([Bind("DirectorateCode,AssetCode,RRName,CRName")] RAApproverFilter model)
        {
            if (!string.IsNullOrEmpty(model.DirectorateCode) && !string.IsNullOrEmpty(model.AssetCode) && !string.IsNullOrEmpty(model.RRName) && !string.IsNullOrEmpty(model.CRName))
                return Ok(requestService.GetRAApprovers(model.DirectorateCode,model.AssetCode, model.RRName, model.CRName));
            else
                return BadRequest();
        }

        #endregion
    }
}
