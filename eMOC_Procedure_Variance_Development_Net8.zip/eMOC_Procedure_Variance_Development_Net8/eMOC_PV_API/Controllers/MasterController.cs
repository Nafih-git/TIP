﻿using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_Models;
using Microsoft.AspNetCore.Mvc;

namespace eMOC_TOC_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterController : ControllerBase
    {
        private readonly IMasterService masterService;
        public MasterController(IMasterService _masterService)
        {
            masterService = _masterService;
        }

        #region Master Items
        [HttpGet("GetMasterItems")]
        public IActionResult GetMasterItems()
        {
            return Ok(masterService.GetMasterItems());
        }
        #endregion

        #region Role
        [HttpGet("GetAllRoles")]
        public IActionResult GetAllRoles()
        {
            return Ok(masterService.GetRole());
        }

        [HttpGet("GetActiveRoles")]
        public IActionResult GetActiveRoles()
        {
            return Ok(masterService.GetRole(IsActive: 1));
        }

        [HttpGet("GetRoleById/{RoleId}")]
        public IActionResult GetRoleById(int RoleId)
        {
            return Ok(masterService.GetRole(RoleId).FirstOrDefault());
        }

        [HttpPost("SaveRole")]
        public IActionResult SaveRole([FromBody] Roles model)
        {
            return Ok(masterService.SaveRole(model));
        }

        [HttpGet("GetAllRolesForUserManagement")]
        public IActionResult GetAllRolesForUserManagement()
        {

            return Ok(masterService.GetAllRolesForUserManagement());
        }

        [HttpGet("GetAllRolesForDelegation")]
        public IActionResult GetAllRolesForDelegation()
        {

            return Ok(masterService.GetAllRolesForDelegation());
        }

        [HttpGet("GetKPISLA")]
        public IActionResult GetKPISLA()
        {

            return Ok(masterService.GetKPISLA());
        }
        #endregion

        #region Module
        [HttpGet("GetAllModules")]
        public IActionResult GetAllModules()
        {
            return Ok(masterService.GetModule());
        }

        [HttpGet("GetActiveModules")]
        public IActionResult GetActiveModules()
        {
            return Ok(masterService.GetModule(IsActive: 1));
        }

        [HttpGet("GetModuleById/{ModuleId}")]
        public IActionResult GetModuleById(int ModuleId)
        {
            return Ok(masterService.GetModule(ModuleId).FirstOrDefault());
        }

        [HttpPost("SaveModule")]
        public IActionResult SaveModule([FromBody] Module model)
        {
            return Ok(masterService.SaveModule(model));
        }
        #endregion

        #region Screen
        [HttpGet("GetAllScreens")]
        public IActionResult GetAllScreens()
        {
            return Ok(masterService.GetScreen());
        }

        [HttpGet("GetActiveScreens")]
        public IActionResult GetActiveScreens()
        {
            return Ok(masterService.GetScreen(IsActive: 1));
        }

        [HttpGet("GetScreenById/{ScreenId}")]
        public IActionResult GetScreenById(int ScreenId)
        {
            return Ok(masterService.GetScreen(ScreenId).FirstOrDefault());
        }

        [HttpPost("SaveScreen")]
        public IActionResult SaveScreen(Screen model)
        {
            return Ok(masterService.SaveScreen(model));
        }
        #endregion

        #region RA Control Type
        [HttpGet("GetAllRAControlType")]
        public IActionResult GetAllRAControlType()
        {
            return Ok(masterService.GetRAControlType());
        }

        [HttpGet("GetActiveRAControlType")]
        public IActionResult GetActiveRAControlType()
        {
            return Ok(masterService.GetRAControlType(IsActive: 1));
        }

        [HttpGet("GetRAControlTypeById/{TypeId}")]
        public IActionResult GetRAControlTypeById(int TypeId)
        {
            return Ok(masterService.GetRAControlType(TypeId));
        }

        [HttpPost("SaveRAControlType")]
        public IActionResult SaveRAControlType([FromBody] RAControlType model)
        {
            return Ok(masterService.SaveRAControlType(model));
        }
        #endregion

        #region RA Control Owner Role
        [HttpGet("GetAllRAControlOwnerRole")]
        public IActionResult GetAllRAControlOwnerRole()
        {
            return Ok(masterService.GetRAControlOwnerRole());
        }

        [HttpGet("GetActiveRAControlOwnerRole")]
        public IActionResult GetActiveRAControlOwnerRole()
        {
            return Ok(masterService.GetRAControlOwnerRole(IsActive: 1));
        }

        [HttpGet("GetRAControlOwnerRoleById/{OwnerRoleId}")]
        public IActionResult GetRAControlOwnerRoleById(int OwnerRoleId)
        {
            return Ok(masterService.GetRAControlOwnerRole(OwnerRoleId));
        }

        [HttpGet("GetRAControlOwnerRoleByName/{OwnerRoleName}")]
        public IActionResult GetRAControlOwnerRoleByName(string OwnerRoleName)
        {
            return Ok(masterService.GetRAControlOwnerRole(0, 1, OwnerRoleName, 1));
        }

        [HttpPost("SaveRAControlOwnerRole")]
        public IActionResult SaveRAControlOwnerRole([FromBody] RAControlOwnerRole model)
        {
            return Ok(masterService.SaveRAControlOwnerRole(model));
        }
        #endregion


        #region Frequency

        [HttpGet("GetFrequency")]
        public IActionResult GetFrequency()
        {
            return Ok(masterService.GetFrequency());
        }

        #endregion
        #region RA Hazard
        [HttpGet("GetAllRAHazards")]
        public IActionResult GetAllRAHazards()
        {
            return Ok(masterService.GetRAHazard());
        }

        [HttpGet("GetActiveRAHazards")]
        public IActionResult GetActiveRAHazards()
        {
            return Ok(masterService.GetRAHazard(IsActive: 1));
        }

        [HttpGet("GetRAHazardById/{HazardId}")]
        public IActionResult GetRAHazardById(int HazardId)
        {
            return Ok(masterService.GetRAHazard(HazardId));
        }

        [HttpGet("GetRAHazardByName/{HazardName}")]
        public IActionResult GetRAHazardByName(string HazardName)
        {
            return Ok(masterService.GetRAHazard(0, 1, HazardName, 1));
        }

        [HttpPost("SaveRAHazard")]
        public IActionResult SaveRAHazard([FromBody] RAHazard model)
        {
            return Ok(masterService.SaveRAHazard(model));
        }
        #endregion

        #region RA Effect of Hazard
        [HttpGet("GetAllRAHazardEffects")]
        public IActionResult GetAllRAHazardEffects()
        {
            return Ok(masterService.GetRAHazardEffect());
        }

        [HttpGet("GetActiveRAHazardEffects")]
        public IActionResult GetActiveRAHazardEffects()
        {
            return Ok(masterService.GetRAHazardEffect(IsActive: 1));
        }

        [HttpGet("GetActiveRAHazardEffectById/{EffectId}")]
        public IActionResult GetActiveRAHazardEffectById(int EffectId)
        {
            return Ok(masterService.GetRAHazardEffect(EffectId));
        }

        [HttpGet("GetActiveRAHazardEffectsByHazardId/{HazardId}")]
        public IActionResult GetActiveRAHazardEffectsByHazardId(int HazardId)
        {
            return Ok(masterService.GetRAHazardEffect(0, HazardId, 1, RetType: 0));
        }

        [HttpGet("GetRAHazardEffectByName")]
        public IActionResult GetRAHazardEffectByName(int HazardId, string EffectName)
        {
            return Ok(masterService.GetRAHazardEffect(0, HazardId, 1, EffectName, 1));
        }

        [HttpPost("SaveRAHazardEffect")]
        public IActionResult SaveRAHazardEffect([FromBody] RAHazardEffects model)
        {
            return Ok(masterService.SaveRAHazardEffect(model));
        }
        #endregion

        #region RA Control Measure
        [HttpGet("GetAllRAControlMeasure")]
        public IActionResult GetAllRAControlMeasure()
        {
            return Ok(masterService.GetRAControlMeasure());
        }

        [HttpGet("GetActiveRAControlMeasure")]
        public IActionResult GetActiveRAControlMeasure()
        {
            return Ok(masterService.GetRAControlMeasure(IsActive: 1));
        }

        [HttpGet("GetActiveRAControlMeasureById/{EffectId}")]
        public IActionResult GetActiveRAControlMeasureById(int EffectId)
        {
            return Ok(masterService.GetRAControlMeasure(EffectId));
        }

        [HttpGet("GetActiveRAControlMeasureByHazardId/{HazardId}")]
        public IActionResult GetActiveRAControlMeasureByHazardId(int HazardId)
        {
            return Ok(masterService.GetRAControlMeasure(0, HazardId, 1, RetType: 0));
        }

        [HttpGet("GetRAControlMeasureByName")]
        public IActionResult GetRAControlMeasureByName(int HazardId, string EffectName)
        {
            return Ok(masterService.GetRAControlMeasure(0, HazardId, 1, EffectName, 1));
        }

        [HttpPost("SaveRAControlMeasure")]
        public IActionResult SaveRAControlMeasure([FromBody] RAControlMeasure model)
        {
            return Ok(masterService.SaveRAControlMeasure(model));
        }
        #endregion

        #region Directorates
        [HttpGet("GetDirectorates")]
        public IActionResult GetDirectorates()
        {
            return Ok(masterService.GetDirectorates());
        }
        #endregion

        #region Asset
        [HttpGet("GetAssets")]
        public IActionResult GetAssets(string Directorate = null)
        {
            return Ok(masterService.GetAssets(Directorate));
        }
        #endregion

        #region Facility
        [HttpGet("GetFacilities")]
        public IActionResult GetFacilities(string Asset = null, string Directorate = null)
        {
            return Ok(masterService.GetFacilities(Asset, Directorate));
        }
        #endregion

        

        #region Reason For Variance
        [HttpGet("GetAllReasonVariance")]
        public IActionResult GetAllReasonVariance()
        {
            return Ok(masterService.GetReasonVariance());
        }
        [HttpGet("GetActiveReasonVariance")]
        public IActionResult GetActiveReasonVariance()
        {
            return Ok(masterService.GetReasonVariance(IsActive: 1));
        }
        [HttpGet("GetReasonVarianceById/{ReasonVarianceId}")]
        public IActionResult GetCategoryById(int ReasonVarianceId)
        {
            return Ok(masterService.GetReasonVariance(ReasonVarianceId));
        }
     
        [HttpPost("SaveReasonVariance")]
        public IActionResult SaveReasonVariance([FromBody] ReasonVariance model)
        {
            return Ok(masterService.SaveReasonVariance(model));
        }
        #endregion

        

        

        #region Approvers List
        [HttpGet("GetApproversList")]
        public IActionResult GetApprovers(int RoleId, string Directorate, string Asset)
        {
            return Ok(masterService.GetApprovers(RoleId, Directorate, Asset));
        }
        #endregion

        #region Workflow Status
        [HttpGet("GetWorkflowStatus")]
        public IActionResult GetWorkflowStatus()
        {
            return Ok(masterService.GetWorkflowStatus());
        }
        #endregion


        #region Email Templates
        [HttpGet("GetAllEmailTemplates")]
        public IActionResult GetAllEmailTemplates()
        {
            return Ok(masterService.GetEmailTemplates());
        }

        [HttpPost("SaveEmailTemplate")]
        public IActionResult SaveEmailTemplate([FromBody] EmailTemplate model)
        {
            return Ok(masterService.SaveEmailTemplate(model));
        }
        #endregion
    }
}
