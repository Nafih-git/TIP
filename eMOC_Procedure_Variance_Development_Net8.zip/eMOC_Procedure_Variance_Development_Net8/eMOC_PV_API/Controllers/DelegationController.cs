﻿using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_Models;
using Microsoft.AspNetCore.Mvc;

namespace eMOC_TOC_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DelegationController : ControllerBase
    {
        private readonly IDelegationService delegationService;

        public DelegationController(IDelegationService DelegationService)
        {
            delegationService = DelegationService;
        }

        #region Delegation
        [HttpPost]
    

        [HttpPost]
        [Route("GetByFilters")]
        public IActionResult GetByFilters([FromBody] Delegation model)
        {
            return Ok(delegationService.GetByFilters(model));
        }


        [HttpGet]
        [Route("GetAll")]
        public IActionResult GetAll()
        {
            return Ok(delegationService.GetAll());
        }
        [HttpGet]
        [Route("GetById/{DelegationId}")]
        public IActionResult GetById(int DelegationId)
        {
            return Ok(delegationService.GetById(DelegationId));
        }
        [HttpPost]
        [Route("Save")]
        public IActionResult Save([FromBody] Delegation model)
        {
            return Ok(delegationService.Save(model));
        }



        #endregion

        #region Search User

        [HttpGet]
        [Route("SearchUser/{keyword}")]
        public IActionResult SearchUser(string keyword)
        {

            return Ok(delegationService.SearchUser(keyword));
        }

        #endregion

        
    }
}
