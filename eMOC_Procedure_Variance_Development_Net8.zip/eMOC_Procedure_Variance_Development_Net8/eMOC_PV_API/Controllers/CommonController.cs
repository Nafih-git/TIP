﻿using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_Common;
using eMOC_PV_Models;
using Microsoft.AspNetCore.Mvc;

namespace eMOC_TOC_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommonController : ControllerBase
    {
        private readonly ICommonService commonService;

        #region Constructor
        public CommonController(ICommonService _commonService)
        {
            commonService = _commonService;
        }
        #endregion

        [HttpGet("TestAPI")]
        public IActionResult TestAPI()
        {
            return Ok();
        }

        #region User Deatils
        [HttpGet("GetWinAuthAccount")]
        public IActionResult GetWinAuthAccount()
        {
            
            return Ok(commonService.GetUserDetail());
        }
        #endregion

        #region Is Authorized
        [HttpGet("IsAuthorized/{ScreenCode}")]
        public IActionResult IsAuthorized(string ScreenCode)
        {
            return Ok(commonService.IsAuthorized(ScreenCode));
        }
        #endregion

        #region Search User (Autocomplete)
        [HttpGet("SearchUser/{Keyword}")]
        public IActionResult SearchUser(string Keyword)
        {
            return Ok(commonService.SearchUser(Keyword));
        }
        #endregion

        #region Dynamic Menu
        [HttpGet("GetDynamicMenu")]
        public IActionResult GetDynamicMenu()
        {
            return Ok(commonService.GetUserMenu());
        }
        #endregion

        #region Allowed File Extension
        [HttpGet("GetAllowedFileExtensions")]
        public IActionResult GetAllowedFileExtensions()
        {
            return Ok(new { AllowedExtension = commonService.GetConfigValue("AppSettings:AllowedDocumentsExtensions") });
        }

        [HttpGet("GetAllowedHelpFileExtensions")]
        public IActionResult GetAllowedHelpFileExtensions()
        {
            return Ok(new { AllowedExtension = commonService.GetConfigValue("AppSettings:AllowedHelpDocumentsExtensions") });
        }
        #endregion

        #region Help Document
        [HttpPost("SaveHelpDocument")]
        public IActionResult SaveHelpDocument([FromForm] HelpDocument model)
        {
            IFormFile file = Request.Form.Files.FirstOrDefault();
            return Ok(commonService.SaveHelpDocumemt(model, file));
        }

        [HttpGet("GetAllHelpDocuments")]
        public IActionResult GetAllHelpDocuments()
        {
            return Ok(commonService.GetHelpDocument());
        }

        [HttpGet("GetHelpDocumentById/{DocumentId}")]
        public IActionResult GetHelpDocumentById(decimal DocumentId)
        {
            return Ok(commonService.GetHelpDocument(DocumentId).FirstOrDefault());
        }

        [HttpGet("GetActiveHelpDocuments")]
        public IActionResult GetActiveHelpDocuments()
        {
            return Ok(commonService.GetHelpDocument(IsActive: 1));
        }

        [HttpGet("DownloadHelpFile")]
        public IActionResult DownloadHelpFile(string FileName)
        {
            return Ok(commonService.DownloadFile(DocTypeEnum.HelpDocument, FileName));
        }
        #endregion

        #region Contact Us Information
        [HttpGet("GetContactUs")]
        public IActionResult GetContactUs()
        {
            return Ok(commonService.GetContactUs());
        }
        #endregion


        #region Crypto

      

        [Route("Decrypt")]
        [HttpGet]
        public string Decrypt(string str)
        {
            return str.Decrypt();
        }

        [Route("Encrypt")]
        [HttpGet]
        public string Encrypt(string str)
        {
            return str.Encrypt();
        }

        #endregion

        #region Search CMS Procedure (Autocomplete)
        [HttpGet("SearchCMSProcedure/{Keyword}")]
        public IActionResult SearchCMSProcedure(string Keyword)
        {
            return Ok(commonService.SearchCMSProcedure(Keyword));
        }
        #endregion

        #region Get UserList By RefrenceIndicator
        [HttpGet("GetUserListByRefrenceIndicator/{Keyword}")]
        public IActionResult GetUserListByRefrenceIndicator(string Keyword)
        {
            return Ok(commonService.GetUserListByRefrenceIndicator(Keyword));
        }


        #endregion




    }
}




