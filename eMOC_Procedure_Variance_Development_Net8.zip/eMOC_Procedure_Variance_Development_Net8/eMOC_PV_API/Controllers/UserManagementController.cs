﻿using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_Models;
using Microsoft.AspNetCore.Mvc;

namespace eMOC_TOC_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserManagementController : ControllerBase
    {
        private readonly IUserManagementService userManagementService;

        public UserManagementController(IUserManagementService UserManagementService)
        {
            userManagementService = UserManagementService;
        }

        #region UserManagement

        [HttpPost]
        [Route("GetByFilters")]
        public IActionResult GetByFilters([FromBody] UserManagement model)
        {
            return Ok(userManagementService.GetByFilters(model));
        }


        [HttpGet]
        [Route("GetAll")]
        public IActionResult GetAll()
        {
            return Ok(userManagementService.GetAll());
        }
        [HttpGet]
        [Route("GetById/{UsermanagementId}")]
        public IActionResult GetById(int UsermanagementId)
        {
            return Ok(userManagementService.GetById(UsermanagementId));
        }
        [HttpPost]
        [Route("Save")]
        public IActionResult Save([FromBody] UserManagement model)
        {
            return Ok(userManagementService.Save(model));
        }



        #endregion

        #region Search User

        [HttpGet]
        [Route("SearchUser/{keyword}")]
        public IActionResult SearchUser(string keyword)
        {

            return Ok(userManagementService.SearchUser(keyword));
        }

        #endregion

        #region Get Asset

        [HttpGet]
        [Route("GetAssest/{DirectorateName}")]
        public IActionResult GetAssest(string DirectorateName)
        {


            return Ok(userManagementService.GetAssest(DirectorateName));
        }

        [HttpGet]
        [Route("GetDirectorate")]
        public IActionResult GetDirectorate()
        {


            return Ok(userManagementService.GetDirectorate());
        }

        #endregion
    }
}
