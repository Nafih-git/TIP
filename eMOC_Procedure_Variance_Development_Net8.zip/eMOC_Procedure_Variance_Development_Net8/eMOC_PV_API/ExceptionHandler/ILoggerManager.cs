﻿namespace eMOC_PV_API.ExceptionHandler
{
    public interface ILoggerManager
    {
        void LogInfo(string message);
        void LogWarn(string message);
        void LogDebug(string message);
        void LogError(string message, Exception ex);
    }
}
