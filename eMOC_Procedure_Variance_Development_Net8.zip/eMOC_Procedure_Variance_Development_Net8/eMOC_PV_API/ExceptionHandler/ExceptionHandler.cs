﻿using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_Common;
using eMOC_PV_Models;
using Microsoft.AspNetCore.Diagnostics;
using System.Net;

namespace eMOC_PV_API.ExceptionHandler
{
    public static class ExceptionHandler
    {
        private static ILoggerManager logger;
        private static ICommonService commonService;

        public static void ConfigureExceptionHandler(this IApplicationBuilder app, IConfiguration configuration, IHttpContextAccessor accessor)
        {
            app.UseExceptionHandler(appError =>
            {
                appError.Run(async context =>
                {
                    logger = accessor.HttpContext?.RequestServices.GetRequiredService<ILoggerManager>();
                    commonService = accessor.HttpContext?.RequestServices.GetRequiredService<ICommonService>();

                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    context.Response.ContentType = "application/json";
                    var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
                    string exception = contextFeature?.Error.Message;

                    Guid errorId = Guid.NewGuid();
                    string formattedException = string.Format("{0} - {1} : {2}", errorId.ToString(), exception?.GetType().Name, exception?.ToString());
                    logger?.LogError(formattedException, (Exception)contextFeature.Error);
                    commonService.SaveErrorLog(new ErrorLog() { ErrorId = errorId.ToString(), Exception = formattedException, StackTrace = exception + "\n" + contextFeature.Error.StackTrace });
                    string errormsg = String.Format("{0}{1}", configuration["AppSettings:GlobalErrorMessage"], String.Format("<b>{0}</b>", errorId));

                    if (contextFeature != null)
                    {
                        Response resp = new()
                        {
                            StatusCode = context.Response.StatusCode,
                            Summary = "Error Occurred",
                            Detail = errormsg
                        };
                        await context.Response.WriteAsync(resp.ToJson());
                    }
                });
            });
        }
    }
}
