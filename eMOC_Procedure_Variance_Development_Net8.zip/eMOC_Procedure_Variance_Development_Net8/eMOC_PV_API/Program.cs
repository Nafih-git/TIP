
using eMOC_PV_BusinessLogic;
using eMOC_PV_API.APILogger;
using eMOC_PV_API.ExceptionHandler;
using eMOC_PV_API.JobScheduler;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using Newtonsoft.Json;
using NLog;
using eMOC_PV_Common;
using Microsoft.Extensions.Configuration;



var builder = WebApplication.CreateBuilder(args);
LogManager.LoadConfiguration(string.Concat(Directory.GetCurrentDirectory(), "/nlog.config"));

// Add services to the container.
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyMethod().AllowAnyHeader().SetIsOriginAllowed(origin => true).AllowCredentials();
    });
});
builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme).AddNegotiate();
builder.Services.AddMvc(config =>
{
    var policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
    config.Filters.Add(new AuthorizeFilter(policy));
});
builder.Services.AddControllers().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.PropertyNamingPolicy = null;
}).AddNewtonsoftJson(options =>
{
    options.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver();
    options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
    options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Local;
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(option =>
{
    option.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = builder.Environment.ApplicationName + " (" + builder.Environment.EnvironmentName + ")", Description = "eMOC Procedure Variance API", Version = "v1" });
});

DependencyInjection.RegisterDependencies(builder.Services);
builder.Services.AddSingleton<ILoggerManager, LoggerManager>();
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
builder.Services.AddHostedService<SchedulerService>();
var accessor = builder.Services.BuildServiceProvider().GetService<IHttpContextAccessor>();
Global.SetHttpContextAccessor(accessor);

var app = builder.Build();
if (app.Configuration.GetValue<bool>("AppSettings:APILogEnabled"))
    app.UseMiddleware<HttpLogger>();

app.ConfigureExceptionHandler(app.Configuration, accessor);

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseCors();
app.UseAuthentication();
app.MapControllers();
app.Run();
