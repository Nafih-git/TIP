﻿using eMOC_PV_BusinessLogic.Interface;
using eMOC_PV_Models;
using System.Net;

namespace eMOC_PV_API.APILogger
{
    public class HttpLogger
    {
        private readonly ICommonService commonService;
        public readonly IConfiguration configuration;
        private readonly RequestDelegate next;

        public HttpLogger(RequestDelegate _next, ICommonService _commonService, IConfiguration _configuration)
        {
            next = _next;
            commonService = _commonService;
            configuration = _configuration;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await next(context);
            }
            finally
            {
                if (configuration.GetValue<bool>("AppSettings:APILogEnabled"))
                {
                    string clientMachine = Dns.GetHostEntry(context.Connection.RemoteIpAddress).HostName.ToUpper();
                    string createdBy = context.User?.Identity?.Name?.ToUpper();
                    ApiLog model = new()
                    {
                        Method = context.Request.Method,
                        Url = context.Request.Path,
                        StatusCode = context.Response.StatusCode,
                        IPAddress = context.Connection.RemoteIpAddress.ToString(),
                        HostName = context.Request.Host.ToString(),
                        ClientMachine = clientMachine != null ? clientMachine.Substring(0, clientMachine.IndexOf(@".")) : "",
                        CreatedBy = createdBy != null ? createdBy.Substring(createdBy.LastIndexOf(@"\") + 1) : "System"
                    };
                    commonService.SaveApiLog(model);
                }
            }
        }
    }
}
