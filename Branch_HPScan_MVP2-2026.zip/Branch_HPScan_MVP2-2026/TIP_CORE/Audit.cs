﻿using System;
using System.Text.Json.Serialization;

namespace TIP_Core
{
    public class Audit
    {
        public string? CreatedBy { get; set; }
        public string? CreatedByName { get; set; }
        public DateTime? CreatedDate { get; set; }

        public string? ModifiedBy { get; set; }
        public string? ModifiedByName { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public decimal Status { get; set; }
    }
}
