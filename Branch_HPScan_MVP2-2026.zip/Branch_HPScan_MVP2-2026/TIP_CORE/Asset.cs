﻿namespace TIP_Core
{
    public class Asset
    {
        public string DisplayName { get; set; }
        public string Value { get; set; }
        public string Name { get; set; }
        public string DirectorateName { get; set; }
    }
}
