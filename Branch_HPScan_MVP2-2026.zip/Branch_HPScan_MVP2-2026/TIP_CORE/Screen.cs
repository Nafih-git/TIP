﻿using System.Text.Json.Serialization;

namespace TIP_Core
{
    public class Screen : Audit
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string DisplayName { get; set; }
        public int OrderNo { get; set; }
        public string URL { get; set; }
        public int ModuleId { get; set; }
        public string ModuleName { get; set; }
        public short IsActive { get; set; }
        public short IsSAOnly { get; set; }
        public short IsCAOnly { get; set; }
        public string Icon { get; set; }
        public bool Selected { get; set; }
    }
}
