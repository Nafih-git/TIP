﻿using TIP_Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE
{
    public class Directorate : Audit
    {
        public decimal DirectorateId { get; set; }
        public string DirectorateName { get; set; }
        public decimal CorporateId { get; set; }
        public decimal ClusterCount { get; set; }
        public decimal SubClusterCount { get; set; }
        public string StatusName { get; set; }
    }
}
