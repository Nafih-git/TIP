﻿using TIP_Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE
{
    public class Corporate : Audit
    {

        public int CorporateId { get; set; }
        public string CorporateName { get; set; }
    }
}

