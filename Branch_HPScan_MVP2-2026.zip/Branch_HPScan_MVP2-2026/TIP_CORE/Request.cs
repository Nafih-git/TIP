﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE
{
    public class Request<T>
    {
        public int Status { get; set; }
        public string Module { get; set; }
        public string MU_ID { get; set; }
        public T TRequest { get; set; }
    }
}
