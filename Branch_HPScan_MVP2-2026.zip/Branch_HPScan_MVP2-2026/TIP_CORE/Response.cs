﻿using System;

namespace TIP_Core
{
    public class Response
    {
        public int StatusCode { get; set; }
        public string Severity { get { return Enum.GetName(typeof(Severity), StatusCode); } }
        public string Summary { get; set; }
        public string Detail { get; set; }
        public int Id { get; set; }
    }
    public enum Severity
    {
        success = 0,
        error,
        warn,
        info,        
    }
}
