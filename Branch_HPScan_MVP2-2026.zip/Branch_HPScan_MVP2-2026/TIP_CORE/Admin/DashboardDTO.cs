﻿using TIP_API.DTO.Admin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.Admin
{
    public class DashboardDTO
    {
        
    }
    public class BaseDTO
    {
        public List<EmployeeDTOs>? employeeData { get; set; }
        public List<UserRoleDTO>? empRoleList { get; set; }

        public List<SideMenuDTO>? empMenuList { get; set; }
    }
    public class SideMenuDTO
    {
        public string? MENU_ID { get; set; }
        public string? PARENT_MENU_ID { get; set; }
        public string? MENU_NAME { get; set; }
        public string? MENU_URL { get; set; }
        public string? ICON_CLASS_NAME { get; set; }
    }
    public class EmployeeDTOs
    {
        public string? COMPANY_NUMBER { get; set; }
        public string? EMPLOYEE_NAME { get; set; }
        public string? FIRST_NAME { get; set; }
        public string? LAST_NAME { get; set; }
        public string? OFFICE_PHONE { get; set; }
        public string? REFERENCE_INDICATOR { get; set; }
        public string? EMAIL_ADDRESS { get; set; }
        public string? DEFAULT_ROLE_ID { get; set; }
    }
  
}
