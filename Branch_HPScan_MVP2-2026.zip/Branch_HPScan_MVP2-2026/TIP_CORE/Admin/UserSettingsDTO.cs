﻿using System.Collections.Generic;
using TIP_Core;
using TIP_CORE.EntitiesDTO;

namespace TIP_API.DTO.Admin
{
    public class UserSettingsDTO
    {
        //public List<AllPDOUsersDTO>? pdoUsers { get; set; }
        public List<UserRoleDTO>? userRoleNames { get; set; }
       
    }

    public class AllPDOUsersDTO
    {
        public string? PERSONNEL_NUMBER { get; set; }
        public string? NAME { get; set; }
        public string? REFERENCE_INDICATOR { get; set; }
        public string? EMAIL_ADDRESS { get; set; }
        public string? USER_DISPLAY { get; set; }
        public string? JOB_DESCRIPTION { get; set; }
        public string? SUPERVISOR_ID { get; set; }
    }

   


    public class UserRoleDTO:Audit
    {
        public string? CRYPT_R_ID { get; set; }
        public Int32 R_ID { get; set; }
        public string? R_NAME { get; set; }
        public string? CODE { get; set; }
        public int IS_ACTIVE { get; set; }
        public int Default_R_ID { get; set; }
        public string? PARAM { get; set; }
    }

    public class UserRoleTypeDTO
    {
        public Int32 ROLE_TYPE_ID { get; set; }
        public string? ROLE_TYPE_NAME { get; set; }
    }

    public class DirectorateDTO
    {
        public Int32 DIRECTORATE_ID { get; set; }
        public string? DIRECTORATE_NAME { get; set; }
    }

    public class UserViewData
    {
        public UserViewDataD? ViewData { get; set; }
    }

    public class UserViewDataD
    {
        public AllPDOUsersDTO? selectedUser { get; set; }
        public List<UserRoleDTO>? selectedRName { get; set; }
       
        public Int32 ROW_ID { get; set; }
        public int IS_ACTIVE { get; set; }
    }


    public class UserApplicationViewDataD
    {
        public AllPDOUsersDTO? selectedUser { get; set; }
        public FocalPoint? selectedFPDetails { get; set; }
        public List<Linking>? selectedLinkingDetails { get; set; }

    }
    public class FocalPointListUAVD 
    {
        List<UserApplicationViewDataD> Asset { get; set; }
        List<UserApplicationViewDataD> Cluster { get; set; }
        List<UserApplicationViewDataD> Subtheme { get; set; }
    }


    public class FocalPoint 
    {
        public long? id { get; set; }
        public string? name { get; set; }
    }


    public class FocalpointLinkDetails
    {
        public string? userId { get; set; }
        public long? id { get; set; }
        public string? name { get; set; }
    }

    public class saveRoleToMenuMappingDTO
    {
       public RoleToMenuMappingDTO? ViewData { get; set; }
}
    public class RoleToMenuMappingDTO
    {
        public long? SelectedRl { get; set; }
        public List<MenuDTO>? rolTMMList { get; set; }
    }

    public class MenuDTO
    {
        public double MENU_ID { get; set; }
        public double PARENT_MENU_ID { get; set; }
        public string? MENU_NAME { get; set; }
        public Boolean IS_SELECTED { get; set; }
        public double? R_ID { get; set; }        
        public Boolean ALL_COMPLETE { get; set; }        
    }
    
}