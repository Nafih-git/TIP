﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtrBudget
    {
        public string Title { get; set; }
        public string Ctrrefnumber { get; set; }
        public string Budgetquarter { get; set; }
        public string Resourcedescription { get; set; }
        public string Itemprovider { get; set; }
        public string Budgetprovider { get; set; }
        public string Budgetamount { get; set; }
        public string Currency { get; set; }
        public string Budgetyear { get; set; }
    }
}
