﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrInitiation
    {
        public CtrInitiation()
        {
            CtrAdditionalSolutions = new HashSet<CtrAdditionalSolution>();
            CtrApprovalListHsties = new HashSet<CtrApprovalListHsty>();
            CtrApprovalLists = new HashSet<CtrApprovalList>();
            CtrBudgets = new HashSet<CtrBudget>();
            CtrDeploymentStaircases = new HashSet<CtrDeploymentStaircase>();
            CtrFlowHistories = new HashSet<CtrFlowHistory>();
            CtrPercentageCompletions = new HashSet<CtrPercentageCompletion>();
            CtrPlanDetails = new HashSet<CtrPlanDetail>();
            CtrPotentialImpacteds = new HashSet<CtrPotentialImpacted>();
            CtrProjectMembers = new HashSet<CtrProjectMember>();
            CtrSchedulePrices = new HashSet<CtrSchedulePrice>();
            CtrSuccessCriteria = new HashSet<CtrSuccessCriterion>();
            CtrTrialCandidates = new HashSet<CtrTrialCandidate>();
            CtrTrialFps = new HashSet<CtrTrialFp>();
            CtrTrialRisks = new HashSet<CtrTrialRisk>();
            CtrTrials = new HashSet<CtrTrial>();
            CtrVots = new HashSet<CtrVot>();
        }

        public long Id { get; set; }
        public long TechId { get; set; }
        public long StartingYear { get; set; }
        public string RefNo { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string CreatedByRef { get; set; }
        public string UpdatedByRef { get; set; }
        public string TrialName { get; set; }
        public long StatusId { get; set; }
        public string TechDescription { get; set; }
        public string TechMaturity { get; set; }
        public string TrialObjectives { get; set; }
        public string TrialWorkplaces { get; set; }
        public string TrialSelectionCriteria { get; set; }
        public string BusinessValue { get; set; }
        public string ContractingStratergy { get; set; }
        public bool? Confidential { get; set; }
        public string UctFp { get; set; }
        public long CurrentApprovalSeq { get; set; }
        public long SubmitCount { get; set; }
        public DateTime? SubmittedOn { get; set; }
        public DateTime? SentbackOn { get; set; }
        public DateTime? LastReminder { get; set; }
        public string DsAssumptionMode { get; set; }
        public string DsComment { get; set; }
        public string VendorCode { get; set; }
        public string SentbackBy { get; set; }
        public string ContractNumber { get; set; }
        public decimal? Ctrtrialcost { get; set; }
        public long? Ctrpaymentmilestone { get; set; }
        public string GeneralComments { get; set; }
        public long? NoTrials { get; set; }
        public long? CurrencyId { get; set; }

        public virtual TypeCodeMaster Currency { get; set; }
        public virtual TypeCodeMaster Status { get; set; }
        public virtual ICollection<CtrAdditionalSolution> CtrAdditionalSolutions { get; set; }
        public virtual ICollection<CtrApprovalListHsty> CtrApprovalListHsties { get; set; }
        public virtual ICollection<CtrApprovalList> CtrApprovalLists { get; set; }
        public virtual ICollection<CtrBudget> CtrBudgets { get; set; }
        public virtual ICollection<CtrDeploymentStaircase> CtrDeploymentStaircases { get; set; }
        public virtual ICollection<CtrFlowHistory> CtrFlowHistories { get; set; }
        public virtual ICollection<CtrPercentageCompletion> CtrPercentageCompletions { get; set; }
        public virtual ICollection<CtrPlanDetail> CtrPlanDetails { get; set; }
        public virtual ICollection<CtrPotentialImpacted> CtrPotentialImpacteds { get; set; }
        public virtual ICollection<CtrProjectMember> CtrProjectMembers { get; set; }
        public virtual ICollection<CtrSchedulePrice> CtrSchedulePrices { get; set; }
        public virtual ICollection<CtrSuccessCriterion> CtrSuccessCriteria { get; set; }
        public virtual ICollection<CtrTrialCandidate> CtrTrialCandidates { get; set; }
        public virtual ICollection<CtrTrialFp> CtrTrialFps { get; set; }
        public virtual ICollection<CtrTrialRisk> CtrTrialRisks { get; set; }
        public virtual ICollection<CtrTrial> CtrTrials { get; set; }
        public virtual ICollection<CtrVot> CtrVots { get; set; }
    }
}
