﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpAdminAttachment
    {
        public string AttachmentId { get; set; }
        public string ChallengeId { get; set; }
        public string FileName { get; set; }
        public string LiveLinkId { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
    }
}
