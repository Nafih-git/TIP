﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtr1
    {
        public short? Id { get; set; }
        public string Ctrrefnumber { get; set; }
        public string Title { get; set; }
        public string Trialname { get; set; }
        public string Challengename { get; set; }
        public string Technology { get; set; }
        public string Status { get; set; }
        public string CreatedBy { get; set; }
        public string Isapproved { get; set; }
        public string Ismechinsmcreated { get; set; }
        public string Trialfocalpoint1 { get; set; }
        public short? Technologyid { get; set; }
        public string Trialfocalpoint2 { get; set; }
        public string Trialfocalpoint3 { get; set; }
        public string Trialfocalpoint4 { get; set; }
        public string Trialfocalpoint5 { get; set; }
        public string Trialfp { get; set; }
        public int? Trialstartringyear { get; set; }
        public string Businessvalue { get; set; }
        public string Selectioncriteria { get; set; }
        public string Trialobjectives { get; set; }
        public string Workspace { get; set; }
        public string Contractingstrategy { get; set; }
        public string ChallengeDescription { get; set; }
    }
}
