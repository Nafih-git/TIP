﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipPhaseMaturationBk
    {
        public string Title { get; set; }
        public DateTime? CtrSubmittedDate { get; set; }
        public DateTime? CtrCompletionDate { get; set; }
        public DateTime? PoDate { get; set; }
        public DateTime? ExecutionInitiatedDate { get; set; }
        public DateTime? ExecutionCompletionDate { get; set; }
        public DateTime? PirSubmittedDate { get; set; }
        public DateTime? PirCompletionDate { get; set; }
        public string StageName { get; set; }
        public long? ActualDays { get; set; }
        public long? AssetId { get; set; }
        public string AssetName { get; set; }
        public long? ClusterId { get; set; }
        public string ClusterName { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public long? ThemeId { get; set; }
        public string ThemeName { get; set; }
    }
}
