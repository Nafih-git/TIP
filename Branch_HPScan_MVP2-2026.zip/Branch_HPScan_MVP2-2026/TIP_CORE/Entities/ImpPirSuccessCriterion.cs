﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpPirSuccessCriterion
    {
        public string Title { get; set; }
        public string Parameter { get; set; }
        public string Targetvalue { get; set; }
        public string Conclusion { get; set; }
        public string Comments { get; set; }
        public string Lessonlearnt { get; set; }
        public int? Pirid { get; set; }
    }
}
