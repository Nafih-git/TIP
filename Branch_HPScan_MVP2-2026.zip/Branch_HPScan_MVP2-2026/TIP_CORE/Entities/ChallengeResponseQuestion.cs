﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengeResponseQuestion
    {
        public long? ChallengeResponseId { get; set; }
        public long? VendorQuestionId { get; set; }
        public bool? Status { get; set; }
        public string Answer { get; set; }
        public long Id { get; set; }
        public string AnswerBk { get; set; }

        public virtual ChallengeResponse ChallengeResponse { get; set; }
        public virtual ChallengeVendorScreening VendorQuestion { get; set; }
    }
}
