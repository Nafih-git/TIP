﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipTechnologybankTrail
    {
        public long Id { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string Title { get; set; }
        public string AssetName { get; set; }
        public string ClusterName { get; set; }
        public string AreaName { get; set; }
        public string ApplicationName { get; set; }
        public string ThemeName { get; set; }
        public long? AssetId { get; set; }
        public long? ClusterId { get; set; }
        public long? AreaId { get; set; }
        public long? ApplicationId { get; set; }
        public long? ThemeId { get; set; }
        public long? SubthemeId { get; set; }
        public string SubthemeName { get; set; }
        public string UctFp { get; set; }
        public long? MaturityId { get; set; }
        public string MaturityLevelName { get; set; }
    }
}
