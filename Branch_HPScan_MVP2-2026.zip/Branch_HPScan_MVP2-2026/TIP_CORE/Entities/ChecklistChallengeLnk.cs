﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChecklistChallengeLnk
    {
        public long Id { get; set; }
        public long ChallengeId { get; set; }
        public long ChecklistId { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public string Yn { get; set; }

        public virtual ChallengeRegistration Challenge { get; set; }
        public virtual ChallengeChecklist Checklist { get; set; }
    }
}
