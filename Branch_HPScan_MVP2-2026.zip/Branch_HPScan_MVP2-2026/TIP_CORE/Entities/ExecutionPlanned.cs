﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ExecutionPlanned
    {
        public long Id { get; set; }
        public long? ExeId { get; set; }
        public long? Status { get; set; }
        public DateTime? SubmittedOn { get; set; }
        public DateTime? SentbackOn { get; set; }
        public DateTime? LastReminder { get; set; }
        public string UctFp { get; set; }
        public string SentbackBy { get; set; }
        public long? SubmitCount { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string Comments { get; set; }
        public string Reason { get; set; }
        public DateTime? ApprovedOn { get; set; }
        public string ApprovedBy { get; set; }

        public virtual TypeCodeMaster StatusNavigation { get; set; }
    }
}
