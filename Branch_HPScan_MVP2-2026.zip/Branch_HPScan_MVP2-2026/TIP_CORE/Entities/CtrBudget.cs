﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrBudget
    {
        public long CtrId { get; set; }
        public string Year { get; set; }
        public long? QId { get; set; }
        public string ResourceDescription { get; set; }
        public string BudgetProvider { get; set; }
        public string ItemProvider { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public decimal? Amount { get; set; }
        public long Id { get; set; }

        public virtual CtrInitiation Ctr { get; set; }
    }
}
