﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ExecutionActualplannedtimline
    {
        public ExecutionActualplannedtimline()
        {
            ExecutionInvoices = new HashSet<ExecutionInvoice>();
        }

        public long? PlannedTimelineId { get; set; }
        public long? StatusId { get; set; }
        public DateTime? Actualstartdate { get; set; }
        public DateTime? Actualendadate { get; set; }
        public decimal? Overallprogress { get; set; }
        public string Comments { get; set; }
        public string Invoicereviewedby { get; set; }
        public DateTime? Submittedon { get; set; }
        public long Id { get; set; }
        public long? Completion { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public long? EscCount { get; set; }
        public DateTime? LastReminder { get; set; }

        public virtual ICollection<ExecutionInvoice> ExecutionInvoices { get; set; }
    }
}
