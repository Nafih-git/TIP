﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ContractInitiation
    {
        public long Id { get; set; }
        public long? CtrId { get; set; }
        public string ContractHolder { get; set; }
        public string ContractOwner { get; set; }
        public string ContractEngineer { get; set; }
        public string HseAdvisor { get; set; }
    }
}
