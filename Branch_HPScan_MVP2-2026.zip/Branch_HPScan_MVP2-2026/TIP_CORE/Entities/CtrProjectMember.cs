﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrProjectMember
    {
        public long Id { get; set; }
        public long? CtrId { get; set; }
        public string Member { get; set; }
        public long? RoleId { get; set; }
        public bool? IsReadOnly { get; set; }

        public virtual CtrInitiation Ctr { get; set; }
        public virtual TmUserRole Role { get; set; }
    }
}
