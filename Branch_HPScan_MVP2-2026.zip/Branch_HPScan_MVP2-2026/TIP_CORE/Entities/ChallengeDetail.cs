﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengeDetail
    {
        public ChallengeDetail()
        {
            ChallengeSolutionReviewers = new HashSet<ChallengeSolutionReviewer>();
            ChallengeVendorScreenings = new HashSet<ChallengeVendorScreening>();
        }

        public long Id { get; set; }
        public long ChallengeId { get; set; }
        public string Title { get; set; }
        public string KeyRequirments { get; set; }
        public string CurrentPractices { get; set; }
        public string ValueDrivers { get; set; }
        public string OperatingEnvelopes { get; set; }
        public string TechnicalSpec { get; set; }
        public string PotentialScoreForecast { get; set; }
        public DateTime VendorSubmissionStartdate { get; set; }
        public DateTime ResponseLastdate { get; set; }
        public DateTime QueryLastdate { get; set; }
        public long MaturityLevelId { get; set; }
        public long AreaId { get; set; }
        public long ApplicationId { get; set; }
        public long ThemeId { get; set; }
        public long SubThemeId { get; set; }
        public string Cfdh { get; set; }
        public string ScoutingKeywords { get; set; }
        public long? Hserisk { get; set; }
        public long? Productionincrease { get; set; }
        public long? Costreduction { get; set; }
        public long? Co2reduction { get; set; }
        public long? Overallscore { get; set; }
        public long? Pillar { get; set; }
        public long? RequestType { get; set; }
        public long? AssetId { get; set; }
        public long? ClusterId { get; set; }
        public string ProblemStatement { get; set; }

        public virtual TypeCodeMaster Application { get; set; }
        public virtual TypeCodeMaster Area { get; set; }
        public virtual ChallengeRegistration Challenge { get; set; }
        public virtual TypeCodeMaster MaturityLevel { get; set; }
        public virtual TypeCodeMaster SubTheme { get; set; }
        public virtual TypeCodeMaster Theme { get; set; }
        public virtual ICollection<ChallengeSolutionReviewer> ChallengeSolutionReviewers { get; set; }
        public virtual ICollection<ChallengeVendorScreening> ChallengeVendorScreenings { get; set; }
    }
}
