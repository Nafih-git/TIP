﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ErrorLog
    {
        public long Id { get; set; }
        public string UserName { get; set; }
        public string IpAddress { get; set; }
        public string ActionName { get; set; }
        public string ControllerName { get; set; }
        public string ErrorMsg { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string ErrorId { get; set; }
    }
}
