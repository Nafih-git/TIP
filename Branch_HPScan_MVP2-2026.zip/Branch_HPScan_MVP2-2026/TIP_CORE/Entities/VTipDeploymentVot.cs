﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipDeploymentVot
    {
        public long? DepVotId { get; set; }
        public long? PirId { get; set; }
        public long? DepId { get; set; }
        public long? QYear { get; set; }
        public string QuerterYear { get; set; }
        public string TechName { get; set; }
        public string PirRef { get; set; }
        public long? UnitId { get; set; }
        public string UnitName { get; set; }
        public decimal? PlanCount { get; set; }
        public decimal? PlanVot { get; set; }
        public decimal? ActualCount { get; set; }
        public decimal? ActualVot { get; set; }
        public long? AssetId { get; set; }
        public string AssetName { get; set; }
        public long? ClusterId { get; set; }
        public string ClusterName { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public long? ThemeId { get; set; }
        public string ThemeName { get; set; }
        public long? SubthemeId { get; set; }
        public string SubthemeName { get; set; }
        public string UctFp { get; set; }
        public decimal? Ytd { get; set; }
        public DateTime? ActionDate { get; set; }
        public decimal? CummulativePlan { get; set; }
        public string MonthShown { get; set; }
        public long? MaturityId { get; set; }
        public string MaturityLevelName { get; set; }
    }
}
