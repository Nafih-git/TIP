﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpVendorScreeningAnswer
    {
        public int? Id { get; set; }
        public string Title { get; set; }
        public string Responsereference { get; set; }
        public string Publishedchallengesquestion { get; set; }
        public string Mandatory { get; set; }
        public string Submitteddate { get; set; }
        public int? TphAnswerid { get; set; }
        public int? TphResponseId { get; set; }
        public string Answer { get; set; }
    }
}
