﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TechnologyKpiConfig
    {
        public long Id { get; set; }
        public long StatusId { get; set; }
        public long? Year { get; set; }
        public long? MaxDays { get; set; }
    }
}
