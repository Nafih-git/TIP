﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrPercentageCompletion
    {
        public long Id { get; set; }
        public long CtrId { get; set; }
        public decimal Percentage { get; set; }
        public decimal EstPrice { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CrreatedByRef { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedByRef { get; set; }

        public virtual CtrInitiation Ctr { get; set; }
    }
}
