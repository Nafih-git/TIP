﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtrImpactedContract
    {
        public string Ctrrefnumber { get; set; }
        public byte? Serial { get; set; }
        public string Contractnumber { get; set; }
        public string Contracttitle { get; set; }
        public string Contractor { get; set; }
        public string Natureofimpact { get; set; }
    }
}
