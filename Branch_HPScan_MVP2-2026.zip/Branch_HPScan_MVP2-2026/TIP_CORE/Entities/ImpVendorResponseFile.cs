﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpVendorResponseFile
    {
        public string Title { get; set; }
        public string LiveLinkId { get; set; }
        public string LiveLinkUrl { get; set; }
        public string TphAttachmentId { get; set; }
        public string AttachmentType { get; set; }
        public string TphResponseid { get; set; }
        public string Responseid { get; set; }
        public string TphQueryid { get; set; }
        public string Queryid { get; set; }
        public string TphQueryAttachmentId { get; set; }
        public string Modified { get; set; }
        public string Attachmentpath { get; set; }
        public string Attachmentcategory { get; set; }
        public string Vendorqueryid { get; set; }
        public string Updatelivelinkurl { get; set; }
        public string Created { get; set; }
    }
}
