using System;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TrAuditLog
    {
        public decimal AUDIT_ID { get; set; }
        public string MODULE_NAME { get; set; }
        public string ACTION_TYPE { get; set; }
        public string ENTITY_TYPE { get; set; }
        public string ENTITY_ID { get; set; }
        public string ENTITY_NAME { get; set; }
        public string FIELD_NAME { get; set; }
        public string OLD_VALUE { get; set; }
        public string NEW_VALUE { get; set; }
        public string SUMMARY { get; set; }
        public string COMMENTS { get; set; }
        public string USER_ID { get; set; }
        public string USER_DISPLAY_NAME { get; set; }
        public decimal? ROLE_ID { get; set; }
        public string ROLE_NAME { get; set; }
        public string IP_ADDRESS { get; set; }
        public string CORRELATION_ID { get; set; }
        public string HTTP_METHOD { get; set; }
        public string REQUEST_PATH { get; set; }
        public DateTime? AUDIT_DATE { get; set; }
        public string OLD_JSON { get; set; }
        public string NEW_JSON { get; set; }
        public string REQUEST_JSON { get; set; }
        public string RESPONSE_JSON { get; set; }
    }
}
