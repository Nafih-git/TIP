﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PirInitiation
    {
        public PirInitiation()
        {
            DepInitiations = new HashSet<DepInitiation>();
            PirActionPlans = new HashSet<PirActionPlan>();
            PirApprovalListHsties = new HashSet<PirApprovalListHsty>();
            PirApprovalLists = new HashSet<PirApprovalList>();
            PirAssessmentTrialResults = new HashSet<PirAssessmentTrialResult>();
            PirDeploymentStaircases = new HashSet<PirDeploymentStaircase>();
            PirFlowHistories = new HashSet<PirFlowHistory>();
            PirImpactedExistingContracts = new HashSet<PirImpactedExistingContract>();
            PirLessonLearnts = new HashSet<PirLessonLearnt>();
            PirSummaries = new HashSet<PirSummary>();
            PirSupportingMembers = new HashSet<PirSupportingMember>();
            PirTrialCandidates = new HashSet<PirTrialCandidate>();
            PirTrialFps = new HashSet<PirTrialFp>();
            PirVots = new HashSet<PirVot>();
        }

        public long Id { get; set; }
        public long CtrId { get; set; }
        public string RefNo { get; set; }
        public string UctFp { get; set; }
        public DateTime? FirstTrialCommencementDate { get; set; }
        public DateTime? LastTrialConclutionDate { get; set; }
        public string AgentName { get; set; }
        public long? NoveltyId { get; set; }
        public long? AvailabilityId { get; set; }
        public string Source { get; set; }
        public bool? TrialCompleted { get; set; }
        public string DeploymentScope { get; set; }
        public string InterimDeploymentScope { get; set; }
        public string WellType { get; set; }
        public long StatusId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string CreatedByRef { get; set; }
        public string UpdatedByRef { get; set; }
        public long SubmitCount { get; set; }
        public long CurrentApprovalSeq { get; set; }
        public DateTime? SubmittedOn { get; set; }
        public DateTime? SentbackOn { get; set; }
        public string TechProviderName { get; set; }
        public string TrialType { get; set; }
        public string TrialledWells { get; set; }
        public DateTime? LastReminder { get; set; }
        public string SentbackBy { get; set; }
        public string ChallengesAddressed { get; set; }
        public string DsAssumptionMode { get; set; }
        public string DsComments { get; set; }

        public virtual TypeCodeMaster Novelty { get; set; }
        public virtual TypeCodeMaster Status { get; set; }
        public virtual ICollection<DepInitiation> DepInitiations { get; set; }
        public virtual ICollection<PirActionPlan> PirActionPlans { get; set; }
        public virtual ICollection<PirApprovalListHsty> PirApprovalListHsties { get; set; }
        public virtual ICollection<PirApprovalList> PirApprovalLists { get; set; }
        public virtual ICollection<PirAssessmentTrialResult> PirAssessmentTrialResults { get; set; }
        public virtual ICollection<PirDeploymentStaircase> PirDeploymentStaircases { get; set; }
        public virtual ICollection<PirFlowHistory> PirFlowHistories { get; set; }
        public virtual ICollection<PirImpactedExistingContract> PirImpactedExistingContracts { get; set; }
        public virtual ICollection<PirLessonLearnt> PirLessonLearnts { get; set; }
        public virtual ICollection<PirSummary> PirSummaries { get; set; }
        public virtual ICollection<PirSupportingMember> PirSupportingMembers { get; set; }
        public virtual ICollection<PirTrialCandidate> PirTrialCandidates { get; set; }
        public virtual ICollection<PirTrialFp> PirTrialFps { get; set; }
        public virtual ICollection<PirVot> PirVots { get; set; }
    }
}
