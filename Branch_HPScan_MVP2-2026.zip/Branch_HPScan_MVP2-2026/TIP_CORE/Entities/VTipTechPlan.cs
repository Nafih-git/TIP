﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipTechPlan
    {
        public long? ChallengeId { get; set; }
        public string ChallengeName { get; set; }
        public string ChaUctFp { get; set; }
        public string ChaRefNo { get; set; }
        public DateTime? ChallengeCreatedOn { get; set; }
        public long TechnologyBankId { get; set; }
        public string TechName { get; set; }
        public DateTime? TechCreatedOn { get; set; }
        public long? ResponseStatusId { get; set; }
        public long? CtrId { get; set; }
        public string CtrTrialName { get; set; }
        public string CtrRefNo { get; set; }
        public string CtrUctFp { get; set; }
        public DateTime? CtrCreatedOn { get; set; }
        public DateTime? TechnologyBankCreatedOn { get; set; }
        public long? ExeId { get; set; }
        public string ExeTrialName { get; set; }
        public DateTime? ExecutionCompletionDate { get; set; }
        public DateTime? ExecutionCreatedOn { get; set; }
        public string ExeUctFp { get; set; }
        public long? PirId { get; set; }
        public string PirRefNo { get; set; }
        public string PirUctFp { get; set; }
        public DateTime? PirCreatedOn { get; set; }
        public DateTime? DepCreatedOn { get; set; }
        public string DepUctFp { get; set; }
        public DateTime? CtrCompletionDate { get; set; }
        public DateTime? PirCompletionDate { get; set; }
        public DateTime? DepCompletionDate { get; set; }
        public long PhaseId { get; set; }
        public string PhaseName { get; set; }
        public string StageName { get; set; }
        public long StageId { get; set; }
        public long? ConfigDays { get; set; }
        public string StgCode { get; set; }
        public long? Sequence { get; set; }
        public DateTime? PlannedStartDate { get; set; }
        public DateTime? PlannedEndDate { get; set; }
        public DateTime? ActualStartDate { get; set; }
        public DateTime? ActualEndDate { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? ThemeId { get; set; }
        public string ThemeName { get; set; }
        public long? SubThemeId { get; set; }
        public string SubthemeName { get; set; }
        public long? ExecutionMaturityId { get; set; }
        public string ExecutionMaturityLevelName { get; set; }
        public long? ChallengeMaturityId { get; set; }
        public string ChallengeMaturityLevelName { get; set; }
        public long? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public long? AssetId { get; set; }
        public string AssetName { get; set; }
        public long? ClusterId { get; set; }
        public string ClusterName { get; set; }
        public DateTime? PoIssuingCreatedOn { get; set; }
        public DateTime? PoIssunigCompletionDate { get; set; }
        public decimal? IsCompletion { get; set; }
        public decimal? PlannedDiffDays { get; set; }
        public decimal? ActualDiffDays { get; set; }
    }
}
