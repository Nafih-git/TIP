﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ExecutionBudgetCostcenter
    {
        public long BudgetId { get; set; }
        public string BudgetProvider { get; set; }
        public string Year { get; set; }
        public decimal Total { get; set; }
        public long? CostCenter { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public long Id { get; set; }
    }
}
