﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengePublicationDetail
    {
        public long Id { get; set; }
        public decimal ChallengeRegid { get; set; }
        public DateTime? SubmissionStartdate { get; set; }
        public DateTime? SubmissionEnddate { get; set; }
        public DateTime? QueryEnddate { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
    }
}
