﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtrTask
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Ctrid { get; set; }
        public string Ctrrefno { get; set; }
        public string Approver { get; set; }
        public string Taskstatus { get; set; }
        public string Nextseq { get; set; }
        public string Tasktype { get; set; }
        public string Modified { get; set; }
        public string ModifiedBy { get; set; }
        public string Comments { get; set; }
    }
}
