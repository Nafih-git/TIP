﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class Configuration
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public long Id { get; set; }
        public string Category { get; set; }
    }
}
