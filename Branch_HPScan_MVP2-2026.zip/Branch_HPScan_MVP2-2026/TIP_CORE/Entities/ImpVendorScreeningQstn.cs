﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpVendorScreeningQstn
    {
        public string Tph { get; set; }
        public string Question { get; set; }
        public string Mandatory { get; set; }
        public string Isdeleted { get; set; }
        public string TphQuestionId { get; set; }
        public string TphChallengeId { get; set; }
        public string TphPublishedchallengeid { get; set; }
        public string Modified { get; set; }
    }
}
