﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpPirLessonlearnt
    {
        public short? Id { get; set; }
        public string Lessonlearnt { get; set; }
        public string Correctivemeasures { get; set; }
        public byte? Pirid { get; set; }
    }
}
