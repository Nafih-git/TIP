﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpTechSelection
    {
        public string Ctrrefnumber { get; set; }
        public string Title { get; set; }
        public string Maturitylevel { get; set; }
        public string Alternativesolutions { get; set; }
        public string Technologyname { get; set; }
        public string Id { get; set; }
        public string Modified { get; set; }
        public string Technologydescription { get; set; }
        public string Maturity { get; set; }
    }
}
