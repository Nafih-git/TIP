﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PdoToVendorQuery
    {
        public PdoToVendorQuery()
        {
            PdoToVendorQueryResponses = new HashSet<PdoToVendorQueryResponse>();
        }

        public long ResponseId { get; set; }
        public string Query { get; set; }
        public bool HasAttachment { get; set; }
        public bool? IsPublic { get; set; }
        public long Id { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }

        public virtual ChallengeResponse Response { get; set; }
        public virtual ICollection<PdoToVendorQueryResponse> PdoToVendorQueryResponses { get; set; }
    }
}
