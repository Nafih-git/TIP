﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class HseApendixA
    {
        public long Id { get; set; }
        public DateTime? HseDate { get; set; }
        public long? ProjectLocation { get; set; }
        public string ContractNumber { get; set; }
        public long? ContactMode { get; set; }
        public bool? BandingRequired { get; set; }
        public long? RiskCategory { get; set; }
        public string TypeOfC9 { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string CreatedbyRef { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedbyRef { get; set; }
    }
}
