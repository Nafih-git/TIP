﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpTphTask
    {
        public string Responsereference { get; set; }
        public string Responseid { get; set; }
        public string CreatedBy { get; set; }
        public string Approvedby { get; set; }
        public string Taskstatus { get; set; }
        public string Created { get; set; }
        public string Modified { get; set; }
        public string Nextreminderdate { get; set; }
        public string Expirydate { get; set; }
        public string Assignedby { get; set; }
        public string Comments { get; set; }
        public string ApprovedbyMu { get; set; }
    }
}
