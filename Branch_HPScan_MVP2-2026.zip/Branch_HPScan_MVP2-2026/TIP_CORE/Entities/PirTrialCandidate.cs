﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PirTrialCandidate
    {
        public long Id { get; set; }
        public long TypeId { get; set; }
        public string Name { get; set; }
        public decimal Cost { get; set; }
        public DateTime? CommencementDate { get; set; }
        public DateTime? ConclusionDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedByRef { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedByRef { get; set; }
        public long PirId { get; set; }
        public string ChallengeDescription { get; set; }
        public string Comments { get; set; }

        public virtual PirInitiation Pir { get; set; }
        public virtual TypeCodeMaster Type { get; set; }
    }
}
