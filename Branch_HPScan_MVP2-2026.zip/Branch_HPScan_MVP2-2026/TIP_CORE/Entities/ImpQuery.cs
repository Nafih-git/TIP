﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpQuery
    {
        public string QueryId { get; set; }
        public string ChallengeId { get; set; }
        public string StatusId { get; set; }
        public string QueryText { get; set; }
        public string QueryAnswer { get; set; }
        public string RefId { get; set; }
        public string VendorId { get; set; }
        public string QueryDate { get; set; }
        public string ReplyDate { get; set; }
        public string QuestionId { get; set; }
    }
}
