﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtrSuccessCriterion
    {
        public string Ctrrefnumber { get; set; }
        public byte? Serial { get; set; }
        public string Parameter { get; set; }
        public string Currentvalue { get; set; }
        public string Trialtarget { get; set; }
        public string Parameterevaluationmethod { get; set; }
        public string Parameterevaluationfrequency { get; set; }
        public string Decisiongateimpacted { get; set; }
        public string Active { get; set; }
    }
}
