﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrActualPlanDetail
    {
        public long Id { get; set; }
        public string Phase { get; set; }
        public string Stage { get; set; }
        public long? Planneddays { get; set; }
        public long? Sequence { get; set; }
        public DateTime? Actualstartdate { get; set; }
        public DateTime? Actualenddate { get; set; }
        public long? CtrId { get; set; }
        public long? PlanId { get; set; }
        public DateTime? ForecastedStDate { get; set; }
        public DateTime? ForecastedEdDate { get; set; }
        public long? Completion { get; set; }
        public long? OverallProgressId { get; set; }
        public string Comments { get; set; }
        public long? StatusId { get; set; }
        public long? PhaseId { get; set; }
        public long? StageId { get; set; }
        public long? TemplateId { get; set; }

        public virtual TypeCodeMaster PhaseNavigation { get; set; }
        public virtual TypeCodeMaster StageNavigation { get; set; }
        public virtual TypeCodeMaster Template { get; set; }
    }
}
