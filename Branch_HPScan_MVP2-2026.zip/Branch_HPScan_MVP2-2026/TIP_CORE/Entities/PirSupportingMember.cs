﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PirSupportingMember
    {
        public long Id { get; set; }
        public long PirId { get; set; }
        public string Fp { get; set; }
        public string RefId { get; set; }
        public string JobTitle { get; set; }

        public virtual PirInitiation Pir { get; set; }
    }
}
