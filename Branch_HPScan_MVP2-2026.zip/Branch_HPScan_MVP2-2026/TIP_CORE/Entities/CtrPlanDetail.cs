﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrPlanDetail
    {
        public long Id { get; set; }
        public string Phase { get; set; }
        public string Stage { get; set; }
        public long? Planneddays { get; set; }
        public long? Sequence { get; set; }
        public DateTime? Startdate { get; set; }
        public DateTime? Enddate { get; set; }
        public long? PhaseId { get; set; }
        public long CtrId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string CreatedByRef { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedByRef { get; set; }
        public long? Statusid { get; set; }
        public long? StageId { get; set; }
        public long? TemplateId { get; set; }
        public string Year { get; set; }

        public virtual CtrInitiation Ctr { get; set; }
        public virtual TypeCodeMaster PhaseNavigation { get; set; }
        public virtual TypeCodeMaster StageNavigation { get; set; }
        public virtual TypeCodeMaster Template { get; set; }
    }
}
