﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PirDeploymentStaircase
    {
        public long Id { get; set; }
        public long PirId { get; set; }
        public string FeildStationName { get; set; }
        public string WellType { get; set; }
        public long Year { get; set; }
        public long NoOfWells { get; set; }
        public decimal EstimatedVot { get; set; }
        public string AssumptionMode { get; set; }
        public string Comments { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual PirInitiation Pir { get; set; }
    }
}
