﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipPhaseMaturation
    {
        public long TechId { get; set; }
        public string UctFp { get; set; }
        public string TechTitle { get; set; }
        public string CtrTrialName { get; set; }
        public DateTime? PreTtaStartDate { get; set; }
        public DateTime? CtrStartDate { get; set; }
        public DateTime? CtrCompletionDate { get; set; }
        public DateTime? PoStartDate { get; set; }
        public DateTime? PoCompletionDate { get; set; }
        public DateTime? ExecutionStartDate { get; set; }
        public DateTime? ExecutionCompletionDate { get; set; }
        public DateTime? PirStartDate { get; set; }
        public DateTime? PirCompletionDate { get; set; }
        public DateTime? DeploymentStartDate { get; set; }
        public DateTime? DeploymentCompletionDate { get; set; }
        public string PreTtaPhaseName { get; set; }
        public decimal? PreTtaDays { get; set; }
        public decimal? PreTtaConfigDays { get; set; }
        public string TtaPhaseName { get; set; }
        public decimal? TtaDays { get; set; }
        public decimal? TtaConfigDays { get; set; }
        public string IpPhaseName { get; set; }
        public decimal? IpDays { get; set; }
        public decimal? IpConfigDays { get; set; }
        public string ExecutionPhaseName { get; set; }
        public decimal? ExecutionDays { get; set; }
        public decimal? ExecutionConfigDays { get; set; }
        public string PirPhaseName { get; set; }
        public decimal? PirDays { get; set; }
        public decimal? PirConfigDays { get; set; }
        public string DeploymentPhaseName { get; set; }
        public decimal? DeploymentDays { get; set; }
        public decimal? DeploymentConfigDays { get; set; }
        public long? AssetId { get; set; }
        public string AssetName { get; set; }
        public long? ClusterId { get; set; }
        public string ClusterName { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public long? ThemeId { get; set; }
        public string ThemeName { get; set; }
        public long? SubthemeId { get; set; }
        public string SubthemeName { get; set; }
        public long? MaturityId { get; set; }
        public string MaturityLevelName { get; set; }
    }
}
