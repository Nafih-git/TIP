﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpChallenge
    {
        public string Id { get; set; }
        public string Challengereferenceno { get; set; }
        public string Theme { get; set; }
        public string Subtheme { get; set; }
        public string Challengestatus { get; set; }
        public string Application { get; set; }
        public string Focalpoint { get; set; }
        public string Challengearea { get; set; }
        public string Challengetitle { get; set; }
        public string Jobtitle { get; set; }
        public string Maturitylevel { get; set; }
        public string Hserisk { get; set; }
        public string Productionreserves { get; set; }
        public string Costreduction { get; set; }
        public string Rankingimpactscore { get; set; }
        public string Submitdate { get; set; }
        public string Title { get; set; }
        public string TphChallengeDimension { get; set; }
        public string TphChallengeId { get; set; }
        public string Created { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public string StatusId { get; set; }
        public string UpdatedRoleId { get; set; }
        public string CreatedRoleId { get; set; }
        public string ProblemStatement { get; set; }
        public string ApplicationId { get; set; }
        public string ThemeId { get; set; }
        public string SubthemeId { get; set; }
        public string MaturityLevelId { get; set; }
    }
}
