﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PirImpactedExistingContract
    {
        public long Id { get; set; }
        public long PirId { get; set; }
        public string ContractNo { get; set; }
        public string ContractTitle { get; set; }
        public string Contractor { get; set; }
        public string Impact { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual PirInitiation Pir { get; set; }
    }
}
