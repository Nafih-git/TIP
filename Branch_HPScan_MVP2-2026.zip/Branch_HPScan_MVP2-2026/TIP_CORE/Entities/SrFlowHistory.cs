﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class SrFlowHistory
    {
        public long ResponseId { get; set; }
        public long StatusId { get; set; }
        public string Comments { get; set; }
        public long? RoleId { get; set; }
        public string UserId { get; set; }
        public string DescInfo { get; set; }
        public DateTime CreatedOn { get; set; }
        public long Id { get; set; }
        public bool? IsExternal { get; set; }
        public long? ExternalUserId { get; set; }
    }
}
