﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TaskRepo
    {
        public long Id { get; set; }
        public string Link { get; set; }
        public long LinkId { get; set; }
        public string Type { get; set; }
        public string ActionBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string DelegatedFrom { get; set; }
        public bool IsDelegated { get; set; }
        public bool IsCompleted { get; set; }
        public string ActionFrom { get; set; }
    }
}
