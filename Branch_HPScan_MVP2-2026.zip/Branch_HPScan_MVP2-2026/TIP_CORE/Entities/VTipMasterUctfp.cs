﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipMasterUctfp
    {
        public string EmployeeName { get; set; }
        public string ReferenceIndicator { get; set; }
        public string MuNumber { get; set; }
        public string EmploymentStatus { get; set; }
    }
}
