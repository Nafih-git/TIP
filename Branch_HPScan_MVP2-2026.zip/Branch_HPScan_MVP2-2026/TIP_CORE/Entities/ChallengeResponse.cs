﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengeResponse
    {
        public ChallengeResponse()
        {
            ChallengeResponseQuestions = new HashSet<ChallengeResponseQuestion>();
            ChallengeResponseReviews = new HashSet<ChallengeResponseReview>();
            ChallengeResponseSrs = new HashSet<ChallengeResponseSr>();
            PdoToVendorQueries = new HashSet<PdoToVendorQuery>();
            TechnologyBanks = new HashSet<TechnologyBank>();
            VendorToChrQueries = new HashSet<VendorToChrQuery>();
        }

        public long ChallengeRegistrationId { get; set; }
        public string ResReferenceNo { get; set; }
        public string TechnologyName { get; set; }
        public long? SourceId { get; set; }
        public long Id { get; set; }
        public DateTime? CreatedOn { get; set; }
        public long CreatedBy { get; set; }
        public string UpdatedRole { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public bool? IsConfirm { get; set; }
        public long? StatusId { get; set; }
        public long? CompanyId { get; set; }
        public bool? IsCr { get; set; }
        public long? Complexity { get; set; }
        public long? Impact { get; set; }
        public long? DecisionId { get; set; }
        public DateTime? LastReminder { get; set; }
        public long? EscCount { get; set; }
        public string TechnologyDescription { get; set; }
        public string StatusComment { get; set; }

        public virtual ChallengeRegistration ChallengeRegistration { get; set; }
        public virtual ExternalUser CreatedByNavigation { get; set; }
        public virtual TypeCodeMaster Source { get; set; }
        public virtual TypeCodeMaster Status { get; set; }
        public virtual ICollection<ChallengeResponseQuestion> ChallengeResponseQuestions { get; set; }
        public virtual ICollection<ChallengeResponseReview> ChallengeResponseReviews { get; set; }
        public virtual ICollection<ChallengeResponseSr> ChallengeResponseSrs { get; set; }
        public virtual ICollection<PdoToVendorQuery> PdoToVendorQueries { get; set; }
        public virtual ICollection<TechnologyBank> TechnologyBanks { get; set; }
        public virtual ICollection<VendorToChrQuery> VendorToChrQueries { get; set; }
    }
}
