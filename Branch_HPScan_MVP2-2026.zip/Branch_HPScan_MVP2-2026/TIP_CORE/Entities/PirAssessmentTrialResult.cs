﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PirAssessmentTrialResult
    {
        public long Id { get; set; }
        public string Parameter { get; set; }
        public string Target { get; set; }
        public long ConclusionId { get; set; }
        public string Comments { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedByRef { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedByRef { get; set; }
        public long PirId { get; set; }

        public virtual TypeCodeMaster Conclusion { get; set; }
        public virtual PirInitiation Pir { get; set; }
    }
}
