﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VendorToChrQueryResponse
    {
        public long Id { get; set; }
        public long QueryId { get; set; }
        public bool HasAttachment { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string Response { get; set; }

        public virtual VendorToChrQuery Query { get; set; }
    }
}
