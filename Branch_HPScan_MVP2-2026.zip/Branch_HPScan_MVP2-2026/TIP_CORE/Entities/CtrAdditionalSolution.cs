﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrAdditionalSolution
    {
        public long Id { get; set; }
        public long CtrId { get; set; }
        public string SerialNumber { get; set; }
        public string SolutionTitle { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedByRef { get; set; }
        public string Remarks { get; set; }

        public virtual CtrInitiation Ctr { get; set; }
    }
}
