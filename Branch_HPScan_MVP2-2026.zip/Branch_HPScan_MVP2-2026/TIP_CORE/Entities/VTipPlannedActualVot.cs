﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipPlannedActualVot
    {
        public long PirId { get; set; }
        public string RefNo { get; set; }
        public decimal? Co2ReductnUnitYr { get; set; }
        public decimal? PowerSavingUnitYr { get; set; }
        public decimal? CostSavingUnitYr { get; set; }
        public decimal? TotOilDefermentAvoidance { get; set; }
        public decimal? AvgIncrmntlOilGain { get; set; }
        public DateTime? PirSubmittedDate { get; set; }
        public string QY { get; set; }
        public decimal? Co2Reduction { get; set; }
        public decimal? PowerSaving { get; set; }
        public decimal? CostSavingUnitQtr { get; set; }
        public decimal? DefermentAvoidance { get; set; }
        public decimal? IncrmntlOilGain { get; set; }
        public DateTime? DepSubmittedDate { get; set; }
        public long? AssetId { get; set; }
        public string AssetName { get; set; }
        public long? ClusterId { get; set; }
        public string ClusterName { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public long? ThemeId { get; set; }
        public string ThemeName { get; set; }
        public long? SubthemeId { get; set; }
        public string SubthemeName { get; set; }
        public string UctFp { get; set; }
        public long? MaturityId { get; set; }
        public string MaturityLevelName { get; set; }
        public string Title { get; set; }
    }
}
