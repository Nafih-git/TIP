﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengeResponseSr
    {
        public long ChallengeResponseId { get; set; }
        public string ResReferenceNo { get; set; }
        public string TechnologyName { get; set; }
        public string TechnologyDescription { get; set; }
        public long? SourceId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public long? StatusId { get; set; }
        public long? CompanyId { get; set; }
        public long Id { get; set; }
        public long? ChallengeRegistrationId { get; set; }

        public virtual ChallengeRegistration ChallengeRegistration { get; set; }
        public virtual ChallengeResponse ChallengeResponse { get; set; }
        public virtual TypeCodeMaster Source { get; set; }
        public virtual TypeCodeMaster Status { get; set; }
    }
}
