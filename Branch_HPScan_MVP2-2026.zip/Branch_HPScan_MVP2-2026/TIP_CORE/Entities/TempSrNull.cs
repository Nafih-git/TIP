﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TempSrNull
    {
        public string EmployeeName { get; set; }
        public string Approvedby { get; set; }
    }
}
