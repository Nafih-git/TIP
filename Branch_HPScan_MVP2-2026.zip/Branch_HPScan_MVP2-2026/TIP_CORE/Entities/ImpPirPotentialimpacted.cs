﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpPirPotentialimpacted
    {
        public string Title { get; set; }
        public string Contractno { get; set; }
        public string Contracttitle { get; set; }
        public string Contractor { get; set; }
        public string Natureofimpact { get; set; }
        public int? Pirid { get; set; }
    }
}
