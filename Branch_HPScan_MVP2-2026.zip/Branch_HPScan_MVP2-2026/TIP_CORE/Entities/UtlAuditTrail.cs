﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class UtlAuditTrail
    {
        public decimal Id { get; set; }
        public string TableName { get; set; }
        public string Action { get; set; }
        public string ActionBy { get; set; }
        public string ActionOn { get; set; }
        public string Description { get; set; }
        public long? RowPid { get; set; }
    }
}
