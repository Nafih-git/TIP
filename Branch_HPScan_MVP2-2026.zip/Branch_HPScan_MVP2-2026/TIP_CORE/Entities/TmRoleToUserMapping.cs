﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TmRoleToUserMapping
    {
        public decimal MapingId { get; set; }
        public string UserId { get; set; }
        public decimal? RoleId { get; set; }
        public decimal IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public long? DefaultRoleId { get; set; }
    }
}
