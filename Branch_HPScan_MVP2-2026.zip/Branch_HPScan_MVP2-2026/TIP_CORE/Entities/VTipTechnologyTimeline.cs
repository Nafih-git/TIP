﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipTechnologyTimeline
    {
        public string Title { get; set; }
        public string PhaseName { get; set; }
        public string StageName { get; set; }
        public decimal? PlannedDays { get; set; }
        public DateTime? PlanStartDate { get; set; }
        public DateTime? PlanEndDate { get; set; }
        public decimal? ActualDays { get; set; }
        public DateTime? ActualStartDate { get; set; }
        public DateTime? ActualEndDate { get; set; }
        public long? AssetId { get; set; }
        public string AssetName { get; set; }
        public long? ClusterId { get; set; }
        public string ClusterName { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public long? ThemeId { get; set; }
        public string ThemeName { get; set; }
        public long? SubthemeId { get; set; }
        public string SubthemeName { get; set; }
        public string UctFp { get; set; }
        public long? MaturityId { get; set; }
        public string MaturityLevelName { get; set; }
        public long? Sequence { get; set; }
        public long TechId { get; set; }
        public long? CtrId { get; set; }
    }
}
