﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrDeploymentStaircase
    {
        public long Id { get; set; }
        public long? Year { get; set; }
        public long? Noofwells { get; set; }
        public decimal? Estimatedvot { get; set; }
        public string Station { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public long CtrId { get; set; }

        public virtual CtrInitiation Ctr { get; set; }
    }
}
