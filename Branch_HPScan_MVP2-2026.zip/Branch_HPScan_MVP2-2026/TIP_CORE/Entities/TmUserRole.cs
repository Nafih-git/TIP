﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TmUserRole
    {
        public TmUserRole()
        {
            CtrFlowHistories = new HashSet<CtrFlowHistory>();
            CtrProjectMembers = new HashSet<CtrProjectMember>();
            ExeFlowHistories = new HashSet<ExeFlowHistory>();
            ExeInvoiceFlowHistories = new HashSet<ExeInvoiceFlowHistory>();
            PirFlowHistories = new HashSet<PirFlowHistory>();
            TmRoleToMenuMappings = new HashSet<TmRoleToMenuMapping>();
        }

        public long RoleId { get; set; }
        public string Code { get; set; }
        public string RoleName { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string Param { get; set; }

        public virtual ICollection<CtrFlowHistory> CtrFlowHistories { get; set; }
        public virtual ICollection<CtrProjectMember> CtrProjectMembers { get; set; }
        public virtual ICollection<ExeFlowHistory> ExeFlowHistories { get; set; }
        public virtual ICollection<ExeInvoiceFlowHistory> ExeInvoiceFlowHistories { get; set; }
        public virtual ICollection<PirFlowHistory> PirFlowHistories { get; set; }
        public virtual ICollection<TmRoleToMenuMapping> TmRoleToMenuMappings { get; set; }
    }
}
