﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtrApproval
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Ctrid { get; set; }
        public string Approversequence { get; set; }
        public string Approvedby { get; set; }
        public string Isdeleted { get; set; }
        public string Approvertype { get; set; }
        public string Modified { get; set; }
        public string Approvedon { get; set; }
        public string CreatedBy { get; set; }
        public string Isapproved { get; set; }
    }
}
