﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengeVendorScreening
    {
        public ChallengeVendorScreening()
        {
            ChallengeResponseQuestions = new HashSet<ChallengeResponseQuestion>();
        }

        public long Id { get; set; }
        public long ChallengeId { get; set; }
        public long ChallengeDetailId { get; set; }
        public long Sequence { get; set; }
        public string Question { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }

        public virtual ChallengeRegistration Challenge { get; set; }
        public virtual ChallengeDetail ChallengeDetail { get; set; }
        public virtual ICollection<ChallengeResponseQuestion> ChallengeResponseQuestions { get; set; }
    }
}
