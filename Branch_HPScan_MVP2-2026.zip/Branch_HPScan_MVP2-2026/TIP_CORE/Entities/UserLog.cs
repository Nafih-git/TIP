﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class UserLog
    {
        public long Id { get; set; }
        public long Userid { get; set; }
        public string IpAddress { get; set; }
        public string Action { get; set; }
        public DateTime LogDate { get; set; }
    }
}
