﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpPirHistory
    {
        public string Id { get; set; }
        public string Modified { get; set; }
        public string Title { get; set; }
        public string Pirid { get; set; }
        public string Pirrefno { get; set; }
        public string Taskdescription { get; set; }
        public string Approver { get; set; }
        public string Reassignapprover { get; set; }
        public string Taskstatus { get; set; }
        public string Tasktype { get; set; }
        public string Nextseq { get; set; }
        public string Submittedby { get; set; }
        public string RoleName { get; set; }
        public string StatusName { get; set; }
    }
}
