﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipTechnologyPlan
    {
        public long? CtrId { get; set; }
        public long? TechId { get; set; }
        public string Title { get; set; }
        public long? PhaseId { get; set; }
        public string PhaseName { get; set; }
        public long? StageId { get; set; }
        public string StageName { get; set; }
        public long? Planneddays { get; set; }
        public DateTime? Plannedstartdate { get; set; }
        public DateTime? Plannedenddate { get; set; }
        public DateTime? Actualstartdate { get; set; }
        public DateTime? Actualenddate { get; set; }
        public decimal? Actualdiff { get; set; }
        public decimal? Completion { get; set; }
        public long? Sequence { get; set; }
    }
}
