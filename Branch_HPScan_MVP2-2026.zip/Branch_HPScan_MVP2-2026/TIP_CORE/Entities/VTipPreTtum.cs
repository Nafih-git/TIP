﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipPreTtum
    {
        public DateTime? ActionDate { get; set; }
        public string ReferenceNo { get; set; }
        public string Title { get; set; }
        public DateTime? ChallengeActionDate { get; set; }
        public string Status { get; set; }
        public string CtrRefNo { get; set; }
        public DateTime? CtrActionDate { get; set; }
        public string PirRefNo { get; set; }
        public DateTime? PirActionDate { get; set; }
        public DateTime? ExecutionActionDate { get; set; }
        public DateTime? DeploymentActionDate { get; set; }
        public long? AssetId { get; set; }
        public string AssetName { get; set; }
        public long? ClusterId { get; set; }
        public string ClusterName { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public long? ThemeId { get; set; }
        public string ThemeName { get; set; }
        public long? SubthemeId { get; set; }
        public string SubthemeName { get; set; }
        public string UctFp { get; set; }
        public long? MaturityId { get; set; }
        public string MaturityLevelName { get; set; }
    }
}
