﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrTrialFp
    {
        public long Id { get; set; }
        public long CtrId { get; set; }
        public string Fp { get; set; }
        public bool? IsMandatory { get; set; }

        public virtual CtrInitiation Ctr { get; set; }
    }
}
