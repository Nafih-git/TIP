﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengeSolutionReviewer
    {
        public long Id { get; set; }
        public string Reviewer { get; set; }
        public long ChallengeId { get; set; }
        public long ChallengeDetailId { get; set; }
        public bool? IsReviewed { get; set; }

        public virtual ChallengeRegistration Challenge { get; set; }
        public virtual ChallengeDetail ChallengeDetail { get; set; }
    }
}
