﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ExternalUser
    {
        public ExternalUser()
        {
            ChallengeResponses = new HashSet<ChallengeResponse>();
        }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }
        public string PhoneNumber { get; set; }
        public string CompanyName { get; set; }
        public string Description { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public bool? IsActive { get; set; }
        public DateTime? LastLogin { get; set; }
        public long? OtpCode { get; set; }
        public DateTime? OtpTime { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public long? SourceId { get; set; }
        public long Id { get; set; }
        public string UserCategory { get; set; }
        public string Type { get; set; }
        public string Representation { get; set; }
        public string Manufacturername { get; set; }
        public string Countryorign { get; set; }
        public string CommercialregNo { get; set; }
        public DateTime? CommercialregExpDate { get; set; }
        public string Address { get; set; }
        public string Companywebsite { get; set; }
        public string Contactperson { get; set; }
        public string ContPerPhoneNumber { get; set; }
        public string Cpb { get; set; }
        public decimal? Attempts { get; set; }
        public DateTime? LastReminderDate { get; set; }

        public virtual ICollection<ChallengeResponse> ChallengeResponses { get; set; }
    }
}
