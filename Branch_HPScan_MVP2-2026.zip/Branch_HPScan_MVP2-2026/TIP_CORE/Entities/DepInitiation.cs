﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class DepInitiation
    {
        public DepInitiation()
        {
            DepVots = new HashSet<DepVot>();
        }

        public long PirId { get; set; }
        public string Uctfp { get; set; }
        public string Chfp { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public long Id { get; set; }

        public virtual PirInitiation Pir { get; set; }
        public virtual ICollection<DepVot> DepVots { get; set; }
    }
}
