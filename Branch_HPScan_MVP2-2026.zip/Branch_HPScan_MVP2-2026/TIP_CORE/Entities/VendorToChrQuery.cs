﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VendorToChrQuery
    {
        public VendorToChrQuery()
        {
            VendorToChrQueryResponses = new HashSet<VendorToChrQueryResponse>();
        }

        public long Id { get; set; }
        public long ResponseId { get; set; }
        public string Query { get; set; }
        public bool HasAttachment { get; set; }
        public bool? IsPublic { get; set; }
        public DateTime CreatedOn { get; set; }
        public bool? IsRead { get; set; }

        public virtual ChallengeResponse Response { get; set; }
        public virtual ICollection<VendorToChrQueryResponse> VendorToChrQueryResponses { get; set; }
    }
}
