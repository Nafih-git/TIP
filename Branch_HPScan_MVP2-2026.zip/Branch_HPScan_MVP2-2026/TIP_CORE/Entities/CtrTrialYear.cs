﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrTrialYear
    {
        public long TrialId { get; set; }
        public long? Year { get; set; }
        public bool? Q1 { get; set; }
        public bool? Q2 { get; set; }
        public bool? Q3 { get; set; }
        public bool? Q4 { get; set; }
        public long Id { get; set; }

        public virtual CtrTrial Trial { get; set; }
    }
}
