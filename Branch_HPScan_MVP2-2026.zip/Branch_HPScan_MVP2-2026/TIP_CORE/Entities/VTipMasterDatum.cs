﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipMasterDatum
    {
        public long? Id { get; set; }
        public string Name { get; set; }
        public decimal? TypeId { get; set; }
        public long? ParentId { get; set; }
        public string TypeName { get; set; }
    }
}
