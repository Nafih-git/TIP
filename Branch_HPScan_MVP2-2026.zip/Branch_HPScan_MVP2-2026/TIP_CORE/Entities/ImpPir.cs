﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpPir
    {
        public string Id { get; set; }
        public string Pirreferenceno { get; set; }
        public string CreatedBy { get; set; }
        public string Pirstatus { get; set; }
        public string Trialname { get; set; }
        public string Trialresult { get; set; }
        public string Isfocalpointassigned { get; set; }
        public string Trialfocalpoint1 { get; set; }
        public string Trialfocalpoint2 { get; set; }
        public string Supportingteammembers { get; set; }
        public string Staircaseyear1 { get; set; }
        public string Staircaseyear2 { get; set; }
        public string Staircaseyear3 { get; set; }
        public string Staircaseyear4 { get; set; }
        public string Staircaseyear5 { get; set; }
        public string Staircaseyear6 { get; set; }
        public string Trailconclusiondate { get; set; }
        public string Trialcommencementdate { get; set; }
        public string Trialyear { get; set; }
        public string Modified { get; set; }
        public string Agentname { get; set; }
        public string Application { get; set; }
        public string Availability { get; set; }
        public string Ctrreferenceno { get; set; }
        public string Deployment { get; set; }
        public string Descriptionofchallenge { get; set; }
        public string Title { get; set; }
        public string Trialedwells { get; set; }
        public string Trialfocalpoint3 { get; set; }
        public string Trialfocalpoint4 { get; set; }
        public string Trialfocalpoint5 { get; set; }
        public string Novelty { get; set; }
        public string Tfpoint { get; set; }
        public string Conclusionsummary { get; set; }
        public string Challengeaddress { get; set; }
        public string TrialType { get; set; }
    }
}
