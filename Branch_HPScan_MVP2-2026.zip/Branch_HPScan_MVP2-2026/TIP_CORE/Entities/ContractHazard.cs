﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ContractHazard
    {
        public decimal Id { get; set; }
        public long? CtrId { get; set; }
        public long? HazardId { get; set; }
    }
}
