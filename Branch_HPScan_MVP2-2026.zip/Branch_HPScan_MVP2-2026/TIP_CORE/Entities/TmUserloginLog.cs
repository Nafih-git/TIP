﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TmUserloginLog
    {
        public long? UserId { get; set; }
        public DateTime? Logindatetime { get; set; }
        public string Status { get; set; }
        public long Id { get; set; }
    }
}
