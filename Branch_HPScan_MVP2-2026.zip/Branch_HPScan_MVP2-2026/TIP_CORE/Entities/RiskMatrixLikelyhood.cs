﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class RiskMatrixLikelyhood
    {
        public decimal Id { get; set; }
        public long? Severity { get; set; }
        public long? Likelyhood { get; set; }
        public string Risk { get; set; }
    }
}
