﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipFunnelSummary
    {
        public string Title { get; set; }
        public decimal? OilGain { get; set; }
        public decimal? DefermentAvoidance { get; set; }
        public decimal? CostSaving { get; set; }
        public decimal? PowerSaving { get; set; }
        public decimal? Co2Reduction { get; set; }
        public decimal? TotalVot { get; set; }
        public long? AssetId { get; set; }
        public string AssetName { get; set; }
        public long? ClusterId { get; set; }
        public string ClusterName { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public long? ThemeId { get; set; }
        public string ThemeName { get; set; }
        public long? SubThemeId { get; set; }
        public string SubTheme { get; set; }
        public string HeaderColumn { get; set; }
        public string UctFp { get; set; }
        public string Keyword { get; set; }
        public long? MaturityId { get; set; }
        public string MaturityLevelName { get; set; }
        public DateTime? ActionDate { get; set; }
    }
}
