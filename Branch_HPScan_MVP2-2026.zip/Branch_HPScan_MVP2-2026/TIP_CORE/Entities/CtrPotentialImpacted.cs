﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrPotentialImpacted
    {
        public long CtrId { get; set; }
        public long Id { get; set; }
        public string ContractNo { get; set; }
        public string ContractTitle { get; set; }
        public string Contractor { get; set; }
        public string Impact { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }

        public virtual CtrInitiation Ctr { get; set; }
    }
}
