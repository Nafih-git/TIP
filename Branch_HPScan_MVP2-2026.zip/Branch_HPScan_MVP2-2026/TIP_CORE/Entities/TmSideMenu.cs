﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TmSideMenu
    {
        public TmSideMenu()
        {
            TmRoleToMenuMappings = new HashSet<TmRoleToMenuMapping>();
        }

        public decimal MenuId { get; set; }
        public decimal? ParentMenuId { get; set; }
        public string MenuName { get; set; }
        public string MenuUrl { get; set; }
        public string IconClassName { get; set; }

        public virtual ICollection<TmRoleToMenuMapping> TmRoleToMenuMappings { get; set; }
    }
}
