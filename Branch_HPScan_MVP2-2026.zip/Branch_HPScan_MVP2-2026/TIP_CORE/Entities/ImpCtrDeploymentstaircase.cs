﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtrDeploymentstaircase
    {
        public string Ctrrefnumber { get; set; }
        public string Title { get; set; }
        public int? Year1wells { get; set; }
        public decimal? Year1vot { get; set; }
        public int? Year2wells { get; set; }
        public decimal? Year2vot { get; set; }
        public int? Year3wells { get; set; }
        public decimal? Year3vot { get; set; }
        public int? Year4wells { get; set; }
        public decimal? Year4vot { get; set; }
        public int? Year5wells { get; set; }
        public decimal? Year5vot { get; set; }
        public short? Year6wells { get; set; }
        public decimal? Year6vot { get; set; }
        public int? Year1 { get; set; }
        public int? Year2 { get; set; }
        public int? Year3 { get; set; }
        public int? Year4 { get; set; }
        public int? Year5 { get; set; }
        public int? Year6 { get; set; }
    }
}
