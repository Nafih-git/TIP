﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ExecutionPotentialValue
    {
        public long? Year { get; set; }
        public long? Noofwells { get; set; }
        public decimal? Value { get; set; }
        public string Station { get; set; }
        public long? ExecId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public long Id { get; set; }

        public virtual ExecutionInitiation Exec { get; set; }
    }
}
