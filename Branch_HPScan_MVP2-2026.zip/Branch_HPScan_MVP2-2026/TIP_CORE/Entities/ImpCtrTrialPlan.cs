﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtrTrialPlan
    {
        public string Ctrrefnumber { get; set; }
        public string Title { get; set; }
        public decimal? Sequence { get; set; }
        public string Deliverabletollgatedecision { get; set; }
        public string Deliverydecisionby { get; set; }
        public string Remarks { get; set; }
        public string Y1q1 { get; set; }
        public string Y1q2 { get; set; }
        public string Y1q3 { get; set; }
        public string Y1q4 { get; set; }
        public string Y2q1 { get; set; }
        public string Y2q2 { get; set; }
        public string Y2q3 { get; set; }
        public string Y2q4 { get; set; }
        public string Y3q1 { get; set; }
        public string Y3q2 { get; set; }
        public string Y3q3 { get; set; }
        public string Y3q4 { get; set; }
        public byte? Year1 { get; set; }
        public byte? Year2 { get; set; }
        public byte? Year3 { get; set; }
    }
}
