﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class EmailEscalation
    {
        public long Id { get; set; }
        public string EscalEmail { get; set; }
        public string EmailCode { get; set; }
        public string Frequency { get; set; }
        public long? FrequencyNo { get; set; }
        public long? EscalNo { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
    }
}
