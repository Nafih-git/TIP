﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrTechConfiguration
    {
        public long? PhaseId { get; set; }
        public long? Planneddays { get; set; }
        public long? Sequence { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string CreatedByRef { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedByRef { get; set; }
        public long Id { get; set; }
        public long? StageId { get; set; }

        public virtual TypeCodeMaster Phase { get; set; }
        public virtual TypeCodeMaster Stage { get; set; }
    }
}
