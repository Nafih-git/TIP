﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TempApproverNull
    {
        public string ReferenceNo { get; set; }
        public long ChallengeId { get; set; }
        public string Approvedby { get; set; }
        public string EmployeeName { get; set; }
        public string CompanyNumber { get; set; }
        public string ApprovedbyName { get; set; }
        public string IsReviewed { get; set; }
        public decimal? Count { get; set; }
    }
}
