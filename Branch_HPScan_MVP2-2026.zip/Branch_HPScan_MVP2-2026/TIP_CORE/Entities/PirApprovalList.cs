﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PirApprovalList
    {
        public long Id { get; set; }
        public long PirId { get; set; }
        public string JobTitle { get; set; }
        public string JobCode { get; set; }
        public long Seq { get; set; }
        public string Status { get; set; }
        public string Comments { get; set; }
        public DateTime? ActionCompletionDate { get; set; }
        public DateTime? ActionAssingedDate { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime CreatedOn { get; set; }
        public string ActionRequiredBy { get; set; }
        public DateTime? LastReminder { get; set; }

        public virtual PirInitiation Pir { get; set; }
    }
}
