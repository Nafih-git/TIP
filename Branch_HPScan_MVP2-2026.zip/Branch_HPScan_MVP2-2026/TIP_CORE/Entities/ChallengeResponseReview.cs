﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengeResponseReview
    {
        public long ChallengeResponseId { get; set; }
        public long ReviewQuestionId { get; set; }
        public bool? Status { get; set; }
        public string Answer { get; set; }
        public bool? TechnologyStatus { get; set; }
        public string ReviewComment { get; set; }
        public string Document { get; set; }
        public long Id { get; set; }
        public string CreatedBy { get; set; }
        public bool? IsSr { get; set; }

        public virtual ChallengeResponse ChallengeResponse { get; set; }
        public virtual TypeCodeMaster ReviewQuestion { get; set; }
    }
}
