﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class EmailTemplateConfigurationBk
    {
        public long Id { get; set; }
        public string TemplateName { get; set; }
        public string MailSubject { get; set; }
        public string MailBody { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public long ModuleId { get; set; }
        public long UniqueTemplateId { get; set; }
        public string TemplateCode { get; set; }
    }
}
