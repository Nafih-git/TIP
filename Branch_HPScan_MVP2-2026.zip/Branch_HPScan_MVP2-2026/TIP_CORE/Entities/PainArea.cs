﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PainArea
    {
        public PainArea()
        {
            ChallengeRegistrations = new HashSet<ChallengeRegistration>();
        }

        public long Id { get; set; }
        public string Reference { get; set; }
        public long AssessmentId { get; set; }
        public string Description { get; set; }
        public string RaisedBy { get; set; }
        public long? Rank { get; set; }
        public long? Hsse { get; set; }
        public string Deferment { get; set; }
        public string Cost { get; set; }
        public string Emission { get; set; }
        public bool? NtSolution { get; set; }
        public string TechFp { get; set; }
        public string TechDescription { get; set; }
        public long? NtCatalogSolution { get; set; }
        public string UctFp { get; set; }
        public string Remarks { get; set; }
        public long Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public long? ClusterId { get; set; }
        public long? NtSource { get; set; }
        public DateTime? LastReminder { get; set; }

        public virtual BtmAssessment Assessment { get; set; }
        public virtual TypeCodeMaster Cluster { get; set; }
        public virtual TypeCodeMaster HsseNavigation { get; set; }
        public virtual TypeCodeMaster StatusNavigation { get; set; }
        public virtual ICollection<ChallengeRegistration> ChallengeRegistrations { get; set; }
    }
}
