﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PirTrialFp
    {
        public long Id { get; set; }
        public long PirId { get; set; }
        public string Fp { get; set; }
        public string RefInd { get; set; }
        public string JobTitle { get; set; }
        public bool IsMandatory { get; set; }

        public virtual PirInitiation Pir { get; set; }
    }
}
