﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengeChecklist
    {
        public ChallengeChecklist()
        {
            ChecklistChallengeLnks = new HashSet<ChecklistChallengeLnk>();
        }

        public long Id { get; set; }
        public string Question { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public bool IsActive { get; set; }

        public virtual ICollection<ChecklistChallengeLnk> ChecklistChallengeLnks { get; set; }
    }
}
