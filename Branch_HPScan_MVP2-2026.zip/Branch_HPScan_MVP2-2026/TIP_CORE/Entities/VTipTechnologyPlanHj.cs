﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipTechnologyPlanHj
    {
        public long? ChallengeId { get; set; }
        public string ChallengeName { get; set; }
        public DateTime? ChallengeCreatedOn { get; set; }
        public long TechnologyBankId { get; set; }
        public string TechnologyBankName { get; set; }
        public long? TtaId { get; set; }
        public string TtaName { get; set; }
        public DateTime? CtrCreaytedOn { get; set; }
        public DateTime? TechnologyBankCreaytedOn { get; set; }
        public DateTime? ExecutionCreaytedOn { get; set; }
        public DateTime? PirCreaytedOn { get; set; }
        public DateTime? DepCreaytedOn { get; set; }
        public long PhaseId { get; set; }
        public string PhaseName { get; set; }
        public string StageName { get; set; }
        public long StageId { get; set; }
        public long? ConfigDays { get; set; }
        public string StgCode { get; set; }
        public long? Sequence { get; set; }
        public DateTime? PlannedStartDate { get; set; }
        public DateTime? PlannedEndDate { get; set; }
        public DateTime? ActualStartDate { get; set; }
        public DateTime? ActualEndDate { get; set; }
    }
}
