﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipTtaVot
    {
        public string RefNo { get; set; }
        public string TrialName { get; set; }
        public decimal? Co2ReductnUnitYr { get; set; }
        public decimal? AvgIncrmntlOilGain { get; set; }
        public decimal? TotOilDefermentAvoidance { get; set; }
        public decimal? CostSavingUnitYr { get; set; }
        public decimal? PowerSavingUnitYr { get; set; }
        public decimal? MwhCost { get; set; }
        public long? AssetId { get; set; }
        public string AssetName { get; set; }
        public long? ClusterId { get; set; }
        public string ClusterName { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public long? ThemeId { get; set; }
        public string ThemeName { get; set; }
        public long? SubthemeId { get; set; }
        public string SubthemeName { get; set; }
        public long? StatusId { get; set; }
        public string StatusName { get; set; }
        public DateTime? ActionDate { get; set; }
        public string UctFp { get; set; }
        public long? MaturityId { get; set; }
        public string MaturityLevelName { get; set; }
    }
}
