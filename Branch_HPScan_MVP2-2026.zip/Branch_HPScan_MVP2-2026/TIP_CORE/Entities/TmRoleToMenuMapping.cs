﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TmRoleToMenuMapping
    {
        public decimal MenuMapId { get; set; }
        public decimal? MenuId { get; set; }
        public long? RoleId { get; set; }
        public decimal? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public virtual TmSideMenu Menu { get; set; }
        public virtual TmUserRole Role { get; set; }
    }
}
