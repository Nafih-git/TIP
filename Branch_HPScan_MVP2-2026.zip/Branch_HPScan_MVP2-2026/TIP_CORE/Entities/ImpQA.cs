﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpQA
    {
        public string TphChallenge { get; set; }
        public string Vendor { get; set; }
        public string Querytext { get; set; }
        public string Queryanswer { get; set; }
    }
}
