﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpPirApproval
    {
        public decimal? Id { get; set; }
        public string Title { get; set; }
        public decimal? Pirid { get; set; }
        public string Approvertype { get; set; }
        public decimal? Approversequence { get; set; }
        public decimal? Status { get; set; }
        public string Approvedby { get; set; }
        public int? Taskid { get; set; }
        public int? Serialno { get; set; }
        public string Isapproved { get; set; }
        public string Approvedon { get; set; }
    }
}
