﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipTechnologyvmb
    {
        public string UctFp { get; set; }
        public DateTime? ActionDate { get; set; }
        public string Name { get; set; }
        public long? Id { get; set; }
        public string Title { get; set; }
        public long? AssetId { get; set; }
        public string AssetName { get; set; }
        public long? ClusterId { get; set; }
        public string ClusterName { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public long? ThemeId { get; set; }
        public string ThemeName { get; set; }
        public long? SubthemeId { get; set; }
        public string SubthemeName { get; set; }
        public string HeaderData { get; set; }
        public decimal? Xdays { get; set; }
        public string Keyword { get; set; }
        public long? MaturityId { get; set; }
        public string MaturityLevelName { get; set; }
    }
}
