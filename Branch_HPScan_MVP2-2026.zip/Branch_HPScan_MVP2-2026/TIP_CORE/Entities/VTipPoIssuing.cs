﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipPoIssuing
    {
        public string Trialtitle { get; set; }
        public string ContractNo { get; set; }
        public string ContractType { get; set; }
        public string AcvValue { get; set; }
        public DateTime? ContractDate { get; set; }
        public long ExecutionId { get; set; }
        public string Keyword { get; set; }
        public string AssetName { get; set; }
        public string ClusterName { get; set; }
        public string AreaName { get; set; }
        public string ApplicationName { get; set; }
        public string ThemeName { get; set; }
        public string MaturityLevelName { get; set; }
        public long? AssetId { get; set; }
        public long? ClusterId { get; set; }
        public long? AreaId { get; set; }
        public long? ApplicationId { get; set; }
        public long? ThemeId { get; set; }
        public string SubthemeId { get; set; }
        public string SubthemeName { get; set; }
        public long? MaturityId { get; set; }
        public string UctFp { get; set; }
    }
}
