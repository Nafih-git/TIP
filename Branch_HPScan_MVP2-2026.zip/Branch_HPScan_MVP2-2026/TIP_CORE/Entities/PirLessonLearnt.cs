﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PirLessonLearnt
    {
        public long Id { get; set; }
        public string Description { get; set; }
        public string CorrectiveMeasures { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedByRef { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedByRef { get; set; }
        public long PirId { get; set; }

        public virtual PirInitiation Pir { get; set; }
    }
}
