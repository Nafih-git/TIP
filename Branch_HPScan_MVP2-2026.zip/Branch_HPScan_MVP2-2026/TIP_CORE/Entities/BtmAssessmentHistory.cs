﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class BtmAssessmentHistory
    {
        public long Id { get; set; }
        public long AssessmentId { get; set; }
        public long Status { get; set; }
        public string Remarks { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedOn { get; set; }

        public virtual BtmAssessment Assessment { get; set; }
        public virtual TypeCodeMaster StatusNavigation { get; set; }
    }
}
