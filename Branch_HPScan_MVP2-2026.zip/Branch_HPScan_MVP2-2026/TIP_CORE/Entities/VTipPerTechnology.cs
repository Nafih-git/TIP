﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipPerTechnology
    {
        public long? ChallengeId { get; set; }
        public string ChaRefNo { get; set; }
        public string ChallengeName { get; set; }
        public string ChaUctFp { get; set; }
        public long TechnologyBankId { get; set; }
        public string TechName { get; set; }
        public long? CtrId { get; set; }
        public string CtrRefNo { get; set; }
        public string CtrUctFp { get; set; }
        public string CtrTrialName { get; set; }
        public long? PirId { get; set; }
        public string PirRefNo { get; set; }
        public string PirUctFp { get; set; }
        public long? AreaId { get; set; }
        public long? ApplicationId { get; set; }
        public long? ThemeId { get; set; }
        public decimal? PtDays { get; set; }
        public decimal? TtaDays { get; set; }
        public decimal? IpDays { get; set; }
        public decimal? ExecDays { get; set; }
        public decimal? PirDays { get; set; }
        public decimal? DepDays { get; set; }
        public DateTime? ChaCreatedOn { get; set; }
        public DateTime? TechCreatedOn { get; set; }
        public DateTime? CtrCreatedOn { get; set; }
        public DateTime? CtrApprovedOn { get; set; }
        public DateTime? PirApprovedOn { get; set; }
    }
}
