﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class AssetFpLnk
    {
        public long Id { get; set; }
        public long AssetId { get; set; }
        public string FocalPoint { get; set; }
    }
}
