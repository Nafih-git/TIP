﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PirFlowHistory
    {
        public long Id { get; set; }
        public long PirId { get; set; }
        public long? StatusId { get; set; }
        public string Comments { get; set; }
        public long? RoleId { get; set; }
        public string UserId { get; set; }
        public string DescInfo { get; set; }
        public DateTime CreatedOn { get; set; }

        public virtual PirInitiation Pir { get; set; }
        public virtual TmUserRole Role { get; set; }
        public virtual TypeCodeMaster Status { get; set; }
    }
}
