﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengeResponseTechnology
    {
        public long ChallengeResponseId { get; set; }
        public long TechnologyQuestion { get; set; }
        public long Id { get; set; }
        public string Description { get; set; }
    }
}
