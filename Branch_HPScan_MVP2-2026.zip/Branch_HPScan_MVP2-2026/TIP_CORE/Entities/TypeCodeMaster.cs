﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TypeCodeMaster
    {
        public TypeCodeMaster()
        {
            BtmAssessmentAssets = new HashSet<BtmAssessment>();
            BtmAssessmentClusters = new HashSet<BtmAssessment>();
            BtmAssessmentDepartments = new HashSet<BtmAssessment>();
            BtmAssessmentHistories = new HashSet<BtmAssessmentHistory>();
            BtmAssessmentStatuses = new HashSet<BtmAssessment>();
            ChallengeDetailApplications = new HashSet<ChallengeDetail>();
            ChallengeDetailAreas = new HashSet<ChallengeDetail>();
            ChallengeDetailMaturityLevels = new HashSet<ChallengeDetail>();
            ChallengeDetailSubThemes = new HashSet<ChallengeDetail>();
            ChallengeDetailThemes = new HashSet<ChallengeDetail>();
            ChallengePublicationSources = new HashSet<ChallengePublicationSource>();
            ChallengeRegistrations = new HashSet<ChallengeRegistration>();
            ChallengeResponseReviews = new HashSet<ChallengeResponseReview>();
            ChallengeResponseSources = new HashSet<ChallengeResponse>();
            ChallengeResponseSrSources = new HashSet<ChallengeResponseSr>();
            ChallengeResponseSrStatuses = new HashSet<ChallengeResponseSr>();
            ChallengeResponseStatuses = new HashSet<ChallengeResponse>();
            ChlFlowHistories = new HashSet<ChlFlowHistory>();
            ClusterFpLnks = new HashSet<ClusterFpLnk>();
            CtrActualPlanDetailPhaseNavigations = new HashSet<CtrActualPlanDetail>();
            CtrActualPlanDetailStageNavigations = new HashSet<CtrActualPlanDetail>();
            CtrActualPlanDetailTemplates = new HashSet<CtrActualPlanDetail>();
            CtrFlowHistories = new HashSet<CtrFlowHistory>();
            CtrInitiationCurrencies = new HashSet<CtrInitiation>();
            CtrInitiationStatuses = new HashSet<CtrInitiation>();
            CtrPlanDetailPhaseNavigations = new HashSet<CtrPlanDetail>();
            CtrPlanDetailStageNavigations = new HashSet<CtrPlanDetail>();
            CtrPlanDetailTemplates = new HashSet<CtrPlanDetail>();
            CtrSuccessCriteria = new HashSet<CtrSuccessCriterion>();
            CtrTechConfigurationPhases = new HashSet<CtrTechConfiguration>();
            CtrTechConfigurationStages = new HashSet<CtrTechConfiguration>();
            CtrTrialCandidates = new HashSet<CtrTrialCandidate>();
            DepVotDeployedToNavigations = new HashSet<DepVot>();
            DepVotQYearNavigations = new HashSet<DepVot>();
            DepVotStatuses = new HashSet<DepVot>();
            EmailTemplateConfigurations = new HashSet<EmailTemplateConfiguration>();
            ExeFlowHistories = new HashSet<ExeFlowHistory>();
            ExeInvoiceFlowHistories = new HashSet<ExeInvoiceFlowHistory>();
            ExecutionInvoices = new HashSet<ExecutionInvoice>();
            ExecutionPlanneds = new HashSet<ExecutionPlanned>();
            PainAreaClusters = new HashSet<PainArea>();
            PainAreaHsseNavigations = new HashSet<PainArea>();
            PainAreaStatusNavigations = new HashSet<PainArea>();
            PirAssessmentTrialResults = new HashSet<PirAssessmentTrialResult>();
            PirFlowHistories = new HashSet<PirFlowHistory>();
            PirInitiationNovelties = new HashSet<PirInitiation>();
            PirInitiationStatuses = new HashSet<PirInitiation>();
            PirTrialCandidates = new HashSet<PirTrialCandidate>();
            SubthemeCfdhLnks = new HashSet<SubthemeCfdhLnk>();
            TechnologyBankApplicationNavigations = new HashSet<TechnologyBank>();
            TechnologyBankAreaNavigations = new HashSet<TechnologyBank>();
            TechnologyBankSourceNavigations = new HashSet<TechnologyBank>();
            TechnologyBankSubThemeNavigations = new HashSet<TechnologyBank>();
            TechnologyBankThemeNavigations = new HashSet<TechnologyBank>();
        }

        public long Id { get; set; }
        public string Type { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Param1 { get; set; }
        public string Param2 { get; set; }
        public string Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedByRef { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedByRef { get; set; }
        public bool? IsInternal { get; set; }
        public long? ParentId { get; set; }
        public bool? IsEditable { get; set; }

        public virtual ICollection<BtmAssessment> BtmAssessmentAssets { get; set; }
        public virtual ICollection<BtmAssessment> BtmAssessmentClusters { get; set; }
        public virtual ICollection<BtmAssessment> BtmAssessmentDepartments { get; set; }
        public virtual ICollection<BtmAssessmentHistory> BtmAssessmentHistories { get; set; }
        public virtual ICollection<BtmAssessment> BtmAssessmentStatuses { get; set; }
        public virtual ICollection<ChallengeDetail> ChallengeDetailApplications { get; set; }
        public virtual ICollection<ChallengeDetail> ChallengeDetailAreas { get; set; }
        public virtual ICollection<ChallengeDetail> ChallengeDetailMaturityLevels { get; set; }
        public virtual ICollection<ChallengeDetail> ChallengeDetailSubThemes { get; set; }
        public virtual ICollection<ChallengeDetail> ChallengeDetailThemes { get; set; }
        public virtual ICollection<ChallengePublicationSource> ChallengePublicationSources { get; set; }
        public virtual ICollection<ChallengeRegistration> ChallengeRegistrations { get; set; }
        public virtual ICollection<ChallengeResponseReview> ChallengeResponseReviews { get; set; }
        public virtual ICollection<ChallengeResponse> ChallengeResponseSources { get; set; }
        public virtual ICollection<ChallengeResponseSr> ChallengeResponseSrSources { get; set; }
        public virtual ICollection<ChallengeResponseSr> ChallengeResponseSrStatuses { get; set; }
        public virtual ICollection<ChallengeResponse> ChallengeResponseStatuses { get; set; }
        public virtual ICollection<ChlFlowHistory> ChlFlowHistories { get; set; }
        public virtual ICollection<ClusterFpLnk> ClusterFpLnks { get; set; }
        public virtual ICollection<CtrActualPlanDetail> CtrActualPlanDetailPhaseNavigations { get; set; }
        public virtual ICollection<CtrActualPlanDetail> CtrActualPlanDetailStageNavigations { get; set; }
        public virtual ICollection<CtrActualPlanDetail> CtrActualPlanDetailTemplates { get; set; }
        public virtual ICollection<CtrFlowHistory> CtrFlowHistories { get; set; }
        public virtual ICollection<CtrInitiation> CtrInitiationCurrencies { get; set; }
        public virtual ICollection<CtrInitiation> CtrInitiationStatuses { get; set; }
        public virtual ICollection<CtrPlanDetail> CtrPlanDetailPhaseNavigations { get; set; }
        public virtual ICollection<CtrPlanDetail> CtrPlanDetailStageNavigations { get; set; }
        public virtual ICollection<CtrPlanDetail> CtrPlanDetailTemplates { get; set; }
        public virtual ICollection<CtrSuccessCriterion> CtrSuccessCriteria { get; set; }
        public virtual ICollection<CtrTechConfiguration> CtrTechConfigurationPhases { get; set; }
        public virtual ICollection<CtrTechConfiguration> CtrTechConfigurationStages { get; set; }
        public virtual ICollection<CtrTrialCandidate> CtrTrialCandidates { get; set; }
        public virtual ICollection<DepVot> DepVotDeployedToNavigations { get; set; }
        public virtual ICollection<DepVot> DepVotQYearNavigations { get; set; }
        public virtual ICollection<DepVot> DepVotStatuses { get; set; }
        public virtual ICollection<EmailTemplateConfiguration> EmailTemplateConfigurations { get; set; }
        public virtual ICollection<ExeFlowHistory> ExeFlowHistories { get; set; }
        public virtual ICollection<ExeInvoiceFlowHistory> ExeInvoiceFlowHistories { get; set; }
        public virtual ICollection<ExecutionInvoice> ExecutionInvoices { get; set; }
        public virtual ICollection<ExecutionPlanned> ExecutionPlanneds { get; set; }
        public virtual ICollection<PainArea> PainAreaClusters { get; set; }
        public virtual ICollection<PainArea> PainAreaHsseNavigations { get; set; }
        public virtual ICollection<PainArea> PainAreaStatusNavigations { get; set; }
        public virtual ICollection<PirAssessmentTrialResult> PirAssessmentTrialResults { get; set; }
        public virtual ICollection<PirFlowHistory> PirFlowHistories { get; set; }
        public virtual ICollection<PirInitiation> PirInitiationNovelties { get; set; }
        public virtual ICollection<PirInitiation> PirInitiationStatuses { get; set; }
        public virtual ICollection<PirTrialCandidate> PirTrialCandidates { get; set; }
        public virtual ICollection<SubthemeCfdhLnk> SubthemeCfdhLnks { get; set; }
        public virtual ICollection<TechnologyBank> TechnologyBankApplicationNavigations { get; set; }
        public virtual ICollection<TechnologyBank> TechnologyBankAreaNavigations { get; set; }
        public virtual ICollection<TechnologyBank> TechnologyBankSourceNavigations { get; set; }
        public virtual ICollection<TechnologyBank> TechnologyBankSubThemeNavigations { get; set; }
        public virtual ICollection<TechnologyBank> TechnologyBankThemeNavigations { get; set; }
    }
}
