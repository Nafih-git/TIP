﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpEmployeeLive
    {
        public string EmployeeName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string OfficePhone { get; set; }
        public string ReferenceIndicator { get; set; }
        public string EmailAddress { get; set; }
        public string JobDescription { get; set; }
        public string LxrefIndicatorN { get; set; }
        public string EmploymentStatus { get; set; }
        public string CompanyNumber { get; set; }
        public string FullName { get; set; }
        public string CompnoNameRefindicator { get; set; }
        public string SupervisorId { get; set; }
    }
}
