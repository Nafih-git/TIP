﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TmUserPaArchieve
    {
        public string PaEnc { get; set; }
        public long ExtUserid { get; set; }
        public DateTime CreatedOn { get; set; }
        public long Id { get; set; }
    }
}
