﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ExecutionBudgetConfirmation
    {
        public string ContractNo { get; set; }
        public decimal? TotalValue { get; set; }
        public string FinanceFp { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public long? StatusId { get; set; }
        public long? CtrId { get; set; }
        public long Id { get; set; }
        public DateTime? ApprovedDate { get; set; }
    }
}
