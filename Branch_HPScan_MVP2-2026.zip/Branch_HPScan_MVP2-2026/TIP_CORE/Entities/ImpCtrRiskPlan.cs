﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtrRiskPlan
    {
        public string Ctrrefnumber { get; set; }
        public byte? Serial { get; set; }
        public string Risk { get; set; }
        public string Mitigationplan { get; set; }
    }
}
