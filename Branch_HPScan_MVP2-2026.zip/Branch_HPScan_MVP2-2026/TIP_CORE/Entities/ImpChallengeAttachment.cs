﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpChallengeAttachment
    {
        public string Title { get; set; }
        public decimal? Tphchallengeid { get; set; }
        public int? LivelinkId { get; set; }
        public string LivelinkUrl { get; set; }
        public decimal? OldTphAttachmentId { get; set; }
        public decimal? OldTphChallengeId { get; set; }
        public string Attachmentpath { get; set; }
    }
}
