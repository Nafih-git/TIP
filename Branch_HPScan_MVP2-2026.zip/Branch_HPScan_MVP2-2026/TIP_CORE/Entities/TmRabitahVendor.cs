﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TmRabitahVendor
    {
        public string VendorCode { get; set; }
        public string VendorDescription { get; set; }
        public string VendorEmail { get; set; }
        public string Address { get; set; }
        public string CompanyWebsite { get; set; }
        public string ContactPersonName { get; set; }
        public string ContactPhone { get; set; }
    }
}
