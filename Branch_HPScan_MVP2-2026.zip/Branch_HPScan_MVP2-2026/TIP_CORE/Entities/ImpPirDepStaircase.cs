﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpPirDepStaircase
    {
        public string Title { get; set; }
        public byte? Pirid { get; set; }
        public string Fieldorstation { get; set; }
        public string Year1wells { get; set; }
        public string Year1estvot { get; set; }
        public string Year2wells { get; set; }
        public string Year2estvot { get; set; }
        public string Year3wells { get; set; }
        public string Year3estvot { get; set; }
        public string Year4wells { get; set; }
        public string Year4estvot { get; set; }
        public string Year5wells { get; set; }
        public string Year5estvot { get; set; }
        public string Year6wells { get; set; }
        public string Year6estvot { get; set; }
    }
}
