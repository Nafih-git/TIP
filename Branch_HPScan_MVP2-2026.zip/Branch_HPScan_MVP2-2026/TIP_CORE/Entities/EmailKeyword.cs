﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class EmailKeyword
    {
        public long ModuleId { get; set; }
        public string Keyword { get; set; }
        public string Description { get; set; }
        public long Id { get; set; }
    }
}
