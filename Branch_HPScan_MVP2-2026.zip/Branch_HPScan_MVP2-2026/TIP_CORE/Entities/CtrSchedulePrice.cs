﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrSchedulePrice
    {
        public long Id { get; set; }
        public long CtrId { get; set; }
        public string Description { get; set; }
        public string Units { get; set; }
        public decimal UnitPrice { get; set; }
        public long Quantity { get; set; }
        public long NumberOfTrials { get; set; }
        public decimal TotalPriceEstimate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedByRef { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedByRef { get; set; }

        public virtual CtrInitiation Ctr { get; set; }
    }
}
