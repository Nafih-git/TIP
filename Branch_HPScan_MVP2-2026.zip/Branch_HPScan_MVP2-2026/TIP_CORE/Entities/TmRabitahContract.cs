﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TmRabitahContract
    {
        public string ContractId { get; set; }
        public string ContractType { get; set; }
        public decimal? OriginalAcvValue { get; set; }
        public DateTime? CommencementDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public string ContractDescription { get; set; }
        public string Contractor { get; set; }
    }
}
