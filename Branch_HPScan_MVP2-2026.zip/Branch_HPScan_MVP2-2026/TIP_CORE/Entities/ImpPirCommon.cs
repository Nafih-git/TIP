﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpPirCommon
    {
        public byte? Id { get; set; }
        public string Title { get; set; }
        public byte? Pirid { get; set; }
        public string Assumptionsmade { get; set; }
        public string Staircasecomments { get; set; }
        public string Lessonlearntnotes { get; set; }
        public string Successcriterianotes { get; set; }
    }
}
