﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ClusterFpLnk
    {
        public long Id { get; set; }
        public long? ClusterId { get; set; }
        public string FocalPoint { get; set; }

        public virtual TypeCodeMaster Cluster { get; set; }
    }
}
