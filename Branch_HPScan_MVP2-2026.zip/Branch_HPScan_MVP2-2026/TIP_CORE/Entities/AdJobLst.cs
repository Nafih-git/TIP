﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class AdJobLst
    {
        public string JobDescription { get; set; }
    }
}
