﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpPirTrialcandidate
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Name { get; set; }
        public string Pirid { get; set; }
        public string Candidatetype { get; set; }
        public string Isdeleted { get; set; }
        public string Cost { get; set; }
        public string Trailcommencementdate { get; set; }
        public string Trailconclusiondate { get; set; }
        public string Challengedescription { get; set; }
        public string Trialoutcome { get; set; }
    }
}
