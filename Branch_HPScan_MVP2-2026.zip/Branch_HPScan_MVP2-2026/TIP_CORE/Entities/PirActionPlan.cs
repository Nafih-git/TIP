﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PirActionPlan
    {
        public long Id { get; set; }
        public string Title { get; set; }
        public string Party { get; set; }
        public DateTime? Target { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public long PirId { get; set; }

        public virtual PirInitiation Pir { get; set; }
    }
}
