﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class JobLog
    {
        public decimal LogId { get; set; }
        public string JobName { get; set; }
        public DateTime? LogTimestamp { get; set; }
        public string LogMessage { get; set; }
    }
}
