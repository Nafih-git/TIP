﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ExecutionInitiation
    {
        public ExecutionInitiation()
        {
            ExeFlowHistories = new HashSet<ExeFlowHistory>();
            ExeInvoiceFlowHistories = new HashSet<ExeInvoiceFlowHistory>();
            ExecutionInvoices = new HashSet<ExecutionInvoice>();
            ExecutionPlannedTimelines = new HashSet<ExecutionPlannedTimeline>();
            ExecutionPotentialValues = new HashSet<ExecutionPotentialValue>();
            ExecutionTrialCandidates = new HashSet<ExecutionTrialCandidate>();
            ExecutionTrialFps = new HashSet<ExecutionTrialFp>();
        }

        public string RefNo { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public long? StatusId { get; set; }
        public string ContractNo { get; set; }
        public string ContractType { get; set; }
        public string Startmonth { get; set; }
        public long? MaturityLevelId { get; set; }
        public long? AreaId { get; set; }
        public long? ThemeId { get; set; }
        public long? ApplicationId { get; set; }
        public string AcvValue { get; set; }
        public long CtrId { get; set; }
        public DateTime? SubmittedOn { get; set; }
        public long Id { get; set; }
        public string Trialtitle { get; set; }
        public string Challengetitle { get; set; }
        public long? AssetId { get; set; }
        public long? ClusterId { get; set; }
        public DateTime? Initiateddate { get; set; }
        public string UctFp { get; set; }
        public bool? IsCompleted { get; set; }
        public DateTime? CompletionDate { get; set; }

        public virtual ICollection<ExeFlowHistory> ExeFlowHistories { get; set; }
        public virtual ICollection<ExeInvoiceFlowHistory> ExeInvoiceFlowHistories { get; set; }
        public virtual ICollection<ExecutionInvoice> ExecutionInvoices { get; set; }
        public virtual ICollection<ExecutionPlannedTimeline> ExecutionPlannedTimelines { get; set; }
        public virtual ICollection<ExecutionPotentialValue> ExecutionPotentialValues { get; set; }
        public virtual ICollection<ExecutionTrialCandidate> ExecutionTrialCandidates { get; set; }
        public virtual ICollection<ExecutionTrialFp> ExecutionTrialFps { get; set; }
    }
}
