﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtrDsAddNote
    {
        public string Ctrrefnumber { get; set; }
        public string Title { get; set; }
        public string Additionalnotes { get; set; }
        public string AssumptionsMade { get; set; }
        public string Comments { get; set; }
    }
}
