﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpTph
    {
        public string Tphreferenceno { get; set; }
        public string Challengereferenceno { get; set; }
        public string Challengetitle { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string Publisheddate { get; set; }
        public string Responselastdate { get; set; }
        public string Status { get; set; }
        public string ExpiryStatus { get; set; }
        public string Modified { get; set; }
        public string Id { get; set; }
        public string Lastdatequery { get; set; }
        public string Publishedby { get; set; }
        public string TphChallengeId { get; set; }
        public string Lastdatetoresponse { get; set; }
        public long? AreaId { get; set; }
        public long? AssetId { get; set; }
        public long? ClusterId { get; set; }
    }
}
