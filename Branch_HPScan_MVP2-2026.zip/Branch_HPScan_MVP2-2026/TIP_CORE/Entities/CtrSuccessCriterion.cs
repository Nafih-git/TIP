﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrSuccessCriterion
    {
        public long CtrId { get; set; }
        public string Parameter { get; set; }
        public string CurrentValue { get; set; }
        public string TrialTarget { get; set; }
        public long? ParameterId { get; set; }
        public string DecisionGateImpacted { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public long Id { get; set; }
        public string Remarks { get; set; }

        public virtual CtrInitiation Ctr { get; set; }
        public virtual TypeCodeMaster ParameterNavigation { get; set; }
    }
}
