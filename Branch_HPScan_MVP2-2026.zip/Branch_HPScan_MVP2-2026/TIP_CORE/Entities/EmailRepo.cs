﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class EmailRepo
    {
        public long Id { get; set; }
        public string MailSubject { get; set; }
        public string MailBody { get; set; }
        public string ToRecipients { get; set; }
        public string CcRecipients { get; set; }
        public DateTime LoggedDate { get; set; }
        public DateTime? EmailedDate { get; set; }
        public string EmailedYn { get; set; }
        public long ModuleId { get; set; }
        public long TemplateId { get; set; }
        public long? TryCount { get; set; }
        public string Error { get; set; }
        public string Attachment { get; set; }
        public string AttachmentName { get; set; }
    }
}
