﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtrScAddNote
    {
        public string CtrRefno { get; set; }
        public string AdditionalNotes { get; set; }
    }
}
