﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpUpdateTechBank
    {
        public long TechId { get; set; }
        public long ChallengeId { get; set; }
        public long ResponseId { get; set; }
    }
}
