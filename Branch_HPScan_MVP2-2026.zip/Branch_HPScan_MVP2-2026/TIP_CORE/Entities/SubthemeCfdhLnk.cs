﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class SubthemeCfdhLnk
    {
        public long Id { get; set; }
        public long SubthemeId { get; set; }
        public string Cfdh { get; set; }

        public virtual TypeCodeMaster Subtheme { get; set; }
    }
}
