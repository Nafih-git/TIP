﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengePublicationSource
    {
        public long Id { get; set; }
        public long SourceId { get; set; }
        public long ChRegId { get; set; }

        public virtual ChallengeRegistration ChReg { get; set; }
        public virtual TypeCodeMaster Source { get; set; }
    }
}
