﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class VTipTechnologySpendingR
    {
        public string Year { get; set; }
        public long CtrId { get; set; }
        public string Months { get; set; }
        public long TechId { get; set; }
        public string Title { get; set; }
        public decimal? AcvValue { get; set; }
        public decimal? Planvalue { get; set; }
        public decimal? Ytd { get; set; }
        public decimal? CumulativeValue { get; set; }
        public long? AssetId { get; set; }
        public string AssetName { get; set; }
        public long? ClusterId { get; set; }
        public string ClusterName { get; set; }
        public long? AreaId { get; set; }
        public string AreaName { get; set; }
        public long? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public long? ThemeId { get; set; }
        public string ThemeName { get; set; }
        public string Keyword { get; set; }
    }
}
