﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class PdoToVendorQueryResponse
    {
        public long QueryId { get; set; }
        public string Response { get; set; }
        public bool? HasAttachment { get; set; }
        public long Id { get; set; }
        public DateTime CreatedOn { get; set; }

        public virtual PdoToVendorQuery Query { get; set; }
    }
}
