﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpVendorResponse
    {
        public string Tphreference { get; set; }
        public string Responsereferenceno { get; set; }
        public string Vendor { get; set; }
        public string Proposedtechnology { get; set; }
        public string Status { get; set; }
        public string Created { get; set; }
        public string Modified { get; set; }
        public string AppModifiedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string Ismarked { get; set; }
        public string TphResponseStatusId { get; set; }
        public string Responseid { get; set; }
        public string Technologyid { get; set; }
        public string Vendorresponse { get; set; }
        public string Detailedsolution { get; set; }
        public string Usercomments { get; set; }
    }
}
