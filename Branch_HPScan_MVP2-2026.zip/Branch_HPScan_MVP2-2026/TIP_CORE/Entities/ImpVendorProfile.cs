﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpVendorProfile
    {
        public string Contactpersonphoneno { get; set; }
        public string TphVendorid { get; set; }
        public string Contactpersonemail { get; set; }
        public string Suppliercode { get; set; }
        public string Manufacturename { get; set; }
        public string Companyorbranchname { get; set; }
        public string Emailaddress { get; set; }
    }
}
