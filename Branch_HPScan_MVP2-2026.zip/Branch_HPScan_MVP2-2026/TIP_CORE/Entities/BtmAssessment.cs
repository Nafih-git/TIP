﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class BtmAssessment
    {
        public BtmAssessment()
        {
            BtmAssessmentHistories = new HashSet<BtmAssessmentHistory>();
            ChallengeRegistrations = new HashSet<ChallengeRegistration>();
            PainAreas = new HashSet<PainArea>();
        }

        public long Id { get; set; }
        public long Year { get; set; }
        public long AssetId { get; set; }
        public long? ClusterId { get; set; }
        public long DepartmentId { get; set; }
        public DateTime WorkshopDate { get; set; }
        public long StatusId { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual TypeCodeMaster Asset { get; set; }
        public virtual TypeCodeMaster Cluster { get; set; }
        public virtual TypeCodeMaster Department { get; set; }
        public virtual TypeCodeMaster Status { get; set; }
        public virtual ICollection<BtmAssessmentHistory> BtmAssessmentHistories { get; set; }
        public virtual ICollection<ChallengeRegistration> ChallengeRegistrations { get; set; }
        public virtual ICollection<PainArea> PainAreas { get; set; }
    }
}
