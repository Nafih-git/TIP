﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ExecutionPlannedTimeline
    {
        public long Id { get; set; }
        public string Stage { get; set; }
        public string Activity { get; set; }
        public DateTime? Startdate { get; set; }
        public DateTime? Enddate { get; set; }
        public long? PlannedDayes { get; set; }
        public long? Cost { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdateOn { get; set; }
        public string UpdatedBy { get; set; }
        public long ExecId { get; set; }
        public long? MilestoneType { get; set; }
        public string PartyName { get; set; }
        public long? Activitysort { get; set; }
        public long? Stagesort { get; set; }
        public long? AcvValue { get; set; }
        public bool? Type { get; set; }
        public long? Phaseid { get; set; }

        public virtual ExecutionInitiation Exec { get; set; }
    }
}
