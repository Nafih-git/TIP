﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TechnologyBank
    {
        public long Id { get; set; }
        public string Title { get; set; }
        public long? Area { get; set; }
        public long? Theme { get; set; }
        public long? SubTheme { get; set; }
        public long? Application { get; set; }
        public long? Source { get; set; }
        public string ContactFp { get; set; }
        public string Description { get; set; }
        public string Vendor { get; set; }
        public string ContactEmail { get; set; }
        public string RefNo { get; set; }
        public long? ChallengeId { get; set; }
        public long? ChallengeResponseId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public long? AssetId { get; set; }
        public long? ClusterId { get; set; }

        public virtual TypeCodeMaster ApplicationNavigation { get; set; }
        public virtual TypeCodeMaster AreaNavigation { get; set; }
        public virtual ChallengeRegistration Challenge { get; set; }
        public virtual ChallengeResponse ChallengeResponse { get; set; }
        public virtual TypeCodeMaster SourceNavigation { get; set; }
        public virtual TypeCodeMaster SubThemeNavigation { get; set; }
        public virtual TypeCodeMaster ThemeNavigation { get; set; }
    }
}
