﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpMigratedChallenge
    {
        public string Ntp { get; set; }
        public string Tip { get; set; }
    }
}
