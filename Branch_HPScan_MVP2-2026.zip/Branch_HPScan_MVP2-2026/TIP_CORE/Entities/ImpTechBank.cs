﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpTechBank
    {
        public string Technologyreferencenumber { get; set; }
        public string Title { get; set; }
        public string Application { get; set; }
        public string Theme { get; set; }
        public string Subtheme { get; set; }
        public string Vendor { get; set; }
        public string Created { get; set; }
        public string Id { get; set; }
    }
}
