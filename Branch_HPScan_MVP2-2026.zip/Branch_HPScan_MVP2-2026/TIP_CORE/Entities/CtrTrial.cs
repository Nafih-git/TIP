﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class CtrTrial
    {
        public CtrTrial()
        {
            CtrTrialYears = new HashSet<CtrTrialYear>();
        }

        public long CtrId { get; set; }
        public string DecisionGate { get; set; }
        public string DecisionBy { get; set; }
        public string Remarks { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public decimal? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public long Id { get; set; }

        public virtual CtrInitiation Ctr { get; set; }
        public virtual ICollection<CtrTrialYear> CtrTrialYears { get; set; }
    }
}
