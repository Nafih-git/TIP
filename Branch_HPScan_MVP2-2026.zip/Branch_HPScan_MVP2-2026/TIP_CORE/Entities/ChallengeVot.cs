﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengeVot
    {
        public long ChallengeId { get; set; }
        public long UnitId { get; set; }
        public long NoOfUnitsYear1 { get; set; }
        public long? NoOfUnitsYear2 { get; set; }
        public long? NoOfUnitsYear3 { get; set; }
        public long? NoOfUnitsYear4 { get; set; }
        public long? NoOfUnitsYear5 { get; set; }
        public long? NoOfUnitsTrailScope { get; set; }
        public decimal? TechCost { get; set; }
        public decimal? OtherCost { get; set; }
        public decimal? AvgIncrmntlOilGain { get; set; }
        public decimal? TotOilDefermentAvoidance { get; set; }
        public decimal? CostSavingUnitYr { get; set; }
        public decimal? PowerSavingUnitYr { get; set; }
        public decimal? CostAvoidance { get; set; }
        public decimal? Co2ReductnUnitYr { get; set; }
        public string Hse { get; set; }
        public string Quality { get; set; }
        public string Compliance { get; set; }
        public long? RiskFactor { get; set; }
        public decimal? M3T0Bbl { get; set; }
        public decimal? Co2Tax { get; set; }
        public decimal? MwhCost { get; set; }
        public decimal? OilPrice { get; set; }
        public decimal? TotalMwhReduction { get; set; }
        public decimal? TotalCo2Reduction { get; set; }
        public decimal? VotUnitYear { get; set; }
        public decimal? VotTrailTotUnits { get; set; }
        public decimal? VotTotDeploymentUnits { get; set; }
        public long Id { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }

        public virtual ChallengeRegistration Challenge { get; set; }
    }
}
