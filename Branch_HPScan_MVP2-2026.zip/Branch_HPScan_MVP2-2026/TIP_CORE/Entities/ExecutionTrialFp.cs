﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ExecutionTrialFp
    {
        public long ExecutionId { get; set; }
        public string Fp { get; set; }
        public string RefInd { get; set; }
        public string JobTitle { get; set; }
        public bool IsMandatory { get; set; }
        public long Id { get; set; }

        public virtual ExecutionInitiation Execution { get; set; }
    }
}
