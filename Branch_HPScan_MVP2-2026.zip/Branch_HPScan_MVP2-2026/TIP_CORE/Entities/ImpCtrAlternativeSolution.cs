﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ImpCtrAlternativeSolution
    {
        public string Ctrrefnumber { get; set; }
        public string SolutionTitle { get; set; }
        public string Remarks { get; set; }
        public bool? Serial { get; set; }
    }
}
