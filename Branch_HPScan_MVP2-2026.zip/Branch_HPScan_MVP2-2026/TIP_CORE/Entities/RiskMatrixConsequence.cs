﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class RiskMatrixConsequence
    {
        public decimal Id { get; set; }
        public long? Severity { get; set; }
        public long? Consequence { get; set; }
        public string CellText { get; set; }
    }
}
