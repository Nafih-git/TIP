﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class TmContractdetail
    {
        public string Column1 { get; set; }
    }
}
