﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class ChallengeRegistration
    {
        public ChallengeRegistration()
        {
            ChallengeDetails = new HashSet<ChallengeDetail>();
            ChallengePublicationSources = new HashSet<ChallengePublicationSource>();
            ChallengeResponseSrs = new HashSet<ChallengeResponseSr>();
            ChallengeResponses = new HashSet<ChallengeResponse>();
            ChallengeSolutionReviewers = new HashSet<ChallengeSolutionReviewer>();
            ChallengeVendorScreenings = new HashSet<ChallengeVendorScreening>();
            ChallengeVots = new HashSet<ChallengeVot>();
            ChecklistChallengeLnks = new HashSet<ChecklistChallengeLnk>();
            TechnologyBanks = new HashSet<TechnologyBank>();
        }

        public long Id { get; set; }
        public long? AssessmentId { get; set; }
        public long? PainAreaId { get; set; }
        public string RequestedBy { get; set; }
        public string ReferenceNo { get; set; }
        public long StatusId { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public long? UpdatedRoleId { get; set; }
        public long? CreatedRoleId { get; set; }
        public string ActionComment { get; set; }
        public string UctFp { get; set; }
        public DateTime? PublishDate { get; set; }
        public string Publishreferenceno { get; set; }
        public DateTime? LastReminder { get; set; }

        public virtual BtmAssessment Assessment { get; set; }
        public virtual PainArea PainArea { get; set; }
        public virtual TypeCodeMaster Status { get; set; }
        public virtual ICollection<ChallengeDetail> ChallengeDetails { get; set; }
        public virtual ICollection<ChallengePublicationSource> ChallengePublicationSources { get; set; }
        public virtual ICollection<ChallengeResponseSr> ChallengeResponseSrs { get; set; }
        public virtual ICollection<ChallengeResponse> ChallengeResponses { get; set; }
        public virtual ICollection<ChallengeSolutionReviewer> ChallengeSolutionReviewers { get; set; }
        public virtual ICollection<ChallengeVendorScreening> ChallengeVendorScreenings { get; set; }
        public virtual ICollection<ChallengeVot> ChallengeVots { get; set; }
        public virtual ICollection<ChecklistChallengeLnk> ChecklistChallengeLnks { get; set; }
        public virtual ICollection<TechnologyBank> TechnologyBanks { get; set; }
    }
}
