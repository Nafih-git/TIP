﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class DepVot
    {
        public long Id { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedByRef { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedByRef { get; set; }
        public long? QYear { get; set; }
        public long? DeployedTo { get; set; }
        public decimal? ScopeCountQtr { get; set; }
        public decimal? IncrmntlOilGain { get; set; }
        public decimal? DefermentAvoidance { get; set; }
        public decimal? CostSavingUnitQtr { get; set; }
        public decimal? PowerSaving { get; set; }
        public decimal? Co2Reduction { get; set; }
        public decimal? TechnologyCost { get; set; }
        public decimal? OtherCostQtr { get; set; }
        public decimal? TotalVotQtr { get; set; }
        public string FinalComments { get; set; }
        public long? StatusId { get; set; }
        public DateTime? LastReminder { get; set; }
        public long? EscCount { get; set; }
        public long? DepId { get; set; }
        public DateTime? SubmittedOn { get; set; }

        public virtual DepInitiation Dep { get; set; }
        public virtual TypeCodeMaster DeployedToNavigation { get; set; }
        public virtual TypeCodeMaster QYearNavigation { get; set; }
        public virtual TypeCodeMaster Status { get; set; }
    }
}
