﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TIP_CORE.Entities
{
    public partial class DocumentRepo
    {
        public long? LinkId { get; set; }
        public string LimkType { get; set; }
        public string FileName { get; set; }
        public string FileType { get; set; }
        public string Description { get; set; }
        public string FilePath { get; set; }
        public long Id { get; set; }
        public bool? IsExternalAccessible { get; set; }
        public string MimeType { get; set; }
        public bool? IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public bool? IsNda { get; set; }
    }
}
