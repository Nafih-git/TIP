﻿using TIP_Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE
{
    public class Cluster : Audit
    {
        public decimal DirectorateId { get; set; }
        public decimal ClusterId { get; set; }
        public string ClusterName { get; set; }
        public string DirectorateName { get; set; }
        public decimal Status { get; set; }
        public decimal ParentClusterId { get; set; }
        public string StatusName { get; set; }
    }
}
