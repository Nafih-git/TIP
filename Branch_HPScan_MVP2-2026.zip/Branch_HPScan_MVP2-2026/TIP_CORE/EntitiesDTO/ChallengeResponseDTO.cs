﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Reflection.PortableExecutable;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{
    public class ChallengeResponseDTO
    {

        public long id { get; set; }
        public string encrptId { get; set; }
        public string resNo { get; set; }
        public string tphNo { get; set; }
        public string chaTitle { get; set; }
        public string theme { get; set; }
        public string subTheme { get; set; }
        public string solTitle { get; set; }
        public long sourceId { get; set; }       
		public string source { get; set; }
		public string contact { get; set; }
        public string status { get; set; }
        public string? statusName { get; set; }
		public bool? isCr { get; set; }
        public string userName { get; set; }
        public string chaNo { get; set; }
        public DateTime? submissionDate { get; set; }
        public string? companyName { get; set; }

        public string? uctFPName { get; set; }
        public bool? isUCTViewOnly { get; set; }
        public long? historyCount { get; set; }

        public bool IsReviewed { get; set; }
        

    }

    public class ChallengeRespondByTypeDTO
    {
        public List<ChallengeResponseDTO> vendorChallengeRespond { get; set; }
        public List<ChallengeResponseDTO> benchmarkedChallengeRespond { get; set; }
    }

    public class ChallengeEscDTO
    {
        [BindNever]
        public long? id { get; set; }
        public string? uctFP { get; set; }
        public string? emailAddress { get; set; }
        public string? displayname { get; set; }
		public DateTime? updatedOn { get; set; }
		public DateTime? lastReminder { get; set; }
	}

    public class SolutionReviewerListDTO
    {
        public long? Id { get; set; }
        public long? challengeid { get; set; }
        public long? chaDetailId { get; set; }
        public string? reviewerName { get; set; }
        public string? muNo { get; set; }
        public string? jobTitle { get; set; }
        public string? statusName { get; set; }
        public string? emailAddress { get; set; }

    }
    public class ChallengeReassignmentDTO
    {
        public long solId { get; set; }
        public AllPDOUsersDTO? NewAdvisor { get; set; }
        public List<AllPDOUsersDTO>? solutionReviewers { get; set; }
        public long CurrentRId { get; set; }
        public string? CurrentMu { get; set; }
    }

    public class ChallengeReassignmentListDTO
    {
        public long? challengeId { get; set; }
        public string? challengeRefId { get; set; }
        public long? resonseId { get; set; }
        public string? resonseRefId { get; set; }
        public string? advisorName { get; set; }
        public string? muNo { get; set; }
        public List<AllPDOUsersDTO>? reviewers { get; set; }
        public string? jobTitle { get; set; }
        public string? statusName { get; set; }
        public string? emailAddress { get; set;}

    }

    [BindNever]
    public class ChallengeReassignUCTDTO
    {
        public long ChallengeId { get; set; }
        public AllPDOUsersDTO? NewAdvisor { get; set; }
        public long? CurrentRId { get; set; }
        public string? CurrentMu { get; set; }
        public string CurrentAdvisorName { get; set; }
        public string? OldUCTEmail { get; set; }
        public string? ChaRefNo { get; set; }
    }

    public class ChallengeReassignReviewerDTO
    {
        public long ChallengeId { get; set; }
        public AllPDOUsersDTO? NewAdvisor { get; set; }
        public List<AllPDOUsersDTO>? SolutionReviewers { get; set; }
        public long? CurrentRId { get; set; }
        public string? CurrentMu { get; set; }
        public string? CurrentCFDH { get; set; }
        public string? CurrentAdvisorName { get; set; }
        public string? OldCREmail { get; set; }
        public string? ChaRefNo { get; set; }

        public AllPDOUsersDTO? CFDH { get; set; }

    }

	[BindNever]
    public class ExternalUserBasicDTO
    {
        public string EMAIL_ADDRESS { get; set; }
        public string DISPLAY_NAME { get; set; }
	}

}
