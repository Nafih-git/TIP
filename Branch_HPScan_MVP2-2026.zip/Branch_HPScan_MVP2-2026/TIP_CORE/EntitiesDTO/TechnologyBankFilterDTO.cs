﻿using System.Runtime.Serialization;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TIP_CORE.EntitiesDTO
{
    [BindNever]
    public class TechnologyBankFilterDTO
    {
        public long? area { get; set; }
        public long? application { get; set; }
        public long? theme { get; set; }
        public long? subTheme { get; set; }
        public long? source { get;set; }
    }
}
