﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    [DataContract]
    public class UserLogDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public long? userid { get; set; }
        [DataMember]
        public DateTime? logindatetime { get; set; }
        [DataMember]
        public string status { get; set; }
    }
}
