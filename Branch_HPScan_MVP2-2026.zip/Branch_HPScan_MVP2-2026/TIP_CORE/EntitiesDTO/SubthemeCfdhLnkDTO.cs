﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class SubthemeCfdhLnkDTO
    {
        public string cfdh { get; set; }
        public string muNo { get; set; }
    }
}
