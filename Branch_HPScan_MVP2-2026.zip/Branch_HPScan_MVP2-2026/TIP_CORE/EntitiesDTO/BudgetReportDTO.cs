﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using TIP_API.DTO.Admin;
using TIP_CORE.Entities;

namespace TIP_CORE.EntitiesDTO
{

    [BindNever]
    public class BudgetReportDTO
    {
        public BudgetReportDTO()
        {
            ActualBudget = new List<ExecutionInvoiceDTO>();
            PlannedBudget = new List<CtrBudgetDTO>();
        }

        public string? chaEncrptId { get; set; }
        public string? chaRefNo { get; set; }
        public string? chaTitle { get; set; }
        public string? chaRequestBy { get; set; }
        public string? chaUCT { get; set; }
        public string? chaUCTName { get; set; }
        public string? chaStatus { get; set; }
        public string? resEncrptId { get; set; }
        public string? resRefNo { get; set; }
        public string? resTechName { get; set; }
        public string? resVendor { get; set; }
        public string? resUCT { get; set; }
        public string? resStatus { get; set; }
        public string? resSource { get; set; }
        public string? resStatusParam { get; set; }
        public string? ctrEncrptId { get; set; }
        public string? ctrRefNo { get; set; }
        public string? ctrTrialName { get; set; }
        public string? ctrUCT { get; set; }
        public string? ctrStatus { get; set; }
        public string? pirEncrptId { get; set; }
        public string? pirRefNo { get; set; }
        public string? pirUCT { get; set; }
        public string? pirStatus { get; set; }
        public long? areaId { get; set; }
        public long? appId { get; set; }
        public long? themeId { get; set; }
        public string? approvedYear { get; set; }
        public long id { get; set; }
        public string encrptId { get; set; }

        public decimal ACV { get; set; }
        public long? assessmentId { get; set; }
        public long? painAreaId { get; set; }
        public string assetName { get; set; }
        public string clusterName { get; set; }
        public string departmentName { get; set; }

        public string UCTFPName { get; set; }
        public string TechName { get; set; }

        public string YearString { get; set; }

        public string currencyName { get; set; }
        public long? currencyId { get; set; }

        public string Year { get; set; }

        public string Type { get; set; }

        public decimal PlannedBudgetTotalAmount { get; set; }

        public decimal ActualBudgetTotalAmount { get; set; }
        public List<CtrBudgetDTO> PlannedBudget { get; set; }
       public Dictionary<int, decimal> PlannedCurrentBudgetMonthly { get; set; }
        public List<ExecutionInvoiceDTO> ActualBudget { get; set; }
        public Dictionary<int, decimal> ActualNextBudgetMonthly { get; set; }

 

        public string CurrentYear { get; set; }
        public string NextYear { get; set; }

        public List<YearlyBudgetPlan> Planned { get; set; }

        public List<YearlyBudgetPlan> Actual { get; set; }

    

        public decimal PlannedBudgetTotalAmountYearly { get; set; }
        //public decimal PlannedBudgetTotalAmountNextYear { get; set; }

        public decimal ActualBudgetTotalAmountYearly { get; set; }
        public Dictionary<int, decimal> BudgetMonthly { get; set; }

        public decimal[] PlannedBudgetMonthlyArray { get; set; }

        public decimal[] BudgetMonthlyArray { get; set; }

        public string BudgetMonthlyStr { get; set; }

        public decimal[] ActualBudgetMonthlyArray { get; set; }
        public string PlannedBudgetMonthlyStr { get; set; }

        public string ActualBudgetMonthlyStr { get; set; }
    }

 public class YearlyBudgetPlan
    {
        //public string Year { get; set; }
        //public decimal PlannedBudgetTotalAmountYearly { get; set; }

        //public decimal ActualBudgetTotalAmountYearly { get; set; }
        public Dictionary<int, decimal> BudgetMonthly { get; set; } = new Dictionary<int, decimal>();

        //public decimal[] PlannedBudgetMonthlyArray { get; set; }

        //public decimal[] ActualBudgetMonthlyArray { get; set; }
        //public string PlannedBudgetMonthlyStr { get; set; }

        //public string ActualBudgetMonthlyStr { get; set; }
    }

    public class BudgetReportRequestDTO
    {
        public long? areaId { get; set; }
        public long? appId { get; set; }
        public long? themeId { get; set; }
        public string? search { get; set; }
        public bool? isExport { get; set; }
        public string? docType { get; set; }
        public string? uctMU { get; set; }
        public string? yearVal { get; set; }

        public long? currencyId { get; set; }
        public PaginatorDTO? paginatorDTO { get; set; }
    }


    public class BudgetReportResponseDTO
    {
        public PaginatorDTO? paginatorDTO { get; set; }
        public List<BudgetReportDTO> data { get; set; }
    }
}