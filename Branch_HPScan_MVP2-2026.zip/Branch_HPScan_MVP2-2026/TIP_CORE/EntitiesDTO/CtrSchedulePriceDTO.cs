﻿using System.Text.Json.Serialization;

namespace TIP_CORE.EntitiesDTO
{
    [JsonNumberHandling(JsonNumberHandling.AllowReadingFromString)]
    public class CtrSchedulePriceDTO
    {
        [JsonConverter(typeof(EmptyAsZeroInt64JsonConverter))]
        public long Id { get; set; }
        public long CtrId { get; set; }
        public string? Description { get; set; }
        public string? Units { get; set; }
        public decimal UnitPrc { get; set; }
        public long Quantity { get; set; }
        public long NumberOfTrials { get; set; }
        public decimal TotalPrcEst { get; set; }
        public string? cfCode { get; set; }
        public string? currName { get; set; }
	}
}
