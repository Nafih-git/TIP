﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{
	public class PirInitiationDTO
	{
		public string? CtrIdEnc { get; set; }
		public string? PirIdEnc { get; set; }
		public long Id { get; set; }
		public long CtrId { get; set; }
		public string? RefNo { get; set; }
		public string? UctFp { get; set; }
		public DateTime? FirstTrialCommencementDate { get; set; }
		public DateTime? LastTrialConclutionDate { get; set; }
		public string? AgentName { get; set; }
		public long? NoveltyId { get; set; }
		public long? AvailabilityId { get; set; }
		public string? Source { get; set; }
		public bool? TrialCompleted { get; set; }
		public string? DeploymentScope { get; set; }
		public string? InterimDeploymentScope { get; set; }
		public string? WellType { get; set; }
		public long StatusId { get; set; }
		public long CurrentRleId { get; set; }
		public List<AllPDOUsersDTO>? MandatoryTP { get; set; }
		public List<AllPDOUsersDTO>? OtherTP { get; set; }
	}

	public class PirGeneralInformationDTO
	{
		public string? IdEnc { get; set; }
		public string? CtrIdEnc { get; set; }
		public string? PirIdEnc { get; set; }
		public string? CtrReferenceNumber { get; set; }
		public string? PirReferenceNumber { get; set; }
		public string? CtrTrialTitle { get; set; }
		public string? CtrApplication { get; set; }
		public string? CtrTheme { get; set; }
		public string? CtrSubTheme { get; set; }
		public string? StatusName { get; set; }
		public string? StatusCode { get; set; }
		public string? TechProviderName { get; set; }

		public DateTime? CommencementDate { get; set; }
		public DateTime? ConclusionDate { get; set; }
		public string? AgentName { get; set; }
		public long? Novelty { get; set; }
		public long? Availability { get; set; }
		public string? Source { get; set; }
		public string? TrialCompleted { get; set; }
		public string? DeploymentScope { get; set; }
		public string? InterimScope { get; set; }
		public string? WellType { get; set; }
		public bool IsSubmit { get; set; }


		public long CurrentRleId { get; set; }
		public List<AllPDOUsersDTO>? MandatoryTP { get; set; }
		public List<AllPDOUsersDTO>? OtherTP { get; set; }

	}

	public class PirTrialDetailsDTO
	{
		public string? IdEnc { get; set; }
		public string? TrialType { get; set; }
		public string? TrialledWells { get; set; }
		public string? ChallengesAddressed { get; set; }
		public long CurrentRleId { get; set; }

		public List<AllPDOUsersDTO>? MandatoryTP { get; set; }
		public List<AllPDOUsersDTO>? OtherTP { get; set; }
		public List<AllPDOUsersDTO>? SupportingTeamMembers { get; set; }

	}

	public class PirDeploymentStaircaseDetailsDTO
	{
		public string? IdEnc { get; set; }
		public string? AssumptionMode { get; set; }
		public string? Comments { get; set; }
		public long CurrentRleId { get; set; }

	}

	[DataContract]
	[JsonNumberHandling(JsonNumberHandling.AllowReadingFromString)]
	public class PirVotDTO
	{
		[DataMember]
		public long id { get; set; }
		[DataMember]
		public long pir_id { get; set; }
		[DataMember]
		public long ctr_id { get; set; }
		[DataMember]
		public string? pirCode { get; set; }
		[DataMember]
		public long unit_id { get; set; }
		[DataMember]
		public long? nofUnitTrailScope { get; set; }
		[DataMember]
		public long nofUnitYear1 { get; set; }
		[DataMember]
		public long? nofUnitYear2 { get; set; }
		[DataMember]
		public long? nofUnitYear3 { get; set; }
		[DataMember]
		public long? nofUnitYear4 { get; set; }
		[DataMember]
		public long? nofUnitYear5 { get; set; }
		[DataMember]
		public decimal? techCst { get; set; }

		[DataMember]
		public decimal? otherCst { get; set; }
		[DataMember]
		public decimal? avgIncrementalOilGain { get; set; }
		[DataMember]
		public decimal? totOilAvoidance { get; set; }
		[DataMember]
		public decimal? cstAvoidance { get; set; }
		[DataMember]
		public decimal? co2ruy { get; set; }
		[DataMember]
		public decimal? cspu { get; set; }
		[DataMember]
		public decimal? powerSavingPerUnit { get; set; }
		[DataMember]
		public string? hseBenefits { get; set; }
		[DataMember]
		public string? quality { get; set; }
		[DataMember]
		public string? compliance { get; set; }
		[DataMember]
		public long? riskFactor { get; set; }
		[DataMember]
		public decimal? m3tobbl { get; set; }
		[DataMember]
		public decimal? co2Tax { get; set; }
		[DataMember]
		public decimal? op { get; set; }
		[DataMember]
		public decimal? mwhCst { get; set; }
		[DataMember]
		public decimal? totMWHReductionScope { get; set; }
		[DataMember]
		public decimal? totCO2Reduction { get; set; }
		[DataMember]
		public decimal? votPerUnitPerYear { get; set; }
		[DataMember]
		public decimal? vottrialTotalUnits { get; set; }
		[DataMember]
		public decimal? votTotalDeploymentUnits { get; set; }
		[DataMember]
		public bool isEdit { get; set; }

        public List<PirDeploymentStaircaseDTO>? stairCases { get; set; }
    }

	public class PirWorkFlowDTO
	{
		public string? CtrIdEnc { get; set; }
		public string? PirIdEnc { get; set; }
		public long Id { get; set; }
		public long CtrId { get; set; }
		public string? RefNo { get; set; }
		public string? UctFp { get; set; }
		public long StatusId { get; set; }
		public long CurrentRleId { get; set; }
		public long CurrentApprovalSeq { get; set; }
		public bool isCurrentApprover { get; set; }
		public bool isHoT { get; set; }

		public bool IsSubmit { get; set; }
		public bool IsDraft { get; set; }
		public bool isOfp { get; set; }
		public bool isMfp { get; set; }
		public bool isUCT { get; set; }
		public string? StatusCode { get; set; }
		public string? ADMsg { get; set; }
		public string? StatusName { get; set; }
		public long? SubmitCount { get; set; }
		public string? PirTrialTitle { get; set; }
		public string? SentbackBy { get; set; }
		public List<AllPDOUsersDTO>? mandatoryFP { get; set; }
		public List<AllPDOUsersDTO>? otherFP { get; set; }


	}

	public class PirWorkFlowUpdateDTO
	{
		public string? IdEnc { get; set; }
		public long CurrentRleId { get; set; }
		public string? Comment { get; set; }
		public string? SentbackBy { get; set; }

	}

	public class PirUctChangeDTO
	{
		public string? PirCode { get; set; }
		public AllPDOUsersDTO? NewUctFp { get; set; }
		public long CurrentRleId { get; set; }
	}
	public class PirTrialFPChangeDTO
	{
		public string? PirCode { get; set; }
		public long CurrentRleId { get; set; }
		public List<AllPDOUsersDTO>? MandatoryTP { get; set; }
		public List<AllPDOUsersDTO>? OtherTP { get; set; }
		public string? CurrentMFp { get; set; }
		public string? CurrentOFp { get; set; }

	}

	public class PrintDTO
	{
		public byte[] FileBytes { get; set; }
		public string FileName { get; set; }
		public string Type { get; set; }
	}

	public class ApprovedPirDTO
	{
		public long id { get; set; }
		public string? pirCode { get; set; }
		public string? pirRefNo { get; set; }
		public string? techName { get; set; }
		public string? application { get; set; }
		public decimal? noOfUnitsTrailScope { get; set; }
		public decimal? cspu { get; set; }
		public bool isUCT { get; set; }
		public bool isCH { get; set; }
		public string uctFpName { get; set; }
		public bool? isCreated { get; set; }
		public long votId { get; set; }
		public string? CHFP { get; set; }
		public AllPDOUsersDTO? ChfpDTO { get; set; }

	}

}
