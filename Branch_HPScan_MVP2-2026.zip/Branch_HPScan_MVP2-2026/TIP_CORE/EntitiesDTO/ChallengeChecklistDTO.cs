﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class ChallengeChecklistDTO
    {
        public long id { get; set; }
        public string? question { get; set; }
        public string? answer { get; set; }
    }

    public class CreateChallengeDTO
    {
        public long assessmentId { get; set; }
        public long painAreaId { get; set; }
        public List<ChallengeChecklistDTO> checkList { get; set; }
        
    }



}
