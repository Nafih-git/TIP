﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{
    public class PirApprovalListDTO
    {
        public long Id { get; set; }
        public long PirId { get; set; }
        public string? JobTitle { get; set; }
        public string? JobCode { get; set; }
        public long Seq { get; set; }
        public string? Status { get; set; }
        public string? StatusCode { get; set; }
        public string? Comments { get; set; }
        public string? ActionRequiredBy { get; set; }
        public string? PirCode { get; set; }
        public DateTime? ActionCompletionDate { get; set; }
        public DateTime? ActionAssignedDate { get; set; }
        public AllPDOUsersDTO? ActionBy { get; set; }
        public bool isjobEditable { get; set; }
        public string? URle { get; set; }
        public long CurrentSeq { get; set; }
    }

    public class PirApprovalReminderDTO
    {
        public long Id { get; set; }
        public long PirId { get; set; }
        public string ReferenceNumber { get; set; }
        public string? Approver { get; set; }
        public string? ApproverName { get; set; }
        public string? UctFp { get; set; }
        public string? MandatoryFp { get; set; }
        public DateTime? LastReminder { get; set; }
        public DateTime? SubmittedOn { get; set; }
        public DateTime? SentbackOn { get; set; }
        public DateTime? ActionAssingedDate { get; set; }
    }

    public class PirApproverListDTO
    {
        public long id { get; set; }
        public long pirId { get; set; }
        public long? seq { get; set; }
        public string? approverName { get; set; }
        public string? jobTitle { get; set; }
        public string? status { get; set; }
        public string? statusName { get; set; }
        public DateTime? actionCompletionDate { get; set; }
        public DateTime? actionAssignedDate { get; set; }

    }

    public class PirApprovalDTO
    {
        public string? PirCode { get; set; }
        public long? CurrentRleId { get; set; }
    }
}
