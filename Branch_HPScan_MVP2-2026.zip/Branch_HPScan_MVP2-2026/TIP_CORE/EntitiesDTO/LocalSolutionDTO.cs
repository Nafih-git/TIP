﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
	public class LocalSolutionDTO
	{
		public long id { get; set; }
		public long chaRegId { get; set; }
		public string? tph { get; set; }
		public long? companyId { get; set; }
		public string? title { get; set; }
		public string? description { get; set; }		
		public long sourceId { get; set; }
		public long participateId { get; set; }
		public long? statusId { get; set; }
		public string? status { get; set; }
        public string? cfcode { get; set; }

        public List<FileUploadDTO>? responseFiles { get; set; }
        public List<SRFlowHistoryDTO>? sRFlowHistories { get; set; }

    }
}
