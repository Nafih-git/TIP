﻿namespace TIP_CORE.EntitiesDTO
{
	public class CtrTrialDTO
	{
		public long id { get; set; }
		public long ctrId { get; set; }
		public string cfCode { get; set; }
		public string gate { get; set; }
		public string ownBy { get; set; }
		public string comment { get; set; }
		public List<CtrTrialYearDTO> ctrTrialYear { get; set; }
	}

    public class CtrTrialYearDTO
    {
        public long id { get; set; }
        public long trialId { get; set; }
        public long yearVal { get; set; }
        public bool? q1 { get; set; }
        public bool? q2 { get; set; }
        public bool? q3 { get; set; }
        public bool? q4 { get; set; }
    }
    public class CtrTrialYearRDLCDTO
    {
        public long id { get; set; }
        public long trialId { get; set; }
        public long yearVal { get; set; }
        public bool? q1 { get; set; }
        public bool? q2 { get; set; }
        public bool? q3 { get; set; }
        public bool? q4 { get; set; }
        public string? gate { get; set; }
        public string? remarks { get; set; }
        public string? decisionBy { get; set; }
    }
}
