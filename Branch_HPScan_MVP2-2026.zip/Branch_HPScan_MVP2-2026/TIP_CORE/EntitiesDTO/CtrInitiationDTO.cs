﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using TIP_API.DTO.Admin;
using static TIP_Common.Enum.Enum;

namespace TIP_CORE.EntitiesDTO
{
    [DataContract]
    public class CtrViewPlanDetailsDTO
    {
        [DataMember]
        public long Id { get; set; }
        [DataMember]
        public string? CtrTrialTitle { get; set; }
        [DataMember]
        public string? CTRId { get; set; }
        [DataMember]
        public string? chRefNo { get; set; }

        [DataMember]
        public string? application { get; set; }
        [DataMember]
        public string? theme { get; set; }

        [DataMember]
        public string? subtheme { get; set; }

        [DataMember]
        public string? CtrRefNo { get; set; }
    }


        [DataContract]
    public class CtrInitiationDTO
    {
        [DataMember]
        public long Id { get; set; }
        [DataMember]
        public string? CtrTrialTitle { get; set; }
        [DataMember]
        public long CtrYearStart { get; set; }
        [DataMember]
        public long CtrTechId { get; set; }

        [DataMember]
        public string? CtrChallengeName { get; set; }

        [DataMember]
        public string? CtrChallengeDefinition { get; set; }

        [DataMember]
        public string? ReferenceNumber { get; set; }
        [DataMember]
        public string? TechName { get; set; }
        [DataMember]
        public long StatusId { get; set; }
        [DataMember]
        public string? StatusName { get; set; }
        [DataMember]
        public string? StatusCode { get; set; }
        [DataMember]
        public string? GeneralComments { get; set; }

        [DataMember]
        public string? IdEnc { get; set; }

        public string? CtrTechDescription { get; set; }
        public string? CtrTechMaturity { get; set; }
        public string? CtrTrialObjectives { get; set; }
        public string? CtrTrialWorkplaces { get; set; }
        public string? CtrTrialSelectionCriteria { get; set; }
        public string? CtrBusinessValue { get; set; }
        public string? CtrContractingStratergy { get; set; }
        public string? CtrConfidential { get; set; }

        public decimal? Ctrtrialcst { get; set; }
        public long? Ctrpaymentmilestone { get; set; }

        public bool IsSubmit { get; set; }
        public bool IsDraft { get; set; }

        public AllPDOUsersDTO? MandatoryTP { get; set; }
        public List<AllPDOUsersDTO>? OtherTP { get; set; }
        public List<AllPDOUsersDTO>? CurrentApprovers { get; set; }
        public string? ApproverName { get; set; }

        public bool isOfp { get; set; }
        public bool isMfp { get; set; }
        public bool isUCT { get; set; }
        public bool isOtherUCT { get; set; }

        public bool isHSEAdvisor { get; set; }
        public bool isCE { get; set; }
        public bool isCO { get; set; }
        public bool isPMReadonly { get; set; }  

        public string? ADMsg { get; set; }
        public string? Comment { get; set; }
        public long CurrentRleId { get; set; }

        public string? UctFp { get; set; }
        public string? UctFpName { get; set; }
        public string? UctHeadFpName { get; set; }
        public long CurrentApprovalSeq { get; set; }
        public long SubmitCount { get; set; }
        public bool isCurrentApprover { get; set; }
        public bool isApprovedByCurrent { get; set; }
        public bool isHoT { get; set; }
        public string? CreatedOn { get; set; }
        public string? ApprovedDate { get; set; }
        public string? UpdatedOn { get; set; }
        public string? OldUctFpName { get; set; }
        public string? OldMandatoryFpName { get; set; }
        public string? DeletedApproverName { get; set; }
        public string? SubmissionDate { get; set; }
        public string? SentbackDate { get; set; }
        public string? SentbackBy { get; set; }
        public bool contractCreated { get; set; } = false;
        public string? vendorCode { get; set; }
        public string? ddFileName { get; set; }
        public string? hseFileName { get; set; }
        public string? tcFileName { get; set; }
        public string? ttaFileName { get; set; }
        public string? ddFormatFile { get; set; }

        public long? noTrials { get; set; }
        public long? currId { get; set; }
        public string? currName { get; set; }

        public string? uctFPEmail { get; set; }
        public string? CE { get; set; }
        public string? CE_Email { get;set; }
        public string? vendorcontact { get; set; }
        public List<ProjectMembers>? PMList { get; set; }

        public string? rabitahVendorName { get; set; }
        

    }
    public class ProjectMembers
    {
        public string memberName { get; set; }
        public string roleName { get; set; }
        public bool  isReadOnly { get; set; }
        public string memberMu { get; set; }
        public long roleId { get; set; }
    }

    [DataContract]
    public class CtrInitChallangeDTO
    {
        [DataMember]
        public string? CtrChallengeName { get; set; }

        [DataMember]
        public string? CtrChallengeDefinition { get; set; }
        [DataMember]
        public long? applicationId { get; set; }

        [DataMember]
        public long? themeId { get; set; }

        [DataMember]
        public long? areaId { get; set; }

        [DataMember]
        public long? maturityLId { get; set; }
        [DataMember]
        public string? CtrTitle { get; set; }
    }

    public class CtrVotDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public long ctr_id { get; set; }
        [DataMember]
        public long challenge_id { get; set; }
        public string? ctrCode { get; set; }

        public long unit_id { get; set; }

        public long? nofUnitTrailScope { get; set; }

        public long nofUnitYear1 { get; set; }

        public long? nofUnitYear2 { get; set; }

        public long? nofUnitYear3 { get; set; }

        public long? nofUnitYear4 { get; set; }

        public long? nofUnitYear5 { get; set; }

        public decimal? techCst { get; set; }


        public decimal? otherCst { get; set; }

        public decimal? avgIncrementalOilGain { get; set; }

        public decimal? totOilAvoidance { get; set; }

        public decimal? cstAvoidance { get; set; }

        public decimal? co2ruy { get; set; }

        public decimal? cspu { get; set; }

        public decimal? powerSavingPerUnit { get; set; }

        public string? hseBenefits { get; set; }

        public string? quality { get; set; }

        public string? compliance { get; set; }

        public long? riskFactor { get; set; }

        public decimal? m3tobbl { get; set; }

        public decimal? co2Tax { get; set; }

        public decimal? op { get; set; }

        public decimal? mwhCst { get; set; }

        public decimal? totMWHReductionScope { get; set; }

        public decimal? totCO2Reduction { get; set; }

        public decimal? votPerUnitPerYear { get; set; }

        public decimal? vottrialTotalUnits { get; set; }

        public decimal? votTotalDeploymentUnits { get; set; }

        public bool isEdit { get; set; }

        public string? assumption { get; set; }

        public string? comment { get; set; }

        public List<CtrDeploymentStaircaseDTO>? stairCases { get; set; }
    }

    [BindNever]
    public class CtrTrialRiskDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public long ctrId { get; set; }
        public long? sNo { get; set; }
        public string cfCode { get; set; }

        public string risk { get; set; }
        public string mitigation { get; set; }

    }
    public class CtrUctChangeDTO
    {
        public string? CtrCode { get; set; }
        public AllPDOUsersDTO? NewUctFp { get; set; }
        public long CurrentRleId { get; set; }
    }
    public class CtrTrialFPChangeDTO
    {
        public string? CtrCode { get; set; }
        public long CurrentRleId { get; set; }
        public AllPDOUsersDTO? MandatoryTP { get; set; }
        public List<AllPDOUsersDTO>? OtherTP { get; set; }
        public string? CurrentMFp { get; set; }
        public string? CurrentOFp { get; set; }

    }

    public class CtrUctChange
    {
        public string? NewUctFp { get; set; }
        public string? OldUctFp { get; set; }
        public string? ChnagedBy { get; set; }
    }
    public class ApprovedCtrDTO
    {
        public string? IdEnc { get; set; }
        public string? CtrIdEnc { get; set; }
        public string? PirIdEnc { get; set; }
        public string? ReferenceNumber { get; set; }
        public string? PirReferenceNumber { get; set; }
        public string? CtrTrialTitle { get; set; }
        public string? CtrApplication { get; set; }
        public string? CtrTheme { get; set; }
        public string? CtrSubTheme { get; set; }
        public string? StatusName { get; set; }
        public string? StatusCode { get; set; }
        public bool isUCT { get; set; }
        public bool isMfp { get; set; }
        public bool isOfp { get; set; }
        public bool isPirCreated { get; set; }
        public long Xid { get; set; }
        public bool isCurrentApprover { get; set; }
        public bool isApprovedByCurrent { get; set; }
        public bool isOtherUCT { get; set; }
        public string? UctFp { get; set; }
        public string? UctFpName { get; set; }
        public string? CreatedOn { get; set; }
        public string? ApprovedDate { get; set; }
        public string? MandatoryFPNames { get; set; }


    }


    public class PirCtrInitDTO
    {
        public string? CtrIdEnc { get; set; }
        public string? PirIdEnc { get; set; }
        public string? CtrReferenceNumber { get; set; }
        public string? PirReferenceNumber { get; set; }
        public string? CtrTrialTitle { get; set; }
        public string? CtrApplication { get; set; }
        public string? CtrTheme { get; set; }
        public string? CtrSubTheme { get; set; }
        public string? StatusName { get; set; }
        public string? StatusCode { get; set; }
        public List<AllPDOUsersDTO>? MandatoryTP { get; set; }
        public List<AllPDOUsersDTO>? OtherTP { get; set; }

    }


    public class CTRPRINTDTO
    {
        public byte[] FileBytes { get; set; }
        public string FileName { get; set; }
        public string Type { get; set; }
    }
    public class GetCTRSheetDTO
    {
        public DateTime SheetDate { get; set; }
        public int SheetId { get; set; }
        public int ClusterId { get; set; }
        public PrintType PrintType { get; set; }

    }

    [BindNever]
    public class CtrInitiationSCDTO
    {
        public string? CTRCode { get; set; }
        public string? GeneralComments { get; set; }
    }

    public class emailReminder
    {
        public string? toEmail { get; set; }
        public string? ccEmail { get; set; }
    }
    public class DDFormat
    {
        public string? vendorCode { get; set; }
        public string? cfcode { get; set; }
    }
    public class TcTemplate
    {
        public string? vendorCode { get; set; }
        public string? cfcode { get; set; }
        public string? fp { get; set; }
    }

    public class TTAPrint
    {
        public bool TrialStartngYr { get; set; }
        public bool ChallengeName { get; set; }
        public bool ChallengeDefinition { get; set; }
        public bool TechDesc { get; set; }
        public bool Maturity { get; set; }
        public bool AltSol { get; set; }
        public bool TrialObjectives { get; set; }
        public bool WorkScope { get; set; }
        public bool SelCriteria { get; set; }
        public bool BusinsVal { get; set; }
        public bool TrialContrStartgy { get; set; }
        public bool TrialPlan { get; set; }
        public bool TrialRiskMitig { get; set; }
        public bool SuccessCriteria { get; set; }
        public bool DeplmntStrcs { get; set; }
        public bool Budget { get; set; }
        public string? vendorCode { get; set; }
        public string? cfcode { get; set; }

        public bool trialCst { get; set; }
        public bool Milestone { get; set; }
        public bool schedOfprc { get; set; }

    }

    public class TTAPaymentDTO
    {
        public long ctrId { get; set; }
        public decimal? ctrTrialCst { get; set; }
        public string? ctrPaymentMilestone { get; set; }
    }


    public class ctrPostingDTO
    {
        public string? ctrCode { get; set; }
        public string? vendorCode { get; set; }
        public long? CurrentRleId { get; set; } = 0;
    }

    public class revivePIRDTO
    {
        public string? pirCode { get; set; }
        public string? Comment { get; set; }
        public long CurrentRleId { get; set; } = 0;
    }

    public class GetAllStatusDTO
	{
		public string? ctrStatus { get; set; }
		public string? pirStatus { get; set; }
		public string? execStatus { get; set; }

	}
}

