﻿
namespace TIP_CORE.EntitiesDTO
{
    public class ConfigurationDTO
    {
        public string key { get; set; }
        public string value { get; set; }
        public long Id { get; set; }
        public string type { get; set; }
    }
}
