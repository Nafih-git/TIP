﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    [DataContract]
    public class ChallengePublicationDetailDTO
    {
        [DataMember]
        public decimal CPId { get; set; }
        [DataMember]
        public string CPChallengeRegid { get; set; }
        [DataMember]
        public DateTime? CPSubmissionStartdate { get; set; }
        [DataMember]
        public DateTime? CPSubmissionEnddate { get; set; }
        [DataMember]
        public DateTime? CPQueryEnddate { get; set; }
        [DataMember]
        //public string CPTphRef { get; set; }
        public List<int> sources { get; set; }
    }

    //[DataContract]
    //public class ChallengePublicationSourceDTO
    //{
    //    [DataMember]
    //    public decimal CPSourceId { get; set; }
    //    [DataMember]
    //    public decimal CPChallengeRegid { get; set; }
    //}
}
