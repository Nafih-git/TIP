﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class ResponseDTO
    {
        public string? tphRef { get; set; }
        public long? sourceId { get; set; }
        public long? participant { get; set; }
        public long challengeId { get; set; }   
    }
}
