﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    [DataContract]
    public class BTMAssessmentDTO: BTMAssessmentIP_DTO
    {
        [DataMember]
        public string assetName { get; set; } = "";
        [DataMember]
        public string clusterName { get; set; } = "";
        [DataMember]
        public string departmentName { get; set; } = "";
        [DataMember]
        public string statusName { get; set; } = "";
        [DataMember]
        public string noOfPainArea { get; set; } = "";
        [DataMember]
        public string noOfDrafted { get; set; } = "";
        [DataMember]
        public string noOfSubmitted { get; set; } = "";
        [DataMember]
        public string noOfReviewed { get; set; } = "";

    }
    [DataContract]
    public class BTMAssessmentIP_DTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public long year { get; set; }
        [DataMember]
        public long assetId { get; set; }
        [DataMember]
        public long? clusterId { get; set; }
        [DataMember]
        public long departmentId { get; set; }
        [DataMember]
        public DateTime workshopDate { get; set; }
        [DataMember]
        public long statusId { get; set; }

    }

    [DataContract]
    public class BTMAssessmentFilterDTO
    {
        [DataMember]
        public long year { get; set; } = 0;
        [DataMember]
        public long assetId { get; set; } = 0;
        [DataMember]
        public long clusterId { get; set; } = 0;
        [DataMember]
        public long departmentId { get; set; } = 0;
    }
    
    public class BTMAssessmentKeywordDTO
    {
        public long year { get; set; }
        public string asset { get; set; }
        public string cluster { get; set; }
        public string department { get; set; }
        public string workshopDate { get; set; }
        public string actionStatus { get; set; }
        public string actionBy { get; set; }
        public string actionDate { get; set; }
        public long assetId { get; set; }
        public long? clusterId { get; set; }


    }
}
