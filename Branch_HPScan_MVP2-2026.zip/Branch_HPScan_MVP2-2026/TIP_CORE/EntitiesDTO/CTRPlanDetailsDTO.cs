﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class CTRPlanDetailsDTO
    {
        public long Id { get; set; }
        public long planneddays { get; set; }
        public long sequence { get; set; }
        public long templateid { get; set; }
        public long ctr_id { get; set; }
        public string? startdate { get; set; }
        public string? enddate { get; set; }
        public string? stage { get; set; }
        public long? stageid { get; set; }
        public long? phaseid { get; set; }
        public string? phase { get; set; }
        public string? statusName { get; set; }
        public string? statusCode { get; set; }
        public string? year { get; set; }
        public string? templateName { get; set; }
        public bool? IsSubmit { get; set; }
        public bool? IsCreated { get; set; }
    }
}
