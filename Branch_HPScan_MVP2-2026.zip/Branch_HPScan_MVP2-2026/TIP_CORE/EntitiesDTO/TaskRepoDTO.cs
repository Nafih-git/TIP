﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class TaskRepoDTO
    {
        public long Id { get; set; }
        public string? title { get; set; }
        public string? Link { get; set; }
        public long LinkId { get; set; }
        public string? Type { get; set; }
        public string? ActionBy { get; set; }
        public string? CreatedOn { get; set; }
        public string? DelegatedFrom { get; set; }
        public bool IsDelegated { get; set; }
        public bool IsCompleted { get; set; }

        public string? ActionFrom { get; set; }
        public string? Reference { get; set; }
        public string? ActionRequired { get; set; }
        public string? CryptedRoleId { get; set; }
      
        
    }

    public class PrecisedTaskDTO
    {
        public string? category { get; set; }
        public string? actionRequired { get; set; }
        public int ? count { get; set; }
        public long? requiredRole { get; set; }  
        public string? linktoPage { get; set; }
        public string? requiredRoleName { get; set; }

        public string? title { get; set; }

    }

    public class TaskReportRepoDTO
    {
        public long Id { get; set; }
        public string? title { get; set; }
        public string? Link { get; set; }
        public long LinkId { get; set; }
        public string? Type { get; set; }
        public string? ActionBy { get; set; }
        public string? CreatedOn { get; set; }
        public string? DelegatedFrom { get; set; }
        public bool IsDelegated { get; set; }
        public bool IsCompleted { get; set; }

        public string? ActionFrom { get; set; }
        public string? Reference { get; set; }
        public string? ActionRequired { get; set; }
        public string? CryptedRoleId { get; set; }


    }

    public class PrecisedTaskForReportsDTO
    {
        public string? category { get; set; }
        public string? ActionRequired { get; set; }

        public string? title { get; set; }
        public string? ActionParty { get; set; }
        public string? ref_No { get; set; }
        public string? UCT_FP { get; set; }
 
    }
    public class PrecisedTaskReportMasterDTO
    {
        public List<PrecisedTaskForReportsDTO> allData { get; set; }
        public PaginatorDTO? paginatorDTO { get; set; }
    }

    public class ActiionTaskRequestDTO
    {
        public string? category { get; set; }
        public string? title { get; set; }
        public bool? isFilter { get; set; }
        public bool? isExport { get; set; }
        public string? docType { get; set; }
        public PaginatorDTO? paginatorDTO { get; set; }
    }
}
