﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TIP_CORE.EntitiesDTO
{
    [BindNever]
    public class CtrDeploymentStaircaseDTO
    {
        public long id { get; set; }
        public long? year { get; set; }
        public long? noofwells { get; set; }
        public decimal? estimatedvot { get; set; }
        public string? station { get; set; }
        public long ctrId { get; set; }
        public string ctrCode { get; set; }

    }
	[BindNever]
	public class CtrInitiationDeploymentStaircaseDTO
	{
		public long id { get; set; }
		public string? assumptionMode { get; set; }
		public string? comments { get; set; }
	}

    public class CtrFinalDeploymentStaircaseDTO
    {
        public CtrInitiationDeploymentStaircaseDTO ctrInitiationDeploymentStaircaseDTO { get; set; }
        public List<CtrDeploymentStaircaseDTO> ctrDeploymentStaircaseDTOs { get; set; }
	}
}
