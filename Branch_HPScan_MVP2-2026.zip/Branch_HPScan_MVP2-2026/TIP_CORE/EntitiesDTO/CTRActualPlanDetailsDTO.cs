﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{
    public class CTRActualPlanDetailsDTO
    {
        public long Id { get; set; }
        public long planneddays { get; set; }
        public long sequence { get; set; }
        public long templateid { get; set; }
        public long ctr_id { get; set; }
        public long plan_id { get; set; }
        public long completion { get; set; }
        public long overall_progress_id { get; set; }
        public long status_id { get; set; }
        public string? forecasted_st_date { get; set; }
        public string? forecasted_ed_date { get; set; }
        public string? actualstartdate { get; set; }
        public string? actualenddate { get; set; }
        public string? planstartdate { get; set; }
        public string? planenddate { get; set; }
        public string? comments { get; set; }
        public string? stage { get; set; }
        public string? phase { get; set; }
        public string? statusCode { get; set; }
        public string? statusName { get; set; }
        public bool? IsSubmit { get; set; }
        public bool? IsExecution { get; set; }
        public AllPDOUsersDTO? UCT { get; set; }
        public AllPDOUsersDTO? MFP { get; set; }
        public string? Tech { get; set; }
        public string? overallprogress { get; set; }
        public string? CTRCode { get; set; }
    }
}
