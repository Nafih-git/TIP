﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{
    public class ExecutionActualPlannedTimelineDTO
    {
        public string? CreatedBy { get; set; }
        public string? ExecCode { get; set; }
        public string? ADMsg { get; set; }

        public DateTime? CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public string? USER_DISPLAYName { get; set; }
        public AllPDOUsersDTO? USER_DISPLAY { get; set; }

        public DateTime? UpdatedOn { get; set; }
        public DateTime? SubmittedON { get; set; }

        [DataMember]
        public long? id { get; set; }
        [DataMember]
        public string? plannedstartdate { get; set; }
        [DataMember]
        public string? plannedenddate { get; set; }

        [DataMember]
        public string? actualstartdate { get; set; }
        [DataMember]
        public string? actualdenddate { get; set; }
        [DataMember]
        public string? invoicereviewedby { get; set; }
        [DataMember]
        public string? stage { get; set; }
        [DataMember]
        public string? activity { get; set; }
        [DataMember]
        public long? exec_id { get; set; }

        [DataMember]
        public long? milestone_Type
        {
            get; set;
        }

        [DataMember]
        public string? comments { get; set; }
        [DataMember]
        public string? StatusName { get; set; }
        [DataMember]
        public string? StatusCode { get; set; }
        
        [DataMember]
        public long? completion { get; set; }

        [DataMember]
        public long? overallprogressID { get; set; }

        [DataMember]
        public long? status_id { get; set; }


        [DataMember]
        public long? planned_timeline_id { get; set; }

        [DataMember]
        public bool? Is_Submit { get; set; }
        public bool? isExecutionCreated { get; set; }
        public bool? Is_PaymentMilestone { get; set; } = false;


        [DataMember]
        public DateTime? StartDate { get; set; }
        [DataMember]
        public DateTime? EndDate { get; set; }

      

    }
}
