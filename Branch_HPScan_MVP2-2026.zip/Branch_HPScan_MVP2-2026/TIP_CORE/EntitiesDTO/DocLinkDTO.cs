﻿using System.Runtime.Serialization;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TIP_CORE.EntitiesDTO
{
	[BindNever]
	public class DocLinkDTO
	{
		[DataMember]
		public long id { get; set; }
		public string name { get; set; }
		public string desc { get; set; }
		public string link { get; set; }
	}
}
