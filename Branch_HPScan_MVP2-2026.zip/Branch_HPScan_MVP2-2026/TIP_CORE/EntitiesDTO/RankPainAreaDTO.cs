﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    [DataContract]
    public class RankPainAreaDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public long? year { get; set; }
        [DataMember]
        public string? asset { get; set; }
        [DataMember]
        public long? assetId { get; set; }
        [DataMember]
        public string? cluster { get; set; }
        [DataMember]
        public long? clusterId { get; set; }
        [DataMember]
        public string? department { get; set; }
        [DataMember]
        public long? departmentId { get; set; }
        [DataMember]
        public string? description { get; set; }
        [DataMember]
        public string? owner { get; set; }
        [DataMember]
        public long? rank { get; set; }
        [DataMember]
        public string? workshopDate { get; set; }
    }
}
