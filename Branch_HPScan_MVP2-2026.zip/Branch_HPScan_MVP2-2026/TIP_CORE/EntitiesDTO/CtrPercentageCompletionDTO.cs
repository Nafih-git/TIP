﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class CtrPercentageCompletionDTO
    {
        public long Id { get; set; }
        public long CtrId { get; set; }
        public decimal Percentage { get; set; }
        public decimal EstPrc { get; set; }
        public string? cfCode { get; set; }
		public string? currName { get; set; }

	}
}
