﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;

namespace TIP_CORE.EntitiesDTO
{
    public class PirImpactedExistingContractDTO
    {
        public long Id { get; set; }
        public long PirId { get; set; }
        public string? pirCode { get; set; }
        public string? ContractNo { get; set; }
        public string? ContractTitle { get; set; }
        public string? Contractor { get; set; }
        public string? Impact { get; set; }
     

    }
}
