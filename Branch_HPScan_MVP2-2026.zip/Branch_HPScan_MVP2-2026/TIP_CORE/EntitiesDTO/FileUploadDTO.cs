﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class FileUploadDTO
    {
        public long? id { get; set; }
        public  string? cfcode { get; set; }
        public string? type { get; set; }
        public string? description { get; set; } 
        public bool? isEA { get; set; }
        public string? fileName { get; set; }
        public string? filepath { get; set; }
        public string? fileExtension { get; set; }
        public string? mimeType { get; set; }
        public bool? isNDA { get; set; }
    }

    public class IFormFileDTO
    {
        
        public IFormFile   file { get; set; }
    }
}
