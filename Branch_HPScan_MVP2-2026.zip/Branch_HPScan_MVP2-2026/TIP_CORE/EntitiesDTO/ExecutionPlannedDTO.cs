﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class ExecutionPlannedDTO
    {

        public long? id { get; set; }
        public string? comments { get; set; }
        public string? reason { get; set; }
        public long? exe_ID { get; set; }
        public string? acvValue { get; set; }
        public long? statusId { get; set; }
        public string? exe_Code { get; set; }
        public string? StatusName { get; set; }
        public string? StatusCode { get; set; }
        
        public string? ADMsg { get; set; }
        public string? SentbackBy { get; set; }
        public string? updated_by { get; set; }
        public string? created_by { get; set; }
        public DateTime? created_on { get; set; }
        public DateTime? updated_on { get; set; }
        public bool isUCT { get; set; }
        public bool? isMfp { get; set; }
        public bool? isOfp { get; set; }
        public bool? IsSubmit { get; set; }
        public bool? IsDraft { get; set; }
        public bool? IsApproved { get; set; }


    }
}
