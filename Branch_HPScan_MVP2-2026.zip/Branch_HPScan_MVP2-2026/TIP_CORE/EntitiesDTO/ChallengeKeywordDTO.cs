﻿namespace TIP_CORE.EntitiesDTO
{
    public class ChallengeKeywordDTO
    {
        public string challengeTitle { get; set; }
        public string maturityLevel { get; set; }
        public string area { get; set; }
        public string application { get; set; }
        public string theme { get; set; }
        public string subTheme { get; set; }
        public string allScore { get; set; }
        public string actionStatus { get; set; }
        public string startDate { get; set; }
        public string actionBy { get; set; }
        public string actionCompletionDate { get; set; }
        public string sendrMU { get; set; }
    }
}
