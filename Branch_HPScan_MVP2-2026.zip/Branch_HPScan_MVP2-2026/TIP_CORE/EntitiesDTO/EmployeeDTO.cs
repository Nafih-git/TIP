﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{
    public  class EmployeeDTO
    {
        public string? COMPANY_NUMBER { get; set; }
        public string? DISPLAY_NAME { get; set; }
        public string? EMPLOYEE_NAME { get; set; }
        public string? REFERENCE_INDICATOR { get; set; }
        public string? EMAIL_ADDRESS { get; set; }
        public string? SUPERVISOR_ID { get; set; }
        public long? ACTIVE_R_ID { get; set; }
    }

    public class EmployeeDL
    {
        public string? id { get; set; }
        public string? name { get; set; }
    }
    public class FPEmployeeDL
    {
        public List<EmployeeDL> emp { get; set; }

        //public List<Focalpoint> focalpoint { get; set; }
        public List<Linking> linkingDetails { get; set; }

    }
    public class FPLinkEmployeeDL
    {
        public List<FPEmployeeDL> AssetFP { get; set; }
        public List<FPEmployeeDL> ClusterFp { get; set; }
        public List<FPEmployeeDL> CFDHFP { get; set; }
       
    }



    //public class UserApplicationViewDataD1
    //{
    //    public AllPDOUsersDTO? selectedUser { get; set; }
    //    public List<Focalpoint1>? selectedFPDetails { get; set; }
    //    public List<Focalpoint1>? selectedLinkingDetails { get; set; }

    //}





    public class FocalpointDto 
    {
        public string? userId { get; set; }
        public List<Linking>? LD { get; set; }
        public string? type { get; set; }
    }

    public class Linking
    {
        public long? id { get; set; }
        public string? name { get; set; }
    }
}
