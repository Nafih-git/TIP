﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class ExecutionPlannedTimelinesDTO
    {
        public string? CreatedBy { get; set; }
        public string? ExecCode { get; set; }
        public string? stageId { get; set; }
        public string? ADMsg { get; set; }
        
        public DateTime? CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        [DataMember]
        public long? id { get; set; }
        [DataMember]
        public string? stage { get; set; }
        [DataMember]
        public string? activity { get; set; }
        [DataMember]
        public string? startdate { get; set; }
        [DataMember]
        public string? enddate { get; set; }
        [DataMember]
        public long? planned_days { get; set; }
        [DataMember]
        public long? type1 { get; set; }
        [DataMember]
        public long? cst { get; set; }

        [DataMember]
        public long? exec_id { get; set; }

        [DataMember]
        public long? milestone_Type
        {
            get; set;
        }

        [DataMember]
        public bool? chkDpayment
        {
            get; set;
        }

        [DataMember]
        public bool? chkIsDeliveryMilestone
        {
            get; set;
        }

        [DataMember]
        public bool? IsApproved
        {
            get; set;
        }


        [DataMember]
        public string? partyName { get; set; }

        [DataMember]
        public long? acvValue { get; set; }

        [DataMember]
        public long? SortOrderStage
        {
            get; set;
        }

        [DataMember]
        public long? SortOrderActivity
        {
            get; set;
        }

        [DataMember]
        public DateTime? Start
        {
            get; set;
        }


        [DataMember]
        public DateTime? End
        {
            get; set;
        }
        //Created bby Hafiz Husnain For Report Purpose
        public ExecutionActualPlannedTimelineDTO? ExecutionActualPlannedTimelineDTO { get; set; }

    }
    public class ApprovedExecutionPlannedDTO
    {
        public string? IdEnc { get; set; }
        public string? CtrIdEnc { get; set; }
        public string? EXECIdEnc { get; set; }
        public string? ReferenceNumber { get; set; }
        public string? FP { get; set; }
        public string? EXECReferenceNumber { get; set; }
        public string? TrialTitle { get; set; }
        public string? Application { get; set; }
        public string? theme { get; set; }
        public string? StatusName { get; set; }
        public string? StatusCode { get; set; }
        public string? ContractNo { get; set; }
        public string? acvValue { get; set; }
        public long? totalPot_Value { get; set; }
        public bool isUCT { get; set; }
        public bool isMfp { get; set; }
        public bool IsSubmitted { get; set; }
        public bool isExecutionCreated { get; set; }
        public long Xid { get; set; }
        public bool isCurrentApprover { get; set; }
        public string? UctFp { get; set; }
        public string? reason { get; set; }
    }

        public class InitiatedTrialForExecDTO
    {
        public string? IdEnc { get; set; }
        public string? CtrIdEnc { get; set; }
        public string? EXECIdEnc { get; set; }
        public string? ReferenceNumber { get; set; }
        public string? EXECReferenceNumber { get; set; }
        public string? CtrTrialTitle { get; set; }
        public string? CtrApplication { get; set; }
        public string? CtrTheme { get; set; }
        public string? CtrSubTheme { get; set; }
        public long? statusId { get; set; }
        public string? StatusName { get; set; }
        public string? StatusCode { get; set; }
        public string? ContractNo { get; set; }
        public string? acvValue { get; set; }
        public long? totalPot_Value { get; set; }
        public bool isUCT { get; set; }
        public bool isMfp { get; set; }
        public bool isExecutionTrialCreated { get; set; }
        public long Xid { get; set; }
        public long planId { get; set; }
        public bool IsApproved { get; set; }
        public bool IsSubmitted { get; set; }
        public string? UctFp { get; set; }
        public string? reason { get; set; }

        public string? ADMsg { get; set; }

       

    }

    public class TrialReportResponseDTO
    {
        public PaginatorDTO? paginatorDTO { get; set; }
        public List<InitiatedTrialForExecDTO> data { get; set; }
    }
}
