﻿using System.Runtime.Serialization;

namespace TIP_CORE.EntitiesDTO
{
    [DataContract]
    public class UserRolesDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public string? uniqueValue { get; set; }
        [DataMember]
        public string name { get; set; }
        [DataMember]
        public bool? status { get; set; }
    }
}
