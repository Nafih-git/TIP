﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TIP_CORE.EntitiesDTO
{
	[BindNever]
	public class CtrBudgetDTO
	{
		[DataMember]
		public long id { get; set; }
		[DataMember]
		public long ctrId { get; set; }	
		public string ctrCode { get; set; }		
		public string yearVal { get; set; }		
		public long? qId { get; set; }
		public string resourceDesc { get; set; }
		public string budgetPro { get; set; }
		public string itemPro { get; set; }		
		public string? currName { get; set; }
		public decimal? amount { get; set; }

	
	}
}
