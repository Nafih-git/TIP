﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    [DataContract]
    public class RankPainAreaFilterDTO
    {
        [DataMember]
        public long? year { get; set; }
        [DataMember]
        public long? asset { get; set; }
        [DataMember]
        public long? cluster { get; set; }
        [DataMember]
        public long? department { get; set; }
    }
}
