﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;

namespace TIP_CORE.EntitiesDTO
{
    public class PirFlowHistoryDTO
    {
        public long Id { get; set; }
        public long PirId { get; set; }
        public long? StatusId { get; set; }
        public string? Comments { get; set; }
        public long? RoleId { get; set; }
        public string? UserId { get; set; }
        public string? DescInfo { get; set; }
        public DateTime CreatedOn { get; set; }
        public string? CreatedOnDisplay { get; set; }
        public string? FullName { get; set; }
        public string? Status { get; set; }
    }
}
