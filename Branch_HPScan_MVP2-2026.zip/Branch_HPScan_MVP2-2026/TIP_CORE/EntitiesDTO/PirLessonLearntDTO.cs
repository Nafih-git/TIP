﻿using System.Text.Json.Serialization;

namespace TIP_CORE.EntitiesDTO
{
    [JsonNumberHandling(JsonNumberHandling.AllowReadingFromString)]
    public class PirLessonLearntDTO
    {
        [JsonConverter(typeof(EmptyAsZeroInt64JsonConverter))]
        public long Id { get; set; }
        public string? Description { get; set; }
        public string? CorrectiveMeasures { get; set; }
        public long PirId { get; set; }
        public string? pirCode { get; set; }
    }
}
