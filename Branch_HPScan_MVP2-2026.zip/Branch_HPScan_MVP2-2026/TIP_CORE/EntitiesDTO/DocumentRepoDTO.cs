﻿namespace TIP_CORE.EntitiesDTO
{
    public class DocumentRepoDTO
    {
        public long id { get; set; }
        public long? typeId { get; set; }
        public string type { get; set; }
        public string name { get; set; }
        public string extension { get; set; }
        public string path { get; set; }        
    }

    public class DocumentUploadDTO
    {
		public string code { get; set; }
        public List<FileUploadDTO> files { get; set; }
	}
}
