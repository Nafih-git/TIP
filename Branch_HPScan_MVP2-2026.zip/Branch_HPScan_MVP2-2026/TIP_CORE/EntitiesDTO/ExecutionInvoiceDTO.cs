﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class ExecutionInvoiceDTO
    {

        public long Id { get; set; }
        public long ExeId { get; set; }
        public long AptId { get; set; }
        public DateTime RequestedDate { get; set; }
        public decimal InvoiceAmount { get; set; }
        public DateTime TfpRequestDate { get; set; }
        public DateTime? SentbackDate { get; set; }
        public DateTime? UctReviwedDate { get; set; }
        public DateTime? PaidDate { get; set; }
        public string Comments { get; set; }
        public long StatusId { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CompletedDate { get; set; }
        public string SapFp { get; set; }

    

    }
}
