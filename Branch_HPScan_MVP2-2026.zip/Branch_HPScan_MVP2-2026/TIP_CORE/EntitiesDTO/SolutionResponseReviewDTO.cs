﻿using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TIP_CORE.EntitiesDTO
{
    public class SolutionResponseReviewDTO
    {
        public string reviewCode { get; set; }
        public string review { get; set; }
        public string confirmTech { get; set; }
        public string formStatus { get; set; }
        public string formBy { get; set; }
		public List<QuestionResponseDTO> questions { get; set; }
    }

    public class QuestionResponseDTO
    {
        public long id { get; set; }
        public string? question { get; set; }
        public string? answer { get; set; }
        public string status { get; set; }
    }
}
