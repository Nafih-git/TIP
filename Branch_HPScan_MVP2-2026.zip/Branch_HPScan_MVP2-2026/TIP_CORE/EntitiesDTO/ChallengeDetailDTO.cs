﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{

    [BindNever]
    public class ChallengeDetailDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public string challengeRegId { get; set; }

        public string title { get; set; }

        public string probState { get; set; }

        public string keyReq { get; set; }

        public string currPract { get; set; }

        public string valDrive { get; set; }

        public string opEnvelop { get; set; }

        public string techSpec { get; set; }

        public string? potScoreFC { get; set; }

        public DateTime venSubSD { get; set; }

        public DateTime resLD { get; set; }

        public DateTime queryLD { get; set; }

        public long mId { get; set; }

        public long araId { get; set; }

        public long appId { get; set; }

        public long theId { get; set; }

        public long sTheId { get; set; }

        public string cfdhVal { get; set; }

        public string? scoutKey { get; set; }

        public string status { get; set; }

        public List<string> reviewerMUNo { get; set; }

        public long? hseRisk { get; set; }

        public long? productionIncrease { get; set; }

        public long? co2Reduction { get; set; }

        public long? cstReduction { get; set; }

        public long? overallScore { get; set; }
        public long? requestType { get; set; }
        public long? pillar { get; set; }

        public List<AllPDOUsersDTO>? employeeDTOs { get; set; }

        public List<ChallengeVendorScreeningDTO>? allVSQ { get; set; }

        public ChallengeVOT_DTO? vot { get; set; }

        public List<FileUploadDTO>? files { get; set; }
        public AllPDOUsersDTO? cfdhDTO { get; set; }

        public long? assetId { get; set; }
        public long? clusterId { get;set; }
        public string? cfdh { get; set; }
        public string? uct { get; set; }
        public string? chr { get; set; }
        public DateTime? LastReminder { get; set; }
        public DateTime? actionOn { get; set; }
        public long? ChallengeId { get; set; }
    }

    [DataContract]
    public class ChallengeVOT_DTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public long challenge_id { get; set; }
        [DataMember]
        public string challengeRegId { get; set; }
        [DataMember]
        public long unit_id { get; set; }
        [DataMember]
        public long? nofUnitTrailScope { get; set; }
        [DataMember]
        public long nofUnitYear1 { get; set; }
        [DataMember]
        public long? nofUnitYear2 { get; set; }
        [DataMember]
        public long? nofUnitYear3 { get; set; }
        [DataMember]
        public long? nofUnitYear4 { get; set; }
        [DataMember]
        public long? nofUnitYear5 { get; set; }
        [DataMember]
        public decimal? techCst { get; set; }


        [DataMember]
        public decimal? otherCst { get; set; }
        [DataMember]
        public decimal? avgIncrementalOilGain { get; set; }
        [DataMember]
        public decimal? totOilAvoidance { get; set; }
        [DataMember]
        public decimal? cstAvoidance { get; set; }
        [DataMember]
        public decimal? co2ruy { get; set; }
        [DataMember]
        public decimal? cspu { get; set; }
        [DataMember]
        public decimal? powerSavingPerUnit { get; set; }
        [DataMember]
        public string hseBenefits { get; set; }
        [DataMember]
        public string quality { get; set; }
        [DataMember]
        public string compliance { get; set; }
        [DataMember]
        public long? riskFactor { get; set; }
        [DataMember]
        public decimal? m3tobbl { get; set; }
        [DataMember]
        public decimal? co2Tax { get; set; }
        [DataMember]
        public decimal? op { get; set; }
        [DataMember]
        public decimal? mwhCst { get; set; }
        [DataMember]
        public decimal? totMWHReductionScope { get; set; }
        [DataMember]
        public decimal? totCO2Reduction { get; set; }
        [DataMember]
        public decimal? votPerUnitPerYear { get; set; }
        [DataMember]
        public decimal? vottrialTotalUnits { get; set; }
        [DataMember]
        public decimal? votTotalDeploymentUnits { get; set; }
    }

    
    public class ChallengeQuestionaire_DTO
    {
        
        public string question { get; set; }
        [DataMember]
        public string answer { get; set; }
        
    }

    public class challengePublishDetailsDTO
    {
        public ChallengeDetailDTO? objChallengeDetails { get; set; }
        public string challengeRegId { get; set; }
        public List<int> sources { get; set; }

        public DateTime venSubSD { get; set; }
        [DataMember]
        public DateTime resLD { get; set; }
        [DataMember]
        public DateTime queryLD { get; set; }

    }

    [BindNever]
    public class RegistrationStatusDTO
    {
        public string? status { get; set; }
        public string? schallengeRegId { get; set; }
        public string? comments { get; set; }
    }

    [BindNever]
    public class QueryDTO
    {
        public long? queryId { get; set; }
        public bool? status { get; set; }
        public string? cfcode { get; set; }

    }
}