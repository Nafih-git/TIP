﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class EmailKeywordDTO
    {
        public long id { get; set; }
        public long type { get; set; }
        public string key { get; set; }
        public string value { get; set; }
        
    }
}
