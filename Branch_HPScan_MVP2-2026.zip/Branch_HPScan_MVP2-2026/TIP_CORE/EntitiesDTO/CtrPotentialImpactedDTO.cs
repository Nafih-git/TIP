﻿using System.Runtime.Serialization;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TIP_CORE.EntitiesDTO
{
	[BindNever]
    public partial class CtrPotentialImpactedDTO
	{
		[DataMember]
		public long id { get; set; }
		[DataMember]
		public long ctrId { get; set; }
		public string cfCode { get; set; }
		public string no { get; set; }
        public string title { get; set; }
        public string provider { get; set; }
        public string impact { get; set; }
    }
}
