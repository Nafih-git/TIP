﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class TIP_App_Error_LogsDTO
    {
        public string? Action_name { get; set; }
        public string? CompanyNumber { get; set; }
        public string? Controller_Name { get; set; }
        public string? Error_Message { get; set; }
        public string? Guid { get; set; }
        public string? Ip_Address { get; set; }
        public string? PC_Name { get; set; }
        public string? Stack_Trace { get; set; }
        public string? Inner_Stack { get; set; }
        public string? Inner_Exception { get; set; }
        public DateTime? Log_Date { get; set; }
        public long Id { get; set; }
    }
}
