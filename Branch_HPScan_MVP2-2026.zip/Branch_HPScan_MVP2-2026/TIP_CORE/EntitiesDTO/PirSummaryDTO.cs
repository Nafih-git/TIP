﻿using System.Runtime.Serialization;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace TIP_CORE.EntitiesDTO
{

	[JsonNumberHandling(JsonNumberHandling.AllowReadingFromString)]
	public class PirSummaryDTO
	{
		[DataMember]
		[JsonConverter(typeof(EmptyAsZeroInt64JsonConverter))]
		public long id { get; set; }
		[DataMember]
		[JsonConverter(typeof(EmptyAsZeroInt64JsonConverter))]
		public long pirId { get; set; }
		public string? pirCode { get; set; }		
		public long? trial { get; set; }
		public string desc { get; set; }
	}

	public class PirActionPlanDTO
	{
		[DataMember]
		[JsonConverter(typeof(EmptyAsZeroInt64JsonConverter))]
		public long id { get; set; }
		[DataMember]
		[JsonConverter(typeof(EmptyAsZeroInt64JsonConverter))]
		public long pirId { get; set; }
		public string? pirCode { get; set; }
		public string title { get; set; }
		public string actionParty { get; set; }
		public DateTime? targetDate { get; set; }
	}

	/// <summary>
	/// Angular forms can post id as "", null, or a numeric string. Treat those as 0 (new record).
	/// </summary>
	public class EmptyAsZeroInt64JsonConverter : JsonConverter<long>
	{
		public override long Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
		{
			if (reader.TokenType == JsonTokenType.Null)
				return 0;

			if (reader.TokenType == JsonTokenType.String)
			{
				var s = reader.GetString();
				if (string.IsNullOrWhiteSpace(s))
					return 0;
				return long.TryParse(s, out var parsed) ? parsed : 0;
			}

			if (reader.TokenType == JsonTokenType.Number && reader.TryGetInt64(out var n))
				return n;

			reader.Skip();
			return 0;
		}

		public override void Write(Utf8JsonWriter writer, long value, JsonSerializerOptions options)
			=> writer.WriteNumberValue(value);
	}
}
