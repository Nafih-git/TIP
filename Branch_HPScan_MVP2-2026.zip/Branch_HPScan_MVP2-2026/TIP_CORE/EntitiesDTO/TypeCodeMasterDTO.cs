﻿using System.Runtime.Serialization;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TIP_CORE.EntitiesDTO
{
    [BindNever]
    public class TypeCodeMasterDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public string name { get; set; }
    }
	[BindNever]
	public class TypeCodeMasterDetailDTO: TypeCodeMasterDTO
    {
        public string type { get; set; }     
        public string? desc { get; set; }        
        public string param1 { get; set; }
        public string status { get; set; }
        public string param2 { get; set; }
        public long? parentId { get; set; }
		public string? parentName { get; set; }
        public bool? isEditable { get; set; }

	}
}
