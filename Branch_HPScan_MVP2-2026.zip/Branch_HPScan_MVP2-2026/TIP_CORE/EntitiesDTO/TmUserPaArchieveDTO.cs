﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    [DataContract]
    public class TmUserPaArchieveDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public string? paEnc { get; set; }
        [DataMember]
        public long? extUserid { get; set; }
        [DataMember]
        public DateTime? CreatedOn { get; set; }
    }
}
