﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class RabitahContractDTO
    {
        public string? contractID { get; set; }
        public string? contractType { get; set; }
        public decimal? acvValue { get; set; }
		public DateTime? commenceDate { get; set; }
		public DateTime? exDate { get; set; }
		public string? contractDesc { get; set; }
		public string? contractor { get; set; }
		public string? financeFP { get; set;}
		public string? financeFPRef { get; set; }
		public DateTime? approvedDate { get; set; }


	}
}
