using System;
using System.Collections.Generic;

namespace TIP_CORE.EntitiesDTO
{
    public class AuditLogDto
    {
        public decimal AUDIT_ID { get; set; }
        public string MODULE_NAME { get; set; }
        public string ACTION_TYPE { get; set; }
        public string ENTITY_TYPE { get; set; }
        public string ENTITY_ID { get; set; }
        public string ENTITY_NAME { get; set; }
        public string FIELD_NAME { get; set; }
        public string OLD_VALUE { get; set; }
        public string NEW_VALUE { get; set; }
        public string SUMMARY { get; set; }
        public string COMMENTS { get; set; }
        public string USER_ID { get; set; }
        public string USER_DISPLAY_NAME { get; set; }
        public decimal? ROLE_ID { get; set; }
        public string ROLE_NAME { get; set; }
        public string IP_ADDRESS { get; set; }
        public string CORRELATION_ID { get; set; }
        public string HTTP_METHOD { get; set; }
        public string REQUEST_PATH { get; set; }
        public DateTime? AUDIT_DATE { get; set; }
        public string OLD_JSON { get; set; }
        public string NEW_JSON { get; set; }
        public string REQUEST_JSON { get; set; }
        public string RESPONSE_JSON { get; set; }
    }

    public class AuditLogSearchRequestDto
    {
        public int pageNumber { get; set; } = 1;
        public int pageSize { get; set; } = 15;
        public string? moduleName { get; set; }
        public string? actionType { get; set; }
        public string? entityType { get; set; }
        public string? entityId { get; set; }
        public string? entityName { get; set; }
        public string? userId { get; set; }
        public string? userDisplayName { get; set; }
        public string? roleName { get; set; }
        public string? ipAddress { get; set; }
        public string? correlationId { get; set; }
        public string? httpMethod { get; set; }
        public string? requestPath { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public string? search { get; set; }
        public string? sortColumn { get; set; } = "AUDIT_DATE";
        public string? sortDirection { get; set; } = "DESC";
    }

    public class AuditLogClearRequestDto
    {
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public string? moduleName { get; set; }
        public string? actionType { get; set; }
        public string? entityType { get; set; }
        public string? userId { get; set; }
        public string? comments { get; set; }
    }

    public class AuditLogClearResultDto
    {
        public int deletedCount { get; set; }
        public decimal retainedClearAuditId { get; set; }
    }

    public class AuditLogReportResponseDto
    {
        public List<AuditLogDto> data { get; set; } = new();
        public int totalCount { get; set; }
        public int pageNumber { get; set; }
        public int pageSize { get; set; }
    }

    public class AuditLogWriteRequestDto
    {
        public string? moduleName { get; set; }
        public string? actionType { get; set; }
        public string? entityType { get; set; }
        public string? entityId { get; set; }
        public string? entityName { get; set; }
        public string? fieldName { get; set; }
        public string? oldValue { get; set; }
        public string? newValue { get; set; }
        public string? summary { get; set; }
        public string? comments { get; set; }
        public string? oldJson { get; set; }
        public string? newJson { get; set; }
        public string? requestJson { get; set; }
        public string? responseJson { get; set; }
        public string? httpMethod { get; set; }
        public string? requestPath { get; set; }
        public string? correlationId { get; set; }
        public string? ipAddress { get; set; }
        public string? userId { get; set; }
        public string? userDisplayName { get; set; }
        public decimal? roleId { get; set; }
        public string? roleName { get; set; }
    }
}
