﻿using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TIP_CORE.EntitiesDTO
{
    public class ChallengeResponseReviewDTO
    {
        public long id { get; set; }
        public long chaResId { get; set; }
        public long qId { get; set; }
        public bool? status { get; set; }
        public string answer { get; set; }
        public bool? techStatus { get; set; }
        public string comment { get; set; }
		public string empName { get; set; }

    }

	public class ReviewDetailDTO
    {
		public string empName { get; set; }
		public string muNo { get; set; }

        public bool? IsSr { get; set; }
        public List<ChallengeResponseReviewDTO>? reviewList { get; set; }
	}

	public class ChallengeReviewKeywordDTO
    {
        public string responseNumber { get; set; }
        public long? vendorQId { get; set; }
        public string tphNumber { get; set; }
        public string solutionTitle { get; set; }
        public string technologyTitle { get; set; }
        public string source { get; set; }
        public string vendorName { get; set; }
        public string companyName { get; set; }
        public string actionStatus { get; set; }
        public string actionBy { get; set; }
        public string actionCompletionDate { get; set; }
        public string comment { get; set; }
        public string senderMU { get; set; }    
        public string challengeRef { get; set; }
    }

    public class ChallengPublishKeywordDTO
    {
        public string tphNumber { get; set; }
        public string challengeTitle { get; set; }
        public string startDate { get; set; }
        public string lastDateOfQuery { get; set; }
        public string lastDataOfResponse { get; set; }        
    }
    public class VendorRegistrationKeywordDTO
    {
        public string vendorCategory { get; set; }
        public string type { get; set; }
        public string representation { get; set; }
        public string ManufactureName { get; set; }
        public string countryOrigin { get; set; }
        public string telMobileNumber { get; set; }
        public string address { get; set; }
        public string companyWebsite { get; set; }
        public string contactPerson { get; set; }
        public string contactPersonPhone { get; set; }
    }

    [BindNever]
    public class UpdateSolutionReviewDTO
    {
        public string code { get; set; }
        public string status { get; set; }
        public string comment { get; set; }
    }

    public class SolutionMatrixDTO
    {
		public string code { get; set; }
		public long? complexity { get; set; }
		public long? impact { get; set; }
		public long? decision { get; set; }
	}

    [BindNever]
	public class UpdateConfirmTechDTO
	{
		public string code { get; set; }
		public bool isConfirm { get; set; }
	}
}
