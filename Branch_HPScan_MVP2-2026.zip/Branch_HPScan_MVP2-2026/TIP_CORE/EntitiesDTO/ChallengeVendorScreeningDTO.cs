﻿using System.Runtime.Serialization;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TIP_CORE.EntitiesDTO
{
    [BindNever]
    public class ChallengeVendorScreeningDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public string challengeRegId { get; set; }        
        public long detailId { get; set; }        
        public long sequence { get; set; }
        public string query { get; set; }
    }
}
