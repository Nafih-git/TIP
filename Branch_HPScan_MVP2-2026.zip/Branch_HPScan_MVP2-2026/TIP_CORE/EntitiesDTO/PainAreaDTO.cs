﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{
    [DataContract]
    public class PainAreaDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public string reference { get; set; } = "";
        [DataMember]
        public long assessmentId { get; set; }
        [DataMember]
        public string description { get; set; }
        [DataMember]
        public string raisedBy { get; set; }
        [DataMember]
        public string raisedByName { get; set; }
        [DataMember]
        public long? hsse { get; set; }
        [DataMember]
        public string deferment { get; set; }
        [DataMember]
        public string? cst { get; set; }
        [DataMember]
        public string emission { get; set; }
        [DataMember]
        public string? ntSolution { get; set; }
        [DataMember]
        public string? techFp { get; set; }
        [DataMember]
        
        public AllPDOUsersDTO? selectedTechFp { get; set; }
        public string? techDescription { get; set; }
        
        public long? ntCatalogSolution { get; set; }
        
        public string? uctFp { get; set; }
        
        public string? remarks { get; set; }
        [DataMember]
        public long status { get; set; }
        public string? statusName { get; set; }
        [DataMember]
        public long? ntSource { get; set; }
        public long? clusterId { get; set; }
        public string? clusterName { get; set; }
        public long? rank { get; set; } = 0;
        public long? assetId { get; set; }
        public DateTime? actionDate { get; set; }
        public DateTime? LastReminder { get; set; }
        
    }
    [DataContract]
    public class PainAreaUpdateDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public long rank { get; set; }
    }

    [BindNever]
    public class SubmitAssessment
    {
        public long? AssesmId { get; set; }
    }

  


}
