﻿using System.Runtime.Serialization;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TIP_CORE.EntitiesDTO
{
    [BindNever]
    public class EmailTemplateConfigurationDTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public long typeId { get; set; }        
        public string template { get; set; }        
        public string subject { get; set; }        
        public string body { get; set; }
    }
}
