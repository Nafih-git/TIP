﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{
    [DataContract]
    public class ExecutionTrialfpsDTO
    {
        [DataMember]
        public long Id { get; set; }
        [DataMember]
        public long ExecutionId { get; set; }
        [DataMember]
        public string ExecutionENCId { get; set; }
        [DataMember]
        public string FP { get; set; }
        [DataMember]
        public string? Ref_Ind { get; set; }
        public string? JOB_TITLE { get; set; }
        public AllPDOUsersDTO? USER_DISPLAY { get; set; }
        public string? USER_DISPLAYName { get; set; }

        public bool? IsMandatory { get; set; }

    }
}
