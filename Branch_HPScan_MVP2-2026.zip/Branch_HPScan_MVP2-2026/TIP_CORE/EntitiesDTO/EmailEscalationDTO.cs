﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
	public class EmailEscalationDTO
	{
		public long id { get; set; }
		public string emailEscal { get; set; }
		public string code { get; set; }
		public string type { get; set; }
		public long? days { get; set; }
		public long? escalCount { get; set; }
	}
}
