﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class ExecutionBudgetCostCentreDTO
    {
        public long? budg_Id { get; set; }
        public string budget_provider { get; set; }
        public string contractType { get; set; }
        public string year { get; set; }
        public long? totalValue { get; set; }
        public long? cost_center { get; set; }
    }
}
