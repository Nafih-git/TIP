﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TIP_CORE.EntitiesDTO
{
	[BindNever]
	public class CtrSuccessCriterionDTO
	{
		
		[DataMember]
		public long id { get; set; }
		[DataMember]
		public long ctrId { get; set; }
		public string cfCode { get; set; }
		public string parameter { get; set; }
		public string value { get; set; }
		public string target { get; set; }
		public string? paramName { get; set; }
		public long? paramId { get; set; }
		public string dgImpact { get; set; }
		public string? comment { get; set; }
	}
}
