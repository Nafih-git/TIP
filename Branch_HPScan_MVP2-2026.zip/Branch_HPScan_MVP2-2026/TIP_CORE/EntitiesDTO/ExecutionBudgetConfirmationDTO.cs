﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class ExecutionBudgetConfirmationDTO
    {
        public long? Id { get; set; }
        public string contractNo { get; set; }
        public string? FinanceFPMU { get; set; }
        public decimal? TotalValue { get; set; }
        public long? StatusId { get; set; }
        public string? ADMsg { get; set; }
    }
}
