﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class PirAssessmentTrialResultDTO
    {
        public long Id { get; set; }
        public string? Parameter { get; set; }
        public string? Target { get; set; }
        public long ConclusionId { get; set; }
        public string? Comments { get; set; }
        public long PirId { get; set; }
        public string? pirCode { get; set; }
        public string? Conclusion { get; set; }

    }
}
