﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class CtrAdditionalSolutionDTO
    {
        public long Id { get; set; }
        public long CtrId { get; set; }
        public string? SerialNumber { get; set; }
        public string? SolutionTitle { get; set; }
        public string? Remarks { get; set; }
        public string? CtrCode { get; set; }
    }
}
