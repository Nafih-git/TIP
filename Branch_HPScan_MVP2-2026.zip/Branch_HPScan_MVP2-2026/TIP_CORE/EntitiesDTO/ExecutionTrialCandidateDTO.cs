﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class ExecutionTrialCandidateDTO
    {
        public string? ExecCode { get; set; }
        public long Id { get; set; }
        public long ExecId { get; set; }
        public long TypeId { get; set; }
        public string? Name { get; set; }
        public decimal Cst { get; set; }
        public DateTime? CommencementDate { get; set; }
        public DateTime? ConclusionDate { get; set; }
        public string? ChallengeDescription { get; set; }
        public string? Comments { get; set; }
        public long OutcomeId { get; set; }

        public string? TypeName { get; set; }
        public string? strCommencementDate { get; set; }
        public string? strConclusionDate { get; set; }
    }
}
