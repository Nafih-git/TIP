﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class PirTrialCandidateDTO
    {

        public string? pirCode { get; set; }
        public long Id { get; set; }
        public long PirId { get; set; }
        public long TypeId { get; set; }
        public string? Name { get; set; }
        public decimal Cst { get; set; }
        public DateTime? CommencementDate { get; set; }
        public DateTime? ConclusionDate { get; set; }
        public string? ChallengeDescription { get; set; }
        public string? Comments { get; set; }
        public string? TypeName { get; set; }
        public string? strCommencementDate { get; set; }
        public string? strConclusionDate { get; set; }


    }

    public class CtrTrialCandidateDTO
    {

        public string? ctrCode { get; set; }
        public long Id { get; set; }
        public long CtrId { get; set; }
        public long TypeId { get; set; }
        public string? Name { get; set; }
        public decimal Cst { get; set; }
        public DateTime CommencementDate { get; set; }
        public DateTime? ConclusionDate { get; set; }
        public string? ChallengeDescription { get; set; }
        public string? Comments { get; set; }        
        public string? TypeName { get; set; }
        public string? strCommencementDate { get; set; }
        public string? strConclusionDate { get; set; }


    }
}
