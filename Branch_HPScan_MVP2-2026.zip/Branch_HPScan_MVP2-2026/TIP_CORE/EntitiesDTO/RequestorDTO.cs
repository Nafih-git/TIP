﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class RequestorDTO
    {
        public string name { get; set; }
        public string muNo { get; set; }
        public string email { get; set; }
        public string challenRef { get; set; }
        public string jobTitle { get; set; }
		public bool? isChangeAllow { get; set; }
	}
}
