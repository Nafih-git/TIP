﻿namespace TIP_CORE.EntitiesDTO
{
    public class ChallengeResponseQuestionDTO
    {
        public long responseId { get; set; }
        public string techName { get; set; }
        public string desc { get; set; }
        public bool? isAgreed { get; set; }
        public bool? isCr { get; set; }
        public long? complexity { get; set; }
        public long? impact { get; set; }
        public long? decision { get; set; }
        public string? vendorName { get; set; }

        public string ChallengeRequestor { get; set; }
        public string ChallengeRequestorName { get; set; }
        public List<ResponseQuestions> responseQuestions { get; set; }
    }
    public class ResponseQuestions
    {
        public long id { get; set;}
        public string question { get; set; }
        public bool? status { get; set; }
        public string answer { get; set; }
    }
}
