﻿using System.Runtime.Serialization;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using TIP_CORE.Entities;

namespace TIP_CORE.EntitiesDTO
{

    public class ChallengeRegistrationDetailDTO
    {
        public List<ChallengeRegistrationDTO> challengeRegistrations { get; set; }
        public List<ChallengeStatusCountDTO> challengeStatusCounts { get; set;}
        
    }

    public class ChallengeReviewDTO
    {
        public List<ChallengeRegistrationDTO> challengeRegistrations { get; set; }
        public List<ChallengeRegistrationDTO> takenChallengeRegistrations { get; set; }
    }
    public class ChallengeRegistrationDTO
    {
        public long id { get; set; }
        public string encrptId { get; set; }
        public long year { get; set; }
        public long? assessmentId { get; set; }
        public long? painAreaId { get; set; }
        public string assetName { get; set; }
        public string clusterName { get; set; }
        public string departmentName { get; set; }
        public string painAreaDesc { get; set; }
        public string raisedBy { get; set; }
        public long? rank { get; set; }
        public string title { get; set; }
        public string status { get; set; }
        public string challengeRef { get; set; }
        public string actionByUser { get; set; }
        public string actionByRole { get;set; }
        public string cfdh { get; set; }
        public string actionComment { get; set; }
        public string uctFp { get; set; }
        public string pubReference { get; set; }
        public long? newQurysCount { get; set; }
        public long? qurysCount { get; set; }
        public string? requestType { get; set; }
        public string? accessType { get; set; }

        //Added by Hafiz 
        public long? chadetailId { get; set; }

        public bool? isUCT { get; set; }
        public bool? isCHR { get; set; }
    }


    public class ChallengeResponseReport
    {
        public PaginatorDTO? paginatorDTO { get; set; }
        public List<ChallengeReportDTO> data { get; set; }
    }

    public class ChallengeResponseReportDTO
    {
        public long? areaId { get; set; }
        public long? appId { get; set; }
        public long? themeId { get; set; }
        public string? search { get; set; }
        public bool? isExport { get; set; }
        public string? docType { get; set; }
        public string? uctMU { get; set; }
        public string? yearVal { get; set; }
 
    }


    public class ChallengeReportRequestDTO
    {
        public long? areaId { get; set; }
        public long? appId { get; set; }
        public long? themeId { get; set; }
        public string? search { get; set; }
        public bool? isExport { get; set; }
        public string? docType { get; set; }
        public string? uctMU { get; set; }
        public string? yearVal { get; set; }
        public PaginatorDTO? paginatorDTO { get; set; }
    }

    public class ChallengeReportDTO
    {
        public string chaEncrptId { get; set; }

        public string resEncrptId { get; set; }
        public string Cha_ref { get; set; }
        public string Res_ref { get; set; }
        public string VendorName { get; set; }

        public string TechName { get; set; }
        public string UCTName { get; set; }

        public string UCTMU { get; set; }
        public string SolutionStatus { get; set; }

        public DateTime? SubmittedDate { get; set; }
        public string SubmittedDateStr { get; set; }

        public string IS_CR_Reviewed { get; set; }
        public string IS_CR_Accepted { get; set; }

        public string Cha_RequestorName { get; set; }
        public string Cha_RequestorMU { get; set; }

        public string source { get; set; }

        public string status { get; set; }

        public string ChallengeReviewFormURL { get; set; }

        public string SolutionReviewFormURL { get; set; }

    }


    public class ChallengeStatusCountDTO
    {
        public string name { get; set; }
        public long count { get; set; }
    }
    public class FileDownLoad
    {
        public string Id { get; set; }
        public string type { get; set; }

    }

    public class LatestChallengeDTO
    {
        public string title { get; set; }       
        public string refNo { get; set; }
        public string requestBy { get; set; }
    }

    public class LatestChallengeForExternalDTO
    {
        public string title { get; set; }
        public string refNo { get; set; }
        public string? theme { get; set; }
		public string? subTheme { get; set; }
        public string? startDate { get; set; }
        public string? endDate { get; set; }
        public string? queryEndDate { get; set; }
        public string? description { get; set; }
        public string? publishedDate { get; set; }
        public string? responseStartDate { get; set; }
        public string? statusName { get; set; }
        public long? challengeId { get; set; }
        public string? cfcode { get; set; }
        public string? rspRef { get; set; }
        public string? rspTitle { get; set; }
        public bool? isQueryDateover { get; set; }
        public bool? isResponseDateover { get; set; }
        public long newQurysCount { get; set; }
        public long order { get; set; }
        public string? problemStatement { get; set; }
        public string? keyReq { get; set; }
        public string? curPract { get; set; }
        public string? operatingEnvlp { get; set; }
        public string? technicalSpec { get; set; }
    }

    public  class ScreeningQuestionsDTO
    {
        public long questionID { get; set; }
        public long challenge_id { get; set; }
        public long sequence { get; set; }
        public string question { get; set; }
        public bool? status { get; set; }
        public string? answer { get;set; }
    }
    public class SolutionTechDetailsDTO
    {
        public long? technologyQuestionId { get; set; }
        public string technologyQuestion { get; set; }
        public string? answer { get;set; }
        public string? tooltip { get; set; }
    }




    public class ChallengesForExternalDTO
    {
        public List<LatestChallengeForExternalDTO> newChallenges { get; set; }
        public List<LatestChallengeForExternalDTO> participatedChallenges { get; set; }
    }

    public class VendorResponseDTO
    {

        public long challengeRegistrationId { get; set; }
        public string resReferenceNo { get; set; }
        public string technologyName { get; set; }
        public string technologyDescription { get; set; }
        public string responseStatus { get;set;}
        public bool? isQueryDateover { get; set; }
        public bool? isResponseDateover { get; set; }
       
    }

    public class QueryResponseDTO
    {

        public long id { get; set; }
        public long responseId { get; set; }
        public string query { get; set; }
        public bool hasAttachment { get; set; }
        public DateTime queryDate { get; set; }
        public bool? isPublic { get; set; }
        public bool? isR_Attachment { get; set; }
        public string? response { get; set; }
        public DateTime? responseDate { get; set; }
        public string vendorName { get; set; }
        public string challengeRef { get; set; }
        public string? respondedBy { get; set; }

        public string? LastName { get; set; }
        public string? FirstName { get; set; }
        public string? ReferenceIndicator { get; set; }
        public long? queryId { get; set; }
        public string? solutionTitle { get; set; }
        public bool? isRead { get; set; }

        public string? qId { get; set; }
        public string? rId { get; set; }
        public string? encChl { get; set; }
        public string? chRequestor { get; set; }
        public string? status { get; set; }
        public string? uctFP { get; set; }

    }

    public class VendorResponseDetailsDTO
    {
        public LatestChallengeForExternalDTO challengeDetails { get; set; }
        public List<ScreeningQuestionsDTO> screeningQuestions { get; set; }
        public VendorResponseDTO solutionDetails { get; set; }     
        public List<SolutionTechDetailsDTO> solutionTechDetails { get; set; }
        public List<QueryResponseDTO> queryResponse { get; set; }

        public List<FileUploadDTO>? challengeFiles { get; set; }
        public List<FileUploadDTO>? responseFiles { get; set; }

        public List<SRFlowHistoryDTO>? sRFlowHistories { get; set; }
    }
    public class filesToUpload
    {
        public string filebase64 { get; set; }
        public string cfcode { get; set; }
        public string filename { get; set; }
        public bool isNDA { get; set; }
        public string fileextention { get; set; }
    }

    public class FilesListCls
    {
        public List<filesToUpload> files { get; set; }
        public string cfcode { set; get; }
        public long vendorId { set; get; }
        public string? query { set; get; }
        public long? queryId { set; get; }
        public long? responseId { set; get; }
    }

    public class TechProposalQueries
    {
        public long responded { get; set; }
        public long notResponded { get; set; }
    }
  

    [BindNever]
    public class ChallengeRegistrationDetailFilterDTO
    {
        public long year { get; set; }
        public long asset { get; set; }
        public long cluster { get; set; }
        public long department { get; set; }
    }
	public class PaginatorDTO
	{
		public long currentPage { get; set; }
		public long previousPage { get; set; }
		public long pageSize { get; set; }
		public long totalItem { get; set; }
	}
	public class OverAllReportRequestDTO
    { 
        public long? areaId { get; set; }
        public long? appId { get; set; }
        public long? themeId { get; set; }
		public string? search { get; set; }
		public bool? isExport { get; set; }
        public string? docType { get; set; }
        public string? uctMU { get; set; }
        public string? yearVal { get; set; }
		public PaginatorDTO? paginatorDTO { get; set; }
	}
	public class OverAllReportResponseDTO
	{
		public PaginatorDTO? paginatorDTO { get; set; }
		public List<OverAllDataDTO> allData { get; set; }
	}
    public class OverAllDataDTO
    {
		public string? chaEncrptId { get; set; }
		public string? chaRefNo { get; set; }
		public string? chaTitle { get; set; }
		public string? chaRequestBy { get; set; }
		public string? chaUCT { get; set; }
		public string? chaUCTName { get; set; }
		public string? chaStatus { get; set; }
		public string? resEncrptId { get; set; }
		public string? resRefNo { get; set; }
		public string? resTechName { get; set; }
		public string? resVendor { get; set; }
		public string? resUCT { get; set; }
		public string? resStatus { get; set; }
		public string? resSource { get; set; }
		public string? resStatusParam { get; set; }
		public string? ctrEncrptId { get; set; }
		public string? ctrRefNo { get; set; }
		public string? ctrTrialName { get; set; }
		public string? ctrUCT { get; set; }
		public string? ctrStatus { get; set; }
		public string? pirEncrptId { get; set; }
		public string? pirRefNo { get; set; }
		public string? pirUCT { get; set; }
		public string? pirStatus { get; set; }
		public long? areaId { get; set; }
		public long? appId { get; set; }
		public long? themeId { get; set; }
        public string? approvedYear { get; set;}
        public string ChallengeReviewFormURL { get; set; }
        public string TTAReviewFormURL { get; set; }
        public string PIRReviewFormURL { get; set; }

        public string SolutionReviewFormURL { get; set; }

        public string source { get; set; }
        public string status { get; set; }
    }

	public class TechKPIReportRequestDTO
	{
		public long? areaId { get; set; }
		public long? appId { get; set; }
		public long? themeId { get; set; }
		public string? search { get; set; }
		public bool? isExport { get; set; }
		public string? docType { get; set; }
		public string? uctMU { get; set; }
		public string yearVal { get; set; }
		public PaginatorDTO? paginatorDTO { get; set; }
	}
	public class TechKPIReportResponseDTO
	{
		public PaginatorDTO? paginatorDTO { get; set; }
		public TechKPIConfigDataDTO? techKPIConfigDataDTO { get; set; }
		public List<TechKPIDataDTO> allData { get; set; }
		public string? kpiConfig { get; set; }

	}

	public class TechKPIConfigDataDTO
    {
		public long? preTTADays { get; set; }
		public long? ctrDays { get; set; }
		public long? pirDays { get; set; }
	}

	public class TechKPIDataDTO
	{
		public string? chaEncrptId { get; set; }
		public string? chaRefNo { get; set; }
		public string? chaTitle { get; set; }
		public string? chaUCT { get; set; }
		public string? chaUCTName { get; set; }
		public long? preTTADays { get; set; }
		public string? techTitle { get; set; }
        public long? ctrId { get; set; }
		public string? ctrEncrptId { get; set; }
		public string? ctrUCT { get; set; }
		public string? ctrRefNo { get; set; }
		public string? ctrTitle { get; set; }
		public long? ctrDays { get; set; }
		public string? pirEncrptId { get; set; }
		public string? pirRefNo { get; set; }
		public string? pirUCT { get; set; }
		public long? pirDays { get; set; }
		public long? areaId { get; set; }
		public long? appId { get; set; }
		public long? themeId { get; set; }
		public string? chaStartYear { get; set;}
		public string? ctrStartYear { get; set; }
		public string? pirStartYear { get; set; }

      
        public string? ctrapprovedYear { get; set; }
        public string? pirapprovedYear { get; set; }

        public string ChallengeReviewFormURL { get; set; }

        public string SolutionReviewFormURL { get; set; }
        public string TTAReviewFormURL { get; set; }

        public string PIRReviewFormURL { get; set; }
    }

	public class TechKPIReportData
    {
		public long? chaSubmittedDays { get; set; }
		public long? chaCFDHDays { get; set; }
		public long? chaPublishedDays { get; set; }
		public long? resRespondDays { get; set; }
		public long? resReviewedDays { get; set; }
		public long? ctrDraftedDays { get; set; }
		public long? ctrApprovedDays { get; set; }
		public long? pirDraftedDays { get; set; }
		public long? pirApprovedDays { get; set; }
	}

	public class MasterReportRequestDTO
	{
		public long? areaId { get; set; }
		public long? appId { get; set; }
		public long? themeId { get; set; }
		public string? search { get; set; }
		public bool? isExport { get; set; }
		public string? docType { get; set; }
		public string? uctMU { get; set; }
		public PaginatorDTO? paginatorDTO { get; set; }
	}

    public class MasterReportResponseDTO
    {
		public PaginatorDTO? paginatorDTO { get; set; }
		public List<MasterSheetDataDTO> allData { get; set; }
	}

    public class MasterSheetDataDTO
    {
        public string? techName { get; set; }
        public long? ctrId { get; set; }
        public long? pirId { get; set; }
		public long? areaId { get; set; }
		public long? appId { get; set; }
		public long? themeId { get; set; }
		public string? status { get; set; }
		public long? techStatusId { get; set; }
		public string? uctFPName { get; set; }
		public string? ctrUCT { get; set; }
		public string? ctrRefNo { get; set; }
		public string? pirUCT { get; set; }
		public string? pirRefNo { get; set; }
		public string? trialFP { get; set; }
        public string? theme { get; set; }
        public string? contractType { get; set; }        
        public DateTime? poDate { get; set; }
        public DateTime? pirApprovedDate { get; set; }
        public decimal? acv { get; set; }
        public decimal? budget2024 { get; set; }
        public decimal? budget2025 { get; set; }
        public decimal? budget2026 { get; set; }
        public decimal? budget2027 { get; set; }
        public string? budgetPro { get; set; }
        public decimal? avgIncrementalOilGain { get; set; }
        public decimal? cspu { get; set; }
        public decimal? votTotalDeploymentUnits { get; set; }
        public List<DepDataDTO>? depDataDTO { get; set; }
		public string? q1Year { get; set; }
		public string? q2Year { get; set; }
		public string? q3Year { get; set; }
		public string? q4Year { get; set; }
		public string? q5Year { get; set; }
		public string? q6Year { get; set; }
		public string? q7Year { get; set; }
		public string? q8Year { get; set; }

	}

	public class DepDataDTO
	{
		public string? qYear { get; set; }
		public decimal? planScope { get; set; }
		public decimal? actualScope { get; set; }
		public decimal? planVOT { get; set; }
		public decimal? actualVOT { get; set; }
	}

	public class ReportPrintDTO
	{
		public byte[] FileBytes { get; set; }
		public string FileName { get; set; }
		public string Type { get; set; }
	}
}
