﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class ExternalUserDTO
    {
        public long id { get; set; }
        public string? firstName { get; set; }
        public string? lastName { get; set; }
        public string? displayName { get; set; }
        public string? companyName { get; set; }
        public string? emailaddress { get; set; }
        public string? pname { get; set; }
        public string? phoneNumber { get; set; }
        public long? sourceId { get; set; }
        public string? source { get; set; }
        public string? sourceParam { get; set; }
        public string? description { get; set; }
        public bool? isActive { get; set; }
        public DateTime? lastLogin { get; set; }
        public long? otpCODE { get; set; }
        public DateTime? otpTIME { get; set; }
        public bool? val_Bit { get; set; }
        public string? message { get; set; }
        public string? UserCategory { get; set; }
        public string? type { get; set; }
        public string? representation { get; set; }
        public string? manufacturername { get; set; }
        public string? countryorign { get; set; }
        public string? commercialregNo { get; set; }
        public DateTime? commercialregExpDate { get; set; }
        public string? address { get; set; }
        public string? companywebsite { get; set; }
        public string? contactperson { get; set; }
        public string? contPerPhoneNumber { get; set; }
        public string? cpb { get; set; }
        public string? createpaLink { get; set; }
    }

    public class ExternalContactUs
    {
        public long id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string emailAddress { get; set; }
        public string message { get; set; }
    }
}
