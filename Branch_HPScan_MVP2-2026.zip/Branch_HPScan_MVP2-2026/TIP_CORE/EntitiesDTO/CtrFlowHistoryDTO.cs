﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class CtrFlowHistoryDTO
    {
        public long Id { get; set; }
        public long CtrId { get; set; }
        public long StatusId { get; set; }
        public string? Comments { get; set; }
        public long RoleId { get; set; }
        public string? UserId { get; set; }
        public string? FullName { get; set; }
        public string? Status { get; set; }
		public string? DescInfo { get; set; }
        public DateTime CreatedOn { get; set; }
        public string? CreatedOnDisplay { get; set; }
    }
    public class ChlFlowHistoryDTO
    {
        public long Id { get; set; }
        public long ChallengeId { get; set; }
        public long StatusId { get; set; }
        public string? Comments { get; set; }
        public long RoleId { get; set; }
        public string? UserId { get; set; }
        public string? FullName { get; set; }
        public string? Status { get; set; }
        public string? DescInfo { get; set; }
        public DateTime CreatedOn { get; set; }
        public string? CreatedOnDisplay { get; set; }
    }
    public class SRFlowHistoryDTO
    {
        public long Id { get; set; }
        public long ChallengeResponseId { get; set; }
        public long StatusId { get; set; }
        public string? Comments { get; set; }
        public long RoleId { get; set; }
        public string? UserId { get; set; }
        public string? FullName { get; set; }
        public string? Status { get; set; }
        public string? DescInfo { get; set; }
        public DateTime CreatedOn { get; set; }
        public string? CreatedOnDisplay { get; set; }
        public bool? isExternal { get; set; }
        public string? actionForExternal { get; set; }
        
    }
}
