﻿namespace TIP_CORE.EntitiesDTO
{
    public class EmailSendConfigDTO
    {
        public long moduleId { get; set; }
        public long templateId { get; set; }
        public string templateCode { get; set; }
        public string subject { get; set; }
        public string body { get; set; }
        public List<string> toRecipients { get; set; }
        public List<string> ccRecipients { get; set; }        
        public List<string> keywords { get; set; }
        public string? attachment { get; set; }
        public string? attachmentname { get; set; }
        public List<string> RecipientsNames { get; set; }
    }
}
