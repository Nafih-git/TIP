﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class CtrTechConfigurationDTO
    {
       
            public long Id { get; set; }
            public long planId { get; set; }
            public string? phase { get; set; }
            public string? stage { get; set; }
            public long? stageid { get; set; }
            public long sequence { get; set; }
            public long planneddays { get; set; }
        public long? phaseid { get; set; }

    }

    public class TechnologyKPIDTO
    {
        public long? id { get; set; }
        public long? year { get; set; }
        public long? statusId { get; set; }
        public long? maxdays { get; set; }
        public string? sectionName { get; set; }
        public string? stateName { get; set; }        
    }

    public class TechKPIList
    {
        public List<TechnologyKPIDTO> list { get; set; }    
    }
}
