﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class ExecutionPotentialValueDTO
    {
        public long? id { get; set; }
        public long? year { get; set; }
        public long? noofwells { get; set; }
        public decimal? value { get; set; }
        public string station { get; set; }
        public long? execid { get; set; }
    }
}
