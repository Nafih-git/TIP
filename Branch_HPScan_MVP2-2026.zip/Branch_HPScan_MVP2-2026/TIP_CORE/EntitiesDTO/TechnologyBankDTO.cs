﻿using System.Runtime.Serialization;

namespace TIP_CORE.EntitiesDTO
{
    public class TechnologyBankDTO
    {
        public long id { get; set; }
        public string title { get; set; }
        public string area { get; set; }
        public string? theme { get; set; }
        public string? subTheme { get; set; }
        public string? application { get; set; }
        public string? source { get; set; }
     
        public string contactFoculPoint { get; set; }
        public string description { get; set; }
        public long? areaId { get; set; }
        public long? themeId { get; set; }
        public long? subThemeId { get; set; }
        public long? applicationId { get; set; }
        public long? sourceId { get; set; }
        [DataMember]
        public string contactEmail { get; set; }
        public string? status { get; set; }
        public string? statusCode { get; set; }
        public bool isInternalCreated { get; set; }
        public bool isCTRCreated { get; set; }
        public string ctrCreatedStatus { get; set; }
        public string? ctrChallengeName { get; set; }
        public string? ctrChallengeDef { get; set; }
        public string? challengeResponseId { get; set; }
        public string? challengeRef { get; set; }
        public string? responseRef { get; set; }

        public string? encCfcode { get; set; }
        public string? encRespCode { get; set; }
        public bool? isCRRecord { get; set; }

        public long? assetId { get; set; }
        public long? clusterId { get; set; }
        public string? SubmittedDate { get; set; }
        public string? VendorName { get; set; }
        public string? UCTNFpName { get; set; }

    }

    [DataContract]
    public class TechnologyBankIP_DTO
    {
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public string title { get; set; }
        [DataMember]
        public string? description { get; set; }
        [DataMember]
        public long? areaId { get; set; }
        [DataMember]
        public long? themeId { get; set; }
        [DataMember]
        public long? subThemeId { get; set; }
        [DataMember]
        public long? applicationId { get; set; }
        [DataMember]
        public long? sourceId { get; set; }
        [DataMember]
        public string contactFocalPoint { get; set; }
        [DataMember]
        public string contactEmail { get; set; }

        public long? assetId { get; set; }
        public long? clusterId { get; set; }

    }
}
