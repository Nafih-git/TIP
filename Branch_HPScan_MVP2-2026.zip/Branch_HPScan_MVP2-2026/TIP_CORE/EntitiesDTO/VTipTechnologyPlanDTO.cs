﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    public class VTipTechnologyPlanDTO
    {
        public long? CtrId { get; set; }
        public long? TechId { get; set; }
        public string Title { get; set; }
        public long? PhaseId { get; set; }
        public string PhaseName { get; set; }
        public long? StageId { get; set; }
        public string StageName { get; set; }
        public long? Planneddays { get; set; }
        public string? Plannedstartdate { get; set; }
        public string? Plannedenddate { get; set; }
        public string? Actualstartdate { get; set; }
        public string? Actualenddate { get; set; }
        public decimal? Actualdiff { get; set; }
        public decimal? Completion { get; set; }
        public long? Sequence { get; set; }
    }
}
