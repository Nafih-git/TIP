﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{
	[BindNever]
	public class DepVotDTO : DepVotBaseDTO
	{
		public long? UnitId { get; set; }
		public string? UnitName { get; set; }
		public decimal? NoOfUnitsTrailScope { get; set; }
		public decimal? TechCost { get; set; }
		public decimal? OtherCost { get; set; }
		public decimal? AvgIncrmntlOilGain { get; set; }
		public decimal? TotOilDefermentAvoidance { get; set; }
		public decimal? CostSavingUnitYr { get; set; }
		public decimal? PowerSavingUnitYr { get; set; }
		public long? CostAvoidance { get; set; }
		public decimal? Co2ReductnUnitYr { get; set; }
		public long? RiskFactor { get; set; }
		public decimal? M3T0Bbl { get; set; }
		public decimal? Co2Tax { get; set; }
		public decimal? MwhCost { get; set; }
		public decimal? OilPrice { get; set; }
		public long? TotalMwhReduction { get; set; }
		public long? TotalCo2Reduction { get; set; }
		public decimal? VotUnitYear { get; set; }
		public decimal? VotTrailTotUnits { get; set; }
		public long? VotTotDeploymentUnits { get; set; }
		public string Techname { get; set; }
		public long? QYear { get; set; }
		public string? QYearName { get; set; }
		public long? DeployedTo { get; set; }
		public decimal? ScopeCountQtr { get; set; }
		public decimal? IncrmntlOilGain { get; set; }
		public decimal? DefermentAvoidance { get; set; }
		public decimal? CostSavingUnitQtr { get; set; }
		public decimal? PowerSaving { get; set; }
		public decimal? Co2Reduction { get; set; }
		public decimal? TechnologyCost { get; set; }
		public decimal? OtherCostQtr { get; set; }
		public decimal? TotalVotQtr { get; set; }
		public string? FinalComments { get; set; }
		public string PirRefNo { get; set; }
		public string DepCode { get; set; }
		public long? PirId { get; set; }
		public string? Status { get; set; }
		public long? DepId { get; set; }
	}
	public class DepVotBaseDTO
	{
		public long Id { get; set; }
		public string PirCode { get; set; }
		public string? Uctfp { get; set; }
		public string? Chfp { get; set; }
		public AllPDOUsersDTO? ChfpDTO { get; set; }
	}

	public class DepVotEmailDTO
	{
		public long id { get; set; }
		public long votId { get; set; }
		public string pirRefNo { get; set; }
		public AllPDOUsersDTO? contractHolderDetails { get; set; }
		public AllPDOUsersDTO? oldContractHolderDetails { get; set; }
		public AllPDOUsersDTO? uctDetails { get; set; }
		public AllPDOUsersDTO? uctFPDetails { get; set; }
		public AllPDOUsersDTO? oldUCTFPDetails { get; set; }
		public string techName { get; set; }
		public string actionBy { get; set; }
		public string actionCompletionDate { get; set; }
		public string? quarter { get; set; }
		public string? pirCode { get; set; }
		public DateTime? updatedOn { get; set; }
		public DateTime? lastReminder { get; set; }

	}


    [DataContract]
    public class DepReassignmentDTO 
	{
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public string techName { get; set; }
        [DataMember]
        public string muNo { get; set; }
        public string UCTmuNo { get; set; }
        [DataMember]
        public string advisorName { get; set; }
        [DataMember]
        public string statusName { get; set; }
        [DataMember]
        public string pirRefNo { get; set; }
    
    }



    [DataContract]
    public class DeploymentTrialfpsDTO
    {
        [DataMember]
        public long Id { get; set; }
        [DataMember]
        public long DepId { get; set; }
        [DataMember]
        public string DepIdENCId { get; set; }
        [DataMember]
        public string FP { get; set; }
        [DataMember]
        public string? Ref_Ind { get; set; }
        public string? JOB_TITLE { get; set; }
        public AllPDOUsersDTO? USER_DISPLAY { get; set; }
        public string? USER_DISPLAYName { get; set; }

        public bool? IsMandatory { get; set; }

    }

    public class postdeployRessign
    {
        public string? MU { get; set; }
        public long? DepId { get; set; }
    }

    public class postUCTdeployRessign
    {
        public string? MU { get; set; }
        public long? DepId { get; set; }
        public long? roleId { get; set; }
    }
}
