﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{
    public class PirEmailDTO
    {
        public string? CtrIdEnc { get; set; }
        public string? PirIdEnc { get; set; }
        public string? ReferenceNumber { get; set; }
        public string? UctFp { get; set; }
        public string? UctFpName { get; set; }
        public DateTime? FirstTrialCommencementDate { get; set; }
        public DateTime? LastTrialConclutionDate { get; set; }
        public string? UpdatedOn { get; set; }
        public string? SubmissionDate { get; set; }
        public string? SentbackDate { get; set; }
        public string? AgentName { get; set; }
        public long? NoveltyId { get; set; }
        public long? AvailabilityId { get; set; }
        public string? Source { get; set; }
        public bool? TrialCompleted { get; set; }
        public string? DeploymentScope { get; set; }
        public string? InterimDeploymentScope { get; set; }
        public string? WellType { get; set; }
        public long StatusId { get; set; }
        public long CurrentRleId { get; set; }
        public List<AllPDOUsersDTO>? MandatoryTP { get; set; }
        public List<AllPDOUsersDTO>? OtherTP { get; set; }
        public List<AllPDOUsersDTO>? CurrentApprovers { get; set; }
        public string? ApproverName { get; set; }
        public string? DeletedApproverName { get; set; }
        public string? OldMandatoryFpName { get; set; }
        public string? NewMandatoryFpName { get; set; }
        public string? OldUctFpName { get; set; }

        public bool IsSubmit { get; set; }
        public bool IsDraft { get; set; }
        public long CurrentApprovalSeq { get; set; }
        
    }

}
