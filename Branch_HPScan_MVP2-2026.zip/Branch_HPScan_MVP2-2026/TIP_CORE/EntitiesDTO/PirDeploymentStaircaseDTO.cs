﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{
    [JsonNumberHandling(JsonNumberHandling.AllowReadingFromString)]
    public class PirDeploymentStaircaseDTO
    {
        public long Id { get; set; }
        public long PirId { get; set; }
        public string? FeildStationName { get; set; }
        public string? WellType { get; set; }
        public long Year { get; set; }
        public long NoOfWells { get; set; }
        public decimal EstimatedVot { get; set; }
        public string? AssumptionMode { get; set; }
        public string? Comments { get; set; }
        public string? pirCode { get; set; }
    }
}
