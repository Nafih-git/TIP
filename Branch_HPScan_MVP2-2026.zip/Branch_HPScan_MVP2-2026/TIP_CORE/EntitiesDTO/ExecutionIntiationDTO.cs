﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;

namespace TIP_CORE.EntitiesDTO
{
    public class ExecutionIntiationDTO
    {
        public string? statusId { get; set; }
        public string? contractNo { get; set; }
        public string? contractType { get; set; }
        public string? initiatemonth { get; set; }
        public string? startmonth { get; set; }
        public long? maturityLevelId { get; set; }
        public long? areaId { get; set; }
        public long? themeId { get; set; }
        public long? applicationId { get; set; }
        public long? assetId { get; set; }
        public long? clusterId { get; set; }
        public long? AcvValue { get; set; }
        public string? ADMsg { get; set; }
        public long ctrId { get; set; }
        public long id { get; set; }
        public string? CtrIdEnc { get; set; }
        public string? ExecIdEnc { get; set; }
        public string? trialtitle { get; set; }
        public string? challengetitle { get; set; }
        public string? UpdatedByRef { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string? submitted_on { get; set; }
        public string? uctFP { get; set; }
        public bool? isUCT { get; set; }
        //public List<AllPDOUsersDTO>? MandatoryTP { get; set; }
        //public List<AllPDOUsersDTO>? OtherTP { get; set; }
    }

    public class ExecutionEmailDTO
    {
        public string? statusId { get; set; }
        public string? contractNo { get; set; }
        public string? contractType { get; set; }
        public string? initiatemonth { get; set; }
        public string? startmonth { get; set; }
        public long? maturityLevelId { get; set; }
        public long? areaId { get; set; }
        public long? themeId { get; set; }
        public long? applicationId { get; set; }
        public long? assetId { get; set; }
        public long? clusterId { get; set; }
        public string? AcvValue { get; set; }
        public string? ADMsg { get; set; }
        public long ctrId { get; set; }
        public long id { get; set; }
        public string? CtrIdEnc { get; set; }
        public string? ExecIdEnc { get; set; }
        public string? trialtitle { get; set; }
        public string? challengetitle { get; set; }
        public string? UpdatedByRef { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string? submitted_on { get; set; }
        public AllPDOUsersDTO? MandatoryTP { get; set; }
        public AllPDOUsersDTO? UCT_FP { get; set; }        
        public AllPDOUsersDTO? oldFpDetails { get; set; }
        public List<AllPDOUsersDTO>? OtherTP { get; set; }
        public AllPDOUsersDTO? InvoiceReviewer { get; set; }
        public List<AllPDOUsersDTO>? SapSustainers { get; set; }
        public string? oldUctFPName { get; set; }
        public string? oldMTFPName { get; set; }
        public string? ReferenceNumber { get; set; }

        public string? plan_SubmissionDate { get; set; }
        
        public string? plan_SentbackDate { get; set; }
        public string? InitiatedDate { get; set; }

        public string? actual_SubmissionDate { get; set; }

        public string? overallProgress { get; set; }
        public decimal? overallprogressid { get; set; }
        public string? actualStartDate { get; set; }    
        public string? actualEndADate { get; set; }
        public string? actualPlanComment { get; set; }  

        public string? invReqDate { get; set; }
        public string? invComments { get; set; }

        public decimal? InvoiceAmount { get; set; }

    }

    public class ApprovedCtrForExecDTO
    {
        public string? IdEnc { get; set; }
        public string? CtrIdEnc { get; set; }
        public string? EXECIdEnc { get; set; }
        public string? ReferenceNumber { get; set; }
        public string? EXECReferenceNumber { get; set; }
        public string? CtrTrialTitle { get; set; }
        public string? CtrApplication { get; set; }
        public string? CtrTheme { get; set; }
        public string? CtrSubTheme { get; set; }
        public string? StatusName { get; set; }
        public string? StatusCode { get; set; }
        public bool isUCT { get; set; }
        public bool isMfp { get; set; }
        public bool isExecutionTrialCreated { get; set; }
        public long Xid { get; set; }
        public bool isCurrentApprover { get; set; }
        public string? UctFp { get; set; }
        public string? ADMsg { get; set; }

    }

    public class InitiatedExecDTO
    {
        public string? IdEnc { get; set; }
        public string? CtrIdEnc { get; set; }
        public string? EXECIdEnc { get; set; }
        public string? ReferenceNumber { get; set; }
        public string? CTRReferenceNumber { get; set; }
        public string? TrialName { get; set; }
        public string? Application { get; set; }
        public string? Contractnumber { get; set; }
        public string? ACVValue { get; set; }
        public string? TotalPOTValue { get; set; }
        public string? StatusCode { get; set; }
        public bool isUCT { get; set; }
        public bool isMfp { get; set; }
        public long Xid { get; set; }
        public string? UctFp { get; set; }

    }

    public class ExecutionReAssisgnDTO
    {
        public long? execId { get; set; }
        public long? ttaId { get; set; }
        public string? ttaRefNo { get; set; }
        public string? trialName { get; set; }
        public string? statusName { get; set; }
        public string? muNo { get; set; }
        public string? advisorName { get; set; }

    }

    public class ExecutionReassignChangeDTO
    {
        public long ExecId { get; set; }
        public AllPDOUsersDTO? NewAdvisor { get; set; }
        public long CurrentRold { get; set; }
        public string CurrentMu { get; set; }
    }

    #region  Invoice Register

    public class InvoiceRequestDTO
    {
        public string? ExeCode { get; set; }
        public string? ContractNo { get; set; }
        public string? Trialtitle { get; set; }
        public string? ApplicationName { get; set; }
        public decimal AcvValue { get; set; }
        public long InvCount { get; set; }
    }

    public class InvoiceRequestDetailsDTO
    {
        public long ID { get; set; }
        public long APT_ID { get; set; }
        public long EXEC_ID { get; set; }
        public string? STAGE { get; set; }
        public string? ACTIVITY { get; set; }
        public DateTime? REQUESTED_DATE { get; set; }
        public decimal INVOICED_AMOUNT { get; set; }
        public string? STATUS { get; set; }
        public long STATUS_ID { get; set; }
        public DateTime? PAID_DATE { get; set; } = DateTime.Today;
        public string? COMMENTS { get; set; }
    }

    #endregion

    public class ExecutionEscDTO
    {
        [BindNever]
        public long? id { get; set; }
        public long? execId { get; set; }
        public long? ttaId { get; set; }
        public string? uctFP { get; set; }
        public string? uctName { get; set; }
        public string? uctEmailAddress { get; set; }
        public string? mendatoryName { get; set; }
        public string? mendatoryEmailAddress { get; set; }
        public DateTime? updatedOn { get; set; }
        public DateTime? lastReminder { get; set; }
        public DateTime? createOn { get; set; }
        public List<string>? oFPs { get; set; }
        public string? ttaRefNo { get; set; }
        public DateTime? submittedDate { get; set; }
    }
    public class postExec
    {
        public string? ExecEnc { get; set; }
        public string? Is_Created { get; set; }
        public long? rold { get; set; }
        public string? CtrIdEnc { get; set; }
        public string? execId { get; set; }
    }
}
