﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TIP_CORE.EntitiesDTO
{

    [DataContract]
    public class TechnologyStatusReportDTO { 
        [DataMember]
        public long id { get; set; }
        [DataMember]
        public string? CTRref { get; set; }
        [DataMember]
        public string? asset { get; set; }
        [DataMember]
        public string? application { get; set; }
        [DataMember]
        public string? theme { get; set; }
        [DataMember]
        public string? phase { get; set; }
        [DataMember]
        public string? directorate { get; set; }
        [DataMember]

        public string? ovrtallprogressStatus { get; set; }

        [DataMember]
        public string? maturity { get; set; }
        [DataMember]
        public string TechName { get; set; }
        [DataMember]
        public string TrialName { get; set; }
        [DataMember]
        public string ScopePlanned { get; set; }
        [DataMember]
        public string ScopeActual { get; set; }
        [DataMember]
        public string costSavingPlan { get; set; }
        [DataMember]
        public string costSavingactual { get; set; }
        [DataMember]
        public string prodIncPlan { get; set; }
        [DataMember]
        public string prodIncActual { get; set; }
        [DataMember]
        public string potValue { get; set; }
        [DataMember]
        public decimal regretValue { get; set; }

        [DataMember]
        public List<TechnologyPhase>? ctrActualPlanDetailslst { get; set; }

        public PaginatorDTO? paginatorDTO { get; set; }


    }
    public class TechnologyStatusRequestDTO
    {
        public string? search { get; set; }
        public long? areaId { get; set; }
        public long? applicationId { get; set; }
        public long? themeId { get; set; }
        public string? UCT_FP { get; set; }
        public bool? isExport { get; set; }
        public string? docType { get; set; }
        public long? maturationPhase { get; set; }
        public bool? isFilter { get; set; }
        public PaginatorDTO? paginatorDTO { get; set; }
    }
    public class TechnologyPhase 
    {
        
              public long? ActualPlanId { get; set; }
              public long? Plan_ID { get; set; }
              public string? Actualstartdate { get; set; }
              public string? Actualenddate { get; set; }
              public string? PlanStartdate { get; set; }
              public string? PlanEnddate { get; set; }
              public string? Phase { get; set; }
              public string? Stage { get; set; }
              public string? Status { get; set; }
              public long? Completion { get; set; }
              public decimal? RegretValue { get; set; }

        public long? Seq { get; set; }
    }

    [DataContract]
    public class TechnologyHeatMapReportDTO
    {
        public List<TechnologyHeatMapDTO> allData { get; set; }
        public PaginatorDTO? paginatorDTO { get; set; }


    }
    [DataContract]
    public class TechnologyHeatMapDTO
    {
        [DataMember]
        public long id { get; set; }

        [DataMember]
        public string? asset { get; set; }
        [DataMember]
        public string? application { get; set; }
        [DataMember]
        public string? theme { get; set; }
        [DataMember]
        public string? area { get; set; }
        [DataMember]
        public string? phase { get; set; }

        [DataMember]
        public string TechName { get; set; }

        [DataMember]
        public long? Opportunity { get; set; }

        [DataMember]
        public long? PIR { get; set; }
        [DataMember]
        public long? TMH { get; set; }
        [DataMember]
        public long? TTA { get; set; }
        [DataMember]
        public long? Execution { get; set; }
        [DataMember]
        public long? GrandTotal { get; set; }

        [DataMember]
        public long? Phase_ID { get; set; }
        [DataMember]
        public long? CTR_ID { get; set; }

        [DataMember]
        public long? Config_Opportunity { get; set; }

        [DataMember]
        public long? Config_PIR { get; set; }
        [DataMember]
        public long? Config_TMH { get; set; }
        [DataMember]
        public long? Config_TTA { get; set; }
        [DataMember]
        public long? Config_Execution { get; set; }
        [DataMember]
        public long? IsComplete { get; set; }

        [DataMember]
        public string ActualStartDate { get; set; }
    }

        [DataContract]
    public class TechnologyHeatMapConfigDTO
    {
        [DataMember]
        public long Planned_Days { get; set; }
  
        [DataMember]
        public string? Name { get; set; }

    }


    }
