﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using TIP_API.DTO.Admin;
using TIP_CORE.Entities;

namespace TIP_CORE.EntitiesDTO
{

    [BindNever]
    public class TrialPlanReportDTO
    {
        public TrialPlanReportDTO()
        {
            
        }

        public int EXEId { get; set; }

        public long ExecutionId { get; set; }

        public int TechId { get; set; }
        public string? chaEncrptId { get; set; }
        public string? chaRefNo { get; set; }
        public string? chaTitle { get; set; }
        public string? chaRequestBy { get; set; }
        public string? chaUCT { get; set; }
        public string? chaUCTName { get; set; }
        public string? chaStatus { get; set; }
        public string? resEncrptId { get; set; }
        public string? resRefNo { get; set; }
        public string? resTechName { get; set; }
        public string? resVendor { get; set; }
        public string? resUCT { get; set; }
        public string? resStatus { get; set; }
        public string? resSource { get; set; }
        public string? resStatusParam { get; set; }
        public string? ctrEncrptId { get; set; }
        public string? ctrRefNo { get; set; }
        public string? ctrTrialName { get; set; }
        public string? ctrUCT { get; set; }
        public string? ctrStatus { get; set; }
        public string? pirEncrptId { get; set; }
        public string? pirRefNo { get; set; }
        public string? pirUCT { get; set; }
        public string? pirStatus { get; set; }
        public long? areaId { get; set; }
        public long? appId { get; set; }
        public long? themeId { get; set; }

        public long? clusterId { get; set; }

        public long? AssetId { get; set; }
        public string? approvedYear { get; set; }
        public long id { get; set; }
        public string encrptId { get; set; }
        public long year { get; set; }
        public long? assessmentId { get; set; }
        public long? painAreaId { get; set; }
        public string assetName { get; set; }
        public string clusterName { get; set; }


        public string themeName { get; set; }
        public string departmentName { get; set; }

        public string UCTFPName { get; set; }
        public string TechName { get; set; }

        public string PlannedStr { get; set; }

        public Dictionary<int, string> Planned { get; set; }

        public string ActualStr { get; set; }

        public Dictionary<int, string> Actual { get; set; }

        public string DelayedStr { get; set; }

        public Dictionary<int, string> Delayed { get; set; }

        public List<ExecutionPlannedTimelinesDTO> ExecutionPlannedTimelinesDTO { get; set; }

        [DataMember]
        public List<ExecutionActualPlannedTimelineDTO> ExecutionActualPlannedTimelineDTO { get; set; }

        //public List<ExecutionActualPlannedTimelineDTO> ExecutionActualPlannedTimelineDTO { get; set; }

    }

 

    public class TrialPlanReportDRequestDTO
    {
        public long? areaId { get; set; }
        public long? appId { get; set; }
        public long? themeId { get; set; }

        public long? assetId { get; set; }

        public long? clusterId { get; set; }
        public string? search { get; set; }
        public bool? isExport { get; set; }
        public string? docType { get; set; }
        public string? uctMU { get; set; }
        public string? yearVal { get; set; }
        public PaginatorDTO? paginatorDTO { get; set; }
    }


    public class TrialPlanReportResponseDTO
    {
        public PaginatorDTO? paginatorDTO { get; set; }
        public List<TrialPlanReportDTO> data { get; set; }
    }
}