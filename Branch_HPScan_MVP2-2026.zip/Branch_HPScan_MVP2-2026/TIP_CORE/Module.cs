﻿using System;
using System.Collections.Generic;

namespace TIP_Core
{
    public class Module : Audit
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public Int16 OrderNo { get; set; }
        public Int16 IsActive { get; set; }
        public string Icon { get; set; }
        public List<Screen> ScreensList { get; set; }
        public string Collapse { get; set; }
    }
}
