using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Oracle.EntityFrameworkCore;
using TIP_CORE.Entities;

#nullable disable

namespace TIP_Core
{
    public partial class AppDbContext : DbContext
    {
        public AppDbContext()
        {
        }

        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AssetFpLnk> AssetFpLnks { get; set; }
        public virtual DbSet<BtmAssessment> BtmAssessments { get; set; }
        public virtual DbSet<BtmAssessmentHistory> BtmAssessmentHistories { get; set; }
        public virtual DbSet<ChallengeChecklist> ChallengeChecklists { get; set; }
        public virtual DbSet<ChallengeDetail> ChallengeDetails { get; set; }
        public virtual DbSet<ChallengePublicationDetail> ChallengePublicationDetails { get; set; }
        public virtual DbSet<ChallengePublicationSource> ChallengePublicationSources { get; set; }
        public virtual DbSet<ChallengeRegistration> ChallengeRegistrations { get; set; }
        public virtual DbSet<ChallengeResponse> ChallengeResponses { get; set; }
        public virtual DbSet<ChallengeResponseQuestion> ChallengeResponseQuestions { get; set; }
        public virtual DbSet<ChallengeResponseReview> ChallengeResponseReviews { get; set; }
        public virtual DbSet<ChallengeResponseSr> ChallengeResponseSrs { get; set; }
        public virtual DbSet<ChallengeResponseTechnology> ChallengeResponseTechnologies { get; set; }
        public virtual DbSet<ChallengeSolutionReviewer> ChallengeSolutionReviewers { get; set; }
        public virtual DbSet<ChallengeVendorScreening> ChallengeVendorScreenings { get; set; }
        public virtual DbSet<ChallengeVot> ChallengeVots { get; set; }
        public virtual DbSet<ChecklistChallengeLnk> ChecklistChallengeLnks { get; set; }
        public virtual DbSet<ChlFlowHistory> ChlFlowHistories { get; set; }
        public virtual DbSet<ClusterFpLnk> ClusterFpLnks { get; set; }
        public virtual DbSet<Configuration> Configurations { get; set; }
        public virtual DbSet<CtrActualPlanDetail> CtrActualPlanDetails { get; set; }
        public virtual DbSet<CtrAdditionalSolution> CtrAdditionalSolutions { get; set; }
        public virtual DbSet<CtrApprovalList> CtrApprovalLists { get; set; }
        public virtual DbSet<CtrApprovalListHsty> CtrApprovalListHsties { get; set; }
        public virtual DbSet<CtrBudget> CtrBudgets { get; set; }
        public virtual DbSet<CtrDeploymentStaircase> CtrDeploymentStaircases { get; set; }
        public virtual DbSet<CtrFlowHistory> CtrFlowHistories { get; set; }
        public virtual DbSet<CtrInitiation> CtrInitiations { get; set; }
        public virtual DbSet<CtrPercentageCompletion> CtrPercentageCompletions { get; set; }
        public virtual DbSet<CtrPlanDetail> CtrPlanDetails { get; set; }
        public virtual DbSet<CtrPotentialImpacted> CtrPotentialImpacteds { get; set; }
        public virtual DbSet<CtrProjectMember> CtrProjectMembers { get; set; }
        public virtual DbSet<CtrSchedulePrice> CtrSchedulePrices { get; set; }
        public virtual DbSet<CtrSuccessCriterion> CtrSuccessCriteria { get; set; }
        public virtual DbSet<CtrTechConfiguration> CtrTechConfigurations { get; set; }
        public virtual DbSet<CtrTrial> CtrTrials { get; set; }
        public virtual DbSet<CtrTrialCandidate> CtrTrialCandidates { get; set; }
        public virtual DbSet<CtrTrialFp> CtrTrialFps { get; set; }
        public virtual DbSet<CtrTrialRisk> CtrTrialRisks { get; set; }
        public virtual DbSet<CtrTrialYear> CtrTrialYears { get; set; }
        public virtual DbSet<CtrVot> CtrVots { get; set; }
        public virtual DbSet<DepInitiation> DepInitiations { get; set; }
        public virtual DbSet<DepVot> DepVots { get; set; }
        public virtual DbSet<DocLink> DocLinks { get; set; }
        public virtual DbSet<DocumentRepo> DocumentRepos { get; set; }
        public virtual DbSet<EmailEscalation> EmailEscalations { get; set; }
        public virtual DbSet<EmailKeyword> EmailKeywords { get; set; }
        public virtual DbSet<EmailRepo> EmailRepos { get; set; }
        public virtual DbSet<EmailTemplateConfiguration> EmailTemplateConfigurations { get; set; }
        public virtual DbSet<ErrorLog> ErrorLogs { get; set; }
        public virtual DbSet<ExeFlowHistory> ExeFlowHistories { get; set; }
        public virtual DbSet<ExeInvoiceFlowHistory> ExeInvoiceFlowHistories { get; set; }
        public virtual DbSet<ExecutionActualplannedtimline> ExecutionActualplannedtimlines { get; set; }
        public virtual DbSet<ExecutionBudgetConfirmation> ExecutionBudgetConfirmations { get; set; }
        public virtual DbSet<ExecutionBudgetCostcenter> ExecutionBudgetCostcenters { get; set; }
        public virtual DbSet<ExecutionInitiation> ExecutionInitiations { get; set; }
        public virtual DbSet<ExecutionInvoice> ExecutionInvoices { get; set; }
        public virtual DbSet<ExecutionPlanned> ExecutionPlanneds { get; set; }
        public virtual DbSet<ExecutionPlannedTimeline> ExecutionPlannedTimelines { get; set; }
        public virtual DbSet<ExecutionPotentialValue> ExecutionPotentialValues { get; set; }
        public virtual DbSet<ExecutionTrialCandidate> ExecutionTrialCandidates { get; set; }
        public virtual DbSet<ExecutionTrialFp> ExecutionTrialFps { get; set; }
        public virtual DbSet<ExternalUser> ExternalUsers { get; set; }

        public virtual DbSet<ImpAdminAttachment> ImpAdminAttachments { get; set; }
        public virtual DbSet<ImpChallenge> ImpChallenges { get; set; }
        public virtual DbSet<ImpChallengeAttachment> ImpChallengeAttachments { get; set; }
        public virtual DbSet<ImpCtr1> ImpCtr1s { get; set; }
        public virtual DbSet<ImpCtrAlternativeSolution> ImpCtrAlternativeSolutions { get; set; }
        public virtual DbSet<ImpCtrApproval> ImpCtrApprovals { get; set; }
        public virtual DbSet<ImpCtrBudget> ImpCtrBudgets { get; set; }
        public virtual DbSet<ImpCtrDeploymentstaircase> ImpCtrDeploymentstaircases { get; set; }
        public virtual DbSet<ImpCtrDsAddNote> ImpCtrDsAddNotes { get; set; }
        public virtual DbSet<ImpCtrHistory> ImpCtrHistories { get; set; }
        public virtual DbSet<ImpCtrImpactedContract> ImpCtrImpactedContracts { get; set; }
        public virtual DbSet<ImpCtrRiskPlan> ImpCtrRiskPlans { get; set; }
        public virtual DbSet<ImpCtrScAddNote> ImpCtrScAddNotes { get; set; }
        public virtual DbSet<ImpCtrSuccessCriterion> ImpCtrSuccessCriteria { get; set; }
        public virtual DbSet<ImpCtrTask> ImpCtrTasks { get; set; }
        public virtual DbSet<ImpCtrTrialPlan> ImpCtrTrialPlans { get; set; }
        public virtual DbSet<ImpEmployeeLive> ImpEmployeeLives { get; set; }
        public virtual DbSet<ImpMigratedChallenge> ImpMigratedChallenges { get; set; }
        public virtual DbSet<ImpPir> ImpPirs { get; set; }
        public virtual DbSet<ImpPirApproval> ImpPirApprovals { get; set; }
        public virtual DbSet<ImpPirCommon> ImpPirCommons { get; set; }
        public virtual DbSet<ImpPirDepStaircase> ImpPirDepStaircases { get; set; }
        public virtual DbSet<ImpPirHistory> ImpPirHistories { get; set; }
        public virtual DbSet<ImpPirLessonlearnt> ImpPirLessonlearnts { get; set; }
        public virtual DbSet<ImpPirPotentialimpacted> ImpPirPotentialimpacteds { get; set; }
        public virtual DbSet<ImpPirSuccessCriterion> ImpPirSuccessCriteria { get; set; }
        public virtual DbSet<ImpPirTrialcandidate> ImpPirTrialcandidates { get; set; }
        public virtual DbSet<ImpQA> ImpQAs { get; set; }
        public virtual DbSet<ImpQuery> ImpQueries { get; set; }
        public virtual DbSet<ImpTechBank> ImpTechBanks { get; set; }
        public virtual DbSet<ImpTechSelection> ImpTechSelections { get; set; }
        public virtual DbSet<ImpTph> ImpTphs { get; set; }
        public virtual DbSet<ImpTphTask> ImpTphTasks { get; set; }
        public virtual DbSet<ImpUpdateTechBank> ImpUpdateTechBanks { get; set; }
        public virtual DbSet<ImpVendorProfile> ImpVendorProfiles { get; set; }
        public virtual DbSet<ImpVendorResponse> ImpVendorResponses { get; set; }
        public virtual DbSet<ImpVendorResponseFile> ImpVendorResponseFiles { get; set; }
        public virtual DbSet<ImpVendorScreeningAnswer> ImpVendorScreeningAnswers { get; set; }
        public virtual DbSet<ImpVendorScreeningQstn> ImpVendorScreeningQstns { get; set; }
        public virtual DbSet<JobLog> JobLogs { get; set; }
        public virtual DbSet<PainArea> PainAreas { get; set; }
        public virtual DbSet<PdoToVendorQuery> PdoToVendorQueries { get; set; }
        public virtual DbSet<PdoToVendorQueryResponse> PdoToVendorQueryResponses { get; set; }
        public virtual DbSet<PirActionPlan> PirActionPlans { get; set; }
        public virtual DbSet<PirApprovalList> PirApprovalLists { get; set; }
        public virtual DbSet<PirApprovalListHsty> PirApprovalListHsties { get; set; }
        public virtual DbSet<PirAssessmentTrialResult> PirAssessmentTrialResults { get; set; }
        public virtual DbSet<PirDeploymentStaircase> PirDeploymentStaircases { get; set; }
        public virtual DbSet<PirFlowHistory> PirFlowHistories { get; set; }
        public virtual DbSet<PirImpactedExistingContract> PirImpactedExistingContracts { get; set; }
        public virtual DbSet<PirInitiation> PirInitiations { get; set; }
        public virtual DbSet<PirLessonLearnt> PirLessonLearnts { get; set; }
        public virtual DbSet<PirSummary> PirSummaries { get; set; }
        public virtual DbSet<PirSupportingMember> PirSupportingMembers { get; set; }
        public virtual DbSet<PirTrialCandidate> PirTrialCandidates { get; set; }
        public virtual DbSet<PirTrialFp> PirTrialFps { get; set; }
        public virtual DbSet<PirVot> PirVots { get; set; }
        public virtual DbSet<SrFlowHistory> SrFlowHistories { get; set; }
        public virtual DbSet<SubthemeCfdhLnk> SubthemeCfdhLnks { get; set; }
        public virtual DbSet<TechnologyBank> TechnologyBanks { get; set; }
        public virtual DbSet<TechnologyKpiConfig> TechnologyKpiConfigs { get; set; }
        public virtual DbSet<TempApproverNull> TempApproverNulls { get; set; }
        public virtual DbSet<TempSrNull> TempSrNulls { get; set; }
        public virtual DbSet<TestRiyan> TestRiyans { get; set; }
        public virtual DbSet<TmContractdetail> TmContractdetails { get; set; }
        public virtual DbSet<TmEmployee> TmEmployees { get; set; }
        public virtual DbSet<TmRabitahContract> TmRabitahContracts { get; set; }
        public virtual DbSet<TmRabitahVendor> TmRabitahVendors { get; set; }
        public virtual DbSet<TmRoleToMenuMapping> TmRoleToMenuMappings { get; set; }
        public virtual DbSet<TmRoleToUserMapping> TmRoleToUserMappings { get; set; }
        public virtual DbSet<TmSideMenu> TmSideMenus { get; set; }
        public virtual DbSet<TmUser> TmUsers { get; set; }
        public virtual DbSet<TmUserPaArchieve> TmUserPaArchieves { get; set; }
        public virtual DbSet<TmUserRole> TmUserRoles { get; set; }
        public virtual DbSet<TmUserloginLog> TmUserloginLogs { get; set; }
        public virtual DbSet<TypeCodeMaster> TypeCodeMasters { get; set; }
        public virtual DbSet<UtlAuditTrail> UtlAuditTrails { get; set; }
        public virtual DbSet<TrAuditLog> TrAuditLogs { get; set; }
        //public virtual DbSet<VTipApprovedPir> VTipApprovedPirs { get; set; }
        //public virtual DbSet<VTipApprovedTtum> VTipApprovedTta { get; set; }
        //public virtual DbSet<VTipChallengesOpportunity> VTipChallengesOpportunities { get; set; }
        //public virtual DbSet<VTipDeploymentVot> VTipDeploymentVots { get; set; }
        //public virtual DbSet<VTipFunnelSummary> VTipFunnelSummaries { get; set; }
        //public virtual DbSet<VTipMasterDatum> VTipMasterData { get; set; }
        //public virtual DbSet<VTipMasterUctfp> VTipMasterUctfps { get; set; }
        public virtual DbSet<VTipPerTechnology> VTipPerTechnologies { get; set; }
        //public virtual DbSet<VTipPhaseMaturation> VTipPhaseMaturations { get; set; }
        //public virtual DbSet<VTipPhaseMaturationBk> VTipPhaseMaturationBks { get; set; }
        //public virtual DbSet<VTipPlannedActualVot> VTipPlannedActualVots { get; set; }
        //public virtual DbSet<VTipPoIssuing> VTipPoIssuings { get; set; }
        //public virtual DbSet<VTipPotentialValue> VTipPotentialValues { get; set; }
        //public virtual DbSet<VTipPreTtum> VTipPreTta { get; set; }
        public virtual DbSet<VTipTechPlan> VTipTechPlans { get; set; }
        //public virtual DbSet<VTipTechTimeline> VTipTechTimelines { get; set; }
        //public virtual DbSet<VTipTechnologyCount> VTipTechnologyCounts { get; set; }
        //public virtual DbSet<VTipTechnologyDurationDay> VTipTechnologyDurationDays { get; set; }
        //public virtual DbSet<VTipTechnologyPlan> VTipTechnologyPlans { get; set; }
        //public virtual DbSet<VTipTechnologySpending> VTipTechnologySpendings { get; set; }
        //public virtual DbSet<VTipTechnologySpendingR> VTipTechnologySpendingRs { get; set; }
        //public virtual DbSet<VTipTechnologyTimeline> VTipTechnologyTimelines { get; set; }
        //public virtual DbSet<VTipTechnologybankTrail> VTipTechnologybankTrails { get; set; }
        //public virtual DbSet<VTipTechnologyvmb> VTipTechnologyvmbs { get; set; }
        //public virtual DbSet<VTipTtaVot> VTipTtaVots { get; set; }
        public virtual DbSet<VendorToChrQuery> VendorToChrQueries { get; set; }
        public virtual DbSet<VendorToChrQueryResponse> VendorToChrQueryResponses { get; set; }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    if (!optionsBuilder.IsConfigured)
        //    {

        //    }
        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.HasDefaultSchema("TIPTS")
            //    .HasAnnotation("Relational:Collation", "USING_NLS_COMP");

            modelBuilder.Entity<AssetFpLnk>(entity =>
            {
                entity.ToTable("ASSET_FP_LNK");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.AssetId)
                    .HasPrecision(18)
                    .HasColumnName("ASSET_ID");

                entity.Property(e => e.FocalPoint)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("FOCAL_POINT");
            });

            modelBuilder.Entity<BtmAssessment>(entity =>
            {
                entity.ToTable("BTM_ASSESSMENT");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.AssetId)
                    .HasPrecision(18)
                    .HasColumnName("ASSET_ID");

                entity.Property(e => e.ClusterId)
                    .HasPrecision(18)
                    .HasColumnName("CLUSTER_ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.DepartmentId)
                    .HasPrecision(18)
                    .HasColumnName("DEPARTMENT_ID");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasPrecision(1)
                    .HasColumnName("IS_ACTIVE")
                    .HasDefaultValueSql("1 ");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.WorkshopDate)
                    .HasColumnType("DATE")
                    .HasColumnName("WORKSHOP_DATE");

                entity.Property(e => e.Year)
                    .HasPrecision(18)
                    .HasColumnName("YEAR");

                entity.HasOne(d => d.Asset)
                    .WithMany(p => p.BtmAssessmentAssets)
                    .HasForeignKey(d => d.AssetId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("BTM_ASSESSMENT_FK1");

                entity.HasOne(d => d.Cluster)
                    .WithMany(p => p.BtmAssessmentClusters)
                    .HasForeignKey(d => d.ClusterId)
                    .HasConstraintName("BTM_ASSESSMENT_FK2");

                entity.HasOne(d => d.Department)
                    .WithMany(p => p.BtmAssessmentDepartments)
                    .HasForeignKey(d => d.DepartmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("BTM_ASSESSMENT_FK3");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.BtmAssessmentStatuses)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("BTM_ASSESSMENT_FK4");
            });

            modelBuilder.Entity<BtmAssessmentHistory>(entity =>
            {
                entity.ToTable("BTM_ASSESSMENT_HISTORY");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.AssessmentId)
                    .HasPrecision(18)
                    .HasColumnName("ASSESSMENT_ID");

                entity.Property(e => e.ModifiedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("MODIFIED_BY");

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("MODIFIED_ON");

                entity.Property(e => e.Remarks)
                    .HasMaxLength(100)
                    .HasColumnName("REMARKS");

                entity.Property(e => e.Status)
                    .HasPrecision(18)
                    .HasColumnName("STATUS");

                entity.HasOne(d => d.Assessment)
                    .WithMany(p => p.BtmAssessmentHistories)
                    .HasForeignKey(d => d.AssessmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("BTM_ASSESSMENT_HISTORY_FK1");

                entity.HasOne(d => d.StatusNavigation)
                    .WithMany(p => p.BtmAssessmentHistories)
                    .HasForeignKey(d => d.Status)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("BTM_ASSESSMENT_HISTORY_FK2");
            });

            modelBuilder.Entity<ChallengeChecklist>(entity =>
            {
                entity.ToTable("CHALLENGE_CHECKLIST");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.IsActive)
                    .HasPrecision(1)
                    .HasColumnName("IS_ACTIVE");

                entity.Property(e => e.Question)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("QUESTION");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.UpdatedRef)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_REF");
            });

            modelBuilder.Entity<ChallengeDetail>(entity =>
            {
                entity.ToTable("CHALLENGE_DETAILS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ApplicationId)
                    .HasPrecision(18)
                    .HasColumnName("APPLICATION_ID");

                entity.Property(e => e.AreaId)
                    .HasPrecision(18)
                    .HasColumnName("AREA_ID");

                entity.Property(e => e.AssetId)
                    .HasPrecision(18)
                    .HasColumnName("ASSET_ID");

                entity.Property(e => e.Cfdh)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CFDH");

                entity.Property(e => e.ChallengeId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.ClusterId)
                    .HasPrecision(18)
                    .HasColumnName("CLUSTER_ID");

                entity.Property(e => e.Co2reduction)
                    .HasPrecision(18)
                    .HasColumnName("CO2REDUCTION");

                entity.Property(e => e.Costreduction)
                    .HasPrecision(18)
                    .HasColumnName("COSTREDUCTION");

                entity.Property(e => e.CurrentPractices)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("CURRENT_PRACTICES");

                entity.Property(e => e.Hserisk)
                    .HasPrecision(18)
                    .HasColumnName("HSERISK");

                entity.Property(e => e.KeyRequirments)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("KEY_REQUIRMENTS");

                entity.Property(e => e.MaturityLevelId)
                    .HasPrecision(18)
                    .HasColumnName("MATURITY_LEVEL_ID");

                entity.Property(e => e.OperatingEnvelopes)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("OPERATING_ENVELOPES");

                entity.Property(e => e.Overallscore)
                    .HasPrecision(18)
                    .HasColumnName("OVERALLSCORE");

                entity.Property(e => e.Pillar)
                    .HasPrecision(18)
                    .HasColumnName("PILLAR");

                entity.Property(e => e.PotentialScoreForecast)
                    .HasMaxLength(1000)
                    .HasColumnName("POTENTIAL_SCORE_FORECAST");

                entity.Property(e => e.ProblemStatement)
                    .HasColumnType("CLOB")
                    .HasColumnName("PROBLEM_STATEMENT");

                entity.Property(e => e.Productionincrease)
                    .HasPrecision(18)
                    .HasColumnName("PRODUCTIONINCREASE");

                entity.Property(e => e.QueryLastdate)
                    .HasColumnType("DATE")
                    .HasColumnName("QUERY_LASTDATE");

                entity.Property(e => e.RequestType)
                    .HasPrecision(18)
                    .HasColumnName("REQUEST_TYPE");

                entity.Property(e => e.ResponseLastdate)
                    .HasColumnType("DATE")
                    .HasColumnName("RESPONSE_LASTDATE");

                entity.Property(e => e.ScoutingKeywords)
                    .HasMaxLength(500)
                    .HasColumnName("SCOUTING_KEYWORDS");

                entity.Property(e => e.SubThemeId)
                    .HasPrecision(18)
                    .HasColumnName("SUB_THEME_ID");

                entity.Property(e => e.TechnicalSpec)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("TECHNICAL_SPEC");

                entity.Property(e => e.ThemeId)
                    .HasPrecision(18)
                    .HasColumnName("THEME_ID");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("TITLE");

                entity.Property(e => e.ValueDrivers)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("VALUE_DRIVERS");

                entity.Property(e => e.VendorSubmissionStartdate)
                    .HasColumnType("DATE")
                    .HasColumnName("VENDOR_SUBMISSION_STARTDATE");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.ChallengeDetailApplications)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_DETAILS_FK4");

                entity.HasOne(d => d.Area)
                    .WithMany(p => p.ChallengeDetailAreas)
                    .HasForeignKey(d => d.AreaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_DETAILS_FK3");

                entity.HasOne(d => d.Challenge)
                    .WithMany(p => p.ChallengeDetails)
                    .HasForeignKey(d => d.ChallengeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_DETAILS_FK1");

                entity.HasOne(d => d.MaturityLevel)
                    .WithMany(p => p.ChallengeDetailMaturityLevels)
                    .HasForeignKey(d => d.MaturityLevelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_DETAILS_FK2");

                entity.HasOne(d => d.SubTheme)
                    .WithMany(p => p.ChallengeDetailSubThemes)
                    .HasForeignKey(d => d.SubThemeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_DETAILS_FK6");

                entity.HasOne(d => d.Theme)
                    .WithMany(p => p.ChallengeDetailThemes)
                    .HasForeignKey(d => d.ThemeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_DETAILS_FK5");
            });

            modelBuilder.Entity<ChallengePublicationDetail>(entity =>
            {
                entity.ToTable("CHALLENGE_PUBLICATION_DETAILS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.ChallengeRegid)
                    .HasColumnType("NUMBER")
                    .HasColumnName("CHALLENGE_REGID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.QueryEnddate)
                    .HasColumnType("DATE")
                    .HasColumnName("QUERY_ENDDATE");

                entity.Property(e => e.SubmissionEnddate)
                    .HasColumnType("DATE")
                    .HasColumnName("SUBMISSION_ENDDATE");

                entity.Property(e => e.SubmissionStartdate)
                    .HasColumnType("DATE")
                    .HasColumnName("SUBMISSION_STARTDATE");
            });

            modelBuilder.Entity<ChallengePublicationSource>(entity =>
            {
                entity.ToTable("CHALLENGE_PUBLICATION_SOURCE");

                entity.HasIndex(e => new { e.SourceId, e.ChRegId }, "CHALLENGE_PUBLICATION_SOU_UK1")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ChRegId)
                    .HasPrecision(18)
                    .HasColumnName("CH_REG_ID");

                entity.Property(e => e.SourceId)
                    .HasPrecision(18)
                    .HasColumnName("SOURCE_ID");

                entity.HasOne(d => d.ChReg)
                    .WithMany(p => p.ChallengePublicationSources)
                    .HasForeignKey(d => d.ChRegId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_PUBLICATION_SOU_FK1");

                entity.HasOne(d => d.Source)
                    .WithMany(p => p.ChallengePublicationSources)
                    .HasForeignKey(d => d.SourceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_PUBLICATION_SOU_FK2");
            });

            modelBuilder.Entity<ChallengeRegistration>(entity =>
            {
                entity.ToTable("CHALLENGE_REGISTRATIONS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ActionComment)
                    .HasColumnType("CLOB")
                    .HasColumnName("ACTION_COMMENT");

                entity.Property(e => e.AssessmentId)
                    .HasPrecision(18)
                    .HasColumnName("ASSESSMENT_ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(40)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CreatedRoleId)
                    .HasPrecision(18)
                    .HasColumnName("CREATED_ROLE_ID");

                entity.Property(e => e.LastReminder)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_REMINDER");

                entity.Property(e => e.PainAreaId)
                    .HasPrecision(18)
                    .HasColumnName("PAIN_AREA_ID");

                entity.Property(e => e.PublishDate)
                    .HasColumnType("DATE")
                    .HasColumnName("PUBLISH_DATE");

                entity.Property(e => e.Publishreferenceno)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("PUBLISHREFERENCENO");

                entity.Property(e => e.ReferenceNo)
                    .IsRequired()
                    .HasMaxLength(25)
                    .HasColumnName("REFERENCE_NO");

                entity.Property(e => e.RequestedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("REQUESTED_BY");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.UctFp)
                    .HasMaxLength(20)
                    .HasColumnName("UCT_FP");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.UpdatedRoleId)
                    .HasPrecision(18)
                    .HasColumnName("UPDATED_ROLE_ID");

                entity.HasOne(d => d.Assessment)
                    .WithMany(p => p.ChallengeRegistrations)
                    .HasForeignKey(d => d.AssessmentId)
                    .HasConstraintName("CHALLENGE_REGISTRATIONS_FK1");

                entity.HasOne(d => d.PainArea)
                    .WithMany(p => p.ChallengeRegistrations)
                    .HasForeignKey(d => d.PainAreaId)
                    .HasConstraintName("CHALLENGE_REGISTRATIONS_FK2");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.ChallengeRegistrations)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_REGISTRATIONS_FK3");
            });

            modelBuilder.Entity<ChallengeResponse>(entity =>
            {
                entity.ToTable("CHALLENGE_RESPONSE");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.ChallengeRegistrationId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_REGISTRATION_ID");

                entity.Property(e => e.CompanyId)
                    .HasPrecision(18)
                    .HasColumnName("COMPANY_ID");

                entity.Property(e => e.Complexity)
                    .HasPrecision(18)
                    .HasColumnName("COMPLEXITY");

                entity.Property(e => e.CreatedBy)
                    .HasPrecision(18)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.DecisionId)
                    .HasPrecision(18)
                    .HasColumnName("DECISION_ID");

                entity.Property(e => e.EscCount)
                    .HasPrecision(18)
                    .HasColumnName("ESC_COUNT");

                entity.Property(e => e.Impact)
                    .HasPrecision(18)
                    .HasColumnName("IMPACT");

                entity.Property(e => e.IsConfirm)
                    .HasPrecision(1)
                    .HasColumnName("IS_CONFIRM");

                entity.Property(e => e.IsCr)
                    .HasPrecision(1)
                    .HasColumnName("IS_CR");

                entity.Property(e => e.LastReminder)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_REMINDER");

                entity.Property(e => e.ResReferenceNo)
                    .HasMaxLength(25)
                    .HasColumnName("RES_REFERENCE_NO");

                entity.Property(e => e.SourceId)
                    .HasPrecision(18)
                    .HasColumnName("SOURCE_ID");

                entity.Property(e => e.StatusComment)
                    .HasColumnType("CLOB")
                    .HasColumnName("STATUS_COMMENT");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.TechnologyDescription)
                    .HasColumnType("CLOB")
                    .HasColumnName("TECHNOLOGY_DESCRIPTION");

                entity.Property(e => e.TechnologyName)
                    .HasMaxLength(250)
                    .HasColumnName("TECHNOLOGY_NAME");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.UpdatedRole)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_ROLE");

                entity.HasOne(d => d.ChallengeRegistration)
                    .WithMany(p => p.ChallengeResponses)
                    .HasForeignKey(d => d.ChallengeRegistrationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_RESPONSE_FK1");

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.ChallengeResponses)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_RESPONSE_FK6");

                entity.HasOne(d => d.Source)
                    .WithMany(p => p.ChallengeResponseSources)
                    .HasForeignKey(d => d.SourceId)
                    .HasConstraintName("CHALLENGE_RESPONSE_FK5");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.ChallengeResponseStatuses)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("CHALLENGE_RESPONSE_FK4");
            });

            modelBuilder.Entity<ChallengeResponseQuestion>(entity =>
            {
                entity.ToTable("CHALLENGE_RESPONSE_QUESTION");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.Answer).HasColumnName("ANSWER");

                entity.Property(e => e.AnswerBk)
                    .HasColumnType("CLOB")
                    .HasColumnName("ANSWER_BK");

                entity.Property(e => e.ChallengeResponseId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_RESPONSE_ID");

                entity.Property(e => e.Status)
                    .HasPrecision(1)
                    .HasColumnName("STATUS")
                    .HasDefaultValueSql("1");

                entity.Property(e => e.VendorQuestionId)
                    .HasPrecision(18)
                    .HasColumnName("VENDOR_QUESTION_ID");

                entity.HasOne(d => d.ChallengeResponse)
                    .WithMany(p => p.ChallengeResponseQuestions)
                    .HasForeignKey(d => d.ChallengeResponseId)
                    .HasConstraintName("CHALLENGE_RESPONSE_QUESTION_FK1");

                entity.HasOne(d => d.VendorQuestion)
                    .WithMany(p => p.ChallengeResponseQuestions)
                    .HasForeignKey(d => d.VendorQuestionId)
                    .HasConstraintName("CHALLENGE_RESPONSE_QUESTION_FK2");
            });

            modelBuilder.Entity<ChallengeResponseReview>(entity =>
            {
                entity.ToTable("CHALLENGE_RESPONSE_REVIEW");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Answer)
                    .HasMaxLength(600)
                    .HasColumnName("ANSWER");

                entity.Property(e => e.ChallengeResponseId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_RESPONSE_ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.Document)
                    .HasMaxLength(40)
                    .HasColumnName("DOCUMENT");

                entity.Property(e => e.IsSr)
                    .HasPrecision(1)
                    .HasColumnName("IS_SR");

                entity.Property(e => e.ReviewComment).HasColumnName("REVIEW_COMMENT");

                entity.Property(e => e.ReviewQuestionId)
                    .HasPrecision(18)
                    .HasColumnName("REVIEW_QUESTION_ID");

                entity.Property(e => e.Status)
                    .HasPrecision(1)
                    .HasColumnName("STATUS");

                entity.Property(e => e.TechnologyStatus)
                    .HasPrecision(1)
                    .HasColumnName("TECHNOLOGY_STATUS");

                entity.HasOne(d => d.ChallengeResponse)
                    .WithMany(p => p.ChallengeResponseReviews)
                    .HasForeignKey(d => d.ChallengeResponseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_RESPONSE_REVIEW_FK2");

                entity.HasOne(d => d.ReviewQuestion)
                    .WithMany(p => p.ChallengeResponseReviews)
                    .HasForeignKey(d => d.ReviewQuestionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_RESPONSE_REVIEW_FK1");
            });

            modelBuilder.Entity<ChallengeResponseSr>(entity =>
            {
                entity.ToTable("CHALLENGE_RESPONSE_SR");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ChallengeRegistrationId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_REGISTRATION_ID");

                entity.Property(e => e.ChallengeResponseId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_RESPONSE_ID");

                entity.Property(e => e.CompanyId)
                    .HasPrecision(18)
                    .HasColumnName("COMPANY_ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.ResReferenceNo)
                    .HasMaxLength(25)
                    .HasColumnName("RES_REFERENCE_NO");

                entity.Property(e => e.SourceId)
                    .HasPrecision(18)
                    .HasColumnName("SOURCE_ID");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.TechnologyDescription).HasColumnName("TECHNOLOGY_DESCRIPTION");

                entity.Property(e => e.TechnologyName)
                    .HasMaxLength(250)
                    .HasColumnName("TECHNOLOGY_NAME");

                entity.HasOne(d => d.ChallengeRegistration)
                    .WithMany(p => p.ChallengeResponseSrs)
                    .HasForeignKey(d => d.ChallengeRegistrationId)
                    .HasConstraintName("CHALLENGE_RESPONSE_SR_FK2");

                entity.HasOne(d => d.ChallengeResponse)
                    .WithMany(p => p.ChallengeResponseSrs)
                    .HasForeignKey(d => d.ChallengeResponseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_RESPONSE_SR_FK1");

                entity.HasOne(d => d.Source)
                    .WithMany(p => p.ChallengeResponseSrSources)
                    .HasForeignKey(d => d.SourceId)
                    .HasConstraintName("CHALLENGE_RESPONSE_SR_FK3");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.ChallengeResponseSrStatuses)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("CHALLENGE_RESPONSE_SR_FK4");
            });

            modelBuilder.Entity<ChallengeResponseTechnology>(entity =>
            {
                entity.ToTable("CHALLENGE_RESPONSE_TECHNOLOGY");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.ChallengeResponseId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_RESPONSE_ID");

                entity.Property(e => e.Description)
                    .HasColumnType("CLOB")
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.TechnologyQuestion)
                    .HasPrecision(18)
                    .HasColumnName("TECHNOLOGY_QUESTION");
            });

            modelBuilder.Entity<ChallengeSolutionReviewer>(entity =>
            {
                entity.ToTable("CHALLENGE_SOLUTION_REVIEWERS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ChallengeDetailId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_DETAIL_ID");

                entity.Property(e => e.ChallengeId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.IsReviewed)
                    .HasPrecision(1)
                    .HasColumnName("IS_REVIEWED")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.Reviewer)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("REVIEWER");

                entity.HasOne(d => d.ChallengeDetail)
                    .WithMany(p => p.ChallengeSolutionReviewers)
                    .HasForeignKey(d => d.ChallengeDetailId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_SOLUTION_REVIEWERS_FK2");

                entity.HasOne(d => d.Challenge)
                    .WithMany(p => p.ChallengeSolutionReviewers)
                    .HasForeignKey(d => d.ChallengeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_SOLUTION_REVIEWERS_FK1");
            });

            modelBuilder.Entity<ChallengeVendorScreening>(entity =>
            {
                entity.ToTable("CHALLENGE_VENDOR_SCREENING");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ChallengeDetailId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_DETAIL_ID");

                entity.Property(e => e.ChallengeId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Question)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("QUESTION");

                entity.Property(e => e.Sequence)
                    .HasPrecision(18)
                    .HasColumnName("SEQUENCE");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.ChallengeDetail)
                    .WithMany(p => p.ChallengeVendorScreenings)
                    .HasForeignKey(d => d.ChallengeDetailId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_VENDOR_SCREENING_FK2");

                entity.HasOne(d => d.Challenge)
                    .WithMany(p => p.ChallengeVendorScreenings)
                    .HasForeignKey(d => d.ChallengeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_VENDOR_SCREENING_FK1");
            });

            modelBuilder.Entity<ChallengeVot>(entity =>
            {
                entity.ToTable("CHALLENGE_VOT");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.AvgIncrmntlOilGain)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("AVG_INCRMNTL_OIL_GAIN");

                entity.Property(e => e.ChallengeId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.Co2ReductnUnitYr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("CO2_REDUCTN_UNIT_YR");

                entity.Property(e => e.Co2Tax)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("CO2_TAX");

                entity.Property(e => e.Compliance)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("COMPLIANCE");

                entity.Property(e => e.CostAvoidance)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("COST_AVOIDANCE");

                entity.Property(e => e.CostSavingUnitYr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("COST_SAVING_UNIT_YR");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Hse)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("HSE");

                entity.Property(e => e.M3T0Bbl)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("M3_T0_BBL");

                entity.Property(e => e.MwhCost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("MWH_COST");

                entity.Property(e => e.NoOfUnitsTrailScope)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_TRAIL_SCOPE");

                entity.Property(e => e.NoOfUnitsYear1)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR1");

                entity.Property(e => e.NoOfUnitsYear2)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR2");

                entity.Property(e => e.NoOfUnitsYear3)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR3");

                entity.Property(e => e.NoOfUnitsYear4)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR4");

                entity.Property(e => e.NoOfUnitsYear5)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR5");

                entity.Property(e => e.OilPrice)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("OIL_PRICE");

                entity.Property(e => e.OtherCost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("OTHER_COST");

                entity.Property(e => e.PowerSavingUnitYr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("POWER_SAVING_UNIT_YR");

                entity.Property(e => e.Quality)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("QUALITY");

                entity.Property(e => e.RiskFactor)
                    .HasPrecision(18)
                    .HasColumnName("RISK_FACTOR");

                entity.Property(e => e.TechCost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("TECH_COST");

                entity.Property(e => e.TotOilDefermentAvoidance)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("TOT_OIL_DEFERMENT_AVOIDANCE");

                entity.Property(e => e.TotalCo2Reduction)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("TOTAL_CO2_REDUCTION");

                entity.Property(e => e.TotalMwhReduction)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("TOTAL_MWH_REDUCTION");

                entity.Property(e => e.UnitId)
                    .HasPrecision(18)
                    .HasColumnName("UNIT_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.VotTotDeploymentUnits)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("VOT_TOT_DEPLOYMENT_UNITS");

                entity.Property(e => e.VotTrailTotUnits)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("VOT_TRAIL_TOT_UNITS");

                entity.Property(e => e.VotUnitYear)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("VOT_UNIT_YEAR");

                entity.HasOne(d => d.Challenge)
                    .WithMany(p => p.ChallengeVots)
                    .HasForeignKey(d => d.ChallengeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHALLENGE_VOT_FK1");
            });

            modelBuilder.Entity<ChecklistChallengeLnk>(entity =>
            {
                entity.ToTable("CHECKLIST_CHALLENGE_LNK");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ChallengeId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.ChecklistId)
                    .HasPrecision(18)
                    .HasColumnName("CHECKLIST_ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.Yn)
                    .IsRequired()
                    .HasMaxLength(2)
                    .HasColumnName("YN");

                entity.HasOne(d => d.Challenge)
                    .WithMany(p => p.ChecklistChallengeLnks)
                    .HasForeignKey(d => d.ChallengeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHECKLIST_CHALLENGE_LNK_FK1");

                entity.HasOne(d => d.Checklist)
                    .WithMany(p => p.ChecklistChallengeLnks)
                    .HasForeignKey(d => d.ChecklistId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHECKLIST_CHALLENGE_LNK_FK2");
            });

            modelBuilder.Entity<ChlFlowHistory>(entity =>
            {
                entity.ToTable("CHL_FLOW_HISTORY");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ChallengeId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.Comments).HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.DescInfo)
                    .HasMaxLength(400)
                    .HasColumnName("DESC_INFO");

                entity.Property(e => e.RoleId)
                    .HasPrecision(18)
                    .HasColumnName("ROLE_ID");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(40)
                    .HasColumnName("USER_ID");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.ChlFlowHistories)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CHL_FLOW_HISTORY_FK1");
            });

            modelBuilder.Entity<ClusterFpLnk>(entity =>
            {
                entity.ToTable("CLUSTER_FP_LNK");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ClusterId)
                    .HasPrecision(18)
                    .HasColumnName("CLUSTER_ID");

                entity.Property(e => e.FocalPoint)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("FOCAL_POINT");

                entity.HasOne(d => d.Cluster)
                    .WithMany(p => p.ClusterFpLnks)
                    .HasForeignKey(d => d.ClusterId)
                    .HasConstraintName("CLUSTER_FP_LNK_FK1");
            });

            modelBuilder.Entity<Configuration>(entity =>
            {
                entity.ToTable("CONFIGURATION");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.Category)
                    .HasMaxLength(200)
                    .HasColumnName("CATEGORY");

                entity.Property(e => e.Key)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("KEY");

                entity.Property(e => e.Value)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("VALUE");
            });

            modelBuilder.Entity<CtrActualPlanDetail>(entity =>
            {
                entity.ToTable("CTR_ACTUAL_PLAN_DETAILS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.Actualenddate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTUALENDDATE");

                entity.Property(e => e.Actualstartdate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTUALSTARTDATE");

                entity.Property(e => e.Comments)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.Completion)
                    .HasPrecision(18)
                    .HasColumnName("COMPLETION");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.ForecastedEdDate)
                    .HasColumnType("DATE")
                    .HasColumnName("FORECASTED_ED_DATE");

                entity.Property(e => e.ForecastedStDate)
                    .HasColumnType("DATE")
                    .HasColumnName("FORECASTED_ST_DATE");

                entity.Property(e => e.OverallProgressId)
                    .HasPrecision(18)
                    .HasColumnName("OVERALL_PROGRESS_ID");

                entity.Property(e => e.Phase)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("PHASE");

                entity.Property(e => e.PhaseId)
                    .HasPrecision(18)
                    .HasColumnName("PHASE_ID");

                entity.Property(e => e.PlanId)
                    .HasPrecision(18)
                    .HasColumnName("PLAN_ID");

                entity.Property(e => e.Planneddays)
                    .HasPrecision(18)
                    .HasColumnName("PLANNEDDAYS");

                entity.Property(e => e.Sequence)
                    .HasPrecision(18)
                    .HasColumnName("SEQUENCE");

                entity.Property(e => e.Stage)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("STAGE");

                entity.Property(e => e.StageId)
                    .HasPrecision(18)
                    .HasColumnName("STAGE_ID");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.TemplateId)
                    .HasPrecision(18)
                    .HasColumnName("TEMPLATE_ID");

                entity.HasOne(d => d.PhaseNavigation)
                    .WithMany(p => p.CtrActualPlanDetailPhaseNavigations)
                    .HasForeignKey(d => d.PhaseId)
                    .HasConstraintName("CTR_ACTUAL_PLAN_DETAILS_FK2");

                entity.HasOne(d => d.StageNavigation)
                    .WithMany(p => p.CtrActualPlanDetailStageNavigations)
                    .HasForeignKey(d => d.StageId)
                    .HasConstraintName("CTR_ACTUAL_PLAN_DETAILS_FK1");

                entity.HasOne(d => d.Template)
                    .WithMany(p => p.CtrActualPlanDetailTemplates)
                    .HasForeignKey(d => d.TemplateId)
                    .HasConstraintName("CTR_ACTUAL_PLAN_DETAILS_FK3");
            });

            modelBuilder.Entity<CtrAdditionalSolution>(entity =>
            {
                entity.ToTable("CTR_ADDITIONAL_SOLUTIONS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.Remarks)
                    .HasColumnType("CLOB")
                    .HasColumnName("REMARKS");

                entity.Property(e => e.SerialNumber)
                    .IsRequired()
                    .HasMaxLength(50)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("SERIAL_NUMBER");

                entity.Property(e => e.SolutionTitle)
                    .IsRequired()
                    .HasColumnName("SOLUTION_TITLE");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrAdditionalSolutions)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_ADDITIONAL_SOLUTIONS_FK1");
            });

            modelBuilder.Entity<CtrApprovalList>(entity =>
            {
                entity.ToTable("CTR_APPROVAL_LIST");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ActionAssignedDate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTION_ASSIGNED_DATE");

                entity.Property(e => e.ActionCompletionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTION_COMPLETION_DATE");

                entity.Property(e => e.ActionRequiredBy)
                    .HasMaxLength(20)
                    .HasColumnName("ACTION_REQUIRED_BY");

                entity.Property(e => e.Comments)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.JobCode)
                    .HasMaxLength(100)
                    .HasColumnName("JOB_CODE");

                entity.Property(e => e.JobTitle)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("JOB_TITLE");

                entity.Property(e => e.LastReminder)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_REMINDER");

                entity.Property(e => e.Seq)
                    .HasPrecision(18)
                    .HasColumnName("SEQ");

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasColumnName("STATUS");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrApprovalLists)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_APPROVAL_LIST_FK1");
            });

            modelBuilder.Entity<CtrApprovalListHsty>(entity =>
            {
                entity.ToTable("CTR_APPROVAL_LIST_HSTY");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.ActionAssignedDate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTION_ASSIGNED_DATE");

                entity.Property(e => e.ActionCompletionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTION_COMPLETION_DATE");

                entity.Property(e => e.Comments).HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.HistoryCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("HISTORY_CREATED_ON");

                entity.Property(e => e.JobCode)
                    .HasMaxLength(200)
                    .HasColumnName("JOB_CODE");

                entity.Property(e => e.JobTitle)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("JOB_TITLE");

                entity.Property(e => e.Seq)
                    .HasPrecision(18)
                    .HasColumnName("SEQ");

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasColumnName("STATUS");

                entity.Property(e => e.Version)
                    .HasPrecision(18)
                    .HasColumnName("VERSION")
                    .HasDefaultValueSql("0 ");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrApprovalListHsties)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_APPROVAL_LIST_HSTY_FK1");
            });

            modelBuilder.Entity<CtrBudget>(entity =>
            {
                entity.ToTable("CTR_BUDGET");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.Amount)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("AMOUNT");

                entity.Property(e => e.BudgetProvider).HasColumnName("BUDGET_PROVIDER");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.ItemProvider).HasColumnName("ITEM_PROVIDER");

                entity.Property(e => e.QId)
                    .HasPrecision(18)
                    .HasColumnName("Q_ID");

                entity.Property(e => e.ResourceDescription).HasColumnName("RESOURCE_DESCRIPTION");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.Year)
                    .HasMaxLength(50)
                    .HasColumnName("YEAR");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrBudgets)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_BUDGET_FK1");
            });

            modelBuilder.Entity<CtrDeploymentStaircase>(entity =>
            {
                entity.ToTable("CTR_DEPLOYMENT_STAIRCASE");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.Estimatedvot)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("ESTIMATEDVOT");

                entity.Property(e => e.Noofwells)
                    .HasPrecision(18)
                    .HasColumnName("NOOFWELLS");

                entity.Property(e => e.Station)
                    .HasMaxLength(1000)
                    .HasColumnName("STATION");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.Year)
                    .HasPrecision(18)
                    .HasColumnName("YEAR");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrDeploymentStaircases)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_DEPLOYMENT_STAIRCASE_FK1");
            });

            modelBuilder.Entity<CtrFlowHistory>(entity =>
            {
                entity.ToTable("CTR_FLOW_HISTORY");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Comments).HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.DescInfo)
                    .HasMaxLength(200)
                    .HasColumnName("DESC_INFO");

                entity.Property(e => e.RoleId)
                    .HasPrecision(18)
                    .HasColumnName("ROLE_ID");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("USER_ID");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrFlowHistories)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_FLOW_HISTORY_FK1");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.CtrFlowHistories)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_FLOW_HISTORY_FK3");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.CtrFlowHistories)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_FLOW_HISTORY_FK2");
            });

            modelBuilder.Entity<CtrInitiation>(entity =>
            {
                entity.ToTable("CTR_INITIATION");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.BusinessValue)
                    .HasColumnType("CLOB")
                    .HasColumnName("BUSINESS_VALUE");

                entity.Property(e => e.Confidential)
                    .HasPrecision(1)
                    .HasColumnName("CONFIDENTIAL");

                entity.Property(e => e.ContractNumber)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACT_NUMBER");

                entity.Property(e => e.ContractingStratergy)
                    .HasColumnType("CLOB")
                    .HasColumnName("CONTRACTING_STRATERGY");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Ctrpaymentmilestone)
                    .HasPrecision(18)
                    .HasColumnName("CTRPAYMENTMILESTONE");

                entity.Property(e => e.Ctrtrialcost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("CTRTRIALCOST");

                entity.Property(e => e.CurrencyId)
                    .HasPrecision(18)
                    .HasColumnName("CURRENCY_ID");

                entity.Property(e => e.CurrentApprovalSeq)
                    .HasPrecision(18)
                    .HasColumnName("CURRENT_APPROVAL_SEQ")
                    .HasDefaultValueSql("0 ");

                entity.Property(e => e.DsAssumptionMode).HasColumnName("DS_ASSUMPTION_MODE");

                entity.Property(e => e.DsComment).HasColumnName("DS_COMMENT");

                entity.Property(e => e.GeneralComments)
                    .HasMaxLength(1000)
                    .HasColumnName("GENERAL_COMMENTS");

                entity.Property(e => e.LastReminder)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_REMINDER");

                entity.Property(e => e.NoTrials)
                    .HasPrecision(18)
                    .HasColumnName("NO_TRIALS");

                entity.Property(e => e.RefNo)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("REF_NO");

                entity.Property(e => e.SentbackBy)
                    .HasMaxLength(3)
                    .HasColumnName("SENTBACK_BY");

                entity.Property(e => e.SentbackOn)
                    .HasColumnType("DATE")
                    .HasColumnName("SENTBACK_ON");

                entity.Property(e => e.StartingYear)
                    .HasPrecision(18)
                    .HasColumnName("STARTING_YEAR");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.SubmitCount)
                    .HasPrecision(18)
                    .HasColumnName("SUBMIT_COUNT")
                    .HasDefaultValueSql("0 ");

                entity.Property(e => e.SubmittedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("SUBMITTED_ON");

                entity.Property(e => e.TechDescription)
                    .HasColumnType("CLOB")
                    .HasColumnName("TECH_DESCRIPTION");

                entity.Property(e => e.TechId)
                    .HasPrecision(18)
                    .HasColumnName("TECH_ID");

                entity.Property(e => e.TechMaturity)
                    .HasColumnType("CLOB")
                    .HasColumnName("TECH_MATURITY");

                entity.Property(e => e.TrialName)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("TRIAL_NAME");

                entity.Property(e => e.TrialObjectives)
                    .HasColumnType("CLOB")
                    .HasColumnName("TRIAL_OBJECTIVES");

                entity.Property(e => e.TrialSelectionCriteria)
                    .HasColumnType("CLOB")
                    .HasColumnName("TRIAL_SELECTION_CRITERIA");

                entity.Property(e => e.TrialWorkplaces)
                    .HasColumnType("CLOB")
                    .HasColumnName("TRIAL_WORKPLACES");

                entity.Property(e => e.UctFp)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("UCT_FP");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.VendorCode)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("VENDOR_CODE");

                entity.HasOne(d => d.Currency)
                    .WithMany(p => p.CtrInitiationCurrencies)
                    .HasForeignKey(d => d.CurrencyId)
                    .HasConstraintName("CTR_INITIATION_FK2");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.CtrInitiationStatuses)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_INITIATION_FK1");
            });

            modelBuilder.Entity<CtrPercentageCompletion>(entity =>
            {
                entity.ToTable("CTR_PERCENTAGE_COMPLETION");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CrreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CRREATED_BY_REF");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.EstPrice)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("EST_PRICE");

                entity.Property(e => e.Percentage)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("PERCENTAGE");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrPercentageCompletions)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_PERCENTAGE_COMPLETION_FK1");
            });

            modelBuilder.Entity<CtrPlanDetail>(entity =>
            {
                entity.ToTable("CTR_PLAN_DETAILS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.Enddate)
                    .HasColumnType("DATE")
                    .HasColumnName("ENDDATE");

                entity.Property(e => e.Phase)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("PHASE");

                entity.Property(e => e.PhaseId)
                    .HasPrecision(18)
                    .HasColumnName("PHASE_ID");

                entity.Property(e => e.Planneddays)
                    .HasPrecision(18)
                    .HasColumnName("PLANNEDDAYS");

                entity.Property(e => e.Sequence)
                    .HasPrecision(18)
                    .HasColumnName("SEQUENCE");

                entity.Property(e => e.Stage)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("STAGE");

                entity.Property(e => e.StageId)
                    .HasPrecision(18)
                    .HasColumnName("STAGE_ID");

                entity.Property(e => e.Startdate)
                    .HasColumnType("DATE")
                    .HasColumnName("STARTDATE");

                entity.Property(e => e.Statusid)
                    .HasPrecision(18)
                    .HasColumnName("STATUSID");

                entity.Property(e => e.TemplateId)
                    .HasPrecision(18)
                    .HasColumnName("TEMPLATE_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.Year)
                    .HasMaxLength(50)
                    .HasColumnName("YEAR");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrPlanDetails)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_PLAN_DETAILS_FK1");

                entity.HasOne(d => d.PhaseNavigation)
                    .WithMany(p => p.CtrPlanDetailPhaseNavigations)
                    .HasForeignKey(d => d.PhaseId)
                    .HasConstraintName("CTR_PLAN_DETAILS_FK2");

                entity.HasOne(d => d.StageNavigation)
                    .WithMany(p => p.CtrPlanDetailStageNavigations)
                    .HasForeignKey(d => d.StageId)
                    .HasConstraintName("CTR_PLAN_DETAILS_FK3");

                entity.HasOne(d => d.Template)
                    .WithMany(p => p.CtrPlanDetailTemplates)
                    .HasForeignKey(d => d.TemplateId)
                    .HasConstraintName("CTR_PLAN_DETAILS_FK4");
            });

            modelBuilder.Entity<CtrPotentialImpacted>(entity =>
            {
                entity.ToTable("CTR_POTENTIAL_IMPACTED");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ContractNo)
                    .HasMaxLength(1000)
                    .HasColumnName("CONTRACT_NO");

                entity.Property(e => e.ContractTitle)
                    .HasMaxLength(1000)
                    .HasColumnName("CONTRACT_TITLE");

                entity.Property(e => e.Contractor)
                    .HasMaxLength(1000)
                    .HasColumnName("CONTRACTOR");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.Impact).HasColumnName("IMPACT");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrPotentialImpacteds)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_POTENTIAL_IMPACTED_FK1");
            });

            modelBuilder.Entity<CtrProjectMember>(entity =>
            {
                entity.ToTable("CTR_PROJECT_MEMBERS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.IsReadOnly)
                    .HasPrecision(1)
                    .HasColumnName("IS_READ_ONLY");

                entity.Property(e => e.Member)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("MEMBER");

                entity.Property(e => e.RoleId)
                    .HasPrecision(18)
                    .HasColumnName("ROLE_ID");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrProjectMembers)
                    .HasForeignKey(d => d.CtrId)
                    .HasConstraintName("CTR_PROJECT_MEMBERS_FK2");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.CtrProjectMembers)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("CTR_PROJECT_MEMBERS_FK1");
            });

            modelBuilder.Entity<CtrSchedulePrice>(entity =>
            {
                entity.ToTable("CTR_SCHEDULE_PRICES");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.NumberOfTrials)
                    .HasPrecision(18)
                    .HasColumnName("NUMBER_OF_TRIALS");

                entity.Property(e => e.Quantity)
                    .HasPrecision(18)
                    .HasColumnName("QUANTITY");

                entity.Property(e => e.TotalPriceEstimate)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("TOTAL_PRICE_ESTIMATE");

                entity.Property(e => e.UnitPrice)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("UNIT_PRICE");

                entity.Property(e => e.Units)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("UNITS");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrSchedulePrices)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_SCHEDULE_PRICES_FK1");
            });

            modelBuilder.Entity<CtrSuccessCriterion>(entity =>
            {
                entity.ToTable("CTR_SUCCESS_CRITERIA");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.CurrentValue)
                    .HasMaxLength(500)
                    .HasColumnName("CURRENT_VALUE");

                entity.Property(e => e.DecisionGateImpacted).HasColumnName("DECISION_GATE_IMPACTED");

                entity.Property(e => e.Parameter).HasColumnName("PARAMETER");

                entity.Property(e => e.ParameterId)
                    .HasPrecision(18)
                    .HasColumnName("PARAMETER_ID");

                entity.Property(e => e.Remarks)
                    .HasMaxLength(300)
                    .HasColumnName("REMARKS");

                entity.Property(e => e.TrialTarget)
                    .HasMaxLength(500)
                    .HasColumnName("TRIAL_TARGET");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrSuccessCriteria)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_SUCCESS_CRITERIA_FK1");

                entity.HasOne(d => d.ParameterNavigation)
                    .WithMany(p => p.CtrSuccessCriteria)
                    .HasForeignKey(d => d.ParameterId)
                    .HasConstraintName("CTR_SUCCESS_CRITERIA_FK2");
            });

            modelBuilder.Entity<CtrTechConfiguration>(entity =>
            {
                entity.ToTable("CTR_TECH_CONFIGURATION");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.PhaseId)
                    .HasPrecision(18)
                    .HasColumnName("PHASE_ID");

                entity.Property(e => e.Planneddays)
                    .HasPrecision(18)
                    .HasColumnName("PLANNEDDAYS");

                entity.Property(e => e.Sequence)
                    .HasPrecision(18)
                    .HasColumnName("SEQUENCE");

                entity.Property(e => e.StageId)
                    .HasPrecision(18)
                    .HasColumnName("STAGE_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Phase)
                    .WithMany(p => p.CtrTechConfigurationPhases)
                    .HasForeignKey(d => d.PhaseId)
                    .HasConstraintName("CTR_TECH_CONFIGURATION_FK2");

                entity.HasOne(d => d.Stage)
                    .WithMany(p => p.CtrTechConfigurationStages)
                    .HasForeignKey(d => d.StageId)
                    .HasConstraintName("CTR_TECH_CONFIGURATION_FK1");
            });

            modelBuilder.Entity<CtrTrial>(entity =>
            {
                entity.ToTable("CTR_TRIAL");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.DecisionBy)
                    .HasMaxLength(100)
                    .HasColumnName("DECISION_BY");

                entity.Property(e => e.DecisionGate)
                    .HasMaxLength(100)
                    .HasColumnName("DECISION_GATE");

                entity.Property(e => e.Remarks).HasColumnName("REMARKS");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("NUMBER")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrTrials)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_TRIAL_FK1");
            });

            modelBuilder.Entity<CtrTrialCandidate>(entity =>
            {
                entity.ToTable("CTR_TRIAL_CANDIDATE");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ChallengeDescription)
                    .HasMaxLength(500)
                    .HasColumnName("CHALLENGE_DESCRIPTION");

                entity.Property(e => e.CommencementDate)
                    .HasColumnType("DATE")
                    .HasColumnName("COMMENCEMENT_DATE");

                entity.Property(e => e.Comments)
                    .HasMaxLength(500)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.ConclusionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("CONCLUSION_DATE");

                entity.Property(e => e.Cost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("COST");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("NAME");

                entity.Property(e => e.TypeId)
                    .HasPrecision(18)
                    .HasColumnName("TYPE_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrTrialCandidates)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_TRIAL_CANDIDATE_FK2");

                entity.HasOne(d => d.Type)
                    .WithMany(p => p.CtrTrialCandidates)
                    .HasForeignKey(d => d.TypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_TRIAL_CANDIDATE_FK1");
            });

            modelBuilder.Entity<CtrTrialFp>(entity =>
            {
                entity.ToTable("CTR_TRIAL_FPS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.Fp)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("FP");

                entity.Property(e => e.IsMandatory)
                    .HasPrecision(1)
                    .HasColumnName("IS_MANDATORY");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrTrialFps)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_TRIAL_FPS_FK1");
            });

            modelBuilder.Entity<CtrTrialRisk>(entity =>
            {
                entity.ToTable("CTR_TRIAL_RISK");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.MitigationPlan)
                    .HasMaxLength(1000)
                    .HasColumnName("MITIGATION_PLAN");

                entity.Property(e => e.Risk)
                    .HasMaxLength(1000)
                    .HasColumnName("RISK");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrTrialRisks)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_TRIAL_RISK_FK1");
            });

            modelBuilder.Entity<CtrTrialYear>(entity =>
            {
                entity.ToTable("CTR_TRIAL_YEAR");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Q1).HasPrecision(1);

                entity.Property(e => e.Q2).HasPrecision(1);

                entity.Property(e => e.Q3).HasPrecision(1);

                entity.Property(e => e.Q4).HasPrecision(1);

                entity.Property(e => e.TrialId)
                    .HasPrecision(18)
                    .HasColumnName("TRIAL_ID");

                entity.Property(e => e.Year)
                    .HasPrecision(18)
                    .HasColumnName("YEAR");

                entity.HasOne(d => d.Trial)
                    .WithMany(p => p.CtrTrialYears)
                    .HasForeignKey(d => d.TrialId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_TRIAL_YEAR_FK1");
            });

            modelBuilder.Entity<CtrVot>(entity =>
            {
                entity.ToTable("CTR_VOT");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.AssumptionMode)
                    .HasMaxLength(300)
                    .HasColumnName("ASSUMPTION_MODE");

                entity.Property(e => e.AvgIncrmntlOilGain)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("AVG_INCRMNTL_OIL_GAIN");

                entity.Property(e => e.Co2ReductnUnitYr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("CO2_REDUCTN_UNIT_YR");

                entity.Property(e => e.Co2Tax)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("CO2_TAX");

                entity.Property(e => e.Comments)
                    .HasMaxLength(300)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.Compliance)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("COMPLIANCE");

                entity.Property(e => e.CostAvoidance)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("COST_AVOIDANCE");

                entity.Property(e => e.CostSavingUnitYr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("COST_SAVING_UNIT_YR");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.Hse)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("HSE");

                entity.Property(e => e.M3T0Bbl)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("M3_T0_BBL");

                entity.Property(e => e.MwhCost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("MWH_COST");

                entity.Property(e => e.NoOfUnitsTrailScope)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_TRAIL_SCOPE");

                entity.Property(e => e.NoOfUnitsYear1)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR1");

                entity.Property(e => e.NoOfUnitsYear2)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR2");

                entity.Property(e => e.NoOfUnitsYear3)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR3");

                entity.Property(e => e.NoOfUnitsYear4)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR4");

                entity.Property(e => e.NoOfUnitsYear5)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR5");

                entity.Property(e => e.OilPrice)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("OIL_PRICE");

                entity.Property(e => e.OtherCost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("OTHER_COST");

                entity.Property(e => e.PowerSavingUnitYr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("POWER_SAVING_UNIT_YR");

                entity.Property(e => e.Quality)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("QUALITY");

                entity.Property(e => e.RiskFactor)
                    .HasPrecision(18)
                    .HasColumnName("RISK_FACTOR");

                entity.Property(e => e.TechCost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("TECH_COST");

                entity.Property(e => e.TotOilDefermentAvoidance)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("TOT_OIL_DEFERMENT_AVOIDANCE");

                entity.Property(e => e.TotalCo2Reduction)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("TOTAL_CO2_REDUCTION");

                entity.Property(e => e.TotalMwhReduction)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("TOTAL_MWH_REDUCTION");

                entity.Property(e => e.UnitId)
                    .HasPrecision(18)
                    .HasColumnName("UNIT_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.VotTotDeploymentUnits)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("VOT_TOT_DEPLOYMENT_UNITS");

                entity.Property(e => e.VotTrailTotUnits)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("VOT_TRAIL_TOT_UNITS");

                entity.Property(e => e.VotUnitYear)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("VOT_UNIT_YEAR");

                entity.HasOne(d => d.Ctr)
                    .WithMany(p => p.CtrVots)
                    .HasForeignKey(d => d.CtrId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("CTR_VOT_FK1");
            });

            modelBuilder.Entity<DepInitiation>(entity =>
            {
                entity.ToTable("DEP_INITIATION");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Chfp)
                    .IsRequired()
                    .HasMaxLength(20)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("CHFP");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.Uctfp)
                    .IsRequired()
                    .HasMaxLength(10)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("UCTFP");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.DepInitiations)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("DEP_INITIATION_FK1");
            });

            modelBuilder.Entity<DepVot>(entity =>
            {
                entity.ToTable("DEP_VOT");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.Co2Reduction)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("CO2_REDUCTION");

                entity.Property(e => e.CostSavingUnitQtr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("COST_SAVING_UNIT_QTR");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.DefermentAvoidance)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("DEFERMENT_AVOIDANCE");

                entity.Property(e => e.DepId)
                    .HasPrecision(18)
                    .HasColumnName("DEP_ID");

                entity.Property(e => e.DeployedTo)
                    .HasPrecision(18)
                    .HasColumnName("DEPLOYED_TO");

                entity.Property(e => e.EscCount)
                    .HasPrecision(18)
                    .HasColumnName("ESC_COUNT");

                entity.Property(e => e.FinalComments).HasColumnName("FINAL_COMMENTS");

                entity.Property(e => e.IncrmntlOilGain)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("INCRMNTL_OIL_GAIN");

                entity.Property(e => e.LastReminder)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_REMINDER");

                entity.Property(e => e.OtherCostQtr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("OTHER_COST_QTR");

                entity.Property(e => e.PowerSaving)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("POWER_SAVING");

                entity.Property(e => e.QYear)
                    .HasPrecision(18)
                    .HasColumnName("Q_YEAR");

                entity.Property(e => e.ScopeCountQtr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("SCOPE_COUNT_QTR");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.SubmittedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("SUBMITTED_ON");

                entity.Property(e => e.TechnologyCost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("TECHNOLOGY_COST");

                entity.Property(e => e.TotalVotQtr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("TOTAL_VOT_QTR");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Dep)
                    .WithMany(p => p.DepVots)
                    .HasForeignKey(d => d.DepId)
                    .HasConstraintName("DEP_VOT_FK2");

                entity.HasOne(d => d.DeployedToNavigation)
                    .WithMany(p => p.DepVotDeployedToNavigations)
                    .HasForeignKey(d => d.DeployedTo)
                    .HasConstraintName("DEP_VOT_FK1");

                entity.HasOne(d => d.QYearNavigation)
                    .WithMany(p => p.DepVotQYearNavigations)
                    .HasForeignKey(d => d.QYear)
                    .HasConstraintName("DEP_VOT_FK3");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.DepVotStatuses)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("DEP_VOT_FK4");
            });

            modelBuilder.Entity<DocLink>(entity =>
            {
                entity.ToTable("DOC_LINK");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.Description)
                    .HasMaxLength(200)
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.Name)
                    .HasMaxLength(100)
                    .HasColumnName("NAME");

                entity.Property(e => e.Url)
                    .HasMaxLength(500)
                    .HasColumnName("URL");
            });

            modelBuilder.Entity<DocumentRepo>(entity =>
            {
                entity.ToTable("DOCUMENT_REPO");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Description).HasColumnName("DESCRIPTION");

                entity.Property(e => e.FileName).HasColumnName("FILE_NAME");

                entity.Property(e => e.FilePath)
                    .HasMaxLength(300)
                    .HasColumnName("FILE_PATH");

                entity.Property(e => e.FileType)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("FILE_TYPE");

                entity.Property(e => e.IsActive)
                    .HasPrecision(1)
                    .HasColumnName("IS_ACTIVE");

                entity.Property(e => e.IsExternalAccessible)
                    .HasPrecision(1)
                    .HasColumnName("IS_EXTERNAL_ACCESSIBLE");

                entity.Property(e => e.IsNda)
                    .HasPrecision(1)
                    .HasColumnName("IS_NDA");

                entity.Property(e => e.LimkType)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("LIMK_TYPE");

                entity.Property(e => e.LinkId)
                    .HasPrecision(18)
                    .HasColumnName("LINK_ID");

                entity.Property(e => e.MimeType)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("MIME_TYPE");
            });

            modelBuilder.Entity<EmailEscalation>(entity =>
            {
                entity.ToTable("EMAIL_ESCALATION");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.EmailCode)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("EMAIL_CODE");

                entity.Property(e => e.EscalEmail)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("ESCAL_EMAIL");

                entity.Property(e => e.EscalNo)
                    .HasPrecision(18)
                    .HasColumnName("ESCAL_NO");

                entity.Property(e => e.Frequency)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("FREQUENCY");

                entity.Property(e => e.FrequencyNo)
                    .HasPrecision(18)
                    .HasColumnName("FREQUENCY_NO");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");
            });

            modelBuilder.Entity<EmailKeyword>(entity =>
            {
                entity.ToTable("EMAIL_KEYWORD");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.Description)
                    .HasMaxLength(200)
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.Keyword)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("KEYWORD");

                entity.Property(e => e.ModuleId)
                    .HasPrecision(18)
                    .HasColumnName("MODULE_ID");
            });

            modelBuilder.Entity<EmailRepo>(entity =>
            {
                entity.ToTable("EMAIL_REPO");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Attachment)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("ATTACHMENT");

                entity.Property(e => e.AttachmentName)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("ATTACHMENT_NAME");

                entity.Property(e => e.CcRecipients).HasColumnName("CC_RECIPIENTS");

                entity.Property(e => e.EmailedDate)
                    .HasColumnType("DATE")
                    .HasColumnName("EMAILED_DATE");

                entity.Property(e => e.EmailedYn)
                    .IsRequired()
                    .HasMaxLength(1)
                    .HasColumnName("EMAILED_YN");

                entity.Property(e => e.Error).HasColumnName("ERROR");

                entity.Property(e => e.LoggedDate)
                    .HasColumnType("DATE")
                    .HasColumnName("LOGGED_DATE");

                entity.Property(e => e.MailBody)
                    .HasColumnType("CLOB")
                    .HasColumnName("MAIL_BODY");

                entity.Property(e => e.MailSubject).HasColumnName("MAIL_SUBJECT");

                entity.Property(e => e.ModuleId)
                    .HasPrecision(18)
                    .HasColumnName("MODULE_ID");

                entity.Property(e => e.TemplateId)
                    .HasPrecision(18)
                    .HasColumnName("TEMPLATE_ID");

                entity.Property(e => e.ToRecipients)
                    .IsRequired()
                    .HasColumnName("TO_RECIPIENTS");

                entity.Property(e => e.TryCount)
                    .HasPrecision(18)
                    .HasColumnName("TRY_COUNT");
            });

            modelBuilder.Entity<EmailTemplateConfiguration>(entity =>
            {
                entity.ToTable("EMAIL_TEMPLATE_CONFIGURATION");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.IsActive)
                    .HasPrecision(1)
                    .HasColumnName("IS_ACTIVE");

                entity.Property(e => e.MailBody)
                    .IsRequired()
                    .HasColumnType("CLOB")
                    .HasColumnName("MAIL_BODY");

                entity.Property(e => e.MailSubject)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("MAIL_SUBJECT");

                entity.Property(e => e.ModuleId)
                    .HasPrecision(18)
                    .HasColumnName("MODULE_ID");

                entity.Property(e => e.TemplateCode)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("TEMPLATE_CODE")
                    .HasDefaultValueSql("000 ");

                entity.Property(e => e.TemplateName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("TEMPLATE_NAME");

                entity.Property(e => e.UniqueTemplateId)
                    .HasPrecision(18)
                    .HasColumnName("UNIQUE_TEMPLATE_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Module)
                    .WithMany(p => p.EmailTemplateConfigurations)
                    .HasForeignKey(d => d.ModuleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MODULE_ID");
            });

            modelBuilder.Entity<ErrorLog>(entity =>
            {
                entity.ToTable("ERROR_LOG");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.ActionName)
                    .HasMaxLength(100)
                    .HasColumnName("ACTION_NAME");

                entity.Property(e => e.ControllerName)
                    .HasMaxLength(100)
                    .HasColumnName("CONTROLLER_NAME");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.ErrorId)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("ERROR_ID");

                entity.Property(e => e.ErrorMsg)
                    .HasColumnType("CLOB")
                    .HasColumnName("ERROR_MSG");

                entity.Property(e => e.IpAddress)
                    .HasMaxLength(50)
                    .HasColumnName("IP_ADDRESS");

                entity.Property(e => e.UserName)
                    .HasMaxLength(20)
                    .HasColumnName("USER_NAME");
            });

            modelBuilder.Entity<ExeFlowHistory>(entity =>
            {
                entity.ToTable("EXE_FLOW_HISTORY");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.AppPlanid)
                    .HasPrecision(18)
                    .HasColumnName("APP_PLANID");

                entity.Property(e => e.Comments)
                    .HasMaxLength(500)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.DescInfo)
                    .HasMaxLength(200)
                    .HasColumnName("DESC_INFO");

                entity.Property(e => e.ExeId)
                    .HasPrecision(18)
                    .HasColumnName("EXE_ID");

                entity.Property(e => e.PlanId)
                    .HasPrecision(18)
                    .HasColumnName("PLAN_ID");

                entity.Property(e => e.RoleId)
                    .HasPrecision(18)
                    .HasColumnName("ROLE_ID");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("USER_ID");

                entity.HasOne(d => d.Exe)
                    .WithMany(p => p.ExeFlowHistories)
                    .HasForeignKey(d => d.ExeId)
                    .HasConstraintName("EXE_FLOW_HISTORY_FK3");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.ExeFlowHistories)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXE_FLOW_HISTORY_FK2");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.ExeFlowHistories)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXE_FLOW_HISTORY_FK1");
            });

            modelBuilder.Entity<ExeInvoiceFlowHistory>(entity =>
            {
                entity.ToTable("EXE_INVOICE_FLOW_HISTORY");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Comments)
                    .HasMaxLength(1000)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.DescInfo)
                    .HasMaxLength(1000)
                    .HasColumnName("DESC_INFO");

                entity.Property(e => e.ExeId)
                    .HasPrecision(18)
                    .HasColumnName("EXE_ID");

                entity.Property(e => e.InvId)
                    .HasPrecision(18)
                    .HasColumnName("INV_ID");

                entity.Property(e => e.RoleId)
                    .HasPrecision(18)
                    .HasColumnName("ROLE_ID");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("USER_ID");

                entity.HasOne(d => d.Exe)
                    .WithMany(p => p.ExeInvoiceFlowHistories)
                    .HasForeignKey(d => d.ExeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXE_INVOICE_FLOW_HISTORY_FK1");

                entity.HasOne(d => d.Inv)
                    .WithMany(p => p.ExeInvoiceFlowHistories)
                    .HasForeignKey(d => d.InvId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXE_INVOICE_FLOW_HISTORY_FK2");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.ExeInvoiceFlowHistories)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXE_INVOICE_FLOW_HISTORY_FK4");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.ExeInvoiceFlowHistories)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXE_INVOICE_FLOW_HISTORY_FK3");
            });

            modelBuilder.Entity<ExecutionActualplannedtimline>(entity =>
            {
                entity.ToTable("EXECUTION_ACTUALPLANNEDTIMLINE");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Actualendadate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTUALENDADATE");

                entity.Property(e => e.Actualstartdate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTUALSTARTDATE");

                entity.Property(e => e.Comments)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.Completion)
                    .HasPrecision(18)
                    .HasColumnName("COMPLETION");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.EscCount)
                    .HasPrecision(18)
                    .HasColumnName("ESC_COUNT");

                entity.Property(e => e.Invoicereviewedby)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("INVOICEREVIEWEDBY");

                entity.Property(e => e.LastReminder)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_REMINDER");

                entity.Property(e => e.Overallprogress)
                    .HasColumnType("NUMBER")
                    .HasColumnName("OVERALLPROGRESS");

                entity.Property(e => e.PlannedTimelineId)
                    .HasPrecision(18)
                    .HasColumnName("PLANNED_TIMELINE_ID");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.Submittedon)
                    .HasColumnType("DATE")
                    .HasColumnName("SUBMITTEDON");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");
            });

            modelBuilder.Entity<ExecutionBudgetConfirmation>(entity =>
            {
                entity.ToTable("EXECUTION_BUDGET_CONFIRMATION");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.ApprovedDate)
                    .HasColumnType("DATE")
                    .HasColumnName("APPROVED_DATE");

                entity.Property(e => e.ContractNo)
                    .HasMaxLength(35)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACT_NO");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.FinanceFp)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("FINANCE_FP");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.TotalValue)
                    .HasColumnType("NUMBER")
                    .HasColumnName("TOTAL_VALUE");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");
            });

            modelBuilder.Entity<ExecutionBudgetCostcenter>(entity =>
            {
                entity.ToTable("EXECUTION_BUDGET_COSTCENTER");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.BudgetId)
                    .HasPrecision(18)
                    .HasColumnName("BUDGET_ID");

                entity.Property(e => e.BudgetProvider)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("BUDGET_PROVIDER");

                entity.Property(e => e.CostCenter)
                    .HasPrecision(18)
                    .HasColumnName("COST_CENTER");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Total)
                    .HasColumnType("NUMBER(18,1)")
                    .HasColumnName("TOTAL");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.Year)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("YEAR");
            });

            modelBuilder.Entity<ExecutionInitiation>(entity =>
            {
                entity.ToTable("EXECUTION_INITIATION");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.AcvValue)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("ACV_VALUE");

                entity.Property(e => e.ApplicationId)
                    .HasPrecision(18)
                    .HasColumnName("APPLICATION_ID");

                entity.Property(e => e.AreaId)
                    .HasPrecision(18)
                    .HasColumnName("AREA_ID");

                entity.Property(e => e.AssetId)
                    .HasPrecision(18)
                    .HasColumnName("ASSET_ID");

                entity.Property(e => e.Challengetitle)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("CHALLENGETITLE");

                entity.Property(e => e.ClusterId)
                    .HasPrecision(18)
                    .HasColumnName("CLUSTER_ID");

                entity.Property(e => e.CompletionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("COMPLETION_DATE");

                entity.Property(e => e.ContractNo)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACT_NO");

                entity.Property(e => e.ContractType)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACT_TYPE");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.Initiateddate)
                    .HasColumnType("DATE")
                    .HasColumnName("INITIATEDDATE");

                entity.Property(e => e.IsCompleted)
                    .HasPrecision(1)
                    .HasColumnName("IS_COMPLETED");

                entity.Property(e => e.MaturityLevelId)
                    .HasPrecision(18)
                    .HasColumnName("MATURITY_LEVEL_ID");

                entity.Property(e => e.RefNo)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("REF_NO");

                entity.Property(e => e.Startmonth)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("STARTMONTH");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.SubmittedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("SUBMITTED_ON");

                entity.Property(e => e.ThemeId)
                    .HasPrecision(18)
                    .HasColumnName("THEME_ID");

                entity.Property(e => e.Trialtitle)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("TRIALTITLE");

                entity.Property(e => e.UctFp)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UCT_FP");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");
            });

            modelBuilder.Entity<ExecutionInvoice>(entity =>
            {
                entity.ToTable("EXECUTION_INVOICES");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.AptId)
                    .HasPrecision(18)
                    .HasColumnName("APT_ID");

                entity.Property(e => e.Comments)
                    .HasMaxLength(100)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.CompletedDate)
                    .HasColumnType("DATE")
                    .HasColumnName("COMPLETED_DATE");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.ExeId)
                    .HasPrecision(18)
                    .HasColumnName("EXE_ID");

                entity.Property(e => e.InvoiceAmount)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("INVOICE_AMOUNT");

                entity.Property(e => e.PaidDate)
                    .HasColumnType("DATE")
                    .HasColumnName("PAID_DATE");

                entity.Property(e => e.RequestedDate)
                    .HasColumnType("DATE")
                    .HasColumnName("REQUESTED_DATE");

                entity.Property(e => e.SapFp)
                    .HasMaxLength(20)
                    .HasColumnName("SAP_FP");

                entity.Property(e => e.SentbackDate)
                    .HasColumnType("DATE")
                    .HasColumnName("SENTBACK_DATE");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.TfpRequestDate)
                    .HasColumnType("DATE")
                    .HasColumnName("TFP_REQUEST_DATE");

                entity.Property(e => e.UctReviwedDate)
                    .HasColumnType("DATE")
                    .HasColumnName("UCT_REVIWED_DATE");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Apt)
                    .WithMany(p => p.ExecutionInvoices)
                    .HasForeignKey(d => d.AptId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXECUTION_INVOICES_FK2");

                entity.HasOne(d => d.Exe)
                    .WithMany(p => p.ExecutionInvoices)
                    .HasForeignKey(d => d.ExeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXECUTION_INVOICES_FK1");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.ExecutionInvoices)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXECUTION_INVOICES_FK3");
            });

            modelBuilder.Entity<ExecutionPlanned>(entity =>
            {
                entity.ToTable("EXECUTION_PLANNED");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ApprovedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("APPROVED_BY");

                entity.Property(e => e.ApprovedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("APPROVED_ON");

                entity.Property(e => e.Comments)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.ExeId)
                    .HasPrecision(18)
                    .HasColumnName("EXE_ID");

                entity.Property(e => e.LastReminder)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_REMINDER");

                entity.Property(e => e.Reason)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("REASON");

                entity.Property(e => e.SentbackBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("SENTBACK_BY");

                entity.Property(e => e.SentbackOn)
                    .HasColumnType("DATE")
                    .HasColumnName("SENTBACK_ON");

                entity.Property(e => e.Status)
                    .HasPrecision(18)
                    .HasColumnName("STATUS");

                entity.Property(e => e.SubmitCount)
                    .HasPrecision(18)
                    .HasColumnName("SUBMIT_COUNT");

                entity.Property(e => e.SubmittedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("SUBMITTED_ON");

                entity.Property(e => e.UctFp)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UCT_FP");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.StatusNavigation)
                    .WithMany(p => p.ExecutionPlanneds)
                    .HasForeignKey(d => d.Status)
                    .HasConstraintName("EXECUTION_PLANNED_FK1");
            });

            modelBuilder.Entity<ExecutionPlannedTimeline>(entity =>
            {
                entity.ToTable("EXECUTION_PLANNED_TIMELINES");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Activity)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("ACTIVITY");

                entity.Property(e => e.Activitysort)
                    .HasPrecision(18)
                    .HasColumnName("ACTIVITYSORT");

                entity.Property(e => e.AcvValue)
                    .HasPrecision(18)
                    .HasColumnName("ACV_VALUE");

                entity.Property(e => e.Cost)
                    .HasPrecision(18)
                    .HasColumnName("COST");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Enddate)
                    .HasColumnType("DATE")
                    .HasColumnName("ENDDATE");

                entity.Property(e => e.ExecId)
                    .HasPrecision(18)
                    .HasColumnName("EXEC_ID");

                entity.Property(e => e.MilestoneType)
                    .HasPrecision(18)
                    .HasColumnName("MILESTONE_TYPE");

                entity.Property(e => e.PartyName)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("PARTY_NAME");

                entity.Property(e => e.Phaseid)
                    .HasPrecision(18)
                    .HasColumnName("PHASEID");

                entity.Property(e => e.PlannedDayes)
                    .HasPrecision(18)
                    .HasColumnName("PLANNED_DAYES");

                entity.Property(e => e.Stage)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("STAGE");

                entity.Property(e => e.Stagesort)
                    .HasPrecision(18)
                    .HasColumnName("STAGESORT");

                entity.Property(e => e.Startdate)
                    .HasColumnType("DATE")
                    .HasColumnName("STARTDATE");

                entity.Property(e => e.Type)
                    .HasPrecision(1)
                    .HasColumnName("TYPE");

                entity.Property(e => e.UpdateOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATE_ON");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY");

                entity.HasOne(d => d.Exec)
                    .WithMany(p => p.ExecutionPlannedTimelines)
                    .HasForeignKey(d => d.ExecId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXECUTION_PLANNED_TIMELIN_FK1");
            });

            modelBuilder.Entity<ExecutionPotentialValue>(entity =>
            {
                entity.ToTable("EXECUTION_POTENTIAL_VALUE");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.ExecId)
                    .HasPrecision(18)
                    .HasColumnName("EXEC_ID");

                entity.Property(e => e.Noofwells)
                    .HasPrecision(18)
                    .HasColumnName("NOOFWELLS");

                entity.Property(e => e.Station)
                    .HasMaxLength(100)
                    .HasColumnName("STATION");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.Value)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("VALUE");

                entity.Property(e => e.Year)
                    .HasPrecision(18)
                    .HasColumnName("YEAR");

                entity.HasOne(d => d.Exec)
                    .WithMany(p => p.ExecutionPotentialValues)
                    .HasForeignKey(d => d.ExecId)
                    .HasConstraintName("EXECUTION_POTENTIAL_VALUE_FK1");
            });

            modelBuilder.Entity<ExecutionTrialCandidate>(entity =>
            {
                entity.ToTable("EXECUTION_TRIAL_CANDIDATE");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ChallengeDescription)
                    .HasMaxLength(500)
                    .HasColumnName("CHALLENGE_DESCRIPTION");

                entity.Property(e => e.CommencementDate)
                    .HasColumnType("DATE")
                    .HasColumnName("COMMENCEMENT_DATE");

                entity.Property(e => e.Comments)
                    .HasMaxLength(500)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.ConclusionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("CONCLUSION_DATE");

                entity.Property(e => e.Cost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("COST");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.ExecutionId)
                    .HasPrecision(18)
                    .HasColumnName("EXECUTION_ID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("NAME");

                entity.Property(e => e.OutcomeId)
                    .HasPrecision(18)
                    .HasColumnName("OUTCOME_ID");

                entity.Property(e => e.TypeId)
                    .HasPrecision(18)
                    .HasColumnName("TYPE_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Execution)
                    .WithMany(p => p.ExecutionTrialCandidates)
                    .HasForeignKey(d => d.ExecutionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXECUTION_TRIAL_CANDIDATE_FK1");
            });

            modelBuilder.Entity<ExecutionTrialFp>(entity =>
            {
                entity.ToTable("EXECUTION_TRIAL_FPS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ExecutionId)
                    .HasPrecision(18)
                    .HasColumnName("EXECUTION_ID");

                entity.Property(e => e.Fp)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("FP");

                entity.Property(e => e.IsMandatory)
                    .HasPrecision(1)
                    .HasColumnName("IS_MANDATORY");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("JOB_TITLE");

                entity.Property(e => e.RefInd)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("REF_IND");

                entity.HasOne(d => d.Execution)
                    .WithMany(p => p.ExecutionTrialFps)
                    .HasForeignKey(d => d.ExecutionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("EXECUTION_TRIAL_FPS_FK1");
            });

            modelBuilder.Entity<ExternalUser>(entity =>
            {
                entity.ToTable("EXTERNAL_USERS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Address)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("ADDRESS");

                entity.Property(e => e.Attempts)
                    .HasColumnType("NUMBER")
                    .HasColumnName("ATTEMPTS");

                entity.Property(e => e.CommercialregExpDate)
                    .HasColumnType("DATE")
                    .HasColumnName("COMMERCIALREG_EXP_DATE");

                entity.Property(e => e.CommercialregNo)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("COMMERCIALREG_NO");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("COMPANY_NAME");

                entity.Property(e => e.Companywebsite)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("COMPANYWEBSITE");

                entity.Property(e => e.ContPerPhoneNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CONT_PER_PHONE_NUMBER");

                entity.Property(e => e.Contactperson)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("CONTACTPERSON");

                entity.Property(e => e.Countryorign)
                    .HasMaxLength(35)
                    .IsUnicode(false)
                    .HasColumnName("COUNTRYORIGN");

                entity.Property(e => e.Cpb)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("CPB");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_DATE");

                entity.Property(e => e.Description)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.EmailAddress)
                    .HasMaxLength(35)
                    .IsUnicode(false)
                    .HasColumnName("EMAIL_ADDRESS");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("FIRST_NAME");

                entity.Property(e => e.IsActive)
                    .HasPrecision(1)
                    .HasColumnName("IS_ACTIVE");

                entity.Property(e => e.LastLogin)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_LOGIN");

                entity.Property(e => e.LastName)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("LAST_NAME");

                entity.Property(e => e.LastReminderDate)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_REMINDER_DATE");

                entity.Property(e => e.Manufacturername)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("MANUFACTURERNAME");

                entity.Property(e => e.OtpCode)
                    .HasPrecision(18)
                    // .ValueGeneratedOnAdd()
                    .HasColumnName("OTP_CODE");

                entity.Property(e => e.OtpTime)
                    .HasPrecision(6)
                    .HasColumnName("OTP_TIME");

                entity.Property(e => e.Password)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("PASSWORD");

                entity.Property(e => e.PhoneNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("PHONE_NUMBER");

                entity.Property(e => e.Representation)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("REPRESENTATION");

                entity.Property(e => e.SourceId)
                    .HasPrecision(18)
                    .HasColumnName("SOURCE_ID");

                entity.Property(e => e.Type)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("TYPE");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.UserCategory)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("USER_CATEGORY");
            });


            modelBuilder.Entity<ImpAdminAttachment>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_ADMIN_ATTACHMENT");

                entity.Property(e => e.AttachmentId)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ATTACHMENT_ID");

                entity.Property(e => e.ChallengeId)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedDate)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_DATE");

                entity.Property(e => e.FileName)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("FILE_NAME");

                entity.Property(e => e.LiveLinkId)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("LIVE_LINK_ID");
            });

            modelBuilder.Entity<ImpChallenge>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CHALLENGES");

                entity.Property(e => e.Application)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("APPLICATION");

                entity.Property(e => e.ApplicationId)
                    .HasMaxLength(500)
                    .HasColumnName("APPLICATION_ID");

                entity.Property(e => e.Challengearea)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("CHALLENGEAREA");

                entity.Property(e => e.Challengereferenceno)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("CHALLENGEREFERENCENO");

                entity.Property(e => e.Challengestatus)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("CHALLENGESTATUS");

                entity.Property(e => e.Challengetitle)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("CHALLENGETITLE");

                entity.Property(e => e.Costreduction)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("COSTREDUCTION");

                entity.Property(e => e.Created)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CREATED");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedRoleId)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_ROLE_ID");

                entity.Property(e => e.Focalpoint)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("FOCALPOINT");

                entity.Property(e => e.Hserisk)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("HSERISK");

                entity.Property(e => e.Id)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("ID");

                entity.Property(e => e.Jobtitle)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("JOBTITLE");

                entity.Property(e => e.MaturityLevelId)
                    .HasMaxLength(500)
                    .HasColumnName("MATURITY_LEVEL_ID");

                entity.Property(e => e.Maturitylevel)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("MATURITYLEVEL");

                entity.Property(e => e.ProblemStatement)
                    .HasColumnType("CLOB")
                    .HasColumnName("PROBLEM_STATEMENT");

                entity.Property(e => e.Productionreserves)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("PRODUCTIONRESERVES");

                entity.Property(e => e.Rankingimpactscore)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("RANKINGIMPACTSCORE");

                entity.Property(e => e.StatusId)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.Submitdate)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("SUBMITDATE");

                entity.Property(e => e.Subtheme)
                    .HasMaxLength(1280)
                    .IsUnicode(false)
                    .HasColumnName("SUBTHEME");

                entity.Property(e => e.SubthemeId)
                    .HasMaxLength(500)
                    .HasColumnName("SUBTHEME_ID");

                entity.Property(e => e.Theme)
                    .HasMaxLength(1280)
                    .IsUnicode(false)
                    .HasColumnName("THEME");

                entity.Property(e => e.ThemeId)
                    .HasMaxLength(500)
                    .HasColumnName("THEME_ID");

                entity.Property(e => e.Title)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");

                entity.Property(e => e.TphChallengeDimension)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TPH_CHALLENGE_DIMENSION");

                entity.Property(e => e.TphChallengeId)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TPH_CHALLENGE_ID");

                entity.Property(e => e.UpdatedRoleId)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_ROLE_ID");
            });

            modelBuilder.Entity<ImpChallengeAttachment>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CHALLENGE_ATTACHMENT");

                entity.Property(e => e.Attachmentpath)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("ATTACHMENTPATH");

                entity.Property(e => e.LivelinkId)
                    .HasPrecision(10)
                    .HasColumnName("LIVELINK_ID");

                entity.Property(e => e.LivelinkUrl)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("LIVELINK_URL");

                entity.Property(e => e.OldTphAttachmentId)
                    .HasColumnType("NUMBER(26)")
                    .HasColumnName("OLD_TPH_ATTACHMENT_ID");

                entity.Property(e => e.OldTphChallengeId)
                    .HasColumnType("NUMBER(26)")
                    .HasColumnName("OLD_TPH_CHALLENGE_ID");

                entity.Property(e => e.Title)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");

                entity.Property(e => e.Tphchallengeid)
                    .HasColumnType("NUMBER(25)")
                    .HasColumnName("TPHCHALLENGEID");
            });

            modelBuilder.Entity<ImpCtr1>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_1");

                entity.Property(e => e.Businessvalue)
                    .HasColumnType("CLOB")
                    .HasColumnName("BUSINESSVALUE");

                entity.Property(e => e.ChallengeDescription)
                    .HasColumnType("CLOB")
                    .HasColumnName("CHALLENGE_DESCRIPTION");

                entity.Property(e => e.Challengename)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("CHALLENGENAME");

                entity.Property(e => e.Contractingstrategy)
                    .HasColumnType("CLOB")
                    .HasColumnName("CONTRACTINGSTRATEGY");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.Ctrrefnumber)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNUMBER");

                entity.Property(e => e.Id)
                    .HasPrecision(5)
                    .HasColumnName("ID");

                entity.Property(e => e.Isapproved)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ISAPPROVED");

                entity.Property(e => e.Ismechinsmcreated)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("ISMECHINSMCREATED");

                entity.Property(e => e.Selectioncriteria)
                    .HasColumnType("CLOB")
                    .HasColumnName("SELECTIONCRITERIA");

                entity.Property(e => e.Status)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("STATUS");

                entity.Property(e => e.Technology)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TECHNOLOGY");

                entity.Property(e => e.Technologyid)
                    .HasPrecision(5)
                    .HasColumnName("TECHNOLOGYID");

                entity.Property(e => e.Title)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");

                entity.Property(e => e.Trialfocalpoint1)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("TRIALFOCALPOINT1");

                entity.Property(e => e.Trialfocalpoint2)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("TRIALFOCALPOINT2");

                entity.Property(e => e.Trialfocalpoint3)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("TRIALFOCALPOINT3");

                entity.Property(e => e.Trialfocalpoint4)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("TRIALFOCALPOINT4");

                entity.Property(e => e.Trialfocalpoint5)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("TRIALFOCALPOINT5");

                entity.Property(e => e.Trialfp)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("TRIALFP");

                entity.Property(e => e.Trialname)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TRIALNAME");

                entity.Property(e => e.Trialobjectives)
                    .HasColumnType("CLOB")
                    .HasColumnName("TRIALOBJECTIVES");

                entity.Property(e => e.Trialstartringyear)
                    .HasPrecision(6)
                    .HasColumnName("TRIALSTARTRINGYEAR");

                entity.Property(e => e.Workspace)
                    .HasColumnType("CLOB")
                    .HasColumnName("WORKSPACE");
            });

            modelBuilder.Entity<ImpCtrAlternativeSolution>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_ALTERNATIVE_SOLUTIONS");

                entity.Property(e => e.Ctrrefnumber)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNUMBER");

                entity.Property(e => e.Remarks)
                    .HasMaxLength(2144)
                    .IsUnicode(false)
                    .HasColumnName("REMARKS");

                entity.Property(e => e.Serial)
                    .HasPrecision(1)
                    .HasColumnName("SERIAL");

                entity.Property(e => e.SolutionTitle)
                    .HasMaxLength(193)
                    .IsUnicode(false)
                    .HasColumnName("SOLUTION_TITLE");
            });

            modelBuilder.Entity<ImpCtrApproval>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_APPROVAL");

                entity.Property(e => e.Approvedby)
                    .HasMaxLength(1280)
                    .IsUnicode(false)
                    .HasColumnName("APPROVEDBY");

                entity.Property(e => e.Approvedon)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("APPROVEDON");

                entity.Property(e => e.Approversequence)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("APPROVERSEQUENCE");

                entity.Property(e => e.Approvertype)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("APPROVERTYPE");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.Ctrid)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CTRID");

                entity.Property(e => e.Id)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ID");

                entity.Property(e => e.Isapproved)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ISAPPROVED");

                entity.Property(e => e.Isdeleted)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ISDELETED");

                entity.Property(e => e.Modified)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED");

                entity.Property(e => e.Title)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");
            });

            modelBuilder.Entity<ImpCtrBudget>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_BUDGET");

                entity.Property(e => e.Budgetamount)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("BUDGETAMOUNT");

                entity.Property(e => e.Budgetprovider)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("BUDGETPROVIDER");

                entity.Property(e => e.Budgetquarter)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("BUDGETQUARTER");

                entity.Property(e => e.Budgetyear)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("BUDGETYEAR");

                entity.Property(e => e.Ctrrefnumber)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNUMBER");

                entity.Property(e => e.Currency)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CURRENCY");

                entity.Property(e => e.Itemprovider)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("ITEMPROVIDER");

                entity.Property(e => e.Resourcedescription)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("RESOURCEDESCRIPTION");

                entity.Property(e => e.Title)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");
            });

            modelBuilder.Entity<ImpCtrDeploymentstaircase>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_DEPLOYMENTSTAIRCASE");

                entity.Property(e => e.Ctrrefnumber)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNUMBER");

                entity.Property(e => e.Title)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");

                entity.Property(e => e.Year1)
                    .HasPrecision(6)
                    .HasColumnName("YEAR1");

                entity.Property(e => e.Year1vot)
                    .HasColumnType("NUMBER(12,3)")
                    .HasColumnName("YEAR1VOT");

                entity.Property(e => e.Year1wells)
                    .HasPrecision(6)
                    .HasColumnName("YEAR1WELLS");

                entity.Property(e => e.Year2)
                    .HasPrecision(6)
                    .HasColumnName("YEAR2");

                entity.Property(e => e.Year2vot)
                    .HasColumnType("NUMBER(12,3)")
                    .HasColumnName("YEAR2VOT");

                entity.Property(e => e.Year2wells)
                    .HasPrecision(7)
                    .HasColumnName("YEAR2WELLS");

                entity.Property(e => e.Year3)
                    .HasPrecision(6)
                    .HasColumnName("YEAR3");

                entity.Property(e => e.Year3vot)
                    .HasColumnType("NUMBER(12,3)")
                    .HasColumnName("YEAR3VOT");

                entity.Property(e => e.Year3wells)
                    .HasPrecision(6)
                    .HasColumnName("YEAR3WELLS");

                entity.Property(e => e.Year4)
                    .HasPrecision(6)
                    .HasColumnName("YEAR4");

                entity.Property(e => e.Year4vot)
                    .HasColumnType("NUMBER(11,3)")
                    .HasColumnName("YEAR4VOT");

                entity.Property(e => e.Year4wells)
                    .HasPrecision(6)
                    .HasColumnName("YEAR4WELLS");

                entity.Property(e => e.Year5)
                    .HasPrecision(6)
                    .HasColumnName("YEAR5");

                entity.Property(e => e.Year5vot)
                    .HasColumnType("NUMBER(9,2)")
                    .HasColumnName("YEAR5VOT");

                entity.Property(e => e.Year5wells)
                    .HasPrecision(6)
                    .HasColumnName("YEAR5WELLS");

                entity.Property(e => e.Year6)
                    .HasPrecision(6)
                    .HasColumnName("YEAR6");

                entity.Property(e => e.Year6vot)
                    .HasColumnType("NUMBER(8,1)")
                    .HasColumnName("YEAR6VOT");

                entity.Property(e => e.Year6wells)
                    .HasPrecision(5)
                    .HasColumnName("YEAR6WELLS");
            });

            modelBuilder.Entity<ImpCtrDsAddNote>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_DS_ADD_NOTES");

                entity.Property(e => e.Additionalnotes)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("ADDITIONALNOTES");

                entity.Property(e => e.AssumptionsMade)
                    .HasColumnType("CLOB")
                    .HasColumnName("ASSUMPTIONS_MADE");

                entity.Property(e => e.Comments)
                    .HasColumnType("CLOB")
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.Ctrrefnumber)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNUMBER");

                entity.Property(e => e.Title)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");
            });

            modelBuilder.Entity<ImpCtrHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_HISTORY");

                entity.Property(e => e.Approver)
                    .HasMaxLength(39)
                    .IsUnicode(false)
                    .HasColumnName("APPROVER");

                entity.Property(e => e.Comments)
                    .HasMaxLength(1122)
                    .IsUnicode(false)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.Ctrid)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("CTRID");

                entity.Property(e => e.Ctrrefno)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNO");

                entity.Property(e => e.Id)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ID");

                entity.Property(e => e.Modified)
                    .HasMaxLength(16)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED");

                entity.Property(e => e.ModifiedBy)
                    .HasMaxLength(34)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED_BY");

                entity.Property(e => e.Nextseq)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("NEXTSEQ");

                entity.Property(e => e.RoleName)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("ROLE_NAME");

                entity.Property(e => e.StatusName)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("STATUS_NAME");

                entity.Property(e => e.Taskstatus)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("TASKSTATUS");

                entity.Property(e => e.Tasktype)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("TASKTYPE");

                entity.Property(e => e.Title)
                    .HasMaxLength(42)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");
            });

            modelBuilder.Entity<ImpCtrImpactedContract>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_IMPACTED_CONTRACT");

                entity.Property(e => e.Contractnumber)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACTNUMBER");

                entity.Property(e => e.Contractor)
                    .HasMaxLength(1280)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACTOR");

                entity.Property(e => e.Contracttitle)
                    .HasMaxLength(1280)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACTTITLE");

                entity.Property(e => e.Ctrrefnumber)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNUMBER");

                entity.Property(e => e.Natureofimpact)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("NATUREOFIMPACT");

                entity.Property(e => e.Serial)
                    .HasPrecision(3)
                    .HasColumnName("SERIAL");
            });

            modelBuilder.Entity<ImpCtrRiskPlan>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_RISK_PLAN");

                entity.Property(e => e.Ctrrefnumber)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNUMBER");

                entity.Property(e => e.Mitigationplan)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("MITIGATIONPLAN");

                entity.Property(e => e.Risk)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("RISK");

                entity.Property(e => e.Serial)
                    .HasPrecision(3)
                    .HasColumnName("SERIAL");
            });

            modelBuilder.Entity<ImpCtrScAddNote>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_SC_ADD_NOTES");

                entity.Property(e => e.AdditionalNotes)
                    .HasColumnType("CLOB")
                    .HasColumnName("ADDITIONAL_NOTES");

                entity.Property(e => e.CtrRefno)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("CTR_REFNO");
            });

            modelBuilder.Entity<ImpCtrSuccessCriterion>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_SUCCESS_CRITERIA");

                entity.Property(e => e.Active)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ACTIVE");

                entity.Property(e => e.Ctrrefnumber)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNUMBER");

                entity.Property(e => e.Currentvalue)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("CURRENTVALUE");

                entity.Property(e => e.Decisiongateimpacted)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("DECISIONGATEIMPACTED");

                entity.Property(e => e.Parameter)
                    .HasMaxLength(1024)
                    .IsUnicode(false)
                    .HasColumnName("PARAMETER");

                entity.Property(e => e.Parameterevaluationfrequency)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("PARAMETEREVALUATIONFREQUENCY");

                entity.Property(e => e.Parameterevaluationmethod)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("PARAMETEREVALUATIONMETHOD");

                entity.Property(e => e.Serial)
                    .HasPrecision(3)
                    .HasColumnName("SERIAL");

                entity.Property(e => e.Trialtarget)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TRIALTARGET");
            });

            modelBuilder.Entity<ImpCtrTask>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_TASKS");

                entity.Property(e => e.Approver)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("APPROVER");

                entity.Property(e => e.Comments)
                    .HasColumnType("CLOB")
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.Ctrid)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CTRID");

                entity.Property(e => e.Ctrrefno)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNO");

                entity.Property(e => e.Id)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ID");

                entity.Property(e => e.Modified)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED");

                entity.Property(e => e.ModifiedBy)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED_BY");

                entity.Property(e => e.Nextseq)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("NEXTSEQ");

                entity.Property(e => e.Taskstatus)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("TASKSTATUS");

                entity.Property(e => e.Tasktype)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TASKTYPE");

                entity.Property(e => e.Title)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");
            });

            modelBuilder.Entity<ImpCtrTrialPlan>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_CTR_TRIAL_PLAN");

                entity.Property(e => e.Ctrrefnumber)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNUMBER");

                entity.Property(e => e.Deliverabletollgatedecision)
                    .HasMaxLength(1280)
                    .IsUnicode(false)
                    .HasColumnName("DELIVERABLETOLLGATEDECISION");

                entity.Property(e => e.Deliverydecisionby)
                    .HasMaxLength(1280)
                    .IsUnicode(false)
                    .HasColumnName("DELIVERYDECISIONBY");

                entity.Property(e => e.Remarks)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("REMARKS");

                entity.Property(e => e.Sequence)
                    .HasColumnType("NUMBER(30)")
                    .HasColumnName("SEQUENCE");

                entity.Property(e => e.Title)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");

                entity.Property(e => e.Y1q1)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("Y1Q1");

                entity.Property(e => e.Y1q2)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("Y1Q2");

                entity.Property(e => e.Y1q3)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("Y1Q3");

                entity.Property(e => e.Y1q4)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("Y1Q4");

                entity.Property(e => e.Y2q1)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("Y2Q1");

                entity.Property(e => e.Y2q2)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("Y2Q2");

                entity.Property(e => e.Y2q3)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("Y2Q3");

                entity.Property(e => e.Y2q4)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("Y2Q4");

                entity.Property(e => e.Y3q1)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("Y3Q1");

                entity.Property(e => e.Y3q2)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("Y3Q2");

                entity.Property(e => e.Y3q3)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("Y3Q3");

                entity.Property(e => e.Y3q4)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("Y3Q4");

                entity.Property(e => e.Year1)
                    .HasPrecision(4)
                    .HasColumnName("YEAR1");

                entity.Property(e => e.Year2)
                    .HasPrecision(4)
                    .HasColumnName("YEAR2");

                entity.Property(e => e.Year3)
                    .HasPrecision(4)
                    .HasColumnName("YEAR3");
            });

            modelBuilder.Entity<ImpEmployeeLive>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_EMPLOYEE_LIVE");

                entity.Property(e => e.CompanyNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("COMPANY_NUMBER");

                entity.Property(e => e.CompnoNameRefindicator)
                    .HasMaxLength(1454)
                    .IsUnicode(false)
                    .HasColumnName("COMPNO_NAME_REFINDICATOR");

                entity.Property(e => e.EmailAddress)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("EMAIL_ADDRESS");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(131)
                    .IsUnicode(false)
                    .HasColumnName("EMPLOYEE_NAME");

                entity.Property(e => e.EmploymentStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("EMPLOYMENT_STATUS");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("FIRST_NAME");

                entity.Property(e => e.FullName)
                    .HasMaxLength(121)
                    .IsUnicode(false)
                    .HasColumnName("FULL_NAME");

                entity.Property(e => e.JobDescription)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("JOB_DESCRIPTION");

                entity.Property(e => e.LastName)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("LAST_NAME");

                entity.Property(e => e.LxrefIndicatorN)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("LXREF_INDICATOR_N")
                    .IsFixedLength(true);

                entity.Property(e => e.OfficePhone)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("OFFICE_PHONE");

                entity.Property(e => e.ReferenceIndicator)
                    .HasMaxLength(90)
                    .IsUnicode(false)
                    .HasColumnName("REFERENCE_INDICATOR");

                entity.Property(e => e.SupervisorId)
                    .HasMaxLength(80)
                    .IsUnicode(false)
                    .HasColumnName("SUPERVISOR_ID");
            });

            modelBuilder.Entity<ImpMigratedChallenge>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_MIGRATED_CHALLENGES");

                entity.Property(e => e.Ntp)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("NTP");

                entity.Property(e => e.Tip)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("TIP");
            });

            modelBuilder.Entity<ImpPir>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_PIR");

                entity.Property(e => e.Agentname)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("AGENTNAME");

                entity.Property(e => e.Application)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("APPLICATION");

                entity.Property(e => e.Availability)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("AVAILABILITY");

                entity.Property(e => e.Challengeaddress)
                    .HasColumnType("CLOB")
                    .HasColumnName("CHALLENGEADDRESS");

                entity.Property(e => e.Conclusionsummary)
                    .HasColumnType("CLOB")
                    .HasColumnName("CONCLUSIONSUMMARY");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.Ctrreferenceno)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFERENCENO");

                entity.Property(e => e.Deployment)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("DEPLOYMENT");

                entity.Property(e => e.Descriptionofchallenge)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("DESCRIPTIONOFCHALLENGE");

                entity.Property(e => e.Id)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ID");

                entity.Property(e => e.Isfocalpointassigned)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ISFOCALPOINTASSIGNED");

                entity.Property(e => e.Modified)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED");

                entity.Property(e => e.Novelty)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("NOVELTY");

                entity.Property(e => e.Pirreferenceno)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("PIRREFERENCENO");

                entity.Property(e => e.Pirstatus)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("PIRSTATUS");

                entity.Property(e => e.Staircaseyear1)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("STAIRCASEYEAR1");

                entity.Property(e => e.Staircaseyear2)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("STAIRCASEYEAR2");

                entity.Property(e => e.Staircaseyear3)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("STAIRCASEYEAR3");

                entity.Property(e => e.Staircaseyear4)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("STAIRCASEYEAR4");

                entity.Property(e => e.Staircaseyear5)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("STAIRCASEYEAR5");

                entity.Property(e => e.Staircaseyear6)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("STAIRCASEYEAR6");

                entity.Property(e => e.Supportingteammembers)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("SUPPORTINGTEAMMEMBERS");

                entity.Property(e => e.Tfpoint)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("TFPOINT");

                entity.Property(e => e.Title)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");

                entity.Property(e => e.Trailconclusiondate)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TRAILCONCLUSIONDATE");

                entity.Property(e => e.TrialType)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TRIAL_TYPE");

                entity.Property(e => e.Trialcommencementdate)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TRIALCOMMENCEMENTDATE");

                entity.Property(e => e.Trialedwells)
                    .IsUnicode(false)
                    .HasColumnName("TRIALEDWELLS");

                entity.Property(e => e.Trialfocalpoint1)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("TRIALFOCALPOINT1");

                entity.Property(e => e.Trialfocalpoint2)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("TRIALFOCALPOINT2");

                entity.Property(e => e.Trialfocalpoint3)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("TRIALFOCALPOINT3");

                entity.Property(e => e.Trialfocalpoint4)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TRIALFOCALPOINT4");

                entity.Property(e => e.Trialfocalpoint5)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TRIALFOCALPOINT5");

                entity.Property(e => e.Trialname)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TRIALNAME");

                entity.Property(e => e.Trialresult)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TRIALRESULT");

                entity.Property(e => e.Trialyear)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TRIALYEAR");
            });

            modelBuilder.Entity<ImpPirApproval>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_PIR_APPROVAL");

                entity.Property(e => e.Approvedby)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("APPROVEDBY");

                entity.Property(e => e.Approvedon)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("APPROVEDON");

                entity.Property(e => e.Approversequence)
                    .HasColumnType("NUMBER(20)")
                    .HasColumnName("APPROVERSEQUENCE");

                entity.Property(e => e.Approvertype)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("APPROVERTYPE");

                entity.Property(e => e.Id)
                    .HasColumnType("NUMBER(20)")
                    .HasColumnName("ID");

                entity.Property(e => e.Isapproved)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("ISAPPROVED");

                entity.Property(e => e.Pirid)
                    .HasColumnType("NUMBER(20)")
                    .HasColumnName("PIRID");

                entity.Property(e => e.Serialno)
                    .HasPrecision(10)
                    .HasColumnName("SERIALNO");

                entity.Property(e => e.Status)
                    .HasColumnType("NUMBER(20)")
                    .HasColumnName("STATUS");

                entity.Property(e => e.Taskid)
                    .HasPrecision(10)
                    .HasColumnName("TASKID");

                entity.Property(e => e.Title)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");
            });

            modelBuilder.Entity<ImpPirCommon>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_PIR_COMMON");

                entity.Property(e => e.Assumptionsmade)
                    .HasColumnType("CLOB")
                    .HasColumnName("ASSUMPTIONSMADE");

                entity.Property(e => e.Id)
                    .HasPrecision(4)
                    .HasColumnName("ID");

                entity.Property(e => e.Lessonlearntnotes)
                    .HasColumnType("CLOB")
                    .HasColumnName("LESSONLEARNTNOTES");

                entity.Property(e => e.Pirid)
                    .HasPrecision(4)
                    .HasColumnName("PIRID");

                entity.Property(e => e.Staircasecomments)
                    .HasColumnType("CLOB")
                    .HasColumnName("STAIRCASECOMMENTS");

                entity.Property(e => e.Successcriterianotes)
                    .HasColumnType("CLOB")
                    .HasColumnName("SUCCESSCRITERIANOTES");

                entity.Property(e => e.Title)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");
            });

            modelBuilder.Entity<ImpPirDepStaircase>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_PIR_DEP_STAIRCASE");

                entity.Property(e => e.Fieldorstation)
                    .HasMaxLength(72)
                    .IsUnicode(false)
                    .HasColumnName("FIELDORSTATION");

                entity.Property(e => e.Pirid)
                    .HasPrecision(2)
                    .HasColumnName("PIRID");

                entity.Property(e => e.Title)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");

                entity.Property(e => e.Year1estvot)
                    .HasMaxLength(9)
                    .IsUnicode(false)
                    .HasColumnName("YEAR1ESTVOT");

                entity.Property(e => e.Year1wells)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("YEAR1WELLS");

                entity.Property(e => e.Year2estvot)
                    .HasMaxLength(9)
                    .IsUnicode(false)
                    .HasColumnName("YEAR2ESTVOT");

                entity.Property(e => e.Year2wells)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("YEAR2WELLS");

                entity.Property(e => e.Year3estvot)
                    .HasMaxLength(9)
                    .IsUnicode(false)
                    .HasColumnName("YEAR3ESTVOT");

                entity.Property(e => e.Year3wells)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("YEAR3WELLS");

                entity.Property(e => e.Year4estvot)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("YEAR4ESTVOT");

                entity.Property(e => e.Year4wells)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("YEAR4WELLS");

                entity.Property(e => e.Year5estvot)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("YEAR5ESTVOT");

                entity.Property(e => e.Year5wells)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("YEAR5WELLS");

                entity.Property(e => e.Year6estvot)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("YEAR6ESTVOT");

                entity.Property(e => e.Year6wells)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("YEAR6WELLS");
            });

            modelBuilder.Entity<ImpPirHistory>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_PIR_HISTORY");

                entity.Property(e => e.Approver)
                    .HasMaxLength(45)
                    .IsUnicode(false)
                    .HasColumnName("APPROVER");

                entity.Property(e => e.Id)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ID");

                entity.Property(e => e.Modified)
                    .HasMaxLength(16)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED");

                entity.Property(e => e.Nextseq)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("NEXTSEQ");

                entity.Property(e => e.Pirid)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("PIRID");

                entity.Property(e => e.Pirrefno)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("PIRREFNO");

                entity.Property(e => e.Reassignapprover)
                    .HasMaxLength(21)
                    .IsUnicode(false)
                    .HasColumnName("REASSIGNAPPROVER");

                entity.Property(e => e.RoleName)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("ROLE_NAME");

                entity.Property(e => e.StatusName)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("STATUS_NAME");

                entity.Property(e => e.Submittedby)
                    .HasMaxLength(39)
                    .IsUnicode(false)
                    .HasColumnName("SUBMITTEDBY");

                entity.Property(e => e.Taskdescription)
                    .HasMaxLength(83)
                    .IsUnicode(false)
                    .HasColumnName("TASKDESCRIPTION");

                entity.Property(e => e.Taskstatus)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("TASKSTATUS");

                entity.Property(e => e.Tasktype)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("TASKTYPE");

                entity.Property(e => e.Title)
                    .HasMaxLength(39)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");
            });

            modelBuilder.Entity<ImpPirLessonlearnt>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_PIR_LESSONLEARNT");

                entity.Property(e => e.Correctivemeasures)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("CORRECTIVEMEASURES");

                entity.Property(e => e.Id)
                    .HasPrecision(5)
                    .HasColumnName("ID");

                entity.Property(e => e.Lessonlearnt)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("LESSONLEARNT");

                entity.Property(e => e.Pirid)
                    .HasPrecision(4)
                    .HasColumnName("PIRID");
            });

            modelBuilder.Entity<ImpPirPotentialimpacted>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_PIR_POTENTIALIMPACTED");

                entity.Property(e => e.Contractno)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACTNO");

                entity.Property(e => e.Contractor)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACTOR");

                entity.Property(e => e.Contracttitle)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACTTITLE");

                entity.Property(e => e.Natureofimpact)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("NATUREOFIMPACT");

                entity.Property(e => e.Pirid)
                    .HasPrecision(10)
                    .HasColumnName("PIRID");

                entity.Property(e => e.Title)
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");
            });

            modelBuilder.Entity<ImpPirSuccessCriterion>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_PIR_SUCCESS_CRITERIA");

                entity.Property(e => e.Comments)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.Conclusion)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("CONCLUSION");

                entity.Property(e => e.Lessonlearnt)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("LESSONLEARNT");

                entity.Property(e => e.Parameter)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("PARAMETER");

                entity.Property(e => e.Pirid)
                    .HasPrecision(10)
                    .HasColumnName("PIRID");

                entity.Property(e => e.Targetvalue)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TARGETVALUE");

                entity.Property(e => e.Title)
                    .HasMaxLength(1024)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");
            });

            modelBuilder.Entity<ImpPirTrialcandidate>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_PIR_TRIALCANDIDATE");

                entity.Property(e => e.Candidatetype)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CANDIDATETYPE");

                entity.Property(e => e.Challengedescription)
                    .HasColumnType("CLOB")
                    .HasColumnName("CHALLENGEDESCRIPTION");

                entity.Property(e => e.Cost)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("COST");

                entity.Property(e => e.Id)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ID");

                entity.Property(e => e.Isdeleted)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ISDELETED");

                entity.Property(e => e.Name)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("NAME");

                entity.Property(e => e.Pirid)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("PIRID");

                entity.Property(e => e.Title)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");

                entity.Property(e => e.Trailcommencementdate)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TRAILCOMMENCEMENTDATE");

                entity.Property(e => e.Trailconclusiondate)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TRAILCONCLUSIONDATE");

                entity.Property(e => e.Trialoutcome)
                    .HasColumnType("CLOB")
                    .HasColumnName("TRIALOUTCOME");
            });

            modelBuilder.Entity<ImpQA>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_Q_A");

                entity.Property(e => e.Queryanswer)
                    .HasColumnType("CLOB")
                    .HasColumnName("QUERYANSWER");

                entity.Property(e => e.Querytext)
                    .HasColumnType("CLOB")
                    .HasColumnName("QUERYTEXT");

                entity.Property(e => e.TphChallenge)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TPH_CHALLENGE");

                entity.Property(e => e.Vendor)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("VENDOR");
            });

            modelBuilder.Entity<ImpQuery>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_QUERIES");

                entity.Property(e => e.ChallengeId)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.QueryAnswer)
                    .HasColumnType("CLOB")
                    .HasColumnName("QUERY_ANSWER");

                entity.Property(e => e.QueryDate)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("QUERY_DATE");

                entity.Property(e => e.QueryId)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("QUERY_ID");

                entity.Property(e => e.QueryText)
                    .HasColumnType("CLOB")
                    .HasColumnName("QUERY_TEXT");

                entity.Property(e => e.QuestionId)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("QUESTION_ID");

                entity.Property(e => e.RefId)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("REF_ID");

                entity.Property(e => e.ReplyDate)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("REPLY_DATE");

                entity.Property(e => e.StatusId)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.VendorId)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("VENDOR_ID");
            });

            modelBuilder.Entity<ImpTechBank>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_TECH_BANK");

                entity.Property(e => e.Application)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("APPLICATION");

                entity.Property(e => e.Created)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("CREATED");

                entity.Property(e => e.Id)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("ID");

                entity.Property(e => e.Subtheme)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("SUBTHEME");

                entity.Property(e => e.Technologyreferencenumber)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("TECHNOLOGYREFERENCENUMBER");

                entity.Property(e => e.Theme)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("THEME");

                entity.Property(e => e.Title)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");

                entity.Property(e => e.Vendor)
                    .HasMaxLength(1280)
                    .IsUnicode(false)
                    .HasColumnName("VENDOR");
            });

            modelBuilder.Entity<ImpTechSelection>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_TECH_SELECTION");

                entity.Property(e => e.Alternativesolutions)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ALTERNATIVESOLUTIONS");

                entity.Property(e => e.Ctrrefnumber)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CTRREFNUMBER");

                entity.Property(e => e.Id)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ID");

                entity.Property(e => e.Maturity)
                    .HasColumnType("CLOB")
                    .HasColumnName("MATURITY");

                entity.Property(e => e.Maturitylevel)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("MATURITYLEVEL");

                entity.Property(e => e.Modified)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED");

                entity.Property(e => e.Technologydescription)
                    .HasColumnType("CLOB")
                    .HasColumnName("TECHNOLOGYDESCRIPTION");

                entity.Property(e => e.Technologyname)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("TECHNOLOGYNAME");

                entity.Property(e => e.Title)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");
            });

            modelBuilder.Entity<ImpTph>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_TPH");

                entity.Property(e => e.AreaId)
                    .HasPrecision(18)
                    .HasColumnName("AREA_ID");

                entity.Property(e => e.AssetId)
                    .HasPrecision(18)
                    .HasColumnName("ASSET_ID");

                entity.Property(e => e.Challengereferenceno)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("CHALLENGEREFERENCENO");

                entity.Property(e => e.Challengetitle)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("CHALLENGETITLE");

                entity.Property(e => e.ClusterId)
                    .HasPrecision(18)
                    .HasColumnName("CLUSTER_ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.ExpiryStatus)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("EXPIRY_STATUS");

                entity.Property(e => e.Id)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ID");

                entity.Property(e => e.Lastdatequery)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("LASTDATEQUERY");

                entity.Property(e => e.Lastdatetoresponse)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("LASTDATETORESPONSE");

                entity.Property(e => e.Modified)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED");

                entity.Property(e => e.ModifiedBy)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED_BY");

                entity.Property(e => e.Publishedby)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("PUBLISHEDBY");

                entity.Property(e => e.Publisheddate)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("PUBLISHEDDATE");

                entity.Property(e => e.Responselastdate)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("RESPONSELASTDATE");

                entity.Property(e => e.Status)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("STATUS");

                entity.Property(e => e.TphChallengeId)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("TPH_CHALLENGE_ID");

                entity.Property(e => e.Tphreferenceno)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("TPHREFERENCENO");
            });

            modelBuilder.Entity<ImpTphTask>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_TPH_TASKS");

                entity.Property(e => e.Approvedby)
                    .HasMaxLength(39)
                    .IsUnicode(false)
                    .HasColumnName("APPROVEDBY");

                entity.Property(e => e.ApprovedbyMu)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("APPROVEDBY_MU");

                entity.Property(e => e.Assignedby)
                    .HasMaxLength(29)
                    .IsUnicode(false)
                    .HasColumnName("ASSIGNEDBY");

                entity.Property(e => e.Comments)
                    .HasMaxLength(2014)
                    .IsUnicode(false)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.Created)
                    .HasMaxLength(16)
                    .IsUnicode(false)
                    .HasColumnName("CREATED");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(23)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.Expirydate)
                    .HasMaxLength(17)
                    .IsUnicode(false)
                    .HasColumnName("EXPIRYDATE");

                entity.Property(e => e.Modified)
                    .HasMaxLength(16)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED");

                entity.Property(e => e.Nextreminderdate)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("NEXTREMINDERDATE");

                entity.Property(e => e.Responseid)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("RESPONSEID");

                entity.Property(e => e.Responsereference)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("RESPONSEREFERENCE");

                entity.Property(e => e.Taskstatus)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("TASKSTATUS");
            });

            modelBuilder.Entity<ImpUpdateTechBank>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_UPDATE_TECH_BANK");

                entity.Property(e => e.ChallengeId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.ResponseId)
                    .HasPrecision(18)
                    .HasColumnName("RESPONSE_ID");

                entity.Property(e => e.TechId)
                    .HasPrecision(18)
                    .HasColumnName("TECH_ID");
            });

            modelBuilder.Entity<ImpVendorProfile>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_VENDOR_PROFILE");

                entity.Property(e => e.Companyorbranchname)
                    .HasMaxLength(99)
                    .IsUnicode(false)
                    .HasColumnName("COMPANYORBRANCHNAME");

                entity.Property(e => e.Contactpersonemail)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("CONTACTPERSONEMAIL");

                entity.Property(e => e.Contactpersonphoneno)
                    .HasMaxLength(128)
                    .IsUnicode(false)
                    .HasColumnName("CONTACTPERSONPHONENO");

                entity.Property(e => e.Emailaddress)
                    .HasMaxLength(42)
                    .IsUnicode(false)
                    .HasColumnName("EMAILADDRESS");

                entity.Property(e => e.Manufacturename)
                    .HasMaxLength(134)
                    .IsUnicode(false)
                    .HasColumnName("MANUFACTURENAME");

                entity.Property(e => e.Suppliercode)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("SUPPLIERCODE");

                entity.Property(e => e.TphVendorid)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("TPH_VENDORID");
            });

            modelBuilder.Entity<ImpVendorResponse>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_VENDOR_RESPONSES");

                entity.Property(e => e.AppModifiedBy)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("APP_MODIFIED_BY");

                entity.Property(e => e.Created)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("CREATED");

                entity.Property(e => e.Detailedsolution)
                    .HasColumnType("CLOB")
                    .HasColumnName("DETAILEDSOLUTION");

                entity.Property(e => e.Ismarked)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("ISMARKED");

                entity.Property(e => e.Modified)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED");

                entity.Property(e => e.ModifiedBy)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED_BY");

                entity.Property(e => e.Proposedtechnology)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("PROPOSEDTECHNOLOGY");

                entity.Property(e => e.Responseid)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("RESPONSEID");

                entity.Property(e => e.Responsereferenceno)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("RESPONSEREFERENCENO");

                entity.Property(e => e.Status)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("STATUS");

                entity.Property(e => e.Technologyid)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TECHNOLOGYID");

                entity.Property(e => e.TphResponseStatusId)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TPH_RESPONSE_STATUS_ID");

                entity.Property(e => e.Tphreference)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("TPHREFERENCE");

                entity.Property(e => e.Usercomments)
                    .HasColumnType("CLOB")
                    .HasColumnName("USERCOMMENTS");

                entity.Property(e => e.Vendor)
                    .HasMaxLength(1280)
                    .IsUnicode(false)
                    .HasColumnName("VENDOR");

                entity.Property(e => e.Vendorresponse)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("VENDORRESPONSE");
            });

            modelBuilder.Entity<ImpVendorResponseFile>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_VENDOR_RESPONSE_FILES");

                entity.Property(e => e.AttachmentType)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("ATTACHMENT_TYPE");

                entity.Property(e => e.Attachmentcategory)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("ATTACHMENTCATEGORY");

                entity.Property(e => e.Attachmentpath)
                    .HasMaxLength(135)
                    .IsUnicode(false)
                    .HasColumnName("ATTACHMENTPATH");

                entity.Property(e => e.Created)
                    .HasMaxLength(16)
                    .IsUnicode(false)
                    .HasColumnName("CREATED");

                entity.Property(e => e.LiveLinkId)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("LIVE_LINK_ID");

                entity.Property(e => e.LiveLinkUrl)
                    .HasMaxLength(142)
                    .IsUnicode(false)
                    .HasColumnName("LIVE_LINK_URL");

                entity.Property(e => e.Modified)
                    .HasMaxLength(16)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED");

                entity.Property(e => e.Queryid)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("QUERYID");

                entity.Property(e => e.Responseid)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("RESPONSEID");

                entity.Property(e => e.Title)
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");

                entity.Property(e => e.TphAttachmentId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("TPH_ATTACHMENT_ID");

                entity.Property(e => e.TphQueryAttachmentId)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("TPH_QUERY_ATTACHMENT_ID");

                entity.Property(e => e.TphQueryid)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("TPH_QUERYID");

                entity.Property(e => e.TphResponseid)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("TPH_RESPONSEID");

                entity.Property(e => e.Updatelivelinkurl)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("UPDATELIVELINKURL");

                entity.Property(e => e.Vendorqueryid)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("VENDORQUERYID");
            });

            modelBuilder.Entity<ImpVendorScreeningAnswer>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_VENDOR_SCREENING_ANSWERS");

                entity.Property(e => e.Answer)
                    .HasColumnType("CLOB")
                    .HasColumnName("ANSWER");

                entity.Property(e => e.Id)
                    .HasPrecision(6)
                    .HasColumnName("ID");

                entity.Property(e => e.Mandatory)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("MANDATORY");

                entity.Property(e => e.Publishedchallengesquestion)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("PUBLISHEDCHALLENGESQUESTION");

                entity.Property(e => e.Responsereference)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("RESPONSEREFERENCE");

                entity.Property(e => e.Submitteddate)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("SUBMITTEDDATE");

                entity.Property(e => e.Title)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("TITLE");

                entity.Property(e => e.TphAnswerid)
                    .HasPrecision(6)
                    .HasColumnName("TPH_ANSWERID");

                entity.Property(e => e.TphResponseId)
                    .HasPrecision(6)
                    .HasColumnName("TPH_RESPONSE_ID");
            });

            modelBuilder.Entity<ImpVendorScreeningQstn>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("IMP_VENDOR_SCREENING_QSTNS");

                entity.Property(e => e.Isdeleted)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("ISDELETED");

                entity.Property(e => e.Mandatory)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("MANDATORY");

                entity.Property(e => e.Modified)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED");

                entity.Property(e => e.Question)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("QUESTION");

                entity.Property(e => e.Tph)
                    .HasMaxLength(26)
                    .IsUnicode(false)
                    .HasColumnName("TPH");

                entity.Property(e => e.TphChallengeId)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("TPH_CHALLENGE_ID");

                entity.Property(e => e.TphPublishedchallengeid)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("TPH_PUBLISHEDCHALLENGEID");

                entity.Property(e => e.TphQuestionId)
                    .HasMaxLength(260)
                    .IsUnicode(false)
                    .HasColumnName("TPH_QUESTION_ID");
            });

            modelBuilder.Entity<JobLog>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("JOB_LOG");

                entity.Property(e => e.JobName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("JOB_NAME");

                entity.Property(e => e.LogId)
                    .HasColumnType("NUMBER")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("LOG_ID");

                entity.Property(e => e.LogMessage)
                    .IsUnicode(false)
                    .HasColumnName("LOG_MESSAGE");

                entity.Property(e => e.LogTimestamp)
                    .HasPrecision(6)
                    .HasColumnName("LOG_TIMESTAMP");
            });

            modelBuilder.Entity<PainArea>(entity =>
            {
                entity.ToTable("PAIN_AREAS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.AssessmentId)
                    .HasPrecision(18)
                    .HasColumnName("ASSESSMENT_ID");

                entity.Property(e => e.ClusterId)
                    .HasPrecision(18)
                    .HasColumnName("CLUSTER_ID");

                entity.Property(e => e.Cost)
                    .HasMaxLength(200)
                    .HasColumnName("COST");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Deferment)
                    .HasMaxLength(100)
                    .HasColumnName("DEFERMENT");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.Emission)
                    .HasMaxLength(100)
                    .HasColumnName("EMISSION");

                entity.Property(e => e.Hsse)
                    .HasPrecision(18)
                    .HasColumnName("HSSE");

                entity.Property(e => e.LastReminder)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_REMINDER");

                entity.Property(e => e.NtCatalogSolution)
                    .HasPrecision(18)
                    .HasColumnName("NT_CATALOG_SOLUTION");

                entity.Property(e => e.NtSolution)
                    .HasPrecision(1)
                    .HasColumnName("NT_SOLUTION");

                entity.Property(e => e.NtSource)
                    .HasPrecision(18)
                    .HasColumnName("NT_SOURCE");

                entity.Property(e => e.RaisedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("RAISED_BY");

                entity.Property(e => e.Rank)
                    .HasPrecision(18)
                    .HasColumnName("RANK")
                    .HasDefaultValueSql("0");

                entity.Property(e => e.Reference)
                    .IsRequired()
                    .HasMaxLength(30)
                    .HasColumnName("REFERENCE");

                entity.Property(e => e.Remarks).HasColumnName("REMARKS");

                entity.Property(e => e.Status)
                    .HasPrecision(18)
                    .HasColumnName("STATUS");

                entity.Property(e => e.TechDescription)
                    .HasMaxLength(500)
                    .HasColumnName("TECH_DESCRIPTION");

                entity.Property(e => e.TechFp)
                    .HasMaxLength(10)
                    .HasColumnName("TECH_FP");

                entity.Property(e => e.UctFp)
                    .HasMaxLength(10)
                    .HasColumnName("UCT_FP");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Assessment)
                    .WithMany(p => p.PainAreas)
                    .HasForeignKey(d => d.AssessmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PAIN_AREAS_FK1");

                entity.HasOne(d => d.Cluster)
                    .WithMany(p => p.PainAreaClusters)
                    .HasForeignKey(d => d.ClusterId)
                    .HasConstraintName("PAIN_AREAS_FK4");

                entity.HasOne(d => d.HsseNavigation)
                    .WithMany(p => p.PainAreaHsseNavigations)
                    .HasForeignKey(d => d.Hsse)
                    .HasConstraintName("PAIN_AREAS_FK2");

                entity.HasOne(d => d.StatusNavigation)
                    .WithMany(p => p.PainAreaStatusNavigations)
                    .HasForeignKey(d => d.Status)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PAIN_AREAS_FK3");
            });

            modelBuilder.Entity<PdoToVendorQuery>(entity =>
            {
                entity.ToTable("PDO_TO_VENDOR_QUERIES");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.HasAttachment)
                    .HasPrecision(1)
                    .HasColumnName("HAS_ATTACHMENT");

                entity.Property(e => e.IsPublic)
                    .HasPrecision(1)
                    .HasColumnName("IS_PUBLIC");

                entity.Property(e => e.Query)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("QUERY");

                entity.Property(e => e.ResponseId)
                    .HasPrecision(18)
                    .HasColumnName("RESPONSE_ID");

                entity.HasOne(d => d.Response)
                    .WithMany(p => p.PdoToVendorQueries)
                    .HasForeignKey(d => d.ResponseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PDO_TO_VENDOR_QUERIES_FK1");
            });

            modelBuilder.Entity<PdoToVendorQueryResponse>(entity =>
            {
                entity.ToTable("PDO_TO_VENDOR_QUERY_RESPONSE");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.HasAttachment)
                    .HasPrecision(1)
                    .HasColumnName("HAS_ATTACHMENT");

                entity.Property(e => e.QueryId)
                    .HasPrecision(18)
                    .HasColumnName("QUERY_ID");

                entity.Property(e => e.Response)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("RESPONSE");

                entity.HasOne(d => d.Query)
                    .WithMany(p => p.PdoToVendorQueryResponses)
                    .HasForeignKey(d => d.QueryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PDO_TO_VENDOR_QUERY_RESPO_FK1");
            });

            modelBuilder.Entity<PirActionPlan>(entity =>
            {
                entity.ToTable("PIR_ACTION_PLAN");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Party)
                    .HasMaxLength(100)
                    .HasColumnName("PARTY");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.Target)
                    .HasColumnType("DATE")
                    .HasColumnName("TARGET");

                entity.Property(e => e.Title)
                    .HasMaxLength(100)
                    .HasColumnName("TITLE");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirActionPlans)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_ACTION_PLAN_FK1");
            });

            modelBuilder.Entity<PirApprovalList>(entity =>
            {
                entity.ToTable("PIR_APPROVAL_LIST");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ActionAssingedDate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTION_ASSINGED_DATE");

                entity.Property(e => e.ActionCompletionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTION_COMPLETION_DATE");

                entity.Property(e => e.ActionRequiredBy)
                    .HasMaxLength(20)
                    .HasColumnName("ACTION_REQUIRED_BY");

                entity.Property(e => e.Comments)
                    .HasMaxLength(500)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.JobCode)
                    .HasMaxLength(100)
                    .HasColumnName("JOB_CODE");

                entity.Property(e => e.JobTitle)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("JOB_TITLE");

                entity.Property(e => e.LastReminder)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_REMINDER");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.Seq)
                    .HasPrecision(18)
                    .HasColumnName("SEQ");

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasColumnName("STATUS");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirApprovalLists)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_APPROVAL_LIST_FK1");
            });

            modelBuilder.Entity<PirApprovalListHsty>(entity =>
            {
                entity.ToTable("PIR_APPROVAL_LIST_HSTY");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ActionAssingedDate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTION_ASSINGED_DATE");

                entity.Property(e => e.ActionCompletionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTION_COMPLETION_DATE");

                entity.Property(e => e.ActionRequiredBy)
                    .HasMaxLength(20)
                    .HasColumnName("ACTION_REQUIRED_BY");

                entity.Property(e => e.Comments)
                    .HasMaxLength(500)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.HistoryCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("HISTORY_CREATED_ON");

                entity.Property(e => e.JobCode)
                    .HasMaxLength(100)
                    .HasColumnName("JOB_CODE");

                entity.Property(e => e.JobTitle)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("JOB_TITLE");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.Seq)
                    .HasPrecision(18)
                    .HasColumnName("SEQ");

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasColumnName("STATUS");

                entity.Property(e => e.Version)
                    .HasPrecision(18)
                    .HasColumnName("VERSION")
                    .HasDefaultValueSql("0 ");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirApprovalListHsties)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_APPROVAL_LIST_HSTY_FK1");
            });

            modelBuilder.Entity<PirAssessmentTrialResult>(entity =>
            {
                entity.ToTable("PIR_ASSESSMENT_TRIAL_RESULTS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.Comments).HasColumnName("COMMENTS");

                entity.Property(e => e.ConclusionId)
                    .HasPrecision(18)
                    .HasColumnName("CONCLUSION_ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Parameter)
                    .IsRequired()
                    .HasColumnName("PARAMETER");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.Target)
                    .IsRequired()
                    .HasColumnName("TARGET");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Conclusion)
                    .WithMany(p => p.PirAssessmentTrialResults)
                    .HasForeignKey(d => d.ConclusionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_ASSESSMENT_TRIAL_RESULTS_FK1");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirAssessmentTrialResults)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_ASSESSMENT_TRIAL_RESULTS_FK2");
            });

            modelBuilder.Entity<PirDeploymentStaircase>(entity =>
            {
                entity.ToTable("PIR_DEPLOYMENT_STAIRCASE");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.AssumptionMode).HasColumnName("ASSUMPTION_MODE");

                entity.Property(e => e.Comments).HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.EstimatedVot)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("ESTIMATED_VOT");

                entity.Property(e => e.FeildStationName)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("FEILD_STATION_NAME");

                entity.Property(e => e.NoOfWells)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_WELLS");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.WellType)
                    .HasMaxLength(100)
                    .HasColumnName("WELL_TYPE");

                entity.Property(e => e.Year)
                    .HasPrecision(18)
                    .HasColumnName("YEAR");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirDeploymentStaircases)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_DEPLOYMENT_STAIRCASE_FK1");
            });

            modelBuilder.Entity<PirFlowHistory>(entity =>
            {
                entity.ToTable("PIR_FLOW_HISTORY");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Comments)
                    .HasMaxLength(500)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.DescInfo)
                    .HasMaxLength(200)
                    .HasColumnName("DESC_INFO");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.RoleId)
                    .HasPrecision(18)
                    .HasColumnName("ROLE_ID");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("USER_ID");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirFlowHistories)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_FLOW_HISTORY_FK1");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.PirFlowHistories)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("PIR_FLOW_HISTORY_FK3");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.PirFlowHistories)
                    .HasForeignKey(d => d.StatusId)
                    .HasConstraintName("PIR_FLOW_HISTORY_FK2");
            });

            modelBuilder.Entity<PirImpactedExistingContract>(entity =>
            {
                entity.ToTable("PIR_IMPACTED_EXISTING_CONTRACTS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ContractNo)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("CONTRACT_NO");

                entity.Property(e => e.ContractTitle)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("CONTRACT_TITLE");

                entity.Property(e => e.Contractor)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("CONTRACTOR");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Impact)
                    .IsRequired()
                    .HasMaxLength(500)
                    .HasColumnName("IMPACT");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirImpactedExistingContracts)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_IMPACTED_EXISTING_CONTRACTS_FK1");
            });

            modelBuilder.Entity<PirInitiation>(entity =>
            {
                entity.ToTable("PIR_INITIATION");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.AgentName)
                    .HasMaxLength(1000)
                    .HasColumnName("AGENT_NAME");

                entity.Property(e => e.AvailabilityId)
                    .HasPrecision(18)
                    .HasColumnName("AVAILABILITY_ID");

                entity.Property(e => e.ChallengesAddressed)
                    .HasColumnType("CLOB")
                    .HasColumnName("CHALLENGES_ADDRESSED");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.CurrentApprovalSeq)
                    .HasPrecision(18)
                    .HasColumnName("CURRENT_APPROVAL_SEQ");

                entity.Property(e => e.DeploymentScope).HasColumnName("DEPLOYMENT_SCOPE");

                entity.Property(e => e.DsAssumptionMode)
                    .HasColumnType("CLOB")
                    .HasColumnName("DS_ASSUMPTION_MODE");

                entity.Property(e => e.DsComments)
                    .HasColumnType("CLOB")
                    .HasColumnName("DS_COMMENTS");

                entity.Property(e => e.FirstTrialCommencementDate)
                    .HasColumnType("DATE")
                    .HasColumnName("FIRST_TRIAL_COMMENCEMENT_DATE");

                entity.Property(e => e.InterimDeploymentScope)
                    .HasMaxLength(200)
                    .HasColumnName("INTERIM_DEPLOYMENT_SCOPE");

                entity.Property(e => e.LastReminder)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_REMINDER");

                entity.Property(e => e.LastTrialConclutionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("LAST_TRIAL_CONCLUTION_DATE");

                entity.Property(e => e.NoveltyId)
                    .HasPrecision(18)
                    .HasColumnName("NOVELTY_ID");

                entity.Property(e => e.RefNo)
                    .HasMaxLength(200)
                    .HasColumnName("REF_NO");

                entity.Property(e => e.SentbackBy)
                    .HasMaxLength(3)
                    .HasColumnName("SENTBACK_BY");

                entity.Property(e => e.SentbackOn)
                    .HasColumnType("DATE")
                    .HasColumnName("SENTBACK_ON");

                entity.Property(e => e.Source)
                    .HasMaxLength(10)
                    .HasColumnName("SOURCE");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.SubmitCount)
                    .HasPrecision(18)
                    .HasColumnName("SUBMIT_COUNT")
                    .HasDefaultValueSql("0 ");

                entity.Property(e => e.SubmittedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("SUBMITTED_ON");

                entity.Property(e => e.TechProviderName).HasColumnName("TECH_PROVIDER_NAME");

                entity.Property(e => e.TrialCompleted)
                    .IsRequired()
                    .HasPrecision(1)
                    .HasColumnName("TRIAL_COMPLETED")
                    .HasDefaultValueSql("0 ");

                entity.Property(e => e.TrialType)
                    .HasMaxLength(500)
                    .HasColumnName("TRIAL_TYPE");

                entity.Property(e => e.TrialledWells).HasColumnName("TRIALLED_WELLS");

                entity.Property(e => e.UctFp)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("UCT_FP");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.WellType)
                    .HasMaxLength(200)
                    .HasColumnName("WELL_TYPE");

                entity.HasOne(d => d.Novelty)
                    .WithMany(p => p.PirInitiationNovelties)
                    .HasForeignKey(d => d.NoveltyId)
                    .HasConstraintName("PIR_INITIATION_FK2");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.PirInitiationStatuses)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_INITIATION_FK1");
            });

            modelBuilder.Entity<PirLessonLearnt>(entity =>
            {
                entity.ToTable("PIR_LESSON_LEARNT");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CorrectiveMeasures)
                    .IsRequired()
                    .HasColumnName("CORRECTIVE_MEASURES");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(40)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(40)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirLessonLearnts)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_LESSON_LEARNT_FK1");
            });

            modelBuilder.Entity<PirSummary>(entity =>
            {
                entity.ToTable("PIR_SUMMARY");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(40)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.Summary)
                    .HasColumnType("CLOB")
                    .HasColumnName("SUMMARY");

                entity.Property(e => e.TrialId)
                    .HasPrecision(18)
                    .HasColumnName("TRIAL_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(40)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirSummaries)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_SUMMARY_FK2");
            });

            modelBuilder.Entity<PirSupportingMember>(entity =>
            {
                entity.ToTable("PIR_SUPPORTING_MEMBERS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Fp)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("FP");

                entity.Property(e => e.JobTitle)
                    .HasMaxLength(200)
                    .HasColumnName("JOB_TITLE");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.RefId)
                    .HasMaxLength(20)
                    .HasColumnName("REF_ID");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirSupportingMembers)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIT_SUPPORTING_MEMBERS_FK1");
            });

            modelBuilder.Entity<PirTrialCandidate>(entity =>
            {
                entity.ToTable("PIR_TRIAL_CANDIDATES");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.ChallengeDescription)
                    .HasColumnType("CLOB")
                    .HasColumnName("CHALLENGE_DESCRIPTION");

                entity.Property(e => e.CommencementDate)
                    .HasColumnType("DATE")
                    .HasColumnName("COMMENCEMENT_DATE");

                entity.Property(e => e.Comments)
                    .HasColumnType("CLOB")
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.ConclusionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("CONCLUSION_DATE");

                entity.Property(e => e.Cost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("COST");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("NAME");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.TypeId)
                    .HasPrecision(18)
                    .HasColumnName("TYPE_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirTrialCandidates)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_TRIAL_CANDIDATES_FK2");

                entity.HasOne(d => d.Type)
                    .WithMany(p => p.PirTrialCandidates)
                    .HasForeignKey(d => d.TypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_TRIAL_CANDIDATES_FK1");
            });

            modelBuilder.Entity<PirTrialFp>(entity =>
            {
                entity.ToTable("PIR_TRIAL_FPS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Fp)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("FP");

                entity.Property(e => e.IsMandatory)
                    .HasPrecision(1)
                    .HasColumnName("IS_MANDATORY");

                entity.Property(e => e.JobTitle)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("JOB_TITLE");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.RefInd)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("REF_IND");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirTrialFps)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_TRIAL_FPS_FK1");
            });

            modelBuilder.Entity<PirVot>(entity =>
            {
                entity.ToTable("PIR_VOT");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.AvgIncrmntlOilGain)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("AVG_INCRMNTL_OIL_GAIN");

                entity.Property(e => e.Co2ReductnUnitYr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("CO2_REDUCTN_UNIT_YR");

                entity.Property(e => e.Co2Tax)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("CO2_TAX");

                entity.Property(e => e.Compliance)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("COMPLIANCE");

                entity.Property(e => e.CostAvoidance)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("COST_AVOIDANCE");

                entity.Property(e => e.CostSavingUnitYr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("COST_SAVING_UNIT_YR");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Hse)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("HSE");

                entity.Property(e => e.M3T0Bbl)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("M3_T0_BBL");

                entity.Property(e => e.MwhCost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("MWH_COST");

                entity.Property(e => e.NoOfUnitsTrailScope)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_TRAIL_SCOPE");

                entity.Property(e => e.NoOfUnitsYear1)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR1");

                entity.Property(e => e.NoOfUnitsYear2)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR2");

                entity.Property(e => e.NoOfUnitsYear3)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR3");

                entity.Property(e => e.NoOfUnitsYear4)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR4");

                entity.Property(e => e.NoOfUnitsYear5)
                    .HasPrecision(18)
                    .HasColumnName("NO_OF_UNITS_YEAR5");

                entity.Property(e => e.OilPrice)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("OIL_PRICE");

                entity.Property(e => e.OtherCost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("OTHER_COST");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.PowerSavingUnitYr)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("POWER_SAVING_UNIT_YR");

                entity.Property(e => e.Quality)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("QUALITY");

                entity.Property(e => e.RiskFactor)
                    .HasPrecision(18)
                    .HasColumnName("RISK_FACTOR");

                entity.Property(e => e.TechCost)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("TECH_COST");

                entity.Property(e => e.TotOilDefermentAvoidance)
                    .HasColumnType("NUMBER(18,3)")
                    .HasColumnName("TOT_OIL_DEFERMENT_AVOIDANCE");

                entity.Property(e => e.TotalCo2Reduction)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("TOTAL_CO2_REDUCTION");

                entity.Property(e => e.TotalMwhReduction)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("TOTAL_MWH_REDUCTION");

                entity.Property(e => e.UnitId)
                    .HasPrecision(18)
                    .HasColumnName("UNIT_ID");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.VotTotDeploymentUnits)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("VOT_TOT_DEPLOYMENT_UNITS");

                entity.Property(e => e.VotTrailTotUnits)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("VOT_TRAIL_TOT_UNITS");

                entity.Property(e => e.VotUnitYear)
                    .HasColumnType("NUMBER(32,3)")
                    .HasColumnName("VOT_UNIT_YEAR");

                entity.HasOne(d => d.Pir)
                    .WithMany(p => p.PirVots)
                    .HasForeignKey(d => d.PirId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PIR_VOT_FK1");
            });

            modelBuilder.Entity<SrFlowHistory>(entity =>
            {
                entity.ToTable("SR_FLOW_HISTORY");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Comments)
                    .HasMaxLength(1000)
                    .HasColumnName("COMMENTS");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.DescInfo)
                    .HasMaxLength(400)
                    .HasColumnName("DESC_INFO");

                entity.Property(e => e.ExternalUserId)
                    .HasPrecision(18)
                    .HasColumnName("EXTERNAL_USER_ID");

                entity.Property(e => e.IsExternal)
                    .HasPrecision(1)
                    .HasColumnName("IS_EXTERNAL");

                entity.Property(e => e.ResponseId)
                    .HasPrecision(18)
                    .HasColumnName("RESPONSE_ID");

                entity.Property(e => e.RoleId)
                    .HasPrecision(18)
                    .HasColumnName("ROLE_ID");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.UserId)
                    .HasMaxLength(40)
                    .HasColumnName("USER_ID");
            });

            modelBuilder.Entity<SubthemeCfdhLnk>(entity =>
            {
                entity.ToTable("SUBTHEME_CFDH_LNK");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.Cfdh)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CFDH");

                entity.Property(e => e.SubthemeId)
                    .HasPrecision(18)
                    .HasColumnName("SUBTHEME_ID");

                entity.HasOne(d => d.Subtheme)
                    .WithMany(p => p.SubthemeCfdhLnks)
                    .HasForeignKey(d => d.SubthemeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("SUBTHEME_CFDH_LNK_FK1");
            });

            modelBuilder.Entity<TechnologyBank>(entity =>
            {
                entity.ToTable("TECHNOLOGY_BANK");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Application)
                    .HasPrecision(18)
                    .HasColumnName("APPLICATION");

                entity.Property(e => e.Area)
                    .HasPrecision(18)
                    .HasColumnName("AREA");

                entity.Property(e => e.AssetId)
                    .HasPrecision(18)
                    .HasColumnName("ASSET_ID");

                entity.Property(e => e.ChallengeId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.ChallengeResponseId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_RESPONSE_ID");

                entity.Property(e => e.ClusterId)
                    .HasPrecision(18)
                    .HasColumnName("CLUSTER_ID");

                entity.Property(e => e.ContactEmail)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("CONTACT_EMAIL");

                entity.Property(e => e.ContactFp)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("CONTACT_FP");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Description)
                    .HasColumnType("CLOB")
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.RefNo)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("REF_NO");

                entity.Property(e => e.Source)
                    .HasPrecision(18)
                    .HasColumnName("SOURCE");

                entity.Property(e => e.SubTheme)
                    .HasPrecision(18)
                    .HasColumnName("SUB_THEME");

                entity.Property(e => e.Theme)
                    .HasPrecision(18)
                    .HasColumnName("THEME");

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("TITLE");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");

                entity.Property(e => e.Vendor)
                    .HasMaxLength(200)
                    .HasColumnName("VENDOR");

                entity.HasOne(d => d.ApplicationNavigation)
                    .WithMany(p => p.TechnologyBankApplicationNavigations)
                    .HasForeignKey(d => d.Application)
                    .HasConstraintName("TECHNOLOGY_BANK_FK4");

                entity.HasOne(d => d.AreaNavigation)
                    .WithMany(p => p.TechnologyBankAreaNavigations)
                    .HasForeignKey(d => d.Area)
                    .HasConstraintName("TECHNOLOGY_BANK_FK1");

                entity.HasOne(d => d.Challenge)
                    .WithMany(p => p.TechnologyBanks)
                    .HasForeignKey(d => d.ChallengeId)
                    .HasConstraintName("TECHNOLOGY_BANK_FK6");

                entity.HasOne(d => d.ChallengeResponse)
                    .WithMany(p => p.TechnologyBanks)
                    .HasForeignKey(d => d.ChallengeResponseId)
                    .HasConstraintName("TECHNOLOGY_BANK_FK7");

                entity.HasOne(d => d.SourceNavigation)
                    .WithMany(p => p.TechnologyBankSourceNavigations)
                    .HasForeignKey(d => d.Source)
                    .HasConstraintName("TECHNOLOGY_BANK_FK5");

                entity.HasOne(d => d.SubThemeNavigation)
                    .WithMany(p => p.TechnologyBankSubThemeNavigations)
                    .HasForeignKey(d => d.SubTheme)
                    .HasConstraintName("TECHNOLOGY_BANK_FK3");

                entity.HasOne(d => d.ThemeNavigation)
                    .WithMany(p => p.TechnologyBankThemeNavigations)
                    .HasForeignKey(d => d.Theme)
                    .HasConstraintName("TECHNOLOGY_BANK_FK2");
            });

            modelBuilder.Entity<TechnologyKpiConfig>(entity =>
            {
                entity.ToTable("TECHNOLOGY_KPI_CONFIG");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.MaxDays)
                    .HasPrecision(18)
                    .HasColumnName("MAX_DAYS");

                entity.Property(e => e.StatusId)
                    .HasPrecision(18)
                    .HasColumnName("STATUS_ID");

                entity.Property(e => e.Year)
                    .HasPrecision(18)
                    .HasColumnName("YEAR");
            });

            modelBuilder.Entity<TempApproverNull>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("TEMP_APPROVER_NULL");

                entity.Property(e => e.Approvedby)
                    .HasMaxLength(39)
                    .IsUnicode(false)
                    .HasColumnName("APPROVEDBY");

                entity.Property(e => e.ApprovedbyName)
                    .HasMaxLength(156)
                    .IsUnicode(false)
                    .HasColumnName("APPROVEDBY_NAME");

                entity.Property(e => e.ChallengeId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.CompanyNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("COMPANY_NUMBER");

                entity.Property(e => e.Count)
                    .HasColumnType("NUMBER")
                    .HasColumnName("COUNT");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(131)
                    .IsUnicode(false)
                    .HasColumnName("EMPLOYEE_NAME");

                entity.Property(e => e.IsReviewed)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("IS_REVIEWED");

                entity.Property(e => e.ReferenceNo)
                    .IsRequired()
                    .HasMaxLength(25)
                    .HasColumnName("REFERENCE_NO");
            });

            modelBuilder.Entity<TempSrNull>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("TEMP_SR_NULL");

                entity.Property(e => e.Approvedby)
                    .HasMaxLength(39)
                    .IsUnicode(false)
                    .HasColumnName("APPROVEDBY");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(131)
                    .IsUnicode(false)
                    .HasColumnName("EMPLOYEE_NAME");
            });

            modelBuilder.Entity<TestRiyan>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("TEST_RIYAN");
            });

            modelBuilder.Entity<TmContractdetail>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("TM_CONTRACTDETAILS");

                entity.Property(e => e.Column1)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("COLUMN1");
            });

            modelBuilder.Entity<TmEmployee>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("TM_EMPLOYEE");

                entity.Property(e => e.CompanyNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("COMPANY_NUMBER");

                entity.Property(e => e.CompnoNameRefindicator)
                    .HasMaxLength(1454)
                    .IsUnicode(false)
                    .HasColumnName("COMPNO_NAME_REFINDICATOR");

                entity.Property(e => e.EmailAddress)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("EMAIL_ADDRESS");

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(131)
                    .IsUnicode(false)
                    .HasColumnName("EMPLOYEE_NAME");

                entity.Property(e => e.EmploymentStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("EMPLOYMENT_STATUS");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("FIRST_NAME");

                entity.Property(e => e.FullName)
                    .HasMaxLength(121)
                    .IsUnicode(false)
                    .HasColumnName("FULL_NAME");

                entity.Property(e => e.JobDescription)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("JOB_DESCRIPTION");

                entity.Property(e => e.LastName)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("LAST_NAME");

                entity.Property(e => e.LxrefIndicatorN)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("LXREF_INDICATOR_N")
                    .IsFixedLength(true);

                entity.Property(e => e.OfficePhone)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("OFFICE_PHONE");

                entity.Property(e => e.ReferenceIndicator)
                    .HasMaxLength(90)
                    .IsUnicode(false)
                    .HasColumnName("REFERENCE_INDICATOR");

                entity.Property(e => e.SupervisorId)
                    .HasMaxLength(80)
                    .IsUnicode(false)
                    .HasColumnName("SUPERVISOR_ID");
            });

            modelBuilder.Entity<TmRabitahContract>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("TM_RABITAH_CONTRACT");

                entity.Property(e => e.CommencementDate)
                    .HasColumnType("DATE")
                    .HasColumnName("COMMENCEMENT_DATE");

                entity.Property(e => e.ContractDescription)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACT_DESCRIPTION");

                entity.Property(e => e.ContractId)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACT_ID");

                entity.Property(e => e.ContractType)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACT_TYPE");

                entity.Property(e => e.Contractor)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("CONTRACTOR");

                entity.Property(e => e.ExpiryDate)
                    .HasColumnType("DATE")
                    .HasColumnName("EXPIRY_DATE");

                entity.Property(e => e.OriginalAcvValue)
                    .HasColumnType("NUMBER")
                    .HasColumnName("ORIGINAL_ACV_VALUE");
            });

            modelBuilder.Entity<TmRabitahVendor>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("TM_RABITAH_VENDORS");

                entity.Property(e => e.Address)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("ADDRESS");

                entity.Property(e => e.CompanyWebsite)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("COMPANY_WEBSITE");

                entity.Property(e => e.ContactPersonName)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("CONTACT_PERSON_NAME");

                entity.Property(e => e.ContactPhone)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("CONTACT_PHONE");

                entity.Property(e => e.VendorCode)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("VENDOR_CODE");

                entity.Property(e => e.VendorDescription)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("VENDOR_DESCRIPTION");

                entity.Property(e => e.VendorEmail)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("VENDOR_EMAIL");
            });

            modelBuilder.Entity<TmRoleToMenuMapping>(entity =>
            {
                entity.HasKey(e => e.MenuMapId)
                    .HasName("TM_ROLE_TO_MENU_MAPPING_PK");

                entity.ToTable("TM_ROLE_TO_MENU_MAPPING");

                entity.Property(e => e.MenuMapId)
                    .HasColumnType("NUMBER")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("MENU_MAP_ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.IsActive)
                    .HasColumnType("NUMBER")
                    .HasColumnName("IS_ACTIVE")
                    .HasDefaultValueSql("1");

                entity.Property(e => e.MenuId)
                    .HasColumnType("NUMBER(38)")
                    .HasColumnName("MENU_ID");

                entity.Property(e => e.ModifiedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED_BY");

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("MODIFIED_ON");

                entity.Property(e => e.RoleId)
                    .HasPrecision(18)
                    .HasColumnName("ROLE_ID");

                entity.HasOne(d => d.Menu)
                    .WithMany(p => p.TmRoleToMenuMappings)
                    .HasForeignKey(d => d.MenuId)
                    .HasConstraintName("TM_ROLE_TO_MENU_MAPPING_FK1");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.TmRoleToMenuMappings)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("TM_ROLE_TO_MENU_MAPPING_FK2");
            });

            modelBuilder.Entity<TmRoleToUserMapping>(entity =>
            {
                entity.HasKey(e => e.MapingId)
                    .HasName("TM_ROLE_TO_USER_MAPPING_PK");

                entity.ToTable("TM_ROLE_TO_USER_MAPPING");

                entity.Property(e => e.MapingId)
                    .HasColumnType("NUMBER")
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("MAPING_ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.DefaultRoleId)
                    .HasPrecision(18)
                    .HasColumnName("DEFAULT_ROLE_ID");

                entity.Property(e => e.IsActive)
                    .HasColumnType("NUMBER")
                    .HasColumnName("IS_ACTIVE")
                    .HasDefaultValueSql("1 ");

                entity.Property(e => e.ModifiedBy)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("MODIFIED_BY");

                entity.Property(e => e.ModifiedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("MODIFIED_ON");

                entity.Property(e => e.RoleId)
                    .HasColumnType("NUMBER")
                    .HasColumnName("ROLE_ID");

                entity.Property(e => e.UserId)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("USER_ID");
            });

            modelBuilder.Entity<TmSideMenu>(entity =>
            {
                entity.HasKey(e => e.MenuId)
                    .HasName("TM_SIDE_MENU_PK");

                entity.ToTable("TM_SIDE_MENU");

                entity.Property(e => e.MenuId)
                    .HasColumnType("NUMBER(38)")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("MENU_ID");

                entity.Property(e => e.IconClassName)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("ICON_CLASS_NAME");

                entity.Property(e => e.MenuName)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("MENU_NAME");

                entity.Property(e => e.MenuUrl)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("MENU_URL");

                entity.Property(e => e.ParentMenuId)
                    .HasColumnType("NUMBER(38)")
                    .HasColumnName("PARENT_MENU_ID");
            });

            modelBuilder.Entity<TmUser>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("USERS_PK");

                entity.ToTable("TM_USERS");

                entity.Property(e => e.UserId)
                    .HasPrecision(10)
                    .ValueGeneratedNever()
                    .HasColumnName("USER_ID");

                entity.Property(e => e.CompanyNumber)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("COMPANY_NUMBER");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON")
                    .HasDefaultValueSql("SYSDATE ");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasPrecision(1)
                    .HasColumnName("IS_ACTIVE")
                    .HasDefaultValueSql("1 ");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");
            });

            modelBuilder.Entity<TmUserPaArchieve>(entity =>
            {
                entity.ToTable("TM_USER_PA_ARCHIEVE");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.ExtUserid)
                    .HasPrecision(18)
                    .HasColumnName("EXT_USERID");

                entity.Property(e => e.PaEnc)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("PA_ENC");
            });

            modelBuilder.Entity<TmUserRole>(entity =>
            {
                entity.HasKey(e => e.RoleId)
                    .HasName("TM_USER_ROLES_PK");

                entity.ToTable("TM_USER_ROLES");

                entity.Property(e => e.RoleId)
                    .HasPrecision(18)
                    .HasColumnName("ROLE_ID");

                entity.Property(e => e.Code)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("CODE");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasPrecision(1)
                    .HasColumnName("IS_ACTIVE")
                    .HasDefaultValueSql("1 ");

                entity.Property(e => e.Param)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("PARAM");

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("ROLE_NAME");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");
            });

            modelBuilder.Entity<TmUserloginLog>(entity =>
            {
                entity.ToTable("TM_USERLOGIN_LOG");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.Logindatetime)
                    .HasColumnType("DATE")
                    .HasColumnName("LOGINDATETIME");

                entity.Property(e => e.Status)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("STATUS");

                entity.Property(e => e.UserId)
                    .HasPrecision(18)
                    .HasColumnName("USER_ID");
            });

            modelBuilder.Entity<TypeCodeMaster>(entity =>
            {
                entity.ToTable("TYPE_CODE_MASTERS");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedByRef)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("CREATED_BY_REF");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.Description)
                    .HasMaxLength(200)
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.IsEditable)
                    .HasPrecision(1)
                    .HasColumnName("IS_EDITABLE")
                    .HasDefaultValueSql("1 ");

                entity.Property(e => e.IsInternal)
                    .HasPrecision(1)
                    .HasColumnName("IS_INTERNAL");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("NAME");

                entity.Property(e => e.Param1)
                    .HasMaxLength(10)
                    .HasColumnName("PARAM1");

                entity.Property(e => e.Param2)
                    .HasMaxLength(50)
                    .HasColumnName("PARAM2");

                entity.Property(e => e.ParentId)
                    .HasPrecision(18)
                    .HasColumnName("PARENT_ID");

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(2)
                    .HasColumnName("STATUS");

                entity.Property(e => e.Type)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasColumnName("TYPE");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY");

                entity.Property(e => e.UpdatedByRef)
                    .HasMaxLength(10)
                    .HasColumnName("UPDATED_BY_REF");

                entity.Property(e => e.UpdatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("UPDATED_ON");
            });

            modelBuilder.Entity<UtlAuditTrail>(entity =>
            {
                entity.ToTable("UTL_AUDIT_TRAIL");

                entity.Property(e => e.Id)
                    .HasColumnType("NUMBER(38)")
                    .ValueGeneratedOnAdd()
                    .UseIdentityColumn()
                    .HasColumnName("ID");

                entity.Property(e => e.Action)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("ACTION");

                entity.Property(e => e.ActionBy)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("ACTION_BY");

                entity.Property(e => e.ActionOn)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("ACTION_ON");

                entity.Property(e => e.Description)
                    .HasColumnType("CLOB")
                    .HasColumnName("DESCRIPTION");

                entity.Property(e => e.RowPid)
                    .HasPrecision(18)
                    .HasColumnName("ROW_PID");

                entity.Property(e => e.TableName)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("TABLE_NAME");
            });

            modelBuilder.Entity<TrAuditLog>(entity =>
            {
                entity.ToTable("TR_AUDIT_LOG");

                entity.HasKey(e => e.AUDIT_ID);

                entity.Property(e => e.AUDIT_ID)
                    .HasColumnType("NUMBER")
                    .ValueGeneratedOnAdd()
                    .HasDefaultValueSql("SEQ_TR_AUDIT_LOG.NEXTVAL")
                    .HasColumnName("AUDIT_ID");

                entity.Property(e => e.MODULE_NAME).HasMaxLength(100).IsUnicode(false).HasColumnName("MODULE_NAME");
                entity.Property(e => e.ACTION_TYPE).HasMaxLength(50).IsUnicode(false).HasColumnName("ACTION_TYPE");
                entity.Property(e => e.ENTITY_TYPE).HasMaxLength(100).IsUnicode(false).HasColumnName("ENTITY_TYPE");
                entity.Property(e => e.ENTITY_ID).HasMaxLength(100).IsUnicode(false).HasColumnName("ENTITY_ID");
                entity.Property(e => e.ENTITY_NAME).HasMaxLength(500).IsUnicode(false).HasColumnName("ENTITY_NAME");
                entity.Property(e => e.FIELD_NAME).HasMaxLength(200).IsUnicode(false).HasColumnName("FIELD_NAME");
                entity.Property(e => e.OLD_VALUE).HasMaxLength(4000).IsUnicode(false).HasColumnName("OLD_VALUE");
                entity.Property(e => e.NEW_VALUE).HasMaxLength(4000).IsUnicode(false).HasColumnName("NEW_VALUE");
                entity.Property(e => e.SUMMARY).HasMaxLength(4000).IsUnicode(false).HasColumnName("SUMMARY");
                entity.Property(e => e.COMMENTS).HasMaxLength(4000).IsUnicode(false).HasColumnName("COMMENTS");
                entity.Property(e => e.USER_ID).HasMaxLength(100).IsUnicode(false).HasColumnName("USER_ID");
                entity.Property(e => e.USER_DISPLAY_NAME).HasMaxLength(200).IsUnicode(false).HasColumnName("USER_DISPLAY_NAME");
                entity.Property(e => e.ROLE_ID).HasColumnType("NUMBER(10)").HasColumnName("ROLE_ID");
                entity.Property(e => e.ROLE_NAME).HasMaxLength(200).IsUnicode(false).HasColumnName("ROLE_NAME");
                entity.Property(e => e.IP_ADDRESS).HasMaxLength(100).IsUnicode(false).HasColumnName("IP_ADDRESS");
                entity.Property(e => e.CORRELATION_ID).HasMaxLength(100).IsUnicode(false).HasColumnName("CORRELATION_ID");
                entity.Property(e => e.HTTP_METHOD).HasMaxLength(20).IsUnicode(false).HasColumnName("HTTP_METHOD");
                entity.Property(e => e.REQUEST_PATH).HasMaxLength(1000).IsUnicode(false).HasColumnName("REQUEST_PATH");
                entity.Property(e => e.AUDIT_DATE).HasColumnType("DATE").HasColumnName("AUDIT_DATE");
                entity.Property(e => e.OLD_JSON).HasColumnType("CLOB").HasColumnName("OLD_JSON");
                entity.Property(e => e.NEW_JSON).HasColumnType("CLOB").HasColumnName("NEW_JSON");
                entity.Property(e => e.REQUEST_JSON).HasColumnType("CLOB").HasColumnName("REQUEST_JSON");
                entity.Property(e => e.RESPONSE_JSON).HasColumnType("CLOB").HasColumnName("RESPONSE_JSON");
            });

            //modelBuilder.Entity<VTipApprovedPir>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_APPROVED_PIR");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.Approveddate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("APPROVEDDATE");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.Criteria)
            //        .HasMaxLength(7)
            //        .IsUnicode(false)
            //        .HasColumnName("CRITERIA")
            //        .IsFixedLength(true);

            //    entity.Property(e => e.Id)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("ID");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.RefNo)
            //        .HasMaxLength(50)
            //        .IsUnicode(false)
            //        .HasColumnName("REF_NO");

            //    entity.Property(e => e.Status)
            //        .HasMaxLength(150)
            //        .IsUnicode(false)
            //        .HasColumnName("STATUS");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .HasMaxLength(1000)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(50)
            //        .IsUnicode(false)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipApprovedTtum>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_APPROVED_TTA");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.Approveddate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("APPROVEDDATE");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CtrId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("CTR_ID");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.TrialName)
            //        .IsRequired()
            //        .HasMaxLength(500)
            //        .HasColumnName("TRIAL_NAME");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(50)
            //        .IsUnicode(false)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipChallengesOpportunity>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_CHALLENGES_OPPORTUNITIES");

            //    entity.Property(e => e.ActionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("ACTION_DATE");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ChallengedetailsId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("CHALLENGEDETAILS_ID");

            //    entity.Property(e => e.ChallengeregId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("CHALLENGEREG_ID");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.Keyword)
            //        .HasMaxLength(1000)
            //        .IsUnicode(false)
            //        .HasColumnName("KEYWORD");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.RequestType)
            //        .HasPrecision(18)
            //        .HasColumnName("REQUEST_TYPE");

            //    entity.Property(e => e.RequestTypeName)
            //        .HasMaxLength(13)
            //        .IsUnicode(false)
            //        .HasColumnName("REQUEST_TYPE_NAME");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .HasMaxLength(1000)
            //        .IsUnicode(false)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(50)
            //        .IsUnicode(false)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipDeploymentVot>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_DEPLOYMENT_VOT");

            //    entity.Property(e => e.ActionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("ACTION_DATE");

            //    entity.Property(e => e.ActualCount)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("ACTUAL_COUNT");

            //    entity.Property(e => e.ActualVot)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("ACTUAL_VOT");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CummulativePlan)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("CUMMULATIVE_PLAN");

            //    entity.Property(e => e.DepId)
            //        .HasPrecision(18)
            //        .HasColumnName("DEP_ID");

            //    entity.Property(e => e.DepVotId)
            //        .HasPrecision(18)
            //        .HasColumnName("DEP_VOT_ID");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.MonthShown)
            //        .HasMaxLength(36)
            //        .IsUnicode(false)
            //        .HasColumnName("MONTH_SHOWN");

            //    entity.Property(e => e.PirId)
            //        .HasPrecision(18)
            //        .HasColumnName("PIR_ID");

            //    entity.Property(e => e.PirRef)
            //        .HasMaxLength(200)
            //        .HasColumnName("PIR_REF");

            //    entity.Property(e => e.PlanCount)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("PLAN_COUNT");

            //    entity.Property(e => e.PlanVot)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("PLAN_VOT");

            //    entity.Property(e => e.QYear)
            //        .HasPrecision(18)
            //        .HasColumnName("Q_YEAR");

            //    entity.Property(e => e.QuerterYear)
            //        .HasMaxLength(200)
            //        .HasColumnName("QUERTER_YEAR");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.TechName)
            //        .HasMaxLength(1000)
            //        .HasColumnName("TECH_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(10)
            //        .HasColumnName("UCT_FP");

            //    entity.Property(e => e.UnitId)
            //        .HasPrecision(18)
            //        .HasColumnName("UNIT_ID");

            //    entity.Property(e => e.UnitName)
            //        .HasMaxLength(200)
            //        .HasColumnName("UNIT_NAME");

            //    entity.Property(e => e.Ytd)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("YTD");
            //});

            //modelBuilder.Entity<VTipFunnelSummary>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_FUNNEL_SUMMARY");

            //    entity.Property(e => e.ActionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("ACTION_DATE");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.Co2Reduction)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("CO2_REDUCTION");

            //    entity.Property(e => e.CostSaving)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("COST_SAVING");

            //    entity.Property(e => e.DefermentAvoidance)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("DEFERMENT_AVOIDANCE");

            //    entity.Property(e => e.HeaderColumn)
            //        .HasMaxLength(10)
            //        .IsUnicode(false)
            //        .HasColumnName("HEADER_COLUMN");

            //    entity.Property(e => e.Keyword)
            //        .HasMaxLength(1000)
            //        .IsUnicode(false)
            //        .HasColumnName("KEYWORD");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.OilGain)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("OIL_GAIN");

            //    entity.Property(e => e.PowerSaving)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("POWER_SAVING");

            //    entity.Property(e => e.SubTheme)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUB_THEME");

            //    entity.Property(e => e.SubThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUB_THEME_ID");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .HasMaxLength(1000)
            //        .IsUnicode(false)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.TotalVot)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("TOTAL_VOT");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(1000)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipMasterDatum>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_MASTER_DATA");

            //    entity.Property(e => e.Id)
            //        .HasPrecision(18)
            //        .HasColumnName("ID");

            //    entity.Property(e => e.Name)
            //        .HasMaxLength(200)
            //        .HasColumnName("NAME");

            //    entity.Property(e => e.ParentId)
            //        .HasPrecision(18)
            //        .HasColumnName("PARENT_ID");

            //    entity.Property(e => e.TypeId)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("TYPE_ID");

            //    entity.Property(e => e.TypeName)
            //        .HasMaxLength(14)
            //        .IsUnicode(false)
            //        .HasColumnName("TYPE_NAME");
            //});

            //modelBuilder.Entity<VTipMasterUctfp>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_MASTER_UCTFP");

            //    entity.Property(e => e.EmployeeName)
            //        .HasMaxLength(131)
            //        .IsUnicode(false)
            //        .HasColumnName("EMPLOYEE_NAME");

            //    entity.Property(e => e.EmploymentStatus)
            //        .HasMaxLength(20)
            //        .IsUnicode(false)
            //        .HasColumnName("EMPLOYMENT_STATUS");

            //    entity.Property(e => e.MuNumber)
            //        .HasMaxLength(20)
            //        .IsUnicode(false)
            //        .HasColumnName("MU_NUMBER");

            //    entity.Property(e => e.ReferenceIndicator)
            //        .HasMaxLength(90)
            //        .IsUnicode(false)
            //        .HasColumnName("REFERENCE_INDICATOR");
            //});


            modelBuilder.Entity<VTipPerTechnology>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("V_TIP_PER_TECHNOLOGY");

                entity.Property(e => e.ApplicationId)
                    .HasPrecision(18)
                    .HasColumnName("APPLICATION_ID");

                entity.Property(e => e.AreaId)
                    .HasPrecision(18)
                    .HasColumnName("AREA_ID");

                entity.Property(e => e.ChaCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CHA_CREATED_ON");

                entity.Property(e => e.ChaRefNo)
                    .HasMaxLength(25)
                    .HasColumnName("CHA_REF_NO");

                entity.Property(e => e.ChaUctFp)
                    .HasMaxLength(20)
                    .HasColumnName("CHA_UCT_FP");

                entity.Property(e => e.ChallengeId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.ChallengeName)
                    .HasMaxLength(1000)
                    .HasColumnName("CHALLENGE_NAME");

                entity.Property(e => e.CtrApprovedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CTR_APPROVED_ON");

                entity.Property(e => e.CtrCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CTR_CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.CtrRefNo)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("CTR_REF_NO");

                entity.Property(e => e.CtrTrialName)
                    .HasMaxLength(500)
                    .HasColumnName("CTR_TRIAL_NAME");

                entity.Property(e => e.CtrUctFp)
                    .HasMaxLength(20)
                    .HasColumnName("CTR_UCT_FP");

                entity.Property(e => e.DepDays)
                    .HasColumnType("NUMBER")
                    .HasColumnName("DEP_DAYS");

                entity.Property(e => e.ExecDays)
                    .HasColumnType("NUMBER")
                    .HasColumnName("EXEC_DAYS");

                entity.Property(e => e.IpDays)
                    .HasColumnType("NUMBER")
                    .HasColumnName("IP_DAYS");

                entity.Property(e => e.PirApprovedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("PIR_APPROVED_ON");

                entity.Property(e => e.PirDays)
                    .HasColumnType("NUMBER")
                    .HasColumnName("PIR_DAYS");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.PirRefNo)
                    .HasMaxLength(200)
                    .HasColumnName("PIR_REF_NO");

                entity.Property(e => e.PirUctFp)
                    .HasMaxLength(20)
                    .HasColumnName("PIR_UCT_FP");

                entity.Property(e => e.PtDays)
                    .HasColumnType("NUMBER")
                    .HasColumnName("PT_DAYS");

                entity.Property(e => e.TechCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("TECH_CREATED_ON");

                entity.Property(e => e.TechName)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("TECH_NAME");

                entity.Property(e => e.TechnologyBankId)
                    .HasPrecision(18)
                    .HasColumnName("TECHNOLOGY_BANK_ID");

                entity.Property(e => e.ThemeId)
                    .HasPrecision(18)
                    .HasColumnName("THEME_ID");

                entity.Property(e => e.TtaDays)
                    .HasColumnType("NUMBER")
                    .HasColumnName("TTA_DAYS");
            });

            //modelBuilder.Entity<VTipPhaseMaturation>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_PHASE_MATURATION");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CtrCompletionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("CTR_COMPLETION_DATE");

            //    entity.Property(e => e.CtrStartDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("CTR_START_DATE");

            //    entity.Property(e => e.CtrTrialName)
            //        .HasMaxLength(500)
            //        .HasColumnName("CTR_TRIAL_NAME");

            //    entity.Property(e => e.DeploymentCompletionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("DEPLOYMENT_COMPLETION_DATE");

            //    entity.Property(e => e.DeploymentConfigDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("DEPLOYMENT_CONFIG_DAYS");

            //    entity.Property(e => e.DeploymentDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("DEPLOYMENT_DAYS");

            //    entity.Property(e => e.DeploymentPhaseName)
            //        .HasMaxLength(200)
            //        .HasColumnName("DEPLOYMENT_PHASE_NAME");

            //    entity.Property(e => e.DeploymentStartDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("DEPLOYMENT_START_DATE");

            //    entity.Property(e => e.ExecutionCompletionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("EXECUTION_COMPLETION_DATE");

            //    entity.Property(e => e.ExecutionConfigDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("EXECUTION_CONFIG_DAYS");

            //    entity.Property(e => e.ExecutionDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("EXECUTION_DAYS");

            //    entity.Property(e => e.ExecutionPhaseName)
            //        .HasMaxLength(200)
            //        .HasColumnName("EXECUTION_PHASE_NAME");

            //    entity.Property(e => e.ExecutionStartDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("EXECUTION_START_DATE");

            //    entity.Property(e => e.IpConfigDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("IP_CONFIG_DAYS");

            //    entity.Property(e => e.IpDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("IP_DAYS");

            //    entity.Property(e => e.IpPhaseName)
            //        .HasMaxLength(200)
            //        .HasColumnName("IP_PHASE_NAME");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.PirCompletionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PIR_COMPLETION_DATE");

            //    entity.Property(e => e.PirConfigDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("PIR_CONFIG_DAYS");

            //    entity.Property(e => e.PirDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("PIR_DAYS");

            //    entity.Property(e => e.PirPhaseName)
            //        .HasMaxLength(200)
            //        .HasColumnName("PIR_PHASE_NAME");

            //    entity.Property(e => e.PirStartDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PIR_START_DATE");

            //    entity.Property(e => e.PoCompletionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PO_COMPLETION_DATE");

            //    entity.Property(e => e.PoStartDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PO_START_DATE");

            //    entity.Property(e => e.PreTtaConfigDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("PRE_TTA_CONFIG_DAYS");

            //    entity.Property(e => e.PreTtaDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("PRE_TTA_DAYS");

            //    entity.Property(e => e.PreTtaPhaseName)
            //        .HasMaxLength(200)
            //        .HasColumnName("PRE_TTA_PHASE_NAME");

            //    entity.Property(e => e.PreTtaStartDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PRE_TTA_START_DATE");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.TechId)
            //        .HasPrecision(18)
            //        .HasColumnName("TECH_ID");

            //    entity.Property(e => e.TechTitle)
            //        .HasMaxLength(1501)
            //        .HasColumnName("TECH_TITLE");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.TtaConfigDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("TTA_CONFIG_DAYS");

            //    entity.Property(e => e.TtaDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("TTA_DAYS");

            //    entity.Property(e => e.TtaPhaseName)
            //        .HasMaxLength(200)
            //        .HasColumnName("TTA_PHASE_NAME");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(20)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipPhaseMaturationBk>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_PHASE_MATURATION_BK");

            //    entity.Property(e => e.ActualDays)
            //        .HasPrecision(18)
            //        .HasColumnName("ACTUAL_DAYS");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CtrCompletionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("CTR_COMPLETION_DATE");

            //    entity.Property(e => e.CtrSubmittedDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("CTR_SUBMITTED_DATE");

            //    entity.Property(e => e.ExecutionCompletionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("EXECUTION_COMPLETION_DATE");

            //    entity.Property(e => e.ExecutionInitiatedDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("EXECUTION_INITIATED_DATE");

            //    entity.Property(e => e.PirCompletionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PIR_COMPLETION_DATE");

            //    entity.Property(e => e.PirSubmittedDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PIR_SUBMITTED_DATE");

            //    entity.Property(e => e.PoDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PO_DATE");

            //    entity.Property(e => e.StageName)
            //        .HasMaxLength(200)
            //        .HasColumnName("STAGE_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .IsRequired()
            //        .HasMaxLength(1000)
            //        .HasColumnName("TITLE");
            //});

            //modelBuilder.Entity<VTipPlannedActualVot>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_PLANNED_ACTUAL_VOT");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.AvgIncrmntlOilGain)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("AVG_INCRMNTL_OIL_GAIN");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.Co2Reduction)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("CO2_REDUCTION");

            //    entity.Property(e => e.Co2ReductnUnitYr)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("CO2_REDUCTN_UNIT_YR");

            //    entity.Property(e => e.CostSavingUnitQtr)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("COST_SAVING_UNIT_QTR");

            //    entity.Property(e => e.CostSavingUnitYr)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("COST_SAVING_UNIT_YR");

            //    entity.Property(e => e.DefermentAvoidance)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("DEFERMENT_AVOIDANCE");

            //    entity.Property(e => e.DepSubmittedDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("DEP_SUBMITTED_DATE");

            //    entity.Property(e => e.IncrmntlOilGain)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("INCRMNTL_OIL_GAIN");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.PirId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("PIR_ID");

            //    entity.Property(e => e.PirSubmittedDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PIR_SUBMITTED_DATE");

            //    entity.Property(e => e.PowerSaving)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("POWER_SAVING");

            //    entity.Property(e => e.PowerSavingUnitYr)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("POWER_SAVING_UNIT_YR");

            //    entity.Property(e => e.QY)
            //        .IsRequired()
            //        .HasMaxLength(200)
            //        .HasColumnName("Q_Y");

            //    entity.Property(e => e.RefNo)
            //        .HasMaxLength(200)
            //        .HasColumnName("REF_NO");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .HasMaxLength(1000)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.TotOilDefermentAvoidance)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("TOT_OIL_DEFERMENT_AVOIDANCE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(20)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipPoIssuing>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_PO_ISSUING");

            //    entity.Property(e => e.AcvValue)
            //        .HasMaxLength(50)
            //        .IsUnicode(false)
            //        .HasColumnName("ACV_VALUE");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.ContractDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("CONTRACT_DATE");

            //    entity.Property(e => e.ContractNo)
            //        .HasMaxLength(50)
            //        .IsUnicode(false)
            //        .HasColumnName("CONTRACT_NO");

            //    entity.Property(e => e.ContractType)
            //        .HasMaxLength(200)
            //        .IsUnicode(false)
            //        .HasColumnName("CONTRACT_TYPE");

            //    entity.Property(e => e.ExecutionId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("EXECUTION_ID");

            //    entity.Property(e => e.Keyword)
            //        .HasMaxLength(1127)
            //        .HasColumnName("KEYWORD");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.SubthemeId)
            //        .HasMaxLength(1000)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(1000)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Trialtitle)
            //        .IsRequired()
            //        .HasMaxLength(500)
            //        .HasColumnName("TRIALTITLE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(20)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipPotentialValue>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_POTENTIAL_VALUE");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CreatedOn)
            //        .HasColumnType("DATE")
            //        .HasColumnName("CREATED_ON");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.Mm)
            //        .HasMaxLength(9)
            //        .IsUnicode(false)
            //        .HasColumnName("MM$");

            //    entity.Property(e => e.PotentialValue)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("POTENTIAL_VALUE");

            //    entity.Property(e => e.RealizedValue)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("REALIZED_VALUE");

            //    entity.Property(e => e.RegretValue)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("REGRET_VALUE");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .HasMaxLength(1000)
            //        .IsUnicode(false)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(1000)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipPreTtum>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_PRE_TTA");

            //    entity.Property(e => e.ActionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("ACTION_DATE");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ChallengeActionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("CHALLENGE_ACTION_DATE");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CtrActionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("CTR_ACTION_DATE");

            //    entity.Property(e => e.CtrRefNo)
            //        .HasMaxLength(200)
            //        .IsUnicode(false)
            //        .HasColumnName("CTR_REF_NO");

            //    entity.Property(e => e.DeploymentActionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("DEPLOYMENT_ACTION_DATE");

            //    entity.Property(e => e.ExecutionActionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("EXECUTION_ACTION_DATE");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.PirActionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PIR_ACTION_DATE");

            //    entity.Property(e => e.PirRefNo)
            //        .HasMaxLength(200)
            //        .HasColumnName("PIR_REF_NO");

            //    entity.Property(e => e.ReferenceNo)
            //        .HasMaxLength(25)
            //        .HasColumnName("REFERENCE_NO");

            //    entity.Property(e => e.Status)
            //        .HasMaxLength(10)
            //        .IsUnicode(false)
            //        .HasColumnName("STATUS");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .HasMaxLength(1000)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(20)
            //        .HasColumnName("UCT_FP");
            //});

            modelBuilder.Entity<VTipTechPlan>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("V_TIP_TECH_PLAN");

                entity.Property(e => e.ActualDiffDays)
                    .HasColumnType("NUMBER")
                    .HasColumnName("ACTUAL_DIFF_DAYS");

                entity.Property(e => e.ActualEndDate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTUAL_END_DATE");

                entity.Property(e => e.ActualStartDate)
                    .HasColumnType("DATE")
                    .HasColumnName("ACTUAL_START_DATE");

                entity.Property(e => e.ApplicationId)
                    .HasPrecision(18)
                    .HasColumnName("APPLICATION_ID");

                entity.Property(e => e.ApplicationName)
                    .HasMaxLength(200)
                    .HasColumnName("APPLICATION_NAME");

                entity.Property(e => e.AreaId)
                    .HasPrecision(18)
                    .HasColumnName("AREA_ID");

                entity.Property(e => e.AreaName)
                    .HasMaxLength(200)
                    .HasColumnName("AREA_NAME");

                entity.Property(e => e.AssetId)
                    .HasPrecision(18)
                    .HasColumnName("ASSET_ID");

                entity.Property(e => e.AssetName)
                    .HasMaxLength(200)
                    .HasColumnName("ASSET_NAME");

                entity.Property(e => e.ChaRefNo)
                    .HasMaxLength(25)
                    .HasColumnName("CHA_REF_NO");

                entity.Property(e => e.ChaUctFp)
                    .HasMaxLength(20)
                    .HasColumnName("CHA_UCT_FP");

                entity.Property(e => e.ChallengeCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CHALLENGE_CREATED_ON");

                entity.Property(e => e.ChallengeId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_ID");

                entity.Property(e => e.ChallengeMaturityId)
                    .HasPrecision(18)
                    .HasColumnName("CHALLENGE_MATURITY_ID");

                entity.Property(e => e.ChallengeMaturityLevelName)
                    .HasMaxLength(200)
                    .HasColumnName("CHALLENGE_MATURITY_LEVEL_NAME");

                entity.Property(e => e.ChallengeName)
                    .HasMaxLength(1000)
                    .HasColumnName("CHALLENGE_NAME");

                entity.Property(e => e.ClusterId)
                    .HasPrecision(18)
                    .HasColumnName("CLUSTER_ID");

                entity.Property(e => e.ClusterName)
                    .HasMaxLength(200)
                    .HasColumnName("CLUSTER_NAME");

                entity.Property(e => e.ConfigDays)
                    .HasPrecision(18)
                    .HasColumnName("CONFIG_DAYS");

                entity.Property(e => e.CtrCompletionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("CTR_COMPLETION_DATE");

                entity.Property(e => e.CtrCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CTR_CREATED_ON");

                entity.Property(e => e.CtrId)
                    .HasPrecision(18)
                    .HasColumnName("CTR_ID");

                entity.Property(e => e.CtrRefNo)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("CTR_REF_NO");

                entity.Property(e => e.CtrTrialName)
                    .HasMaxLength(500)
                    .HasColumnName("CTR_TRIAL_NAME");

                entity.Property(e => e.CtrUctFp)
                    .HasMaxLength(20)
                    .HasColumnName("CTR_UCT_FP");

                entity.Property(e => e.DepCompletionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("DEP_COMPLETION_DATE");

                entity.Property(e => e.DepCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("DEP_CREATED_ON");

                entity.Property(e => e.DepUctFp)
                    .HasMaxLength(10)
                    .HasColumnName("DEP_UCT_FP");

                entity.Property(e => e.ExeId)
                    .HasPrecision(18)
                    .HasColumnName("EXE_ID");

                entity.Property(e => e.ExeTrialName)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("EXE_TRIAL_NAME");

                entity.Property(e => e.ExeUctFp)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("EXE_UCT_FP");

                entity.Property(e => e.ExecutionCompletionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("EXECUTION_COMPLETION_DATE");

                entity.Property(e => e.ExecutionCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("EXECUTION_CREATED_ON");

                entity.Property(e => e.ExecutionMaturityId)
                    .HasPrecision(18)
                    .HasColumnName("EXECUTION_MATURITY_ID");

                entity.Property(e => e.ExecutionMaturityLevelName)
                    .HasMaxLength(200)
                    .HasColumnName("EXECUTION_MATURITY_LEVEL_NAME");

                entity.Property(e => e.IsCompletion)
                    .HasColumnType("NUMBER")
                    .HasColumnName("IS_COMPLETION");

                entity.Property(e => e.PhaseId)
                    .HasPrecision(18)
                    .HasColumnName("PHASE_ID");

                entity.Property(e => e.PhaseName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("PHASE_NAME");

                entity.Property(e => e.PirCompletionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("PIR_COMPLETION_DATE");

                entity.Property(e => e.PirCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("PIR_CREATED_ON");

                entity.Property(e => e.PirId)
                    .HasPrecision(18)
                    .HasColumnName("PIR_ID");

                entity.Property(e => e.PirRefNo)
                    .HasMaxLength(200)
                    .HasColumnName("PIR_REF_NO");

                entity.Property(e => e.PirUctFp)
                    .HasMaxLength(20)
                    .HasColumnName("PIR_UCT_FP");

                entity.Property(e => e.PlannedDiffDays)
                    .HasColumnType("NUMBER")
                    .HasColumnName("PLANNED_DIFF_DAYS");

                entity.Property(e => e.PlannedEndDate)
                    .HasColumnType("DATE")
                    .HasColumnName("PLANNED_END_DATE");

                entity.Property(e => e.PlannedStartDate)
                    .HasColumnType("DATE")
                    .HasColumnName("PLANNED_START_DATE");

                entity.Property(e => e.PoIssuingCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("PO_ISSUING_CREATED_ON");

                entity.Property(e => e.PoIssunigCompletionDate)
                    .HasColumnType("DATE")
                    .HasColumnName("PO_ISSUNIG_COMPLETION_DATE");

                entity.Property(e => e.ResponseStatusId)
                    .HasPrecision(18)
                    .HasColumnName("RESPONSE_STATUS_ID");

                entity.Property(e => e.Sequence)
                    .HasPrecision(18)
                    .HasColumnName("SEQUENCE");

                entity.Property(e => e.StageId)
                    .HasPrecision(18)
                    .HasColumnName("STAGE_ID");

                entity.Property(e => e.StageName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .HasColumnName("STAGE_NAME");

                entity.Property(e => e.StgCode)
                    .HasMaxLength(10)
                    .HasColumnName("STG_CODE");

                entity.Property(e => e.SubThemeId)
                    .HasPrecision(18)
                    .HasColumnName("SUB_THEME_ID");

                entity.Property(e => e.SubthemeName)
                    .HasMaxLength(200)
                    .HasColumnName("SUBTHEME_NAME");

                entity.Property(e => e.TechCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("TECH_CREATED_ON");

                entity.Property(e => e.TechName)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .HasColumnName("TECH_NAME");

                entity.Property(e => e.TechnologyBankCreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("TECHNOLOGY_BANK_CREATED_ON");

                entity.Property(e => e.TechnologyBankId)
                    .HasPrecision(18)
                    .HasColumnName("TECHNOLOGY_BANK_ID");

                entity.Property(e => e.ThemeId)
                    .HasPrecision(18)
                    .HasColumnName("THEME_ID");

                entity.Property(e => e.ThemeName)
                    .HasMaxLength(200)
                    .HasColumnName("THEME_NAME");
            });

            //modelBuilder.Entity<VTipTechTimeline>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_TECH_TIMELINE");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CtrId)
            //        .HasPrecision(18)
            //        .HasColumnName("CTR_ID");

            //    entity.Property(e => e.EndDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("END_DATE");

            //    entity.Property(e => e.Itemid).HasColumnName("ITEMID");

            //    entity.Property(e => e.ParentId).HasColumnName("PARENT_ID");

            //    entity.Property(e => e.StartDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("START_DATE");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title).HasColumnName("TITLE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(20)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipTechnologyCount>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_TECHNOLOGY_COUNT");

            //    entity.Property(e => e.ActualYear)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("ACTUAL_YEAR");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CtrId)
            //        .HasPrecision(18)
            //        .HasColumnName("CTR_ID");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.PhaseName)
            //        .IsRequired()
            //        .HasMaxLength(200)
            //        .HasColumnName("PHASE_NAME");

            //    entity.Property(e => e.StageName)
            //        .IsRequired()
            //        .HasMaxLength(200)
            //        .HasColumnName("STAGE_NAME");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .HasMaxLength(1053)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(20)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipTechnologyDurationDay>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_TECHNOLOGY_DURATION_DAYS");

            //    entity.Property(e => e.ActualYear)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("ACTUAL_YEAR");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CtrId)
            //        .HasPrecision(18)
            //        .HasColumnName("CTR_ID");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.PhaseName)
            //        .IsRequired()
            //        .HasMaxLength(200)
            //        .HasColumnName("PHASE_NAME");

            //    entity.Property(e => e.Planneddays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("PLANNEDDAYS");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .HasMaxLength(1053)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(20)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipTechnologyPlan>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_TECHNOLOGY_PLAN");

            //    entity.Property(e => e.Actualdiff)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("ACTUALDIFF");

            //    entity.Property(e => e.Actualenddate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("ACTUALENDDATE");

            //    entity.Property(e => e.Actualstartdate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("ACTUALSTARTDATE");

            //    entity.Property(e => e.Completion)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("COMPLETION");

            //    entity.Property(e => e.CtrId)
            //        .HasPrecision(18)
            //        .HasColumnName("CTR_ID");

            //    entity.Property(e => e.PhaseId)
            //        .HasPrecision(18)
            //        .HasColumnName("PHASE_ID");

            //    entity.Property(e => e.PhaseName)
            //        .HasMaxLength(200)
            //        .HasColumnName("PHASE_NAME");

            //    entity.Property(e => e.Planneddays)
            //        .HasPrecision(18)
            //        .HasColumnName("PLANNEDDAYS");

            //    entity.Property(e => e.Plannedenddate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PLANNEDENDDATE");

            //    entity.Property(e => e.Plannedstartdate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PLANNEDSTARTDATE");

            //    entity.Property(e => e.Sequence)
            //        .HasPrecision(18)
            //        .HasColumnName("SEQUENCE");

            //    entity.Property(e => e.StageId)
            //        .HasPrecision(18)
            //        .HasColumnName("STAGE_ID");

            //    entity.Property(e => e.StageName)
            //        .HasMaxLength(200)
            //        .HasColumnName("STAGE_NAME");

            //    entity.Property(e => e.TechId)
            //        .HasPrecision(18)
            //        .HasColumnName("TECH_ID");

            //    entity.Property(e => e.Title)
            //        .HasMaxLength(1000)
            //        .HasColumnName("TITLE");
            //});

            //modelBuilder.Entity<VTipTechnologySpending>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_TECHNOLOGY_SPENDING");

            //    entity.Property(e => e.AcvValue)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("ACV_VALUE");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CtrId)
            //        .HasPrecision(18)
            //        .HasColumnName("CTR_ID");

            //    entity.Property(e => e.CumulativeValue)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("CUMULATIVE_VALUE");

            //    entity.Property(e => e.Keyword)
            //        .HasMaxLength(1000)
            //        .IsUnicode(false)
            //        .HasColumnName("KEYWORD");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.Months)
            //        .HasMaxLength(36)
            //        .IsUnicode(false)
            //        .HasColumnName("MONTHS");

            //    entity.Property(e => e.Planvalue)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("PLANVALUE");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.TechId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("TECH_ID");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .IsRequired()
            //        .HasMaxLength(1000)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.UctFp)
            //        .IsRequired()
            //        .HasMaxLength(20)
            //        .HasColumnName("UCT_FP");

            //    entity.Property(e => e.Year)
            //        .HasMaxLength(50)
            //        .HasColumnName("YEAR");

            //    entity.Property(e => e.Ytd)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("YTD");
            //});

            //modelBuilder.Entity<VTipTechnologySpendingR>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_TECHNOLOGY_SPENDING_R");

            //    entity.Property(e => e.AcvValue)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("ACV_VALUE");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CtrId)
            //        .HasPrecision(18)
            //        .HasColumnName("CTR_ID");

            //    entity.Property(e => e.CumulativeValue)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("CUMULATIVE_VALUE");

            //    entity.Property(e => e.Keyword)
            //        .HasMaxLength(1000)
            //        .IsUnicode(false)
            //        .HasColumnName("KEYWORD");

            //    entity.Property(e => e.Months)
            //        .HasMaxLength(36)
            //        .IsUnicode(false)
            //        .HasColumnName("MONTHS");

            //    entity.Property(e => e.Planvalue)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("PLANVALUE");

            //    entity.Property(e => e.TechId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("TECH_ID");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .IsRequired()
            //        .HasMaxLength(1000)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.Year)
            //        .HasMaxLength(50)
            //        .HasColumnName("YEAR");

            //    entity.Property(e => e.Ytd)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("YTD");
            //});

            //modelBuilder.Entity<VTipTechnologyTimeline>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_TECHNOLOGY_TIMELINE");

            //    entity.Property(e => e.ActualDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("ACTUAL_DAYS");

            //    entity.Property(e => e.ActualEndDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("ACTUAL_END_DATE");

            //    entity.Property(e => e.ActualStartDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("ACTUAL_START_DATE");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CtrId)
            //        .HasPrecision(18)
            //        .HasColumnName("CTR_ID");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.PhaseName)
            //        .IsRequired()
            //        .HasMaxLength(200)
            //        .HasColumnName("PHASE_NAME");

            //    entity.Property(e => e.PlanEndDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PLAN_END_DATE");

            //    entity.Property(e => e.PlanStartDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("PLAN_START_DATE");

            //    entity.Property(e => e.PlannedDays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("PLANNED_DAYS");

            //    entity.Property(e => e.Sequence)
            //        .HasPrecision(18)
            //        .HasColumnName("SEQUENCE");

            //    entity.Property(e => e.StageName)
            //        .IsRequired()
            //        .HasMaxLength(200)
            //        .HasColumnName("STAGE_NAME");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.TechId)
            //        .HasPrecision(18)
            //        .HasColumnName("TECH_ID");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .HasMaxLength(1501)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(20)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipTechnologybankTrail>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_TECHNOLOGYBANK_TRAILS");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.CreatedOn)
            //        .HasColumnType("DATE")
            //        .HasColumnName("CREATED_ON");

            //    entity.Property(e => e.Id)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("ID");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .ValueGeneratedOnAdd()
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .IsRequired()
            //        .HasMaxLength(1000)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(20)
            //        .HasColumnName("UCT_FP");
            //});

            //modelBuilder.Entity<VTipTechnologyvmb>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_TECHNOLOGYVMB");

            //    entity.Property(e => e.ActionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("ACTION_DATE");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.HeaderData)
            //        .HasMaxLength(100)
            //        .IsUnicode(false)
            //        .HasColumnName("HEADER_DATA");

            //    entity.Property(e => e.Id)
            //        .HasPrecision(18)
            //        .HasColumnName("ID");

            //    entity.Property(e => e.Keyword)
            //        .HasMaxLength(1000)
            //        .IsUnicode(false)
            //        .HasColumnName("KEYWORD");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.Name)
            //        .HasMaxLength(200)
            //        .HasColumnName("NAME");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.Title)
            //        .HasMaxLength(1000)
            //        .HasColumnName("TITLE");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(50)
            //        .IsUnicode(false)
            //        .HasColumnName("UCT_FP");

            //    entity.Property(e => e.Xdays)
            //        .HasColumnType("NUMBER")
            //        .HasColumnName("XDAYS");
            //});

            //modelBuilder.Entity<VTipTtaVot>(entity =>
            //{
            //    entity.HasNoKey();

            //    entity.ToView("V_TIP_TTA_VOT");

            //    entity.Property(e => e.ActionDate)
            //        .HasColumnType("DATE")
            //        .HasColumnName("ACTION_DATE");

            //    entity.Property(e => e.ApplicationId)
            //        .HasPrecision(18)
            //        .HasColumnName("APPLICATION_ID");

            //    entity.Property(e => e.ApplicationName)
            //        .HasMaxLength(200)
            //        .HasColumnName("APPLICATION_NAME");

            //    entity.Property(e => e.AreaId)
            //        .HasPrecision(18)
            //        .HasColumnName("AREA_ID");

            //    entity.Property(e => e.AreaName)
            //        .HasMaxLength(200)
            //        .HasColumnName("AREA_NAME");

            //    entity.Property(e => e.AssetId)
            //        .HasPrecision(18)
            //        .HasColumnName("ASSET_ID");

            //    entity.Property(e => e.AssetName)
            //        .HasMaxLength(200)
            //        .HasColumnName("ASSET_NAME");

            //    entity.Property(e => e.AvgIncrmntlOilGain)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("AVG_INCRMNTL_OIL_GAIN");

            //    entity.Property(e => e.ClusterId)
            //        .HasPrecision(18)
            //        .HasColumnName("CLUSTER_ID");

            //    entity.Property(e => e.ClusterName)
            //        .HasMaxLength(200)
            //        .HasColumnName("CLUSTER_NAME");

            //    entity.Property(e => e.Co2ReductnUnitYr)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("CO2_REDUCTN_UNIT_YR");

            //    entity.Property(e => e.CostSavingUnitYr)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("COST_SAVING_UNIT_YR");

            //    entity.Property(e => e.MaturityId)
            //        .HasPrecision(18)
            //        .HasColumnName("MATURITY_ID");

            //    entity.Property(e => e.MaturityLevelName)
            //        .HasMaxLength(200)
            //        .HasColumnName("MATURITY_LEVEL_NAME");

            //    entity.Property(e => e.MwhCost)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("MWH_COST");

            //    entity.Property(e => e.PowerSavingUnitYr)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("POWER_SAVING_UNIT_YR");

            //    entity.Property(e => e.RefNo)
            //        .HasMaxLength(242)
            //        .IsUnicode(false)
            //        .HasColumnName("REF_NO");

            //    entity.Property(e => e.StatusId)
            //        .HasPrecision(18)
            //        .HasColumnName("STATUS_ID");

            //    entity.Property(e => e.StatusName)
            //        .HasMaxLength(200)
            //        .HasColumnName("STATUS_NAME");

            //    entity.Property(e => e.SubthemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("SUBTHEME_ID");

            //    entity.Property(e => e.SubthemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("SUBTHEME_NAME");

            //    entity.Property(e => e.ThemeId)
            //        .HasPrecision(18)
            //        .HasColumnName("THEME_ID");

            //    entity.Property(e => e.ThemeName)
            //        .HasMaxLength(200)
            //        .HasColumnName("THEME_NAME");

            //    entity.Property(e => e.TotOilDefermentAvoidance)
            //        .HasColumnType("NUMBER(18,3)")
            //        .HasColumnName("TOT_OIL_DEFERMENT_AVOIDANCE");

            //    entity.Property(e => e.TrialName)
            //        .HasMaxLength(500)
            //        .HasColumnName("TRIAL_NAME");

            //    entity.Property(e => e.UctFp)
            //        .HasMaxLength(20)
            //        .HasColumnName("UCT_FP");
            //});

            modelBuilder.Entity<VendorToChrQuery>(entity =>
            {
                entity.ToTable("VENDOR_TO_CHR_QUERIES");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.HasAttachment)
                    .HasPrecision(1)
                    .HasColumnName("HAS_ATTACHMENT");

                entity.Property(e => e.IsPublic)
                    .HasPrecision(1)
                    .HasColumnName("IS_PUBLIC");

                entity.Property(e => e.IsRead)
                    .HasPrecision(1)
                    .HasColumnName("IS_READ")
                    .HasDefaultValueSql("0 ");

                entity.Property(e => e.Query)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("QUERY");

                entity.Property(e => e.ResponseId)
                    .HasPrecision(18)
                    .HasColumnName("RESPONSE_ID");

                entity.HasOne(d => d.Response)
                    .WithMany(p => p.VendorToChrQueries)
                    .HasForeignKey(d => d.ResponseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("VENDOR_TO_CHR_QUERIES_FK1");
            });

            modelBuilder.Entity<VendorToChrQueryResponse>(entity =>
            {
                entity.ToTable("VENDOR_TO_CHR_QUERY_RESPONSE");

                entity.Property(e => e.Id)
                    .HasPrecision(18)
                    .HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CREATED_BY");

                entity.Property(e => e.CreatedOn)
                    .HasColumnType("DATE")
                    .HasColumnName("CREATED_ON");

                entity.Property(e => e.HasAttachment)
                    .HasPrecision(1)
                    .HasColumnName("HAS_ATTACHMENT");

                entity.Property(e => e.QueryId)
                    .HasPrecision(18)
                    .HasColumnName("QUERY_ID");

                entity.Property(e => e.Response)
                    .HasColumnType("CLOB")
                    .HasColumnName("RESPONSE");

                entity.HasOne(d => d.Query)
                    .WithMany(p => p.VendorToChrQueryResponses)
                    .HasForeignKey(d => d.QueryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("VENDOR_TO_CHR_QUERY_RESPO_FK1");
            });

            modelBuilder.HasSequence("CTR_ADDITIONAL_SOLUTIONS_SEQ");

            modelBuilder.HasSequence("CTR_ADDITIONAL_SOLUTIONS_SEQ1");

            modelBuilder.HasSequence("DEP_INITIATION_SEQ");

            modelBuilder.HasSequence("EMAIL_TEMPLATE_CONFIGURATION_SEQ");

            modelBuilder.HasSequence("EMAIL_TEMPLATE_CONFIGURATION_SEQ1");

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
