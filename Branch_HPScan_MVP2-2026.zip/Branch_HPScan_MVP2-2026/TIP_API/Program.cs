using TIP_API;
using TIP_Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.AspNetCore.Server.IISIntegration;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using TIP_Core;
using Microsoft.EntityFrameworkCore;
using Oracle.EntityFrameworkCore;
using TIP_BAL.BackgroundServices;
using TIP_BAL.Interface;
using TIP_API.Endpoints;
using TIP_BAL.Interface.Admin;
using TIP_BusinessLogic.Interface;
using Serilog;
using TIP_API.ExceptionHandler;
using TIP_API.Auth;
using System.Text;
using TIP_Common.PDOSMS;
using ILogger = Microsoft.Extensions.Logging.ILogger;

var builder = WebApplication.CreateBuilder(args);

const string JwtOrNegotiateScheme = "JWT_OR_NEGOTIATE";

builder.Services.Configure<JwtSettings>(builder.Configuration.GetSection(JwtSettings.SectionName));
builder.Services.AddSingleton<IJwtTokenService, JwtTokenService>();

var jwtSettings = builder.Configuration.GetSection(JwtSettings.SectionName).Get<JwtSettings>() ?? new JwtSettings();
if (string.IsNullOrWhiteSpace(jwtSettings.Key))
{
    throw new InvalidOperationException("Jwt:Key must be configured in appsettings.");
}

builder.Services
    .AddAuthentication(options =>
    {
        options.DefaultAuthenticateScheme = JwtOrNegotiateScheme;
        options.DefaultChallengeScheme = JwtOrNegotiateScheme;
    })
    .AddPolicyScheme(JwtOrNegotiateScheme, "JWT or Windows Negotiate", options =>
    {
        options.ForwardDefaultSelector = context =>
        {
            var authorization = context.Request.Headers.Authorization.FirstOrDefault();
            if (!string.IsNullOrEmpty(authorization)
                && authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                return JwtBearerDefaults.AuthenticationScheme;
            }

            return NegotiateDefaults.AuthenticationScheme;
        };
    })
    .AddJwtBearer(options =>
    {
        options.RequireHttpsMetadata = false;
        options.SaveToken = true;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateIssuerSigningKey = true,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1),
            ValidIssuer = jwtSettings.Issuer,
            ValidAudience = jwtSettings.Audience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings.Key)),
            NameClaimType = System.Security.Claims.ClaimTypes.Name,
            RoleClaimType = System.Security.Claims.ClaimTypes.Role
        };
    })
    .AddNegotiate();

builder.Services.AddAuthorization(options =>
{
    options.FallbackPolicy = new AuthorizationPolicyBuilder(
            JwtBearerDefaults.AuthenticationScheme,
            NegotiateDefaults.AuthenticationScheme)
        .RequireAuthenticatedUser()
        .Build();
});

builder.Services.AddCors(options => options.AddPolicy("AllowCors", policy =>
{
    policy.WithOrigins("http://localhost:4200")
        .AllowAnyMethod()
        .AllowAnyHeader()
        .AllowCredentials();
}));

builder.Services.AddMvc(config =>
{
    var policy = new AuthorizationPolicyBuilder(
            JwtBearerDefaults.AuthenticationScheme,
            NegotiateDefaults.AuthenticationScheme)
        .RequireAuthenticatedUser()
        .Build();
    config.Filters.Add(new AuthorizeFilter(policy));
});
builder.Logging.ClearProviders();
builder.Logging.AddConsole();

builder.Services.AddScoped<EmailService>();
builder.Services.AddScoped<ReminderService>();
builder.Services.AddSingleton<PeriodicHostedService>();
builder.Services.AddHostedService(
    provider => provider.GetRequiredService<PeriodicHostedService>());
// Add services to the container.
builder.Services.AddControllers().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.PropertyNamingPolicy = null;
    options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Version = "v1",
        Title = "PDO: Technology Innovation Portal",
        Description = "PDO TIP API",
        Contact = new OpenApiContact()
        {
            Name = "",
            Email = ""
        }
    });
    var security = new Dictionary<string, IEnumerable<string>>
                {
                    {"Bearer", new string[] { }},
                };

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT"
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement()
    {
        {
            new OpenApiSecurityScheme()
            {
                Reference=new OpenApiReference()
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[]{}
        }
    });

});

DependencyInjection.AddServiceDI(builder.Services);
DependencyInjection.AddRepositoryDI(builder.Services);

// Explicitly reload base + environment settings so IIS Express / Development
// always picks up ConnectionString from appsettings.Development.json.
builder.Configuration
    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true, reloadOnChange: true);
    // Initialize TIP SMS configuration
    TIPSMS.Initialize(builder.Configuration);

builder.Services.AddDbContext<AppDbContext>(options =>
{
    var connectionString = builder.Configuration.GetSection("ConnectionString")["DataSource"];
    if (string.IsNullOrWhiteSpace(connectionString))
    {
        throw new InvalidOperationException(
            $"Oracle ConnectionString:DataSource is missing for environment '{builder.Environment.EnvironmentName}'. " +
            "Ensure ASPNETCORE_ENVIRONMENT=Development and appsettings.Development.json contains ConnectionString:DataSource.");
    }

    string decryptedConnectionString;
    try
    {
        decryptedConnectionString = CryptoExtensions.Decrypt(connectionString);
    }
    catch (Exception ex)
    {
        throw new InvalidOperationException("Failed to decrypt Oracle ConnectionString:DataSource.", ex);
    }

    if (string.IsNullOrWhiteSpace(decryptedConnectionString))
    {
        throw new InvalidOperationException("Decrypted Oracle connection string is empty.");
    }

    options.UseOracle(decryptedConnectionString, oracleOptions =>
    {
        // Oracle 19c/21c do not support TRUE/FALSE literals in SQL.
        // ODP.NET 23+ defaults to DatabaseVersion23 unless overridden.
        oracleOptions.UseOracleSQLCompatibility(OracleSQLCompatibility.DatabaseVersion19);
    });
});

builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
var serviceProvider = builder.Services.BuildServiceProvider();
var accessor = serviceProvider.GetService<IHttpContextAccessor>();
Global.SetHttpContextAccessor(accessor);
var ch_reg = serviceProvider.GetService<IChallengeService>();
var user_setting = serviceProvider.GetService<IUserSettingsService>();
var common_service = serviceProvider.GetService<ICommonService>();
var response_service = serviceProvider.GetService<IResponseService>();
var dashboard_service = serviceProvider.GetService<IDashboardService>();
var logger = serviceProvider.GetService<ILoggerFactory>();
var configration = serviceProvider.GetService<IConfiguration>();

var app = builder.Build();

var loggerFactory = app.Services.GetService<ILoggerFactory>();

var fileName = DateTime.Now.ToString("yyyyMMdd");
loggerFactory.AddSerilog(new LoggerConfiguration()
            .MinimumLevel.Debug().WriteTo.File($@"{Directory.GetCurrentDirectory()}{builder.Configuration["Logging:LogFilePath"].ToString().Replace("{Date}", fileName.ToString())}")
            .CreateLogger());

app.ConfigureExceptionHandler(app.Configuration, accessor, loggerFactory);
app.UseRouting();
app.UseCors("AllowCors");

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<ApiKeyMiddleware>();
// Audit must run after auth so User identity is available, and before endpoints execute.
app.UseMiddleware<TIP_API.Middleware.AuditCaptureMiddleware>();

// Map endpoints AFTER middleware so audit capture covers controllers and minimal APIs.
app.MapGet("/SchedulerServiceStatus", (
    PeriodicHostedService service) =>
{
    return new PeriodicHostedServiceState(service.IsEnabled);
});

app.MapGet("/StartSS", (
    PeriodicHostedService service) =>
{
    service.IsEnabled = true;
});

app.MapGet("/StopSS", (
    PeriodicHostedService service) =>
{
    service.IsEnabled = false;
});

LocationEndpointsConfig.GetUserRoledataEndPoint(app, user_setting, ch_reg, common_service, response_service, loggerFactory.CreateLogger<LocationEndpointsConfig>(), accessor, configration);

app.MapControllers().RequireCors("AllowCors");
app.Run();
