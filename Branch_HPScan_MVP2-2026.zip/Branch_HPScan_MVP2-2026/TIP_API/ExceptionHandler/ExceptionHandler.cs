﻿using Microsoft.AspNetCore.Diagnostics;
using Newtonsoft.Json;
using System.Net;
using TIP_API.DTO;
using TIP_BusinessLogic.Interface;
using TIP_Common;
using TIP_Common.Helpers;

namespace TIP_API.ExceptionHandler
{
    public static class ExceptionHandler
    {
        private static ILogger logger;

        private static ICommonService commonService;
        
        public static void ConfigureExceptionHandler(this IApplicationBuilder app, IConfiguration configuration, IHttpContextAccessor accessor, ILoggerFactory factory)
        {
            app.UseExceptionHandler(appError =>
            {
                appError.Run(async context =>
                {

                    logger = factory.CreateLogger("ExceptionHandler"); ;

                    commonService = accessor.HttpContext?.RequestServices.GetRequiredService<ICommonService>();
                  var s=  context.Request.RouteValues; 
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    context.Response.ContentType = "application/json";
                    var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
                    Exception exception = contextFeature?.Error;

                    Guid errorId = Guid.NewGuid();
                    
                    string errormsg = string.Format("{0}{1}", configuration["GlobalErrorMessage"], string.Format("<b>{0}</b>", errorId));

                    commonService.SaveApplicationErrorLog(ExtensionMethods.GetExceptionMessage(exception), accessor.HttpContext.Request.Path, accessor.HttpContext.Request.Path, Global.User.MuNumber, AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext), errorId);


                    if (contextFeature != null)
                    {
                        var resp = new TIP_RESULT()
                        {
                            status = context.Response.StatusCode,
                            TResponse = "Error Occurred",
                            message = errormsg,
                        };
                        
                        await context.Response.WriteAsync(JsonConvert.SerializeObject(resp));
                    }
                });
            });
        }
    }
}
