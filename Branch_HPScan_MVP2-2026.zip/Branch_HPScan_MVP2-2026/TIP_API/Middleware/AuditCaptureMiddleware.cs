using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using TIP_BAL.Services;
using TIP_CORE.EntitiesDTO;
using TIP_Common.Helpers;

namespace TIP_API.Middleware
{
    /// <summary>
    /// Automatically writes TR_AUDIT_LOG rows for:
    /// - Mutating HTTP requests (POST / PUT / PATCH / DELETE) that change data
    /// - User login / logout activity
    /// Never throws into the business pipeline.
    /// </summary>
    public class AuditCaptureMiddleware
    {
        private static readonly HashSet<string> MutatingMethods = new(StringComparer.OrdinalIgnoreCase)
        {
            HttpMethods.Post, HttpMethods.Put, HttpMethods.Patch, HttpMethods.Delete
        };

        /// <summary>Exact/partial paths that represent login or logout (any HTTP method).</summary>
        private static readonly string[] AuthCapturePathFragments =
        {
            "/api/Common/GetJwtToken",
            "/api/Common/Logout",
            "/api/UserSettings/UpdateActiveRole",
            "/api/GetUserLogin",
            "/api/UpdateUserLogin",
            "/api/GetExternalUserForSso"
        };

        private static readonly string[] SkipPathFragments =
        {
            "/swagger",
            "/health",
            "/favicon",
            "/SchedulerServiceStatus",
            "/StartSS",
            "/StopSS",
            "/api/Report/AuditLog", // list/detail only; Clear already writes a retained CLEAR row
            "/api/Account/refresh",
            "/api/Account/Refresh",
            "/api/Common/download",
            "/api/Common/Download",
            "/api/Common/downloadSingleFile",
            "/api/Common/downloadFiles",
            "/api/Common/downloadQueryResponseFiles",
            "/api/Common/getFilesCount",
            "/api/Common/CanACtivateRouteAsync",
            "/api/Common/GetDynamicMenu",
            "/api/Common/GetWinAuthAccount",
            "/api/Common/DataMask",
            "/api/Common/GetMasterData",
            "/api/Common/GetMasterDetail",
            "/api/Common/GetMasterCustmized",
            "/api/Common/GetAssetByMU",
            "/api/Common/GetCluster",
            "/api/Common/GetContractData",
            "/api/Common/GetEmail",
            "/api/Common/GetDocLink",
            "/api/Common/GetKPI",
            "/api/Common/GetCtr"
        };

        /// <summary>Read-only report/search POST endpoints (skipped only when path is not a Save/Update/Delete).</summary>
        private static readonly string[] SkipReadOnlyPostFragments =
        {
            "HeatMAP",
            "HeatMap",
            "OverAllReport",
            "TechnologyStatusReport",
            "TechnologyStatusTitle",
            "MasterSheet",
            "ActionTracker",
            "GetAllTasks",
            "TechnologyStatus",
            "/Export",
            "/export"
        };

        private const int MaxBodyBytes = 64000;

        private readonly RequestDelegate _next;
        private readonly ILogger<AuditCaptureMiddleware> _logger;

        public AuditCaptureMiddleware(RequestDelegate next, ILogger<AuditCaptureMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context, IServiceScopeFactory scopeFactory)
        {
            if (HttpMethods.IsOptions(context.Request.Method))
            {
                await _next(context);
                return;
            }

            var path = context.Request.Path.Value ?? string.Empty;
            var isAuthEvent = IsAuthCapturePath(path);
            var isMutation = MutatingMethods.Contains(context.Request.Method);

            if (!isAuthEvent && !isMutation)
            {
                await _next(context);
                return;
            }

            if (ShouldSkip(path, context.Request.Method, isAuthEvent))
            {
                _logger.LogDebug("AuditCapture skipped for {Method} {Path}", context.Request.Method, path);
                await _next(context);
                return;
            }

            string? requestBody = null;
            try
            {
                requestBody = await ReadRequestBodyAsync(context.Request);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "AuditCaptureMiddleware could not read request body for {Path}", path);
            }

            var originalBody = context.Response.Body;
            await using var responseBuffer = new MemoryStream();
            context.Response.Body = responseBuffer;

            try
            {
                await _next(context);

                responseBuffer.Position = 0;
                if (responseBuffer.Length > 0)
                {
                    await responseBuffer.CopyToAsync(originalBody);
                }

                if (!IsSuccessfulStatus(context.Response.StatusCode))
                {
                    _logger.LogDebug("AuditCapture skipped non-success HTTP {Status} for {Path}",
                        context.Response.StatusCode, path);
                    return;
                }

                responseBuffer.Position = 0;
                string? responseBody = null;
                var contentType = context.Response.ContentType ?? string.Empty;
                var isJsonResponse = contentType.Contains("json", StringComparison.OrdinalIgnoreCase)
                    || contentType.Contains("text", StringComparison.OrdinalIgnoreCase)
                    || string.IsNullOrWhiteSpace(contentType);

                if (isJsonResponse && responseBuffer.Length > 0 && responseBuffer.Length <= MaxBodyBytes)
                {
                    using var reader = new StreamReader(responseBuffer, Encoding.UTF8, detectEncodingFromByteOrderMarks: false, leaveOpen: true);
                    responseBody = await reader.ReadToEndAsync();
                }

                if (!IsBusinessSuccess(responseBody))
                {
                    _logger.LogDebug("AuditCapture skipped business-failure response for {Path}", path);
                    return;
                }

                var auditRequest = BuildAuditRequest(context, path, requestBody, responseBody, isAuthEvent);
                await PersistAuditSafeAsync(scopeFactory, auditRequest, path);
            }
            catch (Exception)
            {
                // Restore body stream then rethrow so ExceptionHandler can run.
                throw;
            }
            finally
            {
                context.Response.Body = originalBody;
            }
        }

        private static bool IsAuthCapturePath(string path)
        {
            foreach (var fragment in AuthCapturePathFragments)
            {
                if (path.Contains(fragment, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        private static bool ShouldSkip(string path, string method, bool isAuthEvent)
        {
            // Always capture login/logout/role-switch events.
            if (isAuthEvent)
                return false;

            // Always capture Save/Update/Delete/Submit/Upload-style routes (even if name also contains Get/List).
            if (LooksLikeDataChange(path))
                return false;

            foreach (var fragment in SkipPathFragments)
            {
                if (path.Contains(fragment, StringComparison.OrdinalIgnoreCase))
                    return true;
            }

            // Skip known read-only report/search POSTs only.
            if (HttpMethods.IsPost(method) || HttpMethods.IsPut(method) || HttpMethods.IsPatch(method))
            {
                foreach (var fragment in SkipReadOnlyPostFragments)
                {
                    if (path.Contains(fragment, StringComparison.OrdinalIgnoreCase))
                        return true;
                }

                // Pure Get*/Load*/Search* POSTs with no mutation keywords.
                if (IsClearlyReadOnly(path))
                    return true;
            }

            // Default for POST/PUT/PATCH/DELETE: capture.
            return false;
        }

        private static bool IsClearlyReadOnly(string path)
        {
            // Matches action names that are clearly reads, e.g. /GetX, /LoadX, /SearchX
            return Regex.IsMatch(
                path,
                @"/(Get|Fetch|Load|Search|Filter|List|Lookup|Find)[A-Za-z0-9_]*(/|$)",
                RegexOptions.IgnoreCase);
        }

        private static bool LooksLikeDataChange(string path)
        {
            return Regex.IsMatch(path,
                @"(Save|Create|Add|Insert|Update|Edit|Delete|Remove|Submit|Approve|Reject|Clear|Upload|Assign|Map|Publish|Register|Activate|Deactivate|Reset|Change)",
                RegexOptions.IgnoreCase);
        }

        private static bool IsSuccessfulStatus(int statusCode)
            => statusCode >= 200 && statusCode < 400;

        private static async Task<string?> ReadRequestBodyAsync(HttpRequest request)
        {
            if (request.Body == null || !request.Body.CanRead)
                return null;

            if (request.ContentLength is 0)
                return null;

            if (request.ContentLength > MaxBodyBytes)
                return "[TRUNCATED: request body too large]";

            request.EnableBuffering();

            if (request.Body.CanSeek)
                request.Body.Position = 0;

            using var reader = new StreamReader(request.Body, Encoding.UTF8, detectEncodingFromByteOrderMarks: false, leaveOpen: true);
            var body = await reader.ReadToEndAsync();

            if (request.Body.CanSeek)
                request.Body.Position = 0;

            return string.IsNullOrWhiteSpace(body) ? null : body;
        }

        private AuditLogWriteRequestDto BuildAuditRequest(
            HttpContext context,
            string path,
            string? requestBody,
            string? responseBody,
            bool isAuthEvent)
        {
            var segments = path.Split('/', StringSplitOptions.RemoveEmptyEntries);
            // /api/{Controller}/{Action}/...
            var controller = segments.Length >= 2 ? segments[1] : (segments.FirstOrDefault() ?? "API");
            var action = segments.Length >= 3 ? segments[2] : controller;

            var actionType = isAuthEvent
                ? MapAuthAction(path, context.Request.Method)
                : MapDataAction(path, context.Request.Method, action);

            var moduleName = MapModule(controller, isAuthEvent);
            var entityType = SanitizeToken(action);
            var entityId = ExtractEntityId(path, requestBody);
            var entityName = ExtractEntityName(requestBody);
            var userId = context.User?.Identity?.Name;
            if (string.IsNullOrWhiteSpace(userId))
            {
                try { userId = AccountHelper.GetWinAuthAccount(context); } catch { /* ignore */ }
            }

            string? ip = null;
            try { ip = AccountHelper.GetWinAuthIPForLogs(context); } catch { ip = context.Connection.RemoteIpAddress?.ToString(); }

            var summary = isAuthEvent
                ? BuildAuthSummary(actionType, userId, path)
                : $"{actionType} via {context.Request.Method} {controller}/{action}";

            return new AuditLogWriteRequestDto
            {
                moduleName = moduleName,
                actionType = actionType,
                entityType = entityType,
                entityId = entityId,
                entityName = entityName,
                summary = summary,
                comments = isAuthEvent
                    ? $"Auth event captured from {path}"
                    : $"Auto-captured mutating request {context.Request.Method} {path}",
                requestJson = requestBody,
                responseJson = Truncate(responseBody, 8000),
                httpMethod = context.Request.Method,
                requestPath = path,
                correlationId = context.TraceIdentifier,
                ipAddress = ip,
                userId = string.IsNullOrWhiteSpace(userId) ? "SYSTEM" : userId.Trim(),
                userDisplayName = userId
            };
        }

        private async Task PersistAuditSafeAsync(IServiceScopeFactory scopeFactory, AuditLogWriteRequestDto auditRequest, string path)
        {
            try
            {
                using var scope = scopeFactory.CreateScope();
                var auditService = scope.ServiceProvider.GetRequiredService<IAuditLogService>();
                await auditService.TryAuditAsync(auditRequest);
                _logger.LogInformation(
                    "AuditCapture saved {Action} {Module}/{Entity} for {Path}",
                    auditRequest.actionType, auditRequest.moduleName, auditRequest.entityType, path);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "AuditCaptureMiddleware failed to persist audit for {Path}", path);
            }
        }

        private static string MapAuthAction(string path, string method)
        {
            if (path.Contains("Logout", StringComparison.OrdinalIgnoreCase))
                return "LOGOUT";
            if (path.Contains("UpdateActiveRole", StringComparison.OrdinalIgnoreCase))
                return "ACCESS";
            if (path.Contains("GetJwtToken", StringComparison.OrdinalIgnoreCase)
                || path.Contains("getUserLoginData", StringComparison.OrdinalIgnoreCase)
                || path.Contains("GetUserLogin", StringComparison.OrdinalIgnoreCase)
                || path.Contains("UpdateUserLogin", StringComparison.OrdinalIgnoreCase)
                || path.Contains("GetExternalUserForSso", StringComparison.OrdinalIgnoreCase))
                return "LOGIN";
            return HttpMethods.IsPost(method) ? "LOGIN" : "ACCESS";
        }

        private static string MapDataAction(string path, string method, string actionSegment)
        {
            var haystack = $"{path}/{actionSegment}";

            if (Regex.IsMatch(haystack, @"Delete|Remove", RegexOptions.IgnoreCase))
                return "DELETE";
            if (Regex.IsMatch(haystack, @"Approve", RegexOptions.IgnoreCase))
                return "APPROVE";
            if (Regex.IsMatch(haystack, @"Reject", RegexOptions.IgnoreCase))
                return "REJECT";
            if (Regex.IsMatch(haystack, @"Submit", RegexOptions.IgnoreCase))
                return "SUBMIT";
            if (Regex.IsMatch(haystack, @"Clear", RegexOptions.IgnoreCase))
                return "CLEAR";
            if (Regex.IsMatch(haystack, @"Update|Edit|Save|Assign|Map|Upload", RegexOptions.IgnoreCase))
                return "UPDATE";
            if (Regex.IsMatch(haystack, @"Create|Add|Insert|Register", RegexOptions.IgnoreCase))
                return "CREATE";

            return method.ToUpperInvariant() switch
            {
                "POST" => "CREATE",
                "PUT" => "UPDATE",
                "PATCH" => "UPDATE",
                "DELETE" => "DELETE",
                _ => method.ToUpperInvariant()
            };
        }

        private static string MapModule(string controller, bool isAuthEvent)
        {
            if (isAuthEvent)
                return "AUTH";

            return controller.ToUpperInvariant() switch
            {
                "USERSETTINGS" => "RBAC",
                "COMMON" => "COMMON",
                "DASHBOARD" => "DASHBOARD",
                "CHALLENGE" => "BTI",
                "CTR" => "TTA",
                "EXECUTION" => "EXECUTION",
                "PIR" => "PIR",
                "TECHNOLOGYBANK" => "TECHNOLOGY",
                "REPORT" => "REPORTING",
                "DEPLOYMENT" or "DEPVOT" => "DEPLOYMENT",
                _ => SanitizeToken(controller)
            };
        }

        private static string BuildAuthSummary(string actionType, string? userId, string path)
        {
            var user = string.IsNullOrWhiteSpace(userId) ? "unknown user" : userId;
            return actionType switch
            {
                "LOGIN" => $"User login successful for {user}",
                "LOGOUT" => $"User logout for {user}",
                "ACCESS" => $"Role/session access update for {user}",
                _ => $"{actionType} for {user} via {path}"
            };
        }

        private static string SanitizeToken(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return "UNKNOWN";
            var cleaned = Regex.Replace(value, @"[^A-Za-z0-9_]", "").ToUpperInvariant();
            return string.IsNullOrEmpty(cleaned) ? "UNKNOWN" : cleaned;
        }

        private static string? ExtractEntityId(string path, string? requestBody)
        {
            var segments = path.Split('/', StringSplitOptions.RemoveEmptyEntries);
            for (var i = segments.Length - 1; i >= 0; i--)
            {
                if (decimal.TryParse(segments[i], out _) || Guid.TryParse(segments[i], out _))
                    return segments[i];
            }

            return ExtractJsonProperty(requestBody,
                "id", "Id", "ID", "entityId", "EntityId",
                "CTR_ID", "ctrId", "PIR_ID", "pirId",
                "CHALLENGE_ID", "challengeId", "Role_ID", "ROLE_ID", "userId", "USER_ID");
        }

        private static string? ExtractEntityName(string? requestBody)
        {
            return ExtractJsonProperty(requestBody,
                "name", "Name", "title", "Title", "TITLE",
                "entityName", "EntityName", "REF_NO", "refNo", "CODE", "code");
        }

        private static string? ExtractJsonProperty(string? json, params string[] propertyNames)
        {
            if (string.IsNullOrWhiteSpace(json))
                return null;

            try
            {
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.ValueKind != JsonValueKind.Object)
                    return null;

                foreach (var propName in propertyNames)
                {
                    if (doc.RootElement.TryGetProperty(propName, out var prop)
                        && prop.ValueKind != JsonValueKind.Null
                        && prop.ValueKind != JsonValueKind.Undefined)
                    {
                        var text = prop.ToString();
                        if (!string.IsNullOrWhiteSpace(text))
                            return text.Length > 200 ? text.Substring(0, 200) : text;
                    }
                }
            }
            catch
            {
                // non-JSON body
            }

            return null;
        }

        private static bool IsBusinessSuccess(string? responseBody)
        {
            if (string.IsNullOrWhiteSpace(responseBody))
                return true;

            try
            {
                using var doc = JsonDocument.Parse(responseBody);
                if (!doc.RootElement.TryGetProperty("status", out var statusProp))
                    return true;

                if (statusProp.ValueKind == JsonValueKind.Number && statusProp.TryGetInt32(out var status))
                    return status == 1;

                if (statusProp.ValueKind == JsonValueKind.String
                    && int.TryParse(statusProp.GetString(), out var statusStr))
                    return statusStr == 1;
            }
            catch
            {
                return true;
            }

            return true;
        }

        private static string? Truncate(string? value, int maxLength)
        {
            if (string.IsNullOrEmpty(value) || value.Length <= maxLength)
                return value;
            return value.Substring(0, maxLength) + "...";
        }
    }
}
