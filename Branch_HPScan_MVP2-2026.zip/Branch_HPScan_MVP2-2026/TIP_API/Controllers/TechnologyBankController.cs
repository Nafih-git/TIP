﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Exchange.WebServices.Data;
using System.Text.Json;
using TIP_API.DTO;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using static System.Net.Mime.MediaTypeNames;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TechnologyBankController : BaseController
    {
        private readonly ITechnologyBankService _technologyBankService;
      
        public TechnologyBankController(ITechnologyBankService technologyBankService, ICommonService _commonService) : base(_commonService)
        {
        _technologyBankService = technologyBankService;
    }

        [Route("GetTechnologyBanks")]
        [HttpGet]
        public async Task<IActionResult> GetTechnologyBanks()
        {
            try
            {
				EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();

				var result = await _technologyBankService.GetTechnologyBanks(LoggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("FilterTechnologyBanks")]
        [HttpPost]
        public async Task<IActionResult> GetFilterTechnologyBanks(TechnologyBankFilterDTO technologyBankFilterDTO)
        {
            try
            {
                var result = await _technologyBankService.GetFilterTechnologyBanks(technologyBankFilterDTO);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddTechnologyBanks")]
        [HttpPost]
        public async Task<IActionResult> AddTechnologyBanks([Bind("")] TechnologyBankIP_DTO DTO)
        {
            try
            {
                EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();
                var addObj = await TechBankDTOMapping(DTO, true);
                var result = await _technologyBankService.AddTechnologyBank(addObj);
                
                UtlAuditTrail obj = new UtlAuditTrail()
                {
                    TableName = "TECHNOLOGY_BANK",
                    Action = "ADD",
                    ActionBy = LoggedInUser.DISPLAY_NAME+ " "+ LoggedInUser.COMPANY_NUMBER,
                    ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                    Description = JsonSerializer.Serialize(DTO),
                   
                };
                await commonService.Log(obj);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

      

       


        [Route("UpdateTechnologyBanks")]
        [HttpPost]
        public async Task<IActionResult> UpdateTechnologyBanks([Bind("")] TechnologyBankIP_DTO DTO)
        {
            try
            {

                var updateObj = await TechBankDTOMapping(DTO, false);
                var result = await _technologyBankService.UpdateTechnologyBank(updateObj);
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                UtlAuditTrail obj = new UtlAuditTrail()
                {
                    TableName = "TECHNOLOGY_BANK",
                    Action = "UPDATE",
                    ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                    ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                    Description = JsonSerializer.Serialize(DTO),
                    
                };
                await commonService.Log(obj);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }

        [Route("DeleteTechnologyBanks/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteTechnologyBanks(long id)
        {
            try
            {


                var result = await _technologyBankService.DeleteTechnologyBank(id, GetIdentityOfLoggedInUser());
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }

        private async Task<TechnologyBank> TechBankDTOMapping(TechnologyBankIP_DTO obj, bool isAdd)
        {
            EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();
            TechnologyBank returnObj;
            if (isAdd)
            {
                returnObj = new TechnologyBank()
            {
                Id = 0,
                Title = obj.title,
                Area = obj.areaId,
                Theme = obj.themeId,
                SubTheme = obj.subThemeId,
                Application = obj.applicationId,
                Source = obj.sourceId,
                ContactFp = obj.contactFocalPoint,
                Description = obj.description,
                ContactEmail = obj.contactEmail,
                AssetId= obj.assetId,
                ClusterId= obj.clusterId,
                CreatedBy = LoggedInUser.COMPANY_NUMBER,
                CreatedOn = DateTime.Today,
                CreatedByRef = LoggedInUser.REFERENCE_INDICATOR,
            };
            }
            else
            {
                returnObj = new TechnologyBank()
                {
                    Id = obj.id,
                    Title = obj.title,
                    Area = obj.areaId,
                    Theme = obj.themeId,
                    SubTheme = obj.subThemeId,
                    Application = obj.applicationId,
                    Source = obj.sourceId,
                    ContactFp = obj.contactFocalPoint,
                    Description = obj.description,
                    ContactEmail = obj.contactEmail,
                    AssetId = obj.assetId,
                    ClusterId = obj.clusterId,
                    UpdatedBy = LoggedInUser.COMPANY_NUMBER,
                    UpdatedOn = DateTime.Today,
                    UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR,
                };
            }
            return returnObj;
        }

        [Route("TechnologyStatusTitle/{search}/{areaId}/{applicationId}/{themeId}/{UCT_FP}/{maturationPhase}/{isFilter}")]
        [HttpGet]
        public async Task<IActionResult> TechnologyStatusTitle(string? search,long? areaId,long? applicationId,long? themeId, string? UCT_FP, long? maturationPhase, bool? isFilter)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                var result = await _technologyBankService.TechnologyStatusTitle(search, areaId, applicationId, themeId, UCT_FP, maturationPhase,isFilter);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        public class technologyTitleReportDTO
        {
            public long? tech { get; set; }
           
        }

        [Route("TechnologyStatusReport")]
        [HttpPost]
        public async Task<IActionResult> TechnologyStatusReport([Bind("tech")] technologyTitleReportDTO tech)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                var result = await _technologyBankService.TechnologyStatusReport((long)tech.tech);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("TechnologyHeatMAPReport")]
        [HttpPost]
        public async Task<IActionResult> TechnologyHeatMAPReport([Bind("")] TechnologyStatusRequestDTO technologystatusrequestdto)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                var result = await _technologyBankService.TechnologyHeatMAPReport(technologystatusrequestdto);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ActionTrackerPrint")]
        [HttpPost]
        public async Task<IActionResult> ActionTrackerPrint([Bind("")] ActiionTaskRequestDTO techKPIReportDTO)
        {
            try
            {
                var result = await _technologyBankService.ActionTrackerPrint(techKPIReportDTO);
                var response = new FileContentResult(result.FileBytes, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(result.Type));
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("TechnologyHeatMAPPrint")]
        [HttpPost]
        public async Task<IActionResult> TechnologyHeatMAPPrint([Bind("")] TechnologyStatusRequestDTO technologyheatmapreportdto)
        {
            try
            {
                var result = await _technologyBankService.TechnologyHeatMAPPrint(technologyheatmapreportdto);
                var response = new FileContentResult(result.FileBytes, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(result.Type));
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

    }
}
