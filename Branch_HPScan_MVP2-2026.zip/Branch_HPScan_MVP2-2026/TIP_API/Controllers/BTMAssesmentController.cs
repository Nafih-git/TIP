﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TIP_API.DTO;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using System.Text.Json;
using static TIP_Common.Enum.Enum;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BTMAssesmentController : BaseController
    {
        private readonly IBTMAssesmentService btmService;
        private readonly IBTMPainAreaService _painAreaService;
        public BTMAssesmentController(IBTMAssesmentService _btmService,ICommonService _commonService, IBTMPainAreaService painAreaService) : base(_commonService)
        {
            btmService = _btmService;
            _painAreaService = painAreaService;
        }

        [Route("GetBTMAssessments")]
        [HttpGet]
        public async Task<IActionResult> GetBTMAssessments()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await btmService.GetBTMAssessments(LoggedInUser);                
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        [Route("GetPainAreasByAssessmentID/{ID}")]
        [HttpGet]
        public async Task<IActionResult> GetPainAreasByAssessmentID(int ID)
        {
            try
            {EmployeeDTO employeeDTO = GetIdentityOfLoggedInUser();
                var result = await _painAreaService.GetPainAreasByAssessmentId(ID,employeeDTO);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        [Route("AddBTMAssessments")]
        [HttpPost]
        public async Task<IActionResult> AddBTMAssessments( [Bind("")] BTMAssessmentIP_DTO DTO)
        {
            try
            { 
                var addObj = await BTMAssessmentDTOMapping(DTO, true);
                var result = await btmService.AddBTM(addObj);
                UtlAuditTrail obj =  new UtlAuditTrail() { 
                    TableName= "BTM_ASSESSMENT",
                    Action="ADD",
                    ActionBy=addObj.CreatedBy+" "+addObj.CreatedByRef,
                    ActionOn=addObj.CreatedOn.ToString("dd/MM/yyyy"),
                    Description= JsonSerializer.Serialize(DTO),
                    //Id =addObj.Id,
                };
                await commonService.Log(obj);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("UpdateBTM")]
        [HttpPost]
        public async Task<IActionResult> UpdateBTM([Bind("")] BTMAssessmentIP_DTO DTO)
        {
            try
            {
                var updateObj=await BTMAssessmentDTOMapping(DTO, false);
                var result = await btmService.UpdateBTM(updateObj);
                UtlAuditTrail obj = new UtlAuditTrail()
                {
                    TableName = "BTM_ASSESSMENT",
                    Action = "UPDATE",
                    ActionBy = updateObj.UpdatedBy + " " + updateObj.UpdatedByRef,
                    ActionOn = updateObj.UpdatedOn?.ToString("dd/MM/yyyy"),
                    Description = JsonSerializer.Serialize(DTO),
                    //Id =addObj.Id,
                };
                await commonService.Log(obj);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }


           
        }

        [Route("DeleteBTM/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteBTM(long id)
        {
            try
            {
                EmployeeDTO dto = GetIdentityOfLoggedInUser();
                var result = await btmService.DeleteBTM(id,dto);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }



        }



        [Route("AddPainArea")]
        [HttpPost]
        public async Task<IActionResult> AddPainArea([FromBody] PainAreaDTO DTO)
        {
            try
            {
                if (DTO == null)
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Invalid pain area data.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                var painAreaObj = PainAreaDTOMapping(DTO, true);
                var result = await _painAreaService.AddPainArea(painAreaObj);
                UtlAuditTrail obj = new UtlAuditTrail()
                {
                    TableName = "PAIN_AREAS",
                    Action = "ADD",
                    ActionBy = painAreaObj.CreatedBy ,
                    ActionOn = painAreaObj.CreatedOn.ToString("dd/MM/yyyy"),
                    Description = JsonSerializer.Serialize(DTO),
                    //Id =addObj.Id,
                };
                await commonService.Log(obj);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
                catch (Exception ex)
                {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("UpdatePainArea")]
        [HttpPost]
        public async Task<IActionResult> UpdatePainArea([FromBody] PainAreaDTO DTO)
        {
            EmployeeDTO? employee = GetIdentityOfLoggedInUser();
            try
            {
                if (DTO == null)
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Invalid pain area data.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                var updateObj = PainAreaDTOMapping(DTO, false);
                var result = await _painAreaService.UpdatePainArea(updateObj);
                var reviewedId = commonService.GetMasterDataByParentAndParam1(TypeCodes.PainAreaStatus, BTIAssessment.Reviewed).Result.Id;
                if (DTO.status== reviewedId)
                {
                    await _painAreaService.SendBTMEmail((long)DTO.id, "BTIAS", "BTMP02",employee);
                }
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                UtlAuditTrail obj = new UtlAuditTrail()
                {
                    TableName = "BTM_ASSESSMENT",
                    Action = "UPDATE",
                    ActionBy = updateObj.UpdatedBy ,
                    ActionOn = updateObj.UpdatedOn?.ToString("dd/MM/yyyy"),
                    Description = JsonSerializer.Serialize(DTO),
                    //Id =addObj.Id,
                };
                await commonService.Log(obj);
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }



        }

        [Route("DeletePainArea/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeletePainArea(long id)
        {
            try
            {
                var result = await _painAreaService.DeletePainArea(id,GetIdentityOfLoggedInUser());
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }



        }



        private async Task<BtmAssessment> BTMAssessmentDTOMapping(BTMAssessmentIP_DTO obj,bool isAdd)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            BtmAssessment returnObj = new BtmAssessment()
            {
                AssetId = obj.assetId,
                ClusterId = obj.clusterId > 0 ? obj.clusterId : null,
                DepartmentId = obj.departmentId,
                Id = isAdd ? 0 : obj.id,
                Year = obj.year,
                WorkshopDate = obj.workshopDate,
                StatusId = obj.statusId,
                IsActive = true,
            };
            if (isAdd) {
                returnObj.CreatedBy = Truncate(LoggedInUser?.COMPANY_NUMBER, 20) ?? string.Empty;
                returnObj.CreatedByRef = Truncate(LoggedInUser?.REFERENCE_INDICATOR, 20) ?? string.Empty;
                returnObj.CreatedOn = DateTime.Now;
            }
            else
            {
                returnObj.UpdatedBy = Truncate(LoggedInUser?.COMPANY_NUMBER, 20);
                returnObj.UpdatedByRef = Truncate(LoggedInUser?.REFERENCE_INDICATOR, 20);
                returnObj.UpdatedOn = DateTime.Now;
            }
            return returnObj;
        }

        private static string? Truncate(string? value, int maxLength)
        {
            if (string.IsNullOrEmpty(value))
                return value;
            return value.Length <= maxLength ? value : value.Substring(0, maxLength);
        }

        private PainArea PainAreaDTOMapping(PainAreaDTO obj, bool isAdd)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            PainArea returnObj = new PainArea()
            {
                AssessmentId = obj.assessmentId,
                Description = obj.description,
                RaisedBy = LoggedInUser.COMPANY_NUMBER,
                Id = isAdd ? 0 : obj.id,
                Hsse = obj.hsse,
                NtSource = obj.ntSource.HasValue && obj.ntSource.Value > 0 ? obj.ntSource : null,
                Deferment = obj.deferment,
                Cost = obj.cst,
                Emission = obj.emission,
                NtSolution = obj.ntSolution == "1",
                NtCatalogSolution = obj.ntCatalogSolution.GetValueOrDefault(),
                TechDescription = obj.techDescription,
                TechFp = obj.techFp,
                UctFp = obj.uctFp,
                Remarks = obj.remarks,
                Status = obj.status,
                ClusterId = obj.clusterId.HasValue && obj.clusterId.Value > 0 ? obj.clusterId : null,
                Rank = obj.rank ?? 0
            };
            if (isAdd)
            {
                returnObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                returnObj.CreatedOn = DateTime.Now;
            }
            else
            {
                returnObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                returnObj.UpdatedOn = DateTime.Now;
            }
            return returnObj;
        }

    }
}
