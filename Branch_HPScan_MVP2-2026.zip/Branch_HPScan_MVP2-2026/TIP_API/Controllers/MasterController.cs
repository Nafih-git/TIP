﻿using TIP_BusinessLogic.Interface;
using TIP_Core;
using Microsoft.AspNetCore.Mvc;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterController : ControllerBase
    {
        private readonly IMasterService masterService;

        public MasterController(IMasterService _masterService)
        {
            masterService = _masterService;
        }

        #region Modules
        [HttpGet("GetAllModules")]
        public async Task<IActionResult> GetAllModules()
        {
            return Ok(await masterService.GetModule());
        }

        [HttpGet("GetModuleById/{ModuleId}")]
        public async Task<IActionResult> GetModuleById(int ModuleId)
        {
            var response = await masterService.GetModule(ModuleId);
            return Ok(response.FirstOrDefault());
        }

        [HttpPost("SaveModule")]
        public async Task<IActionResult> SaveModule([FromBody] [Bind("")] Module model)
        {
            return Ok(await masterService.SaveModule(model));
        }
        #endregion
    }
}
