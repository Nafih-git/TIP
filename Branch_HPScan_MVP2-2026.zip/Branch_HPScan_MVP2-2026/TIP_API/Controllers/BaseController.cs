﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Routing;
using System.Text.RegularExpressions;
using TIP_BAL.Interface;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_Common.Helpers;
using TIP_CORE.EntitiesDTO;

namespace TIP_API.Controllers
{
    public class BaseController : ControllerBase
    {
        protected readonly ICommonService commonService;

        protected BaseController(ICommonService _commonService)
        {
            commonService = _commonService;
        }


        protected EmployeeDTO? GetIdentityOfLoggedInUser()
        {
            try
            {
                string UserName = AccountHelper.GetWinAuthAccount(HttpContext).Trim();

                if (!string.IsNullOrWhiteSpace(UserName))
                {
                    EmployeeDTO? loggedinuser = commonService.GetIdentityOfLoggedInUser(UserName);
                    if (loggedinuser == null)
                    {
                        return null;
                    }
                    else
                    {
                        return loggedinuser;
                    }
                }
            }
            catch
            {
                throw ;
            }
            return null;
        }

        protected void ExceptionLogger(Exception ex,string Action,string Controller)
        {
            string UserName = AccountHelper.GetWinAuthAccount(HttpContext).Trim();

            string errorMessage = string.Empty;

            if (ex == null)
            {
               errorMessage =  "No exception provided.";
            }
            else
            {
                errorMessage = $"Exception Type: {ex.GetType().FullName}\n";
                errorMessage += $"Message: {ex.Message}\n";
                errorMessage += $"Source: {ex.Source}\n";
                errorMessage += $"Stack Trace:\n{ex.StackTrace}\n";

                if (ex.InnerException != null)
                {
                    errorMessage += "\nInner Exception:\n";
                    errorMessage += GetDetailedErrorMessage(ex.InnerException);
                }
            }


            commonService.SaveApplicationErrorLog(errorMessage, Action, Controller, UserName, AccountHelper.GetWinAuthIPForLogs(HttpContext).Trim());
        }

        private string GetDetailedErrorMessage(Exception ex, HashSet<Exception> processedExceptions = null)
        {
            if (ex == null)
            {
                return "No exception provided.";
            }

            if (processedExceptions == null)
            {
                processedExceptions = new HashSet<Exception>();
            }

            if (processedExceptions.Contains(ex))
            {
                return "Recursive exception encountered.";
            }

            processedExceptions.Add(ex);

            string errorMessage = $"Exception Type: {ex.GetType().FullName}\n";
            errorMessage += $"Message: {ex.Message}\n";
            errorMessage += $"Source: {ex.Source}\n";
            errorMessage += $"Stack Trace:\n{ex.StackTrace}\n";

            if (ex.InnerException != null)
            {
                errorMessage += "\nInner Exception:\n";
                errorMessage += GetDetailedErrorMessage(ex.InnerException, processedExceptions);
            }

            return errorMessage;
        }

        protected string GetErrorMessage(Exception ex)
        {


            string errorMessage = "ExceptionStart ";

            if (ex == null)
            {
                errorMessage = "No exception provided.";
            }
            else
            {
                errorMessage += $"Exception Type: {ex.GetType().FullName}\n";
                errorMessage += $"Message: {ex.Message}\n";
                errorMessage += $"Source: {ex.Source}\n";
                errorMessage += $"Stack Trace:\n{ex.StackTrace}\n";

                if (ex.InnerException != null)
                {
                    errorMessage += "\nInner Exception:\n";
                    errorMessage += GetDetailedErrorMessage(ex.InnerException);
                }
            }


            return Regex.Replace(errorMessage, @"\s+", " ") + " ExceptionEnd";
        }

        protected static string GetUserFacingExceptionMessage(Exception ex)
        {
            var inner = ex;
            while (inner.InnerException != null)
            {
                inner = inner.InnerException;
            }

            return inner.Message;
        }
    }
}
