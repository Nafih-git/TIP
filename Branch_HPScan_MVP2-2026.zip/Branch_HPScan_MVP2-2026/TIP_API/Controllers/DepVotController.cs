﻿using TIP_API.DTO;
using TIP_BusinessLogic.Interface;
using TIP_CORE;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using TIP_BAL.Services;
using TIP_Common.Helpers;
using TIP_CORE.Entities;
using TIP_Core;
using TIP_CORE.EntitiesDTO;
using TIP_BAL.Interface;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;
using TIP_CORE.Admin;
using TIP_Common.Admin;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.StaticFiles;
using TIP_Common;
using System.IO.Compression;
using System.Text;
using Microsoft.EntityFrameworkCore;
using System.Runtime.Serialization;
using System.IO;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Cors.Infrastructure;
using static TIP_Common.Enum.Enum;
using TIP_BAL.Services.Admin;
using System.Reflection.Emit;

namespace TIP_API.Controllers
{
	[Route("api/[controller]")]
	[ApiController]

	//[Authorize]
	public class DepVotController : BaseController
	{
		private readonly IDepVotService depVotService;
		private readonly IConfiguration Configuration;
		private readonly IEmployeeService employeeService;

		public DepVotController(IDepVotService _depVotService, IConfiguration configuration, ICommonService _commonService, IEmployeeService _employeeService) : base(_commonService)
		{
			depVotService = _depVotService;
			Configuration = configuration;
			employeeService = _employeeService;
		}

		[Route("AssignCH")]
		[HttpPost]
		public async Task<IActionResult> AssignCH([Bind("")] DepVotBaseDTO depVotBaseDTO) 
		{
			try
			{
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
				var result = await depVotService.AssignCH(DepVotBaseDTOMapping(depVotBaseDTO));
				if (result > 0)
				{
					if (depVotBaseDTO.Id > 0)
					{
						await depVotService.SendDeploymentEmail(Convert.ToInt64(depVotBaseDTO.Id), EmailModules.DEP, "DEV001", LoggedInUser, 0, depVotBaseDTO.Chfp, depVotBaseDTO.ChfpDTO.PERSONNEL_NUMBER);
						await depVotService.SendDeploymentEmail(Convert.ToInt64(depVotBaseDTO.Id), EmailModules.DEP, "DEV002", LoggedInUser, 0, depVotBaseDTO.Chfp, depVotBaseDTO.ChfpDTO.PERSONNEL_NUMBER);
					}
					else
					{
						await depVotService.SendDeploymentEmail(Convert.ToInt64(result), EmailModules.DEP, "DEV006", LoggedInUser, 0, depVotBaseDTO.Chfp, depVotBaseDTO.ChfpDTO.PERSONNEL_NUMBER);
					}
					List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
					TmUserRole UctRole = await employeeService.GetRoleId(UserRolesParam.ContractHolder);

					TmRoleToUserMapping roleUCT = new TmRoleToUserMapping()
					{
						UserId = depVotBaseDTO.Chfp,
						RoleId = UctRole.RoleId,
						IsActive = 1,
						CreatedBy = LoggedInUser?.COMPANY_NUMBER,
						CreatedOn = DateTime.Now
					};
					tmRoleToUsers.Add(roleUCT);

					if (tmRoleToUsers.Any())
					{
						var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
					}
					var response = new TIP_RESULT()
					{
						message = ResponseStatus.success.ToString(),
						status = (int)ResponseStatus.success,
						TResponse = result
					};
					return Ok(response);
				}
				else
				{
					var response = new TIP_RESULT()
					{
						message = "Contract Holder is not assigned",
						status = (int)ResponseStatus.error,
						TResponse = ""
					};
					return Ok(response);
				}
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}
		}

		[Route("GetDeployment/{pirCode}")]
		[HttpGet]
		public async Task<IActionResult> GetDeployment(string pirCode)
		{
			try
			{
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
				var PirData = CryptoExtensions.Decrypt(pirCode);
				if (PirData.StartsWith("PIR-"))
				{
					long PirId = (long)PirData.Split("-").Last().ToInt64();

					if (PirId > 0)
					{
						var result = await depVotService.GetDeployment((long)LoggedInUser.ACTIVE_R_ID, LoggedInUser.COMPANY_NUMBER, PirId);
						var response = new TIP_RESULT()
						{
							message = ResponseStatus.success.ToString(),
							status = (int)ResponseStatus.success,
							TResponse = result
						};
						return Ok(response);
					}
					else
					{
						var response = new TIP_RESULT()
						{
							message = "Deployment Plan data not found",
							status = (int)ResponseStatus.error,
							TResponse = ""
						};
						return Ok(response);
					}
				}
				else
				{
					var response = new TIP_RESULT()
					{
						message = "Deployment Plan data not found",
						status = (int)ResponseStatus.error,
						TResponse = ""
					};
					return Ok(response);
				}
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}

		}

		[Route("GetDeploymentById/{depCode}")]
		[HttpGet]
		public async Task<IActionResult> GetDeploymentById(string depCode)
		{
			try
			{
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
				var DepData = CryptoExtensions.Decrypt(depCode);
				if (DepData.StartsWith("DEP-"))
				{
					long DepId = (long)DepData.Split("-").Last().ToInt64();

					if (DepId > 0)
					{
						var result = await depVotService.GetDeploymentById(DepId);
						var response = new TIP_RESULT()
						{
							message = ResponseStatus.success.ToString(),
							status = (int)ResponseStatus.success,
							TResponse = result
						};
						return Ok(response);
					}
					else
					{
						var response = new TIP_RESULT()
						{
							message = "Deployment Plan data not found",
							status = (int)ResponseStatus.error,
							TResponse = ""
						};
						return Ok(response);
					}
				}
				else
				{
					var response = new TIP_RESULT()
					{
						message = "Deployment Plan data not found",
						status = (int)ResponseStatus.error,
						TResponse = ""
					};
					return Ok(response);
				}
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}

		}

		[Route("GetDeploymentByPirId/{pirCode}")]
		[HttpGet]
		public async Task<IActionResult> GetDeploymentByPirId(string pirCode)
		{
			try
			{
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
				var PirData = CryptoExtensions.Decrypt(pirCode);
				if (PirData.StartsWith("PIR-"))
				{
					long PirId = (long)PirData.Split("-").Last().ToInt64();

					if (PirId > 0)
					{
						var result = await depVotService.GetDeploymentByPirId(PirId);
						var response = new TIP_RESULT()
						{
							message = ResponseStatus.success.ToString(),
							status = (int)ResponseStatus.success,
							TResponse = result
						};
						return Ok(response);
					}
					else
					{
						var response = new TIP_RESULT()
						{
							message = "Deployment Plan data not found",
							status = (int)ResponseStatus.error,
							TResponse = ""
						};
						return Ok(response);
					}
				}
				else
				{
					var response = new TIP_RESULT()
					{
						message = "Deployment Plan data not found",
						status = (int)ResponseStatus.error,
						TResponse = ""
					};
					return Ok(response);
				}
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}

		}

		[Route("DeploymentPlan")]
		[HttpPost]
		public async Task<IActionResult> DeploymentPlan([Bind("")] DepVotDTO depVotDTO)
		{
			try
			{
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
				long PirId = (long)CryptoExtensions.Decrypt(depVotDTO.PirCode).Split("-").Last().ToInt64();
				var result = await depVotService.DeploymentPlan(DepVotDTOMapping(depVotDTO), depVotDTO.Status, PirId);
				var obj = result.Split("-");
				if (depVotDTO.Status.ToUpper() == "S" && result != "")
					await depVotService.SendDeploymentEmail(Convert.ToInt64(depVotDTO.DepId), EmailModules.DEP, "DEV005", LoggedInUser, Convert.ToInt64(obj[1]), depVotDTO.Uctfp, depVotDTO.Chfp);

				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = obj[0]
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}
		}

		[Route("DeleteDeploymentPlan/{id}")]
		[HttpDelete]
		public async Task<IActionResult> DeleteDeploymentPlan(long id)
		{
			try
			{
				var result = await depVotService.DeleteDeploymentPlan(id);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}
		}

		private DepInitiation DepVotBaseDTOMapping(DepVotBaseDTO depVotBase)
		{
			EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
			DepInitiation depInitiation = new DepInitiation()
			{
				Id = depVotBase.Id,
				PirId = (long)CryptoExtensions.Decrypt(depVotBase.PirCode).Split("-").Last().ToInt64(),
				Chfp = depVotBase.Chfp,
				Uctfp = LoggedInUser.COMPANY_NUMBER
			};
			if (depInitiation.Id > 0)
			{
				depInitiation.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
				depInitiation.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
				depInitiation.UpdatedOn = DateTime.Now;
			}
			else
			{
				depInitiation.CreatedBy = LoggedInUser.COMPANY_NUMBER;
				depInitiation.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
				depInitiation.CreatedOn = DateTime.Now;
			}
			return depInitiation;
		}

		private DepVot DepVotDTOMapping(DepVotDTO depVotDTO)
		{
			EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
			DepVot depVot = new DepVot()
			{
				Id = depVotDTO.Id,
				DepId = (long)CryptoExtensions.Decrypt(depVotDTO.DepCode).Split("-").Last().ToInt64(),
				QYear = depVotDTO.QYear,
				DeployedTo = depVotDTO.DeployedTo,
				ScopeCountQtr = depVotDTO.ScopeCountQtr,
				IncrmntlOilGain = depVotDTO.IncrmntlOilGain,
				DefermentAvoidance = depVotDTO.DefermentAvoidance,
				CostSavingUnitQtr = depVotDTO?.CostSavingUnitQtr,
				PowerSaving = depVotDTO?.PowerSaving,
				Co2Reduction = depVotDTO.Co2Reduction,
				TechnologyCost = depVotDTO.TechnologyCost,
				OtherCostQtr = depVotDTO.OtherCostQtr,
				TotalVotQtr = depVotDTO.TotalVotQtr,
				FinalComments = depVotDTO.FinalComments
			};
			if (depVot.Id > 0)
			{
				depVot.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
				depVot.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
				depVot.UpdatedOn = DateTime.Now;
			}
			else
			{
				depVot.CreatedBy = LoggedInUser.COMPANY_NUMBER;
				depVot.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
				depVot.CreatedOn = DateTime.Now;
			}
			if (depVotDTO.Status.ToUpper() == "S")
				depVot.SubmittedOn = DateTime.Now;
			return depVot;
		}


		[Route("GetAllDeploymentforReAssignment/{roleId}")]
		[HttpGet]
		public async Task<IActionResult> GetAllDeploymentforReAssignment(long roleId)
		{
			EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

			try
			{

				var result = await depVotService.GetAllDeploymentforReAssignment(roleId, LoggedInUser.COMPANY_NUMBER);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				return Ok(response);
			}
		}


		[Route("GetCHFPForDeploymentbyId/{id}")]
		[HttpGet]
		public async Task<IActionResult> GetCHFPForDeploymentbyId(long id)
		{
			try
			{
				
				var result = await depVotService.GetCHFPForDeploymentbyId(id);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				return Ok(response);
			}
		}


		[Route("GetUCTFPForDeploymentbyId/{mu}")]
		[HttpGet]
		public async Task<IActionResult> GetUCTFPForDeploymentbyId(string mu)
		{
			try
			{
				
				var result = await depVotService.GetUCTFPForDeploymentbyId(mu);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				return Ok(response);
			}
		}



		[Route("ChangeCHFp")]
		[HttpPost]
		public async Task<IActionResult> ChangeCHFp([Bind("MU,DepId")] postdeployRessign recevingDTO)
		{
			try
			{
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
				var Id = recevingDTO.DepId;
				var previousCHFP = "";
				if (Id > 0)
				{
					DepInitiation dbObj = await depVotService.GetDeploymentReAssignment((long)recevingDTO.DepId);
					previousCHFP = dbObj.Chfp;
                    dbObj.Chfp = recevingDTO.MU;
					var result = await depVotService.UpdateDeploymentReAssignment(dbObj);
					if (result > 0)
					{
                        await depVotService.SendDeploymentEmail(Convert.ToInt64(Id), EmailModules.DEP, "DEV001", LoggedInUser, 0, recevingDTO.MU, previousCHFP);
                        await depVotService.SendDeploymentEmail(Convert.ToInt64(Id), EmailModules.DEP, "DEV002", LoggedInUser, 0, recevingDTO.MU, previousCHFP);

                        var response = new TIP_RESULT()
						{
							message = ResponseStatus.success.ToString(),
							status = (int)ResponseStatus.success,
							TResponse = result
						};
						return Ok(response);
					}
					else
					{
						var response = new TIP_RESULT()
						{
							message = "The Deployment record is not updated",
							status = (int)ResponseStatus.error,
							TResponse = ""
						};
						return Ok(response);
					}
				}
				else
				{
					var response = new TIP_RESULT()
					{
						message = "The Deployment record is not exist",
						status = (int)ResponseStatus.error,
						TResponse = ""
					};
					return Ok(response);

				}
			}
			catch (Exception ex)
			{
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				return Ok(response);
			}
		}


		[Route("ChangeDeployUCT")]
		[HttpPost]
		public async Task<IActionResult> ChangeDeployUCT([Bind("MU,DepId,roleId")] postUCTdeployRessign recevingDTO)
		{
			try
			{
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
				TmUserRole AdminRole = await employeeService.GetRoleId(UserRolesParam.Administrator);
				var previousUCT = "";
				if (AdminRole.RoleId == recevingDTO.roleId)
				{
					DepInitiation dbObj = await depVotService.GetDeploymentReAssignment((long)recevingDTO.DepId);
					previousUCT = dbObj.Uctfp;
                    dbObj.Uctfp = recevingDTO.MU;
					var result = await depVotService.UpdateDeploymentReAssignment(dbObj);
					if (result > 0)
					{
                        await depVotService.SendDeploymentEmail(Convert.ToInt64(recevingDTO.DepId), EmailModules.DEP, "DEV003", LoggedInUser, 0, recevingDTO.MU, previousUCT);
                        await depVotService.SendDeploymentEmail(Convert.ToInt64(recevingDTO.DepId), EmailModules.DEP, "DEV004", LoggedInUser, 0, recevingDTO.MU, previousUCT);
                        var response = new TIP_RESULT()
						{
							message = ResponseStatus.success.ToString(),
							status = (int)ResponseStatus.success,
							TResponse = result
						};
						return Ok(response);
					}
					else
					{
						var response = new TIP_RESULT()
						{
							message = "The Deployment record is not updated",
							status = (int)ResponseStatus.error,
							TResponse = ""
						};
						return Ok(response);
					}
				}
				else
				{
					var response = new TIP_RESULT()
					{
						message = "Oops! Something went wrong on Role",
						status = (int)ResponseStatus.error,
						TResponse = ""
					};
					return Ok(response);

				}
			}
			catch (Exception ex)
			{
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				return Ok(response);
			}
		}




	}
}
