﻿using TIP_API.DTO;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface.Admin;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_Core;
using TIP_CORE;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using TIP_CORE.Entities;
using TIP_BAL.Services;
using TIP_CORE.EntitiesDTO;
using TIP_BAL.Services.Admin;
using TIP_BAL.Interface;
using TIP_Common.Helpers;
//using PDOOTPSMS;

namespace TIP_API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class UserSettingsController : BaseController
    {
        private readonly IUserSettingsService userSettingsService;
        private readonly IUserSettingEFService userSettingEFService;
        private readonly IEmployeeService employeeService;
        ILogger<ExecutionController> logger = null;


        public UserSettingsController(ICommonService _commonService, IUserSettingsService _userSettingsService, IEmployeeService _employeeService, ILogger<ExecutionController> _logger,IUserSettingEFService _userSettingEFService) : base(_commonService)
        {
            userSettingsService = _userSettingsService;
            employeeService = _employeeService;
            logger = _logger;
            this.userSettingEFService = _userSettingEFService;
        }

        #region USER_ROLE

        [Route("GetUserRoles/{onlyActivated}")]
        [HttpGet]
        public async Task<IActionResult> GetUserRoles(bool onlyActivated)
        {
            try
            {
                var result = await userSettingsService.GetUserRoles(onlyActivated);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddUserRole")]
        [HttpPost]
        public async Task<IActionResult> AddUserRole([Bind("")] UserRolesDTO userRoleDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await userSettingsService.AddUserRole(UserRoleDTOMapping(userRoleDTO, LoggedInUser));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateUserRole")]
        [HttpPost]
        public async Task<IActionResult> UpdateUserRole([Bind("")] UserRolesDTO userRoleDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await userSettingsService.UpdateUserRole(UserRoleDTOMapping(userRoleDTO, LoggedInUser));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteUserRole/{roleId}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteUserRole(long roleId)
        {
            try
            {
                var result = await userSettingsService.DeleteUserRole(roleId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private TmUserRole UserRoleDTOMapping(UserRolesDTO userRoleDTO, EmployeeDTO employeeDTO)
        {
            TmUserRole tmUserRole = new TmUserRole()
            {
                RoleId = userRoleDTO.id,
                Code = userRoleDTO.uniqueValue,
                RoleName = userRoleDTO.name,
                IsActive = userRoleDTO.status
            };
            if (tmUserRole.RoleId > 0)
            {
                tmUserRole.UpdatedBy = employeeDTO.COMPANY_NUMBER;
                tmUserRole.UpdatedOn = DateTime.Now;
            }
            else
            {
                tmUserRole.CreatedBy = employeeDTO.COMPANY_NUMBER;
                tmUserRole.CreatedOn = DateTime.Now;
            }

            return tmUserRole;
        }

        #endregion

        [Route("GetUserRoleData")]
        [HttpGet]

        public async Task<IActionResult> GetUserRoleData()
        {
            try
            {
             
                var result = await userSettingsService.GetUserRoledata();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
    
        [Route("GetUsersWithfilter")]
        [HttpGet]
        public async Task<IActionResult> GetUsersWithfilter(string Filter)
        {
            try
            {
                var result = await userSettingsService.GetUsersWithfilter(Filter);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetFFPUsersWithfilter")]
        [HttpGet]
        public async Task<IActionResult> GetFFPUsersWithfilter(string Filter)
        {
            try
            {
                var result = await userSettingsService.GetUsersWithfilter(Filter);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("getUserWithoutUCT")]
        [HttpGet]
        public async Task<IActionResult> getUserWithoutUCT(string Filter)
        {
            try
            {

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await userSettingsService.GetUserWithoutUCTANDLoggedInUser(Filter, LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("getUserWithoutLoggedInUser")]
        [HttpGet]
        public async Task<IActionResult> GetUserWithoutLoggedInUser(string Filter)
        {
            try
            {

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await userSettingsService.GetUserWithoutLoggedInUser(Filter, LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("SaveUserToRoleMapping")]
        [HttpPost]
        public async Task<TIP_RESULT> SaveUserToRoleMapping([FromBody] UserViewData ViewData)
        {
            try
            {
                if (ViewData?.ViewData == null)
                    throw new ArgumentException("User role mapping data is required.");

                if (ViewData.ViewData.selectedUser == null || string.IsNullOrWhiteSpace(ViewData.ViewData.selectedUser.PERSONNEL_NUMBER))
                    throw new ArgumentException("Please select a valid user.");

                if (ViewData.ViewData.selectedRName == null || ViewData.ViewData.selectedRName.Count == 0)
                    throw new ArgumentException("Please select at least one role.");

                for (int i = 0; i < ViewData.ViewData.selectedRName.Count; i++) 
                {
                    ViewData.ViewData.selectedRName[i].Default_R_ID = 0;

                }
                var result = await userSettingsService.SaveUserToRoleMapping(ViewData);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return await Task.FromResult(response);
                //return Ok(response);
            }
            catch (Exception ex)
            {
                logger.LogCritical(ex, "Critical- SaveUserToRoleMapping - UserSettingController" + ex.Message+" - " + AccountHelper.GetWinAuthIPForLogs(HttpContext));

                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return await Task.FromResult(response);
                //return Ok(response);
            }
        }

        [Route("UpdateActiveRole")]
        [HttpGet]
        public async Task<TIP_RESULT> UpdateActiveRole(long Role_ID)
        {
            try
            {
                EmployeeDTO? loggedinuser = GetIdentityOfLoggedInUser();

                bool hasRole = await employeeService.CheckIfUserHasRole(loggedinuser.COMPANY_NUMBER, Role_ID);
                if (hasRole)
                {
                    var result = await userSettingEFService.UpdateActiveRole(loggedinuser.COMPANY_NUMBER,Role_ID);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return await Task.FromResult(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "You do not have access to the current requested role.",
                        status = (int)ResponseStatus.success,
                        TResponse = "AuthorizationError"
                    };
                    return await Task.FromResult(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return await Task.FromResult(response);
            }
        }

        [Route("UpdateActiveRoleByR_C")]
        [HttpGet]
        public async Task<TIP_RESULT> UpdateActiveRoleByR_C(string Role_Code)
        {
            try
            {
                EmployeeDTO? loggedinuser = GetIdentityOfLoggedInUser();

                bool hasRole = await employeeService.CheckIfUserHasRoleByR_C(loggedinuser.COMPANY_NUMBER, Role_Code);
                if (hasRole)
                {
                    var result = await userSettingsService.UpdateActiveRoleByCode(Role_Code);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return await Task.FromResult(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "You do not have access to the current requested role.",
                        status = (int)ResponseStatus.success,
                        TResponse = "AuthorizationError"
                    };

                    return await Task.FromResult(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return await Task.FromResult(response);
            }
        }


        [Route("loadUserRoleMapping")]
        [HttpGet]
        public async Task<TIP_RESULT> loadUserRoleMapping()
        {
            try
            {
                var result = await userSettingsService.loadUserRoleMapping();
                 //var result1 = await userSettingsService.loadUserAssetFocalPoint();

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return await Task.FromResult(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return await Task.FromResult(response);
            }
        }



        [Route("loadApplicationUser")]
        [HttpGet]
        public async Task<TIP_RESULT> loadApplicationUser()
        {
            try
            {
                var result = await userSettingsService.loadApplicationUser();

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return await Task.FromResult(response);
            }
            catch (Exception ex)
            {
                logger.LogCritical(ex, "Critical- loadApplicationUser - UserSettingController" + ex.Message + " - " + AccountHelper.GetWinAuthIPForLogs(HttpContext));

                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return await Task.FromResult(response);
            }
        }



        [Route("loadUserFocalPoint")]
        [HttpGet]
        public async Task<TIP_RESULT> loadUserFocalPoint()
        {
            try
            {

                var result = await userSettingsService.loadUserAssetFocalPoint();

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return await Task.FromResult(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return await Task.FromResult(response);
            }
        }


        [Route("loadUserClusterFocalPoint")]
        [HttpGet]
        public async Task<TIP_RESULT> loadUserClusterFocalPoint()
        {
            try
            {

                var result = await userSettingsService.loadUserClusterFocalPoint();

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return await Task.FromResult(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return await Task.FromResult(response);
            }
        }

        //

        [Route("DeleteUserToRoleMapping")]
        [HttpGet]
        public async Task<TIP_RESULT> DeleteUserToRoleMapping(string UserId)
        {
            try
            {
                var result = await userSettingsService.DeleteUserToRoleMapping(UserId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return await Task.FromResult(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return await Task.FromResult(response);
            }
        }


        [Route("LoadRoleToMenuToElement/{roleID}")]
        [HttpGet]
        public async Task<TIP_RESULT> LoadRoleToMenuToElement(long roleID)
        {
            try
            {
                var result = await userSettingsService.LoadRoleMenuMapping(roleID);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return await Task.FromResult(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return await Task.FromResult(response);
            }
        }

        [Route("saveRoleToMenuTolElement")]
        [HttpPost]
        public async Task<TIP_RESULT> saveRoleToMenuTolElement([Bind("SelectedRl,rolTMMList")] RoleToMenuMappingDTO ViewData)
        {
            try
            {
                var result = await userSettingsService.saveRoleMenuMapping(ViewData);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return await Task.FromResult(response);
                //return Ok(response);
            }
            catch (Exception ex)
            {                
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return await Task.FromResult(response);
                //return Ok(response);
            }
        }
    }
}
