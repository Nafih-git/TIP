﻿using TIP_API.DTO;
using TIP_API.Auth;
using TIP_BusinessLogic.Interface;
using TIP_CORE;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using TIP_BAL.Services;
using TIP_Common.Helpers;
using TIP_CORE.Entities;
using TIP_Core;
using TIP_CORE.EntitiesDTO;
using TIP_BAL.Interface;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;
using TIP_CORE.Admin;
using TIP_Common.Admin;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.StaticFiles;
using TIP_Common;
using System.IO.Compression;
using System.Text;
using Microsoft.EntityFrameworkCore;
using System.Runtime.Serialization;
using System.IO;
using System.Net.Http.Headers;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using System.Net.Mime;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    //[Authorize]
    public class CommonController : BaseController
    {
        private readonly ICommonService commonService;
        private readonly IConfiguration Configuration;
        ILogger<ExecutionController> logger = null;
        private readonly IChallengeService challenge;
        private readonly ICtrService ctrService;
        private readonly IPIRService pirService;
        private readonly IJwtTokenService jwtTokenService;

        public CommonController(ICommonService _commonService, IConfiguration configuration, ILogger<ExecutionController> logger, IChallengeService challenge, ICtrService ctrService, IPIRService pirService, IJwtTokenService jwtTokenService) : base(_commonService)
        {
            commonService = _commonService;
            Configuration = configuration;
            this.logger = logger;
            this.challenge = challenge;
            this.ctrService = ctrService;
            this.pirService = pirService;
            this.jwtTokenService = jwtTokenService;
        }

        [HttpGet("DataMask")]
        public IActionResult DataMask(string type, string data)
        {
            if (type.Equals("E"))
            {
                return Ok(CryptoExtensions.Encrypt(data));
            }
            else if (type.Equals("D"))
            {
                return Ok(CryptoExtensions.Decrypt(data));
            }
            else
            {
                return Ok();
            }

        }


        #region Dynamic Menu
        [HttpGet("GetDynamicMenu")]
        public IActionResult GetDynamicMenu()
        {
            //return Ok(commonService.GetUserMenu());
            return Ok("Okay");
        }

        #endregion

        #region TypeCodeMaster

        [Route("GetMasterDataByType/{Type}")]
        [HttpGet]
        public async Task<IActionResult> GetMasterDataByType(string Type)
        {
            try
            {

                var result = await commonService.GetMasterDataByType(Type);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
        [Route("GetMasterCustmizedDataByType/{Type}")]
        [HttpGet]
        public async Task<IActionResult> GetMasterCustmizedDataByType(string Type)
        {
            try
            {

                var result = await commonService.GetMasterDataByType(Type);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }







        [Route("GetAssetByMU")]
        [HttpGet]
        public async Task<IActionResult> GetAssetByMU()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.GetAssetByMU(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetMasterDataByTypeInternal/{Type}")]
        [HttpGet]
        public async Task<IActionResult> GetMasterDataByTypeInternal(string Type)
        {
            try
            {

                var result = await commonService.GetMasterDataByTypeConfiguration(Type);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetMasterDataByParentId/{pid}")]
        [HttpGet]
        public async Task<IActionResult> GetMasterDataByParentId(long pid)
        {
            try
            {

                var result = await commonService.GetMasterDataByParentId(pid);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetMasterDataByParam2/{Type}")]
        [HttpGet]
        public async Task<IActionResult> GetMasterDataByParam2(string Type)
        {
            try
            {
                var result = await commonService.GetMasterDataByParam2(Type);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetMasterDataByTypeAndParentID/{Type}/{ParentID}")]
        [HttpGet]
        public async Task<IActionResult> GetMasterDataByTypeAndParentID(string Type, int ParentID)
        {
            try
            {
                var result = await commonService.GetMasterDataByTypeAndParentID(Type, ParentID);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetClusterByMUAndAssetID/{AssetID}")]
        [HttpGet]
        public async Task<IActionResult> GetClusterByMUAndAssetID(int AssetID)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.GetClusterByAssetIdAndMU(AssetID, LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetClusterByMU/{assessmentId}")]
        [HttpGet]
        public async Task<IActionResult> GetClusterByMU(long assessmentId)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.GetClusterByMU(LoggedInUser, assessmentId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region Contract
        [Route("GetContractData")]
        [HttpGet]
        public async Task<IActionResult> GetContractData()
        {
            try
            {
                var result = await commonService.GetContractData();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetContractDataByContID/{ContractID}")]
        [HttpGet]
        public async Task<IActionResult> GetContractDataByContID(string ContractID)
        {
            try
            {
                var result = await commonService.GetContractDataByContID(ContractID);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
        #endregion
        #region Type Code Master Page ~ Fazal, Rahim IDAP1X

        [Route("GetMasterDetailByType/{type}")]
        [HttpGet]
        public async Task<IActionResult> GetMasterDetailByType(string type)
        {
            try
            {

                var result = await commonService.GetMasterDetailByType(type);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddSubType")]
        [HttpPost]
        public async Task<IActionResult> AddNewSubType(TypeCodeMasterDetailDTO typeCodeMasterDetailDTO)
        {
            try
            {
                if (typeCodeMasterDetailDTO == null)
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Invalid sub type data.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                if (string.IsNullOrWhiteSpace(typeCodeMasterDetailDTO.name))
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Name is required.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                if (string.IsNullOrWhiteSpace(typeCodeMasterDetailDTO.type))
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Type is required.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.AddNewSubType(TypeCodeDTOMapping(typeCodeMasterDetailDTO, LoggedInUser));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateSubType")]
        [HttpPost]
        public async Task<IActionResult> UpdateNewSubType(TypeCodeMasterDetailDTO typeCodeMasterDetailDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.UpdateNewSubType(TypeCodeDTOMapping(typeCodeMasterDetailDTO, LoggedInUser));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteSubType/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteSubType(long id)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.DeleteSubType(id, LoggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        


        private static string TruncateField(string? value, int maxLength, string fallback = "")
        {
            var text = string.IsNullOrWhiteSpace(value) ? fallback : value.Trim();
            return text.Length <= maxLength ? text : text.Substring(0, maxLength);
        }

        private TypeCodeMaster TypeCodeDTOMapping(TypeCodeMasterDetailDTO typeCodeMasterDetailDTO, EmployeeDTO employeeDTO)
        {
            if (typeCodeMasterDetailDTO == null)
                throw new ArgumentException("Invalid sub type data.");

            TypeCodeMaster typeCodeMaster = new TypeCodeMaster()
            {
                Id = typeCodeMasterDetailDTO.id,
                Name = TruncateField(typeCodeMasterDetailDTO.name, 200),
                Type = TruncateField(typeCodeMasterDetailDTO.type, 5),
                Description = TruncateField(typeCodeMasterDetailDTO.desc, 200),
                Param1 = TruncateField(typeCodeMasterDetailDTO.param1, 10),
                Status = TruncateField(typeCodeMasterDetailDTO.status, 2, "A"),
                IsInternal = false,
                IsEditable = typeCodeMasterDetailDTO.isEditable ?? true,
                ParentId = typeCodeMasterDetailDTO.parentId > 0 ? typeCodeMasterDetailDTO.parentId : null,
                Param2 = TruncateField(typeCodeMasterDetailDTO.param2, 50),
            };
            if (typeCodeMaster.Id > 0)
            {
                typeCodeMaster.UpdatedBy = TruncateField(employeeDTO?.COMPANY_NUMBER, 10);
                typeCodeMaster.UpdatedByRef = TruncateField(employeeDTO?.REFERENCE_INDICATOR, 10, "NA");
                typeCodeMaster.UpdatedOn = DateTime.Now;
            }
            else
            {
                typeCodeMaster.CreatedBy = TruncateField(employeeDTO?.COMPANY_NUMBER, 10, "SYSTEM");
                typeCodeMaster.CreatedByRef = TruncateField(employeeDTO?.REFERENCE_INDICATOR, 10, "NA");
                typeCodeMaster.CreatedOn = DateTime.Now;
            }

            return typeCodeMaster;
        }

        #endregion


        #region windows authentication

        [HttpGet("GetWinAuthAccount")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<Response> GetWinAuthAccount()
        {

            try
            {
                string UserName = AccountHelper.GetWinAuthAccount(HttpContext).Trim();

                if (!string.IsNullOrWhiteSpace(UserName))
                {
                    EmployeeDTO? loggedinuser = commonService.GetIdentityOfLoggedInUser(UserName);
                    if (loggedinuser == null)
                    {
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.error.ToString(),
                            status = (int)ResponseStatus.error,
                            TResponse = 0
                        };
                        return Ok(response);
                    }
                    else
                    {

                        var response = new TIP_RESULT()
                        {
                            message = loggedinuser?.DISPLAY_NAME ?? "",
                            status = (int)ResponseStatus.success,
                            TResponse = 1
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "User Name Not Valid.",
                        status = (int)ResponseStatus.error,
                        TResponse = 0
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [HttpGet("CanACtivateRouteAsync")]
        public IActionResult CanACtivateRouteAsync()
        {
            try
            {
                string UserName = AccountHelper.GetWinAuthAccount(HttpContext).Trim();
                if (!string.IsNullOrWhiteSpace(UserName))
                {
                    EmployeeDTO? loggedinuser = commonService.GetIdentityOfLoggedInUser(UserName);
                    if (loggedinuser == null)
                    {
                        return Ok(false);
                    }
                    else
                    {
                        return Ok(true);
                    }
                }
                return Ok(false);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(false);
            }

        }

        /// <summary>
        /// Issues a JWT after the caller is authenticated (Windows Negotiate and/or existing JWT).
        /// </summary>
        [HttpGet("GetJwtToken")]
        [HttpPost("GetJwtToken")]
        public IActionResult GetJwtToken()
        {
            try
            {
                string userName = AccountHelper.GetWinAuthAccount(HttpContext).Trim();
                if (string.IsNullOrWhiteSpace(userName))
                {
                    return Unauthorized(new TIP_RESULT()
                    {
                        message = "User is not authenticated.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                EmployeeDTO? loggedInUser = commonService.GetIdentityOfLoggedInUser(userName);
                if (loggedInUser == null)
                {
                    return Unauthorized(new TIP_RESULT()
                    {
                        message = "User is not authorized for TIP.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                var roles = new List<string>();
                if (loggedInUser.ACTIVE_R_ID.HasValue && loggedInUser.ACTIVE_R_ID.Value > 0)
                    roles.Add(loggedInUser.ACTIVE_R_ID.Value.ToString());

                var token = jwtTokenService.CreateToken(userName, loggedInUser, roles);
                return Ok(new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = new
                    {
                        accessToken = token.AccessToken,
                        expiresAtUtc = token.ExpiresAtUtc,
                        expiresIn = token.ExpiresInSeconds,
                        tokenType = "Bearer"
                    }
                });
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                });
            }
        }

        /// <summary>
        /// Stateless JWT logout helper for the client. Token invalidation is client-side.
        /// </summary>
        [HttpPost("Logout")]
        [AllowAnonymous]
        public IActionResult Logout()
        {
            return Ok(new TIP_RESULT()
            {
                message = ResponseStatus.success.ToString(),
                status = (int)ResponseStatus.success,
                TResponse = 1
            });
        }

        #endregion

        

        #region  Document download  ~ Fazal, Rahim IDAP1X 

        

        [HttpGet("downloadQueryResponseFiles/{id}/{type}")]
        public async Task<IActionResult> downloadQueryResponseFiles(string id, string type)
        {
            long Id = Convert.ToInt64(id);
            var obj = await commonService.DocumentRepoList(Id, type, false);
            if (obj == null || obj.Count == 0)
                return Ok(new FileContentResult(Array.Empty<byte>(), "application/octet-stream"));

            var filepath = obj.FirstOrDefault().path;
            string res = ResolveDocumentPhysicalPath(filepath);
            var fileName = CryptoExtensions.Decrypt(obj.FirstOrDefault().name);

            // Local/dev: DocumentRepo may still point at NAS while the file was saved under LocalUploadPath
            if (!string.IsNullOrWhiteSpace(fileName) && (string.IsNullOrWhiteSpace(res) || !System.IO.File.Exists(res)))
            {
                try
                {
                    var localRoot = ResolveUploadRootPath();
                    if (!string.IsNullOrWhiteSpace(localRoot))
                    {
                        var localCandidate = Path.Combine(localRoot, fileName);
                        if (System.IO.File.Exists(localCandidate))
                            res = localCandidate;
                    }
                }
                catch
                {
                    // keep original path
                }
            }

            if (fileName != null && System.IO.File.Exists(res))
            {
                var content = await System.IO.File.ReadAllBytesAsync(res);
                var provider = new FileExtensionContentTypeProvider();
                provider.Mappings[".msg"] = "application/vnd.ms-outlook";
                provider.TryGetContentType(fileName, out string contentType);
                contentType ??= "application/octet-stream";
                var response = new FileContentResult(content, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(contentType));
                return Ok(response);
            }

            // Same contract the UI already handles (empty FileContents → existing toast), avoid HTTP 404 console noise
            return Ok(new FileContentResult(Array.Empty<byte>(), "application/octet-stream"));
        }


        [HttpGet("downloadFiles/{cfcode}/{type}")]
        public async Task<IActionResult> downloadFiles(string cfcode, string type)
        {
            long Id;
            if (type != "TTA DD format")
                Id = Convert.ToInt64(CryptoExtensions.Decrypt(cfcode));
            else
                Id = 1;
            var obj = commonService.DocumentRepoList(Id, type, false);
            if (obj.Result.Count == 0)
                return NotFound(new { message = "File is not found." });
            var filepath = obj.Result.FirstOrDefault().path;
            string res = ResolveDocumentPhysicalPath(filepath);
            var fileName = CryptoExtensions.Decrypt(obj.Result.FirstOrDefault().name);
            if (fileName != null && System.IO.File.Exists(res))
            {
                var content = await System.IO.File.ReadAllBytesAsync(res);
                var provider = new FileExtensionContentTypeProvider();
                provider.Mappings[".msg"] = "application/vnd.ms-outlook";
                provider.TryGetContentType(fileName, out string contentType);
                var response = new FileContentResult(content, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(contentType));
                return Ok(response);
            }
            else
            {
                return NotFound(new { message = "file does not exist." });
            }
        }
        [HttpGet("getFilesCount/{cfcode}/{type}")]
        public async Task<IActionResult> getFilesCount(string cfcode, string type)
        {
            long Id = Convert.ToInt64(CryptoExtensions.Decrypt(cfcode));
            var obj = commonService.DocumentRepoList(Id, type, false);
            var response = new TIP_RESULT
            {
                message = "",
                status = 1,
                TResponse = obj.Result.Count()
            };
            return Ok(response);
        }


        [HttpGet("downloadSingleFile")]
        [AllowAnonymous]
        public Task<IActionResult> downloadSingleFileByQuery([FromQuery] string? filepath, [FromQuery] string? filename)
        {
            if (string.IsNullOrWhiteSpace(filepath) || string.IsNullOrWhiteSpace(filename))
            {
                return Task.FromResult<IActionResult>(BadRequest(new { message = "File path and file name are required." }));
            }

            return DownloadSingleFileInternal(filepath, filename);
        }

        [HttpGet("downloadSingleFile/{filepath}/{filename}")]
        [AllowAnonymous]
        public Task<IActionResult> downloadSingleFile(string filepath, string filename)
        {
            return DownloadSingleFileInternal(filepath, filename);
        }

        private async Task<IActionResult> DownloadSingleFileInternal(string filepath, string filename)
        {
            filepath = Uri.UnescapeDataString(filepath ?? string.Empty);
            filename = Uri.UnescapeDataString(filename ?? string.Empty)
                .Replace("\0", string.Empty)
                .Replace("&#x0;", string.Empty, StringComparison.OrdinalIgnoreCase);

            if (string.IsNullOrWhiteSpace(filepath) || string.IsNullOrWhiteSpace(filename))
            {
                return BadRequest(new { message = "File path and file name are required." });
            }

            string res = ResolveDocumentPhysicalPath(filepath);
            var fileName = filename;
            if (string.IsNullOrWhiteSpace(res) || !IsAllowedDownloadPath(res))
            {
                return BadRequest(new { message = "File path is not correct or not accessible." });
            }

            if (fileName != null && System.IO.File.Exists(res))
            {
                var content = await System.IO.File.ReadAllBytesAsync(res);

                var provider = new FileExtensionContentTypeProvider();
                provider.Mappings[".msg"] = "application/vnd.ms-outlook";
                provider.TryGetContentType(fileName, out string contentType);
                contentType ??= "application/octet-stream";
                var response = new FileContentResult(content, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(contentType));
                return Ok(response);
            }

            return NotFound(new { message = "file does not exist." });
        }

        [HttpGet("downloadSRFile/{id}")]
        public async Task<IActionResult> downloadSRFiles(long id)
        {
            if (id <= 0)
            {
                return BadRequest(new { message = "File is not saved yet. Use the uploaded file path to download, or save the form first." });
            }

            var docs = await commonService.GetDocumentsById(id);
            if (docs == null || docs.Count == 0)
            {
                return NotFound(new { message = "No file is found." });
            }

            var doc = docs.First();
            string path = CryptoExtensions.Decrypt(doc.path ?? string.Empty);
            string fileName = CryptoExtensions.Decrypt(doc.name ?? string.Empty);

            if (string.IsNullOrWhiteSpace(fileName))
            {
                return BadRequest(new { message = "File name is empty." });
            }

            if (string.IsNullOrWhiteSpace(path) || !IsAllowedDownloadPath(path))
            {
                return BadRequest(new { message = "File path is not correct or not accessible." });
            }

            if (!System.IO.File.Exists(path))
            {
                return NotFound(new { message = "Physical file does not exist on the server." });
            }

            var content = await System.IO.File.ReadAllBytesAsync(path);
            var provider = new FileExtensionContentTypeProvider();
            provider.Mappings[".msg"] = "application/vnd.ms-outlook";
            provider.TryGetContentType(fileName, out string contentType);
            contentType ??= "application/octet-stream";
            var response = new FileContentResult(content, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(contentType));
            return Ok(response);
        }

        /// <summary>
        /// Allows NAS and configured local upload roots for download.
        /// </summary>
        private bool IsAllowedDownloadPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return false;

            try
            {
                var fullPath = Path.GetFullPath(path);
                if (fullPath.StartsWith(@"\\musnas06\", StringComparison.OrdinalIgnoreCase))
                    return true;

                var root = ResolveUploadRootPath();
                var fullRoot = Path.GetFullPath(root);
                if (!fullRoot.EndsWith(Path.DirectorySeparatorChar) && !fullRoot.EndsWith(Path.AltDirectorySeparatorChar))
                    fullRoot += Path.DirectorySeparatorChar;

                return fullPath.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        #endregion

        #region  Document Upload   
        [Route("UploadActivity")]
        [DisableRequestSizeLimit]
        [HttpPost]
        public async Task<IActionResult> UploadActivity([Bind("")] FileUploadDTO DTO)
        {
            try
            {
                long id = (long)CryptoExtensions.Decrypt(DTO.cfcode).ToInt64();
                if (Request.Form.Files.Any())
                {
                    var formCollection = await Request.ReadFormAsync();

                    foreach (var file in formCollection.Files)
                    {
                        //string EncryptedNASPath = CryptoExtensions.Encrypt(GetNASPath("dev"));
                        //string DecryptedNASPath = CryptoExtensions.Decrypt(EncryptedNASPath);


                        string DecryptedNASPath = string.Empty;
                        if (Configuration["ServerMode"].Equals("Prod"))
                        {
                            DecryptedNASPath = CryptoExtensions.Decrypt(Configuration["EncryptedNASPathS"]);
                        }
                        else
                        {
                            DecryptedNASPath = CryptoExtensions.Decrypt(Configuration["EncryptedNASPathD"]);
                        }



                        string fileExtension = Normalize.parse(System.IO.Path.GetExtension(file.FileName).TrimStart(new char[] { '.' }));
                        string originalFileName = Normalize.parse(file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1));
                        string guidName = Normalize.parse("File-" + Guid.NewGuid().ToString() + DateTime.Today.Second.ToString() + "." + fileExtension);

                        long fileSizeibMbs = file.Length / (1024 * 1024);
                        if (fileSizeibMbs <= 20)
                        {
                            if (!string.IsNullOrEmpty(DecryptedNASPath))
                            {

                                var FinalPath = Normalize.parse(Path.Combine(DecryptedNASPath, guidName));

                                if (CheckerHelper.IsValidName(FinalPath, 0) && FinalPath.StartsWith("\\\\musnas06") && Path.GetFileName(FinalPath) == guidName && (System.IO.Path.IsPathRooted(FinalPath)))
                                {
                                    if (!System.IO.File.Exists(FinalPath))
                                    {
                                        using (Stream fileStream = new FileStream(FinalPath, FileMode.CreateNew))
                                        {
                                            await file.CopyToAsync(fileStream);

                                            if (System.IO.File.Exists(FinalPath))
                                            {
                                                

                                                string MimeType = "";
                                                new FileExtensionContentTypeProvider().TryGetContentType(originalFileName, out MimeType);

                                                string ContentType = file.ContentType;
                                                //TypeCodeMaster activeStatus = await masterDataService.GetTypeCodeByParentAndParam1("DOCS", DocumentStatus.Active.ToString());
                                                EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();
                                                DocumentRepo obj = new DocumentRepo()
                                                {
                                                    LimkType = DTO.type,
                                                    LinkId = id,
                                                    FilePath = guidName,
                                                    CreatedBy = LoggedInUser.COMPANY_NUMBER,
                                                    CreatedOn = DateTime.Now,
                                                    FileName = originalFileName,
                                                    FileType = fileExtension,
                                                    Description = DTO.description,
                                                    MimeType = ContentType,
                                                    IsActive = true,
                                                    IsExternalAccessible = DTO.isEA,
                                                };

                                                var Result = await commonService.AddDocument(obj);

                                            }
                                            else
                                            {
                                                var responses = new TIP_RESULT()
                                                {
                                                    message = "File Not Uploaded",
                                                    status = (int)ResponseStatus.error,
                                                    TResponse = ""
                                                };
                                                return Ok(responses);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        var responses = new TIP_RESULT()
                                        {
                                            message = "File exist with same name, rename and try again.",
                                            status = (int)ResponseStatus.error,
                                            TResponse = ""
                                        };
                                        return Ok(responses);

                                    }
                                }
                                else
                                {
                                    var responses = new TIP_RESULT()
                                    {
                                        message = "Not a valid path or file.",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(responses);

                                }

                            }
                            else
                            {
                                var responses = new TIP_RESULT()
                                {
                                    message = "NASPath not found.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(responses);

                            }
                        }
                        else
                        {
                            var responses = new TIP_RESULT()
                            {
                                message = "File size of " + originalFileName + " is too large. Maximum file size permitted is " + 20 + "Mb",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(responses);

                        }

                    }
                }
                else
                {
                    var responses = new TIP_RESULT()
                    {
                        message = "No files found to upload.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(responses);

                }
                var response = new TIP_RESULT()
                {
                    message = "File Uploaded Successfully",
                    status = (int)ResponseStatus.success,
                    TResponse = ""
                };
                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("FileUpload")]
        [DisableRequestSizeLimit]
        [HttpPost]
        public async Task<IActionResult> FileUpload()
        {
            try
            {

                //if (Request.Form.Files.Any())
                //{
                var formCollection = await Request.ReadFormAsync();

                foreach (var file in formCollection.Files)
                {
                    string DecryptedNASPath = ResolveUploadRootPath();

                    string fileExtension = Normalize.parse(System.IO.Path.GetExtension(file.FileName).TrimStart(new char[] { '.' }));
                    string originalFileName = Normalize.parse(file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1));
                    string guidName = Normalize.parse("File-" + Guid.NewGuid().ToString() + DateTime.Today.Second.ToString() + "." + fileExtension);

                    long fileSizeibMbs = file.Length / (1024 * 1024);
                    if (fileSizeibMbs <= 20)
                    {
                        if (!string.IsNullOrEmpty(DecryptedNASPath))
                        {

                            var FinalPath = Normalize.parse(Path.Combine(DecryptedNASPath, guidName));

                            if (IsAllowedUploadPath(FinalPath, DecryptedNASPath, guidName))
                            {
                                if (!System.IO.File.Exists(FinalPath))
                                {
                                    using (Stream fileStream = new FileStream(FinalPath, FileMode.CreateNew))
                                    {
                                        await file.CopyToAsync(fileStream);

                                        if (System.IO.File.Exists(FinalPath))
                                        {
                                            

                                            string MimeType = "";
                                            new FileExtensionContentTypeProvider().TryGetContentType(originalFileName, out MimeType);

                                            string ContentType = file.ContentType;
                                            //TypeCodeMaster activeStatus = await masterDataService.GetTypeCodeByParentAndParam1("DOCS", DocumentStatus.Active.ToString());
                                            EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();

                                            FileUploadResponse fr = new FileUploadResponse();
                                            fr.filename = originalFileName;
                                            fr.filepath = CryptoExtensions.Encrypt(FinalPath);
                                            fr.fileExtension = fileExtension;
                                            fr.mimeType = ContentType;
                                            fr.status = 1;
                                            fr.Message = "File Uploaded Successfully";
                                            return Ok(fr);


                                        }
                                        else
                                        {
                                            FileUploadResponse fr = new FileUploadResponse();
                                            fr.filename = originalFileName;
                                            fr.filepath = CryptoExtensions.Encrypt(FinalPath);
                                            fr.status = 0;
                                            fr.Message = "Upload Failed!";
                                            return Ok(fr);
                                        }
                                    }
                                }
                                else
                                {
                                    FileUploadResponse fr = new FileUploadResponse();
                                    fr.filename = originalFileName;
                                    fr.filepath = CryptoExtensions.Encrypt(FinalPath);
                                    fr.status = 0;
                                    fr.Message = "File exist with same name, rename and try again.";
                                    return Ok(fr);


                                }
                            }
                            else
                            {
                                FileUploadResponse fr = new FileUploadResponse();
                                fr.filename = originalFileName;
                                fr.filepath = CryptoExtensions.Encrypt(FinalPath);
                                fr.status = 0;
                                fr.Message = "Not a valid path or file.";
                                return Ok(fr);



                            }

                        }
                        else
                        {
                            FileUploadResponse fr = new FileUploadResponse();
                            fr.filename = originalFileName;
                            fr.filepath = "";
                            fr.status = 0;
                            fr.Message = "NASPath not found.";
                            return Ok(fr);


                        }
                    }
                    else
                    {
                        FileUploadResponse fr = new FileUploadResponse();
                        fr.filename = originalFileName;
                        fr.filepath = "";
                        fr.status = 0;
                        fr.Message = "File size of " + originalFileName + " is too large. Maximum file size permitted is " + 20 + "Mb";
                        return Ok(fr);
                    }

                }
               
                FileUploadResponse frr = new FileUploadResponse();
                frr.filename = "";
                frr.filepath = "";
                frr.status = 0;
                frr.Message = "No file was received for upload.";
                return Ok(frr);


            }
            catch (Exception ex)
            {
                FileUploadResponse fr1 = new FileUploadResponse();
                fr1.filename = "";
                fr1.filepath = "";
                fr1.status = 0;
                fr1.Message = ex.Message.ToString();
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(fr1);

            }
        }


        [Route("UploadTTADocs")]
        [DisableRequestSizeLimit]
        [HttpPost]
        public async Task<IActionResult> UploadTTADocs()
        {
            try
            {
                var tta = "1"; var description = "";
                try
                {
                    tta = CryptoExtensions.Decrypt(Request.Form.Where(x => x.Key == "tta").FirstOrDefault().Value);
                }
                catch { }
                try
                {
                    description = Request.Form.Where(x => x.Key == "description").FirstOrDefault().Value;
                }
                catch { }
                var id = Convert.ToInt64(tta);
                var originalFileName = "";
                var type = Request.Form.Where(x => x.Key == "type").FirstOrDefault().Value;
                if (Request.Form.Files.Any())
                {
                    var formCollection = await Request.ReadFormAsync();

                    foreach (var file in formCollection.Files)
                    {
                        //string EncryptedNASPath = CryptoExtensions.Encrypt(GetNASPath("dev"));
                        //string DecryptedNASPath = CryptoExtensions.Decrypt(EncryptedNASPath);


                        string DecryptedNASPath = ResolveUploadRootPath();

                        string fileExtension = Normalize.parse(System.IO.Path.GetExtension(file.FileName).TrimStart(new char[] { '.' }));
                        originalFileName = Normalize.parse(file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1));
                        string guidName = Normalize.parse("File-" + Guid.NewGuid().ToString() + DateTime.Today.Second.ToString() + "." + fileExtension);

                        long fileSizeibMbs = file.Length / (1024 * 1024);
                        if (fileSizeibMbs <= 20)
                        {
                            if (!string.IsNullOrEmpty(DecryptedNASPath))
                            {

                                var FinalPath = Path.Combine(DecryptedNASPath, guidName);

                                if (IsAllowedUploadPath(FinalPath, DecryptedNASPath, guidName))
                                {
                                    if (!System.IO.File.Exists(FinalPath))
                                    {
                                        using (Stream fileStream = new FileStream(FinalPath, FileMode.CreateNew))
                                        {
                                            await file.CopyToAsync(fileStream);

                                            if (System.IO.File.Exists(FinalPath))
                                            {
                                                //returnResponse.Result = 1;
                                                string MimeType = "";
                                                new FileExtensionContentTypeProvider().TryGetContentType(originalFileName, out MimeType);
                                                string ContentType = file.ContentType;
                                                //TypeCodeMaster activeStatus = await masterDataService.GetTypeCodeByParentAndParam1("DOCS", DocumentStatus.Active.ToString());
                                                EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();
                                                if (type != "TTA TC Template" && type != "TTA Other Files")
                                                    commonService.DeleteDocument(id, type);
                                                DocumentRepo obj = new DocumentRepo()
                                                {
                                                    LimkType = type,
                                                    LinkId = id,
                                                    FilePath = CryptoExtensions.Encrypt(FinalPath),
                                                    CreatedBy = LoggedInUser.COMPANY_NUMBER,
                                                    CreatedOn = DateTime.Now,
                                                    FileName = CryptoExtensions.Encrypt(originalFileName),
                                                    FileType = fileExtension,
                                                    Description = description,
                                                    MimeType = ContentType,
                                                    IsActive = true,
                                                    IsExternalAccessible = false,
                                                };
                                                var Result = await commonService.AddDocument(obj);
                                            }
                                            else
                                            {
                                                var responses = new TIP_RESULT()
                                                {
                                                    message = "File Not Uploaded",
                                                    status = (int)ResponseStatus.error,
                                                    TResponse = ""
                                                };
                                                return Ok(responses);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        var responses = new TIP_RESULT()
                                        {
                                            message = "File exist with same name, rename and try again.",
                                            status = (int)ResponseStatus.error,
                                            TResponse = ""
                                        };
                                        return Ok(responses);

                                    }
                                }
                                else
                                {
                                    var responses = new TIP_RESULT()
                                    {
                                        message = "Not a valid path or file.",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(responses);

                                }

                            }
                            else
                            {
                                var responses = new TIP_RESULT()
                                {
                                    message = "NASPath not found.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(responses);

                            }
                        }
                        else
                        {
                            var responses = new TIP_RESULT()
                            {
                                message = "File size of " + originalFileName + " is too large. Maximum file size permitted is " + 20 + "Mb",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(responses);

                        }

                    }
                }
                else
                {
                    var responses = new TIP_RESULT()
                    {
                        message = "No files found to upload.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(responses);

                }
                var response = new TIP_RESULT()
                {
                    message = "File Uploaded Successfully",
                    status = (int)ResponseStatus.success,
                    TResponse = originalFileName
                };
                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        public class FileUploadResponse
        {
            public int status { get; set; }
            public string filename { get; set; }
            public string filepath { get; set; }
            public string fileExtension { get; set; }
            public string mimeType { get; set; }
            public string Message { get; set; }

        }



        #endregion


        #region  Email Template Configuration  ~ Fazal, Rahim IDAP1X 

        [Route("GetEmailKeywordByType/{id}")]
        [HttpGet]
        public async Task<IActionResult> GetEmailKeywordByType(long id)
        {
            try
            {

                var result = await commonService.GetEmailKeywordByType(id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetEmailTemplateConfigByModule/{id}")]
        [HttpGet]
        public async Task<IActionResult> GetEmailTemplateConfigByModule(long id)
        {
            try
            {

                var result = await commonService.GetEmailTemplateConfigByModule(id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddOrUpdateEmailTemplate")]
        [HttpPost]
        public async Task<IActionResult> AddOrUpdateEmailTemplate(EmailTemplateConfigurationDTO emailTemplateConfigurationDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.AddOrUpdateEmailTemplate(EmailTemplateConfigurationDTOMapping(emailTemplateConfigurationDTO, LoggedInUser));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
            return null;
        }

        private EmailTemplateConfiguration EmailTemplateConfigurationDTOMapping(EmailTemplateConfigurationDTO emailTemplateConfigurationDTO, EmployeeDTO employeeDTO)
        {
            EmailTemplateConfiguration emailTemplateConfiguration = new EmailTemplateConfiguration()
            {
                Id = emailTemplateConfigurationDTO.id,
                ModuleId = emailTemplateConfigurationDTO.typeId,
                TemplateName = emailTemplateConfigurationDTO.template,
                MailSubject = emailTemplateConfigurationDTO.subject,
                MailBody = emailTemplateConfigurationDTO.body
            };
            if (emailTemplateConfiguration.Id > 0)
            {
                emailTemplateConfiguration.UpdatedBy = employeeDTO.COMPANY_NUMBER;
                emailTemplateConfiguration.UpdatedOn = DateTime.Now;
            }
            else
            {
                emailTemplateConfiguration.CreatedBy = employeeDTO.COMPANY_NUMBER;
                emailTemplateConfiguration.CreatedOn = DateTime.Now;
            }

            return emailTemplateConfiguration;
        }


        #endregion

        [Route("GetDocLink")]
        [HttpGet]
        public async Task<IActionResult> GetDocLink()
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {
                var result = await commonService.GetDocLink();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                logger.LogCritical("Critical Error - Execution Controller - GetApprovedCtr " + AccountHelper.GetWinAuthIPForLogs(HttpContext) + "- Get Method -" + " Internal Application - " + HttpContext.Connection.RemotePort + " - " + HttpContext.Request.Path + " - " + LoggedInUser.COMPANY_NUMBER + " - " + GetErrorMessage(ex));

                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("GetEmailEsc")]
        [HttpGet]
        public async Task<IActionResult> GetEmailEsc()
        {
            try
            {

                var result = await commonService.GetAllEmailsData();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("UpdateEmailEsc")]
        [HttpPost]
        public async Task<IActionResult> UpdateEmailEsc([Bind("")] EmailEscalationDTO emailEscalationDTO)
        {
            try
            {
                var result = await commonService.UpdateEmailEsc(EmailEscalationDTOMapping(emailEscalationDTO));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
            return null;
        }

        private EmailEscalation EmailEscalationDTOMapping(EmailEscalationDTO emailEscalationDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            EmailEscalation emailEscalation = new EmailEscalation()
            {
                Id = emailEscalationDTO.id,
                EscalEmail = emailEscalationDTO.emailEscal,
                EmailCode = emailEscalationDTO.code,
                Frequency = emailEscalationDTO.type,
                FrequencyNo = emailEscalationDTO.days,
                EscalNo = emailEscalationDTO.escalCount
            };
            if (emailEscalation.Id > 0)
            {
                emailEscalation.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                emailEscalation.UpdatedOn = DateTime.Now;
            }

            return emailEscalation;
        }

        public class ReciveObj
        {
            public string? rle { get; set; }
        }
        public class RoleValidateVM
        {
            public bool isValid { get; set; }
            public string? RoleParam { get; set; }
            public string? CryptedRole { get; set; }
        }

        [HttpPost("CheckIfRoleExist")]
        public async Task<ActionResult> CheckIfRoleExist([Bind("")] ReciveObj rObj)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                string RoleParam = CryptoExtensions.Decrypt(rObj.rle).Split(":")[0];
                long Role = Convert.ToInt64(CryptoExtensions.Decrypt(rObj.rle).Split(":")[1]);

                bool check = await commonService.CheckIfUserHasRole(Role, LoggedInUser.COMPANY_NUMBER);
                if (check)
                {
                    RoleValidateVM roleValidateVM = new RoleValidateVM()
                    {
                        isValid = true,
                        RoleParam = RoleParam
                    };
                    return Ok(roleValidateVM);
                }
                else
                {
                    RoleValidateVM roleValidateVM = new RoleValidateVM()
                    {
                        isValid = false

                    };
                    return Ok(roleValidateVM);
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                throw;
            }

        }

        private string GetNASPath(string env)
        {
            if (env.Equals("Prod"))
                return @"\\musnas06\web_applications\TIP\Production\";

            return @"\\musnas06\web_applications\TIP\Development\";
        }

        /// <summary>
        /// Resolves the upload root: NAS when available, otherwise local Dev folder.
        /// </summary>
        private string ResolveDocumentPhysicalPath(string encryptedStoredPath)
        {
            if (string.IsNullOrWhiteSpace(encryptedStoredPath))
                return string.Empty;

            var decrypted = CryptoExtensions.Decrypt(encryptedStoredPath);
            if (string.IsNullOrWhiteSpace(decrypted))
                return string.Empty;

            if (Path.IsPathRooted(decrypted))
                return decrypted;

            var root = ResolveUploadRootPath();
            return string.IsNullOrWhiteSpace(root)
                ? decrypted
                : Path.Combine(root, decrypted);
        }

        private string ResolveUploadRootPath()
        {
            string configuredNas = string.Empty;
            try
            {
                if (string.Equals(Configuration["ServerMode"], "Prod", StringComparison.OrdinalIgnoreCase))
                    configuredNas = CryptoExtensions.Decrypt(Configuration["EncryptedNASPathS"] ?? string.Empty);
                else
                    configuredNas = CryptoExtensions.Decrypt(Configuration["EncryptedNASPathD"] ?? string.Empty);
            }
            catch
            {
                configuredNas = string.Empty;
            }

            configuredNas = NormalizeUncPath(configuredNas);

            bool useLocal = string.Equals(Configuration["UseLocalFileStorage"], "true", StringComparison.OrdinalIgnoreCase);
            string localPath = Configuration["LocalUploadPath"] ?? string.Empty;

            if (!useLocal && !string.IsNullOrWhiteSpace(configuredNas) && Directory.Exists(configuredNas))
                return configuredNas.EndsWith("\\") ? configuredNas : configuredNas + "\\";

            if (string.IsNullOrWhiteSpace(localPath))
            {
                localPath = Path.Combine(AppContext.BaseDirectory, "App_Data", "Uploads");
            }

            Directory.CreateDirectory(localPath);
            return localPath.EndsWith("\\") ? localPath : localPath + "\\";
        }

        private static string NormalizeUncPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return string.Empty;

            // Fix paths encrypted with doubled separators: \\server\\share\\folder\\
            if (path.StartsWith(@"\\", StringComparison.Ordinal))
            {
                var trimmed = path.TrimStart('\\');
                trimmed = trimmed.Replace(@"\\", @"\");
                return @"\\" + trimmed;
            }

            return path;
        }

        private bool IsAllowedUploadPath(string finalPath, string rootPath, string guidName)
        {
            if (string.IsNullOrWhiteSpace(finalPath) || string.IsNullOrWhiteSpace(rootPath))
                return false;

            try
            {
                // CheckerHelper bans ':' which breaks local Windows drive paths (C:\...).
                // Validate filename separately and ensure the file stays under the upload root.
                if (guidName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
                    return false;

                var fullFile = Path.GetFullPath(finalPath);
                var fullRoot = Path.GetFullPath(rootPath);
                if (!fullRoot.EndsWith(Path.DirectorySeparatorChar) && !fullRoot.EndsWith(Path.AltDirectorySeparatorChar))
                    fullRoot += Path.DirectorySeparatorChar;

                return Path.IsPathRooted(finalPath)
                    && Path.GetFileName(finalPath) == guidName
                    && fullFile.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        [Route("CheckIfPaymentMilestone/{Id}")]
        [HttpGet]
        public async Task<IActionResult> CheckIfPaymentMilestone(int Id)
        {
            bool returnVal = false;
            try
            {


                var result = await commonService.CheckIfPaymentMilestone(Id);
                if (result.Name.Trim().Equals("Percentage Completion"))
                {
                    returnVal = true;
                }
                else
                {
                    returnVal = false;
                }

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = returnVal
                };
                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = returnVal
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetCtrTechConfiguration")]
        [HttpGet]
        public async Task<IActionResult> GetCtrTechConfiguration()
        {
            try
            {

                var result = await commonService.GetCtrTechConfiguration();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetCtrplandetailsByCTRID/{ctrId}/{phase}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrplandetailsByCTRID(string ctrId, string phase)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrId);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    if (Id > 0)
                    {
                        var result = await commonService.GetCtrplandetailsByCtrID(Id, phase);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("AddplanTechnology")]
        [HttpPost]
        public async Task<IActionResult> AddNPlanTech([Bind("")] CtrTechConfigurationDTO ctrTechConfigurationDTO)
        {
            try
            {
                var response = new TIP_RESULT();
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.AddPlanTech(CtrTechConfigurationMapping(ctrTechConfigurationDTO, LoggedInUser));
                if (result == 0)
                {
                     response = new TIP_RESULT()
                    {
                        message = "Phase already exist in this template",
                        status = (int)ResponseStatus.warning,
                        TResponse = result
                    };
                }
                else 
                {
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                }
               
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateplanTechnology")]
        [HttpPost]
        public async Task<IActionResult> UpdatePlanTech([Bind("")] CtrTechConfigurationDTO ctrTechConfigurationDTO)
        {
            try
            {
                var response = new TIP_RESULT();

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.UpdatePlanTech(CtrTechConfigurationMapping(ctrTechConfigurationDTO, LoggedInUser));
                if (result == 0)
                {
                    response = new TIP_RESULT()
                    {
                        message = "Plan already exist in different record",
                        status = (int)ResponseStatus.warning,
                        TResponse = result
                    };
                }
                else
                {
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteplanTechnology/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeletePlanTech(long id)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.DeletePlanTech(id, LoggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
        private CtrTechConfiguration CtrTechConfigurationMapping(CtrTechConfigurationDTO ctrTechConfigurationDTO, EmployeeDTO employeeDTO)
        {
            
            CtrTechConfiguration ctrTechConfiguration = new CtrTechConfiguration()
            {
                Id = ctrTechConfigurationDTO.Id,
                Planneddays = ctrTechConfigurationDTO.planneddays,
                //Sequence = ctrTechConfigurationDTO.sequence,
                PhaseId = ctrTechConfigurationDTO.phaseid,
                StageId = ctrTechConfigurationDTO.stageid,

            };
           
            if (ctrTechConfiguration.Id > 0)
            {
                ctrTechConfiguration.UpdatedBy = employeeDTO.COMPANY_NUMBER;
                ctrTechConfiguration.UpdatedByRef = employeeDTO.REFERENCE_INDICATOR;
                ctrTechConfiguration.UpdatedOn = DateTime.Now;
            }
            else
            {
                ctrTechConfiguration.CreatedBy = employeeDTO.COMPANY_NUMBER;
                ctrTechConfiguration.CreatedByRef = employeeDTO.REFERENCE_INDICATOR;
                ctrTechConfiguration.CreatedOn = DateTime.Now;
            }

            return ctrTechConfiguration;
        }


        [Route("GetKPIConfigurationByYear/{year}")]
        [HttpGet]
        public async Task<IActionResult> GetKPIConfigurationByYear(long year)
        {
            try
            {
                var result = await commonService.GetTechKPIByYear(year);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddKPIConfiguration")]
        [HttpPost]
        public async Task<IActionResult> AddKPIConfiguration([Bind("")] TechKPIList techKPIList)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var year = techKPIList.list.FirstOrDefault().year;
                if (year != null)
                {
                    await commonService.DeleteTechKPI(year.Value);
                    var result = await commonService.AddTechKPI(KPIConfigurationMapping(techKPIList));

                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                var response2 = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,

                };

                return Ok(response2);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("UploadMigratedFiles/{docmoduletype}")]
        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> UploadMigratedFiles(int docmoduletype)
        {
            //docmoduletype 1 = Challenge Registration & 2 = CTR/TTA
            string LimkType = String.Empty;
            string FolderName = String.Empty;

            if (docmoduletype ==1)
            {
                LimkType = "Challenge Details";
                FolderName = "Challenge Attachments";
            }
            else if (docmoduletype == 2)
            {
                LimkType = "CTR Form";
                FolderName = "CTR Attachments";
            }
            else if (docmoduletype == 3)
            {
                LimkType = "PIR Form";
                FolderName = "PIR Attachments";
            }
            else
            {
                return default;
            }
            List<string> ListofChId = new List<string>();
            string DecryptedNASPath = String.Empty;
            if (Configuration["ServerMode"].Equals("Prod"))
            {
                DecryptedNASPath = CryptoExtensions.Decrypt(Configuration["EncryptedNASPathS"]);
            }
            else
            {
                DecryptedNASPath = CryptoExtensions.Decrypt(Configuration["EncryptedNASPathD"]);
            }
          string  DecryptedNASPathForMigration = Path.Combine(DecryptedNASPath, "Migration");


            #region Challenge

            string DecryptedNASPathForSpecificfolder = Path.Combine(DecryptedNASPathForMigration, FolderName);
            string[] dirs = Directory.GetDirectories(DecryptedNASPathForSpecificfolder, "*", SearchOption.TopDirectoryOnly);

            foreach (string dir in dirs)
            {
                long linkid = 0;
                string cHiD = String.Empty;
                if (docmoduletype == 1)
                {
                     cHiD = CreateIdentificationId(1, dir);

                    ChallengeRegistrationDTO challengeObj = await challenge.GetChallengeRegistrationByRefNo(cHiD);
                    if (challengeObj == null) //Check is it manually created challange on Production from Old application
                    {
                        string cHiDwithoutM = cHiD.Substring(0, cHiD.LastIndexOf("-"));
                        ChallengeRegistrationDTO oldchallengeObj = await challenge.GetChallengeRegistrationFromOldTIPRef(cHiDwithoutM);
                        ChallengeRegistrationDTO newchallengeObj = await challenge.GetChallengeRegistrationByRefNo(oldchallengeObj.challengeRef);
                        linkid = newchallengeObj == null ? 0 : newchallengeObj.id;


                    }
                    else
                    {
                        linkid = challengeObj == null ? 0 : challengeObj.id;

                    }

                }
                else if (docmoduletype == 2)
                {
                     cHiD = CreateIdentificationId(2, dir);

                    CtrInitiationDTO dto = await ctrService.GetCtrByRefNo(cHiD);
                    linkid = dto == null ? 0 : dto.Id;
                  
                }
                else if (docmoduletype == 3)
                {
                    cHiD = CreateIdentificationId(3, dir);

                    PirInitiationDTO dto = await pirService.GetPirDataByRefNo(cHiD);
                    linkid = dto == null ? 0 : dto.Id;

                }
                else
                {
                    return default;
                }
                if (linkid > 0)
                {
                 string[] FilesNames = Directory.GetFiles(dir);

                   

                    foreach (var item in FilesNames)
                    {
                      
                  
                        
          


                            string fileExtension = Normalize.parse(System.IO.Path.GetExtension(item).TrimStart(new char[] { '.' }));
                            string originalFileName = Normalize.parse(item.Substring(item.LastIndexOf("\\") + 1));
                            string guidName = Normalize.parse("File-" + Guid.NewGuid().ToString() + DateTime.Today.Second.ToString() + "." + fileExtension);

                           
                                if (!string.IsNullOrEmpty(DecryptedNASPath))
                                {

                                    var FinalPath = Normalize.parse(Path.Combine(DecryptedNASPath, guidName));

                                    if (CheckerHelper.IsValidName(FinalPath, 0) && FinalPath.StartsWith("\\\\musnas06") && Path.GetFileName(FinalPath) == guidName && (System.IO.Path.IsPathRooted(FinalPath)))
                                    {
                                        if (!System.IO.File.Exists(FinalPath))
                                        {
                                        System.IO.File.Move(item, FinalPath);
                                        //await file.CopyToAsync(fileStream);

                                                if (System.IO.File.Exists(FinalPath))
                                                {
                                                    //returnResponse.Result = 1;

                                                    string MimeType = "";
                                                    new FileExtensionContentTypeProvider().TryGetContentType(originalFileName, out MimeType);
                                           
                                               
                                                    DocumentRepo obj = new DocumentRepo()
                                                    {
                                                        LimkType = LimkType,
                                                        LinkId = linkid,
                                                        FilePath = CryptoExtensions.Encrypt(FinalPath),
                                                        
                                                        CreatedBy = "Migrated User",
                                                        CreatedOn = DateTime.Now,
                                                        FileName = CryptoExtensions.Encrypt(originalFileName),
                                                        
                                                        FileType = fileExtension,
                                                        Description = "Migrated  from TPH",
                                                        MimeType = MimeType,
                                                        IsActive = true,
                                                        IsExternalAccessible = false,
                                                    };

                                                    var Result = await commonService.AddDocument(obj);

                                                }
                                                else
                                                {
                                                    var responses = new TIP_RESULT()
                                                    {
                                                        message = "File Not Uploaded",
                                                        status = (int)ResponseStatus.error,
                                                        TResponse = ""
                                                    };
                                                    return Ok(responses);
                                                }
                                            
                                        }
                                        else
                                        {
                                            var responses = new TIP_RESULT()
                                            {
                                                message = "File exist with same name, rename and try again.",
                                                status = (int)ResponseStatus.error,
                                                TResponse = ""
                                            };
                                            return Ok(responses);

                                        }
                                    }
                                    else
                                    {
                                        var responses = new TIP_RESULT()
                                        {
                                            message = "Not a valid path or file.",
                                            status = (int)ResponseStatus.error,
                                            TResponse = ""
                                        };
                                        return Ok(responses);

                                    }

                                }
                                else
                                {
                                    var responses = new TIP_RESULT()
                                    {
                                        message = "NASPath not found.",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(responses);

                                }
                            
                          
                        

                       


   
                          
                    }
                }
                else
                {
                    cHiD = cHiD;
                }
                ListofChId.Add(cHiD);
            }
            return Ok(ListofChId);

            #endregion

        }

        private string CreateIdentificationId(int type, string foldername)
        {
            int intlastindex = foldername.LastIndexOf("\\") + 1;
            int length = foldername.Length - intlastindex;
            foldername = foldername.Substring(intlastindex, length);
            string zerostring = "00000000000000";
            int idzerocount = 6;
            string requestId = String.Empty;
            if (type == 1) // Chanllege Detail
            {
                //	CH-000061-M
                string Prefix = "CH-";
                int Prefixlength = 3;
                int foldercount = foldername.Length;
                int zerocount = idzerocount - foldercount;
                requestId = Prefix + zerostring.Substring(0, zerocount) + foldername + "-M";
            }
            else if (type == 2) // TTA
            {
                //TTA-000136-M

                string Prefix = "TTA-";
                int Prefixlength = 4;
                int foldercount = foldername.Length;
                int zerocount = idzerocount - foldercount;
                requestId = Prefix + zerostring.Substring(0, zerocount) + foldername + "-M";
            }
            else if (type == 3) // PIR
            {
                //PIR-000033-M

                string Prefix = "PIR-";
                int Prefixlength = 4;
                int foldercount = foldername.Length;
                int zerocount = idzerocount - foldercount;
                requestId = Prefix + zerostring.Substring(0, zerocount) + foldername + "-M";
            }
            return requestId;
        }

        private List<TechnologyKpiConfig> KPIConfigurationMapping(TechKPIList techKPIList)
        {
            List<TechnologyKpiConfig> result = new List<TechnologyKpiConfig>();
            List<TechnologyKPIDTO> techKPIDTOList = techKPIList.list;
            foreach (var techKPIDTO in techKPIDTOList)
            {
                TechnologyKpiConfig techKpiConfig = new TechnologyKpiConfig();
                techKpiConfig.Year = techKPIDTO.year;
                techKpiConfig.StatusId = techKPIDTO.statusId.Value;
                techKpiConfig.MaxDays = techKPIDTO.maxdays;
                result.Add(techKpiConfig);
            }
            return result;
        }
    }
}
