﻿using TIP_API.DTO;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface.Admin;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_Core;
using TIP_CORE;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using TIP_CORE.Entities;
using TIP_BAL.Services;
using TIP_CORE.EntitiesDTO;
using TIP_BAL.Services.Admin;
using TIP_BAL.Interface;


namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserSettingEFController : BaseController
    {
        private readonly IUserSettingEFService userSettingEFService;
        private readonly IUserSettingsService userSettingService;

        public UserSettingEFController(ICommonService _commonService, IUserSettingEFService _userSettingsEFService, IUserSettingsService _userSettingService) : base(_commonService)
        {
            userSettingEFService = _userSettingsEFService;
            userSettingService = _userSettingService;
        }
        [Route("GetApplicationUsers")]
        [HttpGet]

        public async Task<IActionResult> GetApplicationUsers()
        {
            try
            {
                var result = await userSettingEFService.GetApplicationUser();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("UpdateFocalPoint")]
        [HttpPost]
        public async Task<IActionResult> UpdateFocalPoint([Bind("")] FocalpointDto DTO)
        {
            try
            {
                var result = await userSettingEFService.UpdateFocalPointLink(DTO);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                UtlAuditTrail obj = new UtlAuditTrail()
                {
                    TableName = "BTM_ASSESSMENT",
                   
                };
                
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }

        [Route("deleteFocalPoint")]
        [HttpPost]
        public async Task<IActionResult> deleteFocalPoint([Bind("userId")] FocalpointDto DTO)
        {
            try
            {
                var result = await userSettingEFService.DeleteFocalPointLink(DTO.userId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
              
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }


        [Route("deleteClusterFocalPoint")]
        [HttpPost]
        public async Task<IActionResult> deleteClusterFocalPoint([Bind("userId")] FocalpointDto DTO)
        {
            try
            {
                var result = await userSettingEFService.DeleteClusterFocalPointLink(DTO.userId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("UpdateCLFocalPoint")]
        [HttpPost]
        public async Task<IActionResult> UpdateCLFocalPoint([FromBody] FocalpointDto DTO)
        {
            try
            {
                var result = await userSettingEFService.UpdateClusterFocalPointLink(DTO);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }


        [Route("GetApplicationFPDetailsDTO")]
        [HttpGet]
        public async Task<TIP_RESULT> GetApplicationFPDetailsDTO()
        {
            try
            {
                var result = await userSettingEFService.GetApplicationFPDetailsDTO();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return await Task.FromResult(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return await Task.FromResult(response);
            }
        }


        [Route("AddExternalSource")]
        [HttpPost]
        public async Task<IActionResult> AddExternalSource([Bind("")] ExternalUserDTO DTO)
        {
            try
            {
                if (DTO == null)
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Invalid request data.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                if (string.IsNullOrWhiteSpace(DTO.emailaddress))
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Email address is required.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                emailSendConfigDTO.moduleId = 217;
                emailSendConfigDTO.templateId = 18;
                emailSendConfigDTO.toRecipients = new List<string>();
                emailSendConfigDTO.toRecipients.Add(DTO.emailaddress.Trim());

                var result = await userSettingService.AddExternal_User(DTO, emailSendConfigDTO);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                UtlAuditTrail obj = new UtlAuditTrail()
                {
                    TableName = "Add External Source",
                  
                };
                
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }


        [Route("GetExternalUser")]
        [HttpGet]
        public async Task<IActionResult> GetExternalUser()
        {
            try
            {
                var result =  await userSettingEFService.GetExternalUser();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("UpdateExternalSource")]
        [HttpPost]
        public async Task<IActionResult> UpdateExternalSource([Bind("")] ExternalUserDTO DTO)
        {
            try
            {
                if (DTO == null)
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Invalid request data.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                if (string.IsNullOrWhiteSpace(DTO.emailaddress))
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Email address is required.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                emailSendConfigDTO.moduleId = 217;
                emailSendConfigDTO.templateId = 18;
                emailSendConfigDTO.toRecipients = new List<string>();
                emailSendConfigDTO.toRecipients.Add(DTO.emailaddress.Trim());

                var result = await userSettingService.AddExternal_User(DTO, emailSendConfigDTO);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                UtlAuditTrail obj = new UtlAuditTrail()
                {
                    TableName = "Update External Source",
                  
                };
                
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetPMRoles")]
        [HttpGet]

        public async Task<IActionResult> GetPMRoles()
        {
            try
            {
                var result = await userSettingEFService.GetPMRoles();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

    }
}
