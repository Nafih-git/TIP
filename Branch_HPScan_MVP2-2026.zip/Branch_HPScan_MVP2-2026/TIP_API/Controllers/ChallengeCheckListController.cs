﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using TIP_API.DTO;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using TIP_BusinessLogic.Interface;
using TIP_Common;
using TIP_Core;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChallengeCheckListController : BaseController
    {
        private readonly ICommonService _commonService;
        private readonly IChallengeCheckListService _challengeCheckListService;
        private readonly IChallengeService _challengeService;
        public ChallengeCheckListController(ICommonService commonService, IChallengeCheckListService challengeCheckListService,IChallengeService challengeService) : base(commonService)
        {
            _commonService = commonService;
            _challengeCheckListService = challengeCheckListService;
            _challengeService = challengeService;
        }

        [Route("GetCheckLists")]
        [HttpGet]
        public async Task<IActionResult> GetCheckLists()
        {
            try
            {
                var result = await _challengeCheckListService.GetCheckLists();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("Question")]
        [HttpPost]
        public async Task<IActionResult> AddOrUpdateChallengeQuestion([FromBody] ChallengeChecklistDTO challengeChecklistDTO)
        {
			try
			{
                if (challengeChecklistDTO == null)
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Invalid question data.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                if (string.IsNullOrWhiteSpace(challengeChecklistDTO.question))
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Question is required.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

				var result = await _challengeCheckListService.AddOrUpdateQuestion(ChallengeDTOMapping(challengeChecklistDTO));
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}
        }

        [Route("DeleteQuestion/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteChallengeQuestion(long id)
        {
			try
			{
				var result = await _challengeCheckListService.DeleteQuestion(id);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}
		}


        [Route("CreateChallenge")]
        [HttpPost]
        public async Task<IActionResult> CreateChallenge([FromBody] CreateChallengeDTO answers)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                if (LoggedInUser == null || string.IsNullOrWhiteSpace(LoggedInUser.COMPANY_NUMBER))
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Logged-in user could not be resolved.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                TypeCodeMaster? DraftStatus = await _commonService.GetMasterDataByParentAndParam1("CT", "D");
                if (DraftStatus == null)
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Draft challenge status (CT/D) was not found.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                if (answers != null && answers.checkList != null && answers.checkList.Count > 0)
                {
                    var companyNumber = AuditField(LoggedInUser.COMPANY_NUMBER, 20, "SYSTEM");
                    var createdByRef = AuditField(LoggedInUser.REFERENCE_INDICATOR, 40, "NA");
                    var linkCreatedByRef = AuditField(LoggedInUser.REFERENCE_INDICATOR, 20, "NA");

                    ChallengeRegistration challenge = new ChallengeRegistration();
                    challenge.Id = 0;
                    challenge.ReferenceNo = "CH/" + answers.assessmentId + "/" + answers.painAreaId;
                    challenge.RequestedBy = companyNumber;
                    challenge.StatusId = DraftStatus.Id;
                    challenge.CreatedByRef = createdByRef;
                    challenge.CreatedBy = companyNumber;
                    challenge.CreatedRoleId = LoggedInUser.ACTIVE_R_ID;
                    challenge.CreatedOn = DateTime.Now;
                    if (answers.assessmentId > 0 && answers.painAreaId > 0)
                    {
                        challenge.AssessmentId = answers.assessmentId;
                        challenge.PainAreaId = answers.painAreaId;
                    }
                    var ChallengeId = await _challengeCheckListService.AddNewChallenge(challenge);
                    if (ChallengeId > 0)
                    {
                        long roleId = LoggedInUser.ACTIVE_R_ID ?? 0;
                        await AddChlFlowHistoryAsync(ChallengeId, DraftStatus.Id, challenge.ReferenceNo + " Drafted", roleId, AuditField(LoggedInUser.DISPLAY_NAME + " Drafted the Challenge", 400, "Drafted"));

                        UtlAuditTrail objA = new UtlAuditTrail()
                        {
                            TableName = "CHALLENGE_REGISTRATIONS",
                            Action = "ADD",
                            ActionBy = companyNumber + " " + (LoggedInUser.DISPLAY_NAME ?? string.Empty),
                            ActionOn = DateTime.Now.ToString("dd/MM/yyyy"),
                        };
                        await commonService.Log(objA);

                        List<ChecklistChallengeLnk> lstLnk = new List<ChecklistChallengeLnk>();

                        foreach (ChallengeChecklistDTO obj in answers.checkList)
                        {
                            var yn = string.IsNullOrWhiteSpace(obj.answer) ? "N" : obj.answer.Trim().ToUpperInvariant();
                            if (yn.Length > 2)
                                yn = yn.Substring(0, 2);

                            ChecklistChallengeLnk checklistChallengeLnk = new ChecklistChallengeLnk();
                            checklistChallengeLnk.Id = 0;
                            checklistChallengeLnk.ChallengeId = ChallengeId;
                            checklistChallengeLnk.ChecklistId = obj.id;
                            checklistChallengeLnk.Yn = yn;
                            checklistChallengeLnk.CreatedByRef = linkCreatedByRef;
                            checklistChallengeLnk.CreatedBy = companyNumber;
                            checklistChallengeLnk.CreatedOn = DateTime.Now;
                            lstLnk.Add(checklistChallengeLnk);
                        }

                        var result = await _challengeCheckListService.AddChallengeCheckListLnks(lstLnk);
                        if (result > 0)
                        {
                            UtlAuditTrail obj = new UtlAuditTrail()
                            {
                                TableName = "CHECKLIST_CHALLENGE_LNK",
                                Action = "ADD",
                                ActionBy = companyNumber + " " + (LoggedInUser.DISPLAY_NAME ?? string.Empty),
                                ActionOn = DateTime.Now.ToString("dd/MM/yyyy"),
                            };
                            await commonService.Log(obj);
                            var response = new TIP_RESULT()
                            {
                                message = ResponseStatus.success.ToString(),
                                status = (int)ResponseStatus.success,
                                TResponse = CryptoExtensions.Encrypt(ChallengeId.ToString())
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "CheckList Challenge Link Registation Failure.",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }


                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Challenge Registation Failure.",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }

                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Answer list cannot be empty.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
        private async Task AddChlFlowHistoryAsync(long challengeId, long statusId, string comments, long currentRoleId, string descInfo)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                if (LoggedInUser == null || currentRoleId <= 0)
                    return;

                ChlFlowHistory obj = new ChlFlowHistory()
                {
                    Id = 0,
                    ChallengeId = challengeId,
                    StatusId = statusId,
                    Comments = comments,
                    RoleId = currentRoleId,
                    UserId = AuditField(LoggedInUser.COMPANY_NUMBER, 40, "SYSTEM"),
                    CreatedOn = DateTime.Now,
                    DescInfo = AuditField(descInfo, 400, "Drafted"),
                };

                await _challengeService.AddChallengeFlowHistory(obj);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private ChecklistChallengeLnk PainAreaDTOMapping(ChallengeChecklistDTO list, EmployeeDTO employeeDTO)
        {
            ChecklistChallengeLnk obj = new ChecklistChallengeLnk()
            {
                ChecklistId = list.id,
                Yn = list.answer
            };
            if (obj.Id > 0)
            {
                obj.UpdatedByRef = employeeDTO.REFERENCE_INDICATOR;
                obj.UpdatedBy = employeeDTO.COMPANY_NUMBER;
                obj.UpdatedOn = DateTime.Now;
            }
            else
            {
                obj.CreatedByRef = employeeDTO.REFERENCE_INDICATOR;
                obj.CreatedBy = employeeDTO.COMPANY_NUMBER;
                obj.CreatedOn = DateTime.Now;
            }

            return obj;
        }

        private static string AuditField(string? value, int maxLength, string fallback)
        {
            var text = string.IsNullOrWhiteSpace(value) ? fallback : value.Trim();
            return text.Length <= maxLength ? text : text.Substring(0, maxLength);
        }

        private ChallengeChecklist ChallengeDTOMapping(ChallengeChecklistDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            var question = obj.question?.Trim() ?? string.Empty;
            if (question.Length > 1000)
                question = question.Substring(0, 1000);

            ChallengeChecklist challengeChecklist = new ChallengeChecklist()
            {
                Id = obj.id,
                Question = question,
                IsActive = true
            };
            if (challengeChecklist.Id > 0)
            {
                challengeChecklist.UpdatedBy = AuditField(LoggedInUser?.COMPANY_NUMBER, 10, "SYSTEM");
                challengeChecklist.UpdatedRef = AuditField(LoggedInUser?.REFERENCE_INDICATOR, 10, "NA");
                challengeChecklist.UpdatedOn = DateTime.Now;
            }
            else
            {
                challengeChecklist.CreatedBy = AuditField(LoggedInUser?.COMPANY_NUMBER, 10, "SYSTEM");
                challengeChecklist.CreatedByRef = AuditField(LoggedInUser?.REFERENCE_INDICATOR, 20, "NA");
                challengeChecklist.CreatedOn = DateTime.Now;
            }
            return challengeChecklist;
        }
    }
}
