﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TIP_API.DTO;
using TIP_BAL.Interface;
using TIP_BAL.Services.Admin;
using TIP_BusinessLogic.Interface;
using TIP_Common;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : BaseController
    {
        private readonly IEmployeeService employeeService;
        public EmployeeController(ICommonService _commonService, IEmployeeService _employeeService) : base(_commonService)
        {
            employeeService = _employeeService;
        }

        [Route("GetByCompanyName")]
        [HttpPost]
        public async Task<IActionResult> GetByMuNumber(string MuNumber)
        {
            try
            {
                var result = await employeeService.getByMuNumber(MuNumber);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddEmployee")]
        [HttpPost]
        public async Task<IActionResult> AddEmployee( [Bind("")] EmployeeDTO DTO)
        {
            try
            {

                var result = await employeeService.AddEmployee(EmployeeDTOMapping(DTO));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateEmployee")]
        [HttpPost]
        public async Task<IActionResult> UpdateEmployee([Bind("")] EmployeeDTO DTO)
        {
            try
            {
                var result = await employeeService.UpdateEmployee(EmployeeDTOMapping(DTO));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteEmployee")]
        [HttpPost]
        public async Task<IActionResult> DeleteEmployee(string DTO)
        {
            try
            {
                var result = await employeeService.DeleteEmployee(DTO);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetCFDH/{subThemeId}")]
        [HttpGet]
        public async Task<IActionResult> GetCFDH(long subThemeId)
        {
            try
            {
                var result = await employeeService.GetCFDH(subThemeId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetEmployeeByRoleId/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetEmployeeByRoleId(long roleid)
        {
            try
            {
                var result = await employeeService.GetEmployeeByRoleId(roleid);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        private TmEmployee EmployeeDTOMapping(EmployeeDTO obj)
        {
            TmEmployee returnObj = new TmEmployee()
            {
                EmployeeName = obj.EMPLOYEE_NAME,
                FirstName = "First Name",
                LastName = "Last Name",
                OfficePhone = "",
                ReferenceIndicator = obj.REFERENCE_INDICATOR,
                EmailAddress  = obj.EMPLOYEE_NAME,
                JobDescription = "",
                LxrefIndicatorN = "",
                EmploymentStatus = "ACTIVE",
                CompanyNumber = obj.COMPANY_NUMBER,
                FullName = "",
                CompnoNameRefindicator = ""
            };

            return returnObj;
        }


       
        #region
        [HttpPost("EncKey")]
        public IActionResult EncKey(string key)
        {

            return Ok(new
            {
                Key = key,
                EncKey = CryptoExtensions.Encrypt(key)
            });
        }
        [HttpPost("DecKey")]
        public IActionResult DecKey(string key)
        {

            return Ok(new
            {
                Key = key,
                EncKey = CryptoExtensions.Decrypt(key)
            });
        }
        #endregion
    }
}
