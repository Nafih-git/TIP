﻿using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net.Mime;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Unicode;
using TIP_API.DTO;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_Common;
using TIP_Common.Admin;
using TIP_Core;
using TIP_CORE.Admin;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using static TIP_Common.Enum.Enum;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using static TIP_DAL.DBConstants;
using Microsoft.Reporting.Map.WebForms.BingMaps;
using Microsoft.AspNetCore.Components.RenderTree;
using Microsoft.AspNetCore.Authorization;
using TIP_BAL.Interface.Admin;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CtrController : BaseController
    {
        private readonly ICtrService ctrService;
        private readonly IEmployeeService employeeService;
        private readonly IUserSettingEFService userSettingEFService;
        private readonly IConfiguration Configuration;
        public CtrController(ICommonService _commonService, ICtrService _ctrService, IEmployeeService _employeeService, IConfiguration configuration,IUserSettingEFService userSettingEF) : base(_commonService)
        {
            ctrService = _ctrService;
            employeeService = _employeeService;
            Configuration = configuration;
            userSettingEFService = userSettingEF;
        }


        [Route("CreateCTR")]
        [HttpPost]
        public async Task<IActionResult> CreateCTR([Bind("")] CtrInitiationDTO ctrInitiation)
        {
            try
            {

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                TypeCodeMaster Status = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.Drafted);

                if (ctrInitiation.MandatoryTP != null)
                {
                    if (ctrInitiation.OtherTP?.Count > 0)
                    {
                        AllPDOUsersDTO find = ctrInitiation.OtherTP.Find(x => x.PERSONNEL_NUMBER.Equals(ctrInitiation.MandatoryTP.PERSONNEL_NUMBER));
                        if (find != null)
                        {
                            var response1 = new TIP_RESULT()
                            {
                                message = "Cannot duplicate mandatory focal point as other focal point.",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response1);
                        }
                    }

                }

                var addObj = await CtrInitiationDTOMapping(ctrInitiation);
                var result = await ctrService.AddCTR(addObj);
                if (result > 0)
                {
                    await AddCtrFlowHistoryAsync(addObj.Id, Status.Id, "", ctrInitiation.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) initiated TTA");

                    List<CtrTrialFp> FocalPoints = new List<CtrTrialFp>();
                    List<CtrProjectMember> projectMembers = new List<CtrProjectMember>();
                    //Proceed with Assigning Roles
                    List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                    TmUserRole TrialFP = await employeeService.GetRoleId(UserRolesParam.TrialFP);


                    if (ctrInitiation.MandatoryTP != null)
                    {
                        CtrTrialFp MTFP = new CtrTrialFp()
                        {
                            Id = 0,
                            CtrId = addObj.Id,
                            Fp = ctrInitiation.MandatoryTP.PERSONNEL_NUMBER,
                            IsMandatory = true
                        };
                        FocalPoints.Add(MTFP);

                        TmRoleToUserMapping roleMTFP = new TmRoleToUserMapping()
                        {
                            UserId = ctrInitiation.MandatoryTP.PERSONNEL_NUMBER,
                            RoleId = TrialFP.RoleId,
                            IsActive = 1,
                            CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                            CreatedOn = DateTime.Now
                        };
                        tmRoleToUsers.Add(roleMTFP);
                    }

                    if (ctrInitiation.OtherTP?.Count > 0)
                    {
                        foreach (AllPDOUsersDTO ofp in ctrInitiation.OtherTP)
                        {
                            CtrTrialFp OTFP = new CtrTrialFp()
                            {
                                Id = 0,
                                CtrId = addObj.Id,
                                Fp = ofp.PERSONNEL_NUMBER,
                                IsMandatory = false
                            };
                            FocalPoints.Add(OTFP);

                            TmRoleToUserMapping roleMTFP = new TmRoleToUserMapping()
                            {
                                UserId = ofp.PERSONNEL_NUMBER,
                                RoleId = TrialFP.RoleId,
                                IsActive = 1,
                                CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                CreatedOn = DateTime.Now
                            };
                            tmRoleToUsers.Add(roleMTFP);
                        }
                    }
                    var mResult = await ctrService.AddTrialFp(FocalPoints);

                    if (ctrInitiation.PMList?.Count > 0)
                    {
                        foreach (ProjectMembers ofp in ctrInitiation.PMList)
                        {
                            CtrProjectMember OTFP = new CtrProjectMember()
                            {
                                Id = 0,
                                CtrId = addObj.Id,
                                Member = ofp.memberMu,
                                RoleId = ofp.roleId,
                                IsReadOnly=ofp.isReadOnly
                            };
                            projectMembers.Add(OTFP);

                            TmRoleToUserMapping roleMTFP = new TmRoleToUserMapping()
                            {
                                UserId = ofp.memberMu,
                                RoleId = ofp.roleId,
                                IsActive = 1,
                                CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                CreatedOn = DateTime.Now
                            };
                            tmRoleToUsers.Add(roleMTFP);
                        }
                    }
                    if (projectMembers.Count > 0)
                    {
                        var pResult = await ctrService.AddProjectMembers(projectMembers);   
                    }

                    //Code Moved outside the projectMembers.count block, because projectMembers are optional.
                    if (mResult > 0)
                    {
                        if (tmRoleToUsers.Any())
                        {
                            var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                        }

                        await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR001");
                    }
                }


                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result

                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };

                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);

                return Ok(response);
            }
        }

        private async Task<CtrInitiation> CtrInitiationDTOMapping(CtrInitiationDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            var isAdd = true;

            CtrInitiation returnObj = new CtrInitiation()
            {
                Id = 0,
                TrialName = obj.CtrTrialTitle,
                StartingYear = obj.CtrYearStart,
                TechId = obj.CtrTechId,
            };
            if (isAdd)
            {

                returnObj.UctFp = LoggedInUser.COMPANY_NUMBER;
                returnObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                returnObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                returnObj.CreatedOn = DateTime.Now;
            }
            else
            {

                returnObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                returnObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                returnObj.UpdatedOn = DateTime.Now;
            }
            return returnObj;
        }

        private async Task<CtrInitiation> CtrFormDTOMapping(CtrInitiationDTO obj, CtrInitiation dbObj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            dbObj.TrialName = obj.CtrTrialTitle;
            dbObj.StartingYear = obj.CtrYearStart;
            dbObj.TechDescription = obj.CtrTechDescription;
            dbObj.TechMaturity = obj.CtrTechMaturity;
            dbObj.TrialObjectives = obj.CtrTrialObjectives;
            dbObj.TrialWorkplaces = obj.CtrTrialWorkplaces;
            dbObj.TrialSelectionCriteria = obj.CtrTrialSelectionCriteria;
            dbObj.BusinessValue = obj.CtrBusinessValue;
            dbObj.ContractingStratergy = obj.CtrContractingStratergy;
            dbObj.NoTrials = obj.noTrials;
            dbObj.Ctrtrialcost = obj.Ctrtrialcst;
            dbObj.Ctrpaymentmilestone = obj.Ctrpaymentmilestone;
            dbObj.Confidential = (obj.CtrConfidential == null) ? false : (obj.CtrConfidential == "Yes") ? true : false;
            dbObj.CurrencyId = obj.currId;
            var isAdd = false;
            if (isAdd)
            {
                dbObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                dbObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                dbObj.CreatedOn = DateTime.Now;
            }
            else
            {
                dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                dbObj.UpdatedOn = DateTime.Now;
            }
            return dbObj;
        }



        [Route("GetAllCtr")]
        [HttpGet]
        public async Task<IActionResult> GetAllCtr()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await ctrService.GetAllCtr(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetAllCtrForTTA")]
        [HttpGet]
        public async Task<IActionResult> GetAllCtrForTTA()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await ctrService.GetAllCtrForTTA(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetDDFormat")]
        [HttpGet]
        public async Task<IActionResult> GetDDFormat()
        {
            try
            {

                var result = await ctrService.GetDDFormat();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }


        [Route("GenerateTTA")]
        [HttpPost]
        public async Task<IActionResult> GenerateTTA([Bind("")] TTAPrint tTAPrint)
        {
            try
            {
                long Id = (long)CryptoExtensions.Decrypt(tTAPrint.cfcode).ToInt64();
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await ctrService.GetTTAPrint(Id, (long)LoggedInUser.ACTIVE_R_ID, LoggedInUser.COMPANY_NUMBER, tTAPrint);
                

                string DecryptedNASPath = string.Empty;
                if (Configuration["ServerMode"].Equals("Prod"))
                {
                    DecryptedNASPath = CryptoExtensions.Decrypt(Configuration["EncryptedNASPathS"]);
                }
                else
                {
                    DecryptedNASPath = CryptoExtensions.Decrypt(Configuration["EncryptedNASPathD"]);
                }
                string guidName = "File-" + Guid.NewGuid().ToString() + DateTime.Today.Second.ToString() + ".pdf";
                var FinalPath = Path.Combine(DecryptedNASPath, guidName);
                System.IO.File.WriteAllBytes(FinalPath, result.FileBytes);
                commonService.DeleteDocument((long)CryptoExtensions.Decrypt(tTAPrint.cfcode).ToInt64(), "TTA");
                commonService.AddDocument(new DocumentRepo { CreatedBy = LoggedInUser.COMPANY_NUMBER, CreatedOn = DateTime.Today, LimkType = "TTA", LinkId = (long)CryptoExtensions.Decrypt(tTAPrint.cfcode).ToInt64(), FileName = CryptoExtensions.Encrypt("TTA_" + (long)CryptoExtensions.Decrypt(tTAPrint.cfcode).ToInt64() + ".pdf"), FilePath = CryptoExtensions.Encrypt(FinalPath) });

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = true
                };
                return Ok(response);

            }

            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }




        [Route("CtrPrint/{ctrCode}/{docType}")]
        [HttpGet]
        public async Task<IActionResult> CtrPrint(string ctrCode, string docType)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    if (Id > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await ctrService.GetAllCtrPrint(Id, (long)LoggedInUser.ACTIVE_R_ID, LoggedInUser.COMPANY_NUMBER, docType);
                        
                        var response = new FileContentResult(result.FileBytes, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(result.Type));
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetAllCTRforReview")]
        [HttpGet]
        public async Task<IActionResult> GetAllCTRforReview()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await ctrService.GetAllCTRforReview(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetCtrFormData/{ctrCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrFormData(string ctrCode, long roleid)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();


                    if (Id > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await ctrService.GetCtrFormData(Id, roleid, LoggedInUser.COMPANY_NUMBER);
                        result.SentbackBy = string.IsNullOrEmpty(result.SentbackBy) ? "" : result.SentbackBy;
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }




            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ValidateVendor")]
        [HttpPost]
        public async Task<IActionResult> ValidateVendor([Bind("ctrCode,vendorCode")] ctrPostingDTO ctr)
        {
            try
            {
                var result = await ctrService.ValidateVendor(ctr.ctrCode, ctr.vendorCode);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateCtr")]
        [HttpPost]
        public async Task<IActionResult> UpdateCtr([Bind("")] CtrInitiationDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster UnderApprovalStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.UnderApproval);
                TypeCodeMaster SubmittedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.Submitted);
                TypeCodeMaster DraftedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.Drafted);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();
                var validateMsg = ctrService.ValidateCTR(Id).Result;
                if (recevingDTO.IsSubmit && !(validateMsg=="OK"))//&& isValid
                {
                    //check for mandatory grids and return if anything is missed.
                    ReturnMessage = validateMsg;
                    ReturnStatus = (int)ResponseStatus.errorinfo;
                }
               else
                {

                    if (Id > 0)
                    {
                        CtrInitiation dbObj = await ctrService.GetById(Id);

                        if (dbObj != null && SubmittedStatus != null && DraftedStatus != null)
                        {
                            //If its submitted, it cannot be changed.
                            if (dbObj.StatusId == SubmittedStatus.Id)
                            {
                                if (recevingDTO.IsSubmit)
                                {
                                    await AddDefaultApprovalListAsync(dbObj.Id);
                                    var submittedResponse = new TIP_RESULT()
                                    {
                                        message = "TTA Submitted Successfully.",
                                        status = (int)ResponseStatus.success,
                                        TResponse = recevingDTO.IdEnc
                                    };
                                    return Ok(submittedResponse);
                                }

                                var returnData = new TIP_RESULT()
                                {
                                    message = "Unathorized Dataentry Revoked.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = recevingDTO.IdEnc

                                };

                                return Ok(returnData);
                            }

                            var addObj = await CtrFormDTOMapping(recevingDTO, dbObj);

                            bool isSentBacktoAPR = false;

                            if (!string.IsNullOrEmpty(recevingDTO.SentbackBy) && recevingDTO.SentbackBy.Equals("APR"))
                            {
                                isSentBacktoAPR = true;
                            }

                            if (recevingDTO.IsSubmit)
                            {
                                addObj.SubmitCount = addObj.SubmitCount + 1;
                                addObj.StatusId = SubmittedStatus.Id;
                                addObj.SubmittedOn = DateTime.Now;
                                addObj.LastReminder = null;
                                addObj.SentbackOn = null;

                                if (isSentBacktoAPR)
                                {
                                    addObj.StatusId = UnderApprovalStatus.Id;
                                }
                                addObj.SentbackBy = "";
                            }
                            else
                            {
                                
                                addObj.SubmittedOn = null;
                            }

                            var result = await ctrService.UpdateCtr(addObj);
                            TmUserRole rl = await userSettingEFService.GetUserRoleById(recevingDTO.CurrentRleId);
                            if (result > 0)
                            {
                                if (recevingDTO.IsSubmit)
                                {
                                    if (isSentBacktoAPR)
                                    {
                                        //Update current Seq level 
                                        List<CtrApprovalList> approvalList = await ctrService.GetApprovalListsByCtrId(addObj.Id);
                                        CtrApprovalList approvalObj =  approvalList.Where(x => x.Seq.Equals(dbObj.CurrentApprovalSeq) && x.Status.Equals(CTRApprovalStatus.SentBack)).SingleOrDefault();
                                        
                                        approvalObj.Status = CTRApprovalStatus.UnderApproval;
                                        approvalObj.Comments = "";
                                        approvalObj.ActionCompletionDate = null;
                                        approvalObj.ActionAssignedDate = DateTime.Now;
                                        var saveResult = await ctrService.UpdateApprovalList(approvalObj);
                                        if (saveResult > 0)
                                        {
                                            await AddCtrFlowHistoryAsync(addObj.Id, UnderApprovalStatus.Id, "", recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " ("+rl.RoleName+") Re Submitted TTA directly to Approver");
                                            ReturnMessage = "TTA Submitted and Sent to Approver Successfully.";
                                            await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR007");
                                        }

                                    }
                                    else
                                    {
                                        ReturnMessage = "TTA Submitted Successfully.";
                                        if (addObj.SubmitCount > 1)
                                        {
                                            await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR003");
                                            await AddCtrFlowHistoryAsync(addObj.Id, SubmittedStatus.Id, "", recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " ("+rl.RoleName+") Re Submitted TTA");
                                        }
                                        else
                                        {
                                            await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR002");
                                            await AddCtrFlowHistoryAsync(addObj.Id, SubmittedStatus.Id, "", recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " ("+rl.RoleName+") Submitted TTA");
                                        }

                                        await AddDefaultApprovalListAsync(addObj.Id);
                                    }

                                }
                                else
                                {
                                    ReturnMessage = "TTA Updated Successfully.";
                                    await AddCtrFlowHistoryAsync(addObj.Id, DraftedStatus.Id, "", recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " ("+rl.RoleName+") updated TTA");
                                }


                               
                                ReturnStatus = (int)ResponseStatus.success;
                                ReturnData = recevingDTO.IdEnc;
                            }
                            else
                            {
                                ReturnMessage = "TTA updating Error.";
                                ReturnStatus = (int)ResponseStatus.error;
                                ReturnData = recevingDTO.IdEnc;
                            }

                        }
                        else
                        {
                            ReturnMessage = "TTA data/status does not exist.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "TTA data does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }
                }
                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateCtrAsUCT")]
        [HttpPost]
        public async Task<IActionResult> UpdateCtrAsUCT([Bind("")] CtrInitiationDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster SubmittedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.Submitted);
                TypeCodeMaster DraftedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.Drafted);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();

                var validate = ctrService.ValidateCTR(Id).Result;

                if (Id > 0)
                {
                    if (!(validate == "OK"))//&& isValid
                    {
                        //check for mandatory grids and return if anything is missed.
                        ReturnMessage = validate;
                        ReturnStatus = (int)ResponseStatus.error;
                    }
                    else
                    {
                        CtrInitiation dbObj = await ctrService.GetById(Id);

                        if (dbObj != null && SubmittedStatus != null && DraftedStatus != null)
                        {

                            var addObj = await CtrFormDTOMapping(recevingDTO, dbObj);

                            var result = await ctrService.UpdateCtr(addObj);
                            if (result > 0)
                            {
                                ReturnMessage = "TTA updated Successfully.";
                                await AddCtrFlowHistoryAsync(addObj.Id, SubmittedStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Updated TTA");

                                ReturnStatus = (int)ResponseStatus.success;
                                ReturnData = recevingDTO.IdEnc;
                            }
                            else
                            {
                                ReturnMessage = "TTA updating Error.";
                                ReturnStatus = (int)ResponseStatus.error;
                                ReturnData = recevingDTO.IdEnc;
                            }

                        }
                        else
                        {
                            ReturnMessage = "TTA data/status does not exist.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }
                    }
                }
                else
                {
                    ReturnMessage = "TTA data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("SendBackCtr")]
        [HttpPost]
        public async Task<IActionResult> SendBackCtr([Bind("")] CtrInitiationDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster SentBackStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.SentBack);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    CtrInitiation dbObj = await ctrService.GetById(Id);

                    if (dbObj != null && SentBackStatus != null)
                    {

                        var addObj = await CtrFormDTOMapping(recevingDTO, dbObj);
                        addObj.StatusId = SentBackStatus.Id;
                        addObj.SentbackOn = DateTime.Now;
                        addObj.LastReminder = null;
                        addObj.SubmittedOn = null;
                        addObj.SentbackBy = "UCT";

                        var result = await ctrService.UpdateCtr(addObj);
                        if (result > 0)
                        {
                            await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR005", recevingDTO.Comment);

                            ReturnMessage = "TTA Sent back successfully.";
                            await AddCtrFlowHistoryAsync(addObj.Id, SentBackStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Sent back TTA to Trial Fp");

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "TTA updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "TTA data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "TTA data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("SendEmailReminder")]
        [HttpPost]
        public async Task<IActionResult> SendEmailReminder([Bind("")] emailReminder emailReminder)
        {
            try
            {
                var result = ctrService.SendEmailReminderToVendor(emailReminder);
                var response = new TIP_RESULT()
                {
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("SendEmailDDFormat")]
        [HttpPost]
        public async Task<IActionResult> SendEmailDDFormat([Bind("")] DDFormat ddFormat)
        {
            try
            {
                var result = ctrService.SendEmailDDFormatToVendor(ddFormat);
                var response = new TIP_RESULT()
                {
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("SendTCFormatFile")]
        [HttpPost]
        public async Task<IActionResult> SendTCFormatFile([Bind("")] TcTemplate tcFormat)
        {
            try
            {
                var result = ctrService.SendEmailTCTemplateToVendor(tcFormat);
                var response = new TIP_RESULT()
                {
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }




        [Route("SendTTAFile")]
        [HttpPost]
        public async Task<IActionResult> SendTTAFile([Bind("")] DDFormat tcFormat)
        {
            try
            {
                var result = ctrService.SendEmailTTAToVendor(tcFormat);
                var response = new TIP_RESULT()
                {
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("SendEmailTCTemplate")]
        [HttpPost]
        public async Task<IActionResult> SendEmailTCTemplate([Bind("")] TcTemplate Format)
        {
            try
            {
                var result = ctrService.SendEmailTCTemplateToVendor(Format);
                var response = new TIP_RESULT()
                {
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetAllTTATCFiles")]
        [HttpGet]
        public async Task<IActionResult> GetAllTTATCFiles()
        {
            try
            {
                var result = await commonService.GetDocumentsByLinkType("TTA TC Template");
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAllTTAOtherFiles/{cfcode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllTTAOtherFiles(string cfcode)
        {
            try
            {
                long id = Convert.ToInt64(CryptoExtensions.Decrypt(cfcode));
                var result = await commonService.GetAllFilesByLinkId(id, "TTA Other Files", false);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ShelveCtr")]
        [HttpPost]
        public async Task<IActionResult> ShelveCtr([Bind("")] CtrInitiationDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;
            try
            {
                TypeCodeMaster ShelvedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.Shelved);
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();

                if (Id > 0)
                {
                    CtrInitiation dbObj = await ctrService.GetById(Id);

                    if (dbObj != null && ShelvedStatus != null)
                    {
                        var addObj = await CtrFormDTOMapping(recevingDTO, dbObj);
                        addObj.StatusId = ShelvedStatus.Id;
                        var result = await ctrService.UpdateCtr(addObj);
                        if (result > 0)
                        {
                            ReturnMessage = "TTA Shelved successfully.";
                            await AddCtrFlowHistoryAsync(addObj.Id, ShelvedStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Shelved TTA");
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "TTA shelving Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }
                    }
                    else
                    {
                        ReturnMessage = "TTA data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "TTA data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteCtr")]
        [HttpPost]
        public async Task<IActionResult> DeleteCtr([Bind("")] CtrInitiationDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster DeleteStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.Deleted);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    CtrInitiation dbObj = await ctrService.GetById(Id);

                    if (dbObj != null && DeleteStatus != null)
                    {

                        var addObj = await CtrFormDTOMapping(recevingDTO, dbObj);
                        addObj.StatusId = DeleteStatus.Id;

                        var result = await ctrService.UpdateCtr(addObj);
                        if (result > 0)
                        {
                            ReturnMessage = "TTA Deleted successfully.";
                            await AddCtrFlowHistoryAsync(addObj.Id, DeleteStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Deleted TTA");

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "TTA delete Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "TTA data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "TTA data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("RevertDeletedCtr")]
        [HttpPost]
        public async Task<IActionResult> RevertDeletedCtr([Bind("")] CtrInitiationDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster SubmitStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.Submitted);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    CtrInitiation dbObj = await ctrService.GetById(Id);

                    if (dbObj != null && SubmitStatus != null)
                    {

                        var addObj = await CtrFormDTOMapping(recevingDTO, dbObj);
                        addObj.StatusId = SubmitStatus.Id;

                        var result = await ctrService.UpdateCtr(addObj);
                        if (result > 0)
                        {
                            ReturnMessage = "TTA successfully Reived from deletion .";
                            await AddCtrFlowHistoryAsync(addObj.Id, SubmitStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Reverted Deletion of TTA");

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "TTA revert deletion  Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "TTA data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "TTA data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        #region CTR Additional Solutions

        private async Task<CtrAdditionalSolution> CtrAdditionalSolutionDTOMapping(CtrAdditionalSolutionDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            var isAdd = true;

            CtrAdditionalSolution returnObj = new CtrAdditionalSolution()
            {
                Id = 0,
                // SERIAL_NUMBER is DB-generated; empty string would be sent and break ValueGeneratedOnAdd.
                SerialNumber = string.IsNullOrWhiteSpace(obj.SerialNumber) ? null : obj.SerialNumber,
                SolutionTitle = obj.SolutionTitle,
                Remarks = obj.Remarks
            };
            if (isAdd)
            {
                returnObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                returnObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                returnObj.CreatedOn = DateTime.Now;
            }

            return returnObj;
        }

        [Route("CreateAddionalSolutions")]
        [HttpPost]
        public async Task<IActionResult> CreateAddionalSolutions([Bind("")] CtrAdditionalSolutionDTO ctrAdditionalSolution)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrAdditionalSolution.CtrCode);
                long CtrId = (long)IdData.Split("-").Last().ToInt64();

                var addObj = await CtrAdditionalSolutionDTOMapping(ctrAdditionalSolution);
                addObj.CtrId = CtrId;
                var result = await ctrService.AddAdditionalSolution(addObj);

                if (result > 0)
                {
                    EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                    UtlAuditTrail obj = new UtlAuditTrail()
                    {
                        TableName = "CTR_ADDITIONAL_SOLUTIONS",
                        Action = "ADD",
                        ActionBy = LoggedInUser.COMPANY_NUMBER + " " + LoggedInUser.REFERENCE_INDICATOR,
                        ActionOn = DateTime.Now.ToString("dd/MM/yyyy"),
                        Description = JsonSerializer.Serialize(ctrAdditionalSolution),
                        //Id =addObj.Id,
                    };

                }

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result

                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetAllAdditionalSolution/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllAdditionalSolution(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                long CtrId = (long)IdData.Split("-").Last().ToInt64();

                var result = await ctrService.GetAllAdditionalSolution(CtrId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAdditionalSolutionFormData/{ctrASId}")]
        [HttpGet]
        public async Task<IActionResult> GetAdditionalSolutionFormData(long ctrASId)
        {
            try
            {

                if (ctrASId != 0)
                {
                    var result = await ctrService.GetAdditionalSolutionFormData(ctrASId);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Additional Solution data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateAdditionalSolution")]
        [HttpPost]
        public async Task<IActionResult> UpdateAdditionalSolution([Bind("")] CtrAdditionalSolutionDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                if (recevingDTO.Id > 0)
                {
                    CtrAdditionalSolution dbObj = await ctrService.GetAdditionalSolutionById(recevingDTO.Id);

                    if (dbObj != null)
                    {
                        dbObj.SolutionTitle = recevingDTO.SolutionTitle;
                        dbObj.Remarks = recevingDTO.Remarks;

                        var result = await ctrService.UpdateAdditionalSolution(dbObj);
                        if (result > 0)
                        {
                            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                            UtlAuditTrail obj = new UtlAuditTrail()
                            {
                                TableName = "CTR_ADDITIONAL_SOLUTIONS",
                                Action = "UPDATE",
                                ActionBy = LoggedInUser.COMPANY_NUMBER + " " + LoggedInUser.REFERENCE_INDICATOR,
                                ActionOn = DateTime.Now.ToString("dd/MM/yyyy"),
                                Description = JsonSerializer.Serialize(recevingDTO),
                                //Id =addObj.Id,
                            };
                            ReturnMessage = "Additional Solution Updated Successfully.";
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.Id;
                        }
                        else
                        {
                            ReturnMessage = "Additional Solution updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.Id;
                        }

                    }
                    else
                    {
                        ReturnMessage = "Additional Solution data does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.Id;
                    }

                }
                else
                {
                    ReturnMessage = "Additional Solution data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.Id;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteAdditionalSolution/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteAdditionalSolution(long id)
        {
            try
            {


                var result = await ctrService.DeleteAdditionalSolution(id, GetIdentityOfLoggedInUser());

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }

        private async Task AddCtrFlowHistoryAsync(long ctrId, long statusId, string comments, long currentRoleId, string descInfo)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                if (currentRoleId <= 0)
                {
                    TmUserRole uctRole = await employeeService.GetRoleId(UserRolesParam.UCT);
                    currentRoleId = uctRole.RoleId;
                }
                else
                {
                    TmUserRole role = await employeeService.GetRoleId(currentRoleId);
                    if (role == null)
                    {
                        TmUserRole uctRole = await employeeService.GetRoleId(UserRolesParam.UCT);
                        currentRoleId = uctRole.RoleId;
                    }
                }

                if (!string.IsNullOrEmpty(descInfo) && descInfo.Length > 200)
                {
                    descInfo = descInfo[..200];
                }

                CtrFlowHistory obj = new CtrFlowHistory()
                {
                    Id = 0,
                    CtrId = ctrId,
                    StatusId = statusId,
                    Comments = comments,
                    RoleId = currentRoleId,
                    UserId = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    DescInfo = descInfo,
                };

                var result = await ctrService.AddCtrFlowHistory(obj);

            }
            catch (Exception)
            {
                throw;
            }
        }


        [Route("GetAllFlowHistory/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllFlowHistory(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                long CtrId = (long)IdData.Split("-").Last().ToInt64();

                var result = await ctrService.GetAllFlowHistory(CtrId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAllFlowHistoryDetail/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllFlowHistoryDetail(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                long CtrId = (long)IdData.Split("-").Last().ToInt64();

                var result = await ctrService.GetAllFlowHistoryDetail(CtrId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region Approval List

        private async Task AddDefaultApprovalListAsync(long ctrId)
        {
            try
            {
                CtrInitiation dbObj = await ctrService.GetById(ctrId);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                List<CtrApprovalList> lst = new List<CtrApprovalList>();

                TypeCodeMaster? HoT = await commonService.GetMasterDataByParentAndParam1(TypeCodes.Configuration, "HNT");

                EmployeeDTO? LM = await employeeService.getByMuNumber(dbObj.CreatedBy);

                lst.Add(new CtrApprovalList()
                {
                    CtrId = ctrId,
                    JobTitle = "Head of New Technology",
                    JobCode = "HNT",
                    Status = "D",
                    Seq = 1,
                    ActionRequiredBy = (HoT != null && HoT.Param2 != null) ? HoT.Param2 : "",
                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    CreatedByRef = LoggedInUser?.REFERENCE_INDICATOR,
                }); ;

                lst.Add(new CtrApprovalList()
                {
                    CtrId = ctrId,
                    JobTitle = "Line Manager",
                    JobCode = "LM",
                    Status = "D",
                    Seq = 2,
                    ActionRequiredBy = (LM != null && !string.IsNullOrEmpty(LM.SUPERVISOR_ID)) ? LM.SUPERVISOR_ID : "",
                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    CreatedByRef = LoggedInUser?.REFERENCE_INDICATOR,
                });

                lst.Add(new CtrApprovalList()
                {
                    CtrId = ctrId,
                    JobTitle = "Technology Expert / SME",
                    JobCode = "TL",
                    Status = "D",
                    Seq = 0,
                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    CreatedByRef = LoggedInUser?.REFERENCE_INDICATOR,
                });

                lst.Add(new CtrApprovalList()
                {
                    CtrId = ctrId,
                    JobTitle = "CFDH",
                    JobCode = "CFDH",
                    Status = "D",
                    Seq = 0,
                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    CreatedByRef = LoggedInUser?.REFERENCE_INDICATOR,
                });

                lst.Add(new CtrApprovalList()
                {
                    CtrId = ctrId,
                    JobTitle = "Deployment Contract Owner",
                    JobCode = "DCO",
                    Status = "D",
                    Seq = 0,
                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    CreatedByRef = LoggedInUser?.REFERENCE_INDICATOR,
                });

                if (ctrService.GetAllApprovalListByCtrId(ctrId).Result.Count() == 0)
                {
                    var result = await ctrService.AddDefaultApprovalList(lst);
                }


            }
            catch (Exception)
            {
                throw;
            }
        }

        [Route("GetAdJobswithFilter")]
        [HttpGet]
        public async Task<IActionResult> GetAdJobswithFilter(string Filter)
        {
            try
            {
                var result = await ctrService.GetAdJobswithFilter(Filter);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAllApprovalListforCtr/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllApprovalListforCtr(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                long CtrId = (long)IdData.Split("-").Last().ToInt64();

                var result = await ctrService.GetAllApprovalListByCtrId(CtrId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetApprovalListFormData/{id}")]
        [HttpGet]
        public async Task<IActionResult> GetApprovalListFormData(long id)
        {
            try
            {

                if (id != 0)
                {
                    var result = await ctrService.GetApprovalListFormData(id);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Additional Solution data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("AddUpdateCtrApproval")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateCtrApproval([Bind("")] CtrApprovalListDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                var IdData = CryptoExtensions.Decrypt(recevingDTO.CtrCode);
                long CtrId = (long)IdData.Split("-").Last().ToInt64();
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                TmUserRole UCTRole = await employeeService.GetRoleId(UserRolesParam.UCT);

                CtrInitiation ctrObj = await ctrService.GetById(CtrId);
                TypeCodeMaster UnderApproval = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.UnderApproval);

                if (ctrObj.StatusId.Equals(UnderApproval.Id))
                {
                    if (recevingDTO.Id > 0)
                    {
                        var ur = await ctrService.GetAllApprovalListByCtrId(CtrId);
                        var ulst = ur.Where(x => x.Seq > 0 && x.Id != recevingDTO.Id && x.UsrRle.Equals(recevingDTO.ActionBy.PERSONNEL_NUMBER));
                        if (ulst != null && ulst.Count() > 0)
                        {
                            long distinctCount = ulst.Select(x => x.ActionRequiredBy).Distinct().Count();
                            if (ulst.Count() == distinctCount)
                            {
                                var r2 = new TIP_RESULT()
                                {
                                    message = "Approvers cannot be duplicated.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(r2);
                            }
                        }

                        if (recevingDTO.Seq < ctrObj.CurrentApprovalSeq)
                        {
                            var rs1 = new TIP_RESULT()
                            {
                                message = "Cannot update record with sequence less than the current sequence = " + ctrObj.CurrentApprovalSeq,
                                status = (int)ResponseStatus.error,
                                TResponse = ""

                            };
                            return Ok(rs1);
                        }
                        else if (recevingDTO.Seq > ctrObj.CurrentApprovalSeq)
                        {
                            var result = await ctrService.GetAllApprovalListByCtrId(CtrId);
                            var dataset2 = result.Where(x => x.Seq > 0);
                            if (dataset2 != null && dataset2.Count() > 0)
                            {
                                long max = dataset2.Where(x => x.Id != recevingDTO.Id).Max(x => x.Seq);

                                if (recevingDTO.Seq > (max + 1))
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Please create approval seq with " + (max + 1) + " before updating record to  " + recevingDTO.Seq,
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""

                                    };
                                    return Ok(rs1);
                                }

                            }
                        }
                    }
                    else
                    {
                        var ur = await ctrService.GetAllApprovalListByCtrId(CtrId);
                        var ulst = ur.Where(x => x.Seq > 0 && x.UsrRle.Equals(recevingDTO.ActionBy.PERSONNEL_NUMBER));
                        if (ulst != null && ulst.Count() > 0)
                        {
                            long distinctCount = ulst.Select(x => x.ActionRequiredBy).Distinct().Count();
                            if (ulst.Count() == distinctCount)
                            {
                                var r2 = new TIP_RESULT()
                                {
                                    message = "Approvers cannot be duplicated.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(r2);
                            }
                        }

                        if (recevingDTO.Seq < ctrObj.CurrentApprovalSeq)
                        {
                            var rs1 = new TIP_RESULT()
                            {
                                message = "Cannot create record with sequence less than the current sequence = " + ctrObj.CurrentApprovalSeq,
                                status = (int)ResponseStatus.error,
                                TResponse = ""

                            };
                            return Ok(rs1);
                        }
                        else if (recevingDTO.Seq > ctrObj.CurrentApprovalSeq)
                        {
                            var result = await ctrService.GetAllApprovalListByCtrId(CtrId);
                            var dataset2 = result.Where(x => x.Seq > 0);
                            if (dataset2 != null && dataset2.Count() > 0)
                            {
                                long max = dataset2.Max(x => x.Seq);

                                if (recevingDTO.Seq > (max + 1))
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Please create approval seq with " + (max + 1) + " before creating " + recevingDTO.Seq,
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""

                                    };
                                    return Ok(rs1);
                                }
                            }
                        }
                    }


                }

                if (recevingDTO.Id > 0)
                {
                    CtrApprovalList dbObj = await ctrService.GetApprovalListById(recevingDTO.Id);
                    string approverBeforeChange = dbObj.ActionRequiredBy;
                    if (dbObj != null)
                    {
                        var DefaultJobCodes = new string[] { "HNT", "LM", "TL", "CFDH", "DCO" };

                        if (!DefaultJobCodes.Contains(dbObj.JobCode))
                        {
                            dbObj.JobTitle = recevingDTO.JobTitle;
                        }

                        dbObj.Seq = recevingDTO.Seq;
                        dbObj.ActionRequiredBy = recevingDTO.ActionBy.PERSONNEL_NUMBER;

                        if (ctrObj.StatusId.Equals(UnderApproval.Id))
                            dbObj.Status = CTRApprovalStatus.UnderApproval;
                        else
                            dbObj.Status = CTRApprovalStatus.Drafted;



                        var result = await ctrService.UpdateApprovalList(dbObj);
                        if (result > 0)
                        {
                            if (ctrObj.StatusId.Equals(UnderApproval.Id))
                            {
                                //Proceed with Assigning Roles
                                List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                                TmUserRole CTRApprover = await employeeService.GetRoleId(UserRolesParam.CTRApprover);

                                TmRoleToUserMapping newRtU = new TmRoleToUserMapping()
                                {
                                    UserId = recevingDTO.ActionBy.PERSONNEL_NUMBER,
                                    RoleId = CTRApprover.RoleId,
                                    IsActive = 1,
                                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now
                                };
                                tmRoleToUsers.Add(newRtU);

                                if (tmRoleToUsers.Any())
                                {
                                    var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                                }

                                await AddCtrFlowHistoryAsync(ctrObj.Id, ctrObj.StatusId, "", UCTRole.RoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Updated Approver : " + dbObj.ActionRequiredBy + " to Seq : " + dbObj.Seq);
                                if (ctrObj.CurrentApprovalSeq.Equals(dbObj.Seq))
                                {
                                    //email to new approver
                                    await ctrService.SendReassignEmail(ctrObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR019", dbObj.ActionRequiredBy, "", LoggedInUser.DISPLAY_NAME);

                                    if (!approverBeforeChange.Equals(dbObj.ActionRequiredBy))
                                    {
                                        //email to old approver
                                        await ctrService.SendReassignEmail(ctrObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR018", "", approverBeforeChange, LoggedInUser.DISPLAY_NAME);
                                    }
                                }

                            }

                            ReturnMessage = "TTA approval updated Successfully.";
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.Id;
                        }
                        else
                        {
                            ReturnMessage = "TTA approval updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.Id;
                        }

                    }
                    else
                    {
                        ReturnMessage = "TTA approval data not found.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.Id;
                    }

                }
                else
                {


                    var ApprovalList = await ctrService.GetAllApprovalListByCtrId(CtrId);

                    var DefaultJobTitle = new string[] { "Head of New Technology", "Line Manager", "Technology Expert / SME", "CFDH", "Deployment Contract Owner" };
                    var ToLowerArray = Array.ConvertAll(DefaultJobTitle, d => d.ToLower());

                    if (ApprovalList != null && ApprovalList.Count == 15)
                    {
                        ReturnMessage = "You have reached the maximum number of approvals allowed. MAX = 15";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = "";
                    }
                    else if (ToLowerArray.Contains(recevingDTO.JobTitle.ToLower().Trim()))
                    {
                        ReturnMessage = "Job title cannot be duplicated with default job titles";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = "";
                    }
                    else
                    {

                        CtrApprovalList newObj = new CtrApprovalList()
                        {
                            Seq = recevingDTO.Seq,
                            CtrId = CtrId,
                            JobTitle = recevingDTO.JobTitle,
                            ActionRequiredBy = recevingDTO.ActionBy.PERSONNEL_NUMBER,
                            CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                            CreatedOn = DateTime.Now,
                            CreatedByRef = LoggedInUser?.REFERENCE_INDICATOR
                        };

                        if (ctrObj.StatusId.Equals(UnderApproval.Id))
                            newObj.Status = CTRApprovalStatus.UnderApproval;
                        else
                            newObj.Status = CTRApprovalStatus.Drafted;

                        var result = await ctrService.AddCtrApprovalList(newObj);
                        if (result > 0)
                        {
                            if (ctrObj.StatusId.Equals(UnderApproval.Id))
                            {
                                //Proceed with Assigning Roles
                                List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                                TmUserRole CTRApprover = await employeeService.GetRoleId(UserRolesParam.CTRApprover);

                                TmRoleToUserMapping newRtU = new TmRoleToUserMapping()
                                {
                                    UserId = recevingDTO.ActionBy.PERSONNEL_NUMBER,
                                    RoleId = CTRApprover.RoleId,
                                    IsActive = 1,
                                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now
                                };
                                tmRoleToUsers.Add(newRtU);

                                if (tmRoleToUsers.Any())
                                {
                                    var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                                }

                                await AddCtrFlowHistoryAsync(ctrObj.Id, ctrObj.StatusId, "", UCTRole.RoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Added Approver : " + newObj.ActionRequiredBy + " to Seq : " + newObj.Seq);
                                if (ctrObj.CurrentApprovalSeq.Equals(newObj.Seq))
                                    await ctrService.SendReassignEmail(ctrObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR019", newObj.ActionRequiredBy, "", LoggedInUser.DISPLAY_NAME);
                            }

                            ReturnMessage = "TTA approval added Successfully.";
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = result;
                        }
                        else
                        {
                            ReturnMessage = "TTA approval added Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = "";
                        }
                    }
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteCtrApprovalList/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteCtrApprovalList(long id)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = "";

            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                TypeCodeMaster UnderApproval = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.UnderApproval);
                CtrApprovalList dbObj = await ctrService.GetApprovalListById(id);

                if (dbObj != null)
                {
                    CtrInitiation ctrObj = await ctrService.GetById(dbObj.CtrId);
                    var deleteduser = await employeeService.getByMuNumber(dbObj.ActionRequiredBy);
                    TmUserRole UCTRole = await employeeService.GetRoleId(UserRolesParam.UCT);

                    if (ctrObj.StatusId.Equals(UnderApproval.Id))
                    {
                        var allApproval = await ctrService.GetAllApprovalListByCtrId(dbObj.CtrId);

                        if (dbObj.Seq < ctrObj.CurrentApprovalSeq)
                        {
                            var rs1 = new TIP_RESULT()
                            {
                                message = "Cannot delete seq less than current seq = " + ctrObj.CurrentApprovalSeq,
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(rs1);
                        }
                        else if (dbObj.Seq > ctrObj.CurrentApprovalSeq)
                        {

                            var SameSeqCount = allApproval.Where(x => x.Seq.Equals(dbObj.Seq));
                            if (SameSeqCount.Count() > 1)
                            {

                                var r1 = await ctrService.DeleteCtrApprovalList(id);
                                if (r1 > 0)
                                {
                                    await AddCtrFlowHistoryAsync(ctrObj.Id, ctrObj.StatusId, "", UCTRole.RoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Deleted Approver : " + deleteduser.DISPLAY_NAME);
                                    await ctrService.SendReassignEmail(ctrObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR018", "", dbObj.ActionRequiredBy, LoggedInUser.DISPLAY_NAME);
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Approval list record deleted successfully.",
                                        status = (int)ResponseStatus.success,
                                        TResponse = r1
                                    };
                                    return Ok(rs1);
                                }
                                else
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Delete Failure",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(rs1);
                                }

                            }
                            else
                            {
                                var checkIfHigherLevelExist = allApproval.Where(x => x.Seq > dbObj.Seq);
                                if (checkIfHigherLevelExist.Count() > 0)
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Please add a record to seq " + dbObj.Seq + " then delete this record",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(rs1);
                                }
                                else
                                {
                                    var r1 = await ctrService.DeleteCtrApprovalList(id);
                                    if (r1 > 0)
                                    {
                                        await AddCtrFlowHistoryAsync(ctrObj.Id, ctrObj.StatusId, "", UCTRole.RoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Deleted Approver : " + deleteduser.DISPLAY_NAME);
                                        await ctrService.SendReassignEmail(ctrObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR018", "", dbObj.ActionRequiredBy, LoggedInUser.DISPLAY_NAME);
                                        var rs1 = new TIP_RESULT()
                                        {
                                            message = "Approval list record deleted successfully.",
                                            status = (int)ResponseStatus.success,
                                            TResponse = r1
                                        };
                                        return Ok(rs1);
                                    }
                                    else
                                    {
                                        var rs1 = new TIP_RESULT()
                                        {
                                            message = "Delete Failure",
                                            status = (int)ResponseStatus.error,
                                            TResponse = ""
                                        };
                                        return Ok(rs1);
                                    }
                                }
                            }



                        }
                        else if (ctrObj.CurrentApprovalSeq.Equals(dbObj.Seq))
                        {
                            //dataset1 = get all current seq and see if there are any UA, if there are any, then can delete. if nothing is there
                            // then see if next level exist
                            var dataset1 = allApproval.Where(x => x.Id != dbObj.Id && x.Seq.Equals(dbObj.Seq)
                            && x.StatusCode.Equals(CTRApprovalStatus.UnderApproval));

                            if (dataset1.Count() > 0)
                            {
                                var r1 = await ctrService.DeleteCtrApprovalList(id);
                                if (r1 > 0)
                                {
                                    await AddCtrFlowHistoryAsync(ctrObj.Id, ctrObj.StatusId, "", UCTRole.RoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Deleted Approver : " + deleteduser.DISPLAY_NAME);
                                    await ctrService.SendReassignEmail(ctrObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR018", "", dbObj.ActionRequiredBy, LoggedInUser.DISPLAY_NAME);
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Approval list record deleted successfully.",
                                        status = (int)ResponseStatus.success,
                                        TResponse = r1
                                    };
                                    return Ok(rs1);
                                }
                                else
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Delete Failure",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(rs1);
                                }
                            }
                            else
                            {
                                var nextSeqData = allApproval.Where(x => x.Seq > ctrObj.CurrentApprovalSeq);

                                if (nextSeqData.Count() > 0)
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Please add a record to current seq " + dbObj.Seq + " then delete this record",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(rs1);
                                }
                                else
                                {

                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Removing this record is not allowed since it is the last approver, please add another approver for the same seq before removing this record.",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(rs1);

                                   
                                }
                            }
                        }
                        else
                        {
                            var rs1 = new TIP_RESULT()
                            {
                                message = "Delete not validated.",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(rs1);
                        }
                    }
                    else
                    {
                        var r1 = await ctrService.DeleteCtrApprovalList(id);
                        var rs1 = new TIP_RESULT()
                        {
                            message = "Approval list record deleted successfully.",
                            status = (int)ResponseStatus.success,
                            TResponse = r1
                        };
                        return Ok(rs1);

                        
                    }


                }
                else
                {
                    var rs1 = new TIP_RESULT()
                    {
                        message = "TTA approval data not found.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(rs1);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("SendForApproval")]
        [HttpPost]
        public async Task<IActionResult> SendForApproval([Bind("ctrCode,CurrentRleId")] ctrPostingDTO ctr)
        {
            string ctrCode = ctr.ctrCode; long CurrentRleId = Convert.ToInt64(ctr.CurrentRleId);
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                var IdData = CryptoExtensions.Decrypt(ctrCode);
                long CtrId = (long)IdData.Split("-").Last().ToInt64();

                if (CtrId != 0)
                {
                    var result = await ctrService.GetAllApprovalListByCtrId(CtrId);

                    var dataset = result.Where(x => x.Seq.Equals(0) && x.ActionRequiredBy != null);
                    if (dataset != null && dataset.Count() > 0)
                    {
                        var r1 = new TIP_RESULT()
                        {
                            message = "Records with Seq 0 cannot contain approver. Delete record, or assign approver",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(r1);
                    }

                    var dataset3 = result.Where(x => x.Seq.Equals(0) && x.ActionRequiredBy == null);
                    if (dataset3 != null && dataset3.Count() == result.Count())
                    {
                        var r1 = new TIP_RESULT()
                        {
                            message = "There should be at least one approver.",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(r1);
                    }

                    var dataset2 = result.Where(x => x.Seq > 0);
                    if (dataset2 != null && dataset2.Count() > 0)
                    {
                        long index = 1;
                        long max = dataset2.Max(x => x.Seq);

                        foreach (var x in dataset2.DistinctBy(x => x.Seq).OrderBy(x => x.Seq))
                        {
                            if (index.Equals(x.Seq))
                            {
                                index++;
                            }
                            else
                            {
                                var r1 = new TIP_RESULT()
                                {
                                    message = "Sequence should be in proper order.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(r1);
                            }
                        }
                    }

                    if (dataset2 != null && dataset2.Count() > 0)
                    {
                        long distinctCount = dataset2.Select(x => x.ActionRequiredBy).Distinct().Count();
                        if (dataset2.Count() != distinctCount)
                        {
                            var r2 = new TIP_RESULT()
                            {
                                message = "Approvers cannot be duplicated.",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(r2);
                        }
                    }

                    //Proceed with Assigning Roles
                    List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                    TmUserRole CTRApprover = await employeeService.GetRoleId(UserRolesParam.CTRApprover);
                    foreach (var x in dataset2)
                    {
                        TmRoleToUserMapping newRtU = new TmRoleToUserMapping()
                        {
                            UserId = x.UsrRle,
                            RoleId = CTRApprover.RoleId,
                            IsActive = 1,
                            CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                            CreatedOn = DateTime.Now
                        };
                        tmRoleToUsers.Add(newRtU);
                    }

                    if (tmRoleToUsers.Any())
                    {
                        var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);

                        if (empRoles > 0)
                        {
                            CtrInitiation dbObj = await ctrService.GetById(CtrId);
                            TypeCodeMaster UnderApproval = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.UnderApproval);

                            bool firstRoundofApprovals = false;

                            if (dbObj.CurrentApprovalSeq == 0)
                            {
                                firstRoundofApprovals = true;
                                dbObj.CurrentApprovalSeq = 1;
                            }
                            else
                            {
                                firstRoundofApprovals = false;
                            }
                            dbObj.StatusId = UnderApproval.Id;
                            dbObj.UpdatedBy = LoggedInUser?.COMPANY_NUMBER;
                            dbObj.UpdatedByRef = LoggedInUser?.REFERENCE_INDICATOR;
                            dbObj.UpdatedOn = DateTime.Now;

                            var r2 = await ctrService.UpdateCtr(dbObj);
                            if (r2 > 0)
                            {
                                await ctrService.UpdateCtrAprovalList(CtrId, dbObj.CurrentApprovalSeq, firstRoundofApprovals);
                                await ctrService.SendCTREmail(CtrId, EmailModules.CTR_FRONT_END_LOADING, "CTR007");

                                await AddCtrFlowHistoryAsync(CtrId, UnderApproval.Id, "", CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Sent TTA for Approval.");

                                var response = new TIP_RESULT()
                                {
                                    message = "TTA sent for approval successfully.",
                                    status = (int)ResponseStatus.success,
                                    TResponse = r2
                                };
                                return Ok(response);
                            }
                            else
                            {
                                var response = new TIP_RESULT()
                                {
                                    message = "TTA Update error.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(response);
                            }

                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "TTA Approval role creation error.",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }


                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA Update error.",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }

                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ResetCtrApproval")]
        [HttpPost]
        public async Task<IActionResult> ResetCtrApproval([Bind("ctrCode,CurrentRleId")] ctrPostingDTO ctr)
        {
            string ctrCode = ctr.ctrCode; long CurrentRleId = Convert.ToInt64(ctr.CurrentRleId);
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                var IdData = CryptoExtensions.Decrypt(ctrCode);
                long CtrId = (long)IdData.Split("-").Last().ToInt64();

                if (CtrId != 0)
                {
                    CtrInitiation dbObj = await ctrService.GetById(CtrId);
                    if (dbObj != null)
                    {
                        var result = await ctrService.ResetCtrApproval(CtrId);
                        if (result > 0)
                        {
                            await AddDefaultApprovalListAsync(CtrId);
                            dbObj.CurrentApprovalSeq = 0;
                            await ctrService.UpdateCtr(dbObj);
                        }


                        var response = new TIP_RESULT()
                        {
                            message = "TTA Approval Reset Successfully",
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var r1 = new TIP_RESULT()
                        {
                            message = "TTA data/status does not exist.",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(r1);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region Approval Sequence

        [Route("RejectCtr")]
        [HttpPost]
        public async Task<IActionResult> RejectCtr([Bind("")] CtrInitiationDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster RejectStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.Rejected);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    CtrInitiation dbObj = await ctrService.GetById(Id);

                    if (dbObj != null && RejectStatus != null)
                    {

                        var addObj = await CtrFormDTOMapping(recevingDTO, dbObj);
                        addObj.StatusId = RejectStatus.Id;


                        var result = await ctrService.UpdateCtr(addObj);
                        if (result > 0)
                        {
                            await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR008", recevingDTO.Comment);
                            ReturnMessage = "TTA Rejected successfully.";
                            await AddCtrFlowHistoryAsync(addObj.Id, RejectStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Approver) Rejected TTA");

                            CtrApprovalList approvalObj = await ctrService.GetApprovalListBySeq(addObj.CurrentApprovalSeq, addObj.Id, LoggedInUser.COMPANY_NUMBER);
                            approvalObj.Status = CTRApprovalStatus.Rejected;
                            approvalObj.Comments = recevingDTO.Comment;
                            approvalObj.ActionCompletionDate = DateTime.Now;
                            await ctrService.UpdateApprovalList(approvalObj);

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "TTA reject error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "TTA data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "TTA data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("SendbackCtrfromApprover")]
        [HttpPost]
        public async Task<IActionResult> SendbackCtrfromApprover([Bind("")] CtrInitiationDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster SentBack = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.SentBack);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    CtrInitiation dbObj = await ctrService.GetById(Id);

                    if (dbObj != null && SentBack != null)
                    {

                        var addObj = await CtrFormDTOMapping(recevingDTO, dbObj);
                        addObj.StatusId = SentBack.Id;
                        addObj.SentbackOn = DateTime.Now;
                        addObj.LastReminder = null;
                        addObj.SubmittedOn = null;
                        addObj.SentbackBy = "APR";
                        var result = await ctrService.UpdateCtr(addObj);
                        if (result > 0)
                        {
                            ReturnMessage = "TTA Send back successfully.";
                            await AddCtrFlowHistoryAsync(addObj.Id, SentBack.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Approver) Sent back TTA to Trial Fp");

                            CtrApprovalList approvalObj = await ctrService.GetApprovalListBySeq(addObj.CurrentApprovalSeq, addObj.Id, LoggedInUser.COMPANY_NUMBER);
                            approvalObj.Status = CTRApprovalStatus.SentBack;
                            approvalObj.Comments = recevingDTO.Comment;
                            approvalObj.ActionCompletionDate = DateTime.Now;
                            await ctrService.UpdateApprovalList(approvalObj);

                            await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR009", recevingDTO.Comment);

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "TTA Send back error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "TTA data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "TTA data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ApproveCtr")]
        [HttpPost]
        public async Task<IActionResult> ApproveCtr([Bind("")] CtrInitiationDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster UnderApprovalStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.UnderApproval);
                TypeCodeMaster ApprovalStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.CTRStatus, CTRStatus.Approved);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    CtrInitiation dbObj = await ctrService.GetById(Id);

                    if (dbObj != null && UnderApprovalStatus != null && ApprovalStatus != null)
                    {
                        var addObj = await CtrFormDTOMapping(recevingDTO, dbObj);

                        List<CtrApprovalList> allApprovalOnSameSeq = await ctrService.GetApprovalListBySeq(dbObj.CurrentApprovalSeq, addObj.Id);
                        //Check if there is no more approavls on same seq
                        if (allApprovalOnSameSeq.Where(x => x.ActionRequiredBy != LoggedInUser.COMPANY_NUMBER && x.Status.Equals(CTRApprovalStatus.UnderApproval)).Count() == 0)
                        {
                            //check if there is next level approval
                            List<CtrApprovalList> allSeqs = await ctrService.GetApprovalListsByCtrId(addObj.Id);
                            if (allSeqs.Where(x => x.Seq == dbObj.CurrentApprovalSeq + 1).Count() > 0)
                            {
                                //Update current Seq level 
                                CtrApprovalList approvalObj = await ctrService.GetApprovalListBySeq(dbObj.CurrentApprovalSeq, addObj.Id, LoggedInUser.COMPANY_NUMBER);
                                approvalObj.Status = CTRApprovalStatus.Approved;
                                approvalObj.Comments = recevingDTO.Comment;
                                approvalObj.ActionCompletionDate = DateTime.Now;
                                var saveResult = await ctrService.UpdateApprovalList(approvalObj);
                                if (saveResult > 0)
                                {
                                    List<CtrApprovalList> seqToUpdate = allSeqs.Where(x => x.Seq == dbObj.CurrentApprovalSeq + 1).ToList();
                                    seqToUpdate.ForEach((z) =>
                                    {
                                        z.ActionAssignedDate = DateTime.Now;
                                        z.Comments = "";
                                    });
                                    var saveNextLevelResult = await ctrService.UpdateApprovalList(seqToUpdate);
                                    if (saveNextLevelResult > 0)
                                    {
                                        addObj.CurrentApprovalSeq = dbObj.CurrentApprovalSeq + 1;
                                        var ctrResult = await ctrService.UpdateCtr(addObj);
                                        if (ctrResult > 0)
                                        {
                                            ReturnMessage = "TTA approved successfully.";
                                            await AddCtrFlowHistoryAsync(addObj.Id, ApprovalStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Approver) with Seq " + dbObj.CurrentApprovalSeq + " approved TTA");
                                            //Send New Level email;
                                            await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR007");
                                            //Approved Email
                                            await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR011N", employee: LoggedInUser);
                                        }
                                    }

                                }

                            }
                            // no next level, so this is the final level
                            else
                            {
                                //Update Approval Seq 
                                CtrApprovalList approvalObj = await ctrService.GetApprovalListBySeq(dbObj.CurrentApprovalSeq, addObj.Id, LoggedInUser.COMPANY_NUMBER);
                                approvalObj.Status = CTRApprovalStatus.Approved;
                                approvalObj.Comments = recevingDTO.Comment;
                                approvalObj.ActionCompletionDate = DateTime.Now;
                                var saveResult = await ctrService.UpdateApprovalList(approvalObj);
                                if (saveResult > 0)
                                {
                                    addObj.StatusId = ApprovalStatus.Id;
                                    var ctrResult = await ctrService.UpdateCtr(addObj);
                                    if (ctrResult > 0)
                                    {
                                        ReturnMessage = "TTA approved successfully.";
                                        await AddCtrFlowHistoryAsync(addObj.Id, ApprovalStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Approver) with Seq " + dbObj.CurrentApprovalSeq + " approved TTA completely");
                                        //Approved Email
                                        await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR011", employee: LoggedInUser);
                                        //Fully Approved Email
                                        await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR012", employee: LoggedInUser);
                                    }
                                }
                            }
                        }
                        //if some one else on same seq
                        else
                        {
                            //Update Approval Seq 
                            CtrApprovalList approvalObj = await ctrService.GetApprovalListBySeq(addObj.CurrentApprovalSeq, addObj.Id, LoggedInUser.COMPANY_NUMBER);
                            approvalObj.Status = CTRApprovalStatus.Approved;
                            approvalObj.Comments = recevingDTO.Comment;
                            approvalObj.ActionCompletionDate = DateTime.Now;
                            var saveResult = await ctrService.UpdateApprovalList(approvalObj);
                            if (saveResult > 0)
                            {
                                ReturnMessage = "TTA approved successfully.";
                                await AddCtrFlowHistoryAsync(addObj.Id, UnderApprovalStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Approver) with Seq " + dbObj.CurrentApprovalSeq + " approved TTA");

                                //Approved Email
                                await ctrService.SendCTREmail(addObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR011", employee: LoggedInUser);
                            }
                        }

                        ReturnStatus = (int)ResponseStatus.success;
                        ReturnData = recevingDTO.IdEnc;
                    }
                    else
                    {
                        ReturnMessage = "TTA update error.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = "";
                    }

                }
                else
                {
                    ReturnMessage = "TTA data/status does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = "";
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        #endregion

        #region Reassignment

        [Route("GetAllCTRforReAssignment/{CurrentRole}")]
        [HttpGet]
        public async Task<IActionResult> GetAllCTRforReAssignment(long CurrentRole)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                TmUserRole Role = await employeeService.GetRoleId(CurrentRole);
                if (Role.Param.Equals(UserRolesParam.Administrator))
                {
                    var result = await ctrService.GetAllCTRforReAssignmentAdmin(LoggedInUser.COMPANY_NUMBER);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else if (Role.Param.Equals(UserRolesParam.UCT))
                {
                    var result = await ctrService.GetAllCTRforReAssignmentUCT(LoggedInUser.COMPANY_NUMBER);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ChangeUctFp")]
        [HttpPost]
        public async Task<IActionResult> ChangeUctFp([Bind("")] CtrUctChangeDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {


                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.CtrCode);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    CtrInitiation dbObj = await ctrService.GetById(Id);
                    List<CtrTrialFp> trialFp = await ctrService.GetAllCtrTrialFpbyCtrId(Id);

                    if (dbObj != null && !string.IsNullOrEmpty(recevingDTO.NewUctFp.PERSONNEL_NUMBER))
                    {
                        if (dbObj.UctFp.Equals(recevingDTO.NewUctFp.PERSONNEL_NUMBER))
                        {
                            ReturnMessage = "New Technology Advisor cannot be the same as Current Technology Advisor";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.CtrCode;

                        }
                        else if (trialFp != null && trialFp.Where(x => recevingDTO.NewUctFp.PERSONNEL_NUMBER.Equals(x.Fp)).Count() > 0)
                        {
                            ReturnMessage = "New Technology Advisor cannot be the same as any Trial Fp";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.CtrCode;

                        }
                        else
                        {
                            var current = dbObj.UctFp;
                            dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                            dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                            dbObj.UpdatedOn = DateTime.Now;
                            dbObj.UctFp = recevingDTO.NewUctFp.PERSONNEL_NUMBER;

                            var result = await ctrService.UpdateCtr(dbObj);
                            if (result > 0)
                            {
                                //Proceed with Assigning Roles
                                List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                                TmUserRole UctRole = await employeeService.GetRoleId(UserRolesParam.UCT);

                                TmRoleToUserMapping roleUCT = new TmRoleToUserMapping()
                                {
                                    UserId = recevingDTO.NewUctFp.PERSONNEL_NUMBER,
                                    RoleId = UctRole.RoleId,
                                    IsActive = 1,
                                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now
                                };
                                tmRoleToUsers.Add(roleUCT);

                                if (tmRoleToUsers.Any())
                                {
                                    var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                                }

                                await ctrService.SendReassignEmail(dbObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR013", recevingDTO.NewUctFp.PERSONNEL_NUMBER, current, LoggedInUser.DISPLAY_NAME);
                                await ctrService.SendReassignEmail(dbObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR014", recevingDTO.NewUctFp.PERSONNEL_NUMBER, current, LoggedInUser.DISPLAY_NAME);
                                ReturnMessage = "TTA New Technlogy Advisor changed successfully.";
                                TmUserRole AdminRole = await employeeService.GetRoleId(UserRolesParam.Administrator);
                                await AddCtrFlowHistoryAsync(dbObj.Id, dbObj.StatusId, current + " to " + recevingDTO.NewUctFp.USER_DISPLAY, AdminRole.RoleId, LoggedInUser.DISPLAY_NAME + " (Admin) Changed New Technlogy Advisor");

                                ReturnStatus = (int)ResponseStatus.success;
                                ReturnData = recevingDTO.CtrCode;
                            }
                            else
                            {
                                ReturnMessage = "TTA New Technlogy Advisor change Error.";
                                ReturnStatus = (int)ResponseStatus.error;
                                ReturnData = recevingDTO.CtrCode;
                            }
                        }

                    }
                    else
                    {
                        ReturnMessage = "TTA data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.CtrCode;
                    }

                }
                else
                {
                    ReturnMessage = "TTA data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.CtrCode;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ChangeTrialFp")]
        [HttpPost]
        public async Task<IActionResult> ChangeTrialFp([Bind("")] CtrTrialFPChangeDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {


                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.CtrCode);
                long CtrId = (long)IdData.Split("-").Last().ToInt64();


                if (CtrId > 0)
                {
                    CtrInitiation dbObj = await ctrService.GetById(CtrId);
                    var DetaildbObj = await ctrService.GetCtrFormData(CtrId, recevingDTO.CurrentRleId, LoggedInUser.COMPANY_NUMBER);

                    if (recevingDTO.MandatoryTP != null)
                    {
                        if (recevingDTO.OtherTP?.Count > 0)
                        {
                            AllPDOUsersDTO find = recevingDTO.OtherTP.Find(x => x.PERSONNEL_NUMBER.Equals(recevingDTO.MandatoryTP.PERSONNEL_NUMBER));
                            if (find != null)
                            {
                                var response1 = new TIP_RESULT()
                                {
                                    message = "Cannot duplicate mandatory focal point as other focal point.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(response1);
                            }
                        }
                    }



                    if (dbObj != null && DetaildbObj != null)
                    {
                        //Proceed with Assigning Roles
                        List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                        TmUserRole TrialFP = await employeeService.GetRoleId(UserRolesParam.TrialFP);


                        List<CtrTrialFp> FocalPoints = new List<CtrTrialFp>();

                        if (recevingDTO.MandatoryTP != null)
                        {
                            CtrTrialFp MTFP = new CtrTrialFp()
                            {
                                CtrId = CtrId,
                                Fp = recevingDTO.MandatoryTP.PERSONNEL_NUMBER,
                                IsMandatory = true
                            };
                            FocalPoints.Add(MTFP);

                            TmRoleToUserMapping roleMTFP = new TmRoleToUserMapping()
                            {
                                UserId = recevingDTO.MandatoryTP.PERSONNEL_NUMBER,
                                RoleId = TrialFP.RoleId,
                                IsActive = 1,
                                CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                CreatedOn = DateTime.Now
                            };
                            tmRoleToUsers.Add(roleMTFP);
                        }

                        if (recevingDTO.OtherTP?.Count > 0)
                        {
                            foreach (AllPDOUsersDTO ofp in recevingDTO.OtherTP)
                            {
                                CtrTrialFp OTFP = new CtrTrialFp()
                                {
                                    CtrId = CtrId,
                                    Fp = ofp.PERSONNEL_NUMBER,
                                    IsMandatory = false
                                };
                                FocalPoints.Add(OTFP);

                                TmRoleToUserMapping roleMTFP = new TmRoleToUserMapping()
                                {
                                    //MUCI189 Hafiz change due to same role assigning again to MP instead of Other MP
                                    //UserId = recevingDTO.MandatoryTP.PERSONNEL_NUMBER,

                                    UserId = ofp.PERSONNEL_NUMBER,

                                    RoleId = TrialFP.RoleId,
                                    IsActive = 1,
                                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now
                                };
                                tmRoleToUsers.Add(roleMTFP);
                            }
                        }
                        var mResult = await ctrService.AddTrialFp(FocalPoints);
                        if (mResult > 0)
                        {

                            if (tmRoleToUsers.Any())
                            {
                                var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                            }

                            string currentOfp = string.Empty;
                            var currentOfpCount = recevingDTO.OtherTP?.Select(x => x.USER_DISPLAY).Count() ?? 0;
                            if (currentOfpCount > 0)
                            {
                                currentOfp = recevingDTO.OtherTP.Select(x => x.USER_DISPLAY).ToArray().Aggregate((a, x) => a + ", " + x);
                            }

                            long historyRoleId = recevingDTO.CurrentRleId;
                            if (historyRoleId <= 0)
                            {
                                TmUserRole historyRole = await employeeService.GetRoleId(UserRolesParam.UCT);
                                historyRoleId = historyRole.RoleId;
                            }

                            if (DetaildbObj.MandatoryTP?.PERSONNEL_NUMBER == recevingDTO.MandatoryTP?.PERSONNEL_NUMBER)
                            {
                                await ctrService.SendReassignEmail(dbObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR017", recevingDTO.MandatoryTP.PERSONNEL_NUMBER, DetaildbObj.MandatoryTP.PERSONNEL_NUMBER, LoggedInUser.DISPLAY_NAME);
                            }
                            else if (DetaildbObj.MandatoryTP?.PERSONNEL_NUMBER != recevingDTO.MandatoryTP?.PERSONNEL_NUMBER)
                            {
                                await ctrService.SendReassignEmail(dbObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR015", recevingDTO.MandatoryTP.PERSONNEL_NUMBER, DetaildbObj.MandatoryTP.PERSONNEL_NUMBER, LoggedInUser.DISPLAY_NAME);
                                await ctrService.SendReassignEmail(dbObj.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR016", recevingDTO.MandatoryTP.PERSONNEL_NUMBER, DetaildbObj.MandatoryTP.PERSONNEL_NUMBER, LoggedInUser.DISPLAY_NAME);
                            }


                            ReturnMessage = "Trial Focal Point changed successfully.";
                            await AddCtrFlowHistoryAsync(CtrId, dbObj.StatusId, recevingDTO.CurrentMFp + " to " + recevingDTO.MandatoryTP.USER_DISPLAY, historyRoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Changed Mandatory Trial FP");

                            if (currentOfpCount != 0 && recevingDTO.CurrentOFp != "")
                            {
                                await AddCtrFlowHistoryAsync(CtrId, dbObj.StatusId, recevingDTO.CurrentOFp + " to " + currentOfp, historyRoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Changed Other Trial FP");
                            }


                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.CtrCode;
                        }
                        else
                        {
                            ReturnMessage = "Trial Focal Point change Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.CtrCode;
                        }
                    }
                    else
                    {
                        ReturnMessage = "TTA data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.CtrCode;
                    }
                }
                else
                {
                    ReturnMessage = "TTA data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.CtrCode;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region CTR Deployment Staircase & VOT

        [Route("GetCtrVOT/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetChallengeVOT(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await ctrService.GetCtrVOT(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddOrUpdateCtrVOT")]
        [HttpPost]
        public async Task<IActionResult> AddOrUpdateCtrVOT([FromBody] CtrVotDTO ctrVotDTO)
        {
            try
            {
                var vot = CtrVOTDTOMapping(ctrVotDTO);
                var result = await ctrService.AddOrUpdateVOT(vot, ctrVotDTO.isEdit);
                if (result > 0)
                {
                    await ctrService.AddOrUpdateDepStaircase(DeploymentStaircaseListMapping(ctrVotDTO,vot.CtrId));
                }
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("GetAllDeploymentStaircase/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllDeploymentStaircase(string ctrCode)
        {
            try
            {
                var CtrData = CryptoExtensions.Decrypt(ctrCode);
                if (CtrData.StartsWith("TTA-"))
                {
                    long Id = (long)CtrData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await ctrService.GetCtrDeploymentStaircaseDetail(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddDeploymentStaircase")]
        [HttpPost]
        public async Task<IActionResult> AddDeploymentStaircase(CtrDeploymentStaircaseDTO ctrDeploymentStaircaseDTO)
        {
            try
            {
                var CtrData = CryptoExtensions.Decrypt(ctrDeploymentStaircaseDTO.ctrCode);
                if (CtrData.StartsWith("TTA-"))
                {
                    long CtrId = (long)CtrData.Split("-").Last().ToInt64();
                    if (CtrId > 0)
                    {
                        ctrDeploymentStaircaseDTO.ctrId = CtrId;
                        var result = await ctrService.AddDeploymentStaircase(DeploymentStaircaseDTOMapping(ctrDeploymentStaircaseDTO));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = ResponseStatus.success.ToString(),
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "TTA data is not saved",
                                status = (int)ResponseStatus.error,
                                TResponse = result
                            };
                            return Ok(response);
                        }

                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA data is not saved",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data is not saved",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateDeploymentStaircase")]
        [HttpPost]
        public async Task<IActionResult> UpdateDeploymentStaircase(CtrDeploymentStaircaseDTO ctrDeploymentStaircaseDTO)
        {
            try
            {
                var result = await ctrService.UpdateDeploymentStaircase(DeploymentStaircaseDTOMapping(ctrDeploymentStaircaseDTO));
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA deployment staircase data not updated",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateFinalDeploymentStaircase")]
        [HttpPost]
        public async Task<IActionResult> UpdateFinalDeploymentStaircase(CtrInitiationDeploymentStaircaseDTO ctrInitiationDeploymentStaircaseDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await ctrService.UpdateFinalDeploymentStaircase(ctrInitiationDeploymentStaircaseDTO, LoggedInUser);
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA deployment staircase data not updated",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteCtrDeploymentStaircase/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteDeploymentStaircase(long id)
        {
            try
            {
                var result = await ctrService.DeleteDeploymentStaircase(id);
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA deployment staircase deleted successfully.",
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA deployment staircase data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private CtrVot CtrVOTDTOMapping(CtrVotDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            CtrVot returnObj = new CtrVot()
            {
                
                CtrId = obj.ctr_id,
                UnitId = obj.unit_id,
                NoOfUnitsYear1 = obj.nofUnitYear1,
                NoOfUnitsYear2 = obj.nofUnitYear2,
                NoOfUnitsYear3 = obj.nofUnitYear3,
                NoOfUnitsYear4 = obj.nofUnitYear4,
                NoOfUnitsYear5 = obj.nofUnitYear5,
                NoOfUnitsTrailScope = obj.nofUnitTrailScope,
                TechCost = obj.techCst,
                OtherCost = obj.otherCst,
                AvgIncrmntlOilGain = obj.avgIncrementalOilGain,
                TotOilDefermentAvoidance = obj.totOilAvoidance,
                CostSavingUnitYr = obj.cspu,
                PowerSavingUnitYr = obj.powerSavingPerUnit,
                CostAvoidance = obj.cstAvoidance,
                Co2ReductnUnitYr = obj.co2ruy,
                Hse = obj.hseBenefits,
                Quality = obj.quality,
                Compliance = obj.compliance,
                RiskFactor = obj.riskFactor,
                M3T0Bbl = obj.m3tobbl,
                Co2Tax = obj.co2Tax,
                MwhCost = obj.mwhCst,
                OilPrice = obj.op,
                TotalMwhReduction = obj.totMWHReductionScope,
                TotalCo2Reduction = obj.totCO2Reduction,
                VotUnitYear = obj.votPerUnitPerYear,
                VotTrailTotUnits = obj.vottrialTotalUnits,
                VotTotDeploymentUnits = obj.votTotalDeploymentUnits,
                Comments = obj.comment,
                AssumptionMode = obj.assumption,
                CreatedBy = LoggedInUser.COMPANY_NUMBER,
                CreatedByRef = LoggedInUser.REFERENCE_INDICATOR,
                CreatedOn = DateTime.Now
            };
            //if (returnObj.Id <= 0) Change condition By Hafiz MUCI189

             if (returnObj.CtrId <= 0)
            {
                var IdData = CryptoExtensions.Decrypt(obj.ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    returnObj.CtrId = Id;
                }
            }
            return returnObj;
        }

        private CtrDeploymentStaircase DeploymentStaircaseDTOMapping(CtrDeploymentStaircaseDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            CtrDeploymentStaircase ctrDeploymentStaircase = new CtrDeploymentStaircase()
            {
                Id = obj.id,
                CtrId = obj.ctrId,
                Year = obj.year,
                Noofwells = obj.noofwells,
                Estimatedvot = obj.estimatedvot,
                Station = obj.station
            };

            if (obj.id > 0)
            {
                ctrDeploymentStaircase.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrDeploymentStaircase.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrDeploymentStaircase.UpdatedOn = DateTime.Now;
            }
            else
            {
                ctrDeploymentStaircase.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrDeploymentStaircase.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrDeploymentStaircase.CreatedOn = DateTime.Now;
            }

            return ctrDeploymentStaircase;
        }

        private List<CtrDeploymentStaircase> DeploymentStaircaseListMapping(CtrVotDTO obj,long ctrId)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            List < CtrDeploymentStaircase > deploymentStaircaseList = new List<CtrDeploymentStaircase>();
            foreach (var ds in obj.stairCases)
            {
                CtrDeploymentStaircase ctrDeploymentStaircase = new CtrDeploymentStaircase()
                {

                    CtrId = ctrId,
                    Year = ds.year,
                    Noofwells = ds.noofwells,
                    Estimatedvot = ds.estimatedvot,
                    Station = ds.station,
                    CreatedBy = LoggedInUser.COMPANY_NUMBER,
                    CreatedByRef = LoggedInUser.REFERENCE_INDICATOR,
                    CreatedOn = DateTime.Now,
                };
                deploymentStaircaseList.Add(ctrDeploymentStaircase);

            }
               
            

            return deploymentStaircaseList;
        }

        #endregion

        #region CTR Trial Risks

        [Route("GetCtrTrialRisks/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrTrialRisks(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await ctrService.GetCtrTrialRisks(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA risk trial data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA risk trial data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("AddCtrTrialRisks")]
        [HttpPost]
        public async Task<IActionResult> AddCtrTrialRisks(CtrTrialRiskDTO ctrTrialRiskDTO)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrTrialRiskDTO.cfCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    ctrTrialRiskDTO.ctrId = Id;
                    var result = await ctrService.AddTrialRisk(CtrTrialRiskDTOMapping(ctrTrialRiskDTO));
                    if (result > 0)
                    {
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA risk trial data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA risk trial data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateCtrTrialRisks")]
        [HttpPost]
        public async Task<IActionResult> UpdateCtrTrialRisks(CtrTrialRiskDTO ctrTrialRiskDTO)
        {
            try
            {
                var result = await ctrService.UpdateTrialRisk(CtrTrialRiskDTOMapping(ctrTrialRiskDTO));
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA risk trial data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteCtrTrialRisks/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteCtrTrialRisks(long id)
        {
            try
            {
                var result = await ctrService.DeleteTrialRisk(id);
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA risk trial data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private CtrTrialRisk CtrTrialRiskDTOMapping(CtrTrialRiskDTO ctrTrialRiskDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            CtrTrialRisk ctrTrialRisk = new CtrTrialRisk()
            {
                Id = ctrTrialRiskDTO.id,
                CtrId = ctrTrialRiskDTO.ctrId,
                Risk = ctrTrialRiskDTO.risk,
                MitigationPlan = ctrTrialRiskDTO.mitigation
            };
            if (ctrTrialRisk.Id > 0)
            {
                ctrTrialRisk.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrTrialRisk.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrTrialRisk.UpdatedOn = DateTime.Now;
            }
            else
            {
                ctrTrialRisk.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrTrialRisk.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrTrialRisk.CreatedOn = DateTime.Now;
            }
            return ctrTrialRisk;
        }

        #endregion

        #region CTR Success Criteria

        [Route("GetCtrSuccessCerteria/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrSuccessCerteria(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await ctrService.GetCtrSuccessCerteria(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA success certeria data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA success certeria data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("AddCtrSuccessCerteria")]
        [HttpPost]
        public async Task<IActionResult> AddCtrSuccessCerteria(CtrSuccessCriterionDTO ctrSuccessCriterionDTO)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrSuccessCriterionDTO.cfCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    ctrSuccessCriterionDTO.ctrId = Id;
                    var result = await ctrService.AddCtrSuccessCerteria(CtrSuccessCerteriaDTOMapping(ctrSuccessCriterionDTO));
                    if (result > 0)
                    {
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA success certeria data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA success certeria data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateCtrSuccessCerteria")]
        [HttpPost]
        public async Task<IActionResult> UpdateCtrSuccessCerteria(CtrSuccessCriterionDTO ctrSuccessCriterionDTO)
        {
            try
            {
                var result = await ctrService.UpdateCtrSuccessCerteria(CtrSuccessCerteriaDTOMapping(ctrSuccessCriterionDTO));
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA success certeria data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteCtrSuccessCerteria/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteCtrSuccessCerteria(long id)
        {
            try
            {
                var result = await ctrService.DeleteCtrSuccessCerteria(id);
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA success certeria data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private CtrSuccessCriterion CtrSuccessCerteriaDTOMapping(CtrSuccessCriterionDTO ctrSuccessCriterionDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            CtrSuccessCriterion ctrSuccessCriterion = new CtrSuccessCriterion()
            {
                Id = ctrSuccessCriterionDTO.id,
                CtrId = ctrSuccessCriterionDTO.ctrId,
                Parameter = ctrSuccessCriterionDTO.parameter,
                CurrentValue = ctrSuccessCriterionDTO.value,
                TrialTarget = ctrSuccessCriterionDTO.target,
                ParameterId = ctrSuccessCriterionDTO.paramId,
                DecisionGateImpacted = ctrSuccessCriterionDTO.dgImpact,
                Remarks = ctrSuccessCriterionDTO.comment
            };
            if (ctrSuccessCriterion.Id > 0)
            {
                ctrSuccessCriterion.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrSuccessCriterion.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrSuccessCriterion.UpdatedOn = DateTime.Now;
            }
            else
            {
                ctrSuccessCriterion.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrSuccessCriterion.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrSuccessCriterion.CreatedOn = DateTime.Now;
            }
            return ctrSuccessCriterion;
        }


        [Route("UpdateSCDetails")]
        [HttpPost]
        public async Task<IActionResult> UpdateSCDetails(CtrInitiationSCDTO recObj)
        {
            try
            {

                var IdData = CryptoExtensions.Decrypt(recObj.CTRCode);
                if (IdData.StartsWith("TTA-"))
                {
                    EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        CtrInitiation dbObj = await ctrService.GetById(Id);

                        dbObj.GeneralComments = recObj.GeneralComments;
                        dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                        dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                        dbObj.UpdatedOn = DateTime.Now;

                        if (dbObj != null)
                        {
                            var result = await ctrService.UpdateCtr(dbObj);
                            if (result > 0)
                            {
                                var response = new TIP_RESULT()
                                {
                                    message = ResponseStatus.success.ToString(),
                                    status = (int)ResponseStatus.success,
                                    TResponse = result
                                };
                                return Ok(response);
                            }
                            else
                            {
                                var response = new TIP_RESULT()
                                {
                                    message = "TTA success certeria update failed",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(response);
                            }
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "TTA data not  found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }

                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region CTR Trial 
        [Route("GetCtrTrial/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrTrial(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await ctrService.GetCtrTrial(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA trial data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA trial data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }


        [Route("AddOrUpdateCtrTrial")]
        [HttpPost]
        public async Task<IActionResult> AddOrUpdateCtrTrial(List<CtrTrialDTO> ctrTrialDTOs)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                bool isEdit = ctrTrialDTOs[0].id > 0 ? true : false;

                var IdData = CryptoExtensions.Decrypt(ctrTrialDTOs[0].cfCode);

                long ctrId = (long)IdData.Split("-").Last().ToInt64();

                List<CtrTrial> ctrTrialList = new List<CtrTrial>();
                foreach (var item in ctrTrialDTOs)
                {
                    CtrTrial ctrTrial = new CtrTrial();
                    ctrTrial.Id = item.id;
                    ctrTrial.CtrId = ctrId;
                    ctrTrial.DecisionGate = item.gate;
                    ctrTrial.DecisionBy = item.ownBy;
                    ctrTrial.Remarks = item.comment;
                    ctrTrial.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                    ctrTrial.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                    ctrTrial.CreatedOn = DateTime.Now;
                    foreach (var year in item.ctrTrialYear)
                    {
                        CtrTrialYear ctrTrialYear = new CtrTrialYear();
                        ctrTrialYear.Id = year.id;
                        ctrTrialYear.TrialId = year.trialId;
                        ctrTrialYear.Year = year.yearVal;
                        ctrTrialYear.Q1 = year.q1;
                        ctrTrialYear.Q2 = year.q2;
                        ctrTrialYear.Q3 = year.q3;
                        ctrTrialYear.Q4 = year.q4;
                        ctrTrial.CtrTrialYears.Add(ctrTrialYear);
                    }
                    ctrTrialList.Add(ctrTrial);
                }
                var result = await ctrService.AddOrUpdateCtrTrial(ctrTrialList, isEdit);
                if (result <= 0)
                {
                    var failResponse = new TIP_RESULT()
                    {
                        message = "Trial plan is not saved. Please check Decision Gate values and try again.",
                        status = (int)ResponseStatus.error,
                        TResponse = result
                    };
                    return Ok(failResponse);
                }

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region CTR attachment

        [Route("GetAllFiles/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllFiles(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                long Id = (long)IdData.Split("-").Last().ToInt64();
                //Do not change the 'CTR Form' 
                var result = await commonService.GetAllFilesByLinkId(Id, "CTR Form", false);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("SaveAllFiles")]
        [HttpPost]
        public async Task<IActionResult> UploadAllFiles([Bind("")] DocumentUploadDTO documentUploadDTO)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(documentUploadDTO.code);
                long Id = (long)IdData.Split("-").Last().ToInt64();
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                long result = 0;
                //Do not change the 'CTR Form' 
                var res = await commonService.DeleteDocument(Id, "CTR Form");
                foreach (var file in documentUploadDTO.files)
                {
                    DocumentRepo obj = new DocumentRepo()
                    {
                        LimkType = file.type,
                        LinkId = Id,
                        FilePath = (file.filepath),
                        CreatedBy = LoggedInUser.COMPANY_NUMBER,
                        CreatedOn = DateTime.Now,
                        FileName = CryptoExtensions.Encrypt(file.fileName),
                        FileType = file.fileExtension,
                        Description = file.description,
                        MimeType = file.mimeType,
                        IsActive = true,
                        IsExternalAccessible = file.isEA,
                    };
                    result = await commonService.AddDocument(obj);
                }
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region TTA Potential Impact 

        [Route("GetCtrPotentialImpacted/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrPotentialImpacted(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await ctrService.GetCtrPotentialImpacted(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA potential impacted data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA potential impacted data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("AddCtrPotentialImpacted")]
        [HttpPost]
        public async Task<IActionResult> AddCtrPotentialImpacted(CtrPotentialImpactedDTO ctrPotentialImpactedDTO)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrPotentialImpactedDTO.cfCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    ctrPotentialImpactedDTO.ctrId = Id;
                    var result = await ctrService.AddCtrPotentialImpacted(CtrPotentialImpactedDTOMapping(ctrPotentialImpactedDTO));
                    if (result > 0)
                    {
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA potential impacted data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA potential impacted data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateCtrPotentialImpacted")]
        [HttpPost]
        public async Task<IActionResult> UpdateCtrPotentialImpacted(CtrPotentialImpactedDTO ctrPotentialImpactedDTO)
        {
            try
            {
                var result = await ctrService.UpdateCtrPotentialImpacted(CtrPotentialImpactedDTOMapping(ctrPotentialImpactedDTO));
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA potential impacted data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteCtrPotentialImpacted/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteCtrPotentialImpacted(long id)
        {
            try
            {
                var result = await ctrService.DeleteCtrPotentialImpacted(id);
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA potential impacted data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private CtrPotentialImpacted CtrPotentialImpactedDTOMapping(CtrPotentialImpactedDTO ctrPotentialImpactedDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            CtrPotentialImpacted ctrPotentialImpacted = new CtrPotentialImpacted()
            {
                Id = ctrPotentialImpactedDTO.id,
                CtrId = ctrPotentialImpactedDTO.ctrId,
                ContractTitle = ctrPotentialImpactedDTO.title,
                ContractNo = ctrPotentialImpactedDTO.no,
                Contractor = ctrPotentialImpactedDTO.provider,
                Impact = ctrPotentialImpactedDTO.impact
            };
            if (ctrPotentialImpacted.Id > 0)
            {
                ctrPotentialImpacted.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrPotentialImpacted.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrPotentialImpacted.UpdatedOn = DateTime.Now;
            }
            else
            {
                ctrPotentialImpacted.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrPotentialImpacted.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrPotentialImpacted.CreatedOn = DateTime.Now;
            }
            return ctrPotentialImpacted;
        }

        #endregion

        #region CTR Budget

        [Route("GetCtrBudget/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrBudget(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await ctrService.GetCtrBudget(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA budget data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA budget data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("AddCtrBudget")]
        [HttpPost]
        public async Task<IActionResult> AddCtrBudget(CtrBudgetDTO ctrBudgetDTO)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrBudgetDTO.ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    ctrBudgetDTO.ctrId = Id;
                    var result = await ctrService.AddCtrBudget(CtrBudgetDTOMapping(ctrBudgetDTO));
                    if (result > 0)
                    {
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA budget data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA budget data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateCtrBudget")]
        [HttpPost]
        public async Task<IActionResult> UpdateCtrBudget(CtrBudgetDTO ctrBudgetDTO)
        {
            try
            {
                var result = await ctrService.UpdateCtrBudget(CtrBudgetDTOMapping(ctrBudgetDTO));
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA budget data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteCtrBudget/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteCtrBudget(long id)
        {
            try
            {
                var result = await ctrService.DeleteCtrBudget(id);
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA budget data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private CtrBudget CtrBudgetDTOMapping(CtrBudgetDTO ctrBudgetDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            CtrBudget ctrBudget = new CtrBudget()
            {
                Id = ctrBudgetDTO.id,
                CtrId = ctrBudgetDTO.ctrId,
                Year = ctrBudgetDTO.yearVal,
                QId = ctrBudgetDTO.qId,
                BudgetProvider = ctrBudgetDTO.budgetPro,
                ItemProvider = ctrBudgetDTO.itemPro,
                Amount = ctrBudgetDTO.amount,
                ResourceDescription = ctrBudgetDTO.resourceDesc
            };
            if (ctrBudget.Id > 0)
            {
                ctrBudget.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrBudget.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrBudget.UpdatedOn = DateTime.Now;
            }
            else
            {
                ctrBudget.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrBudget.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrBudget.CreatedOn = DateTime.Now;
            }
            return ctrBudget;
        }

        #endregion

        #region CTR Schedule Price

        [Route("GetCtrSchedulePrice/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrSchedulePrice(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await ctrService.GetCtrSchedulePrice(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA schedule price data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA schedule price data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("AddCtrSchedulePrice")]
        [HttpPost]
        public async Task<IActionResult> AddCtrSchedulePrice([FromBody] CtrSchedulePriceDTO recObj)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(recObj.cfCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    recObj.CtrId = Id;
                    var result = await ctrService.AddCtrSchedulePrice(CtrSchedulePriceDTOMapping(recObj));
                    if (result > 0)
                    {
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA Schedule Price data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA Schedule Price data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateCtrSchedulePrice")]
        [HttpPost]
        public async Task<IActionResult> UpdateCtrSchedulePrice([FromBody] CtrSchedulePriceDTO ctrSuccessCriterionDTO)
        {
            try
            {
                var result = await ctrService.UpdateCtrSchedulePrice(CtrSchedulePriceDTOMapping(ctrSuccessCriterionDTO));
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA schedule price data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteCtrSchedulePrice/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteCtrSchedulePrice(long id)
        {
            try
            {
                var result = await ctrService.DeleteCtrSchedulePrice(id);
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA schedule price data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private CtrSchedulePrice CtrSchedulePriceDTOMapping(CtrSchedulePriceDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            CtrSchedulePrice ctrSchedulePrice = new CtrSchedulePrice()
            {
                Id = obj.Id,
                CtrId = obj.CtrId,
                Description = obj.Description,
                Units = obj.Units,
                UnitPrice = obj.UnitPrc,
                Quantity = obj.Quantity,
                NumberOfTrials = obj.NumberOfTrials,
                TotalPriceEstimate = obj.TotalPrcEst

            };
            if (ctrSchedulePrice.Id > 0)
            {
                ctrSchedulePrice.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrSchedulePrice.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrSchedulePrice.UpdatedOn = DateTime.Now;
            }
            else
            {
                ctrSchedulePrice.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                ctrSchedulePrice.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                ctrSchedulePrice.CreatedOn = DateTime.Now;
            }
            return ctrSchedulePrice;
        }

        #endregion

        #region Paymenty Milestone for Percentage Completion 

        [Route("GetCtrPaymentMilestone/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrPaymentMilestone(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await ctrService.GetCtrPaymentMilestone(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA payment milestone data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA payment milestone data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("AddCtrPaymentMilestone")]
        [HttpPost]
        public async Task<IActionResult> AddCtrPaymentMilestone([Bind("")] CtrPercentageCompletionDTO recObj)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(recObj.cfCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    recObj.CtrId = Id;
                    var result = await ctrService.AddCtrPaymentMilestone(CtrPaymentMilestoneDTOMapping(recObj));
                    if (result > 0)
                    {
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA payment milestone data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA payment milestone data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateCtrPaymentMilestone")]
        [HttpPost]
        public async Task<IActionResult> UpdateCtrPaymentMilestone([Bind("")] CtrPercentageCompletionDTO recObj)
        {
            try
            {
                var result = await ctrService.UpdateCtrPaymentMilestone(CtrPaymentMilestoneDTOMapping(recObj));
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA payment milestone data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteCtrPaymentMilestone/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteCtrPaymentMilestone(long id)
        {
            try
            {
                var result = await ctrService.DeleteCtrPaymentMilestone(id);
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA payment milestone data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private CtrPercentageCompletion CtrPaymentMilestoneDTOMapping(CtrPercentageCompletionDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            CtrPercentageCompletion newObj = new CtrPercentageCompletion()
            {
                Id = obj.Id,
                CtrId = obj.CtrId,
                Percentage = obj.Percentage,
                EstPrice = obj.EstPrc,


            };
            if (newObj.Id > 0)
            {
                newObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.UpdatedOn = DateTime.Now;
            }
            else
            {
                newObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.CrreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.CreatedOn = DateTime.Now;
            }
            return newObj;
        }

        #endregion


        #region Trial Candidates

        [Route("GetAllTrialCandidates/{ctrCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetAllTrialCandidates(string ctrCode, long roleid)
        {
            try
            {
                var CtrData = CryptoExtensions.Decrypt(ctrCode);
                if (CtrData.StartsWith("TTA-"))
                {
                    long PirId = (long)CtrData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await ctrService.GetAllTrialCandidates(PirId, roleid, LoggedInUser.COMPANY_NUMBER);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "CTR data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "CTR data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("AddUpdateTrialCandidates")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateTrialCandidates([Bind("")] CtrTrialCandidateDTO recObj)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(recObj.ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long PirId = (long)IdData.Split("-").Last().ToInt64();

                    recObj.CtrId = PirId;
                    if (recObj.Id > 0)
                    {
                        var result = await ctrService.UpdateTrialCandidates(CTRTrialCandidateDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate updated successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }
                    else
                    {
                        var result = await ctrService.AddTrialCandidates(CTRTrialCandidateDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate added successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }

                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "CTR not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteTrialCandidates/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteTrialCandidates(long id)
        {
            try
            {
                var result = await ctrService.DeleteTrialCandidates(id);

                var response = new TIP_RESULT()
                {
                    message = "Trial candidate deleted successfully.",
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }

        private CtrTrialCandidate CTRTrialCandidateDTOMapping(CtrTrialCandidateDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            var isInsert = obj.Id <= 0;

            CtrTrialCandidate newObj = new CtrTrialCandidate()
            {
                TypeId = obj.TypeId,
                Name = obj.Name,
                Cost = obj.Cst,
                CommencementDate = obj.CommencementDate,
                ConclusionDate = obj.ConclusionDate,
                ChallengeDescription = obj.ChallengeDescription,
                Comments = obj.Comments,
                CtrId = obj.CtrId
            };
            if (!isInsert)
            {
                newObj.Id = obj.Id;
                newObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.UpdatedOn = DateTime.Now;
            }
            else
            {
                newObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.CreatedOn = DateTime.Now;
            }


            return newObj;
        }

        #endregion

        [Route("GetApproverListByCtr/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetApproverListByCtr(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await ctrService.GetApproverListByCtr(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA approver's data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA approver's data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("GetAllStatusByCtr/{techId}")]
        [HttpGet]
        public async Task<IActionResult> GetAllStatusByCtr(long techId)
        {
            try
            {
                var result = await ctrService.GetAllStatusByCtr(techId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetCtrFormDataforViewPlan/{ctrCode}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrFormDataforViewPlan(string ctrCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrCode);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();


                    if (Id > 0)
                    {
                        var result = await ctrService.GetCtrFormDataforViewPlan(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }


            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);

            }
        }


        [Route("AddCTRplan")]
        [HttpPost]
        public async Task<IActionResult> AddCTRplan([Bind("")] CTRPlanDetailsDTO ctrplanDTO)
        {
            try
            {
                if (ctrplanDTO.IsCreated != null)
                {
                    if (!(bool)ctrplanDTO.IsCreated)
                    {
                        ctrplanDTO.Id = 0;
                        ctrplanDTO.IsSubmit = false;
                    }
                }
                else 
                {
                    var year = ctrplanDTO.startdate.ToDateTime().Value.Year.ToString();
                    ctrplanDTO.year = year;
                }
                var response = new TIP_RESULT();
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await ctrService.AddctrPlan(CtrplanMapping(ctrplanDTO, LoggedInUser),(bool)ctrplanDTO.IsSubmit);
                if (result == 0)
                {
                    response = new TIP_RESULT()
                    {
                        message = "Phase already exist in this template",
                        status = (int)ResponseStatus.warning,
                        TResponse = result
                    };
                }
                else
                {
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateCTRplan")]
        [HttpPost]
        public async Task<IActionResult> UpdateCTRplan([Bind("")] CTRPlanDetailsDTO ctrplanDTO)
        {
            try
            {
                var response = new TIP_RESULT();
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await ctrService.UpdateCTRPlan(CtrplanMapping(ctrplanDTO, LoggedInUser),(bool)ctrplanDTO.IsSubmit);
                if (result == 0)
                {
                    response = new TIP_RESULT()
                    {
                        message = "Phase already exist in different record",
                        status = (int)ResponseStatus.warning,
                        TResponse = result
                    };
                }
                else
                {
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                }
             
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteCTRplan/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteCTRplan(long id)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await ctrService.DeleteCTRPlan(id, LoggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
        private CtrPlanDetail CtrplanMapping(CTRPlanDetailsDTO cTRPlanDetailsDTO, EmployeeDTO employeeDTO)
        {
       
            CtrPlanDetail ctrplan = new CtrPlanDetail()
            {
                Id = cTRPlanDetailsDTO.Id,
                //Stage = cTRPlanDetailsDTO.stage,
                Planneddays = cTRPlanDetailsDTO.planneddays,
                Sequence = cTRPlanDetailsDTO.sequence,
                Phase = cTRPlanDetailsDTO.phase,
                Startdate = cTRPlanDetailsDTO.startdate == "" || cTRPlanDetailsDTO.startdate == null ? null : (DateTime)cTRPlanDetailsDTO.startdate.ToDateTime(),
                Enddate = cTRPlanDetailsDTO.enddate == "" || cTRPlanDetailsDTO.enddate == null ? null : (DateTime)cTRPlanDetailsDTO.enddate.ToDateTime(),
                StageId = cTRPlanDetailsDTO.stageid,
                PhaseId = cTRPlanDetailsDTO.phaseid,
                CtrId = cTRPlanDetailsDTO.ctr_id,
                TemplateId = cTRPlanDetailsDTO.templateid,
                Year = cTRPlanDetailsDTO.year

            };
            if (ctrplan.Id > 0)
            {
                ctrplan.UpdatedBy = employeeDTO.COMPANY_NUMBER;
                ctrplan.UpdatedByRef = employeeDTO.REFERENCE_INDICATOR;
                ctrplan.UpdatedOn = DateTime.Now;
            }
            else
            {
                ctrplan.CreatedBy = employeeDTO.COMPANY_NUMBER;
                ctrplan.CreatedByRef = employeeDTO.REFERENCE_INDICATOR;
                ctrplan.CreatedOn = DateTime.Now;
            }

            return ctrplan;
        }



        [Route("GetAllCTRActualFiles/{actValID}")]
        [HttpGet]
        public async Task<IActionResult> GetAllCTRActualFiles(string actValID)
        {
            try
            {
                var result = await commonService.GetAllFilesByLinkId((long)actValID.ToInt64(), "CTRActualPlan", false);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }
        //UpdateExecutionActualPlanTimeline

        [Route("SaveAllCTRActualFiles")]
        [HttpPost]
        public async Task<IActionResult> UploadAllCTRActualFiles([Bind("")] DocumentUploadDTO documentUploadDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {
                //var IdData = CryptoExtensions.Decrypt(documentUploadDTO.code);
                long Id = (long)documentUploadDTO.code.ToInt64();
                long result = 0;
                var res = await commonService.DeleteDocument(Id, "CTRActualPlan");
                foreach (var file in documentUploadDTO.files)
                {
                    DocumentRepo obj = new DocumentRepo()
                    {
                        LimkType = file.type,
                        LinkId = Id,
                        FilePath = (file.filepath),
                        CreatedBy = LoggedInUser.COMPANY_NUMBER,
                        CreatedOn = DateTime.Now,
                        FileName = CryptoExtensions.Encrypt(file.fileName),
                        FileType = file.fileExtension,
                        Description = file.description,
                        MimeType = file.mimeType,
                        IsActive = true,
                        IsExternalAccessible = file.isEA,
                    };
                    result = await commonService.AddDocument(obj);
                }
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        [Route("GetCtrViewplandetailsByCTRID/{ctrId}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrViewplandetailsByCTRID(string ctrId)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(ctrId);
                if (IdData.StartsWith("TTA-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    if (Id > 0)
                    {
                        var result = await commonService.GetCtrViewplandetailsByCtrID(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("AddActualCTRplan")]
        [HttpPost]
        public async Task<IActionResult> AddActualCTRplan([Bind("")] CTRActualPlanDetailsDTO ctrplanDTO)
        {
            try
            {

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await ctrService.AddctrActualPlan(CtrActualplanMapping(ctrplanDTO, LoggedInUser));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateActualCTRplan")]
        [HttpPost]
        public async Task<IActionResult> UpdateActualCTRplan([Bind("")] CTRActualPlanDetailsDTO ctrplanDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await ctrService.UpdateCTRActualPlan(ctrplanDTO);//CtrplanMapping(ctrplanDTO, LoggedInUser)
                if (ctrplanDTO.completion == 100 && result > 0) 
                {
                    await ctrService.SendCTRPlanEmail(ctrplanDTO.ctr_id, ctrplanDTO.Id, EmailModules.CTR_FRONT_END_LOADING, "CTR999");
                }
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        private CtrActualPlanDetail CtrActualplanMapping(CTRActualPlanDetailsDTO cTRactualPlanDetailsDTO, EmployeeDTO employeeDTO)
        {
            CtrActualPlanDetail ctrplan = new CtrActualPlanDetail()
            {
                Id = cTRactualPlanDetailsDTO.Id,
                Stage = cTRactualPlanDetailsDTO.stage,
                Planneddays = cTRactualPlanDetailsDTO.planneddays,
                Sequence = cTRactualPlanDetailsDTO.sequence,
                Phase = cTRactualPlanDetailsDTO.phase,

            Actualstartdate = cTRactualPlanDetailsDTO.actualstartdate == "" || cTRactualPlanDetailsDTO.actualstartdate == null ? null : (DateTime)cTRactualPlanDetailsDTO.actualstartdate.ToDateTime(),
            Actualenddate = cTRactualPlanDetailsDTO.actualenddate == "" || cTRactualPlanDetailsDTO.actualenddate == null ? null : (DateTime)cTRactualPlanDetailsDTO.actualenddate.ToDateTime(),

            PlanId = cTRactualPlanDetailsDTO.plan_id,
                Comments = cTRactualPlanDetailsDTO.comments,
                Completion = cTRactualPlanDetailsDTO.completion,
                OverallProgressId = cTRactualPlanDetailsDTO.overall_progress_id,
                StatusId = cTRactualPlanDetailsDTO.status_id,
                ForecastedEdDate = cTRactualPlanDetailsDTO.forecasted_ed_date == "" || cTRactualPlanDetailsDTO.forecasted_ed_date == null ? null : (DateTime)cTRactualPlanDetailsDTO.forecasted_ed_date.ToDateTime(),
                ForecastedStDate = cTRactualPlanDetailsDTO.forecasted_st_date == "" || cTRactualPlanDetailsDTO.forecasted_st_date == null ? null : (DateTime)cTRactualPlanDetailsDTO.forecasted_st_date.ToDateTime(),
                CtrId = cTRactualPlanDetailsDTO.ctr_id


            };
           

            return ctrplan;
        }


        [Route("GetOverallProgress")]
        [HttpGet]
        public async Task<IActionResult> GetOverallProgress()
        {
            try
            {
                var result = await ctrService.GetOverallProgress();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [AllowAnonymous]
        [Route("BudgetRepot")]  
        [HttpPost]
        public async Task<IActionResult> BudgetRepot([Bind("")] BudgetReportRequestDTO budgetReportDTO)
        {
           
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                var result = await ctrService.BudgetRepot(budgetReportDTO, LoggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
           
        }


        [Route("BudgetRepotPrint")]
        [HttpPost]
        public async Task<IActionResult> BudgetRepotPrint([Bind("")] BudgetReportRequestDTO budgetReportDTO)
        {
            try
            {
                
                var result = await ctrService.BudgetRepotPrint(budgetReportDTO);
                var response = new FileContentResult(result.FileBytes, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(result.Type));
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

    }
}
