﻿using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Exchange.WebServices.Data;
using System.Collections.Generic;
using System.Net.Mime;
using System.Text.Json;
using TIP_API.DTO;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_Common;
using TIP_Common.Admin;
using TIP_Common.Enum;
using TIP_Common.Helpers;
using TIP_Core;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using static TIP_API.Controllers.CommonController;
using static TIP_Common.Enum.Enum;

namespace TIP_API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ChallengeController : BaseController
    {
        private readonly IChallengeService challengeService;
        private readonly IChallengeSolutionReviewersService challengeSolutionReviewersService;
        private readonly IConfiguration Configuration;
        private readonly IEmployeeService employeeService;
        public ChallengeController(ICommonService _commonService, IChallengeService _challengeService, IChallengeSolutionReviewersService _challengeSolutionReviewersService, IConfiguration _configuration, IEmployeeService _employeeService) : base(_commonService)
        {
            challengeService = _challengeService;
            challengeSolutionReviewersService = _challengeSolutionReviewersService;
            Configuration = _configuration;
            employeeService = _employeeService; 
        }

        #region Challenge Detial & registration ~ Fazal, Rahim IDAP1X 

        [Route("AddOrUpdateChallengeForm")]
        [HttpPost]
        public async Task<IActionResult> ChallengeResistrationForm([FromBody] ChallengeDetailDTO challengeDetailDTO)
        {
            try
            {
                if (challengeDetailDTO == null)
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Invalid challenge form data.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                long challengeRegId = (long)CryptoExtensions.Decrypt(challengeDetailDTO.challengeRegId).ToInt64();
                var challengeDetailId = await challengeService.ChallengeResistrationForm(UserRoleDTOMapping(challengeDetailDTO));
                if (challengeDetailId > 0)
                {
                    if (challengeDetailDTO.files != null)
                    {
                        var res = await commonService.DeleteDocument(challengeRegId, "Challenge Details");
                        foreach (var file in challengeDetailDTO.files)
                        {
                           
                                DocumentRepo obj = new DocumentRepo()
                                {
                                    LimkType = "Challenge Details",
                                    LinkId = challengeRegId,
                                    FilePath = (file.filepath),
                                    CreatedBy = LoggedInUser.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now,
                                    FileName = CryptoExtensions.Encrypt(file.fileName),
                                    FileType = file.fileExtension,
                                    Description = file.description,
                                    MimeType = file.mimeType,
                                    IsActive = true,
                                    IsExternalAccessible = file.isEA,
                                };
                                var Result = await commonService.AddDocument(obj);                           
                        }

                    }
                    bool isEdit = challengeDetailDTO.id > 0 ? true : false;
                    List<ChallengeSolutionReviewer> challengeSRList = new List<ChallengeSolutionReviewer>();
                    foreach (var item in challengeDetailDTO.reviewerMUNo ?? Enumerable.Empty<string>())
                    {
                        ChallengeSolutionReviewer challengeSolutionReviewer = new ChallengeSolutionReviewer();
                        challengeSolutionReviewer.ChallengeId = challengeRegId;
                        challengeSolutionReviewer.ChallengeDetailId = challengeDetailId;
                        challengeSolutionReviewer.Reviewer = item;
                        challengeSRList.Add(challengeSolutionReviewer);
                    }
                    var crResult = await challengeSolutionReviewersService.AddOrUpdateReviewers(challengeSRList, isEdit);
                    if (crResult > 0 || challengeSRList.Count == 0)
                    {
                        foreach (var item in challengeDetailDTO.reviewerMUNo ?? Enumerable.Empty<string>())
                        {
                            List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                            TmUserRole SrRole = await employeeService.GetRoleId(UserRolesParam.SolutionReviewer);

                            TmRoleToUserMapping roleSR = new TmRoleToUserMapping()
                            {
                                UserId = item,
                                RoleId = SrRole.RoleId,
                                IsActive = 1,
                                CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                CreatedOn = DateTime.Now
                            };
                            tmRoleToUsers.Add(roleSR);

                            if (tmRoleToUsers.Any())
                            {
                                var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                            }
                        }
                        try
                        {
                            if (challengeDetailDTO.allVSQ != null && challengeDetailDTO.allVSQ.Count > 0)
                                await AddOrUpdateVendorScreening(challengeDetailDTO.allVSQ, challengeDetailId);
                            if (challengeDetailDTO.vot != null)
                            {
                                await AddOrUpdateChallengeVOT(challengeDetailDTO.vot);
                            }

                            List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                            TmUserRole CfdhRole = await employeeService.GetRoleId(UserRolesParam.CFDH);

                            TmRoleToUserMapping roleCfdh = new TmRoleToUserMapping()
                            {
                                UserId = challengeDetailDTO.cfdhVal,
                                RoleId = CfdhRole.RoleId,
                                IsActive = 1,
                                CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                CreatedOn = DateTime.Now
                            };
                            tmRoleToUsers.Add(roleCfdh);

                            if (tmRoleToUsers.Any())
                            {
                                var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                            }

                            if (challengeDetailDTO.status.ToUpper() == "S" || challengeDetailDTO.status.ToUpper() == "A")
                            {
                                var result = await challengeService.UpdateChallengeResistrationStatus(challengeDetailDTO.status, challengeRegId, LoggedInUser, challengeDetailDTO.cfdhVal);
                                if (result > 0)
                                {
                                    var response = new TIP_RESULT()
                                    {
                                        message = ResponseStatus.success.ToString(),
                                        status = (int)ResponseStatus.success,
                                        TResponse = challengeDetailId
                                    };
                                    return Ok(response);
                                }
                                else
                                {
                                    var response = new TIP_RESULT()
                                    {
                                        message = "Update Challenge Status saved Failure.",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(response);
                                }
                            }
                            else
                            {
                                var response = new TIP_RESULT()
                                {
                                    message = ResponseStatus.success.ToString(),
                                    status = (int)ResponseStatus.success,
                                    TResponse = challengeDetailId
                                };
                                return Ok(response);
                            }

                        }
                        catch (Exception ex)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = GetUserFacingExceptionMessage(ex),
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                            return Ok(response);
                        }
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Challenge Solution Reviewer saved Failure.",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Challenge Details is not saved Failure.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddOrUpdateChallengeVOT")]
        [HttpPost]
        public async Task<IActionResult> AddOrUpdateChallengeVOT([Bind("")] ChallengeVOT_DTO challengeVOT_DTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                long challengeRegId = (long)CryptoExtensions.Decrypt(challengeVOT_DTO.challengeRegId).ToInt64();
                challengeVOT_DTO.challenge_id = challengeRegId;
                var result = await challengeService.AddOrUpdateVOT(ChallengeVOTDTOMapping(challengeVOT_DTO));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = challengeRegId
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateChallengeResistrationStatus")]
        [HttpPost]
        public async Task<IActionResult> UpdateChallengeResistrationStatus(RegistrationStatusDTO registrationStatusDTO)
        {
            try
            {
                long challengeRegId = (long)CryptoExtensions.Decrypt(registrationStatusDTO.schallengeRegId).ToInt64();
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await challengeService.UpdateChallengeResistrationStatus(registrationStatusDTO.status, challengeRegId, LoggedInUser, "", registrationStatusDTO.comments);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("UpdateChallengeUCTOwnership")]
        [HttpPost]
        public async Task<IActionResult> UpdateChallengeUCTOwnership([Bind("schallengeRegId")] RegistrationStatusDTO challengeDTO)
        {
            try
            {
                long challengeRegId = (long)CryptoExtensions.Decrypt(challengeDTO.schallengeRegId).ToInt64();
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await challengeService.UpdateChallengeUCTOwnership(challengeRegId, LoggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = result == 0 ? 0 : (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
        [Route("GetVOTConfigurations")]
        [HttpGet]
        public async Task<IActionResult> GetVOTConfigurations()
        {
            try
            {
               
                var result = await challengeService.GetVOTConfigurations();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetRequestorInfo/{challengeRegId}")]
        [HttpGet]
        public async Task<IActionResult> GetRequestorInfo(string challengeRegId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(challengeRegId).ToInt64();
                var result = await challengeService.GetRequestorInfo(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAllVendors/{challengeRegId}")]
        [HttpGet]
        public async Task<IActionResult> GetAllVendorScreening(string challengeRegId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(challengeRegId).ToInt64();
                var result = await challengeService.GetAllVendorScreening(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAllFiles/{challengeRegId}")]
        [HttpGet]
        public async Task<IActionResult> GetAllFiles(string challengeRegId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(challengeRegId).ToInt64();
                var result = await commonService.GetAllFilesByLinkId(Id, "Challenge Details", false);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetChallengeVOT/{challengeRegId}")]
        [HttpGet]
        public async Task<IActionResult> GetChallengeVOT(string challengeRegId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(challengeRegId).ToInt64();
                var result = await challengeService.GetChallengeVOT(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetChallengeQuestionaire/{challengeRegId}")]
        [HttpGet]
        public async Task<IActionResult> GetChallengeQuestionaire(string challengeRegId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(challengeRegId).ToInt64();
                var result = await challengeService.GetChallengeQuestionaire(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("AddOrUpdateVendorScreening")]
        [HttpPost]
        public async Task<IActionResult> AddOrUpdateVendorScreening(List<ChallengeVendorScreeningDTO> challengeVendorScreeningDTO, long challengeDetailId)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                bool isEdit = (!string.IsNullOrEmpty(challengeVendorScreeningDTO[0].challengeRegId)) ? true : false;

                List<ChallengeVendorScreening> challengeVSQList = new List<ChallengeVendorScreening>();
                foreach (var item in challengeVendorScreeningDTO)
                {
                    ChallengeVendorScreening ChallengeVendorScreening = new ChallengeVendorScreening();
                    ChallengeVendorScreening.ChallengeId = (long)CryptoExtensions.Decrypt(item.challengeRegId).ToInt64();
                    ChallengeVendorScreening.ChallengeDetailId = challengeDetailId;
                    ChallengeVendorScreening.Question = item.query;
                    ChallengeVendorScreening.Sequence = item.sequence;
                    ChallengeVendorScreening.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                    ChallengeVendorScreening.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                    ChallengeVendorScreening.CreatedOn = DateTime.Now;
                    challengeVSQList.Add(ChallengeVendorScreening);
                }
                var result = await challengeService.AddOrUpdateVendorScreening(challengeVSQList, isEdit);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddVendorScreening")]
        [HttpPost]
        public async Task<IActionResult> AddVendorScreening(ChallengeVendorScreeningDTO challengeVendorScreeningDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await challengeService.AddVendorScreening(ChallengeVendorScreeningDTOMapping(challengeVendorScreeningDTO, LoggedInUser));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateVendorScreening")]
        [HttpPost]
        public async Task<IActionResult> UpdateVendorScreening(ChallengeVendorScreeningDTO challengeVendorScreeningDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await challengeService.UpdateVendorScreening(ChallengeVendorScreeningDTOMapping(challengeVendorScreeningDTO, LoggedInUser));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteVendorScreening/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteVendorScreening(long id)
        {
            try
            {
                var result = await challengeService.DeleteVendorScreening(id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetChallengeDetail/{challengeRegId}")]
        [HttpGet]
        public async Task<IActionResult> GetChallengeDetail(string challengeRegId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(challengeRegId).ToInt64();
                var result = await challengeService.GetChallengeDetail(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("GetpublicationDetailsId/{challengeRegId}")]
        [HttpGet]
        public async Task<IActionResult> GetpublicationDetailsId(string challengeRegId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(challengeRegId).ToInt64();
                var result = await challengeService.GetChallengePublication(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        #region PDOToVendorQueries

        [Route("GetSolutionQuries/{solutionId}")]
        [HttpGet]
        public async Task<IActionResult> GetSolutionQuries(string solutionId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(solutionId).ToInt64();
                var result = await challengeService.GetPDOQueryResponseForInternal(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
              
        //UploadQueryResponseDoc
        [Route("UploadPDOQueryDoc")]
        [DisableRequestSizeLimit]
        [HttpPost]
        public async Task<IActionResult> UploadPDOQueryDoc()
        {
            try
            {
                EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();
                //if (Request.Form.Files.Any())
                //{
                var formCollection = await Request.ReadFormAsync();
                var query = Request.Form.Where(x => x.Key == "query").FirstOrDefault().Value;
                var solutionId= Request.Form.Where(x => x.Key == "cfcode").FirstOrDefault().Value;
                var responseId= (long)CryptoExtensions.Decrypt(solutionId).ToInt64();
                var queryId = await challengeService.AddPDOQueries(query, responseId, formCollection.Files.Count > 0,LoggedInUser);
                if (formCollection.Files.Count > 0)
                {
                    foreach (var file in formCollection.Files)
                    {
                        string uploadRoot = ResolveUploadRootPath();

                        string fileExtension = Normalize.parse(System.IO.Path.GetExtension(file.FileName).TrimStart(new char[] { '.' }));
                        string originalFileName = Normalize.parse(file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1));
                        string guidName = Normalize.parse("File-" + Guid.NewGuid().ToString() + DateTime.Today.Second.ToString() + "." + fileExtension);
                        long fileSizeibMbs = file.Length / (1024 * 1024);
                        if (fileSizeibMbs <= 20)
                        {
                            if (!string.IsNullOrEmpty(uploadRoot))
                            {
                                var FinalPath = Path.Combine(uploadRoot, guidName);
                                FinalPath = Normalize.parse(FinalPath);
                                if (IsAllowedUploadPath(FinalPath, uploadRoot, guidName))
                                {
                                    if (!System.IO.File.Exists(FinalPath))
                                    {
                                        using (Stream fileStream = new FileStream(FinalPath, FileMode.CreateNew))
                                        {
                                            await file.CopyToAsync(fileStream);
                                            if (System.IO.File.Exists(FinalPath))
                                            {
                                                //returnResponse.Result = 1;
                                                string MimeType = "";
                                                new FileExtensionContentTypeProvider().TryGetContentType(originalFileName, out MimeType);

                                                string ContentType = file.ContentType;
                                                
                                               

                                                DocumentRepo obj = new DocumentRepo()
                                                {
                                                    LimkType = "PDOtoVendorQuery",
                                                    LinkId = queryId,
                                                    FilePath = CryptoExtensions.Encrypt(FinalPath),
                                                    CreatedBy = LoggedInUser.COMPANY_NUMBER,
                                                    CreatedOn = DateTime.Now,
                                                    FileName = CryptoExtensions.Encrypt(guidName),
                                                    FileType = fileExtension,
                                                    Description = "Added With PDO to Vendor Query",
                                                    MimeType = ContentType,
                                                    IsActive = true,
                                                    IsExternalAccessible = true,
                                                };
                                                var Result = await commonService.AddDocument(obj);



                                            }
                                           
                                        }
                                    }
                                   
                                }
                               

                            }                           
                        }                       

                    }
                }

                var Id = (long)CryptoExtensions.Decrypt(solutionId).ToInt64();
                var result = await challengeService.GetPDOQueryResponseForInternal(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);

            }
        }
        



        #endregion





        #region VendorTochrQueries
        [Route("GetAllChallengeQuries")]
        [HttpGet]
        public async Task<IActionResult> GetAllChallengeQuries()
        {
            try
            {
                
                var result = await challengeService.GetAllVendorQueryAndResponseForInternal();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("GetChallengeQuries/{challengeRegId}")]
        [HttpGet]
        public async Task<IActionResult> GetChallengeQuries(string challengeRegId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(challengeRegId).ToInt64();
                var result = await challengeService.GetVendorQueryResponseForInternal(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        //UploadQueryResponseDoc
        [Route("UploadQueryResponseDoc")]
        [DisableRequestSizeLimit]
        [HttpPost]
        public async Task<IActionResult> UploadQueryResponseDoc()
        {
            try
            {
                EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();
                //if (Request.Form.Files.Any())
                //{
                var formCollection = await Request.ReadFormAsync();
                long queryId = (long)Convert.ToInt64(Request.Form.Where(x => x.Key == "queryId").FirstOrDefault().Value);
                long responseId = (long)Convert.ToInt64(Request.Form.Where(x => x.Key == "responseId").FirstOrDefault().Value);
                var queryRresponse = Request.Form.Where(x => x.Key == "response").FirstOrDefault().Value;
                var challengeRegId = Request.Form.Where(x => x.Key == "cfcode").FirstOrDefault().Value;
                if (responseId > 0)
                {
                    await challengeService.UpdateVendorQueryResponse(queryRresponse, responseId, formCollection.Files.Count > 0, queryId,LoggedInUser);
                    await commonService.DeleteDocument(responseId, "VendorQueryResponse");
                }
                else
                {
                    responseId = (challengeService.AddVendorQueryResponse(queryRresponse, queryId, formCollection.Files.Count > 0, LoggedInUser)).Result;
                }
                if (formCollection.Files.Count > 0)
                {
                    foreach (var file in formCollection.Files)
                    {
                        string uploadRoot = ResolveUploadRootPath();

                        string fileExtension = Normalize.parse(System.IO.Path.GetExtension(file.FileName).TrimStart(new char[] { '.' }));
                        string originalFileName = Normalize.parse(file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1));
                        string guidName = Normalize.parse("File-" + Guid.NewGuid().ToString() + DateTime.Today.Second.ToString() + "." + fileExtension);
                        long fileSizeibMbs = file.Length / (1024 * 1024);
                        if (fileSizeibMbs <= 20)
                        {
                            if (!string.IsNullOrEmpty(uploadRoot))
                            {

                                var FinalPath = Normalize.parse(Path.Combine(uploadRoot, guidName));

                                if (IsAllowedUploadPath(FinalPath, uploadRoot, guidName))
                                {
                                    if (!System.IO.File.Exists(FinalPath))
                                    {
                                        using (Stream fileStream = new FileStream(FinalPath, FileMode.CreateNew))
                                        {
                                            await file.CopyToAsync(fileStream);

                                            if (System.IO.File.Exists(FinalPath))
                                            {
                                                //returnResponse.Result = 1;

                                                string MimeType = "";
                                                new FileExtensionContentTypeProvider().TryGetContentType(originalFileName, out MimeType);

                                                string ContentType = file.ContentType;
                                              
                                                DocumentRepo obj = new DocumentRepo()
                                                {
                                                    LimkType = "VendorQueryResponse",
                                                    LinkId = responseId,
                                                    FilePath = CryptoExtensions.Encrypt(FinalPath),
                                                    CreatedBy = LoggedInUser.COMPANY_NUMBER,
                                                    CreatedOn = DateTime.Now,
                                                    FileName = CryptoExtensions.Encrypt(guidName),
                                                    FileType = fileExtension,
                                                    Description = "Added With Query Response",
                                                    MimeType = ContentType,
                                                    IsActive = true,
                                                    IsExternalAccessible = true,
                                                };
                                                var Result = await commonService.AddDocument(obj);



                                            }

                                        }
                                    }

                                }


                            }
                        }

                    }
                }

                var Id = (long)CryptoExtensions.Decrypt(challengeRegId).ToInt64();
                var result = await challengeService.GetVendorQueryResponseForInternal(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);

            }
        }
        [Route("UpdateQueryIsPublic")]
        [HttpPost]
        public async Task<IActionResult> UpdateQueryIsPublic(QueryDTO queryDTO)
        {
            try
            {
                long ChallengeId = (long)CryptoExtensions.Decrypt(queryDTO.cfcode).ToInt64();
                await challengeService.UpdateQueryIsPublic((long)queryDTO.queryId, (bool)queryDTO.status);
                var result = await challengeService.GetVendorQueryResponseForInternal(ChallengeId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("UpdateQueryAsRead")]
        [HttpPost]
        public async Task<IActionResult> UpdateQueryAsRead(QueryDTO queryDTO)
        {
            try
            {
                long ChallengeId = (long)CryptoExtensions.Decrypt(queryDTO.cfcode).ToInt64();
                await challengeService.UpdateQueryAsRead((long)queryDTO.queryId);
                var result = await challengeService.GetVendorQueryResponseForInternal(ChallengeId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        #endregion

        [Route("AddpublicationDetails")]
        [HttpPost]
        public async Task<IActionResult> AddpublicationDetails([Bind("")] challengePublishDetailsDTO DTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await challengeService.UpdatechallengePublication(DTO,false,LoggedInUser);

                UtlAuditTrail obj = new UtlAuditTrail()
                {
                    TableName = "Publication Details",
                    Action = "ADD/Update",
                    ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                    ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                    Description = JsonSerializer.Serialize(DTO),

                };
                await commonService.Log(obj);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("Updatepublicationchallenge")]
        [HttpPost]
        public async Task<IActionResult> Updatepublicationchallenge([Bind("")] challengePublishDetailsDTO DTO)
        {
            EmployeeDTO? emp= GetIdentityOfLoggedInUser();
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(DTO.challengeRegId).ToInt64();
                var result = await challengeService.UpdatechallengePublication(DTO, true,emp);
               
                

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
        private async System.Threading.Tasks.Task AddChlFlowHistoryAsync(long challengeId, long statusId, string comments, long currentRoleId, string descInfo, EmployeeDTO? LoggedInUser)
        {
            ChlFlowHistory obj = new ChlFlowHistory()
            {
                ChallengeId = challengeId,
                StatusId = statusId,
                Comments = comments,
                RoleId = currentRoleId,
                UserId = LoggedInUser?.COMPANY_NUMBER,
                CreatedOn = DateTime.Now,
                DescInfo = descInfo,
            };

            await challengeService.AddChallengeFlowHistory(obj);
        }
        private ChallengeVendorScreening ChallengeVendorScreeningDTOMapping(ChallengeVendorScreeningDTO challengeVendorScreeningDTO, EmployeeDTO employeeDTO)
        {
            ChallengeVendorScreening challengeVendorScreening = new ChallengeVendorScreening()
            {
                Id = challengeVendorScreeningDTO.id,
                ChallengeId = (long)CryptoExtensions.Decrypt(challengeVendorScreeningDTO.challengeRegId).ToInt64(),
                ChallengeDetailId = challengeVendorScreeningDTO.detailId,
                Question = challengeVendorScreeningDTO.query,
                Sequence = challengeVendorScreeningDTO.sequence,
            };
            if (challengeVendorScreening.Id > 0)
            {
                challengeVendorScreening.UpdatedBy = employeeDTO.COMPANY_NUMBER;
                challengeVendorScreening.UpdatedByRef = employeeDTO.REFERENCE_INDICATOR;
                challengeVendorScreening.UpdatedOn = DateTime.Now;
            }
            else
            {
                challengeVendorScreening.CreatedBy = employeeDTO.COMPANY_NUMBER;
                challengeVendorScreening.CreatedByRef = employeeDTO.REFERENCE_INDICATOR;
                challengeVendorScreening.CreatedOn = DateTime.Now;
            }

            return challengeVendorScreening;
        }

        private ChallengeDetail UserRoleDTOMapping(ChallengeDetailDTO challengeDetailDTO)
        {
            ChallengeDetail challengeDetail = new ChallengeDetail()
            {
                Id = challengeDetailDTO.id,
                ChallengeId = (long)CryptoExtensions.Decrypt(challengeDetailDTO.challengeRegId).ToInt64(),
                Title = challengeDetailDTO.title ?? string.Empty,
                ApplicationId = challengeDetailDTO.appId,
                AreaId = challengeDetailDTO.araId,
                Cfdh = challengeDetailDTO.cfdhVal ?? string.Empty,
                CurrentPractices = challengeDetailDTO.currPract ?? string.Empty,
                KeyRequirments = challengeDetailDTO.keyReq ?? string.Empty,
                MaturityLevelId = challengeDetailDTO.mId,
                OperatingEnvelopes = challengeDetailDTO.opEnvelop ?? string.Empty,
                PotentialScoreForecast = challengeDetailDTO.potScoreFC,
                ProblemStatement = challengeDetailDTO.probState,
                QueryLastdate = challengeDetailDTO.queryLD,
                ResponseLastdate = challengeDetailDTO.resLD,
                VendorSubmissionStartdate = challengeDetailDTO.venSubSD,
                ValueDrivers = challengeDetailDTO.valDrive ?? string.Empty,
                ThemeId = challengeDetailDTO.theId,
                SubThemeId = challengeDetailDTO.sTheId,
                ScoutingKeywords = challengeDetailDTO.scoutKey,
                TechnicalSpec = challengeDetailDTO.techSpec ?? string.Empty,
                Hserisk = challengeDetailDTO.hseRisk,
                Productionincrease = challengeDetailDTO.productionIncrease,
                Costreduction = challengeDetailDTO.cstReduction,
                Co2reduction = challengeDetailDTO.co2Reduction,
                Overallscore = challengeDetailDTO.overallScore,
                Pillar=challengeDetailDTO.pillar,
                RequestType=challengeDetailDTO.requestType,
                AssetId=challengeDetailDTO.assetId,
                ClusterId=challengeDetailDTO.clusterId
            };

            return challengeDetail;
        }

        private ChallengeVot ChallengeVOTDTOMapping(ChallengeVOT_DTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            

            ChallengeVot returnObj = new ChallengeVot()
            {
                ChallengeId = obj.challenge_id,
                UnitId = obj.unit_id,
                NoOfUnitsYear1 = obj.nofUnitYear1,
                NoOfUnitsYear2 = obj.nofUnitYear2,
                NoOfUnitsYear3 = obj.nofUnitYear3,
                NoOfUnitsYear4 = obj.nofUnitYear4,
                NoOfUnitsYear5 = obj.nofUnitYear5,
                NoOfUnitsTrailScope = obj.nofUnitTrailScope,
                TechCost = obj.techCst,
                OtherCost = obj.otherCst,
                AvgIncrmntlOilGain = obj.avgIncrementalOilGain,
                TotOilDefermentAvoidance = obj.totOilAvoidance,
                CostSavingUnitYr = obj.cspu,
                PowerSavingUnitYr = obj.powerSavingPerUnit,
                CostAvoidance = obj.cstAvoidance,
                Co2ReductnUnitYr = obj.co2ruy,
                Hse = obj.hseBenefits,
                Quality = obj.quality,
                Compliance = obj.compliance,
                RiskFactor = obj.riskFactor,
                M3T0Bbl = obj.m3tobbl,
                Co2Tax = obj.co2Tax,
                MwhCost = obj.mwhCst,
                OilPrice = obj.op,
                TotalMwhReduction = obj.totMWHReductionScope,
                TotalCo2Reduction = obj.totCO2Reduction,
                VotUnitYear = obj.votPerUnitPerYear,
                VotTrailTotUnits = obj.vottrialTotalUnits,
                VotTotDeploymentUnits = obj.votTotalDeploymentUnits,
                Id = obj.id
            };
                returnObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                returnObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                returnObj.CreatedOn = DateTime.Now;
           
            return returnObj;
        }

        #endregion  Challenge Detial & registration  ~ Fazal, Rahim IDAP1X

        #region Challenge registration Landing Page ~ Fazal, Rahim IDAP1X 

        




        [Route("GetChallengeRegistrationDetail")]
        [HttpGet]
        public async Task<IActionResult> GetChallengeRegistrationDetail()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await challengeService.GetChallengeRegistrationDetailDTO(LoggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetChallengePublicationListDetail")]
        [HttpGet]
        public async Task<IActionResult> GetChallengePublicationListDetail()
        {
            try
            {
                var result = await challengeService.GetChallengeRegistrationDetailDTO();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }




        [Route("FilterGetChallengeRegistration")]
        [HttpPost]
        public async Task<IActionResult> FilterGetChallengeRegistration(ChallengeRegistrationDetailFilterDTO challengeRegistrationDetailFilterDTO)
        {
            try
            {
                var result = await challengeService.FilterGetChallengeRegistration(challengeRegistrationDetailFilterDTO);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("LatestPublishChallenges")]
        [HttpGet]
        public async Task<IActionResult> LatestPublishChallenges()
        {
            try
            {
                var result = await challengeService.LatestPublishChallenges();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion Challenge registration Landing Page ~ Fazal, Rahim IDAP1X 

        #region Review
        [Route("getChallengesForReview")]
        [HttpGet]
        public async Task<IActionResult> getChallengesForReview()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await challengeService.GetChallengesForReview(LoggedInUser.ACTIVE_R_ID, LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region Challenge Solution Reviewer  ~ Fazal, Rahim IDAP1X

        [HttpGet]
        [Route("GetAllChallengeResponse/{roleId}")]

        public async Task<IActionResult> GetAllChallengeResponse(long roleId)
        {
            try
            {
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
				
				var result = await challengeService.GetAllChallengeResponse(roleId, LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [HttpPost]
        [Route("SetConfirmTech")]
        public async Task<IActionResult> SetConfirmTech(UpdateConfirmTechDTO updateConfirmTechDTO)
        {
            try
            {

                EmployeeDTO? loggedInUser = GetIdentityOfLoggedInUser();
                long Id = (long)CryptoExtensions.Decrypt(updateConfirmTechDTO.code).ToInt64();
                var result = await challengeService.SetConfirmTech(Id, updateConfirmTechDTO.isConfirm, loggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetChallengeResponseQuestions/{responseId}")]
        [HttpGet]

        public async Task<IActionResult> ChallengeResponseQuestions(string responseId)
        {
            try
            {
                long Id = (long)CryptoExtensions.Decrypt(responseId).ToInt64();
                var result = await challengeService.ChallengeResponseQuestions(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("GetSolutionTechDetails/{responseId}")]
        [HttpGet]

        public async Task<IActionResult> GetSolutionTechDetails(string responseId)
        {
            try
            {
                
                var result = await challengeService.SolutionTechDetailsByResponseId(responseId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("GetChallengeReview/{responseId}/{roleId}")]
        [HttpGet]
        public async Task<IActionResult> GetChallengeReview(string responseId, long roleId)
        {
            try
            {
                long Id = (long)CryptoExtensions.Decrypt(responseId).ToInt64();
				EmployeeDTO? loggedInUser = GetIdentityOfLoggedInUser();
				var result = await challengeService.GetChallengeReview(Id, roleId, loggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

		[Route("GetReviewerDetail/{responseId}")]
		[HttpGet]
		public async Task<IActionResult> GetReviewerDetail(string responseId)
		{
			try
			{
				long Id = (long)CryptoExtensions.Decrypt(responseId).ToInt64();				
				var result = await challengeService.GetReviewerDetail(Id);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
			}
		}

		[Route("AddSoultionReview")]
        [HttpPost]
        public async Task<IActionResult> AddSoultionReview([Bind("")] SolutionResponseReviewDTO solutionResponseReviewDTO)
        {
            try
            {
                EmployeeDTO? loggedInUser = GetIdentityOfLoggedInUser();                
                var result = await challengeService.AddSoultionReview(SolutionResponseReviewDTOMapping(solutionResponseReviewDTO), loggedInUser, solutionResponseReviewDTO.formStatus, solutionResponseReviewDTO.formBy);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateSoultionReview")]
        [HttpPost]
        public async Task<IActionResult> UpdateSoultionReviewStatus(UpdateSolutionReviewDTO updateSolutionReviewDTO)
        {
            try
            {
                EmployeeDTO? loggedInUser = GetIdentityOfLoggedInUser();
                long Id = (long)CryptoExtensions.Decrypt(updateSolutionReviewDTO.code).ToInt64();
                var result = await challengeService.UpdateSoultionReviewStatus(loggedInUser, Id, updateSolutionReviewDTO.status, updateSolutionReviewDTO.comment);
				
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
        [Route("GetSRFlowHistory/{cfCode}")]
        [HttpGet]
        public async Task<IActionResult> GetSRFlowHistory(string cfCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(cfCode);
                long Id = (long)IdData.ToInt64();

                var result = await challengeService.GetSRFlowHistory(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        private async System.Threading.Tasks.Task AddSRFlowHistoryAsync(long resId, long statusId, string comments, long currentRoleId, string descInfo)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            SrFlowHistory obj = new SrFlowHistory()
            {
                ResponseId = resId,//saving response id
                StatusId = statusId,
                Comments = comments,
                RoleId = currentRoleId,
                UserId = LoggedInUser?.COMPANY_NUMBER,
                CreatedOn = DateTime.Now,
                DescInfo = descInfo,
            };

            await challengeService.AddSRFlowHistory(obj);
        }


        [Route("SolutionMatrix")]
		[HttpPost]
		public async Task<IActionResult> SolutionMatrixDTO([Bind("")] SolutionMatrixDTO solutionMatrixDTO)
		{
			try
			{
				EmployeeDTO? loggedInUser = GetIdentityOfLoggedInUser();
				long Id = (long)CryptoExtensions.Decrypt(solutionMatrixDTO.code).ToInt64();
				var result = await challengeService.UpdateSoultionMatrix(loggedInUser, Id, solutionMatrixDTO);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
			}
		}

		[Route("SaveAllSRFiles")]
		[HttpPost]
		public async Task<IActionResult> UploadAllFiles([Bind("")] DocumentUploadDTO documentUploadDTO)
		{
			try
			{
				var IdData = CryptoExtensions.Decrypt(documentUploadDTO.code);
				long Id = (long)IdData.Split("-").Last().ToInt64();
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
				long result = 0;
				var res = await commonService.DeleteDocument(Id, "ChallengeResponse");
				foreach (var file in documentUploadDTO.files)
				{
					DocumentRepo obj = new DocumentRepo()
					{
						LimkType = file.type,
						LinkId = Id,
						FilePath = (file.filepath),
						CreatedBy = LoggedInUser.COMPANY_NUMBER,
						CreatedOn = DateTime.Now,
						FileName = CryptoExtensions.Encrypt(file.fileName),
						FileType = file.fileExtension,
						Description = file.description,
						MimeType = file.mimeType,
						IsActive = true,
						IsExternalAccessible = file.isEA,
					};
					result = await commonService.AddDocument(obj);
				}
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
			}
		}

		[Route("SaveAllSMFiles")]
		[HttpPost]
		public async Task<IActionResult> SaveAllSMFiles([Bind("")] DocumentUploadDTO documentUploadDTO)
		{
			try
			{
				var IdData = CryptoExtensions.Decrypt(documentUploadDTO.code);
				long Id = (long)IdData.Split("-").Last().ToInt64();
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
				long result = 0;
				var res = await commonService.DeleteDocument(Id, "SolutionMatrix");
				foreach (var file in documentUploadDTO.files)
				{
					DocumentRepo obj = new DocumentRepo()
					{
						LimkType = file.type,
						LinkId = Id,
						FilePath = (file.filepath),
						CreatedBy = LoggedInUser.COMPANY_NUMBER,
						CreatedOn = DateTime.Now,
						FileName = CryptoExtensions.Encrypt(file.fileName),
						FileType = file.fileExtension,
						Description = file.description,
						MimeType = file.mimeType,
						IsActive = true,
						IsExternalAccessible = file.isEA,
					};
					result = await commonService.AddDocument(obj);
				}
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
			}
		}

        [Route("GetAllChallengeResponseFiles/{responseId}")]
        [HttpGet]
        public async Task<IActionResult> GetAllChallengeResponseFiles(string responseId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(responseId).ToInt64();
                var result = await commonService.GetAllFilesByLinkId(Id, "ChallengeResponse", false);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAllChallengeResponseandQueryFiles/{responseId}")]
        [HttpGet]
        public async Task<IActionResult> GetAllChallengeResponseandQueryFiles(string responseId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(responseId).ToInt64();
                var result = await commonService.GetSolution_Query_Docs_ByRESP_Id(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAllChallengeMatrixFiles/{responseId}")]
		[HttpGet]
		public async Task<IActionResult> GetAllChallengeMatrixFiles(string responseId)
		{
			try
			{
				var Id = (long)CryptoExtensions.Decrypt(responseId).ToInt64();
				var result = await commonService.GetAllFilesByLinkId(Id, "SolutionMatrix", false);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
			}
		}

		#endregion


		#region Challenge Publication Details


		[Route("GetChallenge_Pub_Details/{challengeRegId}")]
        [HttpGet]
        public async Task<IActionResult> GetChallenge_Pub_Details(string challengeRegId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(challengeRegId).ToInt64();
                var result = await challengeService.GetChallengeDetail(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private List<ChallengeResponseReview> SolutionResponseReviewDTOMapping(SolutionResponseReviewDTO solutionResponseReviewDTO)
        {
            List<ChallengeResponseReview> challengeResponseReviewList = new List<ChallengeResponseReview>();
			EmployeeDTO? loggedInUser = GetIdentityOfLoggedInUser();

			for (int i = 0; i < solutionResponseReviewDTO.questions.Count; i++)
            {
                ChallengeResponseReview challengeResponseReview = new ChallengeResponseReview()
                {
                    Id = 0,
                    ChallengeResponseId = (long)CryptoExtensions.Decrypt(solutionResponseReviewDTO.reviewCode).ToInt64(),
                    ReviewComment = solutionResponseReviewDTO.review,
                    TechnologyStatus = bool.Parse(solutionResponseReviewDTO.confirmTech),
                    ReviewQuestionId = solutionResponseReviewDTO.questions[i].id,
                    Answer = solutionResponseReviewDTO.questions[i].answer,
                    Status = bool.Parse(solutionResponseReviewDTO.questions[i].status)
                };
				if (loggedInUser.ACTIVE_R_ID == Convert.ToInt64(UserRoleseEnum.SR))
				{
                    challengeResponseReview.IsSr = true;

                    //Moved below code to outside the if condition, because CreatedBy must be captured 
                    // challengeResponseReview.CreatedBy = loggedInUser.COMPANY_NUMBER;
                }
                challengeResponseReview.CreatedBy = loggedInUser?.COMPANY_NUMBER;

                challengeResponseReviewList.Add(challengeResponseReview);
            }
            return challengeResponseReviewList;
        }


        #endregion

        
        [Route("SolutionReviewerList/{challengeSolId}")]
        [HttpGet]
        public async Task<IActionResult> SolutionReviewerList(string challengeSolId)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(challengeSolId).ToInt64();
                var result = await challengeService.SolutionReviewerList(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ChallengeReassignmentList/{roleId}")]
        [HttpGet]
        public async Task<IActionResult> ChallengeReassignmentList(long roleId)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                var result = await challengeService.ChallengeReassignmentList(roleId, LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("SolutionReviewerByChaId/{chaId}")]
        [HttpGet]
        public async Task<IActionResult> SolutionReviewerByChaId(long chaId)
        {
            try
            {
                var result = await challengeService.SolutionReviewerByChaId(chaId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("getchallengeFP/{chaId}")]
        [HttpGet]
        public async Task<IActionResult> getchallengeFP(long chaId)
        {
            try
            {
                var result = await challengeService.getchallengeFP(chaId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("CFDHByChaId/{chaId}")]
        [HttpGet]
        public async Task<IActionResult> CFDHByChaId(long chaId)
        {
            try
            {
                var result = await challengeService.CFDHByChaId(chaId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ChangeUctFp")]
        [HttpPost]
        public async Task<IActionResult> ChangeUctFp(ChallengeReassignUCTDTO recevingDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var Id = recevingDTO.ChallengeId;
                if (Id > 0)
                {
                    TmUserRole AdminRole = await employeeService.GetRoleId(UserRolesParam.Administrator);

                    ChallengeRegistration dbObj = await challengeService.GetChallengeForReAssignment(Id);
                    dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                    dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                    dbObj.UpdatedOn = DateTime.Now;
                    dbObj.UctFp = recevingDTO.NewAdvisor.PERSONNEL_NUMBER;
                    var result = await challengeService.UpdateChallengeForReAssignment(dbObj);
                    if (result > 0)
                    {
                        List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                        TmUserRole UctRole = await employeeService.GetRoleId(UserRolesParam.UCT);

                        TmRoleToUserMapping roleUCT = new TmRoleToUserMapping()
                        {
                            UserId = recevingDTO.NewAdvisor.PERSONNEL_NUMBER,
                            RoleId = UctRole.RoleId,
                            IsActive = 1,
                            CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                            CreatedOn = DateTime.Now
                        };
                        tmRoleToUsers.Add(roleUCT);

                        if (tmRoleToUsers.Any())
                        {
                            var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                        }
                        await challengeService.SendReassignEmail(recevingDTO.ChallengeId, EmailModules.TMHPC, "TMH013", recevingDTO.ChaRefNo, recevingDTO.NewAdvisor, recevingDTO.OldUCTEmail, recevingDTO.CurrentAdvisorName, LoggedInUser, null);
                        await challengeService.SendReassignEmail(recevingDTO.ChallengeId, EmailModules.TMHPC, "TMH012", recevingDTO.ChaRefNo, recevingDTO.NewAdvisor, recevingDTO.OldUCTEmail, recevingDTO.CurrentAdvisorName, LoggedInUser, null);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);

                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "The Challenge record is not updated",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "The Challenge record is not exist",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);

                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("ChangeReviewFp")]
        [HttpPost]
        public async Task<IActionResult> ChangeReviewFp([Bind("")] ChallengeReassignReviewerDTO recevingDTO)
        {

            try
            {

                var response = new TIP_RESULT();
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                if (recevingDTO == null)
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Invalid request payload.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                if (recevingDTO.NewAdvisor == null || string.IsNullOrWhiteSpace(recevingDTO.NewAdvisor.PERSONNEL_NUMBER))
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Challenge requestor is required.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                if (recevingDTO.CFDH == null || string.IsNullOrWhiteSpace(recevingDTO.CFDH.PERSONNEL_NUMBER))
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "CFDH is required.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                if (recevingDTO.SolutionReviewers == null || recevingDTO.SolutionReviewers.Count == 0
                    || recevingDTO.SolutionReviewers.All(x => string.IsNullOrWhiteSpace(x.PERSONNEL_NUMBER)))
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "At least one solution reviewer is required.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                var Id = recevingDTO.ChallengeId;
                if (Id > 0)
                {
                    ChallengeRegistration dbObj = await challengeService.GetChallengeForReAssignment(Id);
                    dbObj.UpdatedBy = LoggedInUser?.COMPANY_NUMBER ?? dbObj.UpdatedBy;
                    dbObj.UpdatedByRef = LoggedInUser?.REFERENCE_INDICATOR ?? dbObj.UpdatedByRef;
                    dbObj.UpdatedOn = DateTime.Now;
                    dbObj.RequestedBy = recevingDTO.NewAdvisor.PERSONNEL_NUMBER.Trim();

                    
                    ChallengeDetail dbchDetailObj = await challengeService.GetChallengeDetailForReAssignment(Id);
                  
                    string oldcfdh = dbchDetailObj.Cfdh;
                    dbchDetailObj.Cfdh = recevingDTO.CFDH.PERSONNEL_NUMBER.Trim();

                

                    var result = await challengeService.UpdateChallengeForReAssignment(dbObj);
                    if(result > 0)
                    {
                        var result1 = await challengeService.UpdateChallengeDetailsForReAssignment(dbchDetailObj);
                        if (result1 > 0) 
                        {
                            List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                            TmUserRole CRRole = await employeeService.GetRoleId(UserRolesParam.ChallengeRequestor);

                            TmRoleToUserMapping roleCR = new TmRoleToUserMapping()
                            {
                                UserId = recevingDTO.NewAdvisor.PERSONNEL_NUMBER.Trim(),
                                RoleId = CRRole.RoleId,
                                IsActive = 1,
                                CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                CreatedOn = DateTime.Now
                            };
                            tmRoleToUsers.Add(roleCR);


                            //If CFDH changed then sent email   -- Hafiz Husnain MUCI189
                            if (!string.IsNullOrWhiteSpace(oldcfdh) && oldcfdh != recevingDTO.CFDH.PERSONNEL_NUMBER)
                            {
                                var oldcfdhobj =  await employeeService.getByMuNumber(oldcfdh);
                                await challengeService.SendReassignEmail(recevingDTO.ChallengeId, EmailModules.TMHPC, "TMH018", recevingDTO.ChaRefNo, recevingDTO.CFDH, oldcfdhobj.EMAIL_ADDRESS, recevingDTO.CurrentAdvisorName, LoggedInUser, null);
                                await challengeService.SendReassignEmail(recevingDTO.ChallengeId, EmailModules.TMHPC, "TMH019", recevingDTO.ChaRefNo, recevingDTO.CFDH, oldcfdhobj.EMAIL_ADDRESS, oldcfdhobj.DISPLAY_NAME, LoggedInUser, null);
                            }
                            //If FP changed then sent email   -- Hafiz Husnain MUCI189
                            if (recevingDTO.NewAdvisor?.EMAIL_ADDRESS != recevingDTO.OldCREmail)
                            {
                                await challengeService.SendReassignEmail(recevingDTO.ChallengeId, EmailModules.TMHPC, "TMH015", recevingDTO.ChaRefNo, recevingDTO.NewAdvisor, recevingDTO.OldCREmail, recevingDTO.CurrentAdvisorName, LoggedInUser, null);
                                await challengeService.SendReassignEmail(recevingDTO.ChallengeId, EmailModules.TMHPC, "TMH014", recevingDTO.ChaRefNo, recevingDTO.NewAdvisor, recevingDTO.OldCREmail, recevingDTO.CurrentAdvisorName, LoggedInUser, null);
                            }

                            TmUserRole SRRole = await employeeService.GetRoleId(UserRolesParam.SolutionReviewer);

                            var solObj = await challengeService.SolutionReviewerListByChaId(Id);
                            if (solObj == null || solObj.Count == 0 || solObj[0].chaDetailId == null)
                            {
                                return Ok(new TIP_RESULT()
                                {
                                    message = "Challenge detail could not be resolved for solution reviewers.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                });
                            }

                            List<ChallengeSolutionReviewer> FocalPoints = new List<ChallengeSolutionReviewer>();
                            foreach (AllPDOUsersDTO reviewer in recevingDTO.SolutionReviewers)
                            {
                                if (string.IsNullOrWhiteSpace(reviewer.PERSONNEL_NUMBER))
                                    continue;

                                var reviewerMu = reviewer.PERSONNEL_NUMBER.Trim();
                                if (reviewerMu.Length > 10)
                                    reviewerMu = reviewerMu.Substring(0, 10);

                                ChallengeSolutionReviewer SR = new ChallengeSolutionReviewer()
                                {
                                    ChallengeId = Id,
                                    ChallengeDetailId = solObj[0].chaDetailId.Value,
                                    Reviewer = reviewerMu,
                                    IsReviewed = false
                                };
                                FocalPoints.Add(SR);
                                TmRoleToUserMapping roleMTFP = new TmRoleToUserMapping()
                                {
                                    UserId = reviewerMu,
                                    RoleId = SRRole.RoleId,
                                    IsActive = 1,
                                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now
                                };
                                tmRoleToUsers.Add(roleMTFP);
                            }

                            if (FocalPoints.Count == 0)
                            {
                                return Ok(new TIP_RESULT()
                                {
                                    message = "At least one valid solution reviewer is required.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                });
                            }

                            var res = await challengeService.AddChallengeReviewersForReAssignment(FocalPoints, recevingDTO, LoggedInUser, solObj);
                            if (tmRoleToUsers.Any())
                            {
                                var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                            }

                            response = new TIP_RESULT()
                            {
                                message = ResponseStatus.success.ToString(),
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);

                        }
                         response = new TIP_RESULT()
                        {
                            message = "The Challenge Details record is not updated",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);

                    }
                    else
                    {
                         response = new TIP_RESULT()
                        {
                            message = "The Challenge record is not updated",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }

                }
                else
                {
                     response = new TIP_RESULT()
                    {
                        message = "The Challenge record is not exist",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);

                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("OverAllReport")]
        [HttpPost]
        public async Task<IActionResult> OverAllReport([Bind("")] OverAllReportRequestDTO overAllReportDTO)
        {
			try
			{
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                var result = await challengeService.OverAllReport(overAllReportDTO, LoggedInUser);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}
		}

        [Route("OARPrint")]
        [HttpPost]
        public async Task<IActionResult> OARPrint([Bind("")] OverAllReportRequestDTO overAllReportDTO)
        {
            try
            {
                var result = await challengeService.OARPrint(overAllReportDTO);
				var response = new FileContentResult(result.FileBytes, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(result.Type));
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}
		}

		[Route("TechKPIReport")]
		[HttpPost]
		public async Task<IActionResult> TechKPIReport([Bind("")] TechKPIReportRequestDTO techKPIReportDTO)
		{
			try
			{
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

				var result = await challengeService.TechKPIReport(techKPIReportDTO, LoggedInUser);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}
		}

		[Route("TKRPrint")]
		[HttpPost]
		public async Task<IActionResult> TKRPrint([Bind("")] TechKPIReportRequestDTO techKPIReportDTO)
		{
			try
			{
				var result = await challengeService.TKRPrint(techKPIReportDTO);
				var response = new FileContentResult(result.FileBytes, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(result.Type));
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}
		}

		[Route("MasterReport")]
		[HttpPost]
		public async Task<IActionResult> MasterReport([Bind("")] MasterReportRequestDTO masterReportRequestDTO)
		{
			try
			{
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                var result = await challengeService.MasterReport(masterReportRequestDTO, LoggedInUser);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}
		}

        [Route("MasterReportPrint")]
        [HttpPost]
        public async Task<IActionResult> MasterReportPrint( [Bind("")] MasterReportRequestDTO masterReportRequestDTO)
        {
            try
            {
                var result = await challengeService.MasterReportPrint(masterReportRequestDTO);
                var response = new FileContentResult(result.FileBytes, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(result.Type));
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

       
        [Route("GetChlFlowHistory/{chlCode}")]
        [HttpGet]
        public async Task<IActionResult> GetChlFlowHistory(string chlCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(chlCode);
                long ChlId = (long)IdData.Split("-").Last().ToInt64();

                var result = await challengeService.GetChlHistoryById(ChlId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("GetChallengesResponseReport")]
        [HttpPost]
        public async Task<IActionResult> GetChallengesResponseReport([Bind("")] ChallengeReportRequestDTO ChallengeReportRequestDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await challengeService.GetChallengesResponseReport(ChallengeReportRequestDTO, LoggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("PrintChallengesResponseReport")]
        [HttpPost]
        public async Task<IActionResult> PrintChallengesResponseReport([Bind("")] ChallengeReportRequestDTO ChallengeReportRequestDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await challengeService.PrintChallengesResponseReport(ChallengeReportRequestDTO, LoggedInUser);
                var response = new FileContentResult(result.FileBytes, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(result.Type));
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private string ResolveUploadRootPath()
        {
            string configuredNas = string.Empty;
            try
            {
                if (string.Equals(Configuration["ServerMode"], "Prod", StringComparison.OrdinalIgnoreCase))
                    configuredNas = CryptoExtensions.Decrypt(Configuration["EncryptedNASPathS"] ?? string.Empty);
                else
                    configuredNas = CryptoExtensions.Decrypt(Configuration["EncryptedNASPathD"] ?? string.Empty);
            }
            catch
            {
                configuredNas = string.Empty;
            }

            configuredNas = NormalizeUncPath(configuredNas);

            bool useLocal = string.Equals(Configuration["UseLocalFileStorage"], "true", StringComparison.OrdinalIgnoreCase);
            string localPath = Configuration["LocalUploadPath"] ?? string.Empty;

            if (!useLocal && !string.IsNullOrWhiteSpace(configuredNas) && Directory.Exists(configuredNas))
                return configuredNas.EndsWith("\\") ? configuredNas : configuredNas + "\\";

            if (string.IsNullOrWhiteSpace(localPath))
                localPath = Path.Combine(AppContext.BaseDirectory, "App_Data", "Uploads");

            Directory.CreateDirectory(localPath);
            return localPath.EndsWith("\\") ? localPath : localPath + "\\";
        }

        private static string NormalizeUncPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return string.Empty;

            if (path.StartsWith(@"\\", StringComparison.Ordinal))
            {
                var trimmed = path.TrimStart('\\');
                trimmed = trimmed.Replace(@"\\", @"\");
                return @"\\" + trimmed;
            }

            return path;
        }

        private static bool IsAllowedUploadPath(string finalPath, string rootPath, string guidName)
        {
            if (string.IsNullOrWhiteSpace(finalPath) || string.IsNullOrWhiteSpace(rootPath))
                return false;

            try
            {
                if (guidName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
                    return false;

                if (!Path.IsPathRooted(finalPath) || Path.GetFileName(finalPath) != guidName)
                    return false;

                string fullFile = Path.GetFullPath(finalPath);
                string fullRoot = Path.GetFullPath(rootPath);
                if (!fullRoot.EndsWith(Path.DirectorySeparatorChar.ToString()) &&
                    !fullRoot.EndsWith(Path.AltDirectorySeparatorChar.ToString()))
                    fullRoot += Path.DirectorySeparatorChar;

                return fullFile.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }
	}
}
