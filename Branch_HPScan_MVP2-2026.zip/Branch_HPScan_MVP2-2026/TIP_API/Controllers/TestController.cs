﻿using Microsoft.AspNetCore.Mvc;
using System.Text;
using TIP_API.DTO;
using TIP_BAL.Interface;
using TIP_BAL.Interface.Admin;
using TIP_BAL.BackgroundServices;
using TIP_BAL.Services.Admin;
using TIP_BusinessLogic.Interface;
using TIP_Common.Helpers;
using TIP_CORE.EntitiesDTO;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : BaseController
    {
        private readonly IEmailDiagnosticService _emailDiagnostic;
        private readonly PeriodicHostedService? _periodicHosted;

        public TestController(
            ICommonService _commonService,
            IEmailDiagnosticService emailDiagnostic,
            PeriodicHostedService? periodicHosted = null) : base(_commonService)
        {
            _emailDiagnostic = emailDiagnostic;
            _periodicHosted = periodicHosted;
        }

        [HttpGet("M1")]
        public IActionResult M1()
        {
            try
            {
                string UserName = AccountHelper.GetWinAuthAccount(HttpContext).Trim();
                return Ok(UserName);
            }
            catch (Exception ex)
            {
                StringBuilder sb = new StringBuilder();
                if (ex != null)
                {
                    sb.AppendLine("An exception occurred: ");
                    sb.AppendLine(ex.Message);
                    if (ex.StackTrace != null)
                    {
                        sb.AppendLine("StackTrace: ");
                        sb.AppendLine(ex.StackTrace);
                    }
                    // Check for inner exception
                    if (ex.InnerException != null)
                    {
                        sb.AppendLine("Inner Exception: ");
                        sb.AppendLine(ex.InnerException.Message);
                        if (ex.InnerException.StackTrace != null)
                        {
                            sb.AppendLine(ex.InnerException.StackTrace);
                        }
                    }
                }
                else
                {
                    sb.AppendLine("An unknown exception occurred.");
                }

                return Ok(sb.ToString());
            }
            

        }
        [HttpGet("M2")]
        public IActionResult M2()
        {
            try
            {
                string UserName = AccountHelper.GetWinAuthAccount(HttpContext).Trim();
                if (!string.IsNullOrWhiteSpace(UserName))
                {
                    EmployeeDTO? loggedinuser = commonService.GetIdentityOfLoggedInUser(UserName);
                    if (loggedinuser == null)
                    {
                        return Ok(false);
                    }
                    else
                    {
                        return Ok(loggedinuser);
                    }
                }
                return Ok(UserName);
            }
            catch(Exception ex)
            {
                StringBuilder sb = new StringBuilder();
                if (ex != null)
                {
                    sb.AppendLine("An exception occurred: ");
                    sb.AppendLine(ex.Message);
                    if (ex.StackTrace != null)
                    {
                        sb.AppendLine("StackTrace: ");
                        sb.AppendLine(ex.StackTrace);
                    }
                    // Check for inner exception
                    if (ex.InnerException != null)
                    {
                        sb.AppendLine("Inner Exception: ");
                        sb.AppendLine(ex.InnerException.Message);
                        if (ex.InnerException.StackTrace != null)
                        {
                            sb.AppendLine(ex.InnerException.StackTrace);
                        }
                    }
                }
                else
                {
                    sb.AppendLine("An unknown exception occurred.");
                }

                return Ok(sb.ToString());
            }

        }
        [HttpGet("M3")]
        public IActionResult M3()
        {
            try
            {
                StringBuilder sb = new StringBuilder();

                string UserName = AccountHelper.GetWinAuthAccount(HttpContext).Trim();

                sb.AppendLine("UserName : " + UserName);

                //Check if MU only
                var isNumeric = int.TryParse(UserName.ToUpper().Split("MU")[1], out int n);

                sb.AppendLine("isNumeric : " + isNumeric);

                if (isNumeric || UserName.Split("\\")[1].ToUpper().StartsWith("MUC"))
                {
                    sb.AppendLine("UserName.Split(\"\\\\\")[1].ToUpper().StartsWith(\"MUC\") : " + UserName.Split("\\")[1].ToUpper().StartsWith("MUC"));

                    sb.AppendLine("UserName.Split(\"\\\\\")[1] : " + UserName.Split("\\")[1]);

                    return Ok(sb.ToString());
                }
                else
                {
                    return Ok(null);
                }

            }
            catch (Exception ex)
            {
                StringBuilder sb = new StringBuilder();
                if (ex != null)
                {
                    sb.AppendLine("An exception occurred: ");
                    sb.AppendLine(ex.Message);
                    if (ex.StackTrace != null)
                    {
                        sb.AppendLine("StackTrace: ");
                        sb.AppendLine(ex.StackTrace);
                    }
                    // Check for inner exception
                    if (ex.InnerException != null)
                    {
                        sb.AppendLine("Inner Exception: ");
                        sb.AppendLine(ex.InnerException.Message);
                        if (ex.InnerException.StackTrace != null)
                        {
                            sb.AppendLine(ex.InnerException.StackTrace);
                        }
                    }
                }
                else
                {
                    sb.AppendLine("An unknown exception occurred.");
                }

                return Ok(sb.ToString());
            }

        }

        /// <summary>
        /// Email pipeline diagnostic — supply To, Subject, Body; no templates required.
        /// </summary>
        [HttpPost("EmailDiagnostic")]
        public async Task<IActionResult> EmailDiagnostic([FromBody] EmailDiagnosticRequest request, CancellationToken cancellationToken)
        {
            try
            {
                var dto = new EmailDiagnosticRequestDto
                {
                    To = request.To ?? string.Empty,
                    Cc = request.Cc,
                    Subject = request.Subject ?? string.Empty,
                    Body = request.Body ?? string.Empty,
                    Steps = request.Steps,
                    RunWorkerAfterQueue = request.RunWorkerAfterQueue,
                    ProcessEmailRepoId = request.ProcessEmailRepoId
                };

                var report = await _emailDiagnostic.RunAsync(dto, _periodicHosted?.IsEnabled, cancellationToken);
                return Ok(new TIP_RESULT
                {
                    status = report.OverallSuccess ? (int)ResponseStatus.success : (int)ResponseStatus.error,
                    message = report.OverallSuccess ? "Diagnostic completed." : "One or more steps failed — see TResponse.steps.",
                    TResponse = report
                });
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(new TIP_RESULT
                {
                    status = (int)ResponseStatus.error,
                    message = ex.Message,
                    TResponse = ex.ToString()
                });
            }
        }

        /// <summary>Config + scheduler status only (no send).</summary>
        [HttpGet("EmailDiagnostic/Status")]
        public async Task<IActionResult> EmailDiagnosticStatus(CancellationToken cancellationToken)
        {
            try
            {
                var report = await _emailDiagnostic.GetEnvironmentStatusAsync(_periodicHosted?.IsEnabled, cancellationToken);
                return Ok(new TIP_RESULT
                {
                    status = report.OverallSuccess ? (int)ResponseStatus.success : (int)ResponseStatus.error,
                    message = "Environment status.",
                    TResponse = report
                });
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(new TIP_RESULT
                {
                    status = (int)ResponseStatus.error,
                    message = ex.Message,
                    TResponse = ex.ToString()
                });
            }
        }


    }
}
