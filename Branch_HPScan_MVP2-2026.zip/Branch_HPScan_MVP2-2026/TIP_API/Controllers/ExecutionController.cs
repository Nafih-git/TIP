using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics.Eventing.Reader;
using System.Numerics;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Linq;
using TIP_API.DTO;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using TIP_BusinessLogic.Interface;
using TIP_Common;
using TIP_Common.Admin;
using TIP_Common.Helpers;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using static TIP_Common.Enum.Enum;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExecutionController : BaseController
    {
        private readonly ICtrService ctrService;
        private readonly IExecutionService executionService;
        private readonly IEmployeeService employeeService;
        ILogger<ExecutionController> logger = null;
        public ExecutionController(ICommonService _commonService, ICtrService _ctrService, IEmployeeService _employeeService, IExecutionService _executionService, ILogger<ExecutionController> _logger) : base(_commonService)
        {
            ctrService = _ctrService;
            executionService = _executionService;
            employeeService = _employeeService;
            logger = _logger;
        }


        [Route("GetApprovedCtr")]
        [HttpGet]
        public async Task<IActionResult> GetApprovedCtr()
        {

            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {
            

                var result = await executionService.GetApprovedCtr(LoggedInUser.COMPANY_NUMBER);


                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                 var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };

                return Ok(response);
            }
        }

        [Route("GetExecutionReAssignment/{roleId}")]
        [HttpGet]
        public async Task<IActionResult> GetExecutionReAssignment(long roleId)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            try
            {
               
                var result = await executionService.GetAllExecutionforReAssignment(roleId, LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("GetApprovedExecutionPlanned")]
        [HttpGet]
        public async Task<IActionResult> GetApprovedExecutionPlanned()
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            try
            {
                var result = await executionService.GetActualPlanGrid(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("GetOverallProgress")]
        [HttpGet]
        public async Task<IActionResult> GetOverallProgress()
        {
            try
            {
                var result = await executionService.GetOverallProgress();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }





        [Route("GetinitiatedTrialForExecution")]
        [HttpGet]
        public async Task<IActionResult> GetinitiatedTrialForExecution()
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {
               var result = await executionService.GetinitiatedTrialForExecution(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }




        [Route("GetInitiatedExecution")]
        [HttpGet]
        public async Task<IActionResult> GetInitiatedExecution()
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            try
            {
                var result = await executionService.GetApprovedCtr(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


    
 [Route("GetTrialFPForExecbyId/{CtrIdEnc}")]
        [HttpGet]
        public async Task<IActionResult> GetTrialFPForExecbyId(long CtrIdEnc)
        {
            try
            {
               
                var result = await executionService.GetTrialFPForExecbyId(CtrIdEnc);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        [Route("GetExecTrialFPs/{CtrIdEnc}")]
        [HttpGet]
        public async Task<IActionResult> GetExecTrialFPs(string CtrIdEnc)
        {
            try
            {
                long ctrIdl = 0;
                var ctridData = CryptoExtensions.Decrypt(CtrIdEnc);
                ctrIdl = (long)ctridData.Split("-").Last().ToInt64();
                var result = await executionService.GetTrialFPForExec(ctrIdl);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }



        [Route("GetStageDataByExec/{ExecIdEnc}")]
        [HttpGet]
        public async Task<IActionResult> GetStageDataByExec(string ExecIdEnc)
        {
            try
            {
                var response = new TIP_RESULT();
                if (ExecIdEnc != "undefined")
                {
                    long exeIdl = 0;
                    var execidData = CryptoExtensions.Decrypt(ExecIdEnc);
                    
                    exeIdl = (long)execidData.Split("-").Last().ToInt64();
                    var result = await executionService.GetStagesDataByexec((long)exeIdl);
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        private ExecutionPlannedTimeline ExecutionPlannedTimelineDTOMapping(ExecutionPlannedTimelinesDTO obj)
        {
            ExecutionPlannedTimeline dbObj = new ExecutionPlannedTimeline();
            dbObj.Stage = obj.type1 == 1 ? obj.stageId == null ? "" : obj.stageId.ToString() : obj.stage == null ? "" : obj.stage.ToString();
            dbObj.Activity = obj.activity == null ? "" : obj.activity.ToString();
            dbObj.Cost = obj.cst;
            dbObj.Enddate = obj.enddate == "" || obj.enddate == null ? null : (DateTime)obj.enddate.ToDateTime();
            dbObj.Startdate = obj.startdate == "" || obj.startdate == null ? null : (DateTime)obj.startdate.ToDateTime();
            dbObj.ExecId = (long)obj.exec_id;
            dbObj.MilestoneType = obj.chkDpayment == true && obj.chkIsDeliveryMilestone == true ? 3 : obj.chkIsDeliveryMilestone == true ? 1 : obj.chkDpayment == true ? 2 : 0;
            dbObj.PartyName = obj.partyName == null ? "" : obj.partyName.ToString();
            dbObj.PlannedDayes = obj.planned_days == null ? 0 : obj.planned_days;
            dbObj.Type = obj.type1 == 0 ? false : true;
            dbObj.Id = (long)obj.id;
            dbObj.Stagesort = obj.SortOrderStage == null ? 0 : obj.SortOrderStage;
            dbObj.Activitysort = obj.SortOrderActivity == null ? 0 : obj.SortOrderActivity;
            return dbObj;
        }
        private async Task<ExecutionPlanned> ExecutionPlannedDTOMapping(ExecutionPlannedDTO obj, ExecutionPlanned dbObj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            dbObj.ExeId = obj.exe_ID;
            dbObj.Comments = obj.comments == null ? "" : obj.comments.ToString();
            dbObj.Reason = obj.reason == null ? "" : obj.reason.ToString();
            dbObj.UpdatedBy = obj.updated_by == null ? "" : obj.updated_by.ToString();
            dbObj.UpdatedOn = DateTime.Now;
            return dbObj;
        }

        /// <summary>
        /// Audit-trail serialize for EF entities. Avoids StatusNavigation ↔ ExecutionPlanneds cycles.
        /// </summary>
        private static string SerializeForAudit(object entity)
        {
            return JsonSerializer.Serialize(entity, new JsonSerializerOptions
            {
                ReferenceHandler = ReferenceHandler.IgnoreCycles
            });
        }


        [Route("GetAllFiles/{execCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllFiles(string execCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(execCode);
                long Id = (long)IdData.Split("-").Last().ToInt64();
                var result = await commonService.GetAllFilesByLinkId(Id, "ExecutionPlanForm", false);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }






        [Route("SaveAllFiles")]
        [HttpPost]
        public async Task<IActionResult> UploadAllFiles([Bind("")] DocumentUploadDTO documentUploadDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {
                var IdData = CryptoExtensions.Decrypt(documentUploadDTO.code);
                long Id = (long)IdData.Split("-").Last().ToInt64();
                long result = 0;
                var res = await commonService.DeleteDocument(Id, "ExecutionPlanForm");
                foreach (var file in documentUploadDTO.files)
                {
                    DocumentRepo obj = new DocumentRepo()
                    {
                        LimkType = file.type,
                        LinkId = Id,
                        FilePath = (file.filepath),
                        CreatedBy = LoggedInUser.COMPANY_NUMBER,
                        CreatedOn = DateTime.Now,
                        FileName = CryptoExtensions.Encrypt(file.fileName),
                        FileType = file.fileExtension,
                        Description = file.description,
                        MimeType = file.mimeType,
                        IsActive = true,
                        IsExternalAccessible = file.isEA,
                    };
                    result = await commonService.AddDocument(obj);
                }
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }





        [Route("GetAllActualFiles/{actValID}")]
        [HttpGet]
        public async Task<IActionResult> GetAllActualFiles(string actValID)
        {
            try
            {
                var result = await commonService.GetAllFilesByLinkId((long)actValID.ToInt64(), "ActualPlanTimeLine", false);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }
        

        [Route("SaveAllActualFiles")]
        [HttpPost]
        public async Task<IActionResult> UploadAllActualFiles([Bind("")] DocumentUploadDTO documentUploadDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {
                
                long Id = (long)documentUploadDTO.code.ToInt64();
                long result = 0;
                var res = await commonService.DeleteDocument(Id, "ActualPlanTimeLine");
                foreach (var file in documentUploadDTO.files)
                {
                    DocumentRepo obj = new DocumentRepo()
                    {
                        LimkType = file.type,
                        LinkId = Id,
                        FilePath = (file.filepath),
                        CreatedBy = LoggedInUser.COMPANY_NUMBER,
                        CreatedOn = DateTime.Now,
                        FileName = CryptoExtensions.Encrypt(file.fileName),
                        FileType = file.fileExtension,
                        Description = file.description,
                        MimeType = file.mimeType,
                        IsActive = true,
                        IsExternalAccessible = file.isEA,
                    };
                    result = await commonService.AddDocument(obj);
                }
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        private async Task AddExeFlowHistoryAsync(long ExeId, long statusId, string comments, long currentRoleId, string descInfo)
        {
            try
            {
                

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                ExeFlowHistory obj = new ExeFlowHistory()
                {
                    Id = 0,
                    ExeId = ExeId,
                    StatusId = statusId,
                    Comments = comments,
                    RoleId = currentRoleId,
                    UserId = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    DescInfo = descInfo,
                };

                var result = await executionService.AddExeFlowHistory(obj);

            }
            catch (Exception)
            {
                throw;
            }
        }


        private async Task AddExePlanFlowHistoryAsync(long plan, long statusId, string comments, long currentRoleId, string descInfo)
        {
            try
            {
                

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                ExeFlowHistory obj = new ExeFlowHistory()
                {
                    Id = 0,
                    PlanId = plan,
                    StatusId = statusId,
                    Comments = comments,
                    RoleId = currentRoleId,
                    UserId = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    DescInfo = descInfo,
                };

                var result = await executionService.AddExeFlowHistory(obj);

            }
            catch (Exception)
            {
                throw;
            }
        }

        private async Task AddExeApprovedPlanFlowHistoryAsync(long plan, long statusId, string comments, long currentRoleId, string descInfo)
        {
            try
            {
               

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                ExeFlowHistory obj = new ExeFlowHistory()
                {
                    Id = 0,
                    AppPlanid = plan,
                    StatusId = statusId,
                    Comments = comments,
                    RoleId = currentRoleId,
                    UserId = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    DescInfo = descInfo,
                };

                var result = await executionService.AddExeFlowHistory(obj);

            }
            catch (Exception)
            {
                throw;
            }
        }



        [Route("SendBackExecutionPlan")]
        [HttpPost]
        public async Task<IActionResult> SendBackExecutionPlan([Bind("")] ExecutionPlannedDTO recevingDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster SentBackStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionPlanned, ExecutionPlannedStatus.Sentback);

                var IdData = CryptoExtensions.Decrypt(recevingDTO.exe_Code);
                long Id = (long)IdData.Split("-").Last().ToInt64();
                recevingDTO.exe_ID = Id;



                if (Id > 0)
                {
                    ExecutionPlanned dbObj = await executionService.GetexecutionPlanById(Id);

                    if (dbObj != null && SentBackStatus != null)
                    {

                        var addObj = await ExecutionPlannedDTOMapping(recevingDTO, dbObj);
                        addObj.Status = SentBackStatus.Id;
                        addObj.SentbackOn = DateTime.Now;
                        addObj.LastReminder = null;
                        addObj.SubmittedOn = null;
                        addObj.SentbackBy = "UCT";


                        var result = await executionService.UpdateexecutionPlan(addObj);
                        if (result > 0)
                        {
                            UtlAuditTrail obj = new UtlAuditTrail()
                            {
                                TableName = "Update Execution Plan",
                                Action = "Update Send Back",
                                ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                                ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                                Description = SerializeForAudit(addObj),

                            };
                            await commonService.Log(obj);

                            await executionService.SendExecutionEmail(Convert.ToInt64(addObj.ExeId), EmailModules.EXEC, "EXEC008", LoggedInUser, addObj.Reason);
                            
                            await AddExePlanFlowHistoryAsync(addObj.Id, (long)addObj.Status, addObj.Reason, (long)LoggedInUser.ACTIVE_R_ID, "Execution Plan Sentback Successfully");
                            ReturnMessage = "Execution Plan Sent back successfully.";
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.exe_Code;
                        }
                        else
                        {
                            ReturnMessage = "Execution Plan updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.exe_Code;
                        }

                    }
                    else
                    {
                        ReturnMessage = "Execution Plan data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.exe_Code;
                    }

                }
                else
                {
                    ReturnMessage = "Execution Plan data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.exe_Code;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }



        [Route("UpdateExecutionPlanAsUCT")]
        [HttpPost]
        public async Task<IActionResult> UpdateExecutionPlanAsUCT([Bind("")] ExecutionPlannedDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            try
            {
                TypeCodeMaster SubmittedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionPlanned, ExecutionPlannedStatus.Submitted);
                TypeCodeMaster DraftedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionPlanned, ExecutionPlannedStatus.Drafted);

                var IdData = CryptoExtensions.Decrypt(recevingDTO.exe_Code);
                long Id = (long)IdData.Split("-").Last().ToInt64();
                recevingDTO.exe_ID = Id;



                if (Id > 0)
                {
                    ExecutionPlanned dbObj = await executionService.GetexecutionPlanById(Id);

                    if (dbObj != null && SubmittedStatus != null && DraftedStatus != null)
                    {

                        var addObj = await ExecutionPlannedDTOMapping(recevingDTO, dbObj);

                        var result = await executionService.UpdateexecutionPlan(addObj);
                        if (result > 0)
                        {
                            UtlAuditTrail obj = new UtlAuditTrail()
                            {
                                TableName = "Updat Execution Plan",
                                Action = "Update UCT Workflow",
                                ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                                ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                                Description = SerializeForAudit(addObj),

                            };
                            await commonService.Log(obj);

                            ReturnMessage = "Execution Plan updated Successfully.";
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.exe_Code;
                        }
                        else
                        {
                            ReturnMessage = "Execution Plan updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.exe_Code;
                        }

                    }
                    else
                    {
                        ReturnMessage = "Execution Plan data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.exe_Code;
                    }

                }
                else
                {
                    ReturnMessage = "Execution Plan data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.exe_Code;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }



        [Route("UpdateExecutionPlan")]
        [HttpPost]
        public async Task<IActionResult> UpdateExecutionPlan([Bind("")] ExecutionPlannedDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            try
            {
                TypeCodeMaster SubmittedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionPlanned, ExecutionPlannedStatus.Submitted);
                TypeCodeMaster DraftedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionPlanned, ExecutionPlannedStatus.Drafted);

                var IdData = CryptoExtensions.Decrypt(recevingDTO.exe_Code);
                long Id = (long)IdData.Split("-").Last().ToInt64();
                recevingDTO.exe_ID = Id;


                if (Id > 0)
                {
                    ExecutionPlanned dbObj = await executionService.GetexecutionPlanById(Id);

                    if (dbObj != null && SubmittedStatus != null && DraftedStatus != null)
                    {
                        //If its submitted, it cannot be changed.
                        if (dbObj.Status == SubmittedStatus.Id)
                        {
                            var returnData = new TIP_RESULT()
                            {
                                message = "Unathorized Data entry Revoked.",
                                status = (int)ResponseStatus.error,
                                TResponse = recevingDTO.exe_Code

                            };

                            return Ok(returnData);
                        }

                        var addObj = await ExecutionPlannedDTOMapping(recevingDTO, dbObj);



                        if ((bool)recevingDTO.IsSubmit)
                        {
                            addObj.SubmitCount = addObj.SubmitCount + 1;
                            addObj.Status = SubmittedStatus.Id;
                            addObj.SubmittedOn = DateTime.Now;
                            addObj.LastReminder = null;
                            addObj.SentbackOn = null;
                            addObj.SentbackBy = "";
                        }
                        else
                        {
                            
                            addObj.SubmittedOn = null;
                        }

                        var result = await executionService.UpdateexecutionPlan(addObj);
                        if (result > 0)
                        {
                            if ((bool)recevingDTO.IsSubmit)
                            {
                                UtlAuditTrail obj = new UtlAuditTrail()
                                {
                                    TableName = "Update Execution Plan",
                                    Action = "Update",
                                    ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                                    ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                                    Description = JsonSerializer.Serialize(recevingDTO),

                                };
                                await commonService.Log(obj);


                                await executionService.SendExecutionEmail(Convert.ToInt64(addObj.ExeId), EmailModules.EXEC, "EXEC006", LoggedInUser);

                                await AddExePlanFlowHistoryAsync(addObj.Id, (long)addObj.Status, "", (long)LoggedInUser.ACTIVE_R_ID, "Execution Plan Submitted");
                            }
                            ReturnMessage = "Execution Plan Updated Successfully";
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.exe_Code;
                        }
                        else
                        {
                            ReturnMessage = "Execution Plan updating Error";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.exe_Code;
                        }
                    }
                    else
                    {
                        ReturnMessage = "Execution Plan data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.exe_Code;
                    }

                }
                else
                {
                    ReturnMessage = "Execution Plan data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.exe_Code;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }





        [Route("ApprovedExecutionPlan")]
        [HttpPost]
        public async Task<IActionResult> ApprovedExecutionPlan([Bind("")] ExecutionPlannedDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            try
            {
                TypeCodeMaster Approvedstatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionPlanned, ExecutionPlannedStatus.Approved);

               var IdData = CryptoExtensions.Decrypt(recevingDTO.exe_Code);
                long Id = (long)IdData.Split("-").Last().ToInt64();
                recevingDTO.exe_ID = Id;



                if (Id > 0)
                {
                    ExecutionPlanned dbObj = await executionService.GetexecutionPlanById(Id);

                    if (dbObj != null && Approvedstatus != null)
                    {

                        var addObj = await ExecutionPlannedDTOMapping(recevingDTO, dbObj);


                        addObj.Status = Approvedstatus.Id;

                        addObj.LastReminder = null;
                        addObj.ApprovedOn = DateTime.Now;
                        addObj.ApprovedBy = "UCT";


                        var result = await executionService.UpdateexecutionPlan(addObj);
                        if (result > 0)
                        {
                            UtlAuditTrail obj = new UtlAuditTrail()
                            {
                                TableName = "Update Execution Plan Approved",
                                Action = "Update ",
                                ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                                ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                                Description = JsonSerializer.Serialize(recevingDTO),

                            };
                            await commonService.Log(obj);

                            await executionService.SendExecutionEmail(Convert.ToInt64(addObj.ExeId), EmailModules.EXEC, "EXEC009", LoggedInUser, addObj.Reason);
                            await AddExePlanFlowHistoryAsync(addObj.Id, (long)addObj.Status, addObj.Reason, (long)LoggedInUser.ACTIVE_R_ID, "Execution Plan Approved Successfully");
                            ReturnMessage = "Execution Plan Approved successfully.";
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.exe_Code;
                        }
                        else
                        {
                            ReturnMessage = "Execution Plan Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.exe_Code;
                        }

                    }
                    else
                    {
                        ReturnMessage = "Execution Plan data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.exe_Code;
                    }

                }
                else
                {
                    ReturnMessage = "Execution Plan data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.exe_Code;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }






        [Route("AddorUpdateExecutionPlanned")]
        [HttpPost]
        public async Task<IActionResult> AddorUpdateExecutionPlanned([Bind("")] ExecutionPlannedTimelinesDTO recObj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            try
            {

                long execIdl = 0;
                if (recObj != null)
                {
                    long ctrIdl = 0;
                    var ctridData = CryptoExtensions.Decrypt(recObj.ExecCode);
                    recObj.exec_id = (long)ctridData.Split("-").Last().ToInt64();

                    recObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                    recObj.UpdatedOn = DateTime.Now;
                    var result = await executionService.addorUpdateExecutionPlannedTimeline(ExecutionPlannedTimelineDTOMapping(recObj));
                    if (result == 3)
                    {

                        var response = new TIP_RESULT()
                        {
                            message = "Stage already exist",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                    else if (result > 0)
                    {
                        if ((bool)recObj.IsApproved)
                        {
                            UtlAuditTrail obj = new UtlAuditTrail()
                            {
                                TableName = "ExecutionPlannedTimeline",
                                Action = "ADD/Update",
                                ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                                ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                                Description = JsonSerializer.Serialize(recObj),

                            };
                            await commonService.Log(obj);
                            TypeCodeMaster approvedstatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionPlanned, ExecutionPlannedStatus.Approved);

                            await AddExeApprovedPlanFlowHistoryAsync((long)recObj.exec_id, approvedstatus.Id, "NA", (long)LoggedInUser.ACTIVE_R_ID, "Execution plan date is changed By UCT : From " + recObj.startdate + " to " + recObj.enddate + ".");

                            
                        }
                        var response = new TIP_RESULT()
                        {
                            message = "Milestone Successfully updated.",
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Execution data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Oops! something went wrong.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);

                }
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }



        [Route("GetSortStagesByexec/{ExecCode}")]
        [HttpGet]
        public async Task<IActionResult> GetSortStagesByexec(string ExecCode)
        {
            try
            {
                long ctrIdl = 0;
                var ctridData = CryptoExtensions.Decrypt(ExecCode);
                long exec_id = (long)ctridData.Split("-").Last().ToInt64();

                var result = await executionService.GetSortStagesByexec(exec_id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("GetSortActivity/{ExecCode}")]
        [HttpGet]
        public async Task<IActionResult> GetSortActivity(string ExecCode)
        {
            try
            {
                long ctrIdl = 0;
                var ctridData = CryptoExtensions.Decrypt(ExecCode);
                long exec_id = (long)ctridData.Split("-").Last().ToInt64();

                var result = await executionService.GetSortActivity(exec_id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        
        [Route("GetExecutionPlannedById")]
        [HttpPost]
        public async Task<IActionResult> GetExecutionPlannedById([Bind("ExecEnc,Is_Created,rold")] postExec exec)
        {
            string ExecIdEnc=exec.ExecEnc; bool Is_Created= Convert.ToBoolean( exec.Is_Created); long roleid=Convert.ToInt64(exec.rold);
            try
            {
                long exeIdl = 0;
                var execidData = CryptoExtensions.Decrypt(ExecIdEnc);
                

                exeIdl = (long)execidData.Split("-").Last().ToInt64();

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await executionService.GetExecutionPlannedById((long)exeIdl, roleid, LoggedInUser.COMPANY_NUMBER, Is_Created);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }



        [Route("GetActualConfigurablemilestoneValue")]
        [HttpPost]
        public async Task<IActionResult> GetActualConfigurablemilestoneValue([Bind("")] postExec exec)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            string ExecIdEnc = exec.ExecEnc; bool Is_Created = Convert.ToBoolean(exec.Is_Created); long roleid = Convert.ToInt64(exec.rold);
            try
            {
                long exeIdl = 0;
                var execidData = CryptoExtensions.Decrypt(ExecIdEnc);
                
                exeIdl = (long)execidData.Split("-").Last().ToInt64();

                

                var result = await executionService.GetActualPlannedTimeline(Is_Created, (long)exeIdl, roleid, LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }




        [Route("GetConfigurablemilestoneValue")]
        [HttpPost]
        public async Task<IActionResult> GetConfigurablemilestoneValue([Bind("")] postExec exec)
        {
            string ExecIdEnc = exec.ExecEnc; bool Is_Created = Convert.ToBoolean(exec.Is_Created); long roleid = Convert.ToInt64(exec.rold);

            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {
                long exeIdl = 0;
                var execidData = CryptoExtensions.Decrypt(ExecIdEnc);
                

                exeIdl = (long)execidData.Split("-").Last().ToInt64();
                var result = await executionService.GetConfig_MilestoneBYExecId((long)exeIdl, Is_Created, roleid);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        //GetConfigurablemilestoneValue
        [Route("GetAllExecPotentialValue/{CtrIdEnc}")]
        [HttpGet]
        public async Task<IActionResult> GetAllExecPotentialValue(string CtrIdEnc)
        {
            try
            {
                long ctrIdl = 0;
                var ctridData = CryptoExtensions.Decrypt(CtrIdEnc);
                ctrIdl = (long)ctridData.Split("-").Last().ToInt64();
                var result = await executionService.GetAllExecPotentialValue(ctrIdl);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        [Route("UpdateExecutionPotentialValue")]
        [HttpPost]
        public async Task<IActionResult> UpdateExecutionPotentialValue([Bind("")] ExecutionPotentialValueDTO recObj)
        {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {


                if (recObj.execid > 0 && recObj.id > 0)
                {
                    var result = await executionService.UpdateExPotentialValue(ExecPotentialValueDTOMapping(recObj));
                    if (result > 0)
                    {
                        UtlAuditTrail obj = new UtlAuditTrail()
                        {
                            TableName = "UpdateExPotentialValue",
                            Action = "Update",
                            ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                            ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                            Description = JsonSerializer.Serialize(recObj),

                        };
                        await commonService.Log(obj);
                        var response = new TIP_RESULT()
                        {
                            message = "Potential Value updated successfully.",
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Potential Value data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }



                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Something Went Wrong",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);

                }
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }




        [Route("ExecutionInitiation")]
        [HttpPost]
        public async Task<IActionResult> ExecutionInitiation([Bind("CtrIdEnc,execId,rold")] postExec exec)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            string CtrIdEnc = exec.CtrIdEnc;string execId = exec.execId;long roleid = Convert.ToInt64(exec.rold);
            try
            {
               var IdData = CryptoExtensions.Decrypt(CtrIdEnc);
                long execIdl = 0;
                if (execId != "null")
                {
                    var execidData = CryptoExtensions.Decrypt(execId);
                    execIdl = (long)execidData.Split("-").Last().ToInt64();
                }


                long Id = (long)IdData.Split("-").Last().ToInt64();
                var response = new TIP_RESULT();
                if (Id > 0)
                {
                    
                    var result = await executionService.InitiateExecution(Id, LoggedInUser.COMPANY_NUMBER, roleid, execIdl);
                    if (result != null)
                    {

                        response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result

                        };

                    }
                    else
                    {
                        response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.error,
                            TResponse = null

                        };
                    }

                }
                else
                {
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.error,
                        TResponse = null

                    };
                }


                return Ok(response);

            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }



        [Route("UpdateInitiateExecution")]
        [HttpPost]
        public async Task<IActionResult> UpdateInitiateExecution([Bind("")] ExecutionIntiationDTO recObj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {

                long execIdl = 0;
                if (recObj.ExecIdEnc != "null")
                {
                    var execidData = CryptoExtensions.Decrypt(recObj.ExecIdEnc);
                    recObj.id = (long)execidData.Split("-").Last().ToInt64();
                }



                if (recObj != null)
                {
                   recObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                    recObj.UpdatedOn = DateTime.Now;
                    var result = await executionService.addorUpdateinitiate(recObj, LoggedInUser);
                    if (result == 1)
                    {
                        if (recObj.statusId.ToString() == ExecutionStatus.Initiated)
                        {
                           
                            TypeCodeMaster InitiatedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.EXECStatus, ExecutionStatus.Initiated);
                            await AddExeFlowHistoryAsync(recObj.id, InitiatedStatus.Id, "", (long)LoggedInUser.ACTIVE_R_ID, "Trial Execution Initiated");
                        }
                        else if (recObj.statusId.ToString() == ExecutionStatus.Drafted)
                        {
                            TypeCodeMaster InitiatedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.EXECStatus, ExecutionStatus.Initiated);
                            await AddExeFlowHistoryAsync(recObj.id, InitiatedStatus.Id, "", (long)LoggedInUser.ACTIVE_R_ID, "Trial Execution Updated");
                        }

                        UtlAuditTrail obj = new UtlAuditTrail()
                        {
                            TableName = "Execution Initiation",
                            Action = "Update",
                            ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                            ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                            Description = JsonSerializer.Serialize(recObj),

                        };
                        await commonService.Log(obj);



                        var response = new TIP_RESULT()
                        {
                            message = "initiate execution updated successfully.",
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else if (result == 3)
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "please add mandatory Trial Focal Point/ Potential Value",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "initiate execution data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Oops! something went wrong.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);

                }
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }



        [Route("updateIsMandatory")]
        [HttpPost]
        public async Task<IActionResult> updateIsMandatory([Bind("")] ExecutionTrialfpsDTO DTO)
        {
            try
            {
                var result = await executionService.updateIsMandatory(DTO.Id, (bool)DTO.IsMandatory);

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {

                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }






        [Route("addtrialFPExecution")]
        [HttpPost]
        public async Task<IActionResult> addtrialFPExecution([Bind("")] ExecutionTrialfpsDTO DTO)
        {

            EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {
                if (DTO.ExecutionENCId != "null")
                {
                    var execidData = CryptoExtensions.Decrypt(DTO.ExecutionENCId);
                    DTO.ExecutionId = (long)execidData.Split("-").Last().ToInt64();
                }

                var addObj = await TechBankDTOMapping(DTO, true);
                var result = await executionService.addExecutionTrialFp(addObj);

                UtlAuditTrail obj = new UtlAuditTrail()
                {
                    TableName = "TrialFPExecution",
                    Action = "ADD",
                    ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                    ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                    Description = JsonSerializer.Serialize(DTO),

                };
                await commonService.Log(obj);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {

                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }



        [Route("addExecutionPlannedMaster")]
        [HttpPost]
        public async Task<IActionResult> addExecutionPlannedMaster([Bind("")] ExecutionPlannedDTO DTO)
        {
            EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {
                if (DTO.exe_Code != "null")
                {
                    var execidData = CryptoExtensions.Decrypt(DTO.exe_Code);
                    DTO.exe_ID = (long)execidData.Split("-").Last().ToInt64();
                }

                var result = await executionService.addExecutionplanned(DTO);

                UtlAuditTrail obj = new UtlAuditTrail()
                {
                    TableName = "addExecutionplanned",
                    Action = "ADD",
                    ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                    ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                    Description = JsonSerializer.Serialize(DTO),

                };
                await commonService.Log(obj);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }





        [Route("DeleteExecutionPlanned/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteExecutionPlanned(long id)
        {
            try
            {


                var result = await executionService.DeleteExecutionPlannedTimeline(id, GetIdentityOfLoggedInUser());

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }



        }





        [Route("DeleteTrialFP/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteTrialFP(long id)
        {
            try
            {


                var result = await executionService.DeleteExTrialFPs(id, GetIdentityOfLoggedInUser());

                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }



        }



        private async Task<ExecutionTrialFp> TechBankDTOMapping(ExecutionTrialfpsDTO obj, bool isAdd)
        {
            EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();
            ExecutionTrialFp returnObj;
            if (isAdd)
            {
                returnObj = new ExecutionTrialFp()
                {
                    Fp = obj.USER_DISPLAY.PERSONNEL_NUMBER,
                    ExecutionId = obj.ExecutionId,
                    IsMandatory = (bool)obj.IsMandatory,
                    RefInd = obj.USER_DISPLAY.REFERENCE_INDICATOR,
                    JobTitle = obj.USER_DISPLAY.JOB_DESCRIPTION

                };
            }
            else
            {
                returnObj = new ExecutionTrialFp()
                {
                    IsMandatory = (bool)obj.IsMandatory,
                };
            }
            return returnObj;
        }




        #region Trial Candidates

        [Route("GetAllTrialCandidates/{execCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllTrialCandidates(string execCode)
        {
            try
            {
                var execidData = CryptoExtensions.Decrypt(execCode);
                long ctr_Id = (long)execidData.Split("-").Last().ToInt64();


                if (ctr_Id > 0)
                {
                    EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                    var result = await executionService.GetAllTrialCandidates(ctr_Id);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Trial Candidate data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }


            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        [Route("AddUpdateTrialCandidates")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateTrialCandidates([Bind("")] ExecutionTrialCandidateDTO recObj)
        {
            EmployeeDTO LoggedInUser = GetIdentityOfLoggedInUser();

            try
            {
                var execData = (long)CryptoExtensions.Decrypt(recObj.ExecCode).ToInt64();


                if (execData > 0)
                {
                    recObj.ExecId = execData;
                    if (recObj.Id > 0)
                    {
                        var result = await executionService.UpdateTrialCandidates(ExecTrialCandidateDTOMapping(recObj));
                        if (result > 0)
                        {
                            UtlAuditTrail obj = new UtlAuditTrail()
                            {
                                TableName = "Trial Candidate",
                                Action = "ADD",
                                ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                                ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                                Description = JsonSerializer.Serialize(recObj),

                            };
                            await commonService.Log(obj);

                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate updated successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }
                    else
                    {
                        var result = await executionService.AddTrialCandidates(ExecTrialCandidateDTOMapping(recObj));
                        if (result > 0)
                        {
                            UtlAuditTrail obj = new UtlAuditTrail()
                            {
                                TableName = "Trial Candidate",
                                Action = "Update",
                                ActionBy = LoggedInUser.DISPLAY_NAME + " " + LoggedInUser.COMPANY_NUMBER,
                                ActionOn = DateTime.Today.ToString("dd/MM/yyyy"),
                                Description = JsonSerializer.Serialize(recObj),

                            };
                            await commonService.Log(obj);
                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate added successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }


                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Something Went Wrong",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);

                }
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("DeleteTrialCandidates/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteTrialCandidates(long id)
        {
            try
            {
                var result = await executionService.DeleteTrialCandidates(id);

                var response = new TIP_RESULT()
                {
                    message = "Trial candidate deleted successfully.",
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }



        }




        private ExecutionPotentialValue ExecPotentialValueDTOMapping(ExecutionPotentialValueDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            ExecutionPotentialValue newObj = new ExecutionPotentialValue();
            newObj.Id = (long)obj.id;
            newObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
            newObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
            newObj.UpdatedOn = DateTime.Now;
            newObj.Year = obj.year;
            newObj.ExecId = obj.execid;
            newObj.Value = obj.value;
            newObj.Noofwells = obj.noofwells;
            newObj.Station = obj.station;
            return newObj;
        }




        private ExecutionTrialCandidate ExecTrialCandidateDTOMapping(ExecutionTrialCandidateDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            ExecutionTrialCandidate newObj = new ExecutionTrialCandidate()
            {
                TypeId = obj.TypeId == null ? 0 : obj.TypeId,
                Name = obj.Name == null ? "" : obj.Name,
                Cost = obj.Cst == null ? 0 : obj.Cst,
                CommencementDate = obj.CommencementDate.ToString() == "" || obj.CommencementDate == null ? DateTime.MinValue : (DateTime)obj.CommencementDate.ToDateTime(),
                ConclusionDate = obj.ConclusionDate.ToString() != "" && obj.ConclusionDate != null ? (DateTime)obj.ConclusionDate.ToDateTime() : null,
                ChallengeDescription = obj.ChallengeDescription == null ? "" : obj.ChallengeDescription,
                Comments = obj.Comments == null ? "" : obj.Comments,
                OutcomeId = obj.OutcomeId == null ? 0 : obj.OutcomeId,
                ExecutionId = obj.ExecId
            };
            if (obj.Id > 0)
            {
                newObj.Id = obj.Id;
                newObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.UpdatedOn = DateTime.Now;
            }
            else
            {
                newObj.Id = 0;
                newObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.CreatedOn = DateTime.Now;
            }


            return newObj;
        }

        #endregion

        [Route("ChangeUctFp")]
        [HttpPost]
        public async Task<IActionResult> ChangeUctFp([Bind("")] ExecutionReassignChangeDTO recevingDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var Id = recevingDTO.ExecId;
                if (Id > 0)
                {
                    TmUserRole AdminRole = await employeeService.GetRoleId(UserRolesParam.Administrator);

                    ExecutionInitiation dbObj = await executionService.GetExecutionForReAssignment(Id);
                    dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                    dbObj.RefNo = LoggedInUser.REFERENCE_INDICATOR;
                    dbObj.UpdatedOn = DateTime.Now;
                    dbObj.UctFp = recevingDTO.NewAdvisor.PERSONNEL_NUMBER;
                    var result = await executionService.UpdateExecutionForReAssignment(dbObj);
                    if (result > 0)
                    {
                        List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                        TmUserRole UctRole = await employeeService.GetRoleId(UserRolesParam.UCT);

                        TmRoleToUserMapping roleUCT = new TmRoleToUserMapping()
                        {
                            UserId = recevingDTO.NewAdvisor.PERSONNEL_NUMBER,
                            RoleId = UctRole.RoleId,
                            IsActive = 1,
                            CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                            CreatedOn = DateTime.Now
                        };
                        tmRoleToUsers.Add(roleUCT);

                        if (tmRoleToUsers.Any())
                        {
                            var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                        }
                        await executionService.SendExecutionEmail(recevingDTO.ExecId, EmailModules.EXEC, "EXEC002", LoggedInUser, "", recevingDTO.CurrentMu, 0);
                        await executionService.SendExecutionEmail(recevingDTO.ExecId, EmailModules.EXEC, "EXEC003", LoggedInUser, "", recevingDTO.CurrentMu, 0);

                        await AddExeFlowHistoryAsync(recevingDTO.ExecId, (long)dbObj.StatusId, "", AdminRole.RoleId, "(Administrator) changed UCT for Execution");

                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);

                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "The Execution record is not updated",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "The Execution record is not exist",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);

                }
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        [Route("ChangeTrialFp")]
        [HttpPost]
        public async Task<IActionResult> ChangeTrialFp([Bind("")] ExecutionReassignChangeDTO recevingDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var Id = recevingDTO.ExecId;
                if (Id > 0)
                {
                    //Getting these information to add flow history  
                    TmUserRole UCTRole = await employeeService.GetRoleId(UserRolesParam.UCT);
                    ExecutionInitiation ExeObj = await executionService.GetExecutionForReAssignment(Id);

                    ExecutionTrialFp dbObj = await executionService.GetExecutionMTFReAssignment(Id);
                    dbObj.Fp = recevingDTO.NewAdvisor.PERSONNEL_NUMBER;

                    var result = await executionService.UpdateExecutionMTFReAssignment(dbObj);
                    if (result > 0)
                    {
                        List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                        TmUserRole trilaFP = await employeeService.GetRoleId(UserRolesParam.TrialFP);

                        TmRoleToUserMapping roleTFP = new TmRoleToUserMapping()
                        {
                            UserId = recevingDTO.NewAdvisor.PERSONNEL_NUMBER,
                            RoleId = trilaFP.RoleId,
                            IsActive = 1,
                            CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                            CreatedOn = DateTime.Now
                        };
                        tmRoleToUsers.Add(roleTFP);

                        if (tmRoleToUsers.Any())
                        {
                            var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                        }
                        await executionService.SendExecutionEmail(recevingDTO.ExecId, EmailModules.EXEC, "EXEC004", LoggedInUser, "", recevingDTO.CurrentMu, 0);
                        await executionService.SendExecutionEmail(recevingDTO.ExecId, EmailModules.EXEC, "EXEC005", LoggedInUser, "", recevingDTO.CurrentMu, 0);

                        await AddExeFlowHistoryAsync(ExeObj.Id, (long)ExeObj.StatusId, "", UCTRole.RoleId, "(UCT) changed Focalpoints for Execution");

                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "The Execution record is not updated",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "The Execution record is not exist",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);

                }
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        #region LoadInvoiceRequests

        [Route("LoadInvoiceRequests")]
        [HttpGet]
        public async Task<IActionResult> LoadInvoiceRequests()
        {
            try
            {

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                if (LoggedInUser != null)
                {
                    var result = await executionService.LoadInvoiceRequests((long)LoggedInUser.ACTIVE_R_ID, LoggedInUser.COMPANY_NUMBER);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.error.ToString(),
                        status = (int)ResponseStatus.error,
                        TResponse = 0
                    };
                    return Ok(response);
                }


            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("LoadInvoiceRequestDetails/{execode}")]
        [HttpGet]
        public async Task<IActionResult> LoadInvoiceRequestDetails(string execode)
        {
            try
            {

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                if (LoggedInUser != null)
                {
                    var IdData = CryptoExtensions.Decrypt(execode);
                    long ExecutionId = (long)IdData.Split("-").Last().ToInt64();

                    var result = await executionService.LoadInvoiceRequestDetails((long)LoggedInUser.ACTIVE_R_ID, LoggedInUser.COMPANY_NUMBER, ExecutionId);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.error.ToString(),
                        status = (int)ResponseStatus.error,
                        TResponse = 0
                    };
                    return Ok(response);
                }


            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("AddUpdateInvoice")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateInvoice([Bind("")] InvoiceRequestDetailsDTO DTO)
        {
            try
            {
                string ReturnMessage = String.Empty;
                EmployeeDTO employee = GetIdentityOfLoggedInUser();
                TypeCodeMaster Sentback = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionInvoiceStatus, ExecutionInvoiceStatus.Sentback);

                var addObj = await InvoiceRequestDTOMapping(DTO);
                ExecutionInvoice invoice = await executionService.GetExecutionInvoice(DTO.ID);

                TypeCodeMaster Status;
                if (DTO.STATUS == ExecutionInvoiceStatus.Drafted && (Sentback != null && (invoice != null && invoice.StatusId.Equals(Sentback.Id))))
                {
                    Status = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionInvoiceStatus, ExecutionInvoiceStatus.Sentback);
                    addObj.StatusId = Status.Id;
                    ReturnMessage = "Invoice Request Updated Successfully.";
                }
                else if (DTO.STATUS == ExecutionInvoiceStatus.Drafted)
                {
                    Status = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionInvoiceStatus, ExecutionInvoiceStatus.Drafted);
                    addObj.StatusId = Status.Id;
                    ReturnMessage = "Invoice Request Drafted Successfully.";
                }
                else if (DTO.STATUS == ExecutionInvoiceStatus.Requested)
                {
                    addObj.TfpRequestDate = DateTime.Today;
                    Status = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionInvoiceStatus, ExecutionInvoiceStatus.Requested);
                    addObj.StatusId = Status.Id;

                    ReturnMessage = "Invoice Requested Successfully.";
                }



                if (addObj.Id == 0)
                {
                    var result = await executionService.AddInvoice(addObj);

                    if (DTO.STATUS == ExecutionInvoiceStatus.Requested)
                    {
                        //SEND EMAIL -EXEC011
                        await executionService.SendExecutionEmail(DTO.EXEC_ID, EmailModules.EXEC, "EXEC011", employee, InvId: addObj.Id);
                       

                    }

                    UtlAuditTrail obj = new UtlAuditTrail()
                    {
                        TableName = "EXECUTION_INVOICES",
                        Action = "ADD",
                        ActionBy = addObj.CreatedBy,
                        ActionOn = addObj.CreatedOn.ToString("dd/MM/yyyy"),
                        Description = JsonSerializer.Serialize(DTO),
                        //Id =addObj.Id,
                    };
                    await commonService.Log(obj);
                    var response = new TIP_RESULT()
                    {
                        message = ReturnMessage,
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var result = await executionService.UpdateInvoice(addObj);
                    UtlAuditTrail obj = new UtlAuditTrail()
                    {
                        TableName = "EXECUTION_INVOICES",
                        Action = "UPDATE",
                        ActionBy = addObj.CreatedBy,
                        ActionOn = addObj.CreatedOn.ToString("dd/MM/yyyy"),
                        Description = JsonSerializer.Serialize(DTO),
                        //Id =addObj.Id,
                    };
                    await commonService.Log(obj);
                    var response = new TIP_RESULT()
                    {
                        message = ReturnMessage,
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    if (DTO.STATUS == ExecutionInvoiceStatus.Requested)
                    {
                        //SEND EMAIL -EXEC011
                        await executionService.SendExecutionEmail(DTO.EXEC_ID, EmailModules.EXEC, "EXEC011", employee, InvId: addObj.Id);
                        await AddExeFlowHistoryAsync(DTO.EXEC_ID, addObj.StatusId, "", (long)employee.ACTIVE_R_ID, "Invoice Requested Successfully.");
                    }

                    return Ok(response);
                }


            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("UpdateInvoiceStatus")]
        [HttpPost]
        public async Task<IActionResult> UpdateInvoiceStatus([Bind("")] InvoiceRequestDetailsDTO DTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                string ReturnMessage = String.Empty;

                
                ExecutionInvoice invoice = await executionService.GetExecutionInvoice(DTO.ID);
                invoice.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                invoice.UpdatedOn = DateTime.Now;
                invoice.Comments = DTO.COMMENTS;

                TypeCodeMaster Status;
                if (DTO.STATUS == ExecutionInvoiceStatus.Sentback)
                {
                    Status = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionInvoiceStatus, ExecutionInvoiceStatus.Sentback);
                    invoice.StatusId = Status.Id;
                    invoice.SentbackDate = DateTime.Today;
                    //SEND EMAIL EXEC013
                    ReturnMessage = "Invoice Request Sentback Successfully.";
                }
                if (DTO.STATUS == ExecutionInvoiceStatus.Reviewed)
                {
                    Status = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionInvoiceStatus, ExecutionInvoiceStatus.Reviewed);
                    invoice.StatusId = Status.Id;
                    invoice.UctReviwedDate = DateTime.Today;
                    //SEND EMAIL EXEC012
                    ReturnMessage = "Invoice Request Reviewed Successfully.";
                }
                else if (DTO.STATUS == ExecutionInvoiceStatus.Completed)
                {
                    
                    Status = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionInvoiceStatus, ExecutionInvoiceStatus.Completed);
                    invoice.StatusId = Status.Id;
                    //SEND EMAIL EXEC015
                    ReturnMessage = "Invoice Released Successfully.";
                }


                if (invoice.Id != 0)
                {
                    var result = await executionService.UpdateInvoice(invoice);

                    if (DTO.STATUS == ExecutionInvoiceStatus.Reviewed)
                    {
                        //SEND EMAIL EXEC012
                        await executionService.SendExecutionEmail(DTO.EXEC_ID, EmailModules.EXEC, "EXEC012", LoggedInUser, InvId: invoice.Id);
                       
                    }
                    if (DTO.STATUS == ExecutionInvoiceStatus.Sentback)
                    {
                        //SEND EMAIL EXEC013
                        await executionService.SendExecutionEmail(DTO.EXEC_ID, EmailModules.EXEC, "EXEC013", LoggedInUser, InvId: invoice.Id);
                        
                    }
                    if (DTO.STATUS == ExecutionInvoiceStatus.Completed)
                    {
                        //SEND EMAIL EXEC015
                        await executionService.SendExecutionEmail(DTO.EXEC_ID, EmailModules.EXEC, "EXEC015", LoggedInUser, InvId: invoice.Id);
                        
                    }
                    UtlAuditTrail obj = new UtlAuditTrail()
                    {
                        TableName = "EXECUTION_INVOICES",
                        Action = "UPDATE",
                        ActionBy = invoice.UpdatedBy,
                        ActionOn = invoice.UpdatedOn?.ToString("dd/MM/yyyy"),
                        Description = JsonSerializer.Serialize(DTO),
                        //sId =addObj.Id,
                    };
                    await commonService.Log(obj);
                    var response = new TIP_RESULT()
                    {
                        message = ReturnMessage,
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Invoice not found to update",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }
        private async Task<ExecutionInvoice> InvoiceRequestDTOMapping(InvoiceRequestDetailsDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            ExecutionInvoice returnObj = new ExecutionInvoice()
            {
                Id = obj.ID,
                AptId = obj.APT_ID,
                ExeId = obj.EXEC_ID,
                RequestedDate = Convert.ToDateTime(obj.REQUESTED_DATE),
                InvoiceAmount = obj.INVOICED_AMOUNT,
            };
            if (obj.ID == 0)
            {
                returnObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                returnObj.CreatedOn = DateTime.Now;
            }
            else
            {
                returnObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                returnObj.UpdatedOn = DateTime.Now;
                returnObj.Comments = obj.COMMENTS;
            }
            return returnObj;
        }
        #endregion


        [Route("UpdateExecutionActualPlanTimeline")]
        [HttpPost]
        public async Task<IActionResult> UpdateExecutionActualPlanTimeline([Bind("")] ExecutionActualPlannedTimelineDTO recObj)
        {
            try
            {
                if (recObj != null)
                {
                    EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                    recObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                    recObj.UpdatedOn = DateTime.Now;

                    List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                    TmUserRole InvoiceReviewerRole = await employeeService.GetRoleId(UserRolesParam.InvoiceReviewer);

                    TypeCodeMaster Completestatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionActualplanned, ExecutionOverAllProgress.Completed);
                    TypeCodeMaster submittedstatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionActualplannedStatus, ExecutionActualStatus.Submit);
                    TypeCodeMaster Draftedstatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ExecutionActualplannedStatus, ExecutionActualStatus.Save);
                    recObj.invoicereviewedby = recObj.USER_DISPLAY == null ? "" : recObj.USER_DISPLAY.PERSONNEL_NUMBER;
                    if ((bool)recObj.Is_Submit)
                    {
                        recObj.status_id = submittedstatus.Id;
                        recObj.SubmittedON = DateTime.Now;

                        if (recObj.Is_PaymentMilestone == true && recObj.USER_DISPLAY != null)
                        {
                            //Giving user role to InvoiceReviewerRole 
                            TmRoleToUserMapping roleMTFP = new TmRoleToUserMapping()
                            {
                                UserId = recObj.USER_DISPLAY.PERSONNEL_NUMBER,
                                RoleId = InvoiceReviewerRole.RoleId,
                                IsActive = 1,
                                CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                CreatedOn = DateTime.Now
                            };
                            tmRoleToUsers.Add(roleMTFP);
                        }

                    }
                    else
                    {
                        recObj.status_id = Draftedstatus.Id;
                    }
                    if (Completestatus.Id == recObj.overallprogressID && (recObj.actualdenddate == "" || recObj.actualdenddate == null))
                    {
                        recObj.actualdenddate = DateTime.Now.ToString();
                    }
                    var result = await executionService.UpdateExecutionActualPlanTimeline(ExecutionPlannedTimelineDTOMapping(recObj));
                    if (result > 0)
                    {
                       

                        if ((bool)recObj.Is_Submit && recObj.Is_PaymentMilestone == true && recObj.USER_DISPLAY != null)
                        {
                            if (tmRoleToUsers.Any())
                            {
                                var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                            }
                        }
                        long completion = 0;
                        if((bool)recObj.Is_Submit) 
                        {
                            completion = (long)executionService.UpdateExecutionCompletion((long)recObj.id).Result;
                        }

                        
                        
                        await executionService.SendExecutionEmail(Convert.ToInt64(recObj.exec_id), EmailModules.EXEC, "EXEC010", LoggedInUser, planid: recObj.planned_timeline_id);

                        
                        var response = new TIP_RESULT()
                        {
                            message = "Milestone Successfully updated.",
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Milestone data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Oops! something went wrong.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);

                }
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        private ExecutionActualplannedtimline ExecutionPlannedTimelineDTOMapping(ExecutionActualPlannedTimelineDTO obj)
        {
            ExecutionActualplannedtimline dbObj = new ExecutionActualplannedtimline();

            dbObj.Invoicereviewedby = obj.invoicereviewedby == null ? "" : obj.invoicereviewedby.ToString();
            dbObj.StatusId = obj.status_id == null ? 0 : obj.status_id;
            dbObj.Completion = obj.completion == null ? 0 : obj.completion;
            dbObj.Actualendadate = obj.actualdenddate == "" || obj.actualdenddate == null ? obj.SubmittedON == DateTime.Now ? DateTime.Now : null : (DateTime)obj.actualdenddate.ToDateTime();
            dbObj.Actualstartdate = obj.actualstartdate == "" || obj.actualstartdate == null ? null : (DateTime)obj.actualstartdate.ToDateTime();
            dbObj.Overallprogress = (long)obj.overallprogressID;
            dbObj.Id = (long)obj.id;
            dbObj.PlannedTimelineId = (long)obj.planned_timeline_id;
            dbObj.Comments = obj.comments == null ? "" : obj.comments.ToString();
            dbObj.Submittedon = obj.SubmittedON;
            return dbObj;
        }



        [Route("GetAllFlowHistory/{exeId}")]
        [HttpGet]
        public async Task<IActionResult> GetAllFlowHistory(string exeId)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(exeId);
                long ExeId = (long)IdData.Split("-").Last().ToInt64();

                var result = await executionService.GetAllFlowHistory(ExeId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        [Route("GetHistoryByPlanId/{plan}")]
        [HttpGet]
        public async Task<IActionResult> GetHistoryByPlanId(long plan)
        {
            try
            {


                var result = await executionService.GetHistoryByPlanId(plan);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        [Route("GetHistoryByApprovedPlanId/{plan}")]
        [HttpGet]
        public async Task<IActionResult> GetHistoryByApprovedPlanId(long plan)
        {
            try
            {

                var result = await executionService.GetHistoryByApprovedPlanId(plan);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }

        [Route("SaveAllInvoiceDFiles")]
        [HttpPost]
        public async Task<IActionResult> UploadAllInvoiceDFiles([Bind("")] DocumentUploadDTO documentUploadDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            try
            {
                
                long Id = (long)documentUploadDTO.code.ToInt64();
                long result = 0;
                var res = await commonService.DeleteDocument(Id, "InvoiceDetails");
                foreach (var file in documentUploadDTO.files)
                {
                    DocumentRepo obj = new DocumentRepo()
                    {
                        LimkType = file.type,
                        LinkId = Id,
                        FilePath = (file.filepath),
                        CreatedBy = LoggedInUser.COMPANY_NUMBER,
                        CreatedOn = DateTime.Now,
                        FileName = CryptoExtensions.Encrypt(file.fileName),
                        FileType = file.fileExtension,
                        Description = file.description,
                        MimeType = file.mimeType,
                        IsActive = true,
                        IsExternalAccessible = file.isEA,
                    };
                    result = await commonService.AddDocument(obj);
                }
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }



        [Route("GetAllInvoiceD/{actValID}")]
        [HttpGet]
        public async Task<IActionResult> GetAllInvoiceDFiles(string actValID)
        {
            try
            {
                var result = await commonService.GetAllFilesByLinkId((long)actValID.ToInt64(), "InvoiceDetails", false);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                return Ok(response);
            }
        }


        [Route("TrialPlanReport")]
        [HttpPost]
        public async Task<IActionResult> TrialPlanReport([Bind("")] TrialPlanReportDRequestDTO trialPlanReportDRequestDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await executionService.TrailPlanReport(trialPlanReportDRequestDTO, LoggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }



        [Route("TrialPlanReportPrint")]
        [HttpPost]
        public async Task<IActionResult> TrialPlanReportPrint([Bind("")] TrialPlanReportDRequestDTO trialPlanReportDRequestDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await executionService.TrailPlanPrint(trialPlanReportDRequestDTO);

                var response = new FileContentResult(result.FileBytes, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(result.Type));
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

    }


}
