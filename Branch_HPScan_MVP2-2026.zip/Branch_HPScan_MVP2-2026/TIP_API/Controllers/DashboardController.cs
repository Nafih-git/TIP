﻿using TIP_API.DTO;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface.Admin;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_Core;
using TIP_CORE;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using TIP_BAL.Services;
using TIP_CORE.EntitiesDTO;
using TIP_BAL.Interface;
using static TIP_Common.Enum.Enum;
using TIP_CORE.Entities;
using System.Security.Authentication;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController : BaseController
    {
        private readonly IDashboardService DashboardService;
        private readonly IChallengeService challengeService;
        private readonly IEmployeeService employeeService;
        public DashboardController(ICommonService _commonService, IDashboardService _DashboardService, IChallengeService _challengeService,IEmployeeService _employeeService) : base(_commonService)
        {
            DashboardService = _DashboardService;
            challengeService = _challengeService;
            employeeService = _employeeService;
        }

        [Route("getBaseData")]
        [HttpGet]
        public async Task<IActionResult> getBaseData(int RoleID)
        {
            try
            {
                EmployeeDTO? loggedinuser = GetIdentityOfLoggedInUser();

                bool hasRole = await employeeService.CheckIfUserHasRole(loggedinuser.COMPANY_NUMBER, RoleID);
                if (hasRole)
                {
                    var result = await DashboardService.getBaseData(RoleID, loggedinuser.COMPANY_NUMBER);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };

                    return Ok(response);
                }
                else
                {
                    var result = "";
                    var response = new TIP_RESULT()
                    {
                        message = "You do not have access to the current requested role.",
                        status = (int)ResponseStatus.success,
                        TResponse = "AuthorizationError"
                    };

                    return Ok(response);
                }
                
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

      


        [Route("getUserLoginData")]
        [HttpGet]
        public async Task<IActionResult> getUserLoginData()
        {
            var response = new TIP_RESULT();
            try
            {
                EmployeeDTO? loggedinuser = GetIdentityOfLoggedInUser();
                if (loggedinuser != null)
                {
                    var result = await DashboardService.getBaseData_LoginRoles(loggedinuser.COMPANY_NUMBER);
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                }
                else
                {
                    response = new TIP_RESULT()
                    {
                        message = "User does not exist. Please register or contact support.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #region Pending Task

        [Route("GetAllTasksForUser")]
        [HttpGet]
        public async Task<IActionResult> GetAllTasksForUser()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.GetAllTasksForUser(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetAllTasksCountForUser")]
        [HttpGet]
        public async Task<IActionResult> GetAllTasksCountForUser()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.GetAllTasksCountForUser(LoggedInUser);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
        #endregion



        [Route("GetAllTasks")]
        [HttpPost]
        public async Task<IActionResult> GetAllTasks([Bind("")] ActiionTaskRequestDTO requestdto)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await commonService.GetAllTasks(requestdto);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #region PieCharts
        [Route("getQueryResponseCount")]
        [HttpGet]
        public async Task<IActionResult> getQueryResponseCount()
        {
            try
            {
                var result = await challengeService.TechProposalQueriesCount();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("getCTRStatusCount")]
        [HttpGet]
        public async Task<IActionResult> getCTRStatusCount()
        {
            try
            {
                var result = await challengeService.GetCTRStatusCount();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("getProposalResponseStatusCount")]
        [HttpGet]
        public async Task<IActionResult> getProposalResponseStatusCount()
        {
            try
            {
                var result = await challengeService.GetChallengeResponseStatusCount();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("getPIRtatusCount")]
        [HttpGet]
        public async Task<IActionResult> getPIRStatusCount()
        {
            try
            {
                var result = await challengeService.GetPIRStatusCount();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("getChallengeStatusCount")]
        [HttpGet]
        public async Task<IActionResult> getChallengeStatusCount()
        {
            try
            {
                var result = await challengeService.GetChallengeStatusCount();
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        #endregion
    }
}
