﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TIP_API.DTO;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface;
using TIP_BAL.Interface.Admin;
using TIP_BAL.Services;
using TIP_BAL.Services.Admin;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using static TIP_Common.Enum.Enum;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RankPainAreaController : BaseController
    {
        private readonly IBTMPainAreaService _painAreaService;
        private readonly ICommonService _commonService;
        public RankPainAreaController(ICommonService commonService, IBTMPainAreaService painAreaService) : base(commonService)
        {
            _painAreaService = painAreaService;
            _commonService = commonService;
        }

        [Route("GetAssessmentsForRanking")]
        [HttpGet]
        public async Task<IActionResult> GetAssessmentsForRanking()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await _painAreaService.GetAssessmentsForRanking(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("FilterAssessmentsForRanking")]
        [HttpPost]
        public async Task<IActionResult> FilterAssessmentsForRanking([Bind("")] BTMAssessmentFilterDTO btmAssessmentIP_DTO)
        {
            try
            {
                var result = await _painAreaService.GetFilterAssessmentsForRanking(btmAssessmentIP_DTO);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetPainAreasForRanking")]
        [HttpGet]
        public async Task<IActionResult> GetPainAreasForRanking(long AssessmentId)
        {
            try
            {
                var result = await _painAreaService.GetPainAreasForRanking(AssessmentId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetPainAreasByAssessmentId")]
        [HttpGet]
        public async Task<IActionResult> GetPainAreasByAssessmentId(long AssessmentId)
        {
            try
            {
                EmployeeDTO employee = GetIdentityOfLoggedInUser();
                var result = await _painAreaService.GetPainAreasByAssessmentId(AssessmentId,employee);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("FilterPainAreasForRanking")]
        [HttpPost]
        public async Task<IActionResult> FilterPainAreasForRanking([Bind("")] RankPainAreaFilterDTO rankPainAreaFilterDTO)
        {
            try
            {
                var result = await _painAreaService.GetFilterPainAreasForRanking(rankPainAreaFilterDTO);
               var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdateRank")]
        [HttpPost]
        public async Task<IActionResult> UpdateRank([Bind("")] PainAreaUpdateDTO painAreaUpdateDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await _painAreaService.UpdateRank(PainAreaDTOMapping(painAreaUpdateDTO, LoggedInUser));
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = "Exception Occured!",
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private PainArea PainAreaDTOMapping(PainAreaUpdateDTO painAreaUpdateDTO, EmployeeDTO employeeDTO)
        {
            PainArea objPainArea = new PainArea()
            {
                Id = painAreaUpdateDTO.id,
                Rank = painAreaUpdateDTO.rank
            };
            if (objPainArea.Id > 0)
            {
                objPainArea.UpdatedBy = employeeDTO.COMPANY_NUMBER;
                objPainArea.UpdatedOn = DateTime.Now;
            }
            else
            {
                objPainArea.CreatedBy = employeeDTO.COMPANY_NUMBER;
                objPainArea.CreatedOn = DateTime.Now;
            }

            return objPainArea;
        }

        [Route("SubmitAssessment")]
        [HttpPost]
        public async Task<IActionResult> SubmitAssessment(SubmitAssessment assessment)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                TypeCodeMaster? ReviewStatus = await _commonService.GetMasterDataByParentAndParam1(TypeCodes.BTIAssessmentStatus, BTIAssessment.Reviewed);
                
                if (_painAreaService.CheckIfAssessmentCanBeReviewed((long)assessment.AssesmId))
                {
                    BtmAssessment obj = await _painAreaService.GetAssessmentById((long)assessment.AssesmId);
                    if (ReviewStatus != null && obj != null)
                    {

                        obj.StatusId = ReviewStatus.Id;
                        obj.UpdatedOn = DateTime.Today;
                        obj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                        obj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;

                        var result = await _painAreaService.SubmitAssessment(obj);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Entiries required for this transcation are not found.",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Please rank all pain areas for the selected Assessment and Submit again.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
               
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("submitAssessmentForRanking")]
        [HttpPost]
        public async Task<IActionResult> submitAssessmentForRanking(SubmitAssessment assessment)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                TypeCodeMaster? ReviewStatus = await _commonService.GetMasterDataByParentAndParam1(TypeCodes.PainAreaStatus, PainAreaStatus.Submitted);
               
                    PainArea obj = await _painAreaService.GetPainAreabyId((long)assessment.AssesmId);
                    if (ReviewStatus != null && obj != null)
                    {
                        obj.Status = ReviewStatus.Id;
                        obj.UpdatedOn = DateTime.Today;
                        obj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;                        

                        var result = await _painAreaService.UpdatePainArea(obj);
                        await _painAreaService.SendBTMEmail((long)assessment.AssesmId, "BTIAS", "BTMP01",LoggedInUser);
                                        
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Entiries required for this transcation are not found.",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
              
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
    }
}
