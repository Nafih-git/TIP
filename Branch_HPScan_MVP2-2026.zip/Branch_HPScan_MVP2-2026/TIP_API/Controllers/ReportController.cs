using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TIP_API.DTO;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using TIP_BusinessLogic.Interface;
using TIP_CORE.EntitiesDTO;
using static TIP_Common.Enum.Enum;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ReportController : BaseController
    {
        private readonly IAuditLogService _auditLogService;
        private readonly IEmployeeService _employeeService;
        private readonly ILogger<ReportController> _logger;

        public ReportController(
            ICommonService commonService,
            IAuditLogService auditLogService,
            IEmployeeService employeeService,
            ILogger<ReportController> logger) : base(commonService)
        {
            _auditLogService = auditLogService;
            _employeeService = employeeService;
            _logger = logger;
        }

        [HttpGet("AuditLog")]
        public async Task<IActionResult> GetAuditLogs([FromQuery] AuditLogSearchRequestDto request)
        {
            var response = new TIP_RESULT();
            try
            {
                var loggedInUser = GetIdentityOfLoggedInUser();
                if (!await CanViewAuditLogs(loggedInUser))
                {
                    response.status = (int)ResponseStatus.error;
                    response.message = "AuthorizationError";
                    return Ok(response);
                }

                if (request == null)
                    request = new AuditLogSearchRequestDto();

                if (string.IsNullOrWhiteSpace(request.sortColumn))
                    request.sortColumn = "AUDIT_DATE";
                if (string.IsNullOrWhiteSpace(request.sortDirection))
                    request.sortDirection = "DESC";

                var result = await _auditLogService.GetAuditLogsAsync(request);
                response.status = (int)ResponseStatus.success;
                response.message = "Audit logs retrieved successfully";
                response.TResponse = result;
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "ReportController.GetAuditLogs failed");
                response.status = (int)ResponseStatus.error;
                response.message = ex.Message;
            }

            return Ok(response);
        }

        [HttpGet("AuditLog/{auditId:decimal}")]
        public async Task<IActionResult> GetAuditLogDetail(decimal auditId)
        {
            var response = new TIP_RESULT();
            try
            {
                var loggedInUser = GetIdentityOfLoggedInUser();
                if (!await CanViewAuditLogs(loggedInUser))
                {
                    response.status = (int)ResponseStatus.error;
                    response.message = "AuthorizationError";
                    return Ok(response);
                }

                var result = await _auditLogService.GetAuditLogByIdAsync(auditId);
                if (result == null)
                {
                    response.status = (int)ResponseStatus.error;
                    response.message = "Audit log not found";
                    return Ok(response);
                }

                response.status = (int)ResponseStatus.success;
                response.message = ResponseStatus.success.ToString();
                response.TResponse = result;
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "ReportController.GetAuditLogDetail failed for {AuditId}", auditId);
                response.status = (int)ResponseStatus.error;
                response.message = ex.Message;
            }

            return Ok(response);
        }

        [HttpPost("AuditLog/Clear")]
        public async Task<IActionResult> ClearAuditLogs([FromBody] AuditLogClearRequestDto request)
        {
            var response = new TIP_RESULT();
            try
            {
                var loggedInUser = GetIdentityOfLoggedInUser();
                if (!await CanClearAuditLogs(loggedInUser))
                {
                    response.status = (int)ResponseStatus.error;
                    response.message = "AuthorizationError";
                    return Ok(response);
                }

                if (request == null || (!request.fromDate.HasValue && !request.toDate.HasValue))
                {
                    response.status = (int)ResponseStatus.error;
                    response.message = "From Date or To Date is required to clear audit logs.";
                    return Ok(response);
                }

                var result = await _auditLogService.ClearAuditLogsAsync(request, loggedInUser);
                response.status = (int)ResponseStatus.success;
                response.message = $"Cleared {result.deletedCount} audit log record(s). Clear action was retained.";
                response.TResponse = result;
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "ReportController.ClearAuditLogs failed");
                response.status = (int)ResponseStatus.error;
                response.message = ex.Message;
            }

            return Ok(response);
        }

        private async Task<bool> CanViewAuditLogs(EmployeeDTO? loggedInUser)
        {
            if (loggedInUser == null || string.IsNullOrWhiteSpace(loggedInUser.COMPANY_NUMBER))
                return false;

            // Restrict to users with Admin role (role id 1) — align with TIP admin reporting access.
            return await _employeeService.CheckIfUserHasRole(loggedInUser.COMPANY_NUMBER, 1);
        }

        private Task<bool> CanClearAuditLogs(EmployeeDTO? loggedInUser)
            => CanViewAuditLogs(loggedInUser);
    }
}
