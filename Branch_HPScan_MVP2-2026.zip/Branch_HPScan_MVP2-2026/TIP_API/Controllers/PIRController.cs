using Microsoft.AspNetCore.Mvc;
using TIP_API.DTO;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface;
using TIP_BusinessLogic.Interface;
using TIP_Common;
using TIP_Common.Admin;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using static TIP_Common.Enum.Enum;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PIRController : BaseController
    {
        private readonly ICtrService ctrService;
        private readonly IPIRService pirService;
        private readonly IEmployeeService employeeService;
        public PIRController(ICommonService _commonService, ICtrService _ctrService, IEmployeeService _employeeService, IPIRService _pirService) : base(_commonService)
        {
            ctrService = _ctrService;
            pirService = _pirService;
            employeeService = _employeeService;
        }

        #region Manage PIR

        [Route("GetApprovedCtr")]
        [HttpGet]
        public async Task<IActionResult> GetApprovedCtr()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await pirService.GetApprovedCtr(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAllFlowHistory/{pirCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllFlowHistory(string pirCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(pirCode);
                long PIRId = (long)IdData.Split("-").Last().ToInt64();

                var result = await pirService.GetAllFlowHistory(PIRId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAllFlowHistoryDetail/{pirCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllFlowHistoryDetail(string pirCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(pirCode);
                long PIRId = (long)IdData.Split("-").Last().ToInt64();

                var result = await pirService.GetAllFlowHistoryDetail(PIRId);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region Review PIR
        [Route("GetPirToReview")]
        [HttpGet]
        public async Task<IActionResult> GetPirToReview()
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await pirService.GetPirToReview(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region PIR for approval
        [Route("GetPirForApproval/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetPirForApproval(long roleid)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var result = await pirService.GetPirForApproval(LoggedInUser.COMPANY_NUMBER);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region Initiate Pir

        [Route("InitiatePir")]
        [HttpPost]
        public async Task<IActionResult> InitiatePir([Bind("")] PirInitiationDTO pirInitiation)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                TypeCodeMaster Status = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.Drafted);

                if (pirInitiation.MandatoryTP?.Count > 0)
                {
                    if (pirInitiation.OtherTP?.Count > 0)
                    {
                        foreach (AllPDOUsersDTO MandatoryTP in pirInitiation.MandatoryTP)
                        {
                            AllPDOUsersDTO find = pirInitiation.OtherTP.Find(x => x.PERSONNEL_NUMBER.Equals(MandatoryTP.PERSONNEL_NUMBER));
                            if (find != null)
                            {
                                var response1 = new TIP_RESULT()
                                {
                                    message = "Cannot duplicate mandatory focal point as other focal point.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(response1);
                            }
                        }
                    }
                }

                var addObj = await PirInitiationDTOMapping(pirInitiation);
                if (addObj != null)
                {
                    addObj.StatusId = Status.Id;

                    var result = await pirService.InitiatePir(addObj);
                    if (result > 0)
                    {
                        await AddPirFlowHistoryAsync(addObj.Id, Status.Id, "", pirInitiation.CurrentRleId, LoggedInUser?.DISPLAY_NAME + " (UCT) initiated PIR");

                        List<PirTrialFp> FocalPoints = new List<PirTrialFp>();

                        //Proceed with Assigning Roles
                        List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                        TmUserRole TrialFP = await employeeService.GetRoleId(UserRolesParam.TrialFP);


                        if (pirInitiation.MandatoryTP?.Count > 0)
                        {
                            foreach (AllPDOUsersDTO mfp in pirInitiation.MandatoryTP)
                            {
                                PirTrialFp MTFP = new PirTrialFp()
                                {
                                    PirId = addObj.Id,
                                    Fp = mfp.PERSONNEL_NUMBER,
                                    RefInd = string.IsNullOrWhiteSpace(mfp.REFERENCE_INDICATOR) ? (mfp.PERSONNEL_NUMBER ?? "N/A") : mfp.REFERENCE_INDICATOR,
                                    JobTitle = string.IsNullOrWhiteSpace(mfp.JOB_DESCRIPTION) ? "N/A" : mfp.JOB_DESCRIPTION,
                                    IsMandatory = true
                                };
                                FocalPoints.Add(MTFP);

                                TmRoleToUserMapping roleMTFP = new TmRoleToUserMapping()
                                {
                                    UserId = mfp.PERSONNEL_NUMBER,
                                    RoleId = TrialFP.RoleId,
                                    IsActive = 1,
                                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now
                                };
                                tmRoleToUsers.Add(roleMTFP);
                            }

                        }

                        if (pirInitiation.OtherTP?.Count > 0)
                        {
                            foreach (AllPDOUsersDTO ofp in pirInitiation.OtherTP)
                            {
                                PirTrialFp OTFP = new PirTrialFp()
                                {
                                    PirId = addObj.Id,
                                    Fp = ofp.PERSONNEL_NUMBER,
                                    RefInd = string.IsNullOrWhiteSpace(ofp.REFERENCE_INDICATOR) ? (ofp.PERSONNEL_NUMBER ?? "N/A") : ofp.REFERENCE_INDICATOR,
                                    JobTitle = string.IsNullOrWhiteSpace(ofp.JOB_DESCRIPTION) ? "N/A" : ofp.JOB_DESCRIPTION,
                                    IsMandatory = false
                                };
                                FocalPoints.Add(OTFP);

                                TmRoleToUserMapping roleMTFP = new TmRoleToUserMapping()
                                {
                                    UserId = ofp.PERSONNEL_NUMBER,
                                    RoleId = TrialFP.RoleId,
                                    IsActive = 1,
                                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now
                                };
                                tmRoleToUsers.Add(roleMTFP);
                            }
                        }
                        var mResult = await pirService.AddTrialFp(FocalPoints);

                        if (mResult > 0)
                        {
                            if (tmRoleToUsers.Any())
                            {
                                var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                            }

                            await pirService.SendEmail(addObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR001");
                        }
                    }
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "PIR Data Null",
                        status = (int)ResponseStatus.error,
                        TResponse = ""

                    };
                    return Ok(response);
                }






            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private async Task<PirInitiation> PirInitiationDTOMapping(PirInitiationDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            var isAdd = true;

            long CtrId = 0;
            var IdData = CryptoExtensions.Decrypt(obj.CtrIdEnc);
            if (IdData.StartsWith("TTA-"))
            {
                CtrId = (long)IdData.Split("-").Last().ToInt64();
            }
            if (CtrId > 0)
            {
                PirInitiation returnObj = new PirInitiation()
                {
                    Id = 0,
                    Source = "TTA",
                    CtrId = CtrId
                };
                if (isAdd)
                {

                    returnObj.UctFp = LoggedInUser.COMPANY_NUMBER;
                    returnObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                    returnObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                    returnObj.CreatedOn = DateTime.Now;
                }
                else
                {

                    returnObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                    returnObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                    returnObj.UpdatedOn = DateTime.Now;
                }
                return returnObj;
            }
            else
            {
                return null;
            }



        }

        [Route("GetCtrPriData/{ctrCode}/{pirCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetCtrPriData(string ctrCode, string pirCode, long roleid)
        {
            try
            {
                var CtrIdData = CryptoExtensions.Decrypt(ctrCode);
                if (CtrIdData.StartsWith("TTA-"))
                {
                    long PirId = 0;
                    long CtrId = (long)CtrIdData.Split("-").Last().ToInt64();

                    if (pirCode != "NA")
                    {
                        var PirIdData = CryptoExtensions.Decrypt(pirCode);
                        PirId = (long)PirIdData.Split("-").Last().ToInt64();
                    }

                    if (CtrId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.GetCtrPriData(CtrId, PirId, roleid, LoggedInUser.COMPANY_NUMBER);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "TTA data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "TTA data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }




            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
        #endregion

        private async Task AddPirFlowHistoryAsync(long pirId, long statusId, string comments, long currentRoleId, string descInfo)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                if (currentRoleId <= 0)
                {
                    TmUserRole uctRole = await employeeService.GetRoleId(UserRolesParam.UCT);
                    currentRoleId = uctRole.RoleId;
                }
                else
                {
                    TmUserRole role = await employeeService.GetRoleId(currentRoleId);
                    if (role == null)
                    {
                        TmUserRole uctRole = await employeeService.GetRoleId(UserRolesParam.UCT);
                        currentRoleId = uctRole.RoleId;
                    }
                }

                if (!string.IsNullOrEmpty(descInfo) && descInfo.Length > 200)
                {
                    descInfo = descInfo[..200];
                }

                if (!string.IsNullOrEmpty(comments) && comments.Length > 500)
                {
                    comments = comments[..500];
                }

                PirFlowHistory obj = new PirFlowHistory()
                {
                    PirId = pirId,
                    StatusId = statusId,
                    Comments = comments,
                    RoleId = currentRoleId,
                    UserId = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    DescInfo = descInfo,
                };

                var result = await pirService.AddFlowHistory(obj);

            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                throw;
            }
        }

        #region PIR Crud

        #region WorkFlow

        [Route("GetPirWorkFlowData/{pirCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetPirWorkFlowData(string pirCode, long roleid)
        {
            try
            {
                var PirData = CryptoExtensions.Decrypt(pirCode);
                if (PirData.StartsWith("PIR-"))
                {
                    long PirId = (long)PirData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.GetPirWorkFlowData(PirId, roleid, LoggedInUser.COMPANY_NUMBER);
                        result.SentbackBy = string.IsNullOrEmpty(result.SentbackBy) ? "" : result.SentbackBy;
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }




            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("SubmitPir")]
        [HttpPost]
        public async Task<IActionResult> SubmitPir([Bind("")] PirWorkFlowUpdateDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster UnderApprovalStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.UnderApproval);
                TypeCodeMaster SubmittedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.Submitted);
               

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);

                    if (dbObj != null && SubmittedStatus != null)
                    {
                        //If its submitted, it cannot be changed.
                        if (dbObj.StatusId == SubmittedStatus.Id)
                        {
                            var returnData = new TIP_RESULT()
                            {
                                message = "Unathorized Dataentry Revoked.",
                                status = (int)ResponseStatus.error,
                                TResponse = recevingDTO.IdEnc

                            };

                            return Ok(returnData);
                        }

                        dbObj.SubmitCount = dbObj.SubmitCount + 1;
                        dbObj.StatusId = SubmittedStatus.Id;
                        dbObj.SubmittedOn = DateTime.Now;
                        dbObj.LastReminder = null;
                        dbObj.SentbackOn = null;
                        dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                        dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                        dbObj.UpdatedOn = DateTime.Now;

                        bool isSentBacktoAPR = false;

                        if (!string.IsNullOrEmpty(recevingDTO.SentbackBy) && recevingDTO.SentbackBy.Equals("APR"))
                        {
                            isSentBacktoAPR = true;

                            if (isSentBacktoAPR)
                            {
                                dbObj.StatusId = UnderApprovalStatus.Id;
                            }
                            dbObj.SentbackBy = "";
                        }


                        var result = await pirService.UpdatePir(dbObj);
                        if (result > 0)
                        {
                            if (isSentBacktoAPR)
                            {
                                //Update current Seq level 
                                List<PirApprovalList> approvalList = await pirService.GetApprovalListsByPirId(dbObj.Id);
                                PirApprovalList approvalObj = approvalList.Where(x => x.Seq.Equals(dbObj.CurrentApprovalSeq) && x.Status.Equals(PIRApprovalStatus.SentBack)).SingleOrDefault();

                                approvalObj.Status = PIRApprovalStatus.UnderApproval;
                                approvalObj.Comments = "";
                                approvalObj.ActionCompletionDate = null;
                                approvalObj.ActionAssingedDate = DateTime.Now;
                                var saveResult = await pirService.UpdateApprovalList(approvalObj);
                                if (saveResult > 0)
                                {
                                    await AddPirFlowHistoryAsync(dbObj.Id, UnderApprovalStatus.Id, "", recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Trial Focal Point) Re Submitted PIR directly to Approver");
                                    ReturnMessage = "PIR Submitted and Sent to Approver Successfully.";
                                    await pirService.SendEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR007");
                                }

                            }
                            else
                            {
                                ReturnMessage = "PIR Submitted Successfully.";
                                if (dbObj.SubmitCount > 1)
                                {
                                    await pirService.SendEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR003");
                                    await AddPirFlowHistoryAsync(dbObj.Id, SubmittedStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Trial Focal Point) Re Submitted PIR");
                                }
                                else
                                {
                                    await pirService.SendEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR002");
                                    await AddPirFlowHistoryAsync(dbObj.Id, SubmittedStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Trial Focal Point) Submitted PIR");
                                }

                                await AddDefaultApprovalListAsync(dbObj.Id);
                            }

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "PIR updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private async Task AddDefaultApprovalListAsync(long PirId)
        {
            try
            {

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                PirWorkFlowDTO dbObj = await pirService.GetPirWorkFlowData(PirId, 0, LoggedInUser?.COMPANY_NUMBER ?? "");

                List<PirApprovalList> lst = new List<PirApprovalList>();

                TypeCodeMaster? HoT = await commonService.GetMasterDataByParentAndParam1(TypeCodes.Configuration, "HNT");

                string mandatoryFpNumber = dbObj?.mandatoryFP?.FirstOrDefault()?.PERSONNEL_NUMBER ?? "";
                EmployeeDTO? LM = await employeeService.getByMuNumber(mandatoryFpNumber);

                lst.Add(new PirApprovalList()
                {
                    PirId = PirId,
                    JobTitle = "Head of New Technology",
                    JobCode = "HNT",
                    Status = "D",
                    Seq = 2,
                    ActionRequiredBy = (HoT != null && HoT.Param2 != null) ? HoT.Param2 : "",
                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    CreatedByRef = LoggedInUser?.REFERENCE_INDICATOR,
                }); ;

                lst.Add(new PirApprovalList()
                {
                    PirId = PirId,
                    JobTitle = "Line Manager",
                    JobCode = "LM",
                    Status = "D",
                    Seq = 1,
                    ActionRequiredBy = (LM != null && !string.IsNullOrEmpty(LM.SUPERVISOR_ID)) ? LM.SUPERVISOR_ID : "",
                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    CreatedByRef = LoggedInUser?.REFERENCE_INDICATOR,
                });

                lst.Add(new PirApprovalList()
                {
                    PirId = PirId,
                    JobTitle = "CFDH/SME",
                    JobCode = "CFDH",
                    Status = "D",
                    Seq = 0,
                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    CreatedByRef = LoggedInUser?.REFERENCE_INDICATOR,
                });

                lst.Add(new PirApprovalList()
                {
                    PirId = PirId,
                    JobTitle = "Deployment Contract Owner",
                    JobCode = "DCO",
                    Status = "D",
                    Seq = 0,
                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    CreatedByRef = LoggedInUser?.REFERENCE_INDICATOR,
                });

                var existingApprovals = await pirService.GetAllApprovalListByPirId(PirId);
                if (existingApprovals == null || existingApprovals.Count() == 0)
                {
                    var result = await pirService.AddDefaultApprovalList(lst);
                }


            }
            catch (Exception ex)
            {
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                throw;
            }
        }


        [Route("SendBackPir")]
        [HttpPost]
        public async Task<IActionResult> SendBackPir([Bind("")] PirWorkFlowUpdateDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster SentBackStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.SentBack);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);

                    if (dbObj != null && SentBackStatus != null)
                    {

                        dbObj.StatusId = SentBackStatus.Id;
                        dbObj.SentbackOn = DateTime.Now;
                        dbObj.LastReminder = null;
                        dbObj.SubmittedOn = null;
                        dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                        dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                        dbObj.UpdatedOn = DateTime.Now;
                        dbObj.SentbackBy = "UCT";

                        var result = await pirService.UpdatePir(dbObj);
                        if (result > 0)
                        {
                            await pirService.SendEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR005", recevingDTO.Comment);

                            ReturnMessage = "PIR Sent back successfully.";
                            await AddPirFlowHistoryAsync(dbObj.Id, SentBackStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Sent back PIR to Trial Fp");

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "PIR updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ShelvePir")]
        [HttpPost]
        public async Task<IActionResult> ShelvePir([Bind("")] PirWorkFlowUpdateDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster ShelvedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.Shelved);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);

                    if (dbObj != null && ShelvedStatus != null)
                    {

                        dbObj.StatusId = ShelvedStatus.Id;
                        dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                        dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                        dbObj.UpdatedOn = DateTime.Now;

                        var result = await pirService.UpdatePir(dbObj);
                        if (result > 0)
                        {
                            ReturnMessage = "PIR Shelved successfully.";
                            await AddPirFlowHistoryAsync(dbObj.Id, ShelvedStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Shelved PIR");

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "PIR shelving Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("RevivePir")]
        [HttpPost]
        public async Task<IActionResult> RevivePir([Bind("")] revivePIRDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;
            try
            {
                TypeCodeMaster Status = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.Submitted);
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.pirCode);
                long Id = (long)IdData.Split("-").Last().ToInt64();


                if (Id > 0)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);

                    if (dbObj != null && Status != null)
                    {
                        dbObj.StatusId = Status.Id;
                        dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                        dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                        dbObj.UpdatedOn = DateTime.Now;

                        var result = await pirService.UpdatePir(dbObj);
                        if (result > 0)
                        {
                            ReturnMessage = "PIR Revived successfully.";
                            await AddPirFlowHistoryAsync(dbObj.Id, Status.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Revived PIR");

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.pirCode;
                        }
                        else
                        {
                            ReturnMessage = "PIR revive Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.pirCode;
                        }

                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.pirCode;
                    }

                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.pirCode;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeletePir")]
        [HttpPost]
        public async Task<IActionResult> DeletePir([Bind("")] PirWorkFlowUpdateDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster DeleteStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.Deleted);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);

                    if (dbObj != null && DeleteStatus != null)
                    {
                        dbObj.StatusId = DeleteStatus.Id;
                        dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                        dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                        dbObj.UpdatedOn = DateTime.Now;

                        var result = await pirService.UpdatePir(dbObj);
                        if (result > 0)
                        {
                            ReturnMessage = "PIR Deleted successfully.";
                            await AddPirFlowHistoryAsync(dbObj.Id, DeleteStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Deleted PIR");

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "PIR delete Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("RejectPir")]
        [HttpPost]
        public async Task<IActionResult> RejectPir([Bind("")] PirWorkFlowUpdateDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster RejectedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.Rejected);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);

                    if (dbObj != null && RejectedStatus != null)
                    {

                        dbObj.StatusId = RejectedStatus.Id;
                        dbObj.LastReminder = null;
                        dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                        dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                        dbObj.UpdatedOn = DateTime.Now;

                        var result = await pirService.UpdatePir(dbObj);
                        if (result > 0)
                        {
                            await pirService.SendEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR008", recevingDTO.Comment);

                            ReturnMessage = "PIR rejected successfully.";
                            await AddPirFlowHistoryAsync(dbObj.Id, RejectedStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Rejected PIR");

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "PIR updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("SendBackfromApprover")]
        [HttpPost]
        public async Task<IActionResult> SendBackfromApprover([Bind("")] PirWorkFlowUpdateDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster SentBack = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.SentBack);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);

                    if (dbObj != null && SentBack != null)
                    {

                        dbObj.StatusId = SentBack.Id;
                        dbObj.SentbackOn = DateTime.Now;
                        dbObj.LastReminder = null;
                        dbObj.SubmittedOn = null;
                        dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                        dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                        dbObj.UpdatedOn = DateTime.Now;
                        dbObj.SentbackBy = "APR";

                        var result = await pirService.UpdatePir(dbObj);
                        if (result > 0)
                        {
                            ReturnMessage = "PIR Send back successfully.";
                            await AddPirFlowHistoryAsync(dbObj.Id, SentBack.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Approver) Sent back PIR to Trial Fp");

                            PirApprovalList approvalObj = await pirService.GetApprovalListBySeq(dbObj.CurrentApprovalSeq, dbObj.Id, LoggedInUser.COMPANY_NUMBER);
                            approvalObj.Status = PIRApprovalStatus.SentBack;
                            approvalObj.Comments = recevingDTO.Comment;
                            approvalObj.ActionCompletionDate = DateTime.Now;
                            await pirService.UpdateApprovalList(approvalObj);

                            await pirService.SendEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR009", recevingDTO.Comment,LoggedInUser);

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "PIR Send back error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ApprovePir")]
        [HttpPost]
        public async Task<IActionResult> ApprovePir([Bind("")] PirWorkFlowUpdateDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                TypeCodeMaster UnderApprovalStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.UnderApproval);
                TypeCodeMaster ApprovalStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.Approved);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);

                    if (dbObj != null && UnderApprovalStatus != null && ApprovalStatus != null)
                    {

                        List<PirApprovalList> allApprovalOnSameSeq = await pirService.GetApprovalListBySeq(dbObj.CurrentApprovalSeq, dbObj.Id);
                        //Check if there is no more approavls on same seq
                        if (allApprovalOnSameSeq.Where(x => x.ActionRequiredBy != LoggedInUser.COMPANY_NUMBER && x.Status.Equals(PIRApprovalStatus.UnderApproval)).Count() == 0)
                        {
                            //check if there is next level approval
                            List<PirApprovalList> allSeqs = await pirService.GetApprovalListsByPirId(dbObj.Id);
                            if (allSeqs.Where(x => x.Seq == dbObj.CurrentApprovalSeq + 1).Count() > 0)
                            {
                                //Update current Seq level 
                                PirApprovalList approvalObj = await pirService.GetApprovalListBySeq(dbObj.CurrentApprovalSeq, dbObj.Id, LoggedInUser.COMPANY_NUMBER);
                                approvalObj.Status = PIRApprovalStatus.Approved;
                                approvalObj.Comments = recevingDTO.Comment;
                                approvalObj.ActionCompletionDate = DateTime.Now;
                                var saveResult = await pirService.UpdateApprovalList(approvalObj);
                                if (saveResult > 0)
                                {
                                    List<PirApprovalList> seqToUpdate = allSeqs.Where(x => x.Seq == dbObj.CurrentApprovalSeq + 1).ToList();
                                    seqToUpdate.ForEach((z) =>
                                    {
                                        z.ActionAssingedDate = DateTime.Now;
                                        z.Comments = "";
                                    });
                                    var saveNextLevelResult = await pirService.UpdateApprovalList(seqToUpdate);
                                    if (saveNextLevelResult > 0)
                                    {
                                        dbObj.CurrentApprovalSeq = dbObj.CurrentApprovalSeq + 1;
                                        var ctrResult = await pirService.UpdatePir(dbObj);
                                        if (ctrResult > 0)
                                        {
                                            ReturnMessage = "PIR approved successfully.";
                                            await AddPirFlowHistoryAsync(dbObj.Id, ApprovalStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Approver) with Seq " + (dbObj.CurrentApprovalSeq - 1) + " approved PIR");
                                            //Send New Level email;
                                            await pirService.SendEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR007");
                                            //Approved Email
                                            await pirService.SendEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR011N",employee:LoggedInUser);
                                        }
                                    }

                                }

                            }
                            // no next level, so this is the final level
                            else
                            {
                                //Update Approval Seq 
                                PirApprovalList approvalObj = await pirService.GetApprovalListBySeq(dbObj.CurrentApprovalSeq, dbObj.Id, LoggedInUser.COMPANY_NUMBER);
                                approvalObj.Status = PIRApprovalStatus.Approved;
                                approvalObj.Comments = recevingDTO.Comment;
                                approvalObj.ActionCompletionDate = DateTime.Now;
                                var saveResult = await pirService.UpdateApprovalList(approvalObj);
                                if (saveResult > 0)
                                {
                                    dbObj.StatusId = ApprovalStatus.Id;
                                    var ctrResult = await pirService.UpdatePir(dbObj);
                                    if (ctrResult > 0)
                                    {
                                        ReturnMessage = "PIR approved successfully.";
                                        await AddPirFlowHistoryAsync(dbObj.Id, ApprovalStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Approver) with Seq " + dbObj.CurrentApprovalSeq + " approved PIR completely");
                                        //Approved Email
                                        await pirService.SendEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR011",employee:LoggedInUser);
                                        //Fully Approved Email
                                        await pirService.SendEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR012",employee:LoggedInUser);
                                    }
                                }
                            }
                        }
                        //if some one else on same seq
                        else
                        {
                            //Update Approval Seq 
                            PirApprovalList approvalObj = await pirService.GetApprovalListBySeq(dbObj.CurrentApprovalSeq, dbObj.Id, LoggedInUser.COMPANY_NUMBER);
                            approvalObj.Status = PIRApprovalStatus.Approved;
                            approvalObj.Comments = recevingDTO.Comment;
                            approvalObj.ActionCompletionDate = DateTime.Now;
                            var saveResult = await pirService.UpdateApprovalList(approvalObj);
                            if (saveResult > 0)
                            {
                                ReturnMessage = "PIR approved successfully.";
                                await AddPirFlowHistoryAsync(dbObj.Id, UnderApprovalStatus.Id, recevingDTO.Comment, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Approver) with Seq " + dbObj.CurrentApprovalSeq + " approved PIR");

                                //Approved Email
                                await pirService.SendEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR011");
                            }
                        }

                        ReturnStatus = (int)ResponseStatus.success;
                        ReturnData = recevingDTO.IdEnc;
                    }
                    else
                    {
                        ReturnMessage = "PIR update error.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = "";
                    }

                }
                else
                {
                    ReturnMessage = "PIR data/status does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = "";
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAllApprovalListforPir/{pirCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllApprovalListforPir(string pirCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(pirCode);
                long Id = (long)IdData.Split("-").Last().ToInt64();

                var result = await pirService.GetAllApprovalListByPirId(Id);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetApprovalListFormData/{id}")]
        [HttpGet]
        public async Task<IActionResult> GetApprovalListFormData(long id)
        {
            try
            {

                if (id != 0)
                {
                    var result = await pirService.GetApprovalListFormData(id);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Additional Solution data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeletePirApprovalList/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeletePirApprovalList(long id)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = "";

            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                TypeCodeMaster UnderApproval = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.UnderApproval);
                PirApprovalList dbObj = await pirService.GetApprovalListById(id);

                if (dbObj != null)
                {
                    PirInitiation pirObj = await pirService.GetById(dbObj.PirId);
                    var deleteduser = await employeeService.getByMuNumber(dbObj.ActionRequiredBy);
                    TmUserRole UCTRole = await employeeService.GetRoleId(UserRolesParam.UCT);

                    if (pirObj.StatusId.Equals(UnderApproval.Id))
                    {
                        var allApproval = await pirService.GetAllApprovalListByPirId(dbObj.PirId);

                        if (dbObj.Seq < pirObj.CurrentApprovalSeq)
                        {
                            var rs1 = new TIP_RESULT()
                            {
                                message = "Cannot delete seq less than current seq = " + pirObj.CurrentApprovalSeq,
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(rs1);
                        }
                        else if (dbObj.Seq > pirObj.CurrentApprovalSeq)
                        {

                            var SameSeqCount = allApproval.Where(x => x.Seq.Equals(dbObj.Seq));
                            if (SameSeqCount.Count() > 1)
                            {

                                var r1 = await pirService.DeletePirApprovalList(id);
                                if (r1 > 0)
                                {
                                    await AddPirFlowHistoryAsync(pirObj.Id, pirObj.StatusId, "", UCTRole.RoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Deleted Approver : " + deleteduser.DISPLAY_NAME);
                                    await pirService.SendReassignEmail(pirObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR018", "", dbObj.ActionRequiredBy, LoggedInUser.DISPLAY_NAME);
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Approval list record deleted successfully.",
                                        status = (int)ResponseStatus.success,
                                        TResponse = r1
                                    };
                                    return Ok(rs1);
                                }
                                else
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Delete Failure",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(rs1);
                                }

                            }
                            else
                            {
                                var checkIfHigherLevelExist = allApproval.Where(x => x.Seq > dbObj.Seq);
                                if (checkIfHigherLevelExist.Count() > 0)
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Please add a record to seq " + dbObj.Seq + " then delete this record",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(rs1);
                                }
                                else
                                {
                                    var r1 = await pirService.DeletePirApprovalList(id);
                                    if (r1 > 0)
                                    {
                                        await AddPirFlowHistoryAsync(pirObj.Id, pirObj.StatusId, "", UCTRole.RoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Deleted Approver : " + deleteduser.DISPLAY_NAME);
                                        await pirService.SendReassignEmail(pirObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR018", "", dbObj.ActionRequiredBy, LoggedInUser.DISPLAY_NAME);
                                        var rs1 = new TIP_RESULT()
                                        {
                                            message = "Approval list record deleted successfully.",
                                            status = (int)ResponseStatus.success,
                                            TResponse = r1
                                        };
                                        return Ok(rs1);
                                    }
                                    else
                                    {
                                        var rs1 = new TIP_RESULT()
                                        {
                                            message = "Delete Failure",
                                            status = (int)ResponseStatus.error,
                                            TResponse = ""
                                        };
                                        return Ok(rs1);
                                    }
                                }
                            }



                        }
                        else if (pirObj.CurrentApprovalSeq.Equals(dbObj.Seq))
                        {
                            //dataset1 = get all current seq and see if there are any UA, if there are any, then can delete. if nothing is there
                            // then see if next level exist
                            var dataset1 = allApproval.Where(x => x.Id != dbObj.Id && x.Seq.Equals(dbObj.Seq)
                            && x.StatusCode.Equals(PIRApprovalStatus.UnderApproval));

                            if (dataset1.Count() > 0)
                            {
                                var r1 = await pirService.DeletePirApprovalList(id);
                                if (r1 > 0)
                                {
                                    await AddPirFlowHistoryAsync(pirObj.Id, pirObj.StatusId, "", UCTRole.RoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Deleted Approver : " + deleteduser.DISPLAY_NAME);
                                    await pirService.SendReassignEmail(pirObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR018", "", dbObj.ActionRequiredBy, LoggedInUser.DISPLAY_NAME);
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Approval list record deleted successfully.",
                                        status = (int)ResponseStatus.success,
                                        TResponse = r1
                                    };
                                    return Ok(rs1);
                                }
                                else
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Delete Failure",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(rs1);
                                }
                            }
                            else
                            {
                                var nextSeqData = allApproval.Where(x => x.Seq > pirObj.CurrentApprovalSeq);

                                if (nextSeqData.Count() > 0)
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Please add a record to current seq " + dbObj.Seq + " then delete this record",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(rs1);
                                }
                                else
                                {

                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Removing this record is not allowed since it is the last approver, please add another approver for the same seq before removing this record.",
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""
                                    };
                                    return Ok(rs1);

                                }
                            }
                        }
                        else
                        {
                            var rs1 = new TIP_RESULT()
                            {
                                message = "Delete not validated.",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(rs1);
                        }
                    }
                    else
                    {
                        var r1 = await pirService.DeletePirApprovalList(id);
                        var rs1 = new TIP_RESULT()
                        {
                            message = "Approval list record deleted successfully.",
                            status = (int)ResponseStatus.success,
                            TResponse = r1
                        };
                        return Ok(rs1);


                    }


                }
                else
                {
                    var rs1 = new TIP_RESULT()
                    {
                        message = "Pir approval data not found.",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(rs1);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("SendForApproval")]
        [HttpPost]
        public async Task<IActionResult> SendForApproval([Bind("")] PirApprovalDTO pirApprovalDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                var IdData = CryptoExtensions.Decrypt(pirApprovalDTO.PirCode);
                long PirId = (long)IdData.Split("-").Last().ToInt64();

                if (PirId != 0)
                {
                    var result = await pirService.GetAllApprovalListByPirId(PirId);

                    var dataset = result.Where(x => x.Seq.Equals(0) && x.ActionRequiredBy != null);
                    if (dataset != null && dataset.Count() > 0)
                    {
                        var r1 = new TIP_RESULT()
                        {
                            message = "Records with Seq 0 cannot contain approver. Delete record, or assign approver",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(r1);
                    }

                    var dataset3 = result.Where(x => x.Seq.Equals(0) && x.ActionRequiredBy == null);
                    if (dataset3 != null && dataset3.Count() == result.Count())
                    {
                        var r1 = new TIP_RESULT()
                        {
                            message = "There should be at least one approver.",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(r1);
                    }


                    var dataset2 = result.Where(x => x.Seq > 0);
                    if (dataset2 != null && dataset2.Count() > 0)
                    {
                        long index = 1;
                        long max = dataset2.Max(x => x.Seq);

                        foreach (var x in dataset2.DistinctBy(x => x.Seq).OrderBy(x => x.Seq))
                        {
                            if (index.Equals(x.Seq))
                            {
                                index++;
                            }
                            else
                            {
                                var r1 = new TIP_RESULT()
                                {
                                    message = "Sequence should be in proper order.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(r1);
                            }
                        }
                    }

                    if (dataset2 != null && dataset2.Count() > 0)
                    {
                        long distinctCount = dataset2.Select(x => x.ActionRequiredBy).Distinct().Count();
                        if (dataset2.Count() != distinctCount)
                        {
                            var r2 = new TIP_RESULT()
                            {
                                message = "Approvers cannot be duplicated.",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(r2);
                        }
                    }

                    //Proceed with Assigning Roles
                    List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                    TmUserRole PIRApprover = await employeeService.GetRoleId(UserRolesParam.PIRApprover);
                    foreach (var x in dataset2)
                    {
                        TmRoleToUserMapping newRtU = new TmRoleToUserMapping()
                        {
                            UserId = x.URle,
                            RoleId = PIRApprover.RoleId,
                            IsActive = 1,
                            CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                            CreatedOn = DateTime.Now
                        };
                        tmRoleToUsers.Add(newRtU);
                    }

                    if (tmRoleToUsers.Any())
                    {
                        var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);

                        if (empRoles > 0)
                        {
                            PirInitiation dbObj = await pirService.GetById(PirId);
                            TypeCodeMaster UnderApproval = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.UnderApproval);

                            bool firstRoundofApprovals = false;

                            if (dbObj.CurrentApprovalSeq == 0)
                            {
                                firstRoundofApprovals = true;
                                dbObj.CurrentApprovalSeq = 1;
                            }
                            else
                            {
                                firstRoundofApprovals = false;
                            }
                            dbObj.StatusId = UnderApproval.Id;
                            dbObj.UpdatedBy = LoggedInUser?.COMPANY_NUMBER;
                            dbObj.UpdatedByRef = LoggedInUser?.REFERENCE_INDICATOR;
                            dbObj.UpdatedOn = DateTime.Now;

                            var r2 = await pirService.UpdatePir(dbObj);
                            if (r2 > 0)
                            {
                                await pirService.UpdatePirAprovalList(PirId, dbObj.CurrentApprovalSeq, firstRoundofApprovals);
                                await pirService.SendEmail(PirId, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR007");

                                await AddPirFlowHistoryAsync(PirId, UnderApproval.Id, "", (long)pirApprovalDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (UCT) Sent PIR for Approval.");

                                var response = new TIP_RESULT()
                                {
                                    message = "PIR sent for approval successfully.",
                                    status = (int)ResponseStatus.success,
                                    TResponse = r2
                                };
                                return Ok(response);
                            }
                            else
                            {
                                var response = new TIP_RESULT()
                                {
                                    message = "PIR Update error.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(response);
                            }

                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "PIR Approval role creation error.",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }


                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "PIR Update error.",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }

                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "PIR data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddUpdatePirApproval")]
        [HttpPost]
        public async Task<IActionResult> AddUpdatePirApproval([Bind("")] PirApprovalListDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {
                var IdData = CryptoExtensions.Decrypt(recevingDTO.PirCode);
                long PirId = (long)IdData.Split("-").Last().ToInt64();
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                TmUserRole UCTRole = await employeeService.GetRoleId(UserRolesParam.UCT);

                PirInitiation pirObj = await pirService.GetById(PirId);
                TypeCodeMaster UnderApproval = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.UnderApproval);

                if (pirObj.StatusId.Equals(UnderApproval.Id))
                {
                    if (recevingDTO.Id > 0)
                    {
                        var ur = await pirService.GetAllApprovalListByPirId(PirId);
                        var ulst = ur.Where(x => x.Seq > 0 && x.Id != recevingDTO.Id && x.URle.Equals(recevingDTO.ActionBy.PERSONNEL_NUMBER));
                        if (ulst != null && ulst.Count() > 0)
                        {
                            long distinctCount = ulst.Select(x => x.ActionRequiredBy).Distinct().Count();
                            if (ulst.Count() == distinctCount)
                            {
                                var r2 = new TIP_RESULT()
                                {
                                    message = "Approvers cannot be duplicated.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(r2);
                            }
                        }

                        if (recevingDTO.Seq < pirObj.CurrentApprovalSeq)
                        {
                            var rs1 = new TIP_RESULT()
                            {
                                message = "Cannot update record with sequence less than the current sequence = " + pirObj.CurrentApprovalSeq,
                                status = (int)ResponseStatus.error,
                                TResponse = ""

                            };
                            return Ok(rs1);
                        }
                        else if (recevingDTO.Seq > pirObj.CurrentApprovalSeq)
                        {
                            var result = await pirService.GetAllApprovalListByPirId(PirId);
                            var dataset2 = result.Where(x => x.Seq > 0);
                            if (dataset2 != null && dataset2.Count() > 0)
                            {
                                long max = dataset2.Where(x => x.Id != recevingDTO.Id).Max(x => x.Seq);

                                if (recevingDTO.Seq > (max + 1))
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Please create approval seq with " + (max + 1) + " before updating record to  " + recevingDTO.Seq,
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""

                                    };
                                    return Ok(rs1);
                                }

                            }
                        }
                    }
                    else
                    {
                        var ur = await pirService.GetAllApprovalListByPirId(PirId);
                        var ulst = ur.Where(x => x.Seq > 0 && x.URle.Equals(recevingDTO.ActionBy.PERSONNEL_NUMBER));
                        if (ulst != null && ulst.Count() > 0)
                        {
                            long distinctCount = ulst.Select(x => x.ActionRequiredBy).Distinct().Count();
                            if (ulst.Count() == distinctCount)
                            {
                                var r2 = new TIP_RESULT()
                                {
                                    message = "Approvers cannot be duplicated.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(r2);
                            }
                        }

                        if (recevingDTO.Seq < pirObj.CurrentApprovalSeq)
                        {
                            var rs1 = new TIP_RESULT()
                            {
                                message = "Cannot create record with sequence less than the current sequence = " + pirObj.CurrentApprovalSeq,
                                status = (int)ResponseStatus.error,
                                TResponse = ""

                            };
                            return Ok(rs1);
                        }
                        else if (recevingDTO.Seq > pirObj.CurrentApprovalSeq)
                        {
                            var result = await pirService.GetAllApprovalListByPirId(PirId);
                            var dataset2 = result.Where(x => x.Seq > 0);
                            if (dataset2 != null && dataset2.Count() > 0)
                            {
                                long max = dataset2.Max(x => x.Seq);

                                if (recevingDTO.Seq > (max + 1))
                                {
                                    var rs1 = new TIP_RESULT()
                                    {
                                        message = "Please create approval seq with " + (max + 1) + " before creating " + recevingDTO.Seq,
                                        status = (int)ResponseStatus.error,
                                        TResponse = ""

                                    };
                                    return Ok(rs1);
                                }
                            }
                        }
                    }


                }

                if (recevingDTO.Id > 0)
                {
                    PirApprovalList dbObj = await pirService.GetApprovalListById(recevingDTO.Id);

                    if (dbObj != null)
                    {
                        var DefaultJobCodes = new string[] { "HNT", "LM", "TL", "CFDH", "DCO" };

                        if (!DefaultJobCodes.Contains(dbObj.JobCode))
                        {
                            dbObj.JobTitle = recevingDTO.JobTitle;
                        }

                        dbObj.Seq = recevingDTO.Seq;
                        dbObj.ActionRequiredBy = recevingDTO.ActionBy.PERSONNEL_NUMBER;

                        if (pirObj.StatusId.Equals(UnderApproval.Id))
                            dbObj.Status = PIRApprovalStatus.UnderApproval;
                        else
                            dbObj.Status = PIRApprovalStatus.Drafted;



                        var result = await pirService.UpdateApprovalList(dbObj);
                        if (result > 0)
                        {
                            if (pirObj.StatusId.Equals(UnderApproval.Id))
                            {
                                //Proceed with Assigning Roles
                                List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                                TmUserRole PIRApprover = await employeeService.GetRoleId(UserRolesParam.PIRApprover);

                                TmRoleToUserMapping newRtU = new TmRoleToUserMapping()
                                {
                                    UserId = recevingDTO.ActionBy.PERSONNEL_NUMBER,
                                    RoleId = PIRApprover.RoleId,
                                    IsActive = 1,
                                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now
                                };
                                tmRoleToUsers.Add(newRtU);

                                if (tmRoleToUsers.Any())
                                {
                                    var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                                }

                                await AddPirFlowHistoryAsync(pirObj.Id, pirObj.StatusId, "", UCTRole.RoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Updated Approver : " + dbObj.ActionRequiredBy + " to Seq : " + dbObj.Seq);
                                if (pirObj.CurrentApprovalSeq.Equals(dbObj.Seq))
                                    await pirService.SendReassignEmail(pirObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR019", dbObj.ActionRequiredBy, "", LoggedInUser.DISPLAY_NAME);
                            }

                            ReturnMessage = "Pir approval updated Successfully.";
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.Id;
                        }
                        else
                        {
                            ReturnMessage = "Pir approval updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.Id;
                        }

                    }
                    else
                    {
                        ReturnMessage = "Pir approval data not found.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.Id;
                    }

                }
                else
                {


                    var ApprovalList = await pirService.GetAllApprovalListByPirId(PirId);

                    var DefaultJobTitle = new string[] { "Head of New Technology", "Line Manager", "Technology Expert / SME", "CFDH/SME", "Deployment Contract Owner" };
                    var ToLowerArray = Array.ConvertAll(DefaultJobTitle, d => d.ToLower());

                    if (ApprovalList != null && ApprovalList.Count == 15)
                    {
                        ReturnMessage = "You have reached the maximum number of approvals allowed. MAX = 15";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = "";
                    }
                    else if (ToLowerArray.Contains(recevingDTO.JobTitle.ToLower().Trim()))
                    {
                        ReturnMessage = "Job title cannot be duplicated with default job titles";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = "";
                    }
                    else
                    {

                        PirApprovalList newObj = new PirApprovalList()
                        {
                            Id = 0,
                            Seq = recevingDTO.Seq,
                            PirId = PirId,
                            JobTitle = recevingDTO.JobTitle,
                            ActionRequiredBy = recevingDTO.ActionBy.PERSONNEL_NUMBER,
                            CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                            CreatedOn = DateTime.Now,
                            CreatedByRef = LoggedInUser?.REFERENCE_INDICATOR
                        };

                        if (pirObj.StatusId.Equals(UnderApproval.Id))
                            newObj.Status = PIRApprovalStatus.UnderApproval;
                        else
                            newObj.Status = PIRApprovalStatus.Drafted;

                        var result = await pirService.AddPirApprovalList(newObj);
                        if (result > 0)
                        {
                            if (pirObj.StatusId.Equals(UnderApproval.Id))
                            {
                                //Proceed with Assigning Roles
                                List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                                TmUserRole PIRApprover = await employeeService.GetRoleId(UserRolesParam.PIRApprover);

                                TmRoleToUserMapping newRtU = new TmRoleToUserMapping()
                                {
                                    UserId = recevingDTO.ActionBy.PERSONNEL_NUMBER,
                                    RoleId = PIRApprover.RoleId,
                                    IsActive = 1,
                                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now
                                };
                                tmRoleToUsers.Add(newRtU);

                                if (tmRoleToUsers.Any())
                                {
                                    var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                                }

                                await AddPirFlowHistoryAsync(pirObj.Id, pirObj.StatusId, "", UCTRole.RoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Added Approver : " + newObj.ActionRequiredBy + " to Seq : " + newObj.Seq);
                                }

                            ReturnMessage = "Pir approval added Successfully.";
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = result;
                        }
                        else
                        {
                            ReturnMessage = "Pir approval added Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = "";
                        }
                    }
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("ResetPirApproval")]
        [HttpPost]
        public async Task<IActionResult> ResetPirApproval([Bind("")] PirApprovalDTO pirApprovalDTO)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

                var IdData = CryptoExtensions.Decrypt(pirApprovalDTO.PirCode);
                long PirId = (long)IdData.Split("-").Last().ToInt64();

                if (PirId != 0)
                {
                    PirInitiation dbObj = await pirService.GetById(PirId);
                    if (dbObj != null)
                    {
                        var result = await pirService.ResetPirApproval(PirId);
                        if (result > 0)
                        {
                            await AddDefaultApprovalListAsync(PirId);
                            dbObj.CurrentApprovalSeq = 0;
                            await pirService.UpdatePir(dbObj);
                        }


                        var response = new TIP_RESULT()
                        {
                            message = "Pir Approval Reset Successfully",
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var r1 = new TIP_RESULT()
                        {
                            message = "Pir data/status does not exist.",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(r1);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region General Information

        [Route("GetPirGeneralInformationData/{pirCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetPirGeneralInformationData(string pirCode, long roleid)
        {
            try
            {
                var PirData = CryptoExtensions.Decrypt(pirCode);
                if (PirData.StartsWith("PIR-"))
                {
                    long PirId = (long)PirData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.GetPirData(PirId, roleid, LoggedInUser.COMPANY_NUMBER);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }




            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdatePirGeneralInformation")]
        [HttpPost]
        public async Task<IActionResult> UpdatePirGeneralInformation([Bind("")] PirGeneralInformationDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {

                TypeCodeMaster DraftedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.Drafted);

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);

                    if (dbObj != null && DraftedStatus != null)
                    {
                        var addObj = await UpdatePirGeneralInformationMapping(recevingDTO, dbObj);

                        var result = await pirService.UpdatePirGeneralInformation(addObj);
                        if (result > 0)
                        {
                            ReturnMessage = "PIR Updated Successfully.";
                            await AddPirFlowHistoryAsync(addObj.Id, DraftedStatus.Id, "", recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Trial Focal Point) updated PIR");
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "PIR updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }
                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private async Task<PirInitiation> UpdatePirGeneralInformationMapping(PirGeneralInformationDTO obj, PirInitiation dbObj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            dbObj.TechProviderName = obj.TechProviderName;
            dbObj.FirstTrialCommencementDate = obj.CommencementDate;
            dbObj.LastTrialConclutionDate = obj.ConclusionDate;
            dbObj.AgentName = obj.AgentName;
            dbObj.NoveltyId = obj.Novelty;
            dbObj.AvailabilityId = obj.Availability;
            dbObj.Source = obj.Source;
            
            dbObj.TrialCompleted = obj.TrialCompleted == "1" ? true : false;
            
            dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
            dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
            dbObj.UpdatedOn = DateTime.Now;

            return dbObj;
        }

        #endregion

        #region Trial Details

        [Route("GetPirTrialDetailsData/{pirCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetPirTrialDetailsData(string pirCode, long roleid)
        {
            try
            {
                var PirData = CryptoExtensions.Decrypt(pirCode);
                if (PirData.StartsWith("PIR-"))
                {
                    long PirId = (long)PirData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.GetPirTrialDetailsData(PirId, roleid, LoggedInUser.COMPANY_NUMBER);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }




            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdatePirTrialDetails")]
        [HttpPost]
        public async Task<IActionResult> UpdatePirTrialDetails([FromBody] PirTrialDetailsDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();

                TypeCodeMaster DraftedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.Drafted);

                if (Id > 0 && DraftedStatus != null)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);

                    if (dbObj != null)
                    {
                        if (recevingDTO.SupportingTeamMembers != null)
                        {
                            bool hasDuplicates = recevingDTO.SupportingTeamMembers.GroupBy(p => p.PERSONNEL_NUMBER)
                           .Any(g => g.Count() > 1);

                            if (hasDuplicates)
                            {
                                var response1 = new TIP_RESULT()
                                {
                                    message = "Cannot duplicate Supporting Team Members.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(response1);
                            }
                        }


                        var addObj = await UpdatePirTrialDetailsMapping(recevingDTO, dbObj);

                        var result = await pirService.UpdatePirTrialDetails(addObj);
                        if (result > 0)
                        {

                            List<PirSupportingMember> SupportingMemebers = new List<PirSupportingMember>();

                            if (recevingDTO.SupportingTeamMembers?.Count > 0)
                            {
                                foreach (AllPDOUsersDTO mfp in recevingDTO.SupportingTeamMembers)
                                {
                                    PirSupportingMember sm = new PirSupportingMember()
                                    {
                                        PirId = addObj.Id,
                                        Fp = mfp.PERSONNEL_NUMBER,
                                        RefId = mfp.REFERENCE_INDICATOR,
                                        JobTitle = mfp.JOB_DESCRIPTION,
                                    };
                                    SupportingMemebers.Add(sm);
                                }

                            }

                            if (SupportingMemebers.Any())
                            {
                                var mResult = await pirService.AddSupportingMemebers(SupportingMemebers);
                            }

                            ReturnMessage = "PIR Updated Successfully.";
                            await AddPirFlowHistoryAsync(addObj.Id, DraftedStatus.Id, "", recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Trial Focal Point) updated PIR");
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "PIR updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private async Task<PirInitiation> UpdatePirTrialDetailsMapping(PirTrialDetailsDTO obj, PirInitiation dbObj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            dbObj.TrialType = obj.TrialType;
            
            dbObj.ChallengesAddressed = obj.ChallengesAddressed;
            dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
            dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
            dbObj.UpdatedOn = DateTime.Now;

            return dbObj;
        }

        #endregion

        #region Trial Candidates

        [Route("GetAllTrialCandidates/{pirCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetAllTrialCandidates(string pirCode, long roleid)
        {
            try
            {
                var PirData = CryptoExtensions.Decrypt(pirCode);
                if (PirData.StartsWith("PIR-"))
                {
                    long PirId = (long)PirData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.GetAllTrialCandidates(PirId, roleid, LoggedInUser.COMPANY_NUMBER);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("AddUpdateTrialCandidates")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateTrialCandidates([Bind("")] PirTrialCandidateDTO recObj)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(recObj.pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long PirId = (long)IdData.Split("-").Last().ToInt64();

                    recObj.PirId = PirId;
                    if (recObj.Id > 0)
                    {
                        var result = await pirService.UpdateTrialCandidates(PirTrialCandidateDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate updated successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }
                    else
                    {
                        var result = await pirService.AddTrialCandidates(PirTrialCandidateDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate added successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Trial candidate data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }

                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteTrialCandidates/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteTrialCandidates(long id)
        {
            try
            {
                var result = await pirService.DeleteTrialCandidates(id);

                var response = new TIP_RESULT()
                {
                    message = "Trial candidate deleted successfully.",
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }

        private PirTrialCandidate PirTrialCandidateDTOMapping(PirTrialCandidateDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            PirTrialCandidate newObj = new PirTrialCandidate()
            {
                TypeId = obj.TypeId,
                Name = obj.Name,
                Cost = obj.Cst,
                CommencementDate = obj.CommencementDate,
                ConclusionDate = obj.ConclusionDate,
                ChallengeDescription = obj.ChallengeDescription,
                Comments = obj.Comments,
                PirId = obj.PirId
            };
            if (obj.Id > 0)
            {
                newObj.Id = obj.Id;
                newObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.UpdatedOn = DateTime.Now;
            }
            else
            {
                newObj.Id = 0;
                newObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.CreatedOn = DateTime.Now;
            }


            return newObj;
        }

        #endregion

        #region Assessment of Trial Results

        [Route("GetAllAssessmentTrialResults/{pirCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetAllAssessmentTrialResults(string pirCode, long roleid)
        {
            try
            {
                var PirData = CryptoExtensions.Decrypt(pirCode);
                if (PirData.StartsWith("PIR-"))
                {
                    long PirId = (long)PirData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.GetAllAssessmentTrialResults(PirId, roleid, LoggedInUser.COMPANY_NUMBER);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddUpdateAssessmentTrialResult")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateAssessmentTrialResult([Bind("")] PirAssessmentTrialResultDTO recObj)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(recObj.pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long PirId = (long)IdData.Split("-").Last().ToInt64();

                    recObj.PirId = PirId;
                    if (recObj.Id > 0)
                    {
                        var result = await pirService.UpdateAssessmentTrialResult(PirAssessmentTrialResultDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Assessment trial result updated successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Assessment trial result data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }
                    else
                    {
                        var result = await pirService.AddAssessmentTrialResult(PirAssessmentTrialResultDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Assessment trial result added successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Assessment trial result data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }

                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteAssessmentTrial/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteAssessmentTrial(long id)
        {
            try
            {
                var result = await pirService.DeleteAssessmentTrial(id);

                var response = new TIP_RESULT()
                {
                    message = "Assessment trial result deleted successfully.",
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }

        private PirAssessmentTrialResult PirAssessmentTrialResultDTOMapping(PirAssessmentTrialResultDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            PirAssessmentTrialResult newObj = new PirAssessmentTrialResult()
            {
                Parameter = obj.Parameter,
                Target = obj.Target,
                ConclusionId = obj.ConclusionId,
                Comments = obj.Comments,
                PirId = obj.PirId
            };
            if (obj.Id > 0)
            {
                newObj.Id = obj.Id;
                newObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.UpdatedOn = DateTime.Now;
            }
            else
            {
                newObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.CreatedOn = DateTime.Now;
            }


            return newObj;
        }

        #endregion


        #region LessonLearnt

        [Route("GetAllLessonLearnt/{pirCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetAllLessonLearnt(string pirCode, long roleid)
        {
            try
            {
                var PirData = CryptoExtensions.Decrypt(pirCode);
                if (PirData.StartsWith("PIR-"))
                {
                    long PirId = (long)PirData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.GetAllLessonLearnt(PirId, roleid, LoggedInUser.COMPANY_NUMBER);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddUpdateLessonLearnt")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateLessonLearnt([FromBody] PirLessonLearntDTO recObj)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(recObj.pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long PirId = (long)IdData.Split("-").Last().ToInt64();

                    recObj.PirId = PirId;
                    if (recObj.Id > 0)
                    {
                        var result = await pirService.UpdateLessonLearnt(LessonLearntDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Lesson learnt updated successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Lesson learnt result data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }
                    else
                    {
                        var result = await pirService.AddLessonLearnt(LessonLearntDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Lesson learnt added successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Lesson learnt data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }

                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteLessonLearnt/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteLessonLearnt(long id)
        {
            try
            {
                var result = await pirService.DeleteLessonLearnt(id);

                var response = new TIP_RESULT()
                {
                    message = "Lesson learnt deleted successfully.",
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }

        private PirLessonLearnt LessonLearntDTOMapping(PirLessonLearntDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            PirLessonLearnt newObj = new PirLessonLearnt()
            {
                Description = obj.Description,
                CorrectiveMeasures = obj.CorrectiveMeasures,
                PirId = obj.PirId
            };
            if (obj.Id > 0)
            {
                newObj.Id = obj.Id;
                newObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.UpdatedOn = DateTime.Now;
            }
            else
            {
                newObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.CreatedOn = DateTime.Now;
            }


            return newObj;
        }

        #endregion

        #region Impacted Existing Contracts
        [Route("AddContractsFromCtr")]
        [HttpPost]
        public async Task<IActionResult> AddContractsFromCtr([Bind("PirCode")] PirApprovalDTO pirApprovalDTO)
        {
            try
            {
                var PirData = CryptoExtensions.Decrypt(pirApprovalDTO.PirCode);
                if (PirData.StartsWith("PIR-"))
                {
                    long PirId = (long)PirData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.AddContractsFromCtr(PirId, LoggedInUser);
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Contracts Imported",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "No Contracts to be Imported",
                                status = (int)ResponseStatus.error,
                                TResponse = result
                            };
                            return Ok(response);
                        }

                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("GetAllImpactedContracts/{pirCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetAllImpactedContracts(string pirCode, long roleid)
        {
            try
            {
                var PirData = CryptoExtensions.Decrypt(pirCode);
                if (PirData.StartsWith("PIR-"))
                {
                    long PirId = (long)PirData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.GetAllImpactedContracts(PirId, roleid, LoggedInUser.COMPANY_NUMBER);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddUpdateImpactedExistingContractt")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateImpactedExistingContractt([Bind("")] PirImpactedExistingContractDTO recObj)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(recObj.pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long PirId = (long)IdData.Split("-").Last().ToInt64();

                    recObj.PirId = PirId;
                    if (recObj.Id > 0)
                    {
                        var result = await pirService.UpdateImpactedContracts(ImpactedExistingContractDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Impacted existing contract updated successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Impacted existing contract result data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }
                    else
                    {
                        var result = await pirService.AddImpactedContracts(ImpactedExistingContractDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Impacted existing contract added successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Impacted existing contract data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }

                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteImpactedContracts/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteImpactedContracts(long id)
        {
            try
            {
                var result = await pirService.DeleteImpactedContracts(id);

                var response = new TIP_RESULT()
                {
                    message = "Impacted existing contract deleted successfully.",
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }

        private PirImpactedExistingContract ImpactedExistingContractDTOMapping(PirImpactedExistingContractDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            PirImpactedExistingContract newObj = new PirImpactedExistingContract()
            {
                ContractNo = obj.ContractNo,
                ContractTitle = obj.ContractTitle,
                Contractor = obj.Contractor,
                Impact = obj.Impact,
                PirId = obj.PirId
            };
            if (obj.Id > 0)
            {
                newObj.Id = obj.Id;
                newObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.UpdatedOn = DateTime.Now;
            }
            else
            {
                newObj.Id = 0;
                newObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.CreatedOn = DateTime.Now;
            }


            return newObj;
        }

        #endregion

        #region Deployment Staircase

        [Route("AddDeploymentStaircaseFromCtr")]
        [HttpPost]
        public async Task<IActionResult> AddDeploymentStaircaseFromCtr([Bind("PirCode")] PirApprovalDTO pirApprovalDTO)
        {
            try
            {
                var PirData = CryptoExtensions.Decrypt(pirApprovalDTO.PirCode);
                if (PirData.StartsWith("PIR-"))
                {
                    long PirId = (long)PirData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.AddDeploymentStaircaseFromCtr(PirId, LoggedInUser);
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Deployment Staircase Imported",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "No Deployment to be Imported",
                                status = (int)ResponseStatus.error,
                                TResponse = result
                            };
                            return Ok(response);
                        }

                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }


        [Route("GetPirDeploymentStaircaseData/{pirCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetPirDeploymentStaircaseData(string pirCode, long roleid)
        {
            try
            {
                var PirData = CryptoExtensions.Decrypt(pirCode);
                if (PirData.StartsWith("PIR-"))
                {
                    long PirId = (long)PirData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.GetPirDeploymentStaircaseData(PirId, roleid, LoggedInUser.COMPANY_NUMBER);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }




            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdatePirDeploymentStaircaseData")]
        [HttpPost]
        public async Task<IActionResult> UpdatePirDeploymentStaircaseData([Bind("")] PirDeploymentStaircaseDetailsDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {

                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.IdEnc);
                long Id = (long)IdData.Split("-").Last().ToInt64();

                TypeCodeMaster DraftedStatus = await commonService.GetMasterDataByParentAndParam1(TypeCodes.PIRStatus, PIRStatus.Drafted);

                if (Id > 0 && DraftedStatus != null)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);

                    if (dbObj != null)
                    {

                        var addObj = await UpdatePirDeploymentStaircaseDetailsMapping(recevingDTO, dbObj);

                        var result = await pirService.UpdatePirDeploymentStaircaseData(addObj);
                        if (result > 0)
                        {
                            ReturnMessage = "PIR Updated Successfully.";
                            await AddPirFlowHistoryAsync(addObj.Id, DraftedStatus.Id, "", recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Trial Focal Point) updated PIR");
                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.IdEnc;
                        }
                        else
                        {
                            ReturnMessage = "PIR updating Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.IdEnc;
                        }

                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.IdEnc;
                    }

                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.IdEnc;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private async Task<PirInitiation> UpdatePirDeploymentStaircaseDetailsMapping(PirDeploymentStaircaseDetailsDTO obj, PirInitiation dbObj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            dbObj.DsAssumptionMode = obj.AssumptionMode;
            dbObj.DsComments = obj.Comments;
            dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
            dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
            dbObj.UpdatedOn = DateTime.Now;

            return dbObj;
        }



        [Route("GetAllDeploymentStaircase/{pirCode}/{roleid}")]
        [HttpGet]
        public async Task<IActionResult> GetAllDeploymentStaircase(string pirCode, long roleid)
        {
            try
            {
                var PirData = CryptoExtensions.Decrypt(pirCode);
                if (PirData.StartsWith("PIR-"))
                {
                    long PirId = (long)PirData.Split("-").Last().ToInt64();

                    if (PirId > 0)
                    {
                        EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                        var result = await pirService.GetAllDeploymentStaircase(PirId, roleid, LoggedInUser.COMPANY_NUMBER);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddUpdateDeploymentStaircase")]
        [HttpPost]
        public async Task<IActionResult> AddUpdateDeploymentStaircase([Bind("")] PirDeploymentStaircaseDTO recObj)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(recObj.pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long PirId = (long)IdData.Split("-").Last().ToInt64();

                    recObj.PirId = PirId;
                    if (recObj.Id > 0)
                    {
                        var result = await pirService.UpdateDeploymentStaircase(DeploymentStaircaseDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Deployment Staircase updated successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Deployment Staircase result data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }
                    else
                    {
                        var result = await pirService.AddDeploymentStaircase(DeploymentStaircaseDTOMapping(recObj));
                        if (result > 0)
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Deployment Staircase added successfully.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                            return Ok(response);
                        }
                        else
                        {
                            var response = new TIP_RESULT()
                            {
                                message = "Deployment Staircase data not found",
                                status = (int)ResponseStatus.error,
                                TResponse = ""
                            };
                            return Ok(response);
                        }
                    }

                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeleteDeploymentStaircase/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteDeploymentStaircase(long id)
        {
            try
            {
                var result = await pirService.DeleteDeploymentStaircase(id);

                var response = new TIP_RESULT()
                {
                    message = "Deployment Staircase deleted successfully.",
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }



        }

        private PirDeploymentStaircase DeploymentStaircaseDTOMapping(PirDeploymentStaircaseDTO a)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            PirDeploymentStaircase newObj = new PirDeploymentStaircase()
            {
                Id = a.Id,
                PirId = a.PirId,
                FeildStationName = a.FeildStationName,
                WellType = a.WellType,
                Year = a.Year,
                NoOfWells = a.NoOfWells,
                EstimatedVot = a.EstimatedVot,
                AssumptionMode = a.AssumptionMode,
                Comments = a.Comments,
            };
            if (a.Id > 0)
            {
                newObj.Id = a.Id;
                newObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.UpdatedOn = DateTime.Now;
            }
            else
            {
                newObj.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                newObj.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                newObj.CreatedOn = DateTime.Now;
            }


            return newObj;
        }



        private List<PirDeploymentStaircase> DeploymentStaircaseListDTOMapping(List<PirDeploymentStaircaseDTO> obj,long pirId)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            List<PirDeploymentStaircase> pirDeploymentStaircases = new List<PirDeploymentStaircase>();
            foreach (var a in obj)
            {
                PirDeploymentStaircase newObj = new PirDeploymentStaircase()
                {

                    PirId = pirId,
                    FeildStationName = a.FeildStationName,                    
                    Year = a.Year,
                    NoOfWells = a.NoOfWells,
                    EstimatedVot = a.EstimatedVot,
                    CreatedBy = LoggedInUser.COMPANY_NUMBER,
                    CreatedByRef = LoggedInUser.REFERENCE_INDICATOR,
                    CreatedOn = DateTime.Now
                };
                pirDeploymentStaircases.Add(newObj);
            }                
            return pirDeploymentStaircases;
        }
        #endregion

        #endregion

        #region PIR VOT

        [Route("GetPirVOT/{pirCode}")]
        [HttpGet]
        public async Task<IActionResult> GetChallengeVOT(string pirCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await pirService.GetPirVOT(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "PIR data not  found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "PIR data not  found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("AddOrUpdatePirVOT")]
        [HttpPost]
        public async Task<IActionResult> AddOrUpdateCtrVOT([FromBody] PirVotDTO pirVotDTO)
        {
            try
            {
                var vot = PirVOTDTOMapping(pirVotDTO);
                var result = await pirService.AddOrUpdateVOT(vot, pirVotDTO.isEdit);
                if (result > 0)
                {
                    await pirService.AddOrUpdateDepStaircase(DeploymentStaircaseListDTOMapping(pirVotDTO.stairCases, vot.PirId));
                }
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        private PirVot PirVOTDTOMapping(PirVotDTO obj)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();

            PirVot returnObj = new PirVot()
            {
                
                PirId = obj.pir_id,
                UnitId = obj.unit_id,
                NoOfUnitsYear1 = obj.nofUnitYear1,
                NoOfUnitsYear2 = obj.nofUnitYear2,
                NoOfUnitsYear3 = obj.nofUnitYear3,
                NoOfUnitsYear4 = obj.nofUnitYear4,
                NoOfUnitsYear5 = obj.nofUnitYear5,
                NoOfUnitsTrailScope = obj.nofUnitTrailScope,
                TechCost = obj.techCst,
                OtherCost = obj.otherCst,
                AvgIncrmntlOilGain = obj.avgIncrementalOilGain,
                TotOilDefermentAvoidance = obj.totOilAvoidance,
                CostSavingUnitYr = obj.cspu,
                PowerSavingUnitYr = obj.powerSavingPerUnit,
                CostAvoidance = obj.cstAvoidance,
                Co2ReductnUnitYr = obj.co2ruy,
                Hse = obj.hseBenefits,
                Quality = obj.quality,
                Compliance = obj.compliance,
                RiskFactor = obj.riskFactor,
                M3T0Bbl = obj.m3tobbl,
                Co2Tax = obj.co2Tax,
                MwhCost = obj.mwhCst,
                OilPrice = obj.op,
                TotalMwhReduction = obj.totMWHReductionScope,
                TotalCo2Reduction = obj.totCO2Reduction,
                VotUnitYear = obj.votPerUnitPerYear,
                VotTrailTotUnits = obj.vottrialTotalUnits,
                VotTotDeploymentUnits = obj.votTotalDeploymentUnits,
                CreatedBy = LoggedInUser.COMPANY_NUMBER,
                CreatedByRef = LoggedInUser.REFERENCE_INDICATOR,
                CreatedOn = DateTime.Now
            };

            if (returnObj.Id <= 0)
            {
                var IdData = CryptoExtensions.Decrypt(obj.pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    returnObj.PirId = Id;
                }
            }
            return returnObj;
        }

        #endregion

        #region PIR attachment

        [Route("GetAllFiles/{pirCode}")]
        [HttpGet]
        public async Task<IActionResult> GetAllFiles(string pirCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(pirCode);
                long Id = (long)IdData.Split("-").Last().ToInt64();
                var result = await commonService.GetAllFilesByLinkId(Id, "PIR Form", false);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("SaveAllFiles")]
        [HttpPost]
        public async Task<IActionResult> UploadAllFiles([Bind("")] DocumentUploadDTO documentUploadDTO)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(documentUploadDTO.code);
                long Id = (long)IdData.Split("-").Last().ToInt64();
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                long result = 0;
                var res = await commonService.DeleteDocument(Id, "PIR Form");
                foreach (var file in documentUploadDTO.files)
                {
                    DocumentRepo obj = new DocumentRepo()
                    {
                        LimkType = file.type,
                        LinkId = Id,
                        FilePath = (file.filepath),
                        CreatedBy = LoggedInUser.COMPANY_NUMBER,
                        CreatedOn = DateTime.Now,
                        FileName = CryptoExtensions.Encrypt(file.fileName),
                        FileType = file.fileExtension,
                        Description = file.description,
                        MimeType = file.mimeType,
                        IsActive = true,
                        IsExternalAccessible = file.isEA,
                    };
                    result = await commonService.AddDocument(obj);
                }
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        #endregion

        #region Pir Action Plan

        [Route("GetPirActionPlan/{pirCode}")]
        [HttpGet]
        public async Task<IActionResult> GetPirActionPlan(string pirCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await pirService.GetPirActionPlan(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir action plan data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir action plan data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("AddPirActionPlan")]
        [HttpPost]
        public async Task<IActionResult> AddPirActionPlan(PirActionPlanDTO pirActionPlanDTO)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(pirActionPlanDTO.pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    pirActionPlanDTO.pirId = Id;
                    var result = await pirService.AddPirActionPlan(PirActionPlanDTOMapping(pirActionPlanDTO));
                    if (result > 0)
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Action plan added successfully.",
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir action plan data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir action plan data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdatePirActionPlan")]
        [HttpPost]
        public async Task<IActionResult> UpdatePirActionPlan(PirActionPlanDTO pirActionPlanDTO)
        {
            try
            {
                var result = await pirService.UpdatePirActionPlan(PirActionPlanDTOMapping(pirActionPlanDTO));
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Action plan updated successfully.",
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir action plan data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("DeletePirActionPlan/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeletePirActionPlan(long id)
        {
            try
            {
                var result = await pirService.DeletePirActionPlan(id);
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir action plan data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private PirActionPlan PirActionPlanDTOMapping(PirActionPlanDTO pirActionPlanDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            PirActionPlan pirActionPlan = new PirActionPlan()
            {
                Id = pirActionPlanDTO.id,
                PirId = pirActionPlanDTO.pirId,
                Title = pirActionPlanDTO.title,
                Party = pirActionPlanDTO.actionParty,
                Target = pirActionPlanDTO.targetDate
            };
            if (pirActionPlan.Id > 0)
            {
                pirActionPlan.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                pirActionPlan.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                pirActionPlan.UpdatedOn = DateTime.Now;
            }
            else
            {
                pirActionPlan.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                pirActionPlan.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                pirActionPlan.CreatedOn = DateTime.Now;
            }
            return pirActionPlan;
        }

        #endregion

        #region PIR Summary 

        // Query string preferred; path kept for backward compatibility.
        [Route("GetPirSummary")]
        [Route("GetPirSummary/{pirCode}")]
        [HttpGet]
        public async Task<IActionResult> GetPirSummary(string pirCode)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(pirCode))
                {
                    return Ok(new TIP_RESULT()
                    {
                        message = "Pir summary plan data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    });
                }

                var IdData = CryptoExtensions.Decrypt(pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await pirService.GetPirSummary(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir summary plan data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir summary plan data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

        [Route("AddPirSummary")]
        [HttpPost]
        public async Task<IActionResult> AddPirSummary([FromBody] PirSummaryDTO pirSummaryDTO)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(pirSummaryDTO.pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();
                    pirSummaryDTO.pirId = Id;
                    var result = await pirService.AddPirSummary(PirSummaryDTOMapping(pirSummaryDTO));
                    if (result > 0)
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir summary is saved successfully",
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "Pir summary plan data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir summary plan data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("UpdatePirSummary")]
        [HttpPost]
        public async Task<IActionResult> UpdatePirSummary([FromBody] PirSummaryDTO pirSummaryDTO)
        {
            try
            {
                var result = await pirService.UpdatePirSummary(PirSummaryDTOMapping(pirSummaryDTO));
                if (result > 0)
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir summary is updated successfully",
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "Pir summary plan data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        private PirSummary PirSummaryDTOMapping(PirSummaryDTO pirSummaryDTO)
        {
            EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
            PirSummary pirSummary = new PirSummary()
            {
                Id = pirSummaryDTO.id,
                PirId = pirSummaryDTO.pirId,
                TrialId = pirSummaryDTO.trial,
                Summary = pirSummaryDTO.desc
            };
            if (pirSummary.Id > 0)
            {
                pirSummary.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                pirSummary.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                pirSummary.UpdatedOn = DateTime.Now;
            }
            else
            {
                pirSummary.CreatedBy = LoggedInUser.COMPANY_NUMBER;
                pirSummary.CreatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                pirSummary.CreatedOn = DateTime.Now;
            }
            return pirSummary;
        }

        #endregion

        #region Reassignment

        [Route("GetAllPIRforReAssignment/{CurrentRole}")]
        [HttpGet]
        public async Task<IActionResult> GetAllPIRforReAssignment(long CurrentRole)
        {
            try
            {
                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                TmUserRole Role = await employeeService.GetRoleId(CurrentRole);
                if (Role.Param.Equals(UserRolesParam.Administrator))
                {
                    var result = await pirService.GetAllPirforReAssignmentAdmin(LoggedInUser.COMPANY_NUMBER);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else if (Role.Param.Equals(UserRolesParam.UCT))
                {
                    var result = await pirService.GetAllPirforReAssignmentUCT(LoggedInUser.COMPANY_NUMBER);
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                    return Ok(response);
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = ""
                    };
                    return Ok(response);
                }

            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ChangeUctFp")]
        [HttpPost]
        public async Task<IActionResult> ChangeUctFp([Bind("")] PirUctChangeDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {


                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.PirCode);
                long Id = (long)IdData.Split("-").Last().ToInt64();



                if (Id > 0)
                {
                    PirInitiation dbObj = await pirService.GetById(Id);
                    List<PirTrialFp> trialFp = await pirService.GetAllPirTrialFpbyPirId(Id);

                    if (dbObj != null && !string.IsNullOrEmpty(recevingDTO.NewUctFp.PERSONNEL_NUMBER))
                    {
                        if (dbObj.UctFp.Equals(recevingDTO.NewUctFp.PERSONNEL_NUMBER))
                        {
                            ReturnMessage = "New Technology Advisor cannot be the same as Current Technology Advisor";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.PirCode;

                        }
                        else if (trialFp != null && trialFp.Where(x => recevingDTO.NewUctFp.PERSONNEL_NUMBER.Equals(x.Fp)).Count() > 0)
                        {
                            ReturnMessage = "New Technology Advisor cannot be the same as any Trial Fp";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.PirCode;

                        }
                        else
                        {
                            //Proceed with Assigning Roles
                            List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                            TmUserRole UctRole = await employeeService.GetRoleId(UserRolesParam.UCT);

                            var current = dbObj.UctFp;
                            dbObj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
                            dbObj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
                            dbObj.UpdatedOn = DateTime.Now;
                            dbObj.UctFp = recevingDTO.NewUctFp.PERSONNEL_NUMBER;

                            TmRoleToUserMapping roleUCT = new TmRoleToUserMapping()
                            {
                                UserId = recevingDTO.NewUctFp.PERSONNEL_NUMBER,
                                RoleId = UctRole.RoleId,
                                IsActive = 1,
                                CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                CreatedOn = DateTime.Now
                            };
                            tmRoleToUsers.Add(roleUCT);

                            

                            var result = await pirService.UpdatePir(dbObj);
                            if (result > 0)
                            {
                                if (tmRoleToUsers.Any())
                                {
                                    var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                                }

                                await pirService.SendReassignEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR013", recevingDTO.NewUctFp.PERSONNEL_NUMBER, current, LoggedInUser.DISPLAY_NAME);
                                await pirService.SendReassignEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR014", recevingDTO.NewUctFp.PERSONNEL_NUMBER, current, LoggedInUser.DISPLAY_NAME);
                                ReturnMessage = "PIR New Technlogy Advisor changed successfully.";
                                await AddPirFlowHistoryAsync(dbObj.Id, dbObj.StatusId, current + " to " + recevingDTO.NewUctFp.USER_DISPLAY, recevingDTO.CurrentRleId, LoggedInUser.DISPLAY_NAME + " (Admin) Changed New Technlogy Advisor");

                                ReturnStatus = (int)ResponseStatus.success;
                                ReturnData = recevingDTO.PirCode;
                            }
                            else
                            {
                                ReturnMessage = "PIR New Technlogy Advisor change Error.";
                                ReturnStatus = (int)ResponseStatus.error;
                                ReturnData = recevingDTO.PirCode;
                            }
                        }

                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.PirCode;
                    }

                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.PirCode;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

        [Route("ChangeTrialFp")]
        [HttpPost]
        public async Task<IActionResult> ChangeTrialFp([Bind("")] PirTrialFPChangeDTO recevingDTO)
        {
            string ReturnMessage = string.Empty;
            int ReturnStatus = 0;
            object ReturnData = null;

            try
            {


                EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
                var IdData = CryptoExtensions.Decrypt(recevingDTO.PirCode);
                long PirId = (long)IdData.Split("-").Last().ToInt64();


                if (PirId > 0)
                {
                    PirInitiation dbObj = await pirService.GetById(PirId);
                    var DetaildbObj = await pirService.GetPirWorkFlowData(PirId, recevingDTO.CurrentRleId, LoggedInUser.COMPANY_NUMBER);

                    if (recevingDTO.MandatoryTP != null)
                    {
                        if (recevingDTO.OtherTP?.Count > 0)
                        {
                            // Check for duplicates
                            var duplicates = recevingDTO.MandatoryTP.Select(m => m.PERSONNEL_NUMBER)
                                .Intersect(recevingDTO.OtherTP.Select(o => o.PERSONNEL_NUMBER));

                            if (duplicates.Any())
                            {
                                var response1 = new TIP_RESULT()
                                {
                                    message = "Cannot duplicate mandatory focal point as other focal point.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = ""
                                };
                                return Ok(response1);
                            }
                        }
                    }

                    //Proceed with Assigning Roles
                    List<TmRoleToUserMapping> tmRoleToUsers = new List<TmRoleToUserMapping>();
                    TmUserRole TrialFpRole = await employeeService.GetRoleId(UserRolesParam.TrialFP);

                    if (dbObj != null && DetaildbObj != null)
                    {

                        List<PirTrialFp> FocalPoints = new List<PirTrialFp>();

                        if (recevingDTO.MandatoryTP != null)
                        {
                            foreach (AllPDOUsersDTO mfp in recevingDTO.MandatoryTP)
                            {
                                PirTrialFp MFP = new PirTrialFp()
                                {
                                    PirId = PirId,
                                    Fp = mfp.PERSONNEL_NUMBER,
                                    IsMandatory = true,
                                    JobTitle = string.IsNullOrWhiteSpace(mfp.JOB_DESCRIPTION) ? "N/A" : (mfp.JOB_DESCRIPTION.Length > 200 ? mfp.JOB_DESCRIPTION[..200] : mfp.JOB_DESCRIPTION),
                                    RefInd = string.IsNullOrWhiteSpace(mfp.REFERENCE_INDICATOR)
                                        ? (mfp.PERSONNEL_NUMBER ?? "N/A")
                                        : (mfp.REFERENCE_INDICATOR.Length > 20 ? mfp.REFERENCE_INDICATOR[..20] : mfp.REFERENCE_INDICATOR)
                                };
                                FocalPoints.Add(MFP);

                                TmRoleToUserMapping roleUCT = new TmRoleToUserMapping()
                                {
                                    UserId = mfp.PERSONNEL_NUMBER,
                                    RoleId = TrialFpRole.RoleId,
                                    IsActive = 1,
                                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now
                                };
                                tmRoleToUsers.Add(roleUCT);
                            }
                        }

                        if (recevingDTO.OtherTP?.Count > 0)
                        {
                            foreach (AllPDOUsersDTO ofp in recevingDTO.OtherTP)
                            {
                                PirTrialFp OTFP = new PirTrialFp()
                                {
                                    PirId = PirId,
                                    Fp = ofp.PERSONNEL_NUMBER,
                                    IsMandatory = false,
                                    JobTitle = string.IsNullOrWhiteSpace(ofp.JOB_DESCRIPTION) ? "N/A" : (ofp.JOB_DESCRIPTION.Length > 200 ? ofp.JOB_DESCRIPTION[..200] : ofp.JOB_DESCRIPTION),
                                    RefInd = string.IsNullOrWhiteSpace(ofp.REFERENCE_INDICATOR)
                                        ? (ofp.PERSONNEL_NUMBER ?? "N/A")
                                        : (ofp.REFERENCE_INDICATOR.Length > 20 ? ofp.REFERENCE_INDICATOR[..20] : ofp.REFERENCE_INDICATOR)
                                };
                                FocalPoints.Add(OTFP);

                                TmRoleToUserMapping roleUCT = new TmRoleToUserMapping()
                                {
                                    UserId = ofp.PERSONNEL_NUMBER,
                                    RoleId = TrialFpRole.RoleId,
                                    IsActive = 1,
                                    CreatedBy = LoggedInUser?.COMPANY_NUMBER,
                                    CreatedOn = DateTime.Now
                                };
                                tmRoleToUsers.Add(roleUCT);
                            }
                        }
                        var mResult = await pirService.AddTrialFp(FocalPoints);
                        if (mResult > 0)
                        {
                            if (tmRoleToUsers.Any())
                            {
                                var empRoles = await employeeService.AddUserRoles(tmRoleToUsers);
                            }

                            string currentOfp = string.Empty;
                            var otherTpList = recevingDTO.OtherTP ?? new List<AllPDOUsersDTO>();
                            var mandatoryTpList = recevingDTO.MandatoryTP ?? new List<AllPDOUsersDTO>();
                            var detailMandatory = DetaildbObj.mandatoryFP ?? new List<AllPDOUsersDTO>();
                            var detailOther = DetaildbObj.otherFP ?? new List<AllPDOUsersDTO>();

                            var currentOfpCount = otherTpList.Select(x => x.USER_DISPLAY).Count();
                            if (currentOfpCount > 0)
                            {
                                currentOfp = otherTpList.Select(x => x.USER_DISPLAY).ToArray().Aggregate((a, x) => a + "; " + x);
                            }

                            string currentMfp = string.Empty;
                            var currentMfpCount = mandatoryTpList.Select(x => x.USER_DISPLAY).Count();
                            if (currentMfpCount > 0)
                            {
                                currentMfp = mandatoryTpList.Select(x => x.USER_DISPLAY).ToArray().Aggregate((a, x) => a + "; " + x);
                            }

                            long historyRoleId = recevingDTO.CurrentRleId;
                            if (historyRoleId <= 0)
                            {
                                TmUserRole historyRole = await employeeService.GetRoleId(UserRolesParam.UCT);
                                historyRoleId = historyRole.RoleId;
                            }

                            // Find PERSONNEL_NUMBER values in receivingDTOs that are not in detailDbObjects
                            List<string> newMandatoryMu = mandatoryTpList.Select(dto => dto.PERSONNEL_NUMBER)
                                                                             .Except(detailMandatory.Select(obj => obj.PERSONNEL_NUMBER))
                                                                             .ToList();

                            // Find PERSONNEL_NUMBER values in detailDbObjects that are not in receivingDTOs
                            List<string> oldMandatoryMu = detailMandatory.Select(obj => obj.PERSONNEL_NUMBER)
                                                                               .Except(mandatoryTpList.Select(dto => dto.PERSONNEL_NUMBER))
                                                                               .ToList();

                            foreach (string newManMu in newMandatoryMu)
                            {
                                await pirService.SendReassignEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR015", newManMu, "", LoggedInUser.DISPLAY_NAME);
                            }

                            foreach (string oldManMu in oldMandatoryMu)
                            {
                                await pirService.SendReassignEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR016", "", oldManMu, LoggedInUser.DISPLAY_NAME);
                            }

                            // Find PERSONNEL_NUMBER values in receivingDTOs that are not in detailDbObjects
                            List<string> newOtherMu = otherTpList.Select(dto => dto.PERSONNEL_NUMBER)
                                                                             .Except(detailOther.Select(obj => obj.PERSONNEL_NUMBER))
                                                                             .ToList();

                            // Find PERSONNEL_NUMBER values in detailDbObjects that are not in receivingDTOs
                            List<string> oldOtherMu = detailOther.Select(obj => obj.PERSONNEL_NUMBER)
                                                                               .Except(otherTpList.Select(dto => dto.PERSONNEL_NUMBER))
                                                                                .ToList();

                            if (newMandatoryMu.Any() || oldMandatoryMu.Any())
                            {
                                await AddPirFlowHistoryAsync(PirId, dbObj.StatusId, recevingDTO.CurrentMFp + " to " + currentMfp, historyRoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Changed Mandatory Trial FP");
                            }
                            if (newOtherMu.Any() || oldOtherMu.Any())
                            {
                                await pirService.SendReassignEmail(dbObj.Id, EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR017", "", "", LoggedInUser.DISPLAY_NAME);
                                await AddPirFlowHistoryAsync(PirId, dbObj.StatusId, recevingDTO.CurrentOFp + " to " + currentOfp, historyRoleId, LoggedInUser.DISPLAY_NAME + " (UCT) Changed Other Trial FP");
                            }

                            ReturnMessage = "Trial Focal Point changed successfully.";

                            ReturnStatus = (int)ResponseStatus.success;
                            ReturnData = recevingDTO.PirCode;
                        }
                        else
                        {
                            ReturnMessage = "Trial Focal Point change Error.";
                            ReturnStatus = (int)ResponseStatus.error;
                            ReturnData = recevingDTO.PirCode;
                        }
                    }
                    else
                    {
                        ReturnMessage = "PIR data/status does not exist.";
                        ReturnStatus = (int)ResponseStatus.error;
                        ReturnData = recevingDTO.PirCode;
                    }
                }
                else
                {
                    ReturnMessage = "PIR data does not exist.";
                    ReturnStatus = (int)ResponseStatus.error;
                    ReturnData = recevingDTO.PirCode;
                }

                var response = new TIP_RESULT()
                {
                    message = ReturnMessage,
                    status = ReturnStatus,
                    TResponse = ReturnData

                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = GetUserFacingExceptionMessage(ex),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }

		#endregion

		[Route("PirPrint/{pirCode}/{docType}")]
		[HttpGet]
		public async Task<IActionResult> PirPrint(string pirCode, string docType)
		{
			try
			{
				var IdData = CryptoExtensions.Decrypt(pirCode);
				if (IdData.StartsWith("PIR-"))
				{
					long Id = (long)IdData.Split("-").Last().ToInt64();


					if (Id > 0)
					{
						EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
						var result = await pirService.GetPirPrint(Id, (long)LoggedInUser.ACTIVE_R_ID, LoggedInUser.COMPANY_NUMBER, docType);
						var response = new FileContentResult(result.FileBytes, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(result.Type));
						return Ok(response);
					}
					else
					{
						var response = new TIP_RESULT()
						{
							message = "PIR data not found",
							status = (int)ResponseStatus.error,
							TResponse = ""
						};
						return Ok(response);
					}
				}
				else
				{
					var response = new TIP_RESULT()
					{
						message = "PIR data not found",
						status = (int)ResponseStatus.error,
						TResponse = ""
					};
					return Ok(response);
				}
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
			}
		}

        [Route("GetApproverListByPir/{pirCode}")]
        [HttpGet]
        public async Task<IActionResult> GetApproverListByPir(string pirCode)
        {
            try
            {
                var IdData = CryptoExtensions.Decrypt(pirCode);
                if (IdData.StartsWith("PIR-"))
                {
                    long Id = (long)IdData.Split("-").Last().ToInt64();

                    if (Id > 0)
                    {
                        var result = await pirService.GetApproverListByPir(Id);
                        var response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                        return Ok(response);
                    }
                    else
                    {
                        var response = new TIP_RESULT()
                        {
                            message = "PIR approver's data not found",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                        return Ok(response);
                    }
                }
                else
                {
                    var response = new TIP_RESULT()
                    {
                        message = "PIR approver's data not found",
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }

        }

		[Route("AddTrialCandidateFromCtr")]
		[HttpPost]
		public async Task<IActionResult> AddTrialCandidateFromCtr([Bind("PirCode")] PirApprovalDTO pirApprovalDTO)
		{
			try
			{
				var PirData = CryptoExtensions.Decrypt(pirApprovalDTO.PirCode);
				if (PirData.StartsWith("PIR-"))
				{
					long PirId = (long)PirData.Split("-").Last().ToInt64();

					if (PirId > 0)
					{
						EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
						var result = await pirService.AddTrialCandidateFromCtr(PirId, LoggedInUser);
						if (result > 0)
						{
							var response = new TIP_RESULT()
							{
								message = "Trial Candidate Imported",
								status = (int)ResponseStatus.success,
								TResponse = result
							};
							return Ok(response);
						}
						else
						{
							var response = new TIP_RESULT()
							{
								message = "No Trial Candidate to be Imported",
								status = (int)ResponseStatus.error,
								TResponse = result
							};
							return Ok(response);
						}

					}
					else
					{
						var response = new TIP_RESULT()
						{
							message = "Pir data not  found",
							status = (int)ResponseStatus.error,
							TResponse = ""
						};
						return Ok(response);
					}
				}
				else
				{
					var response = new TIP_RESULT()
					{
						message = "Pir data not  found",
						status = (int)ResponseStatus.error,
						TResponse = ""
					};
					return Ok(response);
				}

			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}
		}

		[Route("GetApprovedPir")]
		[HttpGet]
		public async Task<IActionResult> GetApprovedPir()
		{
			try
			{
				EmployeeDTO? LoggedInUser = GetIdentityOfLoggedInUser();
				var result = await pirService.GetApprovedPir(LoggedInUser.COMPANY_NUMBER, (long)LoggedInUser.ACTIVE_R_ID);
				var response = new TIP_RESULT()
				{
					message = ResponseStatus.success.ToString(),
					status = (int)ResponseStatus.success,
					TResponse = result
				};
				return Ok(response);
			}
			catch (Exception ex)
			{
				var response = new TIP_RESULT()
				{
					message = ex.Message.ToString(),
					status = (int)ResponseStatus.error,
					TResponse = ""
				};
				ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
				return Ok(response);
			}

		}

	}
}
