﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TIP_API.DTO;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using TIP_BusinessLogic.Interface;
using TIP_Common;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResponseController : BaseController
    {
        private readonly ICommonService _commonService;
        private readonly IResponseService _responseService;
        public ResponseController(ICommonService commonService, IResponseService challengeCheckListService) : base(commonService)
        {
            _commonService = commonService;
            _responseService = challengeCheckListService;
        }
        [Route("CreateResponse")]
        [HttpPost]
        public async Task<IActionResult> CreateResponse([Bind("")] ResponseDTO answers)
        {
            try
            {


                ChallengeResponse challenge = new ChallengeResponse()
                {
                    SourceId = answers.sourceId,
                    CreatedBy = Convert.ToInt64(answers.participant),
                    ChallengeRegistrationId = answers.challengeId,
                    UpdatedRole = "External",
                    CreatedOn = DateTime.Today
                };
                var ChallengeId = await _responseService.AddNewChallengeResponse(challenge);
                var response = new TIP_RESULT()
                {
                    message = ResponseStatus.success.ToString(),
                    status = (int)ResponseStatus.success,
                    TResponse = CryptoExtensions.Encrypt(ChallengeId.ToString())
                };
                return Ok(response);


            }
            catch (Exception ex)
            {
                var response = new TIP_RESULT()
                {
                    message = ex.Message.ToString(),
                    status = (int)ResponseStatus.error,
                    TResponse = ""
                };
                ExceptionLogger(ex, ControllerContext.ActionDescriptor.ActionName, ControllerContext.ActionDescriptor.ControllerName);
                return Ok(response);
            }
        }
        }
}
