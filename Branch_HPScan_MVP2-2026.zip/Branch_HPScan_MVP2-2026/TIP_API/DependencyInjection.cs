﻿using TIP_BAL.Interface.Admin;
using TIP_BAL.Services.Admin;
using TIP_DAL.Interface;
using TIP_DAL.Interface.Admin;
using TIP_DAL.Repository;
using TIP_DAL.Repository.Admin;
using System.Net;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_DAL.Interface.Base;
using TIP_CORE.Entities;

namespace TIP_API
{
    public static class DependencyInjection
    {

        public static void AddServiceDI(IServiceCollection service)
        {
            service.AddScoped<IUnitOfWork, UnitOfWork>();
            service.AddTransient<IUserSettingsService, UserSettingsService>();
            service.AddTransient<IUserSettingEFService, UserSettingEFService>();
            service.AddTransient<IDashboardService, DashboardService>();
            service.AddTransient<IEmployeeService, EmployeeService>();
            service.AddTransient<ICommonService, CommonService>();
            service.AddTransient<ITechnologyBankService, TechnologyBankService>();
            service.AddTransient<IBTMPainAreaService, BTMPainAreaService>();
            service.AddTransient<IBTMAssesmentService, BTMAssesmentService>();
            service.AddTransient<IChallengeCheckListService, ChallengeCheckListService>();
            service.AddTransient<IChallengeService, ChallengeService>();
            service.AddTransient<IChallengeSolutionReviewersService, ChallengeSolutionReviewersService>();
            service.AddTransient<ICtrService, CtrService>();
            service.AddTransient<IPIRService, PIRService>();
            service.AddTransient<IExecutionService, ExecutionService>();
            service.AddTransient<IDepVotService, DepVotService>();
            service.AddTransient<IAuditLogService, AuditLogService>();
            service.AddTransient<IEmailDiagnosticService, EmailDiagnosticService>();

		}

        public static void AddRepositoryDI(IServiceCollection service)
        {
            service.AddTransient<IAssetFPRespository, AssetFPRespository>();
            service.AddTransient<IClusterFPRespository, ClusterFPRespository>();
            //service.AddTransient<I, IClusterFPRespository>();
            service.AddTransient<IuserSettingsRepository, UserSettingsRepository>();
            service.AddTransient<IUserSettingsEFRepository, UserSettingsEFRepository>();
            service.AddTransient<IDashboardRepository, DashboardRepository>();
            service.AddTransient<IEmployeeRepository, EmployeeRepository>();
            service.AddTransient<IUserRoleRepository, UserRoleRepository>();
            service.AddTransient<ICommonRepository, CommonRepository>();
            service.AddTransient<ITechnologyBankRepository, TechnologyBankRepository>();
            service.AddTransient<IBTMAssesmentRepository, BTMAssesmentRepository>();
            service.AddTransient<IChallengeCheckListRepository, ChallengeCheckListRepository>();
            service.AddTransient<IChallengeDetailRepository, ChallengeDetailRepository>();
            service.AddTransient<IChallengeSolutionReviewersRepository, ChallengeSolutionReviewersRepository>();
            service.AddTransient<IChallengeVendorScreeningRepository, ChallengeVendorScreeningRepository>();
            service.AddTransient<IConfigurationRepository, ConfigurationRepository>();
            service.AddTransient<IChallengeResponseRepository, ChallengeResponseRepository>();
            service.AddTransient<IChallengeResponseQuestionRepository, ChallengeResponseQuestionRepository>();
            service.AddTransient<IEmailRepoRepository, EmailRepoRepository>();
            service.AddTransient<IDocumentRepoRepository, DocumentRepoRepository>();
            service.AddTransient<IVendorDetailRepository, VendorDetailRepository>();
            service.AddTransient<ICtrRepository, CtrRepository>();
            service.AddTransient<IChallengePublicationRepository, ChallengePublicationRepository>();
            service.AddTransient<IChallengeSourcesRepository, ChallengeSourcesRepository>();
            service.AddTransient<ICtrTrialFpRepository, CtrTrialFpRepository>();
            service.AddTransient<ICtrAdditionalSolutionsRepository, CtrAdditionalSolutionsRepository>();
            service.AddTransient<ICtrFlowHistoryRepository, CtrFlowHistoryRepository>();
            service.AddTransient<ICtrTrialRiskRepository, CtrTrialRiskRepository>();
            service.AddTransient<ICtrApprovalListRepository, CtrApprovalListRepository>();
            service.AddTransient<ICtrApprovalListHisRepository, CtrApprovalListHisRepository>();
            service.AddTransient<IAdJobDataRepository, AdJobDataRepository>();
            service.AddTransient<IPirRepository, PirRepository>();
            service.AddTransient<IPirTrialFpRepository, PirTrialFpRepository>();
            service.AddTransient<IPirFlowHistoryRepository, PirFlowHistoryRepository>();
            service.AddTransient<IPirSupportingMembersRepository, PirSupportingMembersRepository>();
            service.AddTransient<IPirLessonLearntRepository, PirLessonLearntRepository>();
            service.AddTransient<IPirAssessmentTrialResultRepository, PirAssessmentTrialResultRepository>();
            service.AddTransient<IPirTrialCandidateRepository, PirTrialCandidateRepository>();
            service.AddTransient<IPirImpactedExistingContractsRepository, PirImpactedExistingContractsRepository>();
            service.AddTransient<IPirDeploymentStaircaseRepository, PirDeploymentStaircaseRepository>();
            service.AddTransient<ICtrSchedulePriceRepository, CtrSchedulePriceRepository>();
            service.AddTransient<ICtrPercentageCompletionRepository, CtrPercentageCompletionRepository>();
            service.AddTransient<IExecutionInitiationRepository, ExecutionInitiationRepository>();
            service.AddTransient<IExecutionPlannedRepository, ExecutionPlannedRepository>();
            service.AddTransient<IExecutionPlannedTimelineRepository, ExecutionPlannedTimelineRepository>();
            service.AddTransient<IExecutionPotentialValueRepository, ExecutionPotentialValueRepository>();
            service.AddTransient<IExec_TrialCandiRepository, Exec_TrialCandiRepository>();
            service.AddTransient<IExec_TrialfpsRepository, Exec_TrialfpsRepository>();
            service.AddTransient<IExecutionActualPlanRepository, ExecutionActualPlanRepository>();
            service.AddTransient<IExeFlowHistoryRepository, ExeFlowHistoryRepository>();
            service.AddTransient<IExeInvoiceRepository, ExeInvoiceRepository>();
            service.AddTransient<IExeInvoiceFlowHistoryRepository, ExeInvoiceFlowHistoryRepository>();
            service.AddTransient<IErroLogRepository, ErroLogRepository>();
            service.AddTransient<IDepVotRepository, DepVotRepository>();
		}
    }

}
