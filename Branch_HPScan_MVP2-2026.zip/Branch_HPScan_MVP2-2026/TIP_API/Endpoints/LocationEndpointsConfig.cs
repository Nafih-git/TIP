﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using System.IO;
using System.Net.Mime;
using TIP_API.DTO;
using TIP_BAL.Interface;
using TIP_BAL.Interface.Admin;
using TIP_BusinessLogic.Interface;
using TIP_Common;
using TIP_Common.Admin;
using TIP_Common.Helpers;
using TIP_Core;
using TIP_CORE;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using static System.Net.WebRequestMethods;
using static TIP_API.Controllers.CommonController;
using static TIP_Common.Enum.Enum;
using File = System.IO.File;
using static TIP_Common.PDOSMS.TIPSMS;
using TIP_Common.Enum;
using System;
using TIP_BAL.Services;
using TIP_BusinessLogic.Services;
using Microsoft.Reporting.Map.WebForms.BingMaps;
using System.Text.RegularExpressions;
using System.Security.AccessControl;
using System.Text.Encodings.Web;


namespace TIP_API.Endpoints
{


    public class ApiKeyMiddleware
    {
        private readonly RequestDelegate _next;
        private
        const string APIKEY = "XApiKey";
        public ApiKeyMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            // Browsers do not send custom headers (e.g. XApiKey) on CORS preflight.
            if (HttpMethods.IsOptions(context.Request.Method))
            {
                await _next(context);
                return;
            }

            if (!context.Request.Headers.TryGetValue("XApiKey", out
                    var extractedApiKey))
            {
                context.Response.StatusCode = 401;
                await context.Response.WriteAsync("Api Key was not provided ");
                return;
            }
            var appSettings = context.RequestServices.GetRequiredService<IConfiguration>();
            if (appSettings.GetValue<string>(APIKEY) == null || appSettings.GetValue<string>(APIKEY) == "" || string.IsNullOrEmpty(extractedApiKey))
            {
                context.Response.StatusCode = 401;
                await context.Response.WriteAsync("Unauthorized client");
                return;
            }
            var apiKey = CryptoExtensions.Decrypt(appSettings.GetValue<string>(APIKEY));
            if (!apiKey.Equals(CryptoExtensions.Decrypt(extractedApiKey)))
            {
                context.Response.StatusCode = 401;
                await context.Response.WriteAsync("Unauthorized client");
                return;
            }

            await _next(context);
        }
    }




    public class LocationEndpointsConfig
    {
        protected readonly ICommonService commonService;
        
        public LocationEndpointsConfig(ICommonService _commonService)
        {
            commonService = _commonService;
            
        }

        public static void GetUserRoledataEndPoint(WebApplication app, IUserSettingsService userSettingsService, IChallengeService challengeService, ICommonService commonService, IResponseService responseService, ILogger logger, IHttpContextAccessor accessor, IConfiguration configuration)
        {
            app.MapGet("/api/GetUserRoledata", async () =>
            {
                var response = await userSettingsService.GetUserRoledata();
                return Results.Ok(response);
            });

            app.MapPost("/api/GetUserLogin", async ([FromBody] ExternalUserDTO vendorDetail) =>
            {

                var response = new TIP_RESULT();
                try
                {
                    var validate = await userSettingsService.ValidateVendor(vendorDetail.emailaddress, vendorDetail.pname, vendorDetail.cpb);
                    if (vendorDetail.cpb == "1")
                    {
                        if (validate == 1)
                        {
                            response = new TIP_RESULT()
                            {
                                message = ResponseStatus.success.ToString(),
                                status = (int)ResponseStatus.success,
                                TResponse = new object()
                            };
                        }
                        else if (validate == 2)
                        {
                            response = new TIP_RESULT()
                            {
                                message = "Not a valid user",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                        }
                        else if (validate == 3)
                        {
                            response = new TIP_RESULT()
                            {
                                message = "Not a valid data",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                        }
                        else
                        {
                            response = new TIP_RESULT()
                            {
                                message = ResponseStatus.error.ToString(),
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                        }

                    }
                    else
                    {
                        if (validate == 1)
                        {
                            //var MultiFactorBit = 1;// 1 = Email, 2 = MobileSMS
                            int randNumber;
                            try
                            {
                                randNumber = await GenerateRandomNo();
                            }
                            catch (Exception ex)
                            {
                                logger.LogCritical("Critical Error - Location EndPoint - GetUserLogin OTP GenerateRandomNo From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                                SaveOtpProcessErrorLog(commonService, ex, "GenerateRandomNo", vendorDetail.emailaddress, accessor.HttpContext);
                                throw;
                            }
                            long userOtpUpdate;
                            try
                            {
                                userOtpUpdate = await userSettingsService.UpdateOTP(vendorDetail.emailaddress, randNumber, 0);
                            }
                            catch (Exception ex)
                            {
                                logger.LogCritical("Critical Error - Location EndPoint - GetUserLogin OTP UpdateOTP From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                                SaveOtpProcessErrorLog(commonService, ex, "UpdateOTP", vendorDetail.emailaddress, accessor.HttpContext);
                                throw;
                            }
                            if (userOtpUpdate != 0)
                            {
                                ExternalUserDTO exUser;
                                try
                                {
                                    exUser = await userSettingsService.GetExternalUser(vendorDetail.emailaddress);//GetExternalUser
                                }
                                catch (Exception ex)
                                {
                                    logger.LogCritical("Critical Error - Location EndPoint - GetUserLogin OTP GetExternalUser From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                                    SaveOtpProcessErrorLog(commonService, ex, "GetExternalUser", vendorDetail.emailaddress, accessor.HttpContext);
                                    throw;
                                }
                                try
                                {
                                    var emailQueued = await userSettingsService.VendorLoginKeywordDTO(EmailModules.TMHVR, "EX001", randNumber.ToString(), vendorDetail.emailaddress);
                                    if (emailQueued)
                                    {
                                        SaveOtpProcessSuccessLog(commonService, "Login OTP email queued successfully for delivery.", "VendorLoginKeywordDTO_Email_Login", vendorDetail.emailaddress, accessor.HttpContext);
                                    }
                                    else
                                    {
                                        SaveOtpProcessDiagnosticLog(commonService, "VendorLoginKeywordDTO returned false; OTP email was not queued.", "VendorLoginKeywordDTO_Email", vendorDetail.emailaddress, accessor.HttpContext);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    logger.LogCritical("Critical Error - Location EndPoint - GetUserLogin OTP VendorLoginKeywordDTO From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                                    SaveOtpProcessErrorLog(commonService, ex, "VendorLoginKeywordDTO_Email", vendorDetail.emailaddress, accessor.HttpContext);
                                    throw;
                                }
                                string resultSms;
                                try
                                {
                                    resultSms = await SendSMS(PDOSMS.SMSLoginOTPMessageFP + randNumber.ToString() + PDOSMS.SMSLoginOTPMessageLP, exUser.phoneNumber);
                                }
                                catch (Exception ex)
                                {
                                    logger.LogCritical("Critical Error - Location EndPoint - GetUserLogin OTP SendSMS From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                                    SaveOtpProcessErrorLog(commonService, ex, "SendSMS_OTP", vendorDetail.emailaddress, accessor.HttpContext);
                                    resultSms = "99";
                                }
                                if (resultSms == "00")
                                {
                                    response = new TIP_RESULT()
                                    {
                                        message = ResponseStatus.success.ToString(),
                                        status = (int)ResponseStatus.success,
                                        TResponse = new object()
                                    };
                                }
                                else
                                {
                                    response = new TIP_RESULT()
                                    {
                                        message = "OTP Sms Failure, Contact Support. OTP Email sent Successfully",
                                        status = (int)ResponseStatus.success,
                                        TResponse = new object()
                                    };
                                    logger.LogCritical("Error - Location EndPoint - GetUserLogin   OTP Sms Failure, Tamimah Integration Issue From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);
                                    return response;
                                    
                                }
                            }
                            else
                            {
                                response = new TIP_RESULT()
                                {
                                    message = "OTP Sms Failure, Contact Support. OTP Email sent Successfully",
                                    status = (int)ResponseStatus.success,
                                    TResponse = new object()
                                };
                                logger.LogCritical("Error - Location EndPoint - GetUserLogin   OTP Sms Failure, Not Saving in database Issue From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);
                                return response;
                            }
                        }
                        else if (validate == 2)
                        {
                            response = new TIP_RESULT()
                            {
                                message = "6 failed login attempts, Account disabled.",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                            logger.LogCritical("Error - Location EndPoint - GetUserLogin 3 failed login attempts, Account disabled. From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);

                            return response;
                        }
                        else if (validate == 3)
                        {
                            response = new TIP_RESULT()
                            {
                                message = "User is Deactivated, Use forgot password screen to activate account.",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                            logger.LogCritical("Error - Location EndPoint - GetUserLogin User is Deactivated, Use forgot password screen to activate account. From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);
                            return response;
                        }
                        else
                        {
                            response = new TIP_RESULT()
                            {
                                message = "Username Password is incorrect.",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                            return response;
                        }
                    }
                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - GetUserLogin From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "GetUserLogin", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));
                    response = new TIP_RESULT()
                    {
                        message = "Unable to send OTP. Please try again or contact support.",
                        status = (int)ResponseStatus.error,
                        TResponse = new object()
                    };
                }



                return response;
            });

          

            app.MapPost("/api/AddingSource", async ([FromBody] ExternalUserDTO vendorDetail) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = commonService.GetMasterDataByParentAndParam1(TypeCodes.EmailTemplate, EmailModules.TMHVR).Result.Id;// 217;
                    emailSendConfigDTO.templateId = 18;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    emailSendConfigDTO.toRecipients.Add(vendorDetail.emailaddress);

                    var vendor = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ParticipationSource, ParticipationSources.Vendor);
                    vendorDetail.sourceId = vendor.Id;
                    var result = await userSettingsService.AddExternal_User(vendorDetail, emailSendConfigDTO);

                    if (result == 1)
                    {
                        response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                    }
                    else if (result == 2)
                    {
                        response = new TIP_RESULT()
                        {
                            message = "Vendor already exist",
                            status = (int)ResponseStatus.error,
                            TResponse = result
                        };
                    }
                    else if (result == 3)
                    {
                        response = new TIP_RESULT()
                        {
                            message = "Vendor Successfully saved, something went wrong on email.",
                            status = (int)ResponseStatus.error,
                            TResponse = result
                        };
                        logger.LogCritical("Error - Location EndPoint - AddingSource   Email not sending From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);
                        SaveOtpProcessDiagnosticLog(commonService, "AddExternal_User returned 3; registration email was not queued.", "AddExternal_User_Email", vendorDetail.emailaddress, accessor.HttpContext);

                    }
                    else
                    {
                        response = new TIP_RESULT()
                        {
                            message = ResponseStatus.error.ToString(),
                            status = (int)ResponseStatus.error,
                            TResponse = 0
                        };
                        logger.LogCritical("Error - Location EndPoint - AddingSource   vendor not saving From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);


                    }

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - AddingSource From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "AddingSource", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));
                }
                return response;
            });

            app.MapPost("/api/CreatePas", async ([FromBody] ExternalUserDTO vendorDetail) =>
            {
                var response = new TIP_RESULT();

                try
                {
                    var result = await userSettingsService.updateExternal_UserPA(vendorDetail);
                    if (result == 1)
                    {
                        response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                    }
                    else if (result == 2)
                    {
                        response = new TIP_RESULT()
                        {
                            message = "Password update failed. The new password you've chosen cannot be the same as any of your last 10 passwords.",
                            status = (int)ResponseStatus.error,
                            TResponse = result
                        };
                    }
                    else if (result == 3)
                    {
                        response = new TIP_RESULT()
                        {
                            message = "Invalid data",
                            status = (int)ResponseStatus.error,
                            TResponse = result
                        };
                    }
                    else
                    {
                        response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.error,
                            TResponse = new object()
                        };
                    }

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - CreatePas From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "CreatePas", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));
                }


                return response;
            });

            app.MapPost("/api/sendOTPForForget_Pa", async ([FromBody] ExternalUserDTO vendorDetail) =>
            {
                var response = new TIP_RESULT();
                try
                {

                    ExternalUserDTO exUser;
                    try
                    {
                        exUser = await userSettingsService.GetExternalUser(vendorDetail.emailaddress);//GetExternalUser
                    }
                    catch (Exception ex)
                    {
                        logger.LogCritical("Critical Error - Location EndPoint - sendOTPForForget_Pa OTP GetExternalUser From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                        SaveOtpProcessErrorLog(commonService, ex, "GetExternalUser", vendorDetail.emailaddress, accessor.HttpContext);
                        throw;
                    }

                    if (exUser != null)
                    {
                        //var MultiFactorBit = 1;// 1 = Email, 2 = MobileSMS
                        int randNumber;
                        try
                        {
                            randNumber = await GenerateRandomNo();
                        }
                        catch (Exception ex)
                        {
                            logger.LogCritical("Critical Error - Location EndPoint - sendOTPForForget_Pa OTP GenerateRandomNo From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                            SaveOtpProcessErrorLog(commonService, ex, "GenerateRandomNo", vendorDetail.emailaddress, accessor.HttpContext);
                            throw;
                        }
                        long userOtpUpdate;
                        try
                        {
                            userOtpUpdate = await userSettingsService.UpdateOTP(vendorDetail.emailaddress, randNumber, 1);
                        }
                        catch (Exception ex)
                        {
                            logger.LogCritical("Critical Error - Location EndPoint - sendOTPForForget_Pa OTP UpdateOTP From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                            SaveOtpProcessErrorLog(commonService, ex, "UpdateOTP", vendorDetail.emailaddress, accessor.HttpContext);
                            throw;
                        }
                        if (userOtpUpdate != 0)
                        {

                            response = new TIP_RESULT()
                            {
                                message = ResponseStatus.success.ToString(),
                                status = (int)ResponseStatus.success,
                                TResponse = new object()
                            };

                        }
                        else
                        {
                            response = new TIP_RESULT()
                            {
                                message = "Something went wrong",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                            return response;
                        }
                        try
                        {
                            var emailQueued = await userSettingsService.VendorLoginKeywordDTO(EmailModules.TMHVR, "EX001", randNumber.ToString(), vendorDetail.emailaddress);
                            if (emailQueued)
                            {
                                SaveOtpProcessSuccessLog(commonService, "Forgot Password OTP email queued successfully for delivery.", "VendorLoginKeywordDTO_Email_ForgotPassword", vendorDetail.emailaddress, accessor.HttpContext);
                            }
                            else
                            {
                                SaveOtpProcessDiagnosticLog(commonService, "VendorLoginKeywordDTO returned false; OTP email was not queued.", "VendorLoginKeywordDTO_Email", vendorDetail.emailaddress, accessor.HttpContext);
                            }
                        }
                        catch (Exception ex)
                        {
                            logger.LogCritical("Critical Error - Location EndPoint - sendOTPForForget_Pa OTP VendorLoginKeywordDTO From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                            SaveOtpProcessErrorLog(commonService, ex, "VendorLoginKeywordDTO_Email", vendorDetail.emailaddress, accessor.HttpContext);
                            throw;
                        }
                        string resultSms;
                        try
                        {
                            resultSms = await SendSMS(PDOSMS.SMSLoginOTPMessageFP + randNumber.ToString() + PDOSMS.SMSLoginOTPMessageLP, exUser.phoneNumber);
                        }
                        catch (Exception ex)
                        {
                            logger.LogCritical("Critical Error - Location EndPoint - sendOTPForForget_Pa OTP SendSMS From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                            SaveOtpProcessErrorLog(commonService, ex, "SendSMS_OTP", vendorDetail.emailaddress, accessor.HttpContext);
                            resultSms = "99";
                        }
                        if (resultSms == "00")
                        {
                            
                            if (userOtpUpdate != 0)
                            {
                                response = new TIP_RESULT()
                                {
                                    message = ResponseStatus.success.ToString(),
                                    status = (int)ResponseStatus.success,
                                    TResponse = new object()
                                };
                            }
                            else
                            {
                                response = new TIP_RESULT()
                                {
                                    message = "OTP Sms Failure, Contact Support.",
                                    status = (int)ResponseStatus.error,
                                    TResponse = new object()
                                };
                                return response;
                            }
                        }
                        else
                        {
                            response = new TIP_RESULT()
                            {
                                message = "OTP Sms Failure, Contact Support.",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                            return response;

                        }
                    }
                    else
                    {
                        response = new TIP_RESULT()
                        {
                            message = "Email Sent Successfully...",
                            status = (int)ResponseStatus.error,
                            TResponse = new object()
                        };
                        logger.LogCritical("Critical Error - Location EndPoint - sendOTPForForget_Pa From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + "- User try to forget password but user not exist in our Application");

                        return response;
                    }
                    //SendForgetPa

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - sendOTPForForget_Pa From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "sendOTPForForget_Pa", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));
                }
                return response;
            });

            app.MapPost("/api/LocalSolution", async ([FromBody] LocalSolutionDTO localSolutionDTO) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    var statusId = commonService.GetMasterDataByParentAndParam1(TypeCodes.ChallengeResponseStatus, localSolutionDTO.status).Result.Id;
                    long responseId = (long)CryptoExtensions.Decrypt(localSolutionDTO.cfcode).ToInt64();
                    ChallengeResponse challengeResponse = new ChallengeResponse()
                    {
                        Id = responseId,
                        TechnologyName = localSolutionDTO.title,
                        TechnologyDescription = localSolutionDTO.description,
                        ChallengeRegistrationId = localSolutionDTO.chaRegId,
                        SourceId = localSolutionDTO.sourceId,
                        CompanyId = localSolutionDTO.companyId,
                        UpdatedRole = SolutionReviewer.External_User,
                        StatusId = statusId
                    };
                    if (challengeResponse.Id > 0)
                    {
                        challengeResponse.UpdatedBy = localSolutionDTO.participateId.ToString();
                        challengeResponse.UpdatedByRef = "";
                        challengeResponse.UpdatedOn = DateTime.Now;
                        challengeResponse.CreatedOn = DateTime.Now;
                    }
                    var result = await challengeService.UpdateLocalSolution(challengeResponse);
                    if (result > 0)
                    {
                        response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = result
                        };
                    }
                    else
                    {
                        response = new TIP_RESULT()
                        {
                            message = "",
                            status = (int)ResponseStatus.error,
                            TResponse = new object()
                        };
                    }
                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - LocalSolution From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "LocalSolution", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));
                }


                return response;//Results.Ok(response)
            });

            app.MapPost("/api/OTPSubmit", async ([FromBody] ExternalUserDTO vendorDetail) =>
            {

                ExternalUserDTO ExtObj = new ExternalUserDTO();
                try
                {
                    long validate;
                    try
                    {
                        validate = await userSettingsService.ValidateOTP(vendorDetail.emailaddress, Convert.ToInt32(vendorDetail.otpCODE));
                    }
                    catch (Exception ex)
                    {
                        logger.LogCritical("Critical Error - Location EndPoint - OTPSubmit ValidateOTP From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                        SaveOtpProcessErrorLog(commonService, ex, "ValidateOTP", vendorDetail.emailaddress, accessor.HttpContext);
                        throw;
                    }
                    var response = new TIP_RESULT();

                    if (validate == 1)
                    {
                        try
                        {
                            ExtObj = await userSettingsService.GetExternalUser(vendorDetail.emailaddress);
                        }
                        catch (Exception ex)
                        {
                            logger.LogCritical("Critical Error - Location EndPoint - OTPSubmit GetExternalUser From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                            SaveOtpProcessErrorLog(commonService, ex, "GetExternalUser", vendorDetail.emailaddress, accessor.HttpContext);
                            throw;
                        }
                        if (ExtObj != null)
                        {
                            long userOtpUpdate;
                            try
                            {
                                userOtpUpdate = await userSettingsService.UpdateOTP(vendorDetail.emailaddress, 99999, 0);
                            }
                            catch (Exception ex)
                            {
                                logger.LogCritical("Critical Error - Location EndPoint - OTPSubmit UpdateOTP From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                                SaveOtpProcessErrorLog(commonService, ex, "UpdateOTP", vendorDetail.emailaddress, accessor.HttpContext);
                                throw;
                            }
                            try
                            {
                                await userSettingsService.saveUserlog(ExtObj.id, UserLogStatus.LoginSuccess);
                            }
                            catch (Exception ex)
                            {
                                logger.LogCritical("Critical Error - Location EndPoint - OTPSubmit saveUserlog From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                                SaveOtpProcessErrorLog(commonService, ex, "saveUserlog", vendorDetail.emailaddress, accessor.HttpContext);
                                throw;
                            }
                            if (userOtpUpdate != 0)
                            {
                                ExtObj.val_Bit = true;

                            }
                            else
                            {
                                ExtObj.message = "OTP not updated";
                                ExtObj.val_Bit = false;
                                logger.LogCritical("Error - Location EndPoint - OTP not updated From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);
                                SaveOtpProcessDiagnosticLog(commonService, "OTPSubmit UpdateOTP returned 0 after successful OTP validation.", "UpdateOTP", vendorDetail.emailaddress, accessor.HttpContext);
                            }
                        }
                    }
                    else if (validate == 2)
                    {
                        ExtObj.message = "OTP expired, request for new OTP";
                        ExtObj.val_Bit = false;
                        logger.LogCritical("Error - Location EndPoint - OTP Timeout From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);
                    }
                    else if (validate == 3)
                    {
                        ExtObj.message = "Trying to use same OTP";
                        ExtObj.val_Bit = false;
                        logger.LogCritical("Critical Error - Location EndPoint - Trying to use same OTP From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);
                    }
                    else
                    {
                        ExtObj.message = "OTP Incorrect";
                        ExtObj.val_Bit = false;
                    }

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - OTPSubmit From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "OTPSubmit", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));
                }
             

                return ExtObj;
            });

            // SSO: skip OTP — return registered external user by email if they exist and are active.
            // Resolve scoped/transient services from the request DI container (not the startup-captured
            // instances). Capturing IUserSettingsService from BuildServiceProvider() reuses one
            // DbContext across concurrent requests and causes InvalidOperationException.
            app.MapPost("/api/GetExternalUserForSso", async (
                [FromBody] ExternalUserDTO vendorDetail,
                IUserSettingsService ssoUserSettingsService,
                ICommonService ssoCommonService,
                IHttpContextAccessor ssoAccessor,
                ILoggerFactory loggerFactory) =>
            {
                var ssoLogger = loggerFactory.CreateLogger("GetExternalUserForSso");
                ExternalUserDTO ExtObj = new ExternalUserDTO();
                try
                {
                    if (string.IsNullOrWhiteSpace(vendorDetail?.emailaddress))
                    {
                        ExtObj.val_Bit = false;
                        ExtObj.message = "Email is required";
                        return ExtObj;
                    }

                    ExtObj = await ssoUserSettingsService.GetExternalUser(vendorDetail.emailaddress.Trim());
                    if (ExtObj == null)
                    {
                        ExtObj = new ExternalUserDTO
                        {
                            emailaddress = vendorDetail.emailaddress,
                            val_Bit = false,
                            message = "User does not exist. Please register or contact support."
                        };
                        ssoLogger.LogCritical("Error - Location EndPoint - GetExternalUserForSso user not found. Email: " + vendorDetail.emailaddress + " - " + AccountHelper.GetWinAuthIPForLogs(ssoAccessor.HttpContext));
                        return ExtObj;
                    }

                    if (ExtObj.isActive == false)
                    {
                        ExtObj.pname = string.Empty;
                        ExtObj.val_Bit = false;
                        ExtObj.message = "User is deactivated. Use forgot password to activate or contact support.";
                        ssoLogger.LogCritical("Error - Location EndPoint - GetExternalUserForSso user deactivated. Email: " + vendorDetail.emailaddress + " - " + AccountHelper.GetWinAuthIPForLogs(ssoAccessor.HttpContext));
                        return ExtObj;
                    }

                    ExtObj.pname = string.Empty;
                    ExtObj.val_Bit = true;
                    ExtObj.message = ResponseStatus.success.ToString();
                    try
                    {
                        await ssoUserSettingsService.saveUserlog(ExtObj.id, UserLogStatus.LoginSuccess);
                    }
                    catch (Exception logEx)
                    {
                        // Login must not fail because audit/login-log insert failed.
                        ssoLogger.LogCritical("GetExternalUserForSso saveUserlog failed for {Email}: {Error}",
                            vendorDetail.emailaddress, GetErrorMessage(logEx));
                        try
                        {
                            ssoCommonService.SaveApplicationErrorLog(
                                GetErrorMessage(logEx) + $" | OTP process step: saveUserlog | Email: {vendorDetail.emailaddress ?? "n/a"}",
                                "saveUserlog",
                                "LocationEndPoints",
                                "External",
                                AccountHelper.GetWinAuthIPForLogs(ssoAccessor.HttpContext));
                        }
                        catch (Exception)
                        {
                            // Do not fail SSO login if error logging fails.
                        }
                    }
                }
                catch (Exception ex)
                {
                    ssoLogger.LogCritical("Critical Error - Location EndPoint - GetExternalUserForSso From External To Internal - Post Method " + AccountHelper.GetWinAuthIPForLogs(ssoAccessor.HttpContext) + "-" + " Internal Application - " + ssoAccessor.HttpContext.Connection.RemotePort + " - " + ssoAccessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    ssoCommonService.SaveApplicationErrorLog(GetErrorMessage(ex), "GetExternalUserForSso", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(ssoAccessor.HttpContext));
                    ExtObj = new ExternalUserDTO
                    {
                        emailaddress = vendorDetail?.emailaddress,
                        val_Bit = false,
                        message = "Unable to complete SSO login. Please register or contact support."
                    };
                }

                return ExtObj;
            });

            app.MapPost("/api/OTPSubmitForgetP", async ([FromBody] ExternalUserDTO vendorDetail) =>
            {

                ExternalUserDTO ExtObj = new ExternalUserDTO();
                var response = new TIP_RESULT();
                var emailForOtp = vendorDetail?.emailaddress?.Trim();
                try
                {
                    if (string.IsNullOrWhiteSpace(emailForOtp) || vendorDetail?.otpCODE == null)
                    {
                        response = new TIP_RESULT()
                        {
                            message = "Email and OTP are required.",
                            status = (int)ResponseStatus.error,
                            TResponse = new object()
                        };
                        commonService.SaveApplicationErrorLog(
                            "OTPSubmitForgetP rejected: missing email or OTP.",
                            "OTPSubmitForgetP_Validation",
                            "LocationEndPoints",
                            emailForOtp ?? "External",
                            AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));
                        return response;
                    }

                    vendorDetail.emailaddress = emailForOtp;
                    long validate;
                    try
                    {
                        validate = await userSettingsService.ValidateOTP(vendorDetail.emailaddress, Convert.ToInt32(vendorDetail.otpCODE));
                    }
                    catch (Exception ex)
                    {
                        logger.LogCritical("Critical Error - Location EndPoint - OTPSubmitForgetP ValidateOTP From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                        SaveOtpProcessErrorLog(commonService, ex, "ValidateOTP", vendorDetail.emailaddress, accessor.HttpContext);
                        throw;
                    }
                    if (validate == 1)
                    {
                        try
                        {
                            ExtObj = await userSettingsService.GetExternalUser(vendorDetail.emailaddress);
                        }
                        catch (Exception ex)
                        {
                            logger.LogCritical("Critical Error - Location EndPoint - OTPSubmitForgetP GetExternalUser From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                            SaveOtpProcessErrorLog(commonService, ex, "GetExternalUser", vendorDetail.emailaddress, accessor.HttpContext);
                            throw;
                        }
                        if (ExtObj != null)
                        {
                            long userOtpUpdate;
                            try
                            {
                                userOtpUpdate = await userSettingsService.UpdateOTP(vendorDetail.emailaddress, 99999, 1);
                            }
                            catch (Exception ex)
                            {
                                logger.LogCritical("Critical Error - Location EndPoint - OTPSubmitForgetP UpdateOTP From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                                SaveOtpProcessErrorLog(commonService, ex, "UpdateOTP", vendorDetail.emailaddress, accessor.HttpContext);
                                throw;
                            }
                            try
                            {
                                await userSettingsService.saveUserlog(ExtObj.id, UserLogStatus.ForgetPa);
                            }
                            catch (Exception ex)
                            {
                                // Audit log failure must not block the forgot-password reset email.
                                logger.LogCritical("Critical Error - Location EndPoint - OTPSubmitForgetP saveUserlog From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                                SaveOtpProcessErrorLog(commonService, ex, "saveUserlog", vendorDetail.emailaddress, accessor.HttpContext);
                            }
                            if (userOtpUpdate != 0)
                            {
                                ExtObj.val_Bit = true;
                            }
                            else
                            {
                                response = new TIP_RESULT()
                                {
                                    message = "OTP not updated",
                                    status = (int)ResponseStatus.success,
                                    TResponse = new object()
                                };
                                logger.LogCritical("Critical Error - Location EndPoint - OTP not updated From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);
                                SaveOtpProcessDiagnosticLog(commonService, "OTPSubmitForgetP UpdateOTP returned 0 after successful OTP validation.", "UpdateOTP", vendorDetail.emailaddress, accessor.HttpContext);
                            }

                        }
                        EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                        emailSendConfigDTO.moduleId = 217;
                        emailSendConfigDTO.templateId = 45;
                        emailSendConfigDTO.toRecipients = new List<string>();
                        emailSendConfigDTO.toRecipients.Add(vendorDetail.emailaddress);
                        long result;
                        try
                        {
                            result = await userSettingsService.SendForgetPa(emailSendConfigDTO, vendorDetail.emailaddress);
                        }
                        catch (Exception ex)
                        {
                            logger.LogCritical("Critical Error - Location EndPoint - OTPSubmitForgetP SendForgetPa From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                            SaveOtpProcessErrorLog(commonService, ex, "SendForgetPa", vendorDetail.emailaddress, accessor.HttpContext);
                            commonService.SaveApplicationErrorLog(
                                GetErrorMessage(ex) + $" | OTPSubmitForgetP SendForgetPa | Email={vendorDetail.emailaddress}",
                                "SendForgetPa",
                                "LocationEndPoints",
                                vendorDetail.emailaddress ?? "External",
                                AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));
                            response = new TIP_RESULT()
                            {
                                message = "Reset password email could not be sent. Please try again or contact support.",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                            return response;
                        }

                        if (result == 1)
                        {
                            SaveOtpProcessSuccessLog(commonService, "Forgot Password reset email queued successfully after OTP validation.", "SendForgetPa_Email", vendorDetail.emailaddress, accessor.HttpContext);
                            response = new TIP_RESULT()
                            {
                                message = "If your email is registered, a reset link has been sent.",
                                status = (int)ResponseStatus.success,
                                TResponse = result
                            };
                        }
                        else if (result == 3)
                        {
                            response = new TIP_RESULT()
                            {
                                message = "Reset password email could not be queued. Please contact support.",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                            SaveOtpProcessDiagnosticLog(commonService, "SendForgetPa returned 3; forget-password email was not queued.", "SendForgetPa_Email", vendorDetail.emailaddress, accessor.HttpContext);
                        }
                        else if (result == 4)
                        {
                            response = new TIP_RESULT()
                            {
                                message = "No account found for this email.",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                            SaveOtpProcessDiagnosticLog(commonService, "SendForgetPa returned 4; external user not found for forget-password email.", "SendForgetPa_Email", vendorDetail.emailaddress, accessor.HttpContext);
                        }
                        else
                        {
                            response = new TIP_RESULT()
                            {
                                message = "Email sent successfully, if email correct",
                                status = (int)ResponseStatus.success,
                                TResponse = new object()
                            };
                        }
                    }
                    else if (validate == 2)
                    {
                        response = new TIP_RESULT()
                        {
                            message = "OTP expired, request for new OTP",
                            status = (int)ResponseStatus.error,
                            TResponse = new object()
                        };
                        logger.LogCritical("Error - Location EndPoint - OTP Timeout From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);
                    }
                    else if (validate == 3)
                    {
                        response = new TIP_RESULT()
                        {
                            message = "OTP not valid",
                            status = (int)ResponseStatus.error,
                            TResponse = new object()
                        };
                        logger.LogCritical("Error - Location EndPoint - OTP Timeout From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path);
                    }
                    else
                    {
                        response = new TIP_RESULT()
                        {
                            message = "OTP Incorrect",
                            status = (int)ResponseStatus.error,
                            TResponse = new object()
                        };
                    }
                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - OTPSubmitForgetP From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(
                        GetErrorMessage(ex) + $" | OTPSubmitForgetP | Email={emailForOtp ?? vendorDetail?.emailaddress}",
                        "OTPSubmitForgetP",
                        "LocationEndPoints",
                        emailForOtp ?? "External",
                        AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));
                    response = new TIP_RESULT()
                    {
                        message = ex.Message + " - " + (ex.GetBaseException()?.Message ?? ""),
                        status = (int)ResponseStatus.error,
                        TResponse = new object()
                    };
                }
                return response;
            });

            app.MapPost("/api/CreateResponse", async ([FromBody] ResponseDTO answers) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    var rs = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ChallengeResponseStatus, ChallengeRspStatus.Drafted);

                    var DraftedStatusId = rs.Id;

                    ChallengeResponse challenge = new ChallengeResponse()
                    {
                        SourceId = answers.sourceId,
                        CreatedBy = Convert.ToInt64(answers.participant),
                        ChallengeRegistrationId = answers.challengeId,
                        UpdatedRole = "External",
                        CreatedOn = DateTime.Now,
                        TechnologyName = "  ",
                        StatusId = DraftedStatusId
                    };

                    var result = await challengeService.AddChallengeSolution(challenge);
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = CryptoExtensions.Encrypt(result.ToString())
                    };

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - CreateResponse From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "CreateResponse", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }
                return response;
            });

            app.MapPost("/api/AddUpdateVendorResponse", async ([FromBody] VendorResponseDetailsFromExternalDTO DTO) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    long responseId = (long)CryptoExtensions.Decrypt(DTO.cfcode).ToInt64();
                    var objR = await challengeService.ChallengeDetailsByResponseId(responseId);
                    if (objR != null && !objR.isResponseDateover.Value && (objR.statusName == "Drafted"||objR.statusName=="Sentback"))
                    {
                        string statusParam = DTO.status == "Drafted"
                            ? ChallengeRspStatus.Drafted
                            : DTO.status == "Sentback"
                                ? ChallengeRspStatus.Sentback
                                : ChallengeRspStatus.Submitted;

                        var statusMaster = await commonService.GetMasterDataByParentAndParam1(TypeCodes.ChallengeResponseStatus, statusParam);
                        long statusId = statusMaster.Id;

                        await challengeService.UpdateChallengeSolution(DTO.solutionDetails, responseId, DTO.vendorId, statusId);
                        await challengeService.AddOrUpdateVendorScreeningAnswers(DTO.screeningQuestions, responseId);
                        await challengeService.AddOrUpdateVendorTechDetailds(DTO.solutionTechDetails, responseId);
                        response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = ""
                        };
                    }
                    else
                    {
                        response = new TIP_RESULT()
                        {
                            message = "Submission date elapsed or already submitted!!!",
                            status = (int)ResponseStatus.error,
                            TResponse = ""
                        };
                    }
                }
                catch (Exception ex)
                {
                    response = new TIP_RESULT()
                    {
                        message = ex.Message,
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                    logger.LogCritical("Critical Error - Location EndPoint - AddUpdateVendorResponse From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "AddUpdateVendorResponse", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }
                return response;
            });

            app.MapPost("/api/AddUpdateVendorResponseFile", async ([FromBody] FilesListCls DTO) =>
            {
                var response = new TIP_RESULT();
                try
                {

                    long responseId = (long)CryptoExtensions.Decrypt(DTO.cfcode).ToInt64();

                    foreach (var fileinfo in DTO.files)
                    {
                        var result = fileUploadFromByte(fileinfo);

                        if (result != null && result.status != 0)
                        {
                            DocumentRepo obj = new DocumentRepo()
                            {
                                LimkType = "ChallengeResponse",
                                LinkId = responseId,
                                FilePath = result.filepath,
                                CreatedBy = DTO.vendorId.ToString(),
                                CreatedOn = DateTime.Now,
                                FileName = CryptoExtensions.Encrypt(fileinfo.filename),
                                FileType = result.fileExtension,
                                Description = fileinfo.isNDA ? "Non Disclosure Agreement(s)" : "Solution Document(s)",
                                //MimeType = result.mimeType,
                                IsActive = true,
                                IsNda = fileinfo.isNDA ? true : false,
                                IsExternalAccessible = true,
                            };

                            var Result = await commonService.AddDocument(obj);
                        }



                    }
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = ""
                    };

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - AddUpdateVendorResponseFile From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "AddUpdateVendorResponseFile", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));
                    response = new TIP_RESULT()
                    {
                        message = GetErrorMessage(ex),
                        status = (int)ResponseStatus.error,
                        TResponse = ""
                    };
                }
                return response;
            });

            app.MapPost("/api/BenchmarkResponseFile", async ([FromBody] FilesListCls DTO) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    long responseId = (long)DTO.cfcode.ToInt64();

                    foreach (var fileinfo in DTO.files)
                    {
                        var result = fileUploadFromByte(fileinfo);

                        if (result != null && result.status != 0)
                        {
                            DocumentRepo obj = new DocumentRepo()
                            {
                                LimkType = "ChallengeResponse",
                                LinkId = responseId,
                                FilePath = result.filepath,
                                CreatedBy = DTO.vendorId.ToString(),
                                CreatedOn = DateTime.Now,
                                FileName = CryptoExtensions.Encrypt(fileinfo.filename),
                                FileType = result.fileExtension,
                                Description = fileinfo.isNDA ? "Non Disclosure Agreement(s)" : "Solution Document(s)",
                                //MimeType = result.mimeType,
                                IsActive = true,
                                IsNda = fileinfo.isNDA ? true : false,
                            };

                            var Result = await commonService.AddDocument(obj);
                        }



                    }
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = ""
                    };

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - BenchmarkResponseFile From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "BenchmarkResponseFile", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }
                return response;
            });

            app.MapPost("/api/AddVendorQueries", async ([FromBody] FilesListCls DTO) =>
            {
                var response = new TIP_RESULT();
                try
                {

                    long responseId = (long)CryptoExtensions.Decrypt(DTO.cfcode).ToInt64();
                    var queryId = await challengeService.AddVendorQueries(DTO.query, responseId, (DTO.files.Count > 0 ? true : false));
                    foreach (var fileinfo in DTO.files)
                    {

                        var result = fileUploadFromByte(fileinfo);

                        if (result != null && result.status != 0)
                        {
                            DocumentRepo obj = new DocumentRepo()
                            {
                                LimkType = "VendorQueries",
                                LinkId = Convert.ToInt64(queryId),
                                FilePath = result.filepath,
                                CreatedBy = DTO.vendorId.ToString(),
                                CreatedOn = DateTime.Now,
                                FileName = CryptoExtensions.Encrypt(result.filename),
                                FileType = result.fileExtension,
                                Description = "Query Attachment",
                                //MimeType = result.mimeType,
                                IsActive = true,
                            };

                            var Result = await commonService.AddDocument(obj);
                        }



                    }
                    var tResponse = await challengeService.GetVendorQueryResponseForExternal(DTO.cfcode);
                    response = new TIP_RESULT()
                    {
                        message =ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = tResponse
                    };
                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - AddVendorQueries From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "AddVendorQueries", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }
                return response;
            });

            app.MapPost("/api/AddPDOQueriesResponse", async ([FromBody] FilesListCls DTO) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    long solutionId = (long)CryptoExtensions.Decrypt(DTO.cfcode).ToInt64();
                    var responseId = DTO.responseId;
                   
                        responseId = (await challengeService.AddPDOQueryResponse(DTO.query, Convert.ToInt64(DTO.queryId), DTO.files.Count > 0));
                    
                    foreach (var fileinfo in DTO.files)
                    {

                        var result = fileUploadFromByte(fileinfo);

                        if (result != null && result.status != 0)
                        {
                            DocumentRepo obj = new DocumentRepo()
                            {
                                LimkType = "PDOQueryResponse",
                                LinkId = Convert.ToInt64(responseId),
                                FilePath = result.filepath,
                                CreatedBy = DTO.vendorId.ToString(),
                                CreatedOn = DateTime.Now,
                                FileName = CryptoExtensions.Encrypt(result.filename),
                                FileType = result.fileExtension,
                                Description = "Vendor to PDO Query Response Attachment",
                                //MimeType = result.mimeType,
                                IsActive = true,
                            };

                            var Result = await commonService.AddDocument(obj);
                        }



                    }
                    var tResponse = await challengeService.GetPDOQueryResponseForInternal(solutionId);
                    response = new TIP_RESULT()
                    {
                        message =ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = tResponse
                    };
                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - AddPDOQueriesResponse From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "AddPDOQueriesResponse", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }

                return response;
            });

            app.MapGet("/api/GetLocalDetails/{cfcode}", async ([FromRoute] string cfcode) =>
            {
                var response = new TIP_RESULT();
                try
                {

                    var result = await challengeService.GetLocalDetails(cfcode);
                    response = new TIP_RESULT()
                    {
                        message =ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - GetLocalDetails From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "GetLocalDetails", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }

                return Results.Ok(response);
            });

            app.MapGet("/api/GetVendorResponseDetailsForExternal/{cfcode}", async ([FromRoute] string cfcode) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    var result = await challengeService.GetVendorResponseDetailsForExternal(cfcode);
                    
    
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - GetVendorResponseDetailsForExternal From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "GetVendorResponseDetailsForExternal", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }
                return response;
            });

            app.MapGet("/api/GetVendorResponseQueryDetailsForExternal/{cfcode}", async ([FromRoute] string cfcode) =>
            {
                var response = new TIP_RESULT();
                try
                {

                    long SolutionId = (long)CryptoExtensions.Decrypt(cfcode).ToInt64();
                    var result = await challengeService.GetPDOQueryResponseForInternal(SolutionId);
                    response = new TIP_RESULT()
                    {
                        message =ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - GetVendorResponseQueryDetailsForExternal From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "GetVendorResponseQueryDetailsForExternal", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }


                return response;
            });

            app.MapGet("/api/AllPublishedChallengesForExternal", async () =>
            {
                var response = new TIP_RESULT();
                try
                {
                    var result = await challengeService.AllPublishedChallengesForExternal();
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };


                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - AllPublishedChallengesForExternal From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "AllPublishedChallengesForExternal", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }
                return response;
            });

            app.MapPost("/api/GetContactUs", async ([FromBody] ExternalContactUs vendorDetail) =>
            {
                var response = new TIP_RESULT();
                try
                {

                    //Contact Us Auto Reply
                    await userSettingsService.AutoReplyContactUs(vendorDetail, EmailModules.TMHVR, "EX003");

                    //Send Contact Us Detail to configured MU numbers
                    await userSettingsService.AutoReplyContactUs(vendorDetail, EmailModules.TMHVR, "EX004");


                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = new object()
                    };

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - GetContactUs From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "GetContactUs", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }

                return response;
            });

            app.MapGet("/api/LatestPublishChallengesForExternal/{SourceId}/{participant}", async ([FromRoute] long SourceId, [FromRoute] long participant) =>
            {
                var response = new TIP_RESULT();
                try
                {

                    var result = await challengeService.LatestPublishChallengesForExternal(SourceId, participant);
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - LatestPublishChallengesForExternal From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "LatestPublishChallengesForExternal", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }


                return response;
            });

            app.MapGet("/api/DownloadSingleFileForExternal/{id}/{type}", async ([FromRoute] string id, [FromRoute] string type) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    long Id =Convert.ToInt64(CryptoExtensions.Decrypt(id));
                    if (type == "Challenge Details")
                    {
                        var obj = commonService.DocumentRepo(Id);
                        var filepath = obj.Result.path;
                        string res = ResolvePhysicalPath(filepath, () => ResolveUploadRootPath(configuration));
                        var fileName = CryptoExtensions.Decrypt(obj.Result.name);
                        if (fileName != null && System.IO.File.Exists(res))
                        {
                            var content = await System.IO.File.ReadAllBytesAsync(res);
                            new FileExtensionContentTypeProvider().TryGetContentType(fileName, out string contentType);
                            //var response = File(content, contentType, fileName);
                            var response1 = new FileContentResult(content, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(contentType));
                            response = new TIP_RESULT()
                            {
                                message = ResponseStatus.success.ToString(),
                                status = (int)ResponseStatus.success,
                                TResponse = response1
                            };
                        }
                        else
                        {
                            response = new TIP_RESULT()
                            {
                                message = ResponseStatus.success.ToString(),
                                status = (int)ResponseStatus.success,
                                TResponse = "File is not found."
                            };

                        }

                    }
                    else
                    {
                        var obj = commonService.DocumentRepoList(Id, type, false);

                        if (obj.Result.Count == 0)
                        {
                            response = new TIP_RESULT()
                            {
                                message = ResponseStatus.success.ToString(),
                                status = (int)ResponseStatus.success,
                                TResponse = "File is not found."
                            };


                        }
                        else
                        {
                            var filepath = obj.Result.FirstOrDefault().path;
                            string res = ResolvePhysicalPath(filepath, () => ResolveUploadRootPath(configuration));
                            var fileName = CryptoExtensions.Decrypt(obj.Result.FirstOrDefault().name);
                            if (fileName != null && System.IO.File.Exists(res))
                            {
                                var content = await System.IO.File.ReadAllBytesAsync(res);
                                new FileExtensionContentTypeProvider().TryGetContentType(fileName, out string contentType);
                                //var response = File(content, contentType, fileName);
                                var response1 = new FileContentResult(content, new Microsoft.Net.Http.Headers.MediaTypeHeaderValue(contentType));
                                response = new TIP_RESULT()
                                {
                                    message = ResponseStatus.success.ToString(),
                                    status = (int)ResponseStatus.success,
                                    TResponse = response1
                                };

                            }
                            else
                            {
                                response = new TIP_RESULT()
                                {
                                    message = ResponseStatus.success.ToString(),
                                    status = (int)ResponseStatus.success,
                                    TResponse = "File is not found."
                                };

                            }
                        }
                    }

                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - DownloadSingleFileForExternal From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "DownloadSingleFileForExternal", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }
                response.message = response.message;
                return response;

            });

            app.MapGet("/api/ParticipatedChallengesForExternal/{SourceId}/{participant}", async ([FromRoute] long SourceId, [FromRoute] long participant) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    var result = await challengeService.ParticipatedChallengesForExternal(SourceId, participant);
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - ParticipatedChallengesForExternal From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "ParticipatedChallengesForExternal", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }

                return response;
            });
            
            app.MapGet("/api/ValidateUserForCreatePassword/{userName}/{createpabit}", async ([FromRoute] string userName,  [FromRoute] string createpabit) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    var validate = await userSettingsService.ValidateVendorForPasswordCreation(userName, "", createpabit);
                    if (createpabit == "1")
                    {
                        if (validate == 1)
                        {
                            response = new TIP_RESULT()
                            {
                                message = ResponseStatus.success.ToString(),
                                status = (int)ResponseStatus.success,
                                TResponse = new object()
                            };
                        }
                        else if (validate == 2)
                        {
                            response = new TIP_RESULT()
                            {
                                message = "Not a valid user",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                        }
                        else if (validate == 3)
                        {
                            response = new TIP_RESULT()
                            {
                                message = "Not a valid data",
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                        }
                        else
                        {
                            response = new TIP_RESULT()
                            {
                                message = ResponseStatus.error.ToString(),
                                status = (int)ResponseStatus.error,
                                TResponse = new object()
                            };
                        }

                    }
                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - ValidateUserForCreatePassword From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "ValidateUserForCreatePassword", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));
                }



                return response;

            });

            app.MapGet("/api/ExternalCompanies/{sourceType}", async ([FromRoute] string sourceType) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    var result = await commonService.GetMasterDataByType(sourceType);
                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success,
                        TResponse = result
                    };
                }
                catch (Exception ex)
                {
                    logger.LogCritical("Critical Error - Location EndPoint - ExternalCompanies From External To Internal - Get Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + GetErrorMessage(ex));
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "ExternalCompanies", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }


                return Results.Ok(response);

            });

            app.MapPost("/api/UpdateUserLogin", async ([FromBody] ExternalUserDTO vendorDetail) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    var result = await userSettingsService.UpdateUserLogin(vendorDetail);
                    if (result == 1)
                    {
                        var user = await userSettingsService.GetExternalUser(vendorDetail.emailaddress);

                        user.pname = String.Empty;
                        response = new TIP_RESULT()
                        {
                            message = ResponseStatus.success.ToString(),
                            status = (int)ResponseStatus.success,
                            TResponse = user
                        };

                    }
                    else if (result == 2)
                    {
                        response = new TIP_RESULT()
                        {
                            message = "User does not exist. Please contact support",
                            status = (int)ResponseStatus.error,
                            TResponse = null
                        };
                        logger.LogCritical("Critical Error - Location EndPoint - UpdateUserLogin From External To Internal - Post Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - User not exist in application");


                    }
                    else if (result == 3)
                    {
                        response = new TIP_RESULT()
                        {
                            message = "Email/Phone already exist. Please use a differnt one.",
                            status = (int)ResponseStatus.error,
                            TResponse = null
                        };
                    }
                    else
                    {
                        response = new TIP_RESULT()
                        {
                            message = "Oops! something went wrong. Please contact support",
                            status = (int)ResponseStatus.error,
                            TResponse = result
                        };
                        logger.LogCritical("Critical Error - Location EndPoint - UpdateUserLogin From External To Internal - Post Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - Something went wrong in repository");
                    }


                }
                catch (Exception ex)
                {
                    logger.LogCritical(ex, "Critical Error - Location EndPoint - UpdateUserLogin From External To Internal - Post Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + ex.Message);
                    commonService.SaveApplicationErrorLog(GetErrorMessage(ex), "UpdateUserLogin", "LocationEndPoints", "External", AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext));

                }
                response.message = response.message;
                return response;
            });

            app.MapPost("/api/SaveExternalApplicationErrorLog", ([FromBody] ExternalErrorLogRequest request) =>
            {
                var response = new TIP_RESULT();
                try
                {
                    if (request == null)
                    {
                        response = new TIP_RESULT()
                        {
                            message = ResponseStatus.error.ToString(),
                            status = (int)ResponseStatus.error
                        };
                        return response;
                    }

                    Guid errorId = Guid.Empty;
                    if (!string.IsNullOrWhiteSpace(request.errorId))
                        Guid.TryParse(request.errorId, out errorId);

                    commonService.SaveApplicationErrorLog(
                        request.errorMessage ?? string.Empty,
                        TrimTo(request.action, 100),
                        TrimTo(request.controller, 100),
                        TrimTo(string.IsNullOrWhiteSpace(request.userName) ? "External" : request.userName, 20),
                        TrimTo(request.ipAddress, 50),
                        errorId);

                    response = new TIP_RESULT()
                    {
                        message = ResponseStatus.success.ToString(),
                        status = (int)ResponseStatus.success
                    };
                }
                catch (Exception ex)
                {
                    logger.LogCritical(ex, "Critical Error - Location EndPoint - SaveExternalApplicationErrorLog From External To Internal - Post Method " + AccountHelper.GetWinAuthIPForLogs(accessor.HttpContext) + "-" + " Internal Application - " + accessor.HttpContext.Connection.RemotePort + " - " + accessor.HttpContext.Request.Path + " - " + ex.Message);
                }

                return response;
            });
                     
            FileUploadResponse fileUpload(IFormFile file)
            {
                string uploadRoot = ResolveUploadRootPath(configuration);
                string fileExtension = Normalize.parse(System.IO.Path.GetExtension(file.FileName).TrimStart(new char[] { '.' }));
                string originalFileName = Normalize.parse(file.FileName.Substring(file.FileName.LastIndexOf("\\") + 1));
                string guidName = Normalize.parse("File-" + Guid.NewGuid().ToString() + DateTime.Today.Second.ToString() + "." + fileExtension);

                long fileSizeibMbs = file.Length / (1024 * 1024);
                if (fileSizeibMbs > 20)
                {
                    return new FileUploadResponse
                    {
                        filename = originalFileName,
                        filepath = "",
                        status = 0,
                        Message = "File size of " + originalFileName + " is too large. Maximum file size permitted is " + 20 + "Mb"
                    };
                }

                if (string.IsNullOrEmpty(uploadRoot))
                {
                    return new FileUploadResponse
                    {
                        filename = originalFileName,
                        filepath = "",
                        status = 0,
                        Message = "Upload path not found."
                    };
                }

                var FinalPath = Path.Combine(uploadRoot, guidName);
                if (!IsAllowedUploadPath(FinalPath, uploadRoot, guidName))
                {
                    return new FileUploadResponse
                    {
                        filename = originalFileName,
                        filepath = FinalPath,
                        status = 0,
                        Message = "Not a valid path or file."
                    };
                }

                if (System.IO.File.Exists(FinalPath))
                {
                    return new FileUploadResponse
                    {
                        filename = originalFileName,
                        filepath = FinalPath,
                        status = 0,
                        Message = "File exist with same name, rename and try again."
                    };
                }

                using (Stream fileStream = new FileStream(FinalPath, FileMode.CreateNew))
                {
                    file.CopyTo(fileStream);
                }

                if (!System.IO.File.Exists(FinalPath))
                {
                    return new FileUploadResponse
                    {
                        filename = originalFileName,
                        filepath = FinalPath,
                        status = 0,
                        Message = "Upload Failed!"
                    };
                }

                string MimeType = "";
                new FileExtensionContentTypeProvider().TryGetContentType(originalFileName, out MimeType);
                return new FileUploadResponse()
                {
                    filename = originalFileName,
                    filepath = CryptoExtensions.Encrypt(FinalPath),
                    fileExtension = fileExtension,
                    mimeType = file.ContentType,
                    status = 1,
                    Message = "File Uploaded Successfully",
                };
            }
            
            FileUploadResponse fileUploadFromByte(filesToUpload files)
            {
                string uploadRoot = ResolveUploadRootPath(configuration);
                string fileExtension = Normalize.parse(files.fileextention);
                string originalFileName = Normalize.parse(files.filename);
                string guidName = Normalize.parse("File-" + Guid.NewGuid().ToString() + DateTime.Today.Second.ToString() + "." + fileExtension);

                if (string.IsNullOrEmpty(uploadRoot))
                {
                    return new FileUploadResponse
                    {
                        filename = originalFileName,
                        filepath = "",
                        status = 0,
                        Message = "Upload path not found."
                    };
                }

                var FinalPath = Path.Combine(uploadRoot, guidName);
                if (!IsAllowedUploadPath(FinalPath, uploadRoot, guidName))
                {
                    return new FileUploadResponse
                    {
                        filename = originalFileName,
                        filepath = FinalPath,
                        status = 0,
                        Message = "Not a valid path or file."
                    };
                }

                if (System.IO.File.Exists(FinalPath))
                {
                    return new FileUploadResponse
                    {
                        filename = originalFileName,
                        filepath = FinalPath,
                        status = 0,
                        Message = "File exist with same name, rename and try again."
                    };
                }

                string base64 = files.filebase64 ?? string.Empty;
                int commaIdx = base64.IndexOf(',');
                if (base64.StartsWith("data:", StringComparison.OrdinalIgnoreCase) && commaIdx >= 0)
                    base64 = base64.Substring(commaIdx + 1);

                Byte[] bytes = Convert.FromBase64String(base64);
                File.WriteAllBytes(FinalPath, bytes);

                if (System.IO.File.Exists(FinalPath) && bytes.Length != 0)
                {
                    return new FileUploadResponse()
                    {
                        filename = guidName,
                        filepath = BuildStoredFilePath(FinalPath, guidName),
                        fileExtension = fileExtension,
                        status = 1,
                        Message = "File Uploaded Successfully",
                    };
                }

                return new FileUploadResponse
                {
                    filename = originalFileName,
                    filepath = FinalPath,
                    status = 0,
                    Message = "Upload Failed!"
                };
            }

        }

        private const int MaxEncryptedFilePathLength = 300;

        private static string BuildStoredFilePath(string finalPath, string guidName)
        {
            var encryptedFullPath = CryptoExtensions.Encrypt(finalPath);
            if (encryptedFullPath.Length <= MaxEncryptedFilePathLength)
                return encryptedFullPath;

            return CryptoExtensions.Encrypt(guidName);
        }

        private static string ResolvePhysicalPath(string encryptedStoredPath, Func<string> resolveUploadRoot)
        {
            if (string.IsNullOrWhiteSpace(encryptedStoredPath))
                return string.Empty;

            var decrypted = CryptoExtensions.Decrypt(encryptedStoredPath);
            if (string.IsNullOrWhiteSpace(decrypted))
                return string.Empty;

            if (Path.IsPathRooted(decrypted))
                return decrypted;

            var root = resolveUploadRoot();
            return string.IsNullOrWhiteSpace(root)
                ? decrypted
                : Path.Combine(root, decrypted);
        }

        private static string ResolveUploadRootPath(IConfiguration configuration)
        {
            string configuredNas = string.Empty;
            try
            {
                if (string.Equals(configuration["ServerMode"], "Prod", StringComparison.OrdinalIgnoreCase))
                    configuredNas = CryptoExtensions.Decrypt(configuration["EncryptedNASPathS"] ?? string.Empty);
                else
                    configuredNas = CryptoExtensions.Decrypt(configuration["EncryptedNASPathD"] ?? string.Empty);
            }
            catch
            {
                configuredNas = string.Empty;
            }

            configuredNas = NormalizeUncPath(configuredNas);

            bool useLocal = string.Equals(configuration["UseLocalFileStorage"], "true", StringComparison.OrdinalIgnoreCase);
            string localPath = configuration["LocalUploadPath"] ?? string.Empty;

            if (!useLocal && !string.IsNullOrWhiteSpace(configuredNas) && Directory.Exists(configuredNas))
                return configuredNas.EndsWith("\\") ? configuredNas : configuredNas + "\\";

            if (string.IsNullOrWhiteSpace(localPath))
                localPath = Path.Combine(AppContext.BaseDirectory, "App_Data", "Uploads");

            Directory.CreateDirectory(localPath);
            return localPath.EndsWith("\\") ? localPath : localPath + "\\";
        }

        private static string NormalizeUncPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return string.Empty;

            if (path.StartsWith(@"\\", StringComparison.Ordinal))
            {
                var trimmed = path.TrimStart('\\');
                trimmed = trimmed.Replace(@"\\", @"\");
                return @"\\" + trimmed;
            }

            return path;
        }

        private static bool IsAllowedUploadPath(string finalPath, string rootPath, string guidName)
        {
            if (string.IsNullOrWhiteSpace(finalPath) || string.IsNullOrWhiteSpace(rootPath))
                return false;

            try
            {
                if (guidName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
                    return false;

                if (!Path.IsPathRooted(finalPath) || Path.GetFileName(finalPath) != guidName)
                    return false;

                string fullFile = Path.GetFullPath(finalPath);
                string fullRoot = Path.GetFullPath(rootPath);
                if (!fullRoot.EndsWith(Path.DirectorySeparatorChar.ToString()) &&
                    !fullRoot.EndsWith(Path.AltDirectorySeparatorChar.ToString()))
                    fullRoot += Path.DirectorySeparatorChar;

                return fullFile.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        public static async Task<int> GenerateRandomNo()
        {
            int _min = 100000;
            int _max = 999999;
            Random _rdm = new Random();
            return _rdm.Next(_min, _max);
        }

        public class VendorResponseDetailsFromExternalDTO
        {
            public string cfcode { get; set; }
            public string status { get; set; }
            public long vendorId { get; set; }
            public List<ScreeningQuestionsDTO> screeningQuestions { get; set; }
            public VendorResponseDTO solutionDetails { get; set; }
            public List<SolutionTechDetailsDTO> solutionTechDetails { get; set; }

        }

        private static string TrimTo(string value, int max)
        {
            if (string.IsNullOrEmpty(value) || value.Length <= max)
                return value ?? string.Empty;
            return value.Substring(0, max);
        }

        private static void SaveOtpProcessErrorLog(ICommonService commonService, Exception ex, string step, string emailAddress, HttpContext httpContext)
        {
            try
            {
                var context = $" | OTP process step: {step} | Email: {emailAddress ?? "n/a"}";
                commonService.SaveApplicationErrorLog(
                    GetErrorMessage(ex) + context,
                    step,
                    "LocationEndPoints",
                    "External",
                    AccountHelper.GetWinAuthIPForLogs(httpContext));
            }
            catch (Exception)
            {
                // Do not fail the OTP flow if error logging fails.
            }
        }

        private static void SaveOtpProcessDiagnosticLog(ICommonService commonService, string message, string step, string emailAddress, HttpContext httpContext)
        {
            try
            {
                var context = $" | OTP process step: {step} | Email: {emailAddress ?? "n/a"}";
                commonService.SaveApplicationErrorLog(
                    message + context,
                    step,
                    "LocationEndPoints",
                    "External",
                    AccountHelper.GetWinAuthIPForLogs(httpContext));
            }
            catch (Exception)
            {
                // Do not fail the OTP flow if error logging fails.
            }
        }

        private static void SaveOtpProcessSuccessLog(ICommonService commonService, string message, string step, string emailAddress, HttpContext httpContext)
        {
            try
            {
                var context = $" | OTP/Forgot Password email delivery | Step: {step} | Email: {emailAddress ?? "n/a"}";
                commonService.SaveApplicationErrorLog(
                    message + context,
                    step + "_Success",
                    "LocationEndPoints",
                    "External",
                    AccountHelper.GetWinAuthIPForLogs(httpContext));
            }
            catch (Exception)
            {
                // Do not fail the OTP flow if success logging fails.
            }
        }

        private static string GetErrorMessage(Exception ex)
        {
            try
            {
                string errorMessage = "ExceptionStart ";

                if (ex == null)
                {
                    errorMessage = "No exception provided.";
                }
                else
                {
                    errorMessage += $"Exception Type: {ex.GetType().FullName}\n";
                    errorMessage += $"Message: {ex.Message}\n";
                    errorMessage += $"Source: {ex.Source}\n";
                    errorMessage += $"Stack Trace:\n{ex.StackTrace}\n";

                    if (ex.InnerException != null)
                    {
                        errorMessage += "\nInner Exception:\n";
                        errorMessage += GetDetailedErrorMessage(ex.InnerException);
                    }
                }

                return Regex.Replace(errorMessage, @"\s+", " ") + " ExceptionEnd";
            }
            catch (Exception)
            {
                return "ExceptionStart Unable to format exception details. ExceptionEnd";
            }
        }
        private static string GetDetailedErrorMessage(Exception ex, HashSet<Exception> processedExceptions = null)
        {
            try
            {
                if (ex == null)
                {
                    return "No exception provided.";
                }

                if (processedExceptions == null)
                {
                    processedExceptions = new HashSet<Exception>();
                }

                if (processedExceptions.Contains(ex))
                {
                    return "Recursive exception encountered.";
                }

                processedExceptions.Add(ex);

                string errorMessage = $"Exception Type: {ex.GetType().FullName}\n";
                errorMessage += $"Message: {ex.Message}\n";
                errorMessage += $"Source: {ex.Source}\n";
                errorMessage += $"Stack Trace:\n{ex.StackTrace}\n";

                if (ex.InnerException != null)
                {
                    errorMessage += "\nInner Exception:\n";
                    errorMessage += GetDetailedErrorMessage(ex.InnerException, processedExceptions);
                }

                return errorMessage;
            }
            catch (Exception)
            {
                return "Unable to format detailed exception message.";
            }
        }

        public static void GenerateAndThrowRandomException()
        {
            Random random = new Random();
            int randomNumber = random.Next(1, 11); // Generate random numbers from 1 to 10

            switch (randomNumber)
            {
                case 1:
                    throw new InvalidOperationException("Randomly raised InvalidOperationException");
                case 2:
                    throw new ArgumentException("Randomly raised ArgumentException");
                case 3:
                    throw new NotImplementedException("Randomly raised NotImplementedException");
                case 4:
                    throw new DivideByZeroException("Randomly raised DivideByZeroException");
                case 5:
                    throw new FileNotFoundException("Randomly raised FileNotFoundException");
                case 6:
                    throw new FormatException("Randomly raised FormatException");
                case 7:
                    throw new IndexOutOfRangeException("Randomly raised IndexOutOfRangeException");
                case 8:
                    throw new TimeoutException("Randomly raised TimeoutException");
                case 9:
                    throw new ApplicationException("Randomly raised ApplicationException");
                case 10:
                    throw new NotSupportedException("Randomly raised NotSupportedException");
                default:
                    throw new Exception("Randomly raised generic Exception");
            }
        }

    }
}