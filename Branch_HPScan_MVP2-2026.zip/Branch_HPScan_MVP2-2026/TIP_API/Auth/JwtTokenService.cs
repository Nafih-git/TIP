using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using TIP_CORE.EntitiesDTO;

namespace TIP_API.Auth
{
    public interface IJwtTokenService
    {
        JwtTokenResult CreateToken(string windowsAccountName, EmployeeDTO employee, IEnumerable<string>? roles = null);
    }

    public class JwtTokenResult
    {
        public string AccessToken { get; set; } = string.Empty;
        public DateTime ExpiresAtUtc { get; set; }
        public int ExpiresInSeconds { get; set; }
    }

    public class JwtTokenService : IJwtTokenService
    {
        private readonly JwtSettings _settings;

        public JwtTokenService(IOptions<JwtSettings> settings)
        {
            _settings = settings.Value;
        }

        public JwtTokenResult CreateToken(string windowsAccountName, EmployeeDTO employee, IEnumerable<string>? roles = null)
        {
            if (string.IsNullOrWhiteSpace(_settings.Key))
                throw new InvalidOperationException("Jwt:Key is not configured.");

            var expires = DateTime.UtcNow.AddMinutes(_settings.ExpireMinutes <= 0 ? 480 : _settings.ExpireMinutes);
            var claims = new List<Claim>
            {
                // Keep Windows-style name so AccountHelper / GetIdentityOfLoggedInUser continue to work.
                new Claim(ClaimTypes.Name, windowsAccountName),
                new Claim(JwtRegisteredClaimNames.Sub, employee.COMPANY_NUMBER ?? windowsAccountName),
                new Claim(JwtRegisteredClaimNames.UniqueName, windowsAccountName),
                new Claim("company_number", employee.COMPANY_NUMBER ?? string.Empty),
                new Claim("display_name", employee.DISPLAY_NAME ?? employee.EMPLOYEE_NAME ?? string.Empty),
                new Claim("active_role_id", (employee.ACTIVE_R_ID ?? 0).ToString())
            };

            if (roles != null)
            {
                foreach (var role in roles.Where(r => !string.IsNullOrWhiteSpace(r)).Distinct(StringComparer.OrdinalIgnoreCase))
                {
                    claims.Add(new Claim(ClaimTypes.Role, role));
                }
            }

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_settings.Key));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                issuer: _settings.Issuer,
                audience: _settings.Audience,
                claims: claims,
                notBefore: DateTime.UtcNow,
                expires: expires,
                signingCredentials: credentials);

            return new JwtTokenResult
            {
                AccessToken = new JwtSecurityTokenHandler().WriteToken(token),
                ExpiresAtUtc = expires,
                ExpiresInSeconds = (int)TimeSpan.FromMinutes(_settings.ExpireMinutes <= 0 ? 480 : _settings.ExpireMinutes).TotalSeconds
            };
        }
    }
}
