﻿namespace TIP_API.DTO
{
    public class GetElementRequest
    {
        public decimal ElementId { get; set; }
        public decimal ElementTypeId { get; set; }
        public decimal GroupId { get; set; }
        public decimal Status { get; set; }
    }
}
