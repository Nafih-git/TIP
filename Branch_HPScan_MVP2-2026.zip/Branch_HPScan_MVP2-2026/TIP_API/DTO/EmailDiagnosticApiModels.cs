namespace TIP_API.DTO
{
    public class EmailDiagnosticRequest
    {
        public string To { get; set; } = string.Empty;
        public string? Cc { get; set; }
        public string Subject { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;

        /// <summary>config, exchange, queue, worker, or all (comma-separated). Default: config,exchange,queue</summary>
        public string? Steps { get; set; }

        public bool RunWorkerAfterQueue { get; set; }

        public long? ProcessEmailRepoId { get; set; }
    }
}
