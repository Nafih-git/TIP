﻿namespace TIP_API.DTO
{
    public class GetDirectorateRequest
    {
        public decimal DirectorateId { get; set; }
        public decimal Status { get; set; }
    }
}
