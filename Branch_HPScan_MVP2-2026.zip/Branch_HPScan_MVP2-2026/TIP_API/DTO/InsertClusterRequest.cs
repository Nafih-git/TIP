﻿namespace TIP_API.DTO
{
    public class InsertClusterRequest
    {
        public decimal DirectorateId { get; set; }
        public decimal ClusterId { get; set; }
        public string ClusterName { get; set; }
        public decimal Status { get; set; }
        public decimal ParentClusterId { get; set; }
    }
}
