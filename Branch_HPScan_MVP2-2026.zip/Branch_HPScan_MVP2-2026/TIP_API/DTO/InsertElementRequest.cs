﻿namespace TIP_API.DTO
{
    public class InsertElementRequest
    {
        public decimal ElementId { get; set; }
        public string ElementName { get; set; }
        public decimal ElementTypeId { get; set; }
        public decimal GroupId { get; set; }
        public string Color { get; set; }
        public decimal IsEditable { get; set; }
        public decimal IsComment { get; set; }
        public decimal Status { get; set; }
    }
}
