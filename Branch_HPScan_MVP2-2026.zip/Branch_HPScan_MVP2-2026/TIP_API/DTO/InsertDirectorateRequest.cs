﻿namespace TIP_API.DTO
{
    public class InsertDirectorateRequest
    {
        public decimal DirectorateId { get; set; }
        public string DirectorateName { get; set; }
        public decimal CorporateId { get; set; }
        public decimal Status { get; set; }
    }
}
