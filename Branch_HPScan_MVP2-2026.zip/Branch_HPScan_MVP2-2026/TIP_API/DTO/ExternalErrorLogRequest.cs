namespace TIP_API.DTO
{
    public class ExternalErrorLogRequest
    {
        public string? errorMessage { get; set; }
        public string? action { get; set; }
        public string? controller { get; set; }
        public string? userName { get; set; }
        public string? ipAddress { get; set; }
        public string? errorId { get; set; }
    }
}
