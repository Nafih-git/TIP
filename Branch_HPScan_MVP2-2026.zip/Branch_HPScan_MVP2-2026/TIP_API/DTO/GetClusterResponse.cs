﻿namespace TIP_API.DTO
{
    public class GetClusterResponse
    {
        public decimal DirectorateId { get; set; }
        public decimal ClusterId { get; set; }
        public string DirectorateName { get; set; }
        public string ClusterName { get; set; }
        public decimal Status { get; set; }
        public decimal ParentClusterId { get; set; }
        public string StatusName { get;  set; }
    }
}
