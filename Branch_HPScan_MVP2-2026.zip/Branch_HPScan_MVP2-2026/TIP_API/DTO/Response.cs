﻿namespace TIP_API.DTO
{
    public class Response<T>
    {
        public string message { get; set; }
        public int status { get; set; }
        public T? TResponse { get; set; }
    }
    public enum ResponseStatus
    {
        error = 0, success = 1, info = 3, warning = 4, errorinfo = 5
    }

    public class TIP_RESULT
    {
        public string message { get; set; }
        public int status { get; set; }
        public object TResponse { get; set; }
        
    }

}
