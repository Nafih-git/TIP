﻿namespace TIP_API.DTO
{
    public class GetDirectorateResponse
    {
        public decimal DirectorateId { get; set; }
        public string DirectorateName { get; set; }
        public decimal CorporateId { get; set; }
        public decimal ClusterCount { get; set; }
        public decimal SubClusterCount { get; set; }
        public decimal Status { get; set; }
        public string StatusName { get; set; }
    }
}
