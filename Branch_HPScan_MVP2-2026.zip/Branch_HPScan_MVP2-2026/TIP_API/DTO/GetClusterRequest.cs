﻿namespace TIP_API.DTO
{
    public class GetClusterRequest
    {
        public decimal DirectorateId { get; set; }
        public decimal ClusterId { get; set; }
        public decimal Status { get; set; }
    }
}
