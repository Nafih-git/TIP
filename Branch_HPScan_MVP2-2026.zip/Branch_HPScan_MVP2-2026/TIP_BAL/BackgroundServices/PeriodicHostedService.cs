﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using TIP_BusinessLogic.Interface;
using TIP_Common;

namespace TIP_BAL.BackgroundServices
{
    public class PeriodicHostedService : BackgroundService
    {
        private readonly TimeSpan _period = TimeSpan.FromMinutes(1);
        private readonly ILogger<PeriodicHostedService> _logger;
        private readonly IServiceScopeFactory _factory;
        private int _executionCount = 0;
        public bool IsEnabled { get; set; } = true;

        public PeriodicHostedService(
            ILogger<PeriodicHostedService> logger,
            IServiceScopeFactory factory)
        {
            _logger = logger;
            _factory = factory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            using PeriodicTimer timer = new PeriodicTimer(_period);
            while (
                !stoppingToken.IsCancellationRequested &&
                await timer.WaitForNextTickAsync(stoppingToken))
            {
                if (!IsEnabled)
                {
                    _logger.LogInformation("Skipped PeriodicHostedService");
                    continue;
                }

                try
                {
                    await using AsyncServiceScope asyncScope = _factory.CreateAsyncScope();
                    EmailService emailService = asyncScope.ServiceProvider.GetRequiredService<EmailService>();
                    try
                    {
                        await emailService.ExecuteAsync();
                    }
                    catch (Exception emailEx)
                    {
                        LogBackgroundError(asyncScope, emailEx, "PeriodicHostedService_EmailService");
                        _logger.LogInformation(
                            $"Failed to execute EmailService from PeriodicHostedService: {emailEx.Message}");
                    }

                    ReminderService reminderService = asyncScope.ServiceProvider.GetRequiredService<ReminderService>();
                    try
                    {
                        await reminderService.ExecuteAsync();
                    }
                    catch (Exception reminderEx)
                    {
                        LogBackgroundError(asyncScope, reminderEx, "PeriodicHostedService_ReminderService");
                        _logger.LogInformation(
                            $"Failed to execute ReminderService from PeriodicHostedService: {reminderEx.Message}");
                    }

                    _executionCount++;
                    _logger.LogInformation($"Executed PeriodicHostedService - Count: {_executionCount}");
                }
                catch (Exception ex)
                {
                    LogBackgroundError(ex, "PeriodicHostedService");
                    _logger.LogInformation(
                        $"Failed to execute PeriodicHostedService with exception message {ex.Message}. Good luck next round!");
                }
            }
        }

        private static void LogBackgroundError(AsyncServiceScope scope, Exception ex, string action)
        {
            try
            {
                var commonService = scope.ServiceProvider.GetRequiredService<ICommonService>();
                commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex),
                    action,
                    "PeriodicHostedService",
                    "System",
                    string.Empty);
            }
            catch (Exception)
            {
                // Never stop the background worker because error logging failed.
            }
        }

        private void LogBackgroundError(Exception ex, string action)
        {
            try
            {
                using var scope = _factory.CreateScope();
                var commonService = scope.ServiceProvider.GetRequiredService<ICommonService>();
                commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex),
                    action,
                    "PeriodicHostedService",
                    "System",
                    string.Empty);
            }
            catch (Exception)
            {
                // Never stop the background worker because error logging failed.
            }
        }
    }
}
