﻿using Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using TIP_BusinessLogic.Interface;
using TIP_Common;
using static TIP_Common.Enum.Enum;
using Task = System.Threading.Tasks.Task;

namespace TIP_BAL.BackgroundServices
{
    public class ReminderService
    {
        private readonly ICtrService _ctrService;
        private readonly IPIRService _pirService;
        private readonly IChallengeService _challengeService;
        private readonly IExecutionService _executionService;
		private readonly IDepVotService _depVotService;
		private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<EmailService> _logger;
        private readonly IConfiguration _configuration;

        public ReminderService(ILogger<EmailService> logger, IUnitOfWork unitOfWork, ICtrService ctrService,IPIRService pirService, IChallengeService challengeService, IExecutionService executionService, IDepVotService depVotService, IConfiguration configuration)
        {
            _logger = logger;
            this._unitOfWork = unitOfWork;
            _configuration = configuration;
            this._ctrService = ctrService;
            this._pirService = pirService;
            _challengeService = challengeService;
            _executionService = executionService;
            _depVotService = depVotService;
        }

        public async Task ExecuteAsync()
        {
            try
            {
                var configurationDTO = await _unitOfWork.Configuration.GetConfigurationByType("email");
                string MailFrom = CryptoExtensions.Decrypt(configurationDTO.FirstOrDefault(x => x.key == "Mail_From").value).ToString();
                string MailPass = CryptoExtensions.Decrypt(configurationDTO.FirstOrDefault(x => x.key == "Mail_Password").value).ToString();
                string MailAcc = CryptoExtensions.Decrypt(configurationDTO.FirstOrDefault(x => x.key == "Mail_Account").value).ToString();
                ExchangeService exchange = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                exchange.Credentials = new WebCredentials(MailAcc, MailPass, configurationDTO.FirstOrDefault(x => x.key == "Mail_Group").value);
                exchange.TraceEnabled = true;
                ExchangeServiceSetup.SetEndpoint(exchange, _configuration, MailFrom);
                await _ctrService.SendCTRReminderEmails(EmailModules.CTR_FRONT_END_LOADING, "CTR004");
                await _ctrService.SendCTRReminderEmails(EmailModules.CTR_FRONT_END_LOADING, "CTR006");
                await _ctrService.SendCTRReminderEmails(EmailModules.CTR_FRONT_END_LOADING, "CTR010");
                await _pirService.SendReminderEmails(EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR004");
                await _pirService.SendReminderEmails(EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR006");
                await _pirService.SendReminderEmails(EmailModules.PIR_MATURATION_CONTROL_TOWER, "PIR010");
                await _challengeService.SendReminderEmails(EmailModules.TMHPC, "TMH006");
                await _challengeService.SendReminderEmails(EmailModules.BTICHL, "BTI0011");
                await _challengeService.SendReminderEmails(EmailModules.BTICHL, "BTI0012");
                await _challengeService.SendReminderEmails(EmailModules.BTICHL, "BTIR04");
                await _challengeService.SendReminderEmails(EmailModules.BTICHL, "BTIR05");
                await _challengeService.SendReminderEmails(EmailModules.BTICHL, "BTIR06");
                await _executionService.SendReminderEmails(EmailModules.EXEC, "EXEC016");
                await _depVotService.SendReminderEmails(EmailModules.DEP, "DEV007");
				_logger.LogInformation("Email Service did something.");

            }
            catch (Exception ex)
            {
                _logger.LogInformation("Exception on email service : " + ex.Message);
            }

        }
    }
}
