﻿using Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using TIP_BAL.Interface;
using TIP_BusinessLogic.Interface;
using TIP_Common;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using Task = System.Threading.Tasks.Task;

namespace TIP_BAL.BackgroundServices
{
    public class EmailService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<EmailService> _logger;
        private readonly ICommonService _commonService;
        private readonly IConfiguration _configuration;
        private const ExchangeVersion exchangeVersion = ExchangeVersion.Exchange2013_SP1;
        private ExchangeService? _exchange;

        public EmailService(ILogger<EmailService> logger, IUnitOfWork unitOfWork, ICommonService commonService, IConfiguration configuration)
        {
            _logger = logger;
            _unitOfWork = unitOfWork;
            _commonService = commonService;
            _configuration = configuration;
        }

        /// <summary>
        /// Email Addresses. Multiple email addresses should be delimited by ;
        /// </summary>
        public string ToAddresses { get; set; }

        /// <summary>
        /// Email Addresses. Multiple email addresses should be delimited by ;
        /// </summary>
        public string? CcAddresses { get; set; }

        /// <summary>
        /// Email Addresses. Multiple email addresses should be delimited by ;
        /// </summary>
        public string? BccAddresses { get; set; }

        public string? AttachmentFileName { get; set; }

        public List<string> To { get; set; }

        public List<string>? Cc { get; set; }

        public List<string>? Bcc { get; set; }

        public List<string>? AttachmentFiles { get; set; }

        public string Subject { get; set; }

        public BodyType MessageBodyType { get; set; } = BodyType.Text;

        public string Message { get; set; }

        /// <summary>
        /// Attachment payload from EMAIL_REPO (name + content); not used when <see cref="AttachmentFiles"/> is set.
        /// </summary>
        public string? AttachmentContent { get; set; }

        public string? AttachmentContentName { get; set; }

        public bool SendAndSaveCopy { get; set; }

        public async Task ExecuteAsync()
        {
            try
            {
                List<ConfigurationDTO> configurationDTO;
                string MailFrom;
                string MailPass;
                string MailAcc;
                string MailDomain;
                try
                {
                    configurationDTO = await _unitOfWork.Configuration.GetConfigurationByType("email");
                    MailFrom = CryptoExtensions.Decrypt(configurationDTO.FirstOrDefault(x => x.key == "Mail_From").value).ToString();
                    MailPass = CryptoExtensions.Decrypt(configurationDTO.FirstOrDefault(x => x.key == "Mail_Password").value).ToString();
                    MailAcc = CryptoExtensions.Decrypt(configurationDTO.FirstOrDefault(x => x.key == "Mail_Account").value).ToString();
                    MailDomain = ResolvePlainOrEncryptedConfig(configurationDTO.FirstOrDefault(x => x.key == "Mail_Group")?.value, "Mail_Group");
                }
                catch (Exception ex)
                {
                    LogEmailError(ex, "EmailService_Configuration", "EmailService", "System");
                    _logger.LogInformation("Exception on email service (configuration): " + ex.Message);
                    return;
                }

                ExchangeService exchange;
                try
                {
                    exchange = new ExchangeService(exchangeVersion);
                    exchange.Credentials = new WebCredentials(MailAcc, MailPass, MailDomain);
                    exchange.TraceEnabled = true;
                    ExchangeServiceSetup.SetEndpoint(exchange, _configuration, MailFrom);
                    _exchange = exchange;
                }
                catch (Exception ex)
                {
                    LogEmailError(ex, "EmailService_Exchange", "EmailService", "System",
                        $" | MailFrom={MailFrom} | Domain={MailDomain}");
                    _logger.LogInformation("Exception on email service (Exchange): " + ex.Message);
                    return;
                }

                IEnumerable<EmailRepo> emailRepos;
                try
                {
                    emailRepos = await _unitOfWork.EmailRepo.GetAllAsync(x => x.EmailedYn.Equals("N") || x.EmailedYn.Equals("E"));
                    emailRepos = emailRepos.Take(100);
                }
                catch (Exception ex)
                {
                    LogEmailError(ex, "EmailService_LoadQueue", "EmailService", "System");
                    _logger.LogInformation("Exception on email service (load queue): " + ex.Message);
                    return;
                }

                foreach (var email in emailRepos)
                {
                    email.EmailedYn = "I";
                    email.EmailedDate = DateTime.Now;
                }
                try
                {
                    if (emailRepos?.Count() > 0)
                    {
                        _unitOfWork.EmailRepo.UpdateRange(emailRepos);
                        await _unitOfWork.SaveAsync();
                    }
                }
                catch (Exception ex)
                {
                    LogEmailError(ex, "EmailService_MarkInProgress", "EmailService", "System");
                    _logger.LogInformation("Exception on email service (mark in-progress): " + ex.Message);
                }

                bool isEmailEnabled = configurationDTO.FirstOrDefault(x => x.key == "IS_Email_Enable")?.value.ToLower() == "true";

                foreach (var email in emailRepos)
                {
                    try
                    {
                        if (!isEmailEnabled)
                        {
                            email.EmailedYn = "N";
                            email.EmailedDate = null;
                            _unitOfWork.EmailRepo.Update(email);
                            await _unitOfWork.SaveAsync();
                            _commonService.SaveApplicationErrorLog(
                                $"Email sending skipped because IS_Email_Enable is not true. | To={email.ToRecipients} | EmailRepoId={email.Id}",
                                "EmailService_Disabled",
                                "EmailService",
                                "System",
                                string.Empty);
                            continue;
                        }

                        string imageData = TryGetBase64ImageData("EmailHeader.jpg");
                        string headerImageRow = string.IsNullOrEmpty(imageData)
                            ? string.Empty
                            : $@"<tr>
                                                    <td>
                                                        <img src=""data:image/jpeg;base64,{imageData}"" alt=""Header Image"" style=""width: 100%; height: auto; display: block;"">
                                                    </td>
                                                </tr>";

                        string FullEmail = $@"
                                        <!DOCTYPE html>
                                        <html lang=""en"">
                                        <head>
                                            <meta charset=""UTF-8"">
                                            <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"">
                                            <title>Email Template</title>
                                        </head>
                                        <body style=""margin: 0; padding: 0; font-family: 'Arial', sans-serif; background-color: #ffffff;"">
                                            <table cellspacing=""0"" cellpadding=""0"" border=""0"" align=""center"" width=""600"" style=""border: 1px solid #000000;border-collapse: collapse; max-width: 600px;"">
                                                {headerImageRow}
                                                <tr>
                                                    <td style=""background-color: #4CAF50; color: #ffffff; text-align: center; padding: 5px;"">
                                                        <h1 style=""margin: 0;"">Technology Innovation Portal</h1>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style=""padding: 20px; background-color: #ffffff;"">
                                                       {email.MailBody}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style=""border-top: 2px solid #4CAF50;""></td>
                                                </tr>
                                                <tr>
                                                    <td style=""padding: 10px; color: #999999;"">
                                                        <p><strong>Note:</strong> This is a system-generated notification. Please do not directly reply to this email as the mailbox is not monitored.</p>
                                                        <p><strong>Note to CC Recipients:</strong> This Email contains an actionable link intented solely for the primary recipient.Please be advised that the link may not be applicable to those in CC, and no action is required from your end.Thank you for your understanding.</p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </body>
                                        </html>
                                        ";

                        ToAddresses = string.Empty;
                        CcAddresses = null;
                        BccAddresses = null;
                        AttachmentFileName = null;
                        AttachmentFiles = null;
                        AttachmentContent = email.Attachment;
                        AttachmentContentName = email.AttachmentName;
                        To = (email.ToRecipients ?? string.Empty).Split(',')
                            .Where(x => !string.IsNullOrWhiteSpace(x))
                            .Select(x => x.Trim())
                            .ToList();
                        Cc = email.CcRecipients != null
                            ? email.CcRecipients.Split(',')
                                .Where(x => !string.IsNullOrWhiteSpace(x))
                                .Select(x => x.Trim())
                                .ToList()
                            : null;
                        Bcc = null;
                        Subject = email.MailSubject;
                        MessageBodyType = BodyType.HTML;
                        Message = FullEmail;
                        SendAndSaveCopy = true;

                        try
                        {
                            SendEmail(exchange);
                        }
                        catch (Exception sendEx)
                        {
                            LogEmailError(sendEx, "EmailService_SendAndSaveCopy", "EmailService", "System",
                                $" | To={email.ToRecipients} | EmailRepoId={email.Id} | Subject={email.MailSubject}");
                            throw;
                        }

                        email.EmailedYn = "Y";
                        email.EmailedDate = DateTime.Now;
                        email.Error = null;
                        _unitOfWork.EmailRepo.Update(email);
                        await _unitOfWork.SaveAsync();
                        await LogLoginOtpOrForgotPasswordDeliveryAsync(email, succeeded: true, deliveryException: null);
                        _logger.LogInformation("Email Service did something.");
                    }
                    catch (Exception ex)
                    {
                        email.EmailedYn = "E";
                        email.Error = ex.Message;
                        email.TryCount = email.TryCount == null ? 1 : email.TryCount + 1;
                        try
                        {
                            _unitOfWork.EmailRepo.Update(email);
                            await _unitOfWork.SaveAsync();
                        }
                        catch (Exception persistEx)
                        {
                            LogEmailError(persistEx, "EmailService_MarkFailed", "EmailService", "System",
                                $" | To={email.ToRecipients} | EmailRepoId={email.Id} | OriginalError={ex.Message}");
                        }
                        await LogLoginOtpOrForgotPasswordDeliveryAsync(email, succeeded: false, deliveryException: ex);
                        LogEmailError(ex, "EmailService_ProcessEmail", "EmailService", "System",
                            $" | To={email.ToRecipients} | EmailRepoId={email.Id} | Subject={email.MailSubject} | TemplateId={email.TemplateId} | ModuleId={email.ModuleId}");
                    }
                }
            }
            catch (Exception ex)
            {
                LogEmailError(ex, "EmailService", "EmailService", "System");
                _logger.LogInformation("Exception on email service : " + ex.Message);
            }
            finally
            {
                _exchange = null;
            }
        }

        public void SendEmail(ExchangeService exchange)
        {
            try
            {
                EmailMessage message = new(exchange);

                if (SendAndSaveCopy)
                {
                    message.Subject = Subject;
                    message.Body = new MessageBody(Message);

                    foreach (var toEmail in To ?? new List<string>())
                    {
                        if (!string.IsNullOrWhiteSpace(toEmail))
                            message.ToRecipients.Add(toEmail.Trim());
                    }

                    if (message.ToRecipients.Count == 0)
                        throw new NullReferenceException("To Email Address not specified");

                    if (Cc != null)
                    {
                        foreach (var ccEmail in Cc)
                        {
                            if (!string.IsNullOrWhiteSpace(ccEmail))
                                message.CcRecipients.Add(ccEmail.Trim());
                        }
                    }

                    if (AttachmentContent != null)
                    {
                        message.Attachments.AddFileAttachment(AttachmentContentName, AttachmentContent);
                    }

                    message.SendAndSaveCopy();
                    return;
                }

                To = !string.IsNullOrEmpty(ToAddresses) ? ToAddresses.Split(';').ToList() : (To ?? new List<string>());
                Cc = !string.IsNullOrEmpty(CcAddresses) ? CcAddresses.Split(';').ToList() : Cc;
                Bcc = !string.IsNullOrEmpty(BccAddresses) ? BccAddresses.Split(';').ToList() : Bcc;
                AttachmentFiles = !string.IsNullOrEmpty(AttachmentFileName) ? AttachmentFileName.Split(';').ToList() : AttachmentFiles;

                if (AttachmentFiles != null)
                {
                    foreach (string file in AttachmentFiles)
                    {
                        message.Attachments.AddFileAttachment(file);
                    }
                }

                if (AttachmentContent != null)
                {
                    message.Attachments.AddFileAttachment(AttachmentContentName, AttachmentContent);
                }

                if (To.Count > 0)
                    message.ToRecipients.AddRange(To);
                else
                    throw new NullReferenceException("To Email Address not specified");

                if (Cc != null) message.CcRecipients.AddRange(Cc);
                if (Bcc != null) message.BccRecipients.AddRange(Bcc);

                message.Subject = Subject;
                message.Body = new MessageBody(MessageBodyType, Message);
                message.Send();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void SendEmail(string to, string subject, string message, string attachment = "", BodyType bodyType = BodyType.HTML)
        {
            ToAddresses = to;
            Subject = subject;
            MessageBodyType = bodyType;
            Message = message;
            AttachmentFileName = attachment;
            SendAndSaveCopy = false;
            AttachmentContent = null;
            AttachmentContentName = null;
            SendEmail(_exchange ?? throw new InvalidOperationException("Exchange service is not initialized."));
        }

        private async Task LogLoginOtpOrForgotPasswordDeliveryAsync(EmailRepo email, bool succeeded, Exception? deliveryException)
        {
            try
            {
                var template = await _unitOfWork.EmailTemplateConfiguration.GetFirstOrDefaultAsync(
                    x => x.UniqueTemplateId == email.TemplateId && x.ModuleId == email.ModuleId);
                if (template == null)
                    return;

                var templateCode = template.TemplateCode ?? string.Empty;
                if (!string.Equals(templateCode, "EX001", StringComparison.OrdinalIgnoreCase)
                    && !string.Equals(templateCode, "TMH005", StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }

                var processName = string.Equals(templateCode, "EX001", StringComparison.OrdinalIgnoreCase)
                    ? "Login/Forgot Password OTP"
                    : "Forgot Password reset link";

                if (succeeded)
                {
                    _commonService.SaveApplicationErrorLog(
                        $"Email delivered successfully via Exchange. | Process={processName} | To={email.ToRecipients} | EmailRepoId={email.Id} | TemplateCode={templateCode} | TemplateId={email.TemplateId} | ModuleId={email.ModuleId} | Subject={email.MailSubject}",
                        "EmailService_DeliverySuccess",
                        "EmailService",
                        email.ToRecipients ?? "External",
                        string.Empty);
                    return;
                }

                var failureDetail = deliveryException != null
                    ? ExtensionMethods.GetExceptionMessage(deliveryException)
                    : "Unknown delivery failure.";
                _commonService.SaveApplicationErrorLog(
                    failureDetail + $" | Email delivery failed. | Process={processName} | To={email.ToRecipients} | EmailRepoId={email.Id} | TemplateCode={templateCode} | TemplateId={email.TemplateId} | ModuleId={email.ModuleId} | Subject={email.MailSubject}",
                    "EmailService_DeliveryFailed",
                    "EmailService",
                    email.ToRecipients ?? "External",
                    string.Empty);
            }
            catch (Exception logEx)
            {
                LogEmailError(logEx, "EmailService_OtpForgotDeliveryLog", "EmailService", "System",
                    $" | EmailRepoId={email?.Id}");
            }
        }

        private void LogEmailError(Exception ex, string action, string controller, string userName, string extraContext = "")
        {
            try
            {
                _commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + extraContext,
                    action,
                    controller,
                    userName,
                    string.Empty);
            }
            catch (Exception)
            {
                // Never fail the email worker because error logging failed.
            }
        }

        private string TryGetBase64ImageData(string imageName)
        {
            try
            {
                var path = Normalize.parse(Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "Assets")));
                string imagePath = Path.Combine(path, imageName);

                if (!File.Exists(imagePath))
                {
                    _commonService.SaveApplicationErrorLog(
                        $"Email header image not found at '{imagePath}'. Sending email without header image.",
                        "EmailService_HeaderImage",
                        "EmailService",
                        "System",
                        string.Empty);
                    return string.Empty;
                }

                byte[] imageBytes = File.ReadAllBytes(imagePath);
                return Convert.ToBase64String(imageBytes);
            }
            catch (Exception ex)
            {
                LogEmailError(ex, "EmailService_HeaderImage", "EmailService", "System", $" | Image={imageName}");
                return string.Empty;
            }
        }

        private string ResolvePlainOrEncryptedConfig(string? value, string configKey)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            if (value.StartsWith("0C000000", StringComparison.OrdinalIgnoreCase))
            {
                try
                {
                    return CryptoExtensions.Decrypt(value);
                }
                catch (Exception decryptEx)
                {
                    LogEmailError(decryptEx, "EmailService_ConfigDecrypt", "EmailService", "System",
                        $" | ConfigKey={configKey}");
                    return value;
                }
            }

            return value;
        }
    }
}
