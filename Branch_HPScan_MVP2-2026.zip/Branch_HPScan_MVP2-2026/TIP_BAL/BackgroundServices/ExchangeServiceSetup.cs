using Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Configuration;

namespace TIP_BAL.BackgroundServices
{
    internal static class ExchangeServiceSetup
    {
        public static void SetEndpoint(ExchangeService exchange, IConfiguration? configuration, string mailFrom)
        {
            var exchangeUrl = configuration?["EmailSettings:ExchangeUrl"];
            if (!string.IsNullOrWhiteSpace(exchangeUrl))
                exchange.Url = new Uri(exchangeUrl);
            else
                exchange.AutodiscoverUrl(mailFrom);
        }
    }
}
