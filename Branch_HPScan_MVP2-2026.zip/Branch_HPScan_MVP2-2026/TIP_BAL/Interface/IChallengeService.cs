﻿using TIP_API.DTO.Admin;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface
{
    public interface IChallengeService
    {
        public Task<long> ChallengeResistrationForm(ChallengeDetail challengeDetail);

        public Task<RequestorDTO> GetRequestorInfo(long challengeRegId);

        public Task<long> UpdateChallengeResistrationStatus(string type, long challengeRegId, EmployeeDTO employeeDTO, string cfdh, string Comments = "");

        public Task<List<ChallengeVendorScreeningDTO>> GetAllVendorScreening(long challengeId);

        public Task<long> AddVendorScreening(ChallengeVendorScreening challengeVendorScreening);
        public Task<long> UpdateVendorScreening(ChallengeVendorScreening challengeVendorScreening);
        public Task<long> DeleteVendorScreening(long id);
        public Task<long> AddOrUpdateVendorScreening(List<ChallengeVendorScreening> challengeVendorScreenings, bool isEdit);
        public Task<ChallengeRegistrationDetailDTO> GetChallengeRegistrationDetailDTO(EmployeeDTO nuNo);
        public Task<LatestChallengeForExternalDTO> ChallengeDetailsByResponseId(long responseID);
        public Task<ChallengeRegistrationDetailDTO> GetChallengeRegistrationDetailDTO();
        public Task<ChallengeReviewDTO> GetChallengesForReview(long? RoleID, string userMU);
        public Task<List<ChallengeRegistrationDTO>> FilterGetChallengeRegistration(ChallengeRegistrationDetailFilterDTO challengeRegistrationDetailFilterDTO);
        public Task<ChallengeDetailDTO> GetChallengeDetail(long challengeRegId);

        public Task<ChallengeRegistrationDTO> GetChallengeRegistrationByRefNo(string challengeRegRefNo);

        public Task<ChallengeRegistrationDTO> GetChallengeRegistrationFromOldTIPRef(string challengeRegRefNo);

        public Task<long> UpdateChallengeUCTOwnership(long challengeRegId, EmployeeDTO employeeDTO);
        public Task<long> AddOrUpdateVOT(ChallengeVot challengeVTO);
        public Task<ChallengeVOT_DTO> GetChallengeVOT(long challengeId);
        public Task <List<ChallengeQuestionaire_DTO>> GetChallengeQuestionaire(long challengeId);
        public Task<bool> MapChallengeForEmail(EmailSendConfigDTO emailSendConfigDTO, long chanlengeRegId);
        public Task<ChallengeRespondByTypeDTO> GetAllChallengeResponse(long roleId, string loggedMu);
        public Task<bool> SetConfirmTech(long Id, bool isConfirm, EmployeeDTO? loggedInUser);
        public Task<ChallengeResponseQuestionDTO> ChallengeResponseQuestions(long responseId);
        public Task<List<ChallengeResponseReviewDTO>> GetChallengeReview(long responseId, long roleId, EmployeeDTO? loggedInUser);
        public Task<List<ReviewDetailDTO>> GetReviewerDetail(long responseId);
        public Task<long> AddSoultionReview(List<ChallengeResponseReview> challengeResponseReview, EmployeeDTO? loggedInUser, string status, string formBy);
        public Task<string> UpdateSoultionReviewStatus(EmployeeDTO? loggedInUser, long Id, string status, string comment);
        public Task<List<LatestChallengeDTO>> LatestPublishChallenges();


        public Task<challengePublishDetailsDTO> GetChallengePublication(long challengeRegId);
        public Task<List<QueryResponseDTO>> GetVendorQueryResponseForInternal(long ChallengeID);
        
        public Task<List<QueryResponseDTO>> GetAllVendorQueryAndResponseForInternal();
        public Task<List<QueryResponseDTO>> GetPDOQueryResponseForInternal(long SolutionId);

        //public Task<long> UpdatechallengePublication(challengePublishDetailsDTO DTO);
        public Task<long> UpdatechallengePublication(challengePublishDetailsDTO DTO, bool publishBit,EmployeeDTO? emp);


        public Task<long> AddChallengeSolution(ChallengeResponse challengeResponse);
        public Task<long> UpdateLocalSolution(ChallengeResponse challengeResponse);		

		public Task<long> UpdateChallengeSolution(VendorResponseDTO challengeResponse,long responseID, long vendorId,long statusId);
        public Task<long> AddOrUpdateVendorScreeningAnswers(List<ScreeningQuestionsDTO> Sqs, long responseID);
        public Task<long> AddVendorQueries(string query,long responseID,bool hasattachment);
        public Task<long> AddVendorQueryResponse(string response, long queryId, bool hasattachment,EmployeeDTO emp);
        public Task<long> UpdateVendorQueryResponse(string response, long responseId, bool hasattachment,long queryId,EmployeeDTO emp);


        public Task<long> AddPDOQueries(string query, long responseID, bool hasattachment, EmployeeDTO emp);
        public Task<long> AddPDOQueryResponse(string response, long queryId, bool hasattachment);
        public Task<long> UpdatePDOQueryResponse(string response, long responseId, bool hasattachment, long queryId);


        public Task<long> AddOrUpdateVendorTechDetailds(List<SolutionTechDetailsDTO> Sqs, long responseID);
        

        public Task<int> UpdatepublishStatus(long challengeRegId);
        public Task<int> UpdateQueryIsPublic(long queryId, bool status);
        public Task<int> UpdateQueryAsRead(long queryId);

        public Task<ChallengesForExternalDTO> LatestPublishChallengesForExternal(long sourceId, long participant);

        public Task<LocalSolutionDTO> GetLocalDetails(string cfcode);
        public Task<VendorResponseDetailsDTO> GetVendorResponseDetailsForExternal(string cfcode);

        public Task<List<SolutionTechDetailsDTO>> SolutionTechDetailsByResponseId(string cfcode);


        public Task <List<QueryResponseDTO>> GetVendorQueryResponseForExternal(string cfcode);
        public Task<List<LatestChallengeForExternalDTO>> ParticipatedChallengesForExternal(long sourceId, long participant);
        public Task<TechProposalQueries> TechProposalQueriesCount();
        public Task<List<ChallengeStatusCountDTO>> GetCTRStatusCount();
        public Task<List<ChallengeStatusCountDTO>> GetChallengeStatusCount();
        public Task<List<ChallengeStatusCountDTO>> GetPIRStatusCount();
        public Task<List<ChallengeStatusCountDTO>> GetChallengeResponseStatusCount();
        public Task<List<LatestChallengeForExternalDTO>> AllPublishedChallengesForExternal();
		public Task<string> UpdateSoultionMatrix(EmployeeDTO? loggedInUser, long Id, SolutionMatrixDTO solutionMatrixDTO);
		public Task<long> SendReminderEmails(string Module, string TemplateCode);
        public Task<List<SolutionReviewerListDTO>> SolutionReviewerList(long solId);
        public Task<List<ChallengeReassignmentListDTO>> ChallengeReassignmentList(long roleId, string CompanyNumber);
        public Task<List<AllPDOUsersDTO>> SolutionReviewerByChaId(long chaId);
        public Task<List<AllPDOUsersDTO>> CFDHByChaId(long chaId);
        public Task<List<AllPDOUsersDTO>> getchallengeFP(long chaId);


        public Task<ChallengeRegistration> GetChallengeForReAssignment(long Id);
        public Task<ChallengeDetail> GetChallengeDetailForReAssignment(long Id);
        public Task<long> UpdateChallengeForReAssignment(ChallengeRegistration obj);
        public Task<long> UpdateChallengeDetailsForReAssignment(ChallengeDetail obj);
        public Task<List<SolutionReviewerListDTO>> SolutionReviewerListByChaId(long chaId);
        public Task<long> AddChallengeReviewersForReAssignment(List<ChallengeSolutionReviewer> obj, ChallengeReassignReviewerDTO recevingDTO, EmployeeDTO? loggedInUser, List<SolutionReviewerListDTO>? OldSR);
        public Task<bool> SendReassignEmail(long Id, string Module, string TemplateCode, string? RefNo, AllPDOUsersDTO? newAdvisor, string? oldEmail, string? oldUserName, EmployeeDTO? loggedInUser, List<AllPDOUsersDTO>? newEmails);
        Task<long> AddChallengeFlowHistory(ChlFlowHistory DTO);
        Task<long> AddSRFlowHistory(SrFlowHistory DTO);
        Task<OverAllReportResponseDTO> OverAllReport(OverAllReportRequestDTO overAllReportDTO, EmployeeDTO? LoggedInUser);
        Task<ReportPrintDTO> OARPrint(OverAllReportRequestDTO overAllReportDTO);
		Task<TechKPIReportResponseDTO> TechKPIReport(TechKPIReportRequestDTO techKPIReportDTO, EmployeeDTO? LoggedInUser);
		Task<ReportPrintDTO> TKRPrint(TechKPIReportRequestDTO techKPIReportDTO);
		Task<MasterReportResponseDTO> MasterReport(MasterReportRequestDTO overAllReportDTO, EmployeeDTO? LoggedInUser);
		Task<ReportPrintDTO> MasterReportPrint(MasterReportRequestDTO masterReportRequestDTO);
        Task<List<ChlFlowHistoryDTO>> GetChlHistoryById(long ChlId);
        Task<ReportPrintDTO> PrintChallengesResponseReport(ChallengeReportRequestDTO ChallengeReportRequestDTO, EmployeeDTO? LoggedInUser);

        Task<ChallengeResponseReport> GetChallengesResponseReport(ChallengeReportRequestDTO ChallengeReportRequestDTO, EmployeeDTO? LoggedInUser);
        public Task<List<SRFlowHistoryDTO>> GetSRFlowHistory(long solutionId);

        Task<List<ConfigurationDTO>> GetVOTConfigurations();

    }

}
