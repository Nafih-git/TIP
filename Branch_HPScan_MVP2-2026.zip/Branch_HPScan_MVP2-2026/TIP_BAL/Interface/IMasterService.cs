﻿using TIP_Core;

namespace TIP_BusinessLogic.Interface
{
    public interface IMasterService
    {
        #region Module
        public Task<List<Module>> GetModule(int Id = 0);
        public Task<Response> SaveModule(Module model);
        #endregion
    }
}
