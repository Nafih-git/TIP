﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface
{
    public interface IBTMAssesmentService
    {
        public Task<List<BTMAssessmentDTO>> GetBTMAssessments(EmployeeDTO employee);
        public Task<long> AddBTM(BtmAssessment DTO);

        public Task<long> UpdateBTM(BtmAssessment DTO);
        public Task<long> DeleteBTM(long ID, EmployeeDTO employee);
        public Task<bool> MapBTMForEmail(EmailSendConfigDTO emailSendConfigDTO, long id,EmployeeDTO employee);
    }
}
