﻿using TIP_Core;
using TIP_CORE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BusinessLogic.Interface
{
    public interface ICommonService
    {
        

        public Task<List<TypeCodeMasterDTO>> GetMasterDataByType(string Type);
        public Task<List<TypeCodeMasterDTO>> GetAssetByMU(string Mu);
        public Task<List<TypeCodeMasterDTO>> GetClusterByAssetIdAndMU(long Assetid, string Mu);
        public Task<List<TypeCodeMasterDTO>> GetClusterByMU(EmployeeDTO employee, long assessmentid); 
        public Task<List<TypeCodeMasterDetailDTO>> GetMasterDetailByType(string type);
        public Task<List<TypeCodeMasterDTO>> GetMasterDataByTypeInternal(string Type);

        public Task<List<EmployeeDTO>> GetAllUsersByRole(string rolecode);

        public Task<long> AddNewSubType(TypeCodeMaster type);
        public Task<long> UpdateNewSubType(TypeCodeMaster type);        
        public Task<long> DeleteSubType(long id, EmployeeDTO employeeDTO);

        public Task<List<TypeCodeMasterDTO>> GetMasterDataByTypeAndParentID(string Type, int ParentID);
        public Task<TypeCodeMaster> GetMasterDataByParentAndParam1(string type, string param);

        EmployeeDTO? GetIdentityOfLoggedInUser(string CompanyNumber);

        public Task<List<EmailKeywordDTO>> GetEmailKeywordByType(long id);
        public Task<List<EmailTemplateConfigurationDTO>> GetEmailTemplateConfigByModule(long id);
        public Task<long> AddOrUpdateEmailTemplate(EmailTemplateConfiguration emailTemplateConfiguration);
        public Task<bool> SendEmail(EmailSendConfigDTO emailSendConfigDTO,EmployeeDTO? employee=null);
        public Task<decimal> Log(UtlAuditTrail obj);
        public Task<EmailSendConfigDTO> GenericEmailTemplateBaseInfo(EmailSendConfigDTO emailSendConfigDTO);
        public Task<List<DocumentRepoDTO>> DocumentRepoList(long linkId, string linkType, bool external = false);
        public Task<DocumentRepoDTO> DocumentRepo(long id);
        public Task<IList<TaskRepoDTO>> GetAllTasksForUser(string CompanyNumber);
        public Task<IList<PrecisedTaskDTO>> GetAllTasksCountForUser(EmployeeDTO employee);
        public Task<List<FileUploadDTO>> GetAllFilesByLinkId(long linkId, string linktype, bool external);
        public Task<List<FileUploadDTO>> GetDocumentsByLinkType(string linkType);
         Task<List<FileUploadDTO>> GetAllFilesById(long linkId, string linktype, bool external);
        public  Task<FileUploadDTO> GetFileById(long Id);

        public Task<long> AddTask(TaskRepo DTO);
        public Task<List<TypeCodeMasterDetailDTO>> GetMasterDataByParam2(string Param2);

        public Task<List<TypeCodeMasterDTO>> GetMasterDataByParentId(long pid);
        public Task<long> AddDocument(DocumentRepo docRepo);
        Task<bool> CheckIfUserHasRole(long RoleId, string UserId);
        public Task<long> DeleteDocument(long LinkId,string Linktype);
        public Task<string> GetEmailBymuNO(string muNo);
        public Task<TmEmployee> GetMuDetails(string muNo);
        public Task<List<RabitahContractDTO>> GetContractData();
        public Task<RabitahContractDTO> GetContractDataByContID(string contractID);    
        public Task<string> GetEmailByVendorCode(string muNo);
        
        public Task<FileUploadDTO> GetDDFormatPath();
        public Task<FileUploadDTO> GetTTAFormatPath(long id);
        public Task<List<DocLinkDTO>> GetDocLink();
		public Task<List<DocumentRepoDTO>> GetDocumentsById(long id);
        public Task<TypeCodeMaster> CheckIfPaymentMilestone(long Id);

        public Task<List<EmailEscalationDTO>> GetAllEmailsData();
        public Task<long> UpdateEmailEsc(EmailEscalation emailEscalation);
        public void SaveApplicationErrorLog(string errorMessage, string Action, string Controller, string UserName, string IPAddress,Guid GId=default);

        public Task<TypeCodeMasterDetailDTO> GetMasterDataById(long Id);

        public Task<long> AddPlanTech(CtrTechConfiguration ctrTechConfig);
        public Task<long> UpdatePlanTech(CtrTechConfiguration ctrTechConfig);
        public Task<long> DeletePlanTech(long id, EmployeeDTO employeeDTO);

        public Task<List<CtrTechConfigurationDTO>> GetCtrTechConfiguration();
        public Task<List<TechnologyKPIDTO>> GetTechKPIByYear(long year);
        public Task<long> AddTechKPI(List<TechnologyKpiConfig> kPIList);
        public Task<long> DeleteTechKPI(long year);
        public Task<List<CTRPlanDetailsDTO>> GetCtrplandetailsByCtrID(long ctrId, string phase);
        Task<List<VTipTechnologyPlanDTO>> GetCtrViewplandetailsByCtrID(long ctrId);

        Task<List<TypeCodeMasterDTO>> GetMasterDataByTypeConfiguration(string Type);

        Task<PrecisedTaskReportMasterDTO> GetAllTasks(ActiionTaskRequestDTO requestdto);
        Task<List<FileUploadDTO>> GetSolution_Query_Docs_ByRESP_Id(long resp_Id);
    }
}
