﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;

namespace TIP_BAL.Interface
{
    public interface IResponseService
    {
        public Task<long> AddNewChallengeResponse(ChallengeResponse challengeDTO);

    }
}
