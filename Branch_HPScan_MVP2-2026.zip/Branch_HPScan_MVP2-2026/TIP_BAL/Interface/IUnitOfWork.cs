﻿
using Microsoft.EntityFrameworkCore;
using TIP_CORE.Entities;
using TIP_DAL.Interface;
using TIP_DAL.Interface.Admin;
using TIP_DAL.Interface.Base;
using TIP_DAL.Repository;

namespace TIP_BAL.Interface
{
    public interface IUnitOfWork : IDisposable
    {
        IEmployeeRepository Employee { get; }
        IUserRoleRepository UserRole { get; }
        ITypeCodeMasterRepository TypeCodeMaster { get; }
        ITechnologyBankRepository TechnologyBank { get; }
        IPainAreasRepository PainAreas { get; }
        IBTMAssesmentRepository BTMAssesment { get; }
        IChallengeCheckListRepository ChallengeCheckList { get; }
        IChallengeRegistrationRepository ChallengeRegistration { get; }
        IChecklistChallengeLnkRepository ChecklistChallengeLnk { get; }

        IChallengeDetailRepository ChallengeDetail { get; }
        IChallengeSolutionReviewersRepository ChallengeSolutionReviewers { get; }
        IChallengeVendorScreeningRepository ChallengeVendorScreening { get; }
        IEmailKeywordRepository EmailKeyword { get; }
        IEmailTemplateConfigurationRepository EmailTemplateConfiguration { get; }

        IChallengeVOTRepository ChallengeVOT { get; }
        IConfigurationRepository Configuration { get; }
        IAuditTrailRepository AuditTrail { get; }
        ITrAuditLogRepository TrAuditLog { get; }

        IChallengeResponseRepository ChallengeResponse { get; }
        IVendortoChrQueryRepository VendortoChrQuery { get; }
        IVendorQueryResponseRepository VendorQueryResponse { get; }
        IPDOToVendorQuriesRepository PDOtoVendorQuery { get; }
        IPDOToVendorQuryResponseRepository PDOQueryResponse { get; }
        IChallengeResponseQuestionRepository ChallengeResponseQuestion { get; }
        IChallengeResponseTechnologyRepository ChallengeResponseTechnology { get; }
        IChallengeResponseReviewRepository ChallengeResponseReview { get; }
        IEmailRepoRepository EmailRepo { get; }

        IDocumentRepoRepository DocumentRepo { get; }
        ICtrRepository Ctr { get; }
        ITaskRepoRepository TasksRepo { get; }
        Task<int> SaveAsync();
        IVendorDetailRepository ExternalUser { get; }
        IChallengePublicationRepository challengePublication { get; }

        IChallengeSourcesRepository challengeSources { get; }
        ICtrTrialFpRepository CtrTrialFp { get; }
        IRoleToUserRepository RoleToUser { get; }
        ICtrAdditionalSolutionsRepository CtrAdditionalSolutions { get; }
        ICtrVotRepository CtrVot { get; }
        ICtrFlowHistoryRepository CtrFlowHistory { get; }
        ICtrTrialRiskRepository CtrTrialRisk { get; }
        ICtrApprovalListRepository CtrApprovalList { get; }
        ICtrApprovalListHisRepository CtrApprovalListHis { get; }
        IUserSettingsEFRepository UserSettings { get; }
        IAssetFPRespository AssetFP { get; }

        IClusterFPRespository ClusterFP { get; }
        IAdJobDataRepository AdJobDataList { get; }
        ICtrSuccessCriterionRepository CtrSuccessCriterion { get; }
		ICtrTrialRepository CtrTrial { get; }
		ICtrTrialYearRepository CtrTrialYear { get; }

		ICtrPotentialImpactedRepository CtrPotentialImpacted { get; }
		ICtrBudgetRepository CtrBudget { get; }

        IPirRepository Pir { get; }
        IPirTrialFpRepository PirTrialFp { get; }
        IPirFlowHistoryRepository PirFlowHistory { get; }
        IPirSupportingMembersRepository PirSupportingMembers { get; }
        IPirLessonLearntRepository PirLessonLearnt { get; }
        IPirAssessmentTrialResultRepository PirAssessmentTrialResult { get; }
        IPirTrialCandidateRepository PirTrialCandidate { get; }
        IPirVotRepository PirVot { get; }
        IPirActionPlanRepository PirActionPlan { get; }
        IPirSummaryRepository PirSummary { get; }	
        IPirImpactedExistingContractsRepository PirImpactedExistingContract { get; }
        IPirDeploymentStaircaseRepository PirDeploymentStaircase { get; }
        ICtrDeploymentStaircaseRepository CtrDeploymentStaircase { get; }
		IChallengeResponseSrRepository ChallengeResponseSr { get; }
        IPirApprovalListRepository PirApprovalList { get;}
        IPirApprovalListHisRepository PirApprovalListHis { get; }
        IDocLinkRepository DocLink { get; }
        IRabitahVendorsRepository RabitahVendor { get; }
        IRabitahContractRepository TmRabitahContract { get; }
        ICtrSchedulePriceRepository CtrSchedulePrice { get; }
        IExecutionInitiationRepository execution { get; }
        IExecutionBudgetConfirmationRepository budgetConfirmation { get; }
        IExecutionBudgetCostCentreRepository budgetCostCentre { get; }
        ICtrPercentageCompletionRepository CtrPercentageCompletion { get; }
        IExec_TrialCandiRepository executionTrialcandidate { get;  }
        IExec_TrialfpsRepository executionTrialFp { get; }
        IExecutionPotentialValueRepository executionPotentialValue { get; }
    
		IEmailEscalationRepository EmailEscalation { get; }
        IExecutionPlannedTimelineRepository executionplannedTimeline { get; }
        IExecutionPlannedRepository executionplanned { get; }
        IExecutionActualPlanRepository actualplanned { get;  }
        IExeFlowHistoryRepository ExeFlowHistory { get; }

        IExeInvoiceRepository ExeInvoice { get;}
        IExeInvoiceFlowHistoryRepository ExeInvoiceFlowHistory { get; }
        IErroLogRepository ErroLog { get; }
        IUserLogRepository UserLogs { get; }
        ITmUserPaArchieveRepository UserPaArchieve { get; }
        IChlFlowHistoryRepository ChlFlowHistory { get; }
        ISRFlowHistoryRepository SRFlowHistory { get; }
        ICtrTrialCandidateRepository CtrTrialCandidate{ get; }
        ICTRProjectMembersRepository CtrPM { get; }

        ICtrTechConfigurationRepository CTRTechConfig { get; }

        ICTRPlanDetailsRepository CTRPlanDetails { get; }
        ICTRActualPlanDetailsRepository CTRActualPlanDetails { get; }
        IDepVotRepository DepVot { get; }
        IDepInitiationRepository DepInitiation { get; }
        ITechnologyKpiConfigRepository TechnologyKpiConfig { get; }
	}
}
