﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface
{
    public interface IChallengeCheckListService
    {
        public Task<List<ChallengeChecklistDTO>> GetCheckLists();

        public Task<long> AddNewChallenge(ChallengeRegistration challengeDTO);

        public Task<long> AddChallengeCheckListLnks(List<ChecklistChallengeLnk> checklists);
		public Task<long> AddOrUpdateQuestion(ChallengeChecklist challengeChecklist);
		public Task<long> DeleteQuestion(long id);

	}
}
