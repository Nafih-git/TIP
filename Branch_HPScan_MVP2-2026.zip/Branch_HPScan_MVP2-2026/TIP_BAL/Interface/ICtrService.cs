﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;
using TIP_BAL.Services;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface
{
    public interface ICtrService
    {
        public Task<long> AddCTR(CtrInitiation DTO);

        public Task<List<CtrInitiationDTO>> GetAllCtr(string CompanyNumber);
        public Task<CtrInitiationDTO> GetCtrByRefNo(string RefNo);
        public Task<List<CtrInitiationDTO>> GetAllCtrForTTA(string CompanyNumber);
        public Task<string> GetDDFormat();

        public Task<CTRPRINTDTO> GetAllCtrPrint(long Id, long roleid, string CompanyNumber, string docType);
        public  Task<CTRPRINTDTO> GetTTAPrint(long Id, long roleid, string CompanyNumber, TTAPrint tTAPrint);
        public Task<List<CtrInitiationDTO>> GetAllCTRforReview(string CompanyNumber);
        Task<Boolean> ValidateVendor(string ttaref, string vendor_code);
        Task<string> ValidateCTR(long id);
        public Task<CtrInitiationDTO> GetCtrFormData(long Id,long roleid,string CompanyNumber);

        public Task<CtrViewPlanDetailsDTO> GetCtrFormDataforViewPlan(long Id);
        public Task<CtrInitiation> GetById(long Id);
        public Task<long> UpdateCtr(CtrInitiation DTO);
        public Task<long> AddTrialFp(List<CtrTrialFp> DTO);
        public Task<long> AddProjectMembers(List<CtrProjectMember> DTO);

        #region Additioal Solution

        public Task<long> AddAdditionalSolution(CtrAdditionalSolution DTO);

        public Task<List<CtrAdditionalSolutionDTO>> GetAllAdditionalSolution(long CtrId);
        public Task<List<CtrFlowHistoryDTO>> GetAllFlowHistory(long CtrId);
        public Task<List<CtrFlowHistoryDTO>> GetAllFlowHistoryDetail(long CtrId);

		public Task<CtrAdditionalSolutionDTO> GetAdditionalSolutionFormData(long Id);

        public Task<CtrAdditionalSolution> GetAdditionalSolutionById(long Id);

        public Task<long> UpdateAdditionalSolution(CtrAdditionalSolution DTO);

        public Task<long> DeleteAdditionalSolution(long Id, EmployeeDTO employee);

        Task<long> AddCtrFlowHistory(CtrFlowHistory DTO);

        #endregion

        #region Approval List
        public Task<CtrApprovalList> GetApprovalListBySeq(long Seq,long CtrId, string CompanyNumber);
        public Task<List<CtrApprovalList>> GetApprovalListBySeq(long Seq, long CtrId);
        public Task<List<CtrApprovalList>> GetApprovalListsByCtrId(long CtrId);

        public Task<CtrApprovalList> GetApprovalListById(long Id);
        public Task<List<AdJobLst>> GetAdJobswithFilter(string Filter);
        public Task<List<CtrApprovalListDTO>> GetAllApprovalListByCtrId(long CtrId);
        public Task<long> UpdateCtrAprovalList(long CtrId,long CurrentApprovalSeq,bool firstRoundofApprovals);
        public Task<bool> AddDefaultApprovalList(List<CtrApprovalList> obj);
        public Task<CtrApprovalListDTO> GetApprovalListFormData(long Id);
        public Task<long> UpdateApprovalList(CtrApprovalList DTO);
        public Task<long> UpdateApprovalList(List<CtrApprovalList> list);
        public Task<long> AddCtrApprovalList(CtrApprovalList obj);
        public Task<long> DeleteCtrApprovalList(long id);
        public Task<long> ResetCtrApproval(long CtrId);

        #endregion

        #region Re Assignemnt 

        public Task<List<CtrInitiationDTO>> GetAllCTRforReAssignmentAdmin(string CompanyNumber);
        public Task<List<CtrInitiationDTO>> GetAllCTRforReAssignmentUCT(string CompanyNumber);

        public Task<List<CtrTrialFp>> GetAllCtrTrialFpbyCtrId(long CtrId);

        #endregion

        #region 
        public Task<long> SendCTREmail(long CTRId, string Module, string TemplateCode, string? Comment="",EmployeeDTO? employee=null);
        public Task<long> SendReassignEmail(long CTRId, string Module, string TemplateCode, string newdataset, string olddataset,string changedby);
        public Task<bool> SendEmailReminderToVendor(emailReminder DTO);
        public Task<bool> SendEmailDDFormatToVendor(DDFormat DTO);
      
        public Task<bool> SendEmailTCTemplateToVendor(TcTemplate DTO);
        public Task<bool> SendEmailTTAToVendor(DDFormat DTO);
        
        #endregion

        #region CTR Reminder
        public Task<long> SendCTRReminderEmails(string Module, string TemplateCode);
        #endregion
        public Task<CtrVotDTO> GetCtrVOT(long ctrId);
        public Task<long> AddOrUpdateVOT(CtrVot ctrVot, bool isEdit);
        public Task<long> AddOrUpdateDepStaircase(List<CtrDeploymentStaircase> depStairs);

        public Task<List<CtrTrialRiskDTO>> GetCtrTrialRisks(long ctrId);
		public Task<long> AddTrialRisk(CtrTrialRisk ctrTrialRisk);
		public Task<long> UpdateTrialRisk(CtrTrialRisk ctrTrialRisk);
		public Task<long> DeleteTrialRisk(long id);
		public Task<List<CtrSuccessCriterionDTO>> GetCtrSuccessCerteria(long ctrId);
		public Task<long> AddCtrSuccessCerteria(CtrSuccessCriterion ctrTrialRisk);
		public Task<long> UpdateCtrSuccessCerteria(CtrSuccessCriterion ctrTrialRisk);
		public Task<long> DeleteCtrSuccessCerteria(long id);
      
        public Task<long> AddOrUpdateCtrTrial(List<CtrTrial> ctrTrials, bool isEdit);		
		public Task<List<CtrTrialDTO>> GetCtrTrial(long ctrId);
        public Task<List<CtrPotentialImpactedDTO>> GetCtrPotentialImpacted(long ctrId);
		public Task<long> AddCtrPotentialImpacted(CtrPotentialImpacted ctrPotentialImpacted);
		public Task<long> UpdateCtrPotentialImpacted(CtrPotentialImpacted ctrPotentialImpacted);
		public Task<long> DeleteCtrPotentialImpacted(long id);

		public Task<List<CtrBudgetDTO>> GetCtrBudget(long ctrId);
		public Task<long> AddCtrBudget(CtrBudget ctrBudget);
		public Task<long> UpdateCtrBudget(CtrBudget ctrBudget);
		public Task<long> DeleteCtrBudget(long id);
		public Task<CtrFinalDeploymentStaircaseDTO> GetCtrDeploymentStaircaseDetail(long CtrId);
		public Task<long> AddDeploymentStaircase(CtrDeploymentStaircase deploymentStaircase);
		public Task<long> UpdateDeploymentStaircase(CtrDeploymentStaircase deploymentStaircase);
		public Task<long> DeleteDeploymentStaircase(long id);
		public Task<long> UpdateFinalDeploymentStaircase(CtrInitiationDeploymentStaircaseDTO ctrInitiationDeploymentStaircaseDTO, EmployeeDTO? LoggedInUser);
		

        public Task<List<CtrSchedulePriceDTO>> GetCtrSchedulePrice(long ctrId);
        public Task<long> AddCtrSchedulePrice(CtrSchedulePrice CtrSchedulePrice);
        public Task<long> UpdateCtrSchedulePrice(CtrSchedulePrice CtrSchedulePrice);
        public Task<long> DeleteCtrSchedulePrice(long id);

        public Task<List<CtrPercentageCompletionDTO>> GetCtrPaymentMilestone(long ctrId);
        public Task<long> AddCtrPaymentMilestone(CtrPercentageCompletion obj);
        public Task<long> UpdateCtrPaymentMilestone(CtrPercentageCompletion obj);
        public Task<long> DeleteCtrPaymentMilestone(long id);
        public Task<List<CtrApproverListDTO>> GetApproverListByCtr(long Id);
		public Task<GetAllStatusDTO> GetAllStatusByCtr(long ctrId);
        Task<List<CtrTrialCandidateDTO>> GetAllTrialCandidates(long CtrId, long roleid, string CompanyNumber);
        Task<long> AddTrialCandidates(CtrTrialCandidate TrialCandidate);
        Task<long> UpdateTrialCandidates(CtrTrialCandidate pirTrialCandidate);
        Task<long> DeleteTrialCandidates(long id);
        Task<long> DeleteCTRPlan(long id, EmployeeDTO employeeDTO);
        Task<long> AddctrPlan(CtrPlanDetail ctrplan, bool IsSubmit);

        Task<long> UpdateCTRActualPlan(CTRActualPlanDetailsDTO ctrplan);
        Task<long> AddctrActualPlan(CtrActualPlanDetail ctrplan);
        Task<List<TypeCodeMasterDTO>> GetOverallProgress();
        Task<long> UpdateCTRPlan(CtrPlanDetail ctrplan, bool IsSubmit);

        public Task<BudgetReportResponseDTO> BudgetRepot(BudgetReportRequestDTO budgetReportDTO, EmployeeDTO? LoggedInUser);

        public Task<ReportPrintDTO> BudgetRepotPrint(BudgetReportRequestDTO budgetReportDTO);
        Task<long> SendCTRPlanEmail(long CTRId, long actualId, string Module, string TemplateCode);
    }
}
