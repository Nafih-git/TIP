﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_BAL.Services;
using TIP_CORE.Admin;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface
{
    public interface IExecutionService
    {
        Task<List<ApprovedCtrForExecDTO>> GetApprovedCtr(string CompanyNumber);
        Task<ExecutionIntiationDTO> InitiateExecution(long ctrId, string companyNumber, long roleId,long execId);
        Task<List<ExecutionTrialfpsDTO>> GetTrialFPForExec(long ctrid);
        Task<ExecutionTrialfpsDTO> GetTrialFPForExecbyId(long exeId);

        public Task<PrintDTO> GetContractDataRDLC(long Id, long roleid, string CompanyNumber);
        Task<List<ExecutionPotentialValueDTO>> GetAllExecPotentialValue(long ctrid);
        //Task<long> addExecutionTrialcandidate(ExecutionTrialCandidate DTO);
        Task<long> addExecutionTrialFp(ExecutionTrialFp DTO);
        Task<long> addExecutionplanned(ExecutionPlannedDTO DTO);
        Task<long> DeleteExTrialFPs(long Id, EmployeeDTO employee);
        Task<long> DeleteExecutionPlannedTimeline(long Id, EmployeeDTO employee);

        Task<long> DeleteTrialCandidates(long id);
        Task<long> UpdateTrialCandidates(ExecutionTrialCandidate obj);
        Task<long> AddTrialCandidates(ExecutionTrialCandidate execTrialCandidate);
        Task<List<ExecutionTrialCandidateDTO>> GetAllTrialCandidates(long execId);
        Task<long> UpdateExPotentialValue(ExecutionPotentialValue obj);
        Task<long> addorUpdateinitiate(ExecutionIntiationDTO obj,EmployeeDTO loggedInUser);
        Task<List<ExecutionPlannedTimelinesDTO>> GetConfig_MilestoneBYExecId(long execId, bool IsCreated, long roleid);
        Task<List<InitiatedTrialForExecDTO>> GetinitiatedTrialForExecution(string companyNumber);
        Task<List<TypeCodeMasterDetailDTO>> GetStagesDataByexec(long exec);
        Task<List<TypeCodeMasterDTO>> GetSortActivity(long execId);
        Task<List<TypeCodeMasterDTO>> GetSortStagesByexec(long execId);
        Task<long> addorUpdateExecutionPlannedTimeline(ExecutionPlannedTimeline obj);
        Task<long> updateIsMandatory(long trialFPSId, bool IsMandatory);
        Task<long> SendExecutionEmail(long ExecId, string Module, string TemplateCode, EmployeeDTO loggedInUser, string? Comment = "",string? previousMU="", long? planid = 0,long? InvId=0);
        Task<ExecutionPlannedDTO> GetExecutionPlannedById(long Id, long roleid, string CompanyNumber, bool Is_Created);
        Task<ExecutionPlanned> GetexecutionPlanById(long Id);
        Task<long> UpdateexecutionPlan(ExecutionPlanned DTO);
        Task<List<ExecutionReAssisgnDTO>> GetAllExecutionforReAssignment(long roleId, string CompanyNumber);
        Task<ExecutionInitiation> GetExecutionForReAssignment(long Id);
        Task<long> UpdateExecutionForReAssignment(ExecutionInitiation DTO);
        Task<ExecutionTrialFp> GetExecutionMTFReAssignment(long Id);

        Task<long> UpdateExecutionMTFReAssignment(ExecutionTrialFp DTO);



        Task<long> AddExeFlowHistory(ExeFlowHistory DTO);

        Task<List<ApprovedExecutionPlannedDTO>> GetActualPlanGrid(string CompanyNumber);

        Task<List<ExecutionActualPlannedTimelineDTO>> GetActualPlannedTimeline(bool is_created, long execId, long roleid,string CompanyNumber);

        Task<List<TypeCodeMasterDTO>> GetOverallProgress();

        #region Invoice Register
        Task<List<InvoiceRequestDTO>> LoadInvoiceRequests(long ActiveRole,string MuNumber);
        Task<List<InvoiceRequestDetailsDTO>> LoadInvoiceRequestDetails(long ActiveRole,string MuNumber,long ExecutionId);

        public Task<long> AddInvoice(ExecutionInvoice DTO);
        public Task<long> UpdateInvoice(ExecutionInvoice DTO);
        public Task<ExecutionInvoice> GetExecutionInvoice(long Id);
        #endregion
        Task<long> UpdateExecutionActualPlanTimeline(ExecutionActualplannedtimline obj);
        Task<long> SendReminderEmails(string Module, string TemplateCode);

        Task<List<ExeFlowHistoryDTO>> GetAllFlowHistory(long ExeId);
        Task<List<ExeFlowHistoryDTO>> GetHistoryByPlanId(long plan);
        Task<List<ExeFlowHistoryDTO>> GetHistoryByApprovedPlanId(long plan);

        Task<TrialPlanReportResponseDTO> TrailPlanReport(TrialPlanReportDRequestDTO trialPlanReportDTORequestDTO, EmployeeDTO? LoggedInUser);

         Task<ReportPrintDTO> TrailPlanPrint(TrialPlanReportDRequestDTO ReportDTO);
        public Task<long> UpdateExecutionCompletion(long execId);
    }
}
