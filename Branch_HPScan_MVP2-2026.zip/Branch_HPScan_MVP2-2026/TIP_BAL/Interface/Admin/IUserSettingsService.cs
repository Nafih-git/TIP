﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;
using TIP_CORE;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface.Admin
{
    public interface IUserSettingsService
    {
        public Task<UserSettingsDTO> GetUserRoledata();
        public Task<List<AllPDOUsersDTO>> GetUsersWithfilter(string Filter);
        public Task<List<AllPDOUsersDTO>> GetUserWithoutLoggedInUser(string Filter,string LoggedInUser);

        public Task<List<AllPDOUsersDTO>> GetUserWithoutUCTANDLoggedInUser(string Filter, string LoggedInUser);

        public Task<string> SaveUserToRoleMapping(UserViewData ViewData);
        public Task<string> UpdateActiveRole(long Role_ID);
        public Task<string> UpdateActiveRoleByCode(string Role_Code);
        public Task<List<UserViewDataD>> loadUserRoleMapping();
        public Task<string> DeleteUserToRoleMapping(string UserId);

        public Task<RoleToMenuMappingDTO> LoadRoleMenuMapping(long ROLE_ID);

        public Task<string> saveRoleMenuMapping(RoleToMenuMappingDTO ViewData);

        public Task<List<TIP_CORE.EntitiesDTO.UserRolesDTO>> GetUserRoles(bool onlyActivated);
        public Task<long> AddUserRole(TmUserRole tmUserRole);
        public Task<long> UpdateUserRole(TmUserRole tmUserRole);
        public Task<long> DeleteUserRole(long RoleId);

        
        public Task<long> ValidateVendor(string emailAddress, string pass, string cpb);
        public Task<long> ValidateVendorForPasswordCreation(string emailAddress, string pass, string cpb);
        public Task<List<EmployeeDTO>> getUCTEmail(long role);
        public Task<bool> VendorLoginKeywordDTO(string Module,string TemplateCode, string otp, string emailAddress);
        public Task<bool> AutoReplyContactUs(ExternalContactUs obj, string Module, string TemplateCode); 
        public Task<long> UpdateOTP(string emailAddress, int otpcode, int bit);
        
        public Task<long> ValidateOTP(string emailAddress, int otpcode);
        public Task<List<UserApplicationViewDataD>> loadUserAssetFocalPoint();
        public Task<List<UserApplicationViewDataD>> loadUserClusterFocalPoint();

        public Task<List<AllPDOUsersDTO>> loadApplicationUser();
        public Task<ExternalUserDTO> GetExternalUser(string emailAddress);
        public Task<long> AddExternal_User(ExternalUserDTO externaluser, EmailSendConfigDTO emailSendConfigDTO);
        Task<long> SendForgetPa(EmailSendConfigDTO emailSendConfigDTO, string emailaddress);
        public Task<long> updateExternal_UserPA(ExternalUserDTO externaluser);
        public Task<long> UpdateUserLogin(ExternalUserDTO externaluser);
        public Task<long> saveUserlog(long userId,string status);
    }
}
