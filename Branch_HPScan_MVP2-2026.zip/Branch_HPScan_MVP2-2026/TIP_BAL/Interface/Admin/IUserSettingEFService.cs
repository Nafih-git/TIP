﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface.Admin
{
    public interface IUserSettingEFService
    {
        public Task<List<EmployeeDL>> GetApplicationUser();        
        public Task<long> UpdateFocalPointLink(FocalpointDto FPLink);
        public Task<long> DeleteFocalPointLink(string userid);
        public Task<long> DeleteClusterFocalPointLink(string userid);
        public Task<FPLinkEmployeeDL> GetApplicationFPDetailsDTO();
        public Task<List<ExternalUserDTO>> GetExternalUser();
        public Task<long> UpdateClusterFocalPointLink(FocalpointDto FPLink);
        public Task<List<UserRolesDTO>> GetPMRoles();

        public Task<TmUserRole> GetUserRoleById(long roleID);

        public Task<long> UpdateActiveRole(string userId,long roleID);
    }
}
