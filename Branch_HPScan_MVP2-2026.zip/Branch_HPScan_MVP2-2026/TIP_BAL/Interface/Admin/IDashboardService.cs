﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;
using TIP_CORE;
using TIP_CORE.Admin;

namespace TIP_BAL.Interface.Admin
{
    public interface IDashboardService
    {
        public Task<BaseDTO> getBaseData(int RoleId, string userName);
        public Task<BaseDTO> getBaseData_LoginRoles(string userName);
    }
}
