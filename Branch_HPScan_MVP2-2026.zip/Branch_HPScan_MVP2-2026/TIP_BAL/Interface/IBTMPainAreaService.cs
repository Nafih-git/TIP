﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface
{
    public interface IBTMPainAreaService
    {
        public Task<List<BTMAssessmentDTO>> GetAssessmentsForRanking(string MU);
        public Task<List<BTMAssessmentDTO>> GetFilterAssessmentsForRanking(BTMAssessmentFilterDTO btmAssessmentIP_DTO); 
        public Task<List<RankPainAreaDTO>> GetPainAreasForRanking(long AssessmentId);
        public Task<PainArea> GetPainAreabyId(long id);
        public Task<List<PainAreaDTO>> GetPainAreasByAssessmentId(long AssessmentId,EmployeeDTO employee);
        public Task<List<RankPainAreaDTO>> GetFilterPainAreasForRanking(RankPainAreaFilterDTO rankPainAreaFilterDTO);


        public Task<long> UpdateRank(PainArea obj);
        public Task<BtmAssessment> GetAssessmentById(long AssessmentId);
        public Task<long> SubmitAssessment(BtmAssessment obj);
        public bool CheckIfAssessmentCanBeReviewed(long AssessmentId);

        public Task<long> SendBTMEmail(long painAreaId, string Module, string TemplateCode, EmployeeDTO employee);
        public Task<bool> MapBTMForEmail(EmailSendConfigDTO emailSendConfigDTO, long painAreaId, BTMAssessmentKeywordDTO obj, string TemplateCode, EmployeeDTO? employee = null);
        public Task<long> AddPainArea(PainArea DTO);
        public Task<long> UpdatePainArea(PainArea DTO);
        public Task<long> DeletePainArea(long ID,EmployeeDTO employee);


    }
}
