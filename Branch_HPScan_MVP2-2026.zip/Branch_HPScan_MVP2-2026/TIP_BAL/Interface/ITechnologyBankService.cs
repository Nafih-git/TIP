﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface
{
    public interface ITechnologyBankService
    {
        public Task<List<TechnologyBankDTO>> GetTechnologyBanks(EmployeeDTO LoggedInUser);
        public Task<List<TechnologyBankDTO>> GetFilterTechnologyBanks(TechnologyBankFilterDTO technologyBankFilterDTO);

        public Task<long> AddTechnologyBank(TechnologyBank DTO);

        public Task<long> UpdateTechnologyBank(TechnologyBank DTO);
        public Task<long> DeleteTechnologyBank(long ID, EmployeeDTO employee);
        public Task<TechnologyBankDTO> GetTechnologyBankByRefId(long challengeId, long challengeRefId);
        public Task<TechnologyStatusReportDTO> TechnologyStatusReport(long tech);

        public Task<List<TechnologyBankDTO>> TechnologyStatusTitle(string? search, long? areaId, long? applicationId, long? themeId, string? UCT_FP, long? maturationPhase, bool? isFilter);
        public Task<TechnologyHeatMapReportDTO> TechnologyHeatMAPReport(TechnologyStatusRequestDTO technologyheatmapreportdto);
        public Task<ReportPrintDTO> ActionTrackerPrint(ActiionTaskRequestDTO requestdto);
        Task<ReportPrintDTO> TechnologyHeatMAPPrint(TechnologyStatusRequestDTO technologyheatmapreportdto);

    }
}
