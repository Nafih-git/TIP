﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_BAL.Services;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface
{
    public interface IPIRService
    {
        Task<long> InitiatePir(PirInitiation DTO);
        Task<long> AddTrialFp(List<PirTrialFp> DTO);
        Task<long> AddSupportingMemebers(List<PirSupportingMember> DTO);
        Task<long> AddFlowHistory(PirFlowHistory DTO);
        Task<PirInitiationDTO> GetPirDataByRefNo(string RefNo);
        Task<List<ApprovedCtrDTO>> GetApprovedCtr(string CompanyNumber);
        Task<List<ApprovedCtrDTO>> GetPirToReview(string CompanyNumber);
        Task<List<ApprovedCtrDTO>> GetPirForApproval(string CompanyNumber);

        Task<PirCtrInitDTO> GetCtrPriData(long CtrId, long PirId, long roleid, string CompanyNumber);
        Task<List<PirFlowHistoryDTO>> GetAllFlowHistory(long PirId);
        Task<List<PirFlowHistoryDTO>> GetAllFlowHistoryDetail(long PirId);


        public Task<PirInitiation> GetById(long Id);

        Task<PirWorkFlowDTO> GetPirWorkFlowData(long PirId, long roleid, string CompanyNumber);
        Task<PirGeneralInformationDTO> GetPirData(long PirId, long roleid, string CompanyNumber);
        public Task<long> UpdatePir(PirInitiation DTO);
        Task<long> UpdatePirGeneralInformation(PirInitiation DTO);

        Task<PirTrialDetailsDTO> GetPirTrialDetailsData(long PirId, long roleid, string CompanyNumber);
        Task<long> UpdatePirTrialDetails(PirInitiation DTO);

        #region Assessment of Trial Candidates
        Task<List<PirTrialCandidateDTO>> GetAllTrialCandidates(long PirId, long roleid, string CompanyNumber);
        Task<long> AddTrialCandidates(PirTrialCandidate pirTrialCandidate);
        Task<long> UpdateTrialCandidates(PirTrialCandidate pirTrialCandidate);
        Task<long> DeleteTrialCandidates(long id);
        #endregion

        #region Assessment of Trial Results
        Task<List<PirAssessmentTrialResultDTO>> GetAllAssessmentTrialResults(long PirId, long roleid, string CompanyNumber);
        Task<long> AddAssessmentTrialResult(PirAssessmentTrialResult pirTrialCandidate);
        Task<long> UpdateAssessmentTrialResult(PirAssessmentTrialResult pirTrialCandidate);
        Task<long> DeleteAssessmentTrial(long id);
        #endregion

        #region Lesson Learnt
        Task<List<PirLessonLearntDTO>> GetAllLessonLearnt(long PirId, long roleid, string CompanyNumber);
        Task<long> AddLessonLearnt(PirLessonLearnt pirLessonLearnt);
        Task<long> UpdateLessonLearnt(PirLessonLearnt pirLessonLearnt);
        Task<long> DeleteLessonLearnt(long id);
        #endregion

        #region Impacted Existing Contracts
        Task<List<PirImpactedExistingContractDTO>> GetAllImpactedContracts(long PirId, long roleid, string CompanyNumber);
        Task<long> AddContractsFromCtr(long PirId, EmployeeDTO? LoggedInUser);
        Task<long> AddImpactedContracts(PirImpactedExistingContract pirImpactedExisting);
        Task<long> UpdateImpactedContracts(PirImpactedExistingContract obj);
        Task<long> DeleteImpactedContracts(long id);

        #endregion

        #region Deployment Staircase

        Task<long> AddDeploymentStaircaseFromCtr(long PirId, EmployeeDTO? LoggedInUser);
        Task<PirDeploymentStaircaseDetailsDTO> GetPirDeploymentStaircaseData(long PirId, long roleid, string CompanyNumber);
        Task<long> UpdatePirDeploymentStaircaseData(PirInitiation DTO);

        Task<List<PirDeploymentStaircaseDTO>> GetAllDeploymentStaircase(long PirId, long roleid, string CompanyNumber);
        Task<long> AddDeploymentStaircase(PirDeploymentStaircase deploymentStaircase);
        Task<long> UpdateDeploymentStaircase(PirDeploymentStaircase deploymentStaircase);
        Task<long> DeleteDeploymentStaircase(long id);
        #endregion

        Task<long> SendEmail(long Id, string Module, string TemplateCode, string? Comment = "", EmployeeDTO? employee=null);
        Task<long> SendReassignEmail(long Id, string Module, string TemplateCode, string newdataset, string olddataset, string changedby);
		public Task<PirVotDTO> GetPirVOT(long ctrId);
		public Task<long> AddOrUpdateVOT(PirVot ctrVot, bool isEdit);
        public Task<long> AddOrUpdateDepStaircase(List<PirDeploymentStaircase> depStairs);
        public Task<List<PirActionPlanDTO>> GetPirActionPlan(long pirId);
		public Task<long> AddPirActionPlan(PirActionPlan pirActionPlan);
		public Task<long> UpdatePirActionPlan(PirActionPlan pirActionPlan);
		public Task<long> DeletePirActionPlan(long id);

		public Task<PirSummaryDTO> GetPirSummary(long pirId);
		public Task<long> AddPirSummary(PirSummary pirSummary);
		public Task<long> UpdatePirSummary(PirSummary pirSummary);

        #region Workflow

        public Task<PirApprovalList> GetApprovalListById(long Id);
        public Task<List<PirApprovalListDTO>> GetAllApprovalListByPirId(long PirId);
        public Task<bool> AddDefaultApprovalList(List<PirApprovalList> obj);

        public Task<PirApprovalListDTO> GetApprovalListFormData(long Id);
        public Task<long> UpdateApprovalList(PirApprovalList DTO);
        public Task<long> UpdateApprovalList(List<PirApprovalList> list);

        public Task<long> AddPirApprovalList(PirApprovalList obj);
        public Task<long> DeletePirApprovalList(long id);
        public Task<long> ResetPirApproval(long id);
        public Task<long> UpdatePirAprovalList(long PirId, long CurrentApprovalSeq, bool firstRoundofApprovals);
        public Task<PirApprovalList> GetApprovalListBySeq(long Seq, long PirId, string CompanyNumber);
        public Task<List<PirApprovalList>> GetApprovalListBySeq(long Seq, long PirId);
        public Task<List<PirApprovalList>> GetApprovalListsByPirId(long PirId);

        #endregion

        #region Re Assignemnt 

        public Task<List<ApprovedCtrDTO>> GetAllPirforReAssignmentAdmin(string CompanyNumber);
        public Task<List<ApprovedCtrDTO>> GetAllPirforReAssignmentUCT(string CompanyNumber);

        public Task<List<PirTrialFp>> GetAllPirTrialFpbyPirId(long PirId);

        #endregion

        #region PIR Reminder
        public Task<long> SendReminderEmails(string Module, string TemplateCode);
        #endregion   

		public Task<PrintDTO> GetPirPrint(long Id, long roleid, string CompanyNumber, string docType);
        public Task<List<PirApproverListDTO>> GetApproverListByPir(long Id);
		public Task<long> AddTrialCandidateFromCtr(long PirId, EmployeeDTO? LoggedInUser);
        public Task<List<ApprovedPirDTO>> GetApprovedPir(string CompanyNumber, long roleId);

	}
}
