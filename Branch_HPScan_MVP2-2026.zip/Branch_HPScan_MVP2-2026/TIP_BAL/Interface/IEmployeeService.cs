﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface
{
    public interface IEmployeeService
    {
        public Task<EmployeeDTO> getByMuNumber(string MuNumber);

        public Task<long> AddEmployee(TmEmployee DTO);

        public Task<long> UpdateEmployee(TmEmployee DTO);

        public Task<long> DeleteEmployee(string COMPANY_NUMBER);

        public Task<List<SubthemeCfdhLnkDTO>> GetCFDH(long subThemeId);
        public Task<List<EmployeeDL?>> GetEmployeeByRoleId(long roleId);

        #region Ctr Approvals

        public Task<long> AddUserRoles(List<TmRoleToUserMapping> obj);

        public Task<TmUserRole> GetRoleId(string RoleCode);

        public Task<TmUserRole> GetRoleId(long RoleID);

        #endregion

        public Task<Boolean> CheckIfUserHasRole(string CompanyNumber, long RoleId);
        public  Task<Boolean> CheckIfUserHasRoleByR_C(string CompanyNumber, string RoleCode);

    }
}
