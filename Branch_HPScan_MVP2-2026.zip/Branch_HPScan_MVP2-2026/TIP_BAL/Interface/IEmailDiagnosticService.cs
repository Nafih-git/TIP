using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Interface
{
  public class EmailDiagnosticRequestDto
    {
        public string To { get; set; } = string.Empty;
        public string? Cc { get; set; }
        public string Subject { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;

        /// <summary>
        /// Comma-separated steps: config, exchange, queue, worker, all.
        /// Default runs config + exchange + queue; set includeWorker or RunWorkerAfterQueue to process the queue.
        /// </summary>
        public string? Steps { get; set; }

        /// <summary>When true, runs EmailService.ExecuteAsync after a successful queue insert.</summary>
        public bool RunWorkerAfterQueue { get; set; }

        /// <summary>When set, worker step only sends this EMAIL_REPO row (must be N or E).</summary>
        public long? ProcessEmailRepoId { get; set; }
    }

    public class EmailDiagnosticStepDto
    {
        public string Step { get; set; } = string.Empty;
        public bool Success { get; set; }
        public string? Detail { get; set; }
        public string? Error { get; set; }
    }

    public class EmailDiagnosticReportDto
    {
        public bool OverallSuccess { get; set; }
        public long? EmailRepoId { get; set; }
        public bool? SchedulerEnabled { get; set; }
        public List<EmailDiagnosticStepDto> Steps { get; set; } = new();
    }

    public interface IEmailDiagnosticService
    {
        Task<EmailDiagnosticReportDto> RunAsync(EmailDiagnosticRequestDto request, bool? schedulerEnabled, CancellationToken cancellationToken = default);

        Task<EmailDiagnosticReportDto> GetEnvironmentStatusAsync(bool? schedulerEnabled, CancellationToken cancellationToken = default);
    }
}
