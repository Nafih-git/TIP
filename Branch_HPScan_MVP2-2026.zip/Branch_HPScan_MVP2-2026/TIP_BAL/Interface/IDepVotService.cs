﻿using TIP_Core;
using TIP_CORE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BusinessLogic.Interface
{
    public interface IDepVotService
    {
		public Task<long> AssignCH(DepInitiation DTO);
		public Task<List<DepVotDTO>> GetDeployment(long roleId, string loggedMu, long pirId);
		public Task<DepVotDTO> GetDeploymentById(long Id);
		public Task<DepVotDTO> GetDeploymentByPirId(long Id);
		public Task<string> DeploymentPlan(DepVot depVot, string status, long pirId);

		public Task<long> DeleteDeploymentPlan(long Id);
		//Task<long> SendDeploymentEmail(long Id, string Module, string TemplateCode, EmployeeDTO loggedInUser, string? currentMU = "", string? previousMU = "");//, string? Comment = "", long? planid = 0

		Task<List<DepReassignmentDTO>> GetAllDeploymentforReAssignment(long roleId, string CompanyNumber);

		Task<DeploymentTrialfpsDTO> GetCHFPForDeploymentbyId(long id);
		Task<long> UpdateDeploymentReAssignment(DepInitiation DTO);
		Task<DepInitiation> GetDeploymentReAssignment(long Id);
		Task<long> SendDeploymentEmail(long Id, string Module, string TemplateCode, EmployeeDTO loggedInUser, long? votId, string? currentMU = "", string? previousMU = "");
		Task<long> SendReminderEmails(string Module, string TemplateCode);
		Task<DeploymentTrialfpsDTO> GetUCTFPForDeploymentbyId(string CompanyNumber);

    }
}
