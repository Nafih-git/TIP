﻿using TIP_CORE.Entities;

namespace TIP_BAL.Interface
{
    public interface IChallengeSolutionReviewersService
    {
        public Task<long> AddOrUpdateReviewers(List<ChallengeSolutionReviewer> challengeSolutionReviewers, bool isEdit);
    }
}
