﻿using TIP_BusinessLogic.Interface;
using TIP_DAL.Interface;
using TIP_Core;

namespace TIP_BusinessLogic.Services
{
    public class MasterService : IMasterService
    {
        private readonly IMasterRepository masterRepository;
        public MasterService(IMasterRepository _masterRepository)
        {
            masterRepository = _masterRepository;
        }

        #region Module
        public async Task<List<Module>> GetModule(int Id = 0)
        {
            return await masterRepository.GetModule(Id);
        }
        public async Task<Response> SaveModule(Module model)
        {
            return await masterRepository.SaveModule(model);
        }
        #endregion
    }
}
