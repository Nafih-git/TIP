using Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using TIP_BAL.BackgroundServices;
using TIP_BAL.BackgroundServices;
using TIP_BAL.Interface;
using TIP_BusinessLogic.Interface;
using TIP_Common;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using Task = System.Threading.Tasks.Task;

namespace TIP_BAL.Services
{
    public class EmailDiagnosticService : IEmailDiagnosticService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<EmailDiagnosticService> _logger;
        private readonly EmailService _emailService;
        private readonly IConfiguration _configuration;

        public EmailDiagnosticService(
            IUnitOfWork unitOfWork,
            ILogger<EmailDiagnosticService> logger,
            EmailService emailService,
            IConfiguration configuration)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
            _emailService = emailService;
            _configuration = configuration;
        }

        public async Task<EmailDiagnosticReportDto> GetEnvironmentStatusAsync(bool? schedulerEnabled, CancellationToken cancellationToken = default)
        {
            var report = new EmailDiagnosticReportDto { SchedulerEnabled = schedulerEnabled };
            await RunConfigStepAsync(report, cancellationToken);
            report.OverallSuccess = report.Steps.Any(s => s.Step == "config" && s.Success);
            if (schedulerEnabled == false)
            {
                report.Steps.Add(new EmailDiagnosticStepDto
                {
                    Step = "scheduler",
                    Success = false,
                    Error = "PeriodicHostedService.IsEnabled is false — queued mail will not send until GET /StartSS."
                });
            }
            else if (schedulerEnabled == true)
            {
                report.Steps.Add(new EmailDiagnosticStepDto
                {
                    Step = "scheduler",
                    Success = true,
                    Detail = "PeriodicHostedService.IsEnabled is true (worker runs about every 1 minute)."
                });
            }
            return report;
        }

        public async Task<EmailDiagnosticReportDto> RunAsync(
            EmailDiagnosticRequestDto request,
            bool? schedulerEnabled,
            CancellationToken cancellationToken = default)
        {
            var report = new EmailDiagnosticReportDto { SchedulerEnabled = schedulerEnabled };
            var stepNames = ResolveSteps(request);

            var needsRecipient =
                stepNames.Contains("exchange")
                || stepNames.Contains("queue")
                || (stepNames.Contains("worker") && !request.ProcessEmailRepoId.HasValue && !request.RunWorkerAfterQueue);

            if (needsRecipient && string.IsNullOrWhiteSpace(request.To) && !request.ProcessEmailRepoId.HasValue)
            {
                report.Steps.Add(new EmailDiagnosticStepDto
                {
                    Step = "validate",
                    Success = false,
                    Error = "To is required unless ProcessEmailRepoId is set."
                });
                report.OverallSuccess = false;
                return report;
            }

            EmailConfigSnapshot? config = null;

            if (stepNames.Contains("config") || stepNames.Contains("exchange") || stepNames.Contains("queue") || stepNames.Contains("worker"))
            {
                config = await RunConfigStepAsync(report, cancellationToken);
                if (config == null && (stepNames.Contains("exchange") || stepNames.Contains("worker")))
                {
                    report.OverallSuccess = false;
                    return report;
                }
            }

            if (stepNames.Contains("exchange") && config != null)
            {
                await RunExchangeStepAsync(report, config, request, cancellationToken);
            }

            if (stepNames.Contains("queue") && !string.IsNullOrWhiteSpace(request.To))
            {
                await RunQueueStepAsync(report, request, cancellationToken);
            }

            if (stepNames.Contains("worker"))
            {
                if (schedulerEnabled == false)
                {
                    report.Steps.Add(new EmailDiagnosticStepDto
                    {
                        Step = "worker",
                        Success = false,
                        Error = "PeriodicHostedService.IsEnabled is false. Call GET /StartSS or wait for the scheduler."
                    });
                }
                else
                {
                    await RunWorkerStepAsync(report, request, cancellationToken);
                }
            }

            report.OverallSuccess = report.Steps.Count > 0 && report.Steps.All(s => s.Success);
            return report;
        }

        private static HashSet<string> ResolveSteps(EmailDiagnosticRequestDto request)
        {
            var raw = string.IsNullOrWhiteSpace(request.Steps)
                ? "config,exchange,queue"
                : request.Steps.Trim();

            if (raw.Equals("all", StringComparison.OrdinalIgnoreCase))
                return new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "config", "exchange", "queue", "worker" };

            var set = raw.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            if (request.RunWorkerAfterQueue)
                set.Add("worker");

            return set;
        }

        private async Task<EmailConfigSnapshot?> RunConfigStepAsync(
            EmailDiagnosticReportDto report,
            CancellationToken cancellationToken)
        {
            try
            {
                var configurationDTO = await _unitOfWork.Configuration.GetConfigurationByType("email");
                if (configurationDTO == null || configurationDTO.Count == 0)
                {
                    report.Steps.Add(new EmailDiagnosticStepDto
                    {
                        Step = "config",
                        Success = false,
                        Error = "No CONFIGURATION rows with CATEGORY=Email."
                    });
                    return null;
                }

                var mailFromEnc = configurationDTO.FirstOrDefault(x => x.key == "Mail_From")?.value;
                var mailPassEnc = configurationDTO.FirstOrDefault(x => x.key == "Mail_Password")?.value;
                var mailAccEnc = configurationDTO.FirstOrDefault(x => x.key == "Mail_Account")?.value;
                var mailGroup = configurationDTO.FirstOrDefault(x => x.key == "Mail_Group")?.value;
                var isEnabledRaw = configurationDTO.FirstOrDefault(x => x.key == "IS_Email_Enable")?.value;

                if (string.IsNullOrWhiteSpace(mailFromEnc) || string.IsNullOrWhiteSpace(mailPassEnc) || string.IsNullOrWhiteSpace(mailAccEnc))
                {
                    report.Steps.Add(new EmailDiagnosticStepDto
                    {
                        Step = "config",
                        Success = false,
                        Error = "Missing Mail_From, Mail_Password, or Mail_Account in CONFIGURATION."
                    });
                    return null;
                }

                var mailFrom = CryptoExtensions.Decrypt(mailFromEnc);
                var mailPass = CryptoExtensions.Decrypt(mailPassEnc);
                var mailAcc = CryptoExtensions.Decrypt(mailAccEnc);
                var mailDomain = ResolvePlainOrEncryptedConfig(mailGroup, "Mail_Group");
                var isEmailEnabled = isEnabledRaw?.ToLower() == "true";

                report.Steps.Add(new EmailDiagnosticStepDto
                {
                    Step = "config",
                    Success = true,
                    Detail =
                        $"IS_Email_Enable={isEnabledRaw} (parsed={isEmailEnabled}); " +
                        $"Mail_From={MaskEmail(mailFrom)}; Mail_Account={MaskEmail(mailAcc)}; Mail_Group={mailDomain}; " +
                        $"ConfigRowCount={configurationDTO.Count}."
                });

                if (!isEmailEnabled)
                {
                    report.Steps.Add(new EmailDiagnosticStepDto
                    {
                        Step = "config_warning",
                        Success = false,
                        Error = "IS_Email_Enable is not true — EmailService will skip sending and reset queued rows to N."
                    });
                }

                return new EmailConfigSnapshot(mailFrom, mailPass, mailAcc, mailDomain, isEmailEnabled);
            }
            catch (Exception ex)
            {
                report.Steps.Add(new EmailDiagnosticStepDto
                {
                    Step = "config",
                    Success = false,
                    Error = ExtensionMethods.GetExceptionMessage(ex)
                });
                _logger.LogError(ex, "Email diagnostic config step failed.");
                return null;
            }
        }

        private async Task RunExchangeStepAsync(
            EmailDiagnosticReportDto report,
            EmailConfigSnapshot config,
            EmailDiagnosticRequestDto request,
            CancellationToken cancellationToken)
        {
            try
            {
                var exchange = new ExchangeService(ExchangeVersion.Exchange2013_SP1);
                exchange.Credentials = new WebCredentials(config.MailAccount, config.MailPassword, config.MailDomain);
                exchange.TraceEnabled = true;
                ExchangeServiceSetup.SetEndpoint(exchange, _configuration, config.MailFrom);

                var subject = string.IsNullOrWhiteSpace(request.Subject)
                    ? $"TIP email diagnostic (Exchange) {DateTime.Now:yyyy-MM-dd HH:mm:ss}"
                    : request.Subject;
                var body = string.IsNullOrWhiteSpace(request.Body)
                    ? "<p>TIP diagnostic test — direct Exchange send (no EMAIL_REPO).</p>"
                    : request.Body;

                var emailMessage = new EmailMessage(exchange);
                emailMessage.Subject = subject;
                emailMessage.Body = new MessageBody(BodyType.HTML, WrapDiagnosticHtml(body));

                foreach (var to in SplitAddresses(request.To))
                    emailMessage.ToRecipients.Add(to);

                if (!string.IsNullOrWhiteSpace(request.Cc))
                {
                    foreach (var cc in SplitAddresses(request.Cc))
                        emailMessage.CcRecipients.Add(cc);
                }

                emailMessage.SendAndSaveCopy();

                report.Steps.Add(new EmailDiagnosticStepDto
                {
                    Step = "exchange",
                    Success = true,
                    Detail = $"Sent via EWS to {request.To.Trim()} (subject: {subject})."
                });
            }
            catch (Exception ex)
            {
                report.Steps.Add(new EmailDiagnosticStepDto
                {
                    Step = "exchange",
                    Success = false,
                    Error = ExtensionMethods.GetExceptionMessage(ex)
                });
                _logger.LogError(ex, "Email diagnostic exchange step failed.");
            }
        }

        private async Task RunQueueStepAsync(
            EmailDiagnosticReportDto report,
            EmailDiagnosticRequestDto request,
            CancellationToken cancellationToken)
        {
            try
            {
                var subject = string.IsNullOrWhiteSpace(request.Subject)
                    ? $"TIP email diagnostic (queue) {DateTime.Now:yyyy-MM-dd HH:mm:ss}"
                    : request.Subject;
                var body = string.IsNullOrWhiteSpace(request.Body)
                    ? "TIP diagnostic test — queued to EMAIL_REPO (processed by EmailService worker)."
                    : request.Body;

                var emailRepo = new EmailRepo
                {
                    MailSubject = subject,
                    MailBody = body,
                    ToRecipients = request.To.Trim(),
                    CcRecipients = string.IsNullOrWhiteSpace(request.Cc) ? null : request.Cc.Trim(),
                    LoggedDate = DateTime.Now,
                    EmailedDate = null,
                    EmailedYn = "N",
                    ModuleId = 0,
                    TemplateId = 0,
                    TryCount = null,
                    Error = null,
                    Attachment = null,
                    AttachmentName = null
                };

                await _unitOfWork.EmailRepo.AddAsync(emailRepo);
                await _unitOfWork.SaveAsync();

                report.EmailRepoId = emailRepo.Id;
                report.Steps.Add(new EmailDiagnosticStepDto
                {
                    Step = "queue",
                    Success = true,
                    Detail = $"Inserted EMAIL_REPO id={emailRepo.Id}, EMAILED_YN=N. Worker picks N/E rows (not S or stuck I)."
                });
            }
            catch (Exception ex)
            {
                report.Steps.Add(new EmailDiagnosticStepDto
                {
                    Step = "queue",
                    Success = false,
                    Error = ExtensionMethods.GetExceptionMessage(ex)
                });
                _logger.LogError(ex, "Email diagnostic queue step failed.");
            }
        }

        private async Task RunWorkerStepAsync(
            EmailDiagnosticReportDto report,
            EmailDiagnosticRequestDto request,
            CancellationToken cancellationToken)
        {
            try
            {
                if (request.ProcessEmailRepoId.HasValue)
                {
                    var row = await _unitOfWork.EmailRepo.GetFirstOrDefaultAsync(x => x.Id == request.ProcessEmailRepoId.Value);
                    if (row == null)
                    {
                        report.Steps.Add(new EmailDiagnosticStepDto
                        {
                            Step = "worker",
                            Success = false,
                            Error = $"EMAIL_REPO id={request.ProcessEmailRepoId} not found."
                        });
                        return;
                    }

                    report.Steps.Add(new EmailDiagnosticStepDto
                    {
                        Step = "worker_preflight",
                        Success = true,
                        Detail = $"Target row id={row.Id}, EMAILED_YN={row.EmailedYn}, ERROR={row.Error ?? "(null)"}."
                    });

                    if (row.EmailedYn != "N" && row.EmailedYn != "E")
                    {
                        report.Steps.Add(new EmailDiagnosticStepDto
                        {
                            Step = "worker",
                            Success = false,
                            Error = $"Row is not pending (N/E). Current EMAILED_YN={row.EmailedYn}. Reset to N to retry."
                        });
                        return;
                    }
                }

                await _emailService.ExecuteAsync();

                if (report.EmailRepoId.HasValue || request.ProcessEmailRepoId.HasValue)
                {
                    var id = request.ProcessEmailRepoId ?? report.EmailRepoId!.Value;
                    var after = await _unitOfWork.EmailRepo.GetFirstOrDefaultAsync(x => x.Id == id);
                    if (after == null)
                    {
                        report.Steps.Add(new EmailDiagnosticStepDto
                        {
                            Step = "worker",
                            Success = false,
                            Error = "Worker ran but row disappeared."
                        });
                        return;
                    }

                    var sent = after.EmailedYn == "Y";
                    report.Steps.Add(new EmailDiagnosticStepDto
                    {
                        Step = "worker",
                        Success = sent,
                        Detail = sent
                            ? $"EMAIL_REPO id={id} is Y (sent at {after.EmailedDate})."
                            : $"EMAIL_REPO id={id} after worker: EMAILED_YN={after.EmailedYn}, ERROR={after.Error ?? "(null)"}, TRY_COUNT={after.TryCount}.",
                        Error = sent ? null : after.Error
                    });
                }
                else
                {
                    report.Steps.Add(new EmailDiagnosticStepDto
                    {
                        Step = "worker",
                        Success = true,
                        Detail = "EmailService.ExecuteAsync completed (processed up to 100 pending N/E rows)."
                    });
                }
            }
            catch (Exception ex)
            {
                report.Steps.Add(new EmailDiagnosticStepDto
                {
                    Step = "worker",
                    Success = false,
                    Error = ExtensionMethods.GetExceptionMessage(ex)
                });
                _logger.LogError(ex, "Email diagnostic worker step failed.");
            }
        }

        private static IEnumerable<string> SplitAddresses(string addresses)
        {
            return addresses.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        }

        private static string WrapDiagnosticHtml(string innerHtmlOrText)
        {
            if (innerHtmlOrText.Contains("<html", StringComparison.OrdinalIgnoreCase))
                return innerHtmlOrText;

            return $@"<!DOCTYPE html><html><body style=""font-family:Arial,sans-serif"">{innerHtmlOrText}</body></html>";
        }

        private static string MaskEmail(string? value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return "(empty)";
            var at = value.IndexOf('@');
            if (at <= 1)
                return "***";
            return value[..2] + "***" + value[at..];
        }

        private static string ResolvePlainOrEncryptedConfig(string? value, string configKey)
        {
            if (string.IsNullOrWhiteSpace(value))
                return string.Empty;

            if (value.StartsWith("0C000000", StringComparison.OrdinalIgnoreCase))
            {
                try
                {
                    return CryptoExtensions.Decrypt(value);
                }
                catch
                {
                    return $"(decrypt failed for {configKey})";
                }
            }

            return value;
        }

        private sealed record EmailConfigSnapshot(
            string MailFrom,
            string MailPassword,
            string MailAccount,
            string MailDomain,
            bool IsEmailEnabled);
    }
}
