﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_BAL.Interface;
using TIP_BusinessLogic.Interface;
using TIP_CORE.Entities;
using TIP_DAL.Interface;
using TIP_CORE.EntitiesDTO;
using static TIP_Common.Enum.Enum;
using Microsoft.EntityFrameworkCore;

namespace TIP_BAL.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IUnitOfWork _unitOfWork;

        public EmployeeService(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;

        }

        public Task<EmployeeDTO> getByMuNumber(string MuNumber)
        {
            return _unitOfWork.Employee.GetByMuNumber(MuNumber);
        }

        public async Task<long> AddEmployee(TmEmployee DTO)
        {
            try
            {
                await _unitOfWork.Employee.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<long> UpdateEmployee(TmEmployee DTO)
        {
            try
            {
                _unitOfWork.Employee.Update(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeleteEmployee(string COMPANY_NUMBER)
        {
            try
            {
                TmEmployee obj = null;
                obj = await _unitOfWork.Employee.GetFirstOrDefaultAsync(t => t.CompanyNumber == COMPANY_NUMBER);
                if (obj != null)
                {
                    _unitOfWork.Employee.Remove(obj);
                    int result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<List<SubthemeCfdhLnkDTO>> GetCFDH(long subThemeId)
        {
            return _unitOfWork.Employee.GetCFDH(subThemeId);
        }

       public Task<List<EmployeeDL?>> GetEmployeeByRoleId(long roleId)
        {
            return _unitOfWork.Employee.GetEmployeeByRoleId(roleId);
        }

        #region Ctr Approvals

        public async Task<long> AddUserRoles(List<TmRoleToUserMapping> obj)
        {
            try
            {
                List<TmRoleToUserMapping> newList = new List<TmRoleToUserMapping>();
               

                foreach (TmRoleToUserMapping role in obj)
                {
                   var userRole =  await _unitOfWork.RoleToUser.GetFirstOrDefaultAsync(x=>x.RoleId.Equals(role.RoleId) && x.UserId.Equals(role.UserId));
                    if (userRole!=null)
                    {
                            userRole.IsActive = 1;
                            userRole.ModifiedBy = role.CreatedBy;
                            userRole.ModifiedOn = DateTime.Now;
                            _unitOfWork.RoleToUser.Update(userRole);
                    }
                    else
                    {
                        newList.Add(role);
                    }

                }
                if (newList.Any())
                {
                    await _unitOfWork.RoleToUser.AddRangeAsync(newList);
                }

                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<TmUserRole> GetRoleId(string RoleCode)
        {
            return _unitOfWork.UserRole.GetFirstOrDefaultAsync(x => x.Param.Equals(RoleCode));
        } 
        public Task<TmUserRole> GetRoleId(long RoleID)
        {
            return _unitOfWork.UserRole.GetFirstOrDefaultAsync(x => x.RoleId.Equals(RoleID));
        }

        #endregion

        public async Task<Boolean> CheckIfUserHasRole(string CompanyNumber,long RoleId)
        {
           TmRoleToUserMapping userRole = await _unitOfWork.RoleToUser.GetFirstOrDefaultAsync(x=>x.UserId== CompanyNumber && x.RoleId == RoleId);
            if(userRole!=null)
                return true;
            else
                return false;
        }

        public async Task<Boolean> CheckIfUserHasRoleByR_C(string CompanyNumber, string RoleCode)
        {
            long RoleId=0;
            try {
                var result = _unitOfWork.UserRole.GetFirstOrDefaultAsync(x => x.Param == RoleCode).Result;
                if(result!=null)
                RoleId = result.RoleId; }

            catch { return false; }
            TmRoleToUserMapping userRole = await _unitOfWork.RoleToUser.GetFirstOrDefaultAsync(x => x.UserId == CompanyNumber && x.RoleId == RoleId);
            if (userRole != null)
                return true;
            else
                return false;
        }
    }
}
