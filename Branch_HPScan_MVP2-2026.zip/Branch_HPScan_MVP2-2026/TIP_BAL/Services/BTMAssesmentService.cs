﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Transactions;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Configuration;
using TIP_BAL.Interface;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_Core;
using TIP_CORE;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Services
{
    public class BTMAssesmentService : IBTMAssesmentService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICommonService _commonService;
        private readonly IConfiguration _configuration;

        public BTMAssesmentService(IUnitOfWork unitOfWork, ICommonService commonService, IConfiguration configuration)
        {
            this._unitOfWork = unitOfWork;
            _commonService = commonService;
            _configuration = configuration;
        }

        public async Task<List<BTMAssessmentDTO>> GetBTMAssessments(EmployeeDTO MU)
        {
            return await _unitOfWork.BTMAssesment.GetBTMAssessments(MU);
        }

        public async Task<long> AddBTM(BtmAssessment DTO)
        {
            try
            {
                DTO.Id = 0;
                if (DTO.ClusterId.HasValue && DTO.ClusterId.Value <= 0)
                    DTO.ClusterId = null;
                if (DTO.IsActive == null)
                    DTO.IsActive = true;
                await _unitOfWork.BTMAssesment.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                return result > 0 ? DTO.Id : result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeleteBTM(long ID,EmployeeDTO employee)
        {
            try
            {
                BtmAssessment? obj = null;
                obj = await _unitOfWork.BTMAssesment.GetFirstOrDefaultAsync(x => x.Id == ID);
                var audittrailObj = new UtlAuditTrail()
                    {TableName="BTM_ASSESSMENT" ,Action="DELETE",ActionBy=employee.DISPLAY_NAME+" "+employee.COMPANY_NUMBER,
                    ActionOn=System.DateTime.Today.ToString("dd/MM/yyyy"),
                    Description= JsonSerializer.Serialize(obj),
                };
                if (obj != null)
                {
                    
                    _unitOfWork.BTMAssesment.Remove(obj);
                    
                }
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateBTM(BtmAssessment DTO)
        {
            try
            {
                BtmAssessment? obj = null;
                obj = await _unitOfWork.BTMAssesment.GetFirstOrDefaultAsync(x => x.Id == DTO.Id);
                if (obj != null)
                {
                    obj.AssetId = DTO.AssetId;
                    obj.ClusterId = DTO.ClusterId;
                    obj.DepartmentId = DTO.DepartmentId;
                    obj.Year = DTO.Year;
                    obj.WorkshopDate = DTO.WorkshopDate;
                    obj.StatusId = DTO.StatusId;
                    obj.UpdatedBy = DTO.UpdatedBy;
                    obj.UpdatedByRef = DTO.UpdatedByRef;
                    obj.UpdatedOn = DTO.UpdatedOn;
                    _unitOfWork.BTMAssesment.Update(obj);
                }
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region Map BTM Email ~ Fazal, Rahim IDAP1X
        public async Task<bool> MapBTMForEmail(EmailSendConfigDTO emailSendConfigDTO, long id,EmployeeDTO employee)
        {
            BTMAssessmentKeywordDTO obj = null;
            obj = await _unitOfWork.BTMAssesment.GetBTMAssessmentById(id);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Year", obj.year.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Asset", obj.asset.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Cluster", obj.cluster.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Department", obj.department.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$WorkshopDate", obj.workshopDate.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionStatus", obj.actionStatus.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionBy", obj.actionBy.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionCompletionDate", obj.actionDate.ToString());

          

            string host = _configuration["TIPApplicationPath"];


            if (emailSendConfigDTO.templateCode.Equals("A001"))
            {
                string link = host + "/#/bti/rank-pain-areas";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view created Assessment's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            else if (emailSendConfigDTO.templateCode.Equals("A002"))
            {
                string link = host + "/#/bti/manage-assessment";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view submitted Assessment's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            return await _commonService.SendEmail(emailSendConfigDTO,employee);
        }
        #endregion
    }
}
