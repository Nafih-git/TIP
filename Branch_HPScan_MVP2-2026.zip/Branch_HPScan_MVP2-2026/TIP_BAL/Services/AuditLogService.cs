using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using TIP_BAL.Interface;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_Common.Helpers;

namespace TIP_BAL.Services
{
    public interface IAuditLogService
    {
        Task<AuditLogReportResponseDto> GetAuditLogsAsync(AuditLogSearchRequestDto request);
        Task<AuditLogDto> GetAuditLogByIdAsync(decimal auditId);
        Task<decimal> AuditAsync(AuditLogWriteRequestDto request, EmployeeDTO? loggedInUser = null);
        /// <summary>Writes an audit row without throwing — safe for middleware/auto-capture.</summary>
        Task TryAuditAsync(AuditLogWriteRequestDto request, EmployeeDTO? loggedInUser = null);
        Task<AuditLogClearResultDto> ClearAuditLogsAsync(AuditLogClearRequestDto request, EmployeeDTO? loggedInUser = null);
    }

    public class AuditLogService : IAuditLogService
    {
        private const int MaxTextLength = 4000;
        private const int MaxJsonLength = 32000;

        private readonly IUnitOfWork _unitOfWork;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger<AuditLogService> _logger;

        private static readonly string[] SensitivePatterns =
        {
            "password", "pwd", "clientsecret", "client_secret", "access_token", "accesstoken",
            "refresh_token", "refreshtoken", "authorization", "bearer", "apikey", "api_key",
            "xapikey", "x-api-key", "secret", "token", "otp", "pin", "cvv", "cardnumber",
            "card_number", "ssn"
        };

        public AuditLogService(
            IUnitOfWork unitOfWork,
            IHttpContextAccessor httpContextAccessor,
            ILogger<AuditLogService> logger)
        {
            _unitOfWork = unitOfWork;
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
        }

        public Task<AuditLogReportResponseDto> GetAuditLogsAsync(AuditLogSearchRequestDto request)
        {
            return _unitOfWork.TrAuditLog.GetAuditLogsAsync(request, includeJsonFields: false);
        }

        public Task<AuditLogDto> GetAuditLogByIdAsync(decimal auditId)
        {
            return _unitOfWork.TrAuditLog.GetAuditLogByIdAsync(auditId);
        }

        public async Task TryAuditAsync(AuditLogWriteRequestDto request, EmployeeDTO? loggedInUser = null)
        {
            try
            {
                await AuditAsync(request, loggedInUser);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Audit logging failed (non-blocking) for module {Module} action {Action}",
                    request?.moduleName, request?.actionType);
            }
        }

        public async Task<decimal> AuditAsync(AuditLogWriteRequestDto request, EmployeeDTO? loggedInUser = null)
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));

            var httpContext = _httpContextAccessor.HttpContext;
            var user = loggedInUser;

            var entity = new TrAuditLog
            {
                MODULE_NAME = Truncate(string.IsNullOrWhiteSpace(request.moduleName) ? "UNKNOWN" : request.moduleName.Trim(), 100),
                ACTION_TYPE = Truncate(string.IsNullOrWhiteSpace(request.actionType) ? "UNKNOWN" : request.actionType.Trim(), 50),
                ENTITY_TYPE = Truncate(string.IsNullOrWhiteSpace(request.entityType) ? "UNKNOWN" : request.entityType.Trim(), 100),
                ENTITY_ID = Truncate(request.entityId, 100),
                ENTITY_NAME = Truncate(request.entityName, 500),
                FIELD_NAME = Truncate(request.fieldName, 200),
                OLD_VALUE = Truncate(SanitizePlain(request.oldValue), MaxTextLength),
                NEW_VALUE = Truncate(SanitizePlain(request.newValue), MaxTextLength),
                SUMMARY = Truncate(request.summary, MaxTextLength),
                COMMENTS = Truncate(request.comments, MaxTextLength),
                USER_ID = Truncate(
                    request.userId
                    ?? user?.COMPANY_NUMBER
                    ?? httpContext?.User?.Identity?.Name
                    ?? "SYSTEM", 100)!,
                USER_DISPLAY_NAME = Truncate(
                    request.userDisplayName
                    ?? user?.DISPLAY_NAME
                    ?? user?.EMPLOYEE_NAME
                    ?? httpContext?.User?.Identity?.Name, 200),
                ROLE_ID = request.roleId ?? (user?.ACTIVE_R_ID.HasValue == true ? (decimal?)user.ACTIVE_R_ID.Value : null),
                ROLE_NAME = Truncate(request.roleName, 200),
                IP_ADDRESS = Truncate(
                    request.ipAddress
                    ?? (httpContext != null ? AccountHelper.GetWinAuthIPForLogs(httpContext) : null), 100),
                CORRELATION_ID = Truncate(request.correlationId ?? httpContext?.TraceIdentifier, 100),
                HTTP_METHOD = Truncate(request.httpMethod ?? httpContext?.Request?.Method, 20),
                REQUEST_PATH = Truncate(request.requestPath ?? httpContext?.Request?.Path.Value, 1000),
                AUDIT_DATE = DateTime.Now,
                OLD_JSON = Truncate(SanitizeJson(request.oldJson), MaxJsonLength),
                NEW_JSON = Truncate(SanitizeJson(request.newJson), MaxJsonLength),
                REQUEST_JSON = Truncate(SanitizeJson(request.requestJson), MaxJsonLength),
                RESPONSE_JSON = Truncate(SanitizeJson(request.responseJson), MaxJsonLength),
            };

            await _unitOfWork.TrAuditLog.AddAsync(entity);
            await _unitOfWork.SaveAsync();
            return entity.AUDIT_ID;
        }

        public async Task<AuditLogClearResultDto> ClearAuditLogsAsync(AuditLogClearRequestDto request, EmployeeDTO? loggedInUser = null)
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));

            if (!request.fromDate.HasValue && !request.toDate.HasValue)
                throw new InvalidOperationException("From Date or To Date is required to clear audit logs.");

            var deletedCount = await _unitOfWork.TrAuditLog.ClearAuditLogsAsync(request);

            var rangeText = $"{(request.fromDate?.ToString("dd-MMM-yyyy") ?? "any")} to {(request.toDate?.ToString("dd-MMM-yyyy") ?? "any")}";
            var filterParts = $"module={request.moduleName ?? "*"}; action={request.actionType ?? "*"}; entity={request.entityType ?? "*"}; user={request.userId ?? "*"}";

            var retainedId = await AuditAsync(new AuditLogWriteRequestDto
            {
                moduleName = "REPORTING",
                actionType = "CLEAR",
                entityType = "AUDIT_LOG",
                entityName = "TR_AUDIT_LOG",
                summary = $"Cleared {deletedCount} audit log row(s) for date range {rangeText}.",
                comments = string.IsNullOrWhiteSpace(request.comments)
                    ? $"Filters: {filterParts}"
                    : request.comments.Trim(),
                oldValue = deletedCount.ToString(),
                newValue = "0",
                requestJson = $"{{\"fromDate\":\"{request.fromDate}\",\"toDate\":\"{request.toDate}\",\"moduleName\":\"{request.moduleName}\",\"deletedCount\":{deletedCount}}}"
            }, loggedInUser);

            return new AuditLogClearResultDto
            {
                deletedCount = deletedCount,
                retainedClearAuditId = retainedId
            };
        }

        internal static string? SanitizeJson(string? json)
        {
            if (string.IsNullOrWhiteSpace(json)) return json;

            var sanitized = json;
            foreach (var pattern in SensitivePatterns)
            {
                sanitized = Regex.Replace(
                    sanitized,
                    $@"(""{pattern}""\s*:\s*"")([^""]*)("")",
                    $"$1***MASKED***$3",
                    RegexOptions.IgnoreCase);
                sanitized = Regex.Replace(
                    sanitized,
                    $@"(""{pattern}""\s*:\s*)([^,\}}\]]+)",
                    $"$1\"***MASKED***\"",
                    RegexOptions.IgnoreCase);
            }
            return sanitized;
        }

        private static string? SanitizePlain(string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return value;
            return SanitizeJson(value);
        }

        private static string? Truncate(string? value, int maxLength)
        {
            if (string.IsNullOrEmpty(value) || value.Length <= maxLength)
                return value;
            return value.Substring(0, maxLength - 3) + "...";
        }
    }
}
