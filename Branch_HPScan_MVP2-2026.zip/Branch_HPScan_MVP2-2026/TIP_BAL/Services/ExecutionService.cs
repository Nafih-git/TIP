using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Reporting.NETCore;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface;
using TIP_BusinessLogic.Interface;
using TIP_Common.Admin;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using static TIP_Common.Enum.Enum;

namespace TIP_BAL.Services
{
    public class ExecutionService : IExecutionService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICommonService _commonService;
        private readonly IConfiguration _configuration;
        public ExecutionService(IUnitOfWork unitOfWork, ICommonService commonService, IConfiguration configuration)
        {
            this._unitOfWork = unitOfWork;
            _commonService = commonService;
            _configuration = configuration;
        }
        public async Task<List<ApprovedCtrForExecDTO>> GetApprovedCtr(string CompanyNumber)
        {
            return await _unitOfWork.Ctr.GetApprovedCtrForExec(CompanyNumber);
        }
        public async Task<List<ExecutionTrialfpsDTO>> GetTrialFPForExec(long ctrid)
        {
            return await _unitOfWork.execution.GetTrialFPForExec(ctrid);
        }
        public async Task<ExecutionTrialfpsDTO> GetTrialFPForExecbyId(long exeId) 
        {
            return await _unitOfWork.execution.GetTrialFPForExecbyId(exeId);

        }
        public async Task<List<ExecutionPlannedTimelinesDTO>> GetConfig_MilestoneBYExecId(long execId, bool IsCreated, long roleid)
        {
            return await _unitOfWork.execution.GetConfig_MilestoneBYExecId(execId, IsCreated, roleid);
        }
        public async Task<List<InitiatedTrialForExecDTO>> GetinitiatedTrialForExecution(string companyNumber)
        {
            return await _unitOfWork.execution.GetinitiatedTrialForExecution(companyNumber);
        }
        public async Task<List<TypeCodeMasterDetailDTO>> GetStagesDataByexec(long exec)
        {
            return await _unitOfWork.execution.GetStagesDataByexec(exec);
        }

        public async Task<List<TypeCodeMasterDTO>> GetSortStagesByexec(long execId)
        {
            return await _unitOfWork.execution.GetSortStagesByexec(execId);
        }
        public async Task<List<TypeCodeMasterDTO>> GetSortActivity(long execId)
        {
            return await _unitOfWork.execution.GetSortActivity(execId);
        }

        public async Task<long> updateIsMandatory(long trialFPSId, bool IsMandatory)
        {
            try
            {
                long result = 0;


                if (IsMandatory)
                {
                    //IsMandatory = 1;
                    ExecutionTrialFp existingMandatory = await _unitOfWork.executionTrialFp.GetFirstOrDefaultAsync(x => x.Id != trialFPSId
                    && x.IsMandatory == IsMandatory);
                    if (existingMandatory != null)
                    {
                        existingMandatory.IsMandatory = false;
                        _unitOfWork.executionTrialFp.Update(existingMandatory);
                        await _unitOfWork.SaveAsync();
                    }

                    ExecutionTrialFp currenMandatory = await _unitOfWork.executionTrialFp.GetFirstOrDefaultAsync(x => x.Id == trialFPSId);
                    currenMandatory.IsMandatory = true;
                    _unitOfWork.executionTrialFp.Update(currenMandatory);
                    result = await _unitOfWork.SaveAsync();
                }
                else
                {
                    //IsMandatory = 0;
                    ExecutionTrialFp existingMandatory = await _unitOfWork.executionTrialFp.GetFirstOrDefaultAsync(x => x.Id == trialFPSId
                    );
                    existingMandatory.IsMandatory = false;
                    _unitOfWork.executionTrialFp.Update(existingMandatory);
                    result = await _unitOfWork.SaveAsync();
                }

                //riyan
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //
        public async Task<long> addExecutionTrialFp(ExecutionTrialFp DTO)
        {
            try
            {
                long result = 0;
                if (DTO.IsMandatory == true)
                {
                    ExecutionTrialFp obj = await _unitOfWork.executionTrialFp.GetFirstOrDefaultAsync(x => x.ExecutionId == DTO.ExecutionId && x.IsMandatory == DTO.IsMandatory);
                    if (obj != null)
                    {
                        obj.IsMandatory = false;
                        _unitOfWork.executionTrialFp.Update(obj);
                        result = await _unitOfWork.SaveAsync();
                    }

                }
                await _unitOfWork.executionTrialFp.AddAsync(DTO);
                result = await _unitOfWork.SaveAsync();

                //riyan
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> addExecutionplanned(ExecutionPlannedDTO DTO)
        {
            try
            {
                ExecutionPlanned dbObj = await _unitOfWork.executionplanned.GetFirstOrDefaultAsync(x => x.Id == DTO.id);
               
                if (dbObj != null)
                {

                   
                    dbObj.ExeId = DTO.exe_ID;
                    _unitOfWork.executionplanned.Update(dbObj);
                    long result = await _unitOfWork.SaveAsync();


                    return result;
                }
                else
                {
                    
                    dbObj.ExeId = DTO.exe_ID;
                    _unitOfWork.executionplanned.AddAsync(dbObj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }


                //riyan
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public async Task<ExecutionPlanned> GetexecutionPlanById(long Id)
        {
            return await _unitOfWork.executionplanned.GetFirstOrDefaultAsync(x => x.ExeId == Id);
        }

        public async Task<long> UpdateexecutionPlan(ExecutionPlanned DTO)
        {
            try
            {
                _unitOfWork.executionplanned.Update(DTO);
                long result = await _unitOfWork.SaveAsync();

                
                if (result > 0)
                {
                    return (long)DTO.Id;// or Id if table id exist
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ExecutionPlannedDTO> GetExecutionPlannedById(long Id, long roleid, string CompanyNumber, bool Is_Created)
        {
            return await _unitOfWork.execution.GetExecutionPlannedById(Id, roleid, CompanyNumber, Is_Created);
        }
        public async Task<List<ApprovedExecutionPlannedDTO>> GetActualPlanGrid(string CompanyNumber)
        {
            return await _unitOfWork.execution.GetActualPlanGrid(CompanyNumber);
        }
        //GetActualPlanGrid
        public async Task<List<ExecutionActualPlannedTimelineDTO>> GetActualPlannedTimeline(bool is_created, long execId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.execution.GetActualPlannedTimeline(is_created, execId, roleid,CompanyNumber);
        }

        public async Task<List<TypeCodeMasterDTO>> GetOverallProgress()
        {
            return await _unitOfWork.execution.GetOverallProgress();
        }

        //GetOverallProgress

        public async Task<long> DeleteExecutionPlannedTimeline(long Id, EmployeeDTO employee)
        {
            try
            {
                ExecutionPlannedTimeline? obj = null;
                obj = await _unitOfWork.executionplannedTimeline.GetFirstOrDefaultAsync(x => x.Id == Id);
                var audittrailObj = new UtlAuditTrail()
                {
                    TableName = "executionplannedTimeline",
                    Action = "DELETE",
                    ActionBy = employee.DISPLAY_NAME + " " + employee.COMPANY_NUMBER,
                    ActionOn = DateTime.Now.ToString("dd/MM/yyyy"),
                    Description = JsonSerializer.Serialize(obj),
                };
                if (obj != null)
                {
                    _unitOfWork.executionplannedTimeline.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    await _commonService.Log(audittrailObj);
                    return result > 0 ? result : 1;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeleteExTrialFPs(long Id, EmployeeDTO employee)
        {
            try
            {
                ExecutionTrialFp? obj = null;
                obj = await _unitOfWork.executionTrialFp.GetFirstOrDefaultAsync(x => x.Id == Id);
                var audittrailObj = new UtlAuditTrail()
                {
                    TableName = "DeleteExTrialFPs",
                    Action = "DELETE",
                    ActionBy = employee.DISPLAY_NAME + " " + employee.COMPANY_NUMBER,
                    ActionOn = DateTime.Now.ToString("dd/MM/yyyy"),
                    Description = JsonSerializer.Serialize(obj),
                };
                if (obj != null)
                {
                    _unitOfWork.executionTrialFp.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    await _commonService.Log(audittrailObj);
                    return result > 0 ? result : 1;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



       



        #region Assessment of Trial Candidates for execution
        public async Task<List<ExecutionTrialCandidateDTO>> GetAllTrialCandidates(long execId)
        {
            return await _unitOfWork.executionTrialcandidate.GetAllTrialCandidates(execId);
        }

        public async Task<long> AddTrialCandidates(ExecutionTrialCandidate execTrialCandidate)
        {
            try
            {
                await _unitOfWork.executionTrialcandidate.AddAsync(execTrialCandidate);
                long result = await _unitOfWork.SaveAsync();

                if (result > 0)
                {
                    return execTrialCandidate.Id;
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public async Task<long> UpdateExPotentialValue(ExecutionPotentialValue obj)
        {
            try
            {
                if (obj != null)
                {
                    _unitOfWork.executionPotentialValue.Update(obj);
                    long result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return obj.Id;
                    }
                    return result;
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        public async Task<long> UpdateTrialCandidates(ExecutionTrialCandidate obj)
        {
            try
            {
                ExecutionTrialCandidate dbObj = await _unitOfWork.executionTrialcandidate.GetFirstOrDefaultAsync(x => x.Id == obj.Id);

                if (dbObj != null)
                {

                    dbObj.TypeId = obj.TypeId;
                    dbObj.Name = obj.Name;
                    dbObj.Cost = obj.Cost;
                    dbObj.CommencementDate = obj.CommencementDate;
                    dbObj.ConclusionDate = obj.ConclusionDate;
                    dbObj.ChallengeDescription = obj.ChallengeDescription;
                    dbObj.Comments = obj.Comments;
                    dbObj.OutcomeId = obj.OutcomeId;
                    dbObj.UpdatedBy = obj.UpdatedBy;
                    dbObj.UpdatedByRef = obj.UpdatedByRef;
                    dbObj.UpdatedOn = obj.UpdatedOn;


                    _unitOfWork.executionTrialcandidate.Update(dbObj);
                    long result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return dbObj.Id;
                    }
                    return result;
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> DeleteTrialCandidates(long id)
        {
            try
            {
                ExecutionTrialCandidate? obj = null;
                obj = await _unitOfWork.executionTrialcandidate.GetFirstOrDefaultAsync(x => x.Id == id);

                if (obj != null)
                {
                    _unitOfWork.executionTrialcandidate.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    if (result > 0)
                    {
                        return result;
                    }
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion







        public async Task<List<ExecutionPotentialValueDTO>> GetAllExecPotentialValue(long ctrid)
        {
            return await _unitOfWork.execution.GetAllExecPotentialValue(ctrid);
        }



        public async Task<List<ExecutionPotentialValueDTO>> GetAllExecPotentialValueById(long poteId)
        {
            return await _unitOfWork.execution.GetAllExecPotentialValue(poteId);
        }


        public async Task<ExecutionIntiationDTO> InitiateExecution(long ctrId, string companyNumber, long roleId, long execId)
        {

            try
            {


                return await _unitOfWork.execution.GetCtrFormDataForExec(ctrId, roleId, companyNumber, execId);


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public async Task<long> addorUpdateinitiate(ExecutionIntiationDTO obj, EmployeeDTO loggedinUser)
        {
            try
            {
                ExecutionInitiation dbObj = await _unitOfWork.execution.GetFirstOrDefaultAsync(x => x.Id == obj.id);
                if (dbObj == null)
                {
                    return 0;
                }

                TypeCodeMasterDTO status = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EXECStatus, obj.statusId);
                if (status == null)
                {
                    return 0;
                }

                dbObj.StatusId = status.id;

                    if (obj.statusId.ToString() == ExecutionStatus.Initiated)
                    {
                        ExecutionTrialFp existingMandatory = await _unitOfWork.executionTrialFp.GetFirstOrDefaultAsync(x => x.ExecutionId == obj.id
                        && x.IsMandatory == true);
                        if (existingMandatory == null)
                        {
                            return 3;
                        }
                        ExecutionPotentialValue existingpot = await _unitOfWork.executionPotentialValue.GetFirstOrDefaultAsync(x => x.ExecId == obj.id);
                        if (existingpot == null)
                        {
                            return 3;
                        }

                    }
                    dbObj.CtrId = obj.ctrId;
                    dbObj.Trialtitle = obj.trialtitle;
                    dbObj.MaturityLevelId = obj.maturityLevelId;
                    dbObj.AreaId = obj.areaId;
                    dbObj.ApplicationId = obj.applicationId;
                    dbObj.ThemeId = obj.themeId;
                    dbObj.ContractNo = obj.contractNo;
                    dbObj.ContractType = obj.contractType;
                    
                    dbObj.UpdatedBy = obj.UpdatedBy;
                    dbObj.UpdatedOn = obj.UpdatedOn;
                    dbObj.AcvValue = obj.AcvValue.ToString();
                    dbObj.Startmonth = obj.startmonth;
                    dbObj.Initiateddate = string.IsNullOrWhiteSpace(obj.initiatemonth)
                        ? null
                        : obj.initiatemonth.ToDateTime();
                    dbObj.Challengetitle = obj.challengetitle;
                    dbObj.AssetId = obj.assetId;
                    dbObj.ClusterId = obj.clusterId;

                    _unitOfWork.execution.Update(dbObj);
                    long result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        if (obj.statusId.ToString() == ExecutionStatus.Initiated)
                            await SendExecutionEmail(dbObj.Id, EmailModules.EXEC, "EXEC001", loggedinUser);
                            
                        return 1;
                    }
                    return 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> addorUpdateExecutionPlannedTimeline(ExecutionPlannedTimeline obj)
        {
            try
            {
                long result = 0;
                
                if (obj != null)
                {
                    ExecutionPlannedTimeline dbObj = await _unitOfWork.execution.Getplantimelinealeardystageexist(obj.Stage.ToLower(),obj.ExecId);

                    if (obj.Id > 0)
                    {

                        if (dbObj == null)
                        {
                            var aaa = await _unitOfWork.execution.Getplantimelinestage( obj.Id, obj.ExecId);
                            for (int i = 0; i < aaa.Count; i++)
                            {
                                aaa[i].Stage = obj.Stage;
                                
                            }
                            aaa.Add(obj);
                            

                           
                            _unitOfWork.executionplannedTimeline.UpdateRange(aaa);
                            result = await _unitOfWork.SaveAsync();
                        }

                       
                            if (result > 0)
                            {
                                return (long)obj.Id;
                            }
                        
                        obj.UpdateOn = DateTime.Now;
                        obj.UpdatedBy = "";
                        obj.Phaseid = dbObj.Phaseid;
                        

                        _unitOfWork.executionplannedTimeline.Update(obj);
                        result = await _unitOfWork.SaveAsync();

                    }
                    else
                    {

                        if (dbObj != null && obj.Type == false) // if record already in Table then you can not create
                        {
                            return 3;
                        }

                        obj.CreatedOn = DateTime.Now;
                        obj.CreatedBy = "";
                        obj.Id = 0;
                        _unitOfWork.executionplannedTimeline.AddAsync(obj);
                        result = await _unitOfWork.SaveAsync();
                        if (result > 0)
                        {
                            return (long)obj.Id;
                        }
                    }

                    //return result;
                }

                return result;
            }
                    catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<PrintDTO> GetContractDataRDLC(long Id, long roleid, string CompanyNumber)
        {
            try
            {
                string contractID = await _unitOfWork.TmRabitahContract.GetContractID(Id);
                List<RabitahContractDTO> contractDTO = new List<RabitahContractDTO>();
                contractDTO.Add(await _unitOfWork.TmRabitahContract.GetContractDataRDLC(contractID));
                Dictionary<string, string> parameters = new Dictionary<string, string>();
                Warning[] warnings;
                string[] streamIds;
                string mimeType = string.Empty;
                string encoding = string.Empty;
                string filetype = string.Empty;
                string fileName = string.Format("{0}.{1}", "Budget Number" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());

                LocalReport localReport = new LocalReport();
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                Encoding.GetEncoding("windows-1252");
                string fileDirPath = Assembly.GetExecutingAssembly().Location.Replace("TIP_BAL.dll", string.Empty);
                string rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "BudgetPrint");

                localReport.ReportPath = rdlcFilePath;
                localReport.DataSources.Add(new ReportDataSource() { Name = "BudgetContractDTO", Value = contractDTO });

                localReport.EnableExternalImages = false;
                localReport.EnableHyperlinks = false;
                localReport.Refresh();

                byte[] bytes = localReport.Render(PrintType.WORD.ToDescription(), null, out mimeType, out encoding, out filetype, out streamIds, out warnings);
                return new PrintDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> SendExecutionEmail(long ExecId, string Module, string TemplateCode, EmployeeDTO loggedInUser, string? Comment = "", string? previousMU = "", long? planid = 0, long? InvId = 0)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {
                    ExecutionEmailDTO ExecObj = await _unitOfWork.execution.ExecutionEmailData(ExecId, TemplateCode, previousMU, planid, InvId);
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.ccRecipients = new List<string>();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    var senderEmail = await _commonService.GetEmailBymuNO(loggedInUser.COMPANY_NUMBER);
                    emailSendConfigDTO.ccRecipients.Add(senderEmail);
                   
                    ExecObj.oldMTFPName = null;
                    ExecObj.oldUctFPName = null;

                    if (TemplateCode.Equals("EXEC001")) // New Execution Created
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ExecObj.MandatoryTP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);
                        foreach (AllPDOUsersDTO Otfp in ExecObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode,employee:loggedInUser);
                    }

                    else if (TemplateCode.Equals("EXEC002")) // to old UCT 
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(previousMU);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);
                        ExecObj.oldUctFPName = ExecObj.oldFpDetails.USER_DISPLAY;

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode, employee: loggedInUser);
                    }

                    else if (TemplateCode.Equals("EXEC003")) // to new UCT 
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ExecObj.UCT_FP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode, employee: loggedInUser);
                    }

                    else if (TemplateCode.Equals("EXEC004")) // to old mfp
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(previousMU);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);
                        ExecObj.oldMTFPName = ExecObj.oldFpDetails.USER_DISPLAY;
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode, employee: loggedInUser);
                    }

                    else if (TemplateCode.Equals("EXEC005")) // to new mfp 
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ExecObj.MandatoryTP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode, employee: loggedInUser);
                    }

                    else if (TemplateCode.Equals("EXEC006") || TemplateCode.Equals("EXEC007")) // execution plan submitted
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ExecObj.UCT_FP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode, employee: loggedInUser);
                    }
                    else if (TemplateCode.Equals("EXEC008") || TemplateCode.Equals("EXEC009")) // execution plan sentback or approved
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ExecObj.MandatoryTP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode, Comment  ,employee: loggedInUser);
                    }
                    else if (TemplateCode.Equals("EXEC010")) // execution actual changes
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ExecObj.UCT_FP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail2 = await _commonService.GetEmailBymuNO(ExecObj.MandatoryTP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail2);

                        foreach (AllPDOUsersDTO Otfp in ExecObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode, Comment, employee: loggedInUser);
                    }
                    else if (TemplateCode.Equals("EXEC011")) //Invoice Requested
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ExecObj.UCT_FP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        if (ExecObj.InvoiceReviewer != null)
                        {
                            emailSendConfigDTO.ccRecipients = new List<string>();
                            var fpEmail2 = await _commonService.GetEmailBymuNO(ExecObj.InvoiceReviewer.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(fpEmail2);
                        }

                        foreach (AllPDOUsersDTO Otfp in ExecObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode, Comment, employee: loggedInUser);
                    }
                    else if (TemplateCode.Equals("EXEC012")) //Invoice Reviewed
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ExecObj.UCT_FP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        if (ExecObj.MandatoryTP != null)
                        {
                            emailSendConfigDTO.ccRecipients = new List<string>();
                            var fpEmail2 = await _commonService.GetEmailBymuNO(ExecObj.MandatoryTP.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(fpEmail2);
                        }
                        foreach (AllPDOUsersDTO Otfp in ExecObj.SapSustainers)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }
                        foreach (AllPDOUsersDTO Otfp in ExecObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }
                        if (ExecObj.InvoiceReviewer != null)
                        {
                            emailSendConfigDTO.ccRecipients = new List<string>();
                            var fpEmail2 = await _commonService.GetEmailBymuNO(ExecObj.InvoiceReviewer.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(fpEmail2);
                        }
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode, Comment, employee: loggedInUser);
                    }
                    else if (TemplateCode.Equals("EXEC013")) //Invoice sentback
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ExecObj.UCT_FP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        if (ExecObj.MandatoryTP != null)
                        {
                            emailSendConfigDTO.ccRecipients = new List<string>();
                            var fpEmail2 = await _commonService.GetEmailBymuNO(ExecObj.MandatoryTP.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(fpEmail2);
                        }

                        foreach (AllPDOUsersDTO Otfp in ExecObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }
                        if (ExecObj.InvoiceReviewer != null)
                        {
                            emailSendConfigDTO.ccRecipients = new List<string>();
                            var fpEmail2 = await _commonService.GetEmailBymuNO(ExecObj.InvoiceReviewer.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(fpEmail2);
                        }
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode, Comment, employee: loggedInUser);
                    }
                    else if (TemplateCode.Equals("EXEC015")) //Invoice completed
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ExecObj.UCT_FP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        if (ExecObj.MandatoryTP != null)
                        {
                            emailSendConfigDTO.ccRecipients = new List<string>();
                            var fpEmail2 = await _commonService.GetEmailBymuNO(ExecObj.MandatoryTP.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(fpEmail2);
                        }

                        foreach (AllPDOUsersDTO Otfp in ExecObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }
                        if (ExecObj.InvoiceReviewer != null)
                        {
                            emailSendConfigDTO.ccRecipients = new List<string>();
                            var fpEmail2 = await _commonService.GetEmailBymuNO(ExecObj.InvoiceReviewer.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(fpEmail2);
                        }
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapExecutionForEmail(res, ExecId, ExecObj, TemplateCode, Comment, employee: loggedInUser);
                    }
                }
            }
            return 0;
        }

        public async Task<List<ExecutionReAssisgnDTO>> GetAllExecutionforReAssignment(long roleId, string CompanyNumber)
        {
            return await _unitOfWork.execution.GetAllExecutionforReAssignment(roleId, CompanyNumber);
        }

        public async Task<ExecutionInitiation> GetExecutionForReAssignment(long Id)
        {
            return await _unitOfWork.execution.GetFirstOrDefaultAsync(x => x.Id == Id);
        }

        public async Task<long> UpdateExecutionForReAssignment(ExecutionInitiation DTO)
        {
            try
            {
                _unitOfWork.execution.Update(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return DTO.Id;
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ExecutionTrialFp> GetExecutionMTFReAssignment(long Id)
        {
            return await _unitOfWork.executionTrialFp.GetFirstOrDefaultAsync(x => x.ExecutionId == Id && x.IsMandatory);
        }

        public async Task<long> UpdateExecutionMTFReAssignment(ExecutionTrialFp DTO)
        {
            try
            {
                _unitOfWork.executionTrialFp.Update(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return DTO.Id;
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> MapExecutionForEmail(EmailSendConfigDTO emailSendConfigDTO, long ExecId, ExecutionEmailDTO ExecObj, string TemplateCode, string Comment = "",EmployeeDTO?employee=null)
        {
            string host = _configuration["TIPApplicationPath"];
            if (!string.IsNullOrEmpty(ExecObj.oldUctFPName))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", ExecObj.oldUctFPName);
            }
            if (!string.IsNullOrEmpty(ExecObj.oldMTFPName))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$MTrailFpName", ExecObj.oldMTFPName);
            }
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$MTrailFpName", ExecObj.MandatoryTP != null ? ExecObj.MandatoryTP.USER_DISPLAY : "");
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ReferenceNo", ExecObj.ReferenceNumber);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", ExecObj.UCT_FP.USER_DISPLAY ?? "");
            var otfp = (ExecObj.OtherTP != null && ExecObj.OtherTP.Count > 0) ? string.Join(" ; ", ExecObj.OtherTP.Select(x => x.USER_DISPLAY)) : "None";
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$OTrialFpNames", (ExecObj.OtherTP != null && ExecObj.OtherTP.Count > 0) ? string.Join(" ; ", ExecObj.OtherTP.Select(x => x.USER_DISPLAY)) : "None");
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$OTrialFPNames", (ExecObj.OtherTP != null && ExecObj.OtherTP.Count > 0) ? string.Join(" ; ", ExecObj.OtherTP.Select(x => x.USER_DISPLAY)) : "None");
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$MonthYear", ExecObj.startmonth);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ContractNo", ExecObj.contractNo);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$InitiatedDate", ExecObj.InitiatedDate);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$TrialTitle", ExecObj.trialtitle);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ACV", ExecObj.AcvValue);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActualStartDate", ExecObj.actualStartDate);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActualEndADate", ExecObj.actualEndADate);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActualPlanComment", ExecObj.actualPlanComment);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Reason", Comment);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SentBackDate", ExecObj.plan_SentbackDate);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SubmissionDate", ExecObj.plan_SubmissionDate);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ReSubmittedDate", ExecObj.plan_SubmissionDate);
            if (TemplateCode.Equals("EXEC009"))
            {
                string link = host + "/#/tmct/manage-execution-actual";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view created Executions : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("EXEC001")||TemplateCode.Equals("EXEC006") || TemplateCode.Equals("EXEC007") || TemplateCode.Equals("EXEC008") )
            {
                string link = host + "/#/tmct/manage-execution-planned";
                if (TemplateCode.Equals("EXEC001") || TemplateCode.Equals("EXEC008"))
                    link = link + "?r_c=TP";
                else if(TemplateCode.Equals("EXEC006") || TemplateCode.Equals("EXEC007"))
                    link = link + "?r_c=UCT";




                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view the Execution Planned Timelines : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("EXEC010"))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SubmissionDate", ExecObj.plan_SubmissionDate);
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Progress", ExecObj.overallProgress);
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$OTrialFpNames", (ExecObj.OtherTP != null && ExecObj.OtherTP.Count > 0) ? string.Join(" ; ", ExecObj.OtherTP.Select(x => x.USER_DISPLAY)) : "None");
                string link = host + "/#/tmct/manage-execution-actual?r_c=UCT";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view  : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("EXEC011") || TemplateCode.Equals("EXEC012") || TemplateCode.Equals("EXEC013") || TemplateCode.Equals("EXEC014") || TemplateCode.Equals("EXEC015"))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SubmissionDate", ExecObj.invReqDate);
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$InvoiceComments", ExecObj.invComments);
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$InvoiceAmount", ExecObj.InvoiceAmount.ToString());
                string link = host + "/#/tmct/manage-invoice";
                if (TemplateCode.Equals("EXEC011"))
                    link = link + "?r_c=UCT";
                else if(TemplateCode.Equals("EXEC012") || TemplateCode.Equals("EXEC013")|| TemplateCode.Equals("EXEC015"))
                    link = link + "?r_c=TP";
                else if (TemplateCode.Equals("EXEC013"))
                    link = link + "?r_c=SS";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view Invoices : " + "<a href='" + link + "'>Link</a>";
                }
            }

            return await _commonService.SendEmail(emailSendConfigDTO,employee);
        }

        public async Task<long> AddExeFlowHistory(ExeFlowHistory DTO)
        {

            try
            {
                await _unitOfWork.ExeFlowHistory.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;





            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region Invoice Register

        public async Task<List<InvoiceRequestDTO>> LoadInvoiceRequests(long ActiveRole, string MuNumber)
        {
            return await _unitOfWork.actualplanned.LoadInvoiceRequests(ActiveRole, MuNumber);
        }

        public async Task<List<InvoiceRequestDetailsDTO>> LoadInvoiceRequestDetails(long ActiveRole, string MuNumber, long ExecutionId)
        {
            return await _unitOfWork.actualplanned.LoadInvoiceRequestDetails(ActiveRole, MuNumber, ExecutionId);
        }

        public async Task<ExecutionInvoice> GetExecutionInvoice(long Id)
        {
            return await _unitOfWork.ExeInvoice.GetFirstOrDefaultAsync(x => x.Id == Id);
        }

        public async Task<long> AddInvoice(ExecutionInvoice DTO)
        {
            try
            {
                await _unitOfWork.ExeInvoice.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> UpdateInvoice(ExecutionInvoice DTO)
        {
            try
            {
                ExecutionInvoice? obj = null;
                obj = await _unitOfWork.ExeInvoice.GetFirstOrDefaultAsync(x => x.Id == DTO.Id);
                if (obj != null)
                {
                    obj.InvoiceAmount = DTO.InvoiceAmount;
                    obj.RequestedDate = DTO.RequestedDate;

                    obj.StatusId = DTO.StatusId;
                    obj.UpdatedBy = DTO.UpdatedBy;

                    obj.UpdatedOn = DTO.UpdatedOn;
                    _unitOfWork.ExeInvoice.Update(obj);
                }
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion



        public async Task<long> UpdateExecutionCompletion(long actualId)
        {
            try
            {
                var validate = _unitOfWork.execution.ValidateExcecutionISCompleted(actualId).Result;
                if (validate != 0) 
                {
                    var existingExecution = _unitOfWork.execution.GetExecutionById(validate).Result;
                    if (existingExecution != null) 
                    {
                        long result = 0;
                        existingExecution.UpdatedOn = DateTime.Now;
                        existingExecution.UpdatedBy = "";
                        existingExecution.CompletionDate = DateTime.Now;
                        existingExecution.IsCompleted = true;
                        _unitOfWork.execution.Update(existingExecution);
                        result = await _unitOfWork.SaveAsync();
                        return result;
                    }
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }





        public async Task<long> UpdateExecutionActualPlanTimeline(ExecutionActualplannedtimline obj)
        {
            try
            {
                long result = 0;
                obj.UpdatedOn = DateTime.Now;
                obj.UpdatedBy = "";
                _unitOfWork.actualplanned.Update(obj);
                result = await _unitOfWork.SaveAsync();

                if (result > 0)
                {
                    return (long)obj.Id;
                }



                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> SendReminderEmails(string Module, string TemplateCode)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {
                    if (TemplateCode.Equals("EXEC016"))
                    {
                        var emailEscConfig = await _unitOfWork.EmailEscalation.getEmailEscByCode(TemplateCode);
                        var reminderData = await _unitOfWork.execution.reminderEmail(emailEscConfig.days.Value);

                        if (reminderData != null && reminderData.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (var item in reminderData)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                emailSendConfigDTO.ccRecipients = new List<string>();
                                emailSendConfigDTO.toRecipients.Add(item.mendatoryEmailAddress);
                                emailSendConfigDTO.ccRecipients.Add(item.uctEmailAddress);
                                if (item.oFPs?.Count > 0)
                                    emailSendConfigDTO.ccRecipients.AddRange(item.oFPs);

                                EmailSendConfigDTO emailConfig = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                                ExecutionActualplannedtimline actualPlan = await _unitOfWork.actualplanned.GetFirstOrDefaultAsync(x => x.Id == item.id);
                                if (actualPlan != null)
                                {
                                    actualPlan.LastReminder = DateTime.Now;
                                    actualPlan.UpdatedOn = DateTime.Now;
                                    actualPlan.EscCount = emailEscConfig.escalCount > 0 ? actualPlan.EscCount != null && actualPlan.EscCount > 0 ? (actualPlan.EscCount + 1) : 1 : 0;

                                    if (item.lastReminder != null && emailEscConfig.escalCount > 0 && emailEscConfig.escalCount == actualPlan.EscCount && _configuration["ServerMode"] == "Prod")
                                    {
                                        var UctFp = await _unitOfWork.Employee.GetByMuNumber(item.uctFP);
                                        if (UctFp != null && UctFp.SUPERVISOR_ID != null)
                                        {
                                            emailSendConfigDTO.ccRecipients = new List<string>();
                                            var UctFpEmail = await _commonService.GetEmailBymuNO(UctFp.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                                            actualPlan.EscCount = 0;
                                        }
                                    }
                                }

                                if (emailConfig.keywords.Count > 0 && !string.IsNullOrEmpty(emailConfig.body))
                                {
                                    var mapData = await MapReminderEmail(emailConfig, item);
                                    if (mapData)
                                    {
                                        _unitOfWork.actualplanned.Update(actualPlan);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return 0;
        }

        private async Task<bool> MapReminderEmail(EmailSendConfigDTO emailSendConfigDTO, ExecutionEscDTO executionEscDTO)
        {
            string hostInternal = _configuration["TIPApplicationPath"];

            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", executionEscDTO.uctName.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$MTrailFpName", executionEscDTO.mendatoryName.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ReferenceNo", executionEscDTO.ttaRefNo.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SubmissionDate", executionEscDTO.submittedDate.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$OTrialFPNames", executionEscDTO.oFPs.ToString());
            string link = hostInternal + "/#/tmct/manage-execution-actual";

            if (emailSendConfigDTO.body.Contains("$$Link"))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
            }
            else
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view the actual timeline's : " + "<a href='" + link + "'>Link</a>";
            }

            return await _commonService.SendEmail(emailSendConfigDTO);
        }

        public async Task<List<ExeFlowHistoryDTO>> GetAllFlowHistory(long ExeId)
        {
            return await _unitOfWork.ExeFlowHistory.GetHistoryById(ExeId);
        }
        public async Task<List<ExeFlowHistoryDTO>> GetHistoryByPlanId(long plan)
        {
            return await _unitOfWork.ExeFlowHistory.GetHistoryByPlanId(plan);
        }
        public async Task<List<ExeFlowHistoryDTO>> GetHistoryByApprovedPlanId(long plan)
        {
            return await _unitOfWork.ExeFlowHistory.GetHistoryByApprovedPlanId(plan);
        }

        public async Task<TrialPlanReportResponseDTO> TrailPlanReport(TrialPlanReportDRequestDTO trialPlanReportDTORequestDTO, EmployeeDTO? LoggedInUser)
        {
            List<TrialPlanReportDTO> currrentYearPlnnedtta = new List<TrialPlanReportDTO>();
            TrialPlanReportResponseDTO response = await _unitOfWork.execution.TrailPlanReport(trialPlanReportDTORequestDTO, LoggedInUser);
            if (response != null)
            {
                string CurrentYearStr = DateTime.Now.Year.ToString();
                int CurrentYear = DateTime.Now.Year;

                currrentYearPlnnedtta = response.data;
                foreach (var item in currrentYearPlnnedtta)
                {
                    #region Planned Trial Plan
                    DateTime? mindate = null;
                    DateTime? maxdate = null;
                    DateTime? amindate = null;
                    DateTime? amaxdate = null;
                   
                    List<ExecutionPlannedTimelinesDTO> currentyearplanned = item.ExecutionPlannedTimelinesDTO.ToList();

                    if (currentyearplanned != null && currentyearplanned.Count > 0)
                    {
                     
                        mindate = Convert.ToDateTime(currentyearplanned.Where(c => c.Start != null && c.Start.Value != default(DateTime)).OrderBy(a => a.Start).FirstOrDefault().Start);
                        maxdate = Convert.ToDateTime(currentyearplanned.Where(c => c.End != null && c.End.Value != default(DateTime)).OrderByDescending(a => a.End).FirstOrDefault().End);

                      


                    }
                    item.Planned = ManageTrail(mindate, maxdate, 1);
                    item.PlannedStr = String.Join(",", item.Planned.Values);

                    #endregion

                    #region Actual Trial Plan

                    List<ExecutionActualPlannedTimelineDTO> actualtimeline = await _unitOfWork.execution.GetActualTimelines(item.ExecutionId);
                    item.ExecutionActualPlannedTimelineDTO = actualtimeline;
                    if (actualtimeline!=null && actualtimeline.Count > 0)
                    {
                        string amindatestr = actualtimeline.Where(a => a.actualstartdate != null && a.actualstartdate != DateTime.MinValue.ToString()).OrderBy(a => a.actualstartdate).FirstOrDefault()?.actualstartdate;

                        if (!String.IsNullOrEmpty(amindatestr) && amindatestr != default(DateTime).ToString())
                        {
                            amindate = Convert.ToDateTime(amindatestr);
                        }
                        string amaxdatestr = actualtimeline.Where(a => a.actualdenddate != null && a.actualdenddate != DateTime.MinValue.ToString()).OrderByDescending(a => a.actualdenddate).FirstOrDefault()?.actualdenddate;



                        if (!String.IsNullOrEmpty(amaxdatestr) && amindatestr != default(DateTime).ToString())
                        {
                            amaxdate = Convert.ToDateTime(amaxdatestr);
                        }

                        
                    }
                    item.Actual = ManageTrail(amindate, amaxdate, 2);
                    item.ActualStr = String.Join(",", item.Actual.Values);

                    #endregion


                    #region Delayed Trial Plan
                  
                        item.Delayed = ManageTrail(maxdate, amaxdate, 3);
                        item.DelayedStr = String.Join(",", item.Delayed.Values);
                    
                     
                    

                    #endregion



                }

            }
            response.data = currrentYearPlnnedtta;
            return response;
        }

        public async Task<ReportPrintDTO> TrailPlanPrint(TrialPlanReportDRequestDTO ReportDTO)
        {

            TrialPlanReportResponseDTO result = new TrialPlanReportResponseDTO();
            result = await TrailPlanReport(ReportDTO, null);
            string[] streamIds;
            string mimeType = string.Empty;
            string encoding = string.Empty;
            string filetype = string.Empty;
            string fileName = string.Format("{0}.{1}", "Trail Rplan Report" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());

            LocalReport localReport = new LocalReport();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Encoding.GetEncoding("windows-1252");
            string fileDirPath = Assembly.GetExecutingAssembly().Location.Replace("TIP_BAL.dll", string.Empty);
            string rdlcFilePath = "";
            rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "TrialPlanReport");
            localReport.ReportPath = rdlcFilePath;
            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("ReportName", "Trial Plan Report") });
            localReport.DataSources.Add(new ReportDataSource() { Name = "TrialPlanReport", Value = result.data });
            localReport.EnableExternalImages = true;
            localReport.EnableHyperlinks = true;
            localReport.Refresh();
            mimeType = string.Empty;
            encoding = string.Empty;
            string extension = string.Empty;

            byte[] bytes = localReport.Render(ReportDTO.docType, null, out mimeType, out encoding, out extension, out streamIds, out Microsoft.Reporting.NETCore.Warning[] warnings);
            return new ReportPrintDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
        }

        public Dictionary<int, string> ManageTrail(DateTime? startDate, DateTime? EndDate, int type)
        {
            int startmonth = 0;
            int endmonth = 0;
                Dictionary<int, string> MonthlyPlan = new Dictionary<int, string>();
            string className = "Green";
            for (int i = 1; i <= 12; i++)
            {
                MonthlyPlan.Add(i, String.Empty);
            }
            int currentYear = DateTime.Now.Year;
            int startyear = Convert.ToDateTime(startDate).Year;
            int endyear = Convert.ToDateTime(EndDate).Year;
            if (startDate != null && EndDate != null)
            {
              
                if (startyear < currentYear)
                {
                    startmonth = 1;
                }
                if (startyear == currentYear)
                {
                    startmonth = Convert.ToDateTime(startDate).Month;
                }
                if (endyear > currentYear)
                {
                    endmonth = 12;
                }
                if ( endyear == currentYear)
                {
                  
                    endmonth = Convert.ToDateTime(EndDate).Month;
                }
                if (startyear == currentYear && endyear == currentYear)
                {
                    startmonth = Convert.ToDateTime(startDate).Month;
                    endmonth = Convert.ToDateTime(EndDate).Month;
                }
         
            }
            if (startmonth == 0 && endmonth ==0 )
            {
                return MonthlyPlan;

            }
            else if(startmonth == 0 && endmonth != 0)
            {
                startmonth = 1;
            }
            else if (startmonth != 0 && endmonth == 0)
            {
                endmonth = 12;
            }
            if (type == 1 || type == 2)
            {

                className = type == 1 ? "Yellow" : "Green";
                for (int i = startmonth; i <= endmonth; i++)
                {

                    MonthlyPlan[i] = className;
                }


            }
            else if (type == 3)
            {
            
                if (startyear > currentYear) //startyear = Planned End Date --  in this no deplay
                {

                    return MonthlyPlan;
                }
                className = "Red";
                for (int i = startmonth + 1; i <= endmonth; i++)
                {

                    MonthlyPlan[i] = className;
                }
            }




            return MonthlyPlan;


        }

     
    }
}
