using Microsoft.EntityFrameworkCore;
using Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Reporting.NETCore;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface;
using TIP_BAL.Services.Admin;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_Common;
using TIP_Common.Admin;
using TIP_CORE;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Repository.Admin;
using static TIP_Common.Enum.Enum;

namespace TIP_BAL.Services
{
    public class CtrService : ICtrService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICommonService _commonService;
        private readonly IConfiguration _configuration;
        public CtrService(IUnitOfWork unitOfWork, ICommonService commonService, IConfiguration configuration)
        {
            this._unitOfWork = unitOfWork;
            _commonService = commonService;
            _configuration = configuration;
        }

        public async Task<long> AddCTR(CtrInitiation DTO)
        {

            try
            {
                TypeCodeMasterDTO Drafted = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.CTRStatus, CTRStatus.Drafted);
                if (Drafted == null)
                {
                    return 0;
                }
                else
                {
                    DTO.StatusId = Drafted.id;

                    await _unitOfWork.Ctr.AddAsync(DTO);
                    long result = await _unitOfWork.SaveAsync();

                    CtrInitiation obj = await _unitOfWork.Ctr.GetFirstOrDefaultAsync(x => x.Id == DTO.Id);

                    //CTR-000003 new change based on discussion
                    string refrno = "TTA-" + obj.Id.ToString().PadLeft(5, '0');
                    obj.RefNo = refrno;


                   
                    _unitOfWork.Ctr.Update(obj);

                    long result1 = await _unitOfWork.SaveAsync();
                    if (result1 > 0)
                    {
                        return DTO.Id;// or Id if table id exist
                    }
                    return result1;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

		private async Task<List<TTAPaymentDTO>> ctrPayment(long ctrId)
        {
            return await _unitOfWork.Ctr.ctrPayment(ctrId);
        }




		#region CTR Print
		public async Task<CTRPRINTDTO> GetAllCtrPrint(long Id, long roleid, string CompanyNumber, string docType)
        {
            try
            {
				var id = Id;
                var RoleId = roleid;
                var result = await _unitOfWork.Ctr.GetCtrFormDataForRDLC(id, RoleId, CompanyNumber);
                var getAllAdditionalSolution = await _unitOfWork.CtrAdditionalSolutions.GetAllAdditionalSolution(id);
                var CtrTrialRisk = await _unitOfWork.CtrTrialRisk.GetCtrTrialRisks(id);
                var CtrSuccessCerteria  =await _unitOfWork.CtrSuccessCriterion.GetCtrSuccessCerteria(id);
                var CtrDeploymentStaircase = await _unitOfWork.CtrDeploymentStaircase.GetCtrDeploymentStaircaseDetail(id);
                var CtrBudget = await _unitOfWork.CtrBudget.GetCtrBudget(id);
                var CtrDeploymentStaircaseByYearly = await _unitOfWork.CtrDeploymentStaircase.GetCtrDeploymentStaircaseByYearly(id);
                var AllFlowHistory = await _unitOfWork.CtrApprovalList.GetApproverListByCtr(id);
                var GetAllFilesByLinkId = await _commonService.GetAllFilesById(id, "CTR Form", false);
                var GetTrialPlan = await _unitOfWork.CtrTrial.GetCtrTrialYear(id);
                var ctrPercentage = await _unitOfWork.CtrPercentageCompletion.GetAllList(Id);
                var schedulePrice = await _unitOfWork.CtrSchedulePrice.GetCtrSchedulePrice(Id);
                var ctrPayment = await _unitOfWork.Ctr.ctrPayment(Id);
                
              

                Dictionary<string, string> parameters = new Dictionary<string, string>();
               
                Warning[] warnings;
                string[] streamIds;
                string mimeType = string.Empty;
                string encoding = string.Empty;
                string filetype = string.Empty;
				string fileName = string.Format("{0}.{1}", "CTR Number" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());// Need to change
                //string fileName = string.Format("{0}.{1}", "OilBingoSheet" + DateTime.Now.Ticks.ToString(), BingoSheetDTO.ReportType.ToString());
                LocalReport localReport = new LocalReport();
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                Encoding.GetEncoding("windows-1252");
                string fileDirPath = Assembly.GetExecutingAssembly().Location.Replace("TIP_BAL.dll", string.Empty);
                string rdlcFilePath = "";
                //if (docType == "WORD")
                //     rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "CTRWordPrint");
                //else
                    rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "CTRPrint");

                localReport.ReportPath = rdlcFilePath;
                
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRInitiation", Value = result });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRAlternativeSol", Value = getAllAdditionalSolution });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRTrialRisk", Value = CtrTrialRisk });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRSuccessCerteria", Value = CtrSuccessCerteria });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRDeploymentStaircase", Value = CtrDeploymentStaircase.ctrDeploymentStaircaseDTOs });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRBudget", Value = CtrBudget });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRDeploymentStaircaseByYearly", Value = CtrDeploymentStaircaseByYearly });
                localReport.DataSources.Add(new ReportDataSource() { Name = "AllFlowHistory", Value = AllFlowHistory });
                localReport.DataSources.Add(new ReportDataSource() { Name = "AllFilesByLinkId", Value = GetAllFilesByLinkId });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRGetTrialPlan", Value = GetTrialPlan });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRPercentage", Value = ctrPercentage });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRSchedulePrice", Value = schedulePrice });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRPayment", Value = ctrPayment });
				localReport.EnableExternalImages = true;    
                localReport.EnableHyperlinks = true;
                
                localReport.Refresh();
                               
               

                byte[] bytes = localReport.Render(docType, null, out mimeType, out encoding, out filetype, out streamIds, out warnings);
                return new CTRPRINTDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        #endregion

        #region TTA Print
        public async Task<CTRPRINTDTO> GetTTAPrint(long Id, long roleid, string CompanyNumber,TTAPrint tTAPrint)
        {
            try
            {
                var id = Id;
                var RoleId = roleid;
                var result = await _unitOfWork.Ctr.GetCtrFormDataForRDLC(id, RoleId, CompanyNumber);
                var getAllAdditionalSolution = await _unitOfWork.CtrAdditionalSolutions.GetAllAdditionalSolution(id);
                var CtrTrialRisk = await _unitOfWork.CtrTrialRisk.GetCtrTrialRisks(id);
                var CtrSuccessCerteria = await _unitOfWork.CtrSuccessCriterion.GetCtrSuccessCerteria(id);
                var CtrDeploymentStaircase = await _unitOfWork.CtrDeploymentStaircase.GetCtrDeploymentStaircaseDetail(id);
                var CtrBudget = await _unitOfWork.CtrBudget.GetCtrBudget(id);
                var CtrDeploymentStaircaseByYearly = await _unitOfWork.CtrDeploymentStaircase.GetCtrDeploymentStaircaseByYearly(id);
                var AllFlowHistory = await _unitOfWork.CtrApprovalList.GetApproverListByCtr(id);
                AllFlowHistory=AllFlowHistory.OrderByDescending(x=>x.seq).Take(1).ToList();
                
                var GetTrialPlan = await _unitOfWork.CtrTrial.GetCtrTrialYear(id);
                var ctrPercentage = await _unitOfWork.CtrPercentageCompletion.GetAllList(Id);
                var schedulePrice = await _unitOfWork.CtrSchedulePrice.GetCtrSchedulePrice(Id);
                var ctrPayment = await _unitOfWork.Ctr.ctrPayment(Id);
                if (ctrPayment[0] == null || !ctrPayment[0].ctrPaymentMilestone.Trim().Equals("Percentage Completion"))
                {
                    ctrPercentage = new List<CtrPercentageCompletionDTO>();
                    CtrPercentageCompletionDTO ctrPercentage1 = new CtrPercentageCompletionDTO();
                    ctrPercentage.Add(ctrPercentage1);
                    ctrPercentage[0].Percentage = -1;
                }
               
                Dictionary<string, bool> parameters = new Dictionary<string, bool>();
                parameters.Add("TrialStartngYr", tTAPrint.TrialStartngYr);
                parameters.Add("ChallengeName", tTAPrint.ChallengeName);
                parameters.Add("ChallengeDefinition", tTAPrint.ChallengeDefinition);
                parameters.Add("technologyDescription", tTAPrint.TechDesc);
                parameters.Add("maturity", tTAPrint.Maturity);
                parameters.Add("alternativeSolution", tTAPrint.AltSol);
                parameters.Add("TrialObjective", tTAPrint.TrialObjectives);
                parameters.Add("workscope", tTAPrint.WorkScope);
                parameters.Add("SelectionCriteria", tTAPrint.SelCriteria);
                parameters.Add("businessvalue", tTAPrint.BusinsVal);
                parameters.Add("trialcontractingstrategy", tTAPrint.TrialContrStartgy);
                parameters.Add("trialplan", tTAPrint.TrialPlan);
                parameters.Add("trialRiskmitigationplan", tTAPrint.TrialRiskMitig);
                parameters.Add("successcriteria", tTAPrint.SuccessCriteria);
                parameters.Add("deploymentstaircase", tTAPrint.DeplmntStrcs);
                parameters.Add("budget", tTAPrint.Budget);
                parameters.Add("trialCost", tTAPrint.trialCst);
                parameters.Add("Milestone", tTAPrint.Milestone);
                parameters.Add("scheduleOfprices", tTAPrint.schedOfprc);
                parameters.Add("Percentage", ctrPercentage.Count==0||ctrPercentage[0].Percentage == -1?false:true);
               

                Warning[] warnings;
                string[] streamIds;
                string mimeType = string.Empty;
                string encoding = string.Empty;
                string filetype = string.Empty;
                string fileName = string.Format("{0}.{1}", "CTR Number" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());// Need to change
               
                LocalReport localReport = new LocalReport();
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                Encoding.GetEncoding("windows-1252");
                string fileDirPath = Assembly.GetExecutingAssembly().Location.Replace("TIP_BAL.dll", string.Empty);
                string rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "TTAgreement");
                localReport.ReportPath = rdlcFilePath;
                foreach (var key in parameters.Keys.AsEnumerable())
                {
                    localReport.SetParameters(new ReportParameter(key, parameters[key]?Boolean.FalseString:Boolean.TrueString));
                }
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRInitiation", Value = result });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRAlternativeSol", Value = getAllAdditionalSolution });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRTrialRisk", Value = CtrTrialRisk });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRSuccessCerteria", Value = CtrSuccessCerteria });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRDeploymentStaircase", Value = CtrDeploymentStaircase.ctrDeploymentStaircaseDTOs });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRBudget", Value = CtrBudget });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRDeploymentStaircaseByYearly", Value = CtrDeploymentStaircaseByYearly });
                localReport.DataSources.Add(new ReportDataSource() { Name = "AllFlowHistory", Value = AllFlowHistory });
               
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRGetTrialPlan", Value = GetTrialPlan });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRPercentage", Value = ctrPercentage });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRSchedulePrice", Value = schedulePrice });
                localReport.DataSources.Add(new ReportDataSource() { Name = "CTRPayment", Value = ctrPayment });

                localReport.EnableExternalImages = true;
                localReport.EnableHyperlinks = true;
               
                localReport.Refresh();
               
                 mimeType = string.Empty;
                 encoding = string.Empty;
                string extension = string.Empty;

              

                byte[] bytes = localReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);
                return new CTRPRINTDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        #endregion




        public async Task<List<CtrInitiationDTO>> GetAllCtr(string CompanyNumber)
        {
            return await _unitOfWork.Ctr.GetAllCtr(CompanyNumber);
        }

        //
        public async Task<List<CtrInitiationDTO>> GetAllCtrForTTA(string CompanyNumber)
        {
            return await _unitOfWork.Ctr.GetAllCtrForTTA(CompanyNumber);
        }
        public async Task<string> GetDDFormat()
        {
            return await _unitOfWork.Ctr.GetDDFormat();
        }
        public async Task<List<CtrInitiationDTO>> GetAllCTRforReview(string CompanyNumber)
        {
            return await _unitOfWork.Ctr.GetAllCTRforReview(CompanyNumber);
        }
        public async Task<Boolean> ValidateVendor(string ttaref, string vendor_code)
        {
            return await _unitOfWork.Ctr.ValidateVendor(ttaref,vendor_code);
        }
        public async Task<string> ValidateCTR(long id)
        {
            return await _unitOfWork.Ctr.ValidateCTR(id);
        }
        public async Task<CtrInitiationDTO> GetCtrFormData(long Id, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.Ctr.GetCtrFormData(Id, roleid, CompanyNumber);
        }

        public async Task<CtrViewPlanDetailsDTO> GetCtrFormDataforViewPlan(long Id)
        {
           
            return await _unitOfWork.Ctr.GetCtrFormDataforViewPlan(Id);
        }
        public async Task<CtrInitiation> GetById(long Id)
        {
            return await _unitOfWork.Ctr.GetAsync(Id);
        }

        public async Task<long> UpdateCtr(CtrInitiation DTO)
        {
            try
            {
                _unitOfWork.Ctr.Update(DTO);
                long result = await _unitOfWork.SaveAsync();

               
                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddTrialFp(List<CtrTrialFp> DTO)
        {
            try
            {
                long CtrId = DTO.SingleOrDefault(x => x.IsMandatory.Equals(true)).CtrId;

                _unitOfWork.CtrTrialFp.RemoveRange(_unitOfWork.CtrTrialFp.GetAllAsync(a => a.CtrId.Equals(CtrId)).Result);

                await _unitOfWork.CtrTrialFp.AddRangeAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddProjectMembers(List<CtrProjectMember> DTO)
        {
            try
            {

                long? ctrId = DTO.FirstOrDefault().CtrId;
                _unitOfWork.CtrPM.RemoveRange(_unitOfWork.CtrPM.GetAllAsync(a => a.CtrId.Equals(ctrId)).Result);

                await _unitOfWork.CtrPM.AddRangeAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region Additional Solution

        public async Task<long> AddAdditionalSolution(CtrAdditionalSolution DTO)
        {

            try
            {
                await _unitOfWork.CtrAdditionalSolutions.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<CtrAdditionalSolutionDTO>> GetAllAdditionalSolution(long CtrId)
        {
            return await _unitOfWork.CtrAdditionalSolutions.GetAllAdditionalSolution(CtrId);
        }
        public async Task<List<CtrFlowHistoryDTO>> GetAllFlowHistory(long CtrId)
        {
            return await _unitOfWork.CtrFlowHistory.GetHistoryById(CtrId);
        }

		public async Task<List<CtrFlowHistoryDTO>> GetAllFlowHistoryDetail(long CtrId)
		{
			return await _unitOfWork.CtrFlowHistory.GetAllFlowHistoryDetail(CtrId);
		}

		public async Task<CtrAdditionalSolutionDTO> GetAdditionalSolutionFormData(long Id)
        {
            return await _unitOfWork.CtrAdditionalSolutions.GetAdditionalSolutionFormData(Id);
        }

        public async Task<CtrAdditionalSolution> GetAdditionalSolutionById(long Id)
        {
            return await _unitOfWork.CtrAdditionalSolutions.GetAsync(Id);
        }

        public async Task<long> UpdateAdditionalSolution(CtrAdditionalSolution DTO)
        {
            try
            {
                _unitOfWork.CtrAdditionalSolutions.Update(DTO);
                long result = await _unitOfWork.SaveAsync();

                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeleteAdditionalSolution(long Id, EmployeeDTO employee)
        {
            try
            {
                CtrAdditionalSolution? obj = null;
                obj = await _unitOfWork.CtrAdditionalSolutions.GetFirstOrDefaultAsync(x => x.Id == Id);
                var audittrailObj = new UtlAuditTrail()
                {
                    TableName = "CTR_ADDITIONAL_SOLUTIONS",
                    Action = "DELETE",
                    ActionBy = employee.DISPLAY_NAME + " " + employee.COMPANY_NUMBER,
                    ActionOn = DateTime.Now.ToString("dd/MM/yyyy"),
                    Description = JsonSerializer.Serialize(obj),
                };
                if (obj != null)
                {
                    _unitOfWork.CtrAdditionalSolutions.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    await _commonService.Log(audittrailObj);
                    return result > 0 ? result : 1;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> AddCtrFlowHistory(CtrFlowHistory DTO)
        {

            try
            {
                await _unitOfWork.CtrFlowHistory.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Approval List

        public async Task<CtrApprovalList> GetApprovalListBySeq(long Seq, long CtrId, string CompanyNumber)
        {
            return await _unitOfWork.CtrApprovalList.GetFirstOrDefaultAsync(x => x.Seq.Equals(Seq) && x.CtrId.Equals(CtrId) && x.ActionRequiredBy.Equals(CompanyNumber));
        }

        public async Task<List<CtrApprovalList>> GetApprovalListBySeq(long Seq, long CtrId)
        {
            return (List<CtrApprovalList>)await _unitOfWork.CtrApprovalList.GetAllAsync(x => x.Seq.Equals(Seq) && x.CtrId.Equals(CtrId));
        }
        public async Task<List<CtrApprovalList>> GetApprovalListsByCtrId(long CtrId)
        {
            return (List<CtrApprovalList>)await _unitOfWork.CtrApprovalList.GetAllAsync(x => x.CtrId.Equals(CtrId));
        }

        public async Task<CtrApprovalList> GetApprovalListById(long Id)
        {
            return await _unitOfWork.CtrApprovalList.GetAsync(Id);
        }
        public async Task<List<AdJobLst>> GetAdJobswithFilter(string Filter)
        {
            return (List<AdJobLst>)await _unitOfWork.AdJobDataList.GetAllAsync(x => x.JobDescription.Contains(Filter));
        }

        public async Task<CtrApprovalListDTO> GetApprovalListFormData(long Id)
        {
            return await _unitOfWork.CtrApprovalList.GetApprovalListFormData(Id);
        }

        public async Task<long> UpdateApprovalList(CtrApprovalList DTO)
        {
            try
            {
                _unitOfWork.CtrApprovalList.Update(DTO);
                long result = await _unitOfWork.SaveAsync();

                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> UpdateApprovalList(List<CtrApprovalList> list)
        {
            try
            {
                _unitOfWork.CtrApprovalList.UpdateRange(list);
                long result = await _unitOfWork.SaveAsync();
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> AddDefaultApprovalList(List<CtrApprovalList> lst)
        {
            try
            {
                foreach (var item in lst)
                {
                    item.Id = 0;
                }
                await _unitOfWork.CtrApprovalList.AddRangeAsync(lst);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return true;// or Id if table id exist
                }
                return false;


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateCtrAprovalList(long CtrId, long CurrentApprovalSeq, bool firstRoundofApprovals)
        {
            try
            {
                List<CtrApprovalList> lst = (List<CtrApprovalList>)await _unitOfWork.CtrApprovalList.GetAllAsync(x => x.CtrId.Equals(CtrId) && x.Seq > 0 && x.ActionRequiredBy != null);
                if (lst != null)
                {
                    if (firstRoundofApprovals)
                    {
                        lst.Where(z => z.Seq.Equals(1)).ToList().ForEach(z => z.ActionAssignedDate = DateTime.Now);
                        lst.ForEach(z => z.Status = CTRApprovalStatus.UnderApproval);
                    }
                    else
                    {
                        

                        lst.Where(z => z.Seq.Equals(CurrentApprovalSeq) && z.Status.Equals(CTRApprovalStatus.SentBack)).ToList()
                            .ForEach((z) =>
                            {
                                z.Status = CTRApprovalStatus.UnderApproval;
                                z.ActionCompletionDate = null;
                                z.ActionAssignedDate = DateTime.Now;
                                z.LastReminder = null;
                                z.Comments = "";
                            });
                    }

                    _unitOfWork.CtrApprovalList.UpdateRange(lst);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<CtrApprovalListDTO>> GetAllApprovalListByCtrId(long CtrId)
        {
            return await _unitOfWork.CtrApprovalList.GetAllApprovalListByCtrId(CtrId);
        }
        public async Task<long> AddCtrApprovalList(CtrApprovalList obj)
        {
            try
            {
                await _unitOfWork.CtrApprovalList.AddAsync(obj);
                long result = await _unitOfWork.SaveAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeleteCtrApprovalList(long id)
        {
            try
            {
                var DefaultJobCodes = new string[] { "HNT", "LM", "TL", "CFDH", "DCO" };

                CtrApprovalList obj = null;
                obj = await _unitOfWork.CtrApprovalList.GetFirstOrDefaultAsync(x => x.Id.Equals(id));
                if (obj != null)
                {
                    if (DefaultJobCodes.Contains(obj.JobCode))
                    {
                        obj.Seq = 0;
                        obj.ActionRequiredBy = null;
                        obj.Status = CTRApprovalStatus.Drafted;
                        obj.ActionAssignedDate = null;
                        obj.ActionCompletionDate = null;
                        obj.Comments = "";
                        _unitOfWork.CtrApprovalList.Update(obj);

                    }
                    else
                    {
                        _unitOfWork.CtrApprovalList.Remove(obj);
                    }

                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> ResetCtrApproval(long CtrId)
        {
            List<CtrApprovalList> ctrApprovalLists = (List<CtrApprovalList>?)await _unitOfWork.CtrApprovalList.GetAllAsync(a => a.CtrId.Equals(CtrId));
            List<CtrApprovalListHsty> ctrApprovalListHsties = new List<CtrApprovalListHsty>();


            if (ctrApprovalLists != null)
            {
                List<CtrApprovalListHsty> checkVersion = (List<CtrApprovalListHsty>)await _unitOfWork.CtrApprovalListHis.GetAllAsync(a => a.CtrId.Equals(CtrId));
                long version = checkVersion.DistinctBy(x => x.Version).Count();

                foreach (CtrApprovalList obj in ctrApprovalLists)
                {
                    CtrApprovalListHsty newobj = new CtrApprovalListHsty()
                    {
                        CtrId = obj.CtrId,
                        JobTitle = obj.JobTitle,
                        JobCode = obj.JobCode,
                        Seq = obj.Seq,
                        Comments = obj.Comments,
                        ActionAssignedDate = obj.ActionAssignedDate,
                        ActionCompletionDate = obj.ActionCompletionDate,
                        CreatedBy = obj.CreatedBy,
                        CreatedByRef = obj.CreatedByRef,
                        CreatedOn = obj.CreatedOn,
                        HistoryCreatedOn = DateTime.Now,
                        Status = obj.Status,
                        Version = version + 1,
                    };
                    ctrApprovalListHsties.Add(newobj);
                }
                if (ctrApprovalListHsties.Any())
                {
                    await _unitOfWork.CtrApprovalListHis.AddRangeAsync(ctrApprovalListHsties);
                    long result = await _unitOfWork.SaveAsync();
                    _unitOfWork.CtrApprovalList.RemoveRange(ctrApprovalLists);
                    result = await _unitOfWork.SaveAsync();
                    return result;
                }
            }
            return 0;
        }

        #endregion

        #region Reassignment 

        public async Task<List<CtrInitiationDTO>> GetAllCTRforReAssignmentAdmin(string CompanyNumber)
        {
            return await _unitOfWork.Ctr.GetAllCTRforReAssignmentAdmin(CompanyNumber);
        }
        public async Task<List<CtrInitiationDTO>> GetAllCTRforReAssignmentUCT(string CompanyNumber)
        {
            return await _unitOfWork.Ctr.GetAllCTRforReAssignmentUCT(CompanyNumber);
        }

        public async Task<List<CtrTrialFp>> GetAllCtrTrialFpbyCtrId(long CtrId)
        {
            try
            {
                return (List<CtrTrialFp>)await _unitOfWork.CtrTrialFp.GetAllAsync(x => x.CtrId.Equals(CtrId));

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region CTR Emails

        public async Task<long> SendCTREmail(long CTRId, string Module, string TemplateCode, string? Comment,EmployeeDTO? employee=null)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {


                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {
                    CtrInitiationDTO ctrObj = await _unitOfWork.Ctr.CTREmailData(CTRId, TemplateCode);

                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                    if (TemplateCode.Equals("CTR001")) // New Ctr
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ctrObj.MandatoryTP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Otfp in ctrObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }
                       
                        var UctFpEmail = await _commonService.GetEmailBymuNO(ctrObj.UctFp);
                        emailSendConfigDTO.ccRecipients.Add(UctFpEmail);

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                    }
                    else if (TemplateCode.Equals("CTR002") || TemplateCode.Equals("CTR003")) //Submit Ctr && Re Submit Ctr
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var UctFpEmail = await _commonService.GetEmailBymuNO(ctrObj.UctFp);
                        emailSendConfigDTO.toRecipients.Add(UctFpEmail);


                        emailSendConfigDTO.ccRecipients = new List<string>();                       
                        var mFpEmail = await _commonService.GetEmailBymuNO(ctrObj.MandatoryTP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.ccRecipients.Add(mFpEmail);

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                    }
                    else if (TemplateCode.Equals("CTR005")) //Sent Back
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var fpEmail = await _commonService.GetEmailBymuNO(ctrObj.MandatoryTP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        emailSendConfigDTO.ccRecipients = new List<string>();
                       
                        var UctFpEmail = await _commonService.GetEmailBymuNO(ctrObj.UctFp);
                        emailSendConfigDTO.ccRecipients.Add(UctFpEmail);


                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode, Comment);
                    }
                    else if (TemplateCode.Equals("CTR007")) //Next lvel approve email
                    {
                        List<CtrApprovalList> currentApproverList = (List<CtrApprovalList>)await _unitOfWork.CtrApprovalList.GetAllAsync(x =>
                        x.CtrId.Equals(CTRId) &&
                        x.Seq.Equals(ctrObj.CurrentApprovalSeq) &&
                        x.Status.Equals(CTRApprovalStatus.UnderApproval) &&
                        x.ActionRequiredBy != null);

                        if (currentApproverList != null)
                        {
                           

                            emailSendConfigDTO.toRecipients = new List<string>();
                            foreach (CtrApprovalList cpl in currentApproverList)
                            {
                                var fpEmail = await _commonService.GetEmailBymuNO(cpl.ActionRequiredBy);
                                emailSendConfigDTO.toRecipients.Add(fpEmail);
                            }

                            emailSendConfigDTO.ccRecipients = new List<string>();
                            var mfpEmail = await _commonService.GetEmailBymuNO(ctrObj.MandatoryTP.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(mfpEmail);

                            var UctFpEmail = await _commonService.GetEmailBymuNO(ctrObj.UctFp);
                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);


                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);

                        }
                    }
                    else if (TemplateCode.Equals("CTR008")) //UCT Rejected
                    {

                        emailSendConfigDTO.toRecipients = new List<string>();

                        var UctFpEmail = await _commonService.GetEmailBymuNO(ctrObj.UctFp);
                        emailSendConfigDTO.toRecipients.Add(UctFpEmail);

                        var fpEmail = await _commonService.GetEmailBymuNO(ctrObj.MandatoryTP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Otfp in ctrObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode, Comment);
                    }
                    else if (TemplateCode.Equals("CTR009")) //Sentback from Approver
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var mfpEmail = await _commonService.GetEmailBymuNO(ctrObj.MandatoryTP.PERSONNEL_NUMBER);
                        emailSendConfigDTO.toRecipients.Add(mfpEmail);

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        var UctFpEmail = await _commonService.GetEmailBymuNO(ctrObj.UctFp);
                        emailSendConfigDTO.ccRecipients.Add(UctFpEmail);

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode, Comment);
                    }
                    else if (TemplateCode.Equals("CTR011") || TemplateCode.Equals("CTR011N")) //Approved Email //N means new Seq 
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var mfpEmail = await _commonService.GetEmailBymuNO(ctrObj.MandatoryTP.PERSONNEL_NUMBER);
                        var UctFpEmail = await _commonService.GetEmailBymuNO(ctrObj.UctFp);
                        emailSendConfigDTO.toRecipients.Add(UctFpEmail);
                        emailSendConfigDTO.toRecipients.Add(mfpEmail);

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        if (employee != null)
                        {
                            emailSendConfigDTO.ccRecipients.Add(employee.EMAIL_ADDRESS);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);

                    }
                    else if (TemplateCode.Equals("CTR012")) //Fully Approved
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var mfpEmail = await _commonService.GetEmailBymuNO(ctrObj.MandatoryTP.PERSONNEL_NUMBER);
                        var UctFpEmail = await _commonService.GetEmailBymuNO(ctrObj.UctFp);
                        emailSendConfigDTO.toRecipients.Add(UctFpEmail);
                        emailSendConfigDTO.toRecipients.Add(mfpEmail);
                        emailSendConfigDTO.ccRecipients = new List<string>();
                        if (employee != null)
                        {
                            emailSendConfigDTO.ccRecipients.Add(employee.EMAIL_ADDRESS);
                        }
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                    }
           

                    //MapCTRPlanForEmail
                }

            }


            return 0;

        }

        public async Task<bool> MapCTRForEmail(EmailSendConfigDTO emailSendConfigDTO, long CTRId, CtrInitiationDTO ctrObj, string TemplateCode, string Comment = "")
        {
            string host = _configuration["TIPApplicationPath"];

            if (!string.IsNullOrEmpty(ctrObj.OldUctFpName))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", ctrObj.OldUctFpName);
            }
            if (!string.IsNullOrEmpty(ctrObj.OldMandatoryFpName))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$MTrailFpName", ctrObj.OldMandatoryFpName);
            }
            if (!string.IsNullOrEmpty(ctrObj.DeletedApproverName))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ApproverName", ctrObj.DeletedApproverName);
            }
            if (!string.IsNullOrEmpty(ctrObj.ApproverName))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ApproverName", ctrObj.ApproverName);
            }
         
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$TTATitle", ctrObj.CtrTrialTitle); 
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$MTrailFpName", ctrObj.MandatoryTP.USER_DISPLAY);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ReferenceNo", ctrObj.ReferenceNumber);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", ctrObj.UctFpName);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTHeadName", ctrObj.UctHeadFpName);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$OTrialFpNames", (ctrObj.OtherTP != null && ctrObj.OtherTP.Count > 0) ? string.Join(" ; ", ctrObj.OtherTP.Select(x => x.USER_DISPLAY)) : "None");
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ApproverNames", string.Join(" , ", ctrObj.CurrentApprovers.Select(x => x.USER_DISPLAY)));
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ApproverName", ctrObj.ApproverName);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Reason", Comment);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SentBackDate", ctrObj.SentbackDate);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$RejectionDate", ctrObj.UpdatedOn);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SubmissionDate", ctrObj.SubmissionDate);


            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$VendorContactName", ctrObj.vendorcontact);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCT_Email", ctrObj.uctFPEmail);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ContractEngineer", ctrObj.CE);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$CE_Email", ctrObj.CE_Email);

            if ( TemplateCode.Equals("TTA002")|| TemplateCode.Equals("TTA003")|| TemplateCode.Equals("TTA004"))
            {
                emailSendConfigDTO.body=emailSendConfigDTO.body+ "\r\n\r\n<p>If you have any questions, feel free to <a href=\"mailto:"+ ctrObj.CE_Email+";"+ctrObj.uctFPEmail + "\">reply via email</a>.</p>";
            }
            if (TemplateCode.Equals("TTA001"))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body + "\r\n\r\n<p>If you have any questions, feel free to <a href=\"mailto:" + ctrObj.CE_Email + "\">reply via email</a>.</p>";
            }

            if (TemplateCode.Equals("CTR001"))
            {
                string link = host + "/#/tfel/manage-ctr?r_c=TP&s="+ ctrObj.CtrTrialTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view created TTA's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("CTR002") || TemplateCode.Equals("CTR003"))
            {
                string link = host + "/#/tfel/manage-ctr?r_c=UCT&s=" + ctrObj.CtrTrialTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view submitted TTA's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("CTR004"))
            {
                string link = host + "/#/tfel/manage-ctr?r_c=UCT&s=" + ctrObj.CtrTrialTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view submitted TTA's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("CTR005"))
            {
                string link = host + "/#/tfel/manage-ctr?r_c=TP&s=" + ctrObj.CtrTrialTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view TTA's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("CTR006"))
            {
                string link = host + "/#/tfel/manage-ctr?r_c=TP&s=" + ctrObj.CtrTrialTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view TTA's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("CTR007"))
            {
                string link = host + "/#/tfel/review-ctr?r_c=CTRA&s=" + ctrObj.CtrTrialTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view TTA's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("CTR008"))
            {
                // No Link for Rejection, since no place to see.
            }
            if (TemplateCode.Equals("CTR009"))
            {
                string link = host + "/#/tfel/manage-ctr?r_c=TP&s=" + ctrObj.CtrTrialTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view TTA's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("CTR011") || TemplateCode.Equals("CTR011N"))
            {
                // No Link for partially approved.
            }
            if (TemplateCode.Equals("CTR012"))
            {
                // No Link for fully approved.
            }
            if (TemplateCode.Equals("CTR019"))
            {
                string link = host + "/#/tfel/review-ctr?r_c=CTRA&s=" + ctrObj.CtrTrialTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view TTA's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            return await _commonService.SendEmail(emailSendConfigDTO);
        }


        public async Task<long> SendCTRPlanEmail(long CTRId, long actualId, string Module, string TemplateCode)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {


                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {
                    CTRActualPlanDetailsDTO ctrObj = await _unitOfWork.Ctr.CTRPlanEmailData(CTRId, actualId);
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    emailSendConfigDTO.toRecipients = new List<string>();

                    var mfpEmail = await _commonService.GetEmailBymuNO(ctrObj.MFP.PERSONNEL_NUMBER);
                    var UctFpEmail = await _commonService.GetEmailBymuNO(ctrObj.UCT.PERSONNEL_NUMBER);
                    emailSendConfigDTO.toRecipients.Add(UctFpEmail);
                    emailSendConfigDTO.toRecipients.Add(mfpEmail);

                    EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                    if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        await MapCTRPlanForEmail(res, CTRId, ctrObj, TemplateCode);
                }
            }
                    return 0;
        }

            public async Task<bool> MapCTRPlanForEmail(EmailSendConfigDTO emailSendConfigDTO, long CTRId, CTRActualPlanDetailsDTO ctrObj, string TemplateCode, string Comment = "")
        {
            string host = _configuration["TIPApplicationPath"];

            if (!string.IsNullOrEmpty(ctrObj.UCT.USER_DISPLAY))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", ctrObj.UCT.USER_DISPLAY);
            }
            if (!string.IsNullOrEmpty(ctrObj.MFP.USER_DISPLAY))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$MTrailFpName", ctrObj.MFP.USER_DISPLAY);
            }
          

            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$CTRReferenceNo", ctrObj.ctr_id.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$TechName", ctrObj.Tech);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$StartDate", ctrObj.actualstartdate);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$EndDate", ctrObj.actualenddate);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$overallprogress", ctrObj.overallprogress);


            if (TemplateCode.Equals("CTR999"))
            {
                string link = host + "#/reporting/updateActualDetails?CTRCode="+ ctrObj.CTRCode + "&view=false&r_c=TP";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view created TTA's : " + "<a href='" + link + "'>Link</a>";
                }
            }
         
            return await _commonService.SendEmail(emailSendConfigDTO);
        }
        public async Task<long> SendReassignEmail(long CTRId, string Module, string TemplateCode, string newdataset, string olddataset, string changedby)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {
                    CtrInitiationDTO ctrObj = await _unitOfWork.Ctr.CTREmailData(CTRId, TemplateCode);
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                    if (TemplateCode.Equals("CTR013")) // New UCT
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var newUCT = await _commonService.GetEmailBymuNO(newdataset);
                        emailSendConfigDTO.toRecipients.Add(newUCT);

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                    }
                    if (TemplateCode.Equals("CTR014")) // OLD UCT
                    {
                        var olduct = await _unitOfWork.Employee.GetByMuNumber(olddataset);

                        if (olduct != null)
                        {
                            ctrObj.OldUctFpName = olduct.DISPLAY_NAME;
                            emailSendConfigDTO.toRecipients = new List<string>();
                            var OldUCT = await _commonService.GetEmailBymuNO(olddataset);
                            emailSendConfigDTO.toRecipients.Add(OldUCT);

                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                        }
                    }
                    if (TemplateCode.Equals("CTR015")) // Mandatory FP Changed - New Mandatory Email
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var newMFp = await _commonService.GetEmailBymuNO(newdataset);
                        emailSendConfigDTO.toRecipients.Add(newMFp);

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Otfp in ctrObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                    }
                    if (TemplateCode.Equals("CTR016")) // Mandatory FP Changed - Old Mandatory Email
                    {
                        var oldmfp = await _unitOfWork.Employee.GetByMuNumber(olddataset);

                        if (oldmfp != null)
                        {
                            ctrObj.OldMandatoryFpName = oldmfp.DISPLAY_NAME;
                            emailSendConfigDTO.toRecipients = new List<string>();
                            var oldMFp = await _commonService.GetEmailBymuNO(olddataset);
                            emailSendConfigDTO.toRecipients.Add(oldMFp);

                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                        }
                    }
                    if (TemplateCode.Equals("CTR017")) // Other Focal Point changed
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var newMFp = await _commonService.GetEmailBymuNO(newdataset);
                        emailSendConfigDTO.toRecipients.Add(newMFp);

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Otfp in ctrObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                    }
                    if (TemplateCode.Equals("CTR018")) // Approver Deleted
                    {
                        var DeletedApproverName = await _unitOfWork.Employee.GetByMuNumber(olddataset);
                        if (DeletedApproverName != null)
                        {
                            ctrObj.DeletedApproverName = DeletedApproverName.DISPLAY_NAME;

                            emailSendConfigDTO.toRecipients = new List<string>();
                            var deletingUser = await _commonService.GetEmailBymuNO(olddataset);
                            emailSendConfigDTO.toRecipients.Add(deletingUser);

                            emailSendConfigDTO.ccRecipients = new List<string>();
                            var newMFp = await _commonService.GetEmailBymuNO(ctrObj.MandatoryTP.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(newMFp);

                            var UctFp = await _commonService.GetEmailBymuNO(ctrObj.UctFp);
                            emailSendConfigDTO.ccRecipients.Add(UctFp);

                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                        }
                    }
                    if (TemplateCode.Equals("CTR019")) // Approver Added or Updated Seq 
                    {
                        var ApproverName = await _unitOfWork.Employee.GetByMuNumber(newdataset);
                        if (ApproverName != null)
                        {
                            ctrObj.ApproverName = ApproverName.DISPLAY_NAME;

                            emailSendConfigDTO.toRecipients = new List<string>();
                            var deletingUser = await _commonService.GetEmailBymuNO(newdataset);
                            emailSendConfigDTO.toRecipients.Add(deletingUser);

                            emailSendConfigDTO.ccRecipients = new List<string>();
                            var mfpEmail = await _commonService.GetEmailBymuNO(ctrObj.MandatoryTP.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(mfpEmail);

                            var UctFpEmail = await _commonService.GetEmailBymuNO(ctrObj.UctFp);
                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);

                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                        }
                    }

                }

            }

            return 0;
        }


        public async Task<bool> SendEmailReminderToVendor(emailReminder DTO)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, EmailModules.CTR_FRONT_END_LOADING);
            var result = false;
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, "TTA001");
                if (Template != null)
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    emailSendConfigDTO.toRecipients.Add(DTO.toEmail);
                    emailSendConfigDTO.ccRecipients = new List<string>();
                    var ccpeople = await _commonService.GetAllUsersByRole("CE");
                    foreach (var cc in ccpeople)
                    {
                        emailSendConfigDTO.ccRecipients.Add(cc.EMAIL_ADDRESS);
                    }
                    emailSendConfigDTO.subject=Template.MailSubject;
                    emailSendConfigDTO.body=Template.MailBody;
                    if (DTO.ccEmail != null)
                    {
                        emailSendConfigDTO.ccRecipients = new List<string>();

                        emailSendConfigDTO.ccRecipients.Add(DTO.ccEmail);
                    }
                   
                    result= await _commonService.SendEmail(emailSendConfigDTO);
                }
            }
            return result;
        }

        // 
        public async Task<bool> SendEmailDDFormatToVendor(DDFormat DTO)
        {
            long CTRId = Convert.ToInt64(CryptoExtensions.Decrypt(DTO.cfcode));
                string TemplateCode = "TTA002";
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, EmailModules.CTR_FRONT_END_LOADING);
            var result = false;
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                CtrInitiationDTO ctrObj = await _unitOfWork.Ctr.CTREmailData(CTRId, TemplateCode);
                if (Template != null)
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    
                    var toEmail = await _commonService.GetEmailByVendorCode(DTO.vendorCode);
                    emailSendConfigDTO.ccRecipients = new List<string>();
                    var ccpeople = await _commonService.GetAllUsersByRole("CE");
                    foreach (var cc in ccpeople)
                    {
                        emailSendConfigDTO.ccRecipients.Add(cc.EMAIL_ADDRESS);
                    }
                    emailSendConfigDTO.toRecipients.Add(toEmail);
                    emailSendConfigDTO.subject = Template.MailSubject;
                    emailSendConfigDTO.body = Template.MailBody;
                    emailSendConfigDTO.attachment =  CryptoExtensions.Decrypt(_commonService.GetDDFormatPath().Result.filepath);
                    emailSendConfigDTO.attachmentname = "DD_Form."+Path.GetExtension(emailSendConfigDTO.attachment);
                    EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                   

                    if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        result = await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                    
                }
            }
            return result;
        }

        public async Task<bool> SendEmailTCTemplateToVendor(TcTemplate DTO)
        {
            long CTRId = Convert.ToInt64(CryptoExtensions.Decrypt(DTO.cfcode));
            string TemplateCode = "TTA003";
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, EmailModules.CTR_FRONT_END_LOADING);
            var result = false;
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                CtrInitiationDTO ctrObj = await _unitOfWork.Ctr.CTREmailData(CTRId, TemplateCode);
                if (Template != null)
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    var toEmail = await _commonService.GetEmailByVendorCode(DTO.vendorCode);
                    emailSendConfigDTO.toRecipients.Add(toEmail);
                    emailSendConfigDTO.ccRecipients = new List<string>();
                    var ccpeople = await _commonService.GetAllUsersByRole("CE");
                    foreach (var cc in ccpeople)
                    {
                        emailSendConfigDTO.ccRecipients.Add(cc.EMAIL_ADDRESS);
                    }
                    emailSendConfigDTO.subject = Template.MailSubject;
                    emailSendConfigDTO.body = Template.MailBody;
                    emailSendConfigDTO.attachment = CryptoExtensions.Decrypt(DTO.fp);
                    emailSendConfigDTO.attachmentname = "TermsAndConditions."+Path.GetExtension(emailSendConfigDTO.attachment);
                    EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                    

                    if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        result = await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                    
                }
            }
            return result;
        }

       public async Task<bool> SendEmailTTAToVendor(DDFormat DTO)
        {
            long CTRId = Convert.ToInt64(CryptoExtensions.Decrypt(DTO.cfcode));
            string TemplateCode = "TTA004";
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, EmailModules.CTR_FRONT_END_LOADING);
            var result = false;
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                CtrInitiationDTO ctrObj = await _unitOfWork.Ctr.CTREmailData(CTRId, TemplateCode);
                if (Template != null)
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    var toEmail = await _commonService.GetEmailByVendorCode(DTO.vendorCode);
                    emailSendConfigDTO.toRecipients.Add(toEmail);
                    emailSendConfigDTO.ccRecipients = new List<string>();
                    var ccpeople = await _commonService.GetAllUsersByRole("CE");
                    foreach (var cc in ccpeople)
                    {
                        emailSendConfigDTO.ccRecipients.Add(cc.EMAIL_ADDRESS);
                    }
                    emailSendConfigDTO.subject = Template.MailSubject;
                    emailSendConfigDTO.body = Template.MailBody;
                    emailSendConfigDTO.attachment = CryptoExtensions.Decrypt(_commonService.GetTTAFormatPath(CTRId).Result.filepath);
                    emailSendConfigDTO.attachmentname= "TechnologyTrialAgreement.pdf";
                    EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                    

                    if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        result = await MapCTRForEmail(res, CTRId, ctrObj, TemplateCode);
                    
                }
            }
            return result;
        }

        #endregion

        #region CTR Reminder
        public async Task<long> SendCTRReminderEmails(string Module, string TemplateCode)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {


                    if (TemplateCode.Equals("CTR004")) // Weekly Reminder when CTR is with New Technology Advisor 
                    {
                        var WeeklyReminderList = await _unitOfWork.Ctr.GetAllForWeeklyReminderUCT();
                        if (WeeklyReminderList != null && WeeklyReminderList.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (CtrApprovalReminderDTO ctrApproval in WeeklyReminderList)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                var ReminderUser = await _commonService.GetEmailBymuNO(ctrApproval.UctFp);
                                emailSendConfigDTO.toRecipients.Add(ReminderUser);

                                // Email Escalation Start
                                DateTime submittedDate = ctrApproval.SubmittedOn.Value;
                                DateTime today = DateTime.Today;

                                // Calculate the time elapsed between submitted date and today
                                TimeSpan timeElapsed = today - submittedDate;

                                // Set the interval between emails in days
                                long emailIntervalDays = await _unitOfWork.EmailEscalation.getEmailEscDays("CTR004");

                                // Calculate the number of occurrences that have happened so far
                                long occurrences = (long)(timeElapsed.TotalDays / emailIntervalDays) + 1;

                                // Set the threshold for escalation
                                long escalationThreshold = await _unitOfWork.EmailEscalation.getEmailEscOccurunces("CTR004");

                                // Check if escalation email should be sent
                                if (escalationThreshold > 0 && occurrences > escalationThreshold)
                                {
                                    // Send escalation email
                                    if (ctrApproval.LastReminder != null && _configuration["ServerMode"] == "Prod")
                                    {
                                        var UctFp = await _unitOfWork.Employee.GetByMuNumber(ctrApproval.UctFp);
                                        if (UctFp != null && UctFp.SUPERVISOR_ID != null)
                                        {
                                            emailSendConfigDTO.ccRecipients = new List<string>();
                                            var UctFpEmail = await _commonService.GetEmailBymuNO(UctFp.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                                        }
                                    }
                                }

                                

                                CtrInitiationDTO ctrObj = await _unitOfWork.Ctr.CTREmailData(ctrApproval.CTRId, TemplateCode);

                                EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                {
                                    var emailResult = await MapCTRForEmail(res, ctrApproval.CTRId, ctrObj, TemplateCode);
                                    if (emailResult)
                                    {
                                        CtrInitiation updateItem = await _unitOfWork.Ctr.GetAsync(ctrApproval.CTRId);
                                        updateItem.LastReminder = DateTime.Now.Date;
                                        _unitOfWork.Ctr.Update(updateItem);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                    if (TemplateCode.Equals("CTR006")) // Weekly Reminder when CTR is with Trial Focal Point
                    {
                        var WeeklyReminderList = await _unitOfWork.Ctr.GetAllForWeeklyReminderTFP();
                        if (WeeklyReminderList != null && WeeklyReminderList.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (CtrApprovalReminderDTO ctrApproval in WeeklyReminderList)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                var ReminderUser = await _commonService.GetEmailBymuNO(ctrApproval.MandatoryFp);
                                emailSendConfigDTO.toRecipients.Add(ReminderUser);

                                // Email Escalation Start
                                DateTime SentbackOn = ctrApproval.SentbackOn.Value;
                                DateTime today = DateTime.Today;

                                // Calculate the time elapsed between Sentback date and today
                                TimeSpan timeElapsed = today - SentbackOn;

                                // Set the interval between emails in days
                                long emailIntervalDays = await _unitOfWork.EmailEscalation.getEmailEscDays("CTR006");

                                // Calculate the number of occurrences that have happened so far
                                long occurrences = (long)(timeElapsed.TotalDays / emailIntervalDays) + 1;

                                // Set the threshold for escalation
                                long escalationThreshold = await _unitOfWork.EmailEscalation.getEmailEscOccurunces("CTR006");

                                // Check if escalation email should be sent
                                if (escalationThreshold > 0 && occurrences > escalationThreshold)
                                {
                                    // Send escalation email
                                    if (ctrApproval.LastReminder != null && _configuration["ServerMode"] == "Prod")
                                    {
                                        var Supervisor = await _unitOfWork.Employee.GetByMuNumber(ctrApproval.MandatoryFp);
                                        if (Supervisor != null && Supervisor.SUPERVISOR_ID != null)
                                        {
                                            emailSendConfigDTO.ccRecipients = new List<string>();
                                            var UctFpEmail = await _commonService.GetEmailBymuNO(Supervisor.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                                        }
                                    }
                                }


                                CtrInitiationDTO ctrObj = await _unitOfWork.Ctr.CTREmailData(ctrApproval.CTRId, TemplateCode);

                                EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                {
                                    var emailResult = await MapCTRForEmail(res, ctrApproval.CTRId, ctrObj, TemplateCode);
                                    if (emailResult)
                                    {
                                        CtrInitiation updateItem = await _unitOfWork.Ctr.GetAsync(ctrApproval.CTRId);
                                        updateItem.LastReminder = DateTime.Now.Date;
                                        _unitOfWork.Ctr.Update(updateItem);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                    if (TemplateCode.Equals("CTR010")) // Daily Reminder for approver, if not approved
                    {
                        var DailyReminderList = await _unitOfWork.CtrApprovalList.GetAllForDailyReminder();
                        if (DailyReminderList != null && DailyReminderList.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (CtrApprovalReminderDTO ctrApproval in DailyReminderList)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                var ReminderUser = await _commonService.GetEmailBymuNO(ctrApproval.Approver);
                                emailSendConfigDTO.toRecipients.Add(ReminderUser);

                                emailSendConfigDTO.ccRecipients = new List<string>();
                                var UctFpEmail = await _commonService.GetEmailBymuNO(ctrApproval.UctFp);
                                emailSendConfigDTO.ccRecipients.Add(UctFpEmail);


                                // Email Escalation Start
                                DateTime ActionAssignedDate = ctrApproval.ActionAssignedDate.Value;
                                DateTime today = DateTime.Today;

                                // Calculate the time elapsed between Action Assigned Date and today
                                TimeSpan timeElapsed = today - ActionAssignedDate;

                                // Set the interval between emails in days
                                long emailIntervalDays = await _unitOfWork.EmailEscalation.getEmailEscDays("CTR010");

                                // Calculate the number of occurrences that have happened so far
                                long occurrences = (long)(timeElapsed.TotalDays / emailIntervalDays) + 1;

                                // Set the threshold for escalation
                                long escalationThreshold = await _unitOfWork.EmailEscalation.getEmailEscOccurunces("CTR010");

                                // Check if escalation email should be sent
                                if (escalationThreshold > 0 && occurrences > escalationThreshold)
                                {
                                    // Send escalation email
                                    if (ctrApproval.LastReminder != null && _configuration["ServerMode"] == "Prod")
                                    {
                                        var Supervisor = await _unitOfWork.Employee.GetByMuNumber(ctrApproval.Approver);
                                        if (Supervisor != null && Supervisor.SUPERVISOR_ID != null)
                                        {
                                            var SupervisorEmail = await _commonService.GetEmailBymuNO(Supervisor.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(SupervisorEmail);
                                        }
                                    }
                                }


                                EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                                var ApproverName = await _unitOfWork.Employee.GetByMuNumber(ctrApproval.Approver);
                                ctrApproval.ApproverName = ApproverName.DISPLAY_NAME;

                                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                {
                                    var emailResult = await MapCTRForReminderEmail(res, ctrApproval.CTRId, ctrApproval, TemplateCode);
                                    if (emailResult)
                                    {
                                        CtrApprovalList updateItem = await _unitOfWork.CtrApprovalList.GetAsync(ctrApproval.Id);
                                        updateItem.LastReminder = DateTime.Now.Date;
                                        _unitOfWork.CtrApprovalList.Update(updateItem);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return 0;
        }

        public async Task<bool> MapCTRForReminderEmail(EmailSendConfigDTO emailSendConfigDTO, long CTRId, CtrApprovalReminderDTO ctrApproval, string TemplateCode, string Comment = "")
        {
            string host = _configuration["TIPApplicationPath"];

            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$TTATitle", ctrApproval.CtrTrialTitle);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ReferenceNo", ctrApproval.ReferenceNumber);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ApproverName", ctrApproval.ApproverName);

            if (TemplateCode.Equals("CTR010"))
            {
                string link = host + "/#/tfel/review-ctr?r_c=CTRA&s=" + ctrApproval.CtrTrialTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view TTA's : " + "<a href='" + link + "'>Link</a>";
                }
            }

            return await _commonService.SendEmail(emailSendConfigDTO);
        }
        #endregion

        public async Task<CtrVotDTO> GetCtrVOT(long ctrId)
        {
            return await _unitOfWork.CtrVot.GetVOTDetails(ctrId);
        }

        public async Task<long> AddOrUpdateVOT(CtrVot ctrVot, bool isEdit)
        {

            await DeleteVOT(ctrVot.CtrId);
            ctrVot.Id = 0;
            await _unitOfWork.CtrVot.AddAsync(ctrVot);
            long result = await _unitOfWork.SaveAsync();
            return ctrVot.Id;
        }
        public async Task<long> AddOrUpdateDepStaircase(List<CtrDeploymentStaircase> depStairs)
        {

            await DeleteDepStairs(depStairs[0].CtrId);
            foreach (var depStair in depStairs)
            {
                depStair.Id = 0;
            }
            await _unitOfWork.CtrDeploymentStaircase.AddRangeAsync(depStairs);
            long result = await _unitOfWork.SaveAsync();
            return 1;
        }

        public async Task<long> DeleteVOT(long id)
        {
            try
            {
               
               var obj = await _unitOfWork.CtrVot.GetAllAsync(x => x.CtrId == id);
                if (obj != null)
                {
                    _unitOfWork.CtrVot.RemoveRange(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

         public async Task<long> DeleteDepStairs(long id)
        {
            try
            {
               
               var obj = await _unitOfWork.CtrDeploymentStaircase.GetAllAsync(x => x.CtrId == id);
                if (obj != null)
                {
                    _unitOfWork.CtrDeploymentStaircase.RemoveRange(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<CtrTrialRiskDTO>> GetCtrTrialRisks(long ctrId)
        {
            try
            {
                return await _unitOfWork.CtrTrialRisk.GetCtrTrialRisks(ctrId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddTrialRisk(CtrTrialRisk ctrTrialRisk)
        {
            try
            {
                if (ctrTrialRisk.Id <= 0)
                {
                    ctrTrialRisk.Id = 0;
                }
                await _unitOfWork.CtrTrialRisk.AddAsync(ctrTrialRisk);
                await _unitOfWork.SaveAsync();
                return ctrTrialRisk.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateTrialRisk(CtrTrialRisk ctrTrialRisk)
        {
            CtrTrialRisk obj = null;
            obj = await _unitOfWork.CtrTrialRisk.GetFirstOrDefaultAsync(x => x.Id == ctrTrialRisk.Id);
            obj.Risk = ctrTrialRisk.Risk;
            obj.MitigationPlan = ctrTrialRisk.MitigationPlan;
            obj.UpdatedBy = ctrTrialRisk.UpdatedBy;
            obj.UpdatedByRef = ctrTrialRisk.UpdatedByRef;
            obj.UpdatedOn = ctrTrialRisk.UpdatedOn;

            _unitOfWork.CtrTrialRisk.Update(obj);
            await _unitOfWork.SaveAsync();
            return ctrTrialRisk.Id;
        }

        public async Task<long> DeleteTrialRisk(long id)
        {
            try
            {
                CtrTrialRisk obj = null;
                obj = await _unitOfWork.CtrTrialRisk.GetFirstOrDefaultAsync(x => x.Id == id);
                if (obj != null)
                {
                    _unitOfWork.CtrTrialRisk.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<CtrSuccessCriterionDTO>> GetCtrSuccessCerteria(long ctrId)
        {
            return await _unitOfWork.CtrSuccessCriterion.GetCtrSuccessCerteria(ctrId);
        }
        

        public async Task<long> AddCtrSuccessCerteria(CtrSuccessCriterion ctrSuccessCriterion)
        {
            try
            {
                await _unitOfWork.CtrSuccessCriterion.AddAsync(ctrSuccessCriterion);
                await _unitOfWork.SaveAsync();
                return ctrSuccessCriterion.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateCtrSuccessCerteria(CtrSuccessCriterion ctrSuccessCriterion)
        {
            CtrSuccessCriterion obj = null;
            obj = await _unitOfWork.CtrSuccessCriterion.GetFirstOrDefaultAsync(x => x.Id == ctrSuccessCriterion.Id);
            obj.Parameter = ctrSuccessCriterion.Parameter;
            obj.CurrentValue = ctrSuccessCriterion.CurrentValue;
            obj.TrialTarget = ctrSuccessCriterion.TrialTarget;
            obj.ParameterId = ctrSuccessCriterion.ParameterId;
            obj.DecisionGateImpacted = ctrSuccessCriterion.DecisionGateImpacted;
            obj.Remarks = ctrSuccessCriterion.Remarks;
			obj.UpdatedBy = ctrSuccessCriterion.UpdatedBy;
            obj.UpdatedByRef = ctrSuccessCriterion.UpdatedByRef;
            obj.UpdatedOn = ctrSuccessCriterion.UpdatedOn;

            _unitOfWork.CtrSuccessCriterion.Update(obj);
            await _unitOfWork.SaveAsync();
            return ctrSuccessCriterion.Id;
        }

        public async Task<long> DeleteCtrSuccessCerteria(long id)
        {
            try
            {
                CtrSuccessCriterion obj = null;
                obj = await _unitOfWork.CtrSuccessCriterion.GetFirstOrDefaultAsync(x => x.Id == id);
                if (obj != null)
                {
                    _unitOfWork.CtrSuccessCriterion.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddOrUpdateCtrTrial(List<CtrTrial> ctrTrials, bool isEdit)
        {
            try
            {
                if (isEdit)
                {
                    List<CtrTrial> ctrExistingTrials = new List<CtrTrial>();
                    ctrExistingTrials = (List<CtrTrial>)await _unitOfWork.CtrTrial.GetAllAsync(x => x.CtrId == ctrTrials[0].CtrId);
                    foreach (var item in ctrExistingTrials)
                    {
                        await DeleteCtrTrial(item.CtrId, item.Id);
                    }

                    foreach (var item in ctrTrials)
                    {
                        item.Id = 0;
                        foreach (var item2 in item.CtrTrialYears)
                        {
                            item2.Id = 0;
                            item2.TrialId = 0;
                        }
                    }
                }
                else
                {
                    foreach (var item in ctrTrials)
                    {
                        if (item.Id <= 0)
                        {
                            item.Id = 0;
                        }
                        foreach (var item2 in item.CtrTrialYears)
                        {
                            if (item2.Id <= 0)
                            {
                                item2.Id = 0;
                            }
                            item2.TrialId = 0;
                        }
                    }
                }

                await _unitOfWork.CtrTrial.AddRangeAsync(ctrTrials);
                long result = await _unitOfWork.SaveAsync();
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<long> DeleteCtrTrial(long ctrId, long trialId)
        {
            try
            {
                List<CtrTrialYear> objYear = (List<CtrTrialYear>)await _unitOfWork.CtrTrialYear.GetAllAsync(x => x.TrialId == trialId);
                if (objYear != null && objYear.Count > 0)
                {
                    _unitOfWork.CtrTrialYear.RemoveRange(objYear);
                    await _unitOfWork.SaveAsync();
                }

                CtrTrial obj = await _unitOfWork.CtrTrial.GetFirstOrDefaultAsync(x => x.Id == trialId && x.CtrId == ctrId);
                if (obj != null)
                {
                    _unitOfWork.CtrTrial.Remove(obj);
                    return await _unitOfWork.SaveAsync();
                }

                return 0;
            }
            catch (Exception)
            {
                throw;
            }
        }

		public async Task<List<CtrTrialDTO>> GetCtrTrial(long ctrId)
		{
			return await _unitOfWork.CtrTrial.GetCtrTrial(ctrId);
		}

		public async Task<List<CtrPotentialImpactedDTO>> GetCtrPotentialImpacted(long ctrId)
		{
			return await _unitOfWork.CtrPotentialImpacted.GetCtrPotentialImpacted(ctrId);
		}

		public async Task<long> AddCtrPotentialImpacted(CtrPotentialImpacted ctrPotentialImpacted)
		{
			try
			{
				ctrPotentialImpacted.Id = 0;
				await _unitOfWork.CtrPotentialImpacted.AddAsync(ctrPotentialImpacted);
				await _unitOfWork.SaveAsync();
				return ctrPotentialImpacted.Id;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public async Task<long> UpdateCtrPotentialImpacted(CtrPotentialImpacted ctrPotentialImpacted)
		{
			CtrPotentialImpacted obj = null;
			obj = await _unitOfWork.CtrPotentialImpacted.GetFirstOrDefaultAsync(x => x.Id == ctrPotentialImpacted.Id);
			obj.CtrId = ctrPotentialImpacted.CtrId;
			obj.ContractTitle = ctrPotentialImpacted.ContractTitle;
			obj.ContractNo = ctrPotentialImpacted.ContractNo;
			obj.Contractor = ctrPotentialImpacted.Contractor;
			obj.Impact = ctrPotentialImpacted.Impact;
			obj.UpdatedBy = ctrPotentialImpacted.UpdatedBy;
			obj.UpdatedByRef = ctrPotentialImpacted.UpdatedByRef;
			obj.UpdatedOn = ctrPotentialImpacted.UpdatedOn;

			_unitOfWork.CtrPotentialImpacted.Update(obj);
			await _unitOfWork.SaveAsync();
			return ctrPotentialImpacted.Id;
		}

		public async Task<long> DeleteCtrPotentialImpacted(long id)
		{
			try
			{
				CtrPotentialImpacted obj = null;
				obj = await _unitOfWork.CtrPotentialImpacted.GetFirstOrDefaultAsync(x => x.Id == id);
				if (obj != null)
				{
					_unitOfWork.CtrPotentialImpacted.Remove(obj);
					long result = await _unitOfWork.SaveAsync();
					return result;
				}
				return 0;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public async Task<List<CtrBudgetDTO>> GetCtrBudget(long ctrId)
		{
            return await _unitOfWork.CtrBudget.GetCtrBudget(ctrId);
		}

		public async Task<long> AddCtrBudget(CtrBudget ctrBudget)
		{
			try
			{
				await _unitOfWork.CtrBudget.AddAsync(ctrBudget);
				await _unitOfWork.SaveAsync();
				return ctrBudget.Id;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public async Task<long> UpdateCtrBudget(CtrBudget ctrBudget)
		{
			CtrBudget obj = null;
			obj = await _unitOfWork.CtrBudget.GetFirstOrDefaultAsync(x => x.Id == ctrBudget.Id);
			obj.CtrId = ctrBudget.CtrId;
			obj.Year = ctrBudget.Year;
			obj.QId = ctrBudget.QId;
			obj.ResourceDescription = ctrBudget.ResourceDescription;
			obj.ItemProvider = ctrBudget.ItemProvider;
			obj.BudgetProvider = ctrBudget.BudgetProvider;			
			obj.Amount = ctrBudget.Amount;
			obj.UpdatedBy = ctrBudget.UpdatedBy;
			obj.UpdatedByRef = ctrBudget.UpdatedByRef;
			obj.UpdatedOn = ctrBudget.UpdatedOn;

			_unitOfWork.CtrBudget.Update(obj);
			await _unitOfWork.SaveAsync();
			return ctrBudget.Id;
		}

		public async Task<long> DeleteCtrBudget(long id)
		{
			try
			{
				CtrBudget obj = null;
				obj = await _unitOfWork.CtrBudget.GetFirstOrDefaultAsync(x => x.Id == id);
				if (obj != null)
				{
					_unitOfWork.CtrBudget.Remove(obj);
					long result = await _unitOfWork.SaveAsync();
					return result;
				}
				return 0;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public async Task<CtrFinalDeploymentStaircaseDTO> GetCtrDeploymentStaircaseDetail(long CtrId)
		{
            return await _unitOfWork.CtrDeploymentStaircase.GetCtrDeploymentStaircaseDetail(CtrId);
		}

		public async Task<long> AddDeploymentStaircase(CtrDeploymentStaircase deploymentStaircase)
		{
			try
			{
				await _unitOfWork.CtrDeploymentStaircase.AddAsync(deploymentStaircase);
				await _unitOfWork.SaveAsync();
				return deploymentStaircase.Id;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public async Task<long> UpdateDeploymentStaircase(CtrDeploymentStaircase deploymentStaircase)
		{
			CtrDeploymentStaircase obj = null;
			obj = await _unitOfWork.CtrDeploymentStaircase.GetFirstOrDefaultAsync(x => x.Id == deploymentStaircase.Id);
			obj.CtrId = deploymentStaircase.CtrId;
			obj.Year = deploymentStaircase.Year;
			obj.Noofwells = deploymentStaircase.Noofwells;
			obj.Estimatedvot = deploymentStaircase.Estimatedvot;
			obj.Station = deploymentStaircase.Station;
			obj.UpdatedBy = deploymentStaircase.UpdatedBy;
			obj.UpdatedByRef = deploymentStaircase.UpdatedByRef;
			obj.UpdatedOn = deploymentStaircase.UpdatedOn;

			_unitOfWork.CtrDeploymentStaircase.Update(obj);
			await _unitOfWork.SaveAsync();
			return deploymentStaircase.Id;
		}

		public async Task<long> DeleteDeploymentStaircase(long id)
		{
			try
			{
				CtrDeploymentStaircase obj = null;
				obj = await _unitOfWork.CtrDeploymentStaircase.GetFirstOrDefaultAsync(x => x.Id == id);
				if (obj != null)
				{
					_unitOfWork.CtrDeploymentStaircase.Remove(obj);
					long result = await _unitOfWork.SaveAsync();
					return result;
				}
				return 0;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public async Task<long>UpdateFinalDeploymentStaircase(CtrInitiationDeploymentStaircaseDTO ctrInitiation, EmployeeDTO? LoggedInUser)
        {
			CtrInitiation obj = null;
			obj = await _unitOfWork.Ctr.GetFirstOrDefaultAsync(x => x.Id == ctrInitiation.id);
			obj.DsComment= ctrInitiation.comments;
            obj.DsAssumptionMode= ctrInitiation.assumptionMode;
			obj.UpdatedBy = LoggedInUser.COMPANY_NUMBER;
			obj.UpdatedByRef = LoggedInUser.REFERENCE_INDICATOR;
			obj.UpdatedOn = DateTime.Now;

			_unitOfWork.Ctr.Update(obj);
			await _unitOfWork.SaveAsync();
			return ctrInitiation.id;
		}


        public async Task<List<CtrSchedulePriceDTO>> GetCtrSchedulePrice(long ctrId)
        {
            return await _unitOfWork.CtrSchedulePrice.GetCtrSchedulePrice(ctrId);
        }

        public async Task<long> AddCtrSchedulePrice(CtrSchedulePrice CtrSchedulePrice)
        {
            try
            {
                CtrSchedulePrice.Id = 0;
                await _unitOfWork.CtrSchedulePrice.AddAsync(CtrSchedulePrice);
                await _unitOfWork.SaveAsync();
                return CtrSchedulePrice.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateCtrSchedulePrice(CtrSchedulePrice CtrSchedulePrice)
        {
            CtrSchedulePrice obj = null;
            obj = await _unitOfWork.CtrSchedulePrice.GetFirstOrDefaultAsync(x => x.Id == CtrSchedulePrice.Id);

            obj.CtrId = CtrSchedulePrice.CtrId;
            obj.Description = CtrSchedulePrice.Description;
            obj.Units = CtrSchedulePrice.Units;
            obj.UnitPrice = CtrSchedulePrice.UnitPrice;
            obj.Quantity = CtrSchedulePrice.Quantity;
            obj.NumberOfTrials = CtrSchedulePrice.NumberOfTrials;
            obj.TotalPriceEstimate = CtrSchedulePrice.TotalPriceEstimate;

            obj.UpdatedBy = CtrSchedulePrice.UpdatedBy;
            obj.UpdatedByRef = CtrSchedulePrice.UpdatedByRef;
            obj.UpdatedOn = CtrSchedulePrice.UpdatedOn;

            _unitOfWork.CtrSchedulePrice.Update(obj);
            await _unitOfWork.SaveAsync();
            return CtrSchedulePrice.Id;
        }

        public async Task<long> DeleteCtrSchedulePrice(long id)
        {
            try
            {
                CtrSchedulePrice obj = null;
                obj = await _unitOfWork.CtrSchedulePrice.GetFirstOrDefaultAsync(x => x.Id == id);
                if (obj != null)
                {
                    _unitOfWork.CtrSchedulePrice.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<CtrPercentageCompletionDTO>> GetCtrPaymentMilestone(long ctrId)
        {
            return await _unitOfWork.CtrPercentageCompletion.GetAllList(ctrId);
        }

        public async Task<long> AddCtrPaymentMilestone(CtrPercentageCompletion obj)
        {
            try
            {
                obj.Id = 0;
                await _unitOfWork.CtrPercentageCompletion.AddAsync(obj);
                await _unitOfWork.SaveAsync();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateCtrPaymentMilestone(CtrPercentageCompletion recObj)
        {
            CtrPercentageCompletion obj = null;
            obj = await _unitOfWork.CtrPercentageCompletion.GetFirstOrDefaultAsync(x => x.Id == recObj.Id);

            obj.Percentage = recObj.Percentage;
            obj.EstPrice = recObj.EstPrice;

            obj.UpdatedBy = recObj.UpdatedBy;
            obj.UpdatedByRef = recObj.UpdatedByRef;
            obj.UpdatedOn = recObj.UpdatedOn;

            _unitOfWork.CtrPercentageCompletion.Update(obj);
            await _unitOfWork.SaveAsync();
            return recObj.Id;
        }

        public async Task<long> DeleteCtrPaymentMilestone(long id)
        {
            try
            {
                CtrPercentageCompletion obj = null;
                obj = await _unitOfWork.CtrPercentageCompletion.GetFirstOrDefaultAsync(x => x.Id == id);
                if (obj != null)
                {
                    _unitOfWork.CtrPercentageCompletion.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<CtrApproverListDTO>> GetApproverListByCtr(long Id)
        {
            return await _unitOfWork.CtrApprovalList.GetApproverListByCtr(Id);
        }

		public async Task<GetAllStatusDTO> GetAllStatusByCtr(long ctrId)
        {
            return await _unitOfWork.Ctr.GetAllStatusByCtr(ctrId);
        }


        public async Task<List<CtrTrialCandidateDTO>> GetAllTrialCandidates(long CtrId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.CtrTrialCandidate.GetAllTrialCandidates(CtrId, roleid, CompanyNumber);
        }
        public async Task<long> AddTrialCandidates(CtrTrialCandidate pirTrialCandidate)
        {
            try
            {
                await _unitOfWork.CtrTrialCandidate.AddAsync(pirTrialCandidate);
                long result = await _unitOfWork.SaveAsync();

                if (result > 0)
                {
                    return pirTrialCandidate.Id;
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> UpdateTrialCandidates(CtrTrialCandidate obj)
        {
            try
            {
                CtrTrialCandidate dbObj = await _unitOfWork.CtrTrialCandidate.GetFirstOrDefaultAsync(x => x.Id == obj.Id);

                if (dbObj != null)
                {

                    dbObj.TypeId = obj.TypeId;
                    dbObj.Name = obj.Name;
                    dbObj.Cost = obj.Cost;
                    dbObj.CommencementDate = obj.CommencementDate;
                    dbObj.ConclusionDate = obj.ConclusionDate;
                    dbObj.ChallengeDescription = obj.ChallengeDescription;
                    dbObj.Comments = obj.Comments;
                    dbObj.UpdatedBy = obj.UpdatedBy;
                    dbObj.UpdatedByRef = obj.UpdatedByRef;
                    dbObj.UpdatedOn = obj.UpdatedOn;

                    _unitOfWork.CtrTrialCandidate.Update(dbObj);
                    long result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return dbObj.Id;
                    }
                    return result;
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> DeleteTrialCandidates(long id)
        {
            try
            {
                CtrTrialCandidate? obj = null;
                obj = await _unitOfWork.CtrTrialCandidate.GetFirstOrDefaultAsync(x => x.Id == id);

                if (obj != null)
                {
                    _unitOfWork.CtrTrialCandidate.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    if (result > 0)
                    {
                        return result;
                    }
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<long> AddctrPlan(CtrPlanDetail ctrplan, bool IsSubmit)
        {
            try
            {
                var InActive = _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type == TypeCodes.CTRPlanStatus && x.Param1 == CTRStatus.InActive).Result.Id;
                var validate = await _unitOfWork.CTRPlanDetails.GetFirstOrDefaultAsync(t => t.StageId == ctrplan.StageId && t.CtrId == ctrplan.CtrId && t.Year == ctrplan.Year && t.TemplateId == ctrplan.TemplateId && t.Statusid != InActive);
                if (validate == null)
                {
                    long status = 0;
                    if (!IsSubmit)
                    {
                        status = _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type == TypeCodes.CTRPlanStatus && x.Param1 == CTRStatus.Drafted).Result.Id;

                    }
                    else
                    {
                        status = _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type == TypeCodes.CTRPlanStatus && x.Param1 == CTRStatus.Submitted).Result.Id;

                    }
                    ctrplan.Statusid = status;
                    await _unitOfWork.CTRPlanDetails.AddAsync(ctrplan);
                    await _unitOfWork.SaveAsync();

                    if (IsSubmit)
                    {
                        await _unitOfWork.CTRActualPlanDetails.AddAsync(CTRActualPlanMapping(ctrplan));
                        await _unitOfWork.SaveAsync();
                    }
                    return ctrplan.Id;
                }
                return 0;
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private CtrActualPlanDetail CTRActualPlanMapping(CtrPlanDetail ctrplan) 
        {
           var status = _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type == TypeCodes.CTRPlanStatus && x.Param1 == CTRStatus.Drafted).Result.Id;

          CtrActualPlanDetail objActualPlan = new CtrActualPlanDetail();
          objActualPlan.StatusId = status;
          objActualPlan.Phase = ctrplan.Phase;
          objActualPlan.Stage = ctrplan.Stage;
          objActualPlan.Planneddays = ctrplan.Planneddays;
          objActualPlan.Sequence = ctrplan.Sequence;
          objActualPlan.Actualstartdate = ctrplan.Enddate;
          objActualPlan.StageId = ctrplan.StageId;
          
          objActualPlan.PhaseId = ctrplan.PhaseId;
          objActualPlan.PlanId = ctrplan.Id;
          objActualPlan.CtrId = ctrplan.CtrId;
          objActualPlan.TemplateId = ctrplan.TemplateId;

            return objActualPlan;
        }


        public async Task<long> UpdateCTRPlan(CtrPlanDetail ctrplan,bool IsSubmit)
        {
            try
            {
                var InActive = _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type == TypeCodes.CTRPlanStatus && x.Param1 == CTRStatus.InActive).Result.Id;

                var validate = await _unitOfWork.CTRPlanDetails.GetAllAsync(t => t.Id != ctrplan.Id && t.StageId == ctrplan.StageId && t.CtrId == ctrplan.CtrId && t.Year == ctrplan.Year && t.TemplateId == ctrplan.TemplateId && t.Statusid != InActive);
                if (validate.Count() == 0)
                {
                    CtrPlanDetail obj = null;
                    long status = 0;
                    if (!IsSubmit)
                    {
                        status = _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type == TypeCodes.CTRPlanStatus && x.Param1 == CTRStatus.Drafted).Result.Id;

                    }
                    else
                    {

                        status = _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type == TypeCodes.CTRPlanStatus && x.Param1 == CTRStatus.Submitted).Result.Id;

                        await _unitOfWork.CTRActualPlanDetails.AddAsync(CTRActualPlanMapping(ctrplan));
                        await _unitOfWork.SaveAsync();
                    }

                    obj = await _unitOfWork.CTRPlanDetails.GetFirstOrDefaultAsync(x => x.Id == ctrplan.Id);
                    if (obj != null)
                    {
                        obj.Statusid = status;
                        obj.UpdatedBy = ctrplan.UpdatedBy;
                        obj.UpdatedOn = ctrplan.UpdatedOn;
                        obj.UpdatedByRef = ctrplan.UpdatedByRef;
                        obj.Phase = ctrplan.Phase;
                        obj.Stage = ctrplan.Stage;
                        obj.Planneddays = ctrplan.Planneddays;
                        obj.Sequence = ctrplan.Sequence;
                        obj.StageId = ctrplan.StageId;
                        obj.Startdate = ctrplan.Startdate;
                        obj.Enddate = ctrplan.Enddate;
                        obj.PhaseId = ctrplan.PhaseId;
                        obj.TemplateId = ctrplan.TemplateId;
                        obj.Year = ctrplan.Year;
                    }
                    _unitOfWork.CTRPlanDetails.Update(obj);
                    await _unitOfWork.SaveAsync();
                    return obj.Id;
                }
                return 0;
              
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> DeleteCTRPlan(long id, EmployeeDTO employeeDTO)
        {
            CtrPlanDetail obj = null;
            obj = await _unitOfWork.CTRPlanDetails.GetFirstOrDefaultAsync(x => x.Id == id);
            if (obj != null)
            {
              var  status = _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type == TypeCodes.CTRPlanStatus && x.Param1 == CTRStatus.InActive).Result.Id;
                if (status != null) 
                {
                    obj.Statusid = status;
                }
                obj.UpdatedBy = employeeDTO.COMPANY_NUMBER;
                obj.UpdatedOn = DateTime.Now;
                obj.UpdatedByRef = employeeDTO.REFERENCE_INDICATOR;

                _unitOfWork.CTRPlanDetails.Update(obj);
                await _unitOfWork.SaveAsync();
                
                return 1;
            }
            return 0;
        }


        public async Task<long> AddctrActualPlan(CtrActualPlanDetail ctrplan)
        {
            try
            {
                await _unitOfWork.CTRActualPlanDetails.AddAsync(ctrplan);
                await _unitOfWork.SaveAsync();
                return ctrplan.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateCTRActualPlan(CTRActualPlanDetailsDTO ctrplan)
        {
            try
            {
                CtrActualPlanDetail obj = null;
                long status = 0;
                obj = await _unitOfWork.CTRActualPlanDetails.GetFirstOrDefaultAsync(x => x.Id == ctrplan.Id);
                if (obj != null)
                {
                    if (!(bool)ctrplan.IsSubmit)
                    {
                        status = _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type == TypeCodes.CTRPlanStatus && x.Param1 == CTRStatus.Drafted).Result.Id;

                    }
                    else
                    {

                        status = _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type == TypeCodes.CTRPlanStatus && x.Param1 == CTRStatus.Submitted).Result.Id;

                    
                    }
                    
                    obj.Phase = ctrplan.phase;
                    obj.Stage = ctrplan.stage;
                    obj.Planneddays = ctrplan.planneddays;
                    obj.Sequence = ctrplan.sequence;
                    obj.Actualstartdate = ctrplan.actualstartdate == "" || ctrplan.actualstartdate == null ? null : (DateTime)ctrplan.actualstartdate.ToDateTime();
                    
                    obj.Actualenddate = ctrplan.actualenddate == "" || ctrplan.actualenddate == null ? null : (DateTime)ctrplan.actualenddate.ToDateTime();
                    obj.ForecastedEdDate = ctrplan.forecasted_ed_date == "" || ctrplan.forecasted_ed_date == null ? null : (DateTime)ctrplan.forecasted_ed_date.ToDateTime();
                    obj.ForecastedStDate = ctrplan.forecasted_st_date == "" || ctrplan.forecasted_st_date == null ? null : (DateTime)ctrplan.forecasted_st_date.ToDateTime();
                    obj.Comments = ctrplan.comments == null ?"": ctrplan.comments;
                    obj.Completion = ctrplan.completion;
                    obj.OverallProgressId   = ctrplan.overall_progress_id;
                    
                    obj.StatusId = status;

                }
                _unitOfWork.CTRActualPlanDetails.Update(obj);
                await _unitOfWork.SaveAsync();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<CtrInitiationDTO> GetCtrByRefNo(string RefNo)
        {
            try
            {
                return await _unitOfWork.Ctr.GetCtrByRefNo(RefNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<List<TypeCodeMasterDTO>> GetOverallProgress()
        {
            return await _unitOfWork.Ctr.GetOverallProgress();
        }




        public YearlyBudgetPlan ManagePlanedValues(List<CtrBudgetDTO> Plannedlst)
        {
            YearlyBudgetPlan YearPlan = new YearlyBudgetPlan();
            YearPlan.BudgetMonthly = new Dictionary<int, decimal>();
            for (int i = 1; i <= 12; i++)
            {
                YearPlan.BudgetMonthly.Add(i, 0);
            }
            if (Plannedlst?.Count > 0)
            {
                int quarterbymonths = 3; //4 Quaters
              
                foreach (var pb in Plannedlst)
                {

                    #region Q1
                    decimal monthwiseAmount = Convert.ToDecimal(pb.amount / quarterbymonths);
                    //Q1
                    if (pb.qId == 1)
                    {


                        for (int i = 1; i <= 3; i++)
                        {
                            YearPlan.BudgetMonthly[i] += decimal.Round(monthwiseAmount, 2, MidpointRounding.AwayFromZero);  
                        }

                    }
                    //Q2
                    else if (pb.qId == 2)
                    {

                        for (int i = 4; i <= 6; i++)
                        {
                            YearPlan.BudgetMonthly[i] += decimal.Round(monthwiseAmount, 2, MidpointRounding.AwayFromZero); ;
                        }

                    }
                    //Q3
                    else if (pb.qId == 3)
                    {

                        for (int i = 7; i <= 9; i++)
                        {
                            YearPlan.BudgetMonthly[i] += decimal.Round(monthwiseAmount, 2, MidpointRounding.AwayFromZero); ;
                        }

                    }
                    //Q4
                    else if (pb.qId == 4)
                    {

                        for (int i = 10; i <= 12; i++)
                        {
                            YearPlan.BudgetMonthly[i] += decimal.Round(monthwiseAmount, 2, MidpointRounding.AwayFromZero); ;
                        }

                    }
                    #endregion
                }
            }
            return YearPlan;
        }
      


        public async Task<BudgetReportResponseDTO> BudgetRepot(BudgetReportRequestDTO budgetReportDTO, EmployeeDTO? LoggedInUser)
        {
            BudgetReportDTO resultobj = new BudgetReportDTO();
            List<BudgetReportDTO> resultlst = new List<BudgetReportDTO>();
            BudgetReportResponseDTO budgetReportResponseDTO = new BudgetReportResponseDTO();
            budgetReportResponseDTO = await _unitOfWork.CtrBudget.BudgetRepot(budgetReportDTO, LoggedInUser);
          
            Dictionary<string, string> student = new Dictionary<string, string>();
            if (budgetReportResponseDTO != null)
            {
                string CurrentYear = DateTime.Now.Year.ToString();
                string NextYear = DateTime.Now.AddYears(1).Year.ToString();

                int quarterbymonths = 3; //4 Quaters

                foreach (var item in budgetReportResponseDTO.data)
                {
                    BudgetReportDTO cplan = new BudgetReportDTO();
                    BudgetReportDTO cactual = new BudgetReportDTO();
                    BudgetReportDTO nplan = new BudgetReportDTO();
                    BudgetReportDTO nactual = new BudgetReportDTO();

                    cplan = new BudgetReportDTO();
                    cplan.TechName = cactual.TechName= nplan.TechName= nactual.TechName = item.TechName;
                    cplan.currencyName = cactual.currencyName = nplan.currencyName = nactual.currencyName = item.currencyName;
                    cplan.currencyId = cactual.currencyId = nplan.currencyId = nactual.currencyId = item.currencyId;
                    cplan.UCTFPName = cactual.UCTFPName = nplan.UCTFPName = nactual.UCTFPName = item.UCTFPName;
                    cplan.ctrTrialName = cactual.ctrTrialName = nplan.ctrTrialName = nactual.ctrTrialName = item.ctrTrialName;
                    cplan.ACV = cactual.ACV = nplan.ACV = nactual.ACV = Convert.ToDecimal(item.PlannedBudget.Sum(c => c.amount));
                    cplan.PlannedBudgetTotalAmountYearly = cactual.ActualBudgetTotalAmountYearly = nplan.PlannedBudgetTotalAmountYearly = nactual.ActualBudgetTotalAmountYearly = 0;
                

                    item.Planned = new List<YearlyBudgetPlan>();
                    item.Actual = new List<YearlyBudgetPlan>();


                    #region Planned
                    cplan.Type= nplan.Type = "Planned";
                    cactual.Type = nactual.Type = "Actual";
                    item.PlannedCurrentBudgetMonthly = new Dictionary<int, decimal>();

                    #region Current Year

                    YearlyBudgetPlan currentYearPlan = new YearlyBudgetPlan();
                    item.PlannedCurrentBudgetMonthly = InitializeMonthlyDictonary();


                    item.PlannedBudget = item.PlannedBudget.OrderBy(c => c.qId).ToList();
                    List<CtrBudgetDTO> CurrentYearPlanned = new List<CtrBudgetDTO>();
                    CurrentYearPlanned = item.PlannedBudget.Where(p => p.yearVal == CurrentYear).ToList();

                    cplan.PlannedBudgetTotalAmountYearly = Convert.ToDecimal(CurrentYearPlanned.Sum(c => c.amount));
                    cplan.Year = CurrentYear;

                    currentYearPlan = ManagePlanedValues(CurrentYearPlanned);




                    cplan.PlannedBudgetMonthlyArray = currentYearPlan.BudgetMonthly.Values.ToArray<decimal>();
                    cplan.PlannedBudgetMonthlyStr = String.Join(",", currentYearPlan.BudgetMonthly.Values);



                    cplan.BudgetMonthlyArray = currentYearPlan.BudgetMonthly.Values.ToArray<decimal>();
                    cplan.BudgetMonthlyStr = String.Join(",", currentYearPlan.BudgetMonthly.Values);

                    resultlst.Add(cplan);


              
                    YearlyBudgetPlan currentYearActual = new YearlyBudgetPlan();
                    currentYearActual.BudgetMonthly = InitializeMonthlyDictonary();
                    List<ExecutionInvoiceDTO> currentyearActuallst = item.ActualBudget.Where(c => Convert.ToDateTime(c.PaidDate).Year.ToString() == CurrentYear).OrderBy(c => c.PaidDate).ToList();
                    cactual.ActualBudgetTotalAmountYearly = Convert.ToDecimal(currentyearActuallst.Sum(c => c.InvoiceAmount));
                    cactual.Year = CurrentYear;
                    if (currentyearActuallst?.Count > 0)
                    {
                        foreach (var ab in currentyearActuallst)
                        {

                            decimal monthwiseAmount = Convert.ToDecimal(ab.InvoiceAmount);

                            int Monthofdate = ab.PaidDate.Value.Month;
                            currentYearActual.BudgetMonthly[Monthofdate] += decimal.Round(monthwiseAmount, 2, MidpointRounding.AwayFromZero); ;



                        }
                    }


                    cactual.ActualBudgetMonthlyArray = currentYearActual.BudgetMonthly.Values.ToArray<decimal>();

                    cactual.ActualBudgetMonthlyStr = String.Join(",", currentYearActual.BudgetMonthly.Values);

                    cactual.BudgetMonthlyArray = currentYearActual.BudgetMonthly.Values.ToArray<decimal>();
                    cactual.BudgetMonthlyStr = String.Join(",", currentYearActual.BudgetMonthly.Values);

                    resultlst.Add(cactual);

                    #endregion


                    #region Next Year

                    YearlyBudgetPlan nextYearPlan = new YearlyBudgetPlan();
                    nextYearPlan.BudgetMonthly = InitializeMonthlyDictonary();


                    item.PlannedBudget = item.PlannedBudget.OrderBy(c => c.qId).ToList();
                    List<CtrBudgetDTO> nextYearPlanPlanned = new List<CtrBudgetDTO>();
                    nextYearPlanPlanned = item.PlannedBudget.Where(p => p.yearVal == NextYear).ToList();
                    nplan.PlannedBudgetTotalAmountYearly = Convert.ToDecimal(nextYearPlanPlanned.Sum(c => c.amount));
                    nplan.Year = NextYear;

                    nextYearPlan = ManagePlanedValues(nextYearPlanPlanned);

                    nplan.ActualBudgetMonthlyArray = nextYearPlan.BudgetMonthly.Values.ToArray<decimal>();

                    nplan.ActualBudgetMonthlyStr = String.Join(",", nextYearPlan.BudgetMonthly.Values);


                    nplan.BudgetMonthlyArray = nextYearPlan.BudgetMonthly.Values.ToArray<decimal>();
                    nplan.BudgetMonthlyStr = String.Join(",", nextYearPlan.BudgetMonthly.Values);

                    resultlst.Add(nplan);

                    #endregion






                    #endregion


                    #region Actual

                    #region Next Year
                 

                    YearlyBudgetPlan nextYearActual = new YearlyBudgetPlan();
                    nextYearActual.BudgetMonthly = InitializeMonthlyDictonary();
                    List<ExecutionInvoiceDTO> nextyearActuallst = item.ActualBudget.Where(c => Convert.ToDateTime(c.PaidDate).Year.ToString() == NextYear).OrderBy(c => c.PaidDate).ToList();
                    nactual.ActualBudgetTotalAmountYearly = Convert.ToDecimal(nextyearActuallst.Sum(c => c.InvoiceAmount));
                    nactual.Year = NextYear;
                    if (nextyearActuallst?.Count > 0)
                    {
                        foreach (var ab in nextyearActuallst)
                        {

                            decimal monthwiseAmount = Convert.ToDecimal(ab.InvoiceAmount);

                            int Monthofdate = ab.PaidDate.Value.Month;
                            nextYearActual.BudgetMonthly[Monthofdate] += decimal.Round(monthwiseAmount, 2, MidpointRounding.AwayFromZero); ;



                        }
                    }

                    #endregion

                    nactual.ActualBudgetMonthlyArray = nextYearActual.BudgetMonthly.Values.ToArray<decimal>();

                    nactual.ActualBudgetMonthlyStr = String.Join(",", nextYearActual.BudgetMonthly.Values);

                    nactual.BudgetMonthlyArray = nextYearActual.BudgetMonthly.Values.ToArray<decimal>();
                    nactual.BudgetMonthlyStr = String.Join(",", nextYearActual.BudgetMonthly.Values);

                    resultlst.Add(nactual);

                    #endregion
                }


            }



            budgetReportResponseDTO.data = resultlst;

            
            return budgetReportResponseDTO;
        }


        public async Task<ReportPrintDTO> BudgetRepotPrint(BudgetReportRequestDTO budgetReportDTO)
        {
            BudgetReportResponseDTO result = new BudgetReportResponseDTO();
            result = await BudgetRepot(budgetReportDTO, null);
            string[] streamIds;
            string mimeType = string.Empty;
            string encoding = string.Empty;
            string filetype = string.Empty;
            string fileName = string.Format("{0}.{1}", "Budget Report" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());

            LocalReport localReport = new LocalReport();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Encoding.GetEncoding("windows-1252");
            string fileDirPath = Assembly.GetExecutingAssembly().Location.Replace("TIP_BAL.dll", string.Empty);
            string rdlcFilePath = "";
            rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "PlannedandActualBudgetPrint");
            localReport.ReportPath = rdlcFilePath;
            decimal SumofPlannedUSD = result.data.Where(c=>c.currencyName=="USD").Sum(c=>c.PlannedBudgetTotalAmountYearly);
            decimal SumofActualUSD = result.data.Where(c => c.currencyName == "USD").Sum(c => c.ActualBudgetTotalAmountYearly);


            decimal SumofPlannedOMR = result.data.Where(c => c.currencyName == "OMR").Sum(c => c.PlannedBudgetTotalAmountYearly);
            decimal SumofActualOMR = result.data.Where(c => c.currencyName == "OMR").Sum(c => c.ActualBudgetTotalAmountYearly);


            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("SumofPlannedUSD", SumofPlannedUSD.ToString()) });
            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("SumofActualUSD", SumofActualUSD.ToString()) });
            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("SumofPlannedOMR", SumofPlannedOMR.ToString()) });
            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("SumofActualOMR", SumofActualOMR.ToString()) });

            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("ReportName", "Planned And Actual Budget Report (Internal)") });
            localReport.DataSources.Add(new ReportDataSource() { Name = "BudgetReport", Value = result.data });
            localReport.EnableExternalImages = true;
            localReport.EnableHyperlinks = true;
            localReport.Refresh();
            mimeType = string.Empty;
            encoding = string.Empty;
            string extension = string.Empty;

            byte[] bytes = localReport.Render(budgetReportDTO.docType, null, out mimeType, out encoding, out extension, out streamIds, out Microsoft.Reporting.NETCore.Warning[] warnings);
            return new ReportPrintDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
        }





        private Dictionary<int,decimal> InitializeMonthlyDictonary()
        {
            Dictionary<int, decimal> obj = new Dictionary<int, decimal>();
            for (int i = 1; i <= 12; i++)
            {
                obj.Add(i, 0);
            }

            return obj;
        }

    }
}
