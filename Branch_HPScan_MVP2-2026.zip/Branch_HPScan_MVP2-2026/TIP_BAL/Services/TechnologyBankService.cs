using Microsoft.Exchange.WebServices.Data;
using Microsoft.Reporting.NETCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using TIP_BAL.Interface;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using static System.Net.Mime.MediaTypeNames;
using static TIP_Common.Enum.Enum;

namespace TIP_BAL.Services
{
    public class TechnologyBankService : ITechnologyBankService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICommonService _commonService;
        public TechnologyBankService(IUnitOfWork unitOfWork, ICommonService commonService)
        {
            _unitOfWork = unitOfWork;
            _commonService = commonService;
        }

        public async Task<List<TechnologyBankDTO>> GetFilterTechnologyBanks(TechnologyBankFilterDTO technologyBankFilterDTO)
        {
            return await _unitOfWork.TechnologyBank.GetFilterTechnologyBanks(technologyBankFilterDTO);
        }

        public async Task<List<TechnologyBankDTO>> GetTechnologyBanks(EmployeeDTO LoggedInUser)
        {
            return await _unitOfWork.TechnologyBank.GetTechnologyBanks(LoggedInUser);
        }

		public async Task<TechnologyBankDTO> GetTechnologyBankByRefId(long challengeId, long challengeRefId)
		{
			return await _unitOfWork.TechnologyBank.GetTechnologyBankByRefId(challengeId, challengeRefId);
		}

        public async Task<TechnologyStatusReportDTO> TechnologyStatusReport(long tech)
        {
            return await _unitOfWork.CTRActualPlanDetails.TechnologyStatusReport(tech);
        }
        public async Task<List<TechnologyBankDTO>> TechnologyStatusTitle(string? search, long? areaId, long? applicationId, long? themeId, string? UCT_FP, long? maturationPhase, bool? isFilter) 
        {
            return await _unitOfWork.CTRActualPlanDetails.TechnologyStatusTitle(search, areaId, applicationId, themeId, UCT_FP, maturationPhase, isFilter);

        }

        public async Task<TechnologyHeatMapReportDTO> TechnologyHeatMAPReport(TechnologyStatusRequestDTO technologyheatmapreportdto)
        {
            return await _unitOfWork.CTRActualPlanDetails.TechnologyHeatMAPReport(technologyheatmapreportdto);

        }
        public async Task<ReportPrintDTO> TechnologyHeatMAPPrint(TechnologyStatusRequestDTO technologyheatmapreportdto)
        {
            TechnologyHeatMapReportDTO result = new TechnologyHeatMapReportDTO();
            result.allData = new List<TechnologyHeatMapDTO>();
            List<PrecisedTaskForReportsDTO> configObj = new List<PrecisedTaskForReportsDTO>();
            result =  await TechnologyHeatMAPReport(technologyheatmapreportdto); ;
            string[] streamIds;
            string mimeType = string.Empty;
            string encoding = string.Empty;
            string filetype = string.Empty;
            string fileName = string.Format("{0}.{1}", "Technology Heat Map Report" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());

            LocalReport localReport = new LocalReport();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Encoding.GetEncoding("windows-1252");
            string fileDirPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? AppContext.BaseDirectory;
            string rdlcFilePath = Path.Combine(fileDirPath, "RDLC", "TechnologyHeatMapReport.rdlc");
            if (!File.Exists(rdlcFilePath))
            {
                rdlcFilePath = Path.Combine(AppContext.BaseDirectory, "RDLC", "TechnologyHeatMapReport.rdlc");
            }
            if (!File.Exists(rdlcFilePath))
            {
                throw new FileNotFoundException($"Technology Heat Map RDLC template was not found at '{rdlcFilePath}'.");
            }
            localReport.ReportPath = rdlcFilePath;
            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("ReportName", "Technology Heat Map Report (Internal)") });
            localReport.DataSources.Add(new ReportDataSource() { Name = "TechnologyHeatMapDTO", Value = result.allData ?? new List<TechnologyHeatMapDTO>() });
            localReport.EnableExternalImages = true;
            localReport.EnableHyperlinks = true;
            localReport.Refresh();
            mimeType = string.Empty;
            encoding = string.Empty;
            string extension = string.Empty;

            string renderFormat = string.IsNullOrWhiteSpace(technologyheatmapreportdto.docType)
                ? PrintType.xls.ToDescription()
                : technologyheatmapreportdto.docType;
            byte[] bytes = localReport.Render(renderFormat, null, out mimeType, out encoding, out extension, out streamIds, out Microsoft.Reporting.NETCore.Warning[] warnings);
            return new ReportPrintDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
        }

        public async Task<ReportPrintDTO> ActionTrackerPrint(ActiionTaskRequestDTO requestdto)
        {
            PrecisedTaskReportMasterDTO result = new PrecisedTaskReportMasterDTO();
            result.allData = new List<PrecisedTaskForReportsDTO>();
            List<PrecisedTaskForReportsDTO> configObj = new List<PrecisedTaskForReportsDTO>();
            result = await _commonService.GetAllTasks(requestdto); ;
            configObj.AddRange(result.allData);
            string[] streamIds;
            string mimeType = string.Empty;
            string encoding = string.Empty;
            string filetype = string.Empty;
            string fileName = string.Format("{0}.{1}", "Action Tracker Report" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());

            LocalReport localReport = new LocalReport();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Encoding.GetEncoding("windows-1252");
            string fileDirPath = Assembly.GetExecutingAssembly().Location.Replace("TIP_BAL.dll", string.Empty);
            string rdlcFilePath = "";
            rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "ActionTrackerReport");
            localReport.ReportPath = rdlcFilePath;
            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("ReportName", "Action Tracker Report (Internal)") });
            localReport.DataSources.Add(new ReportDataSource() { Name = "PrecisedTaskForReportsDTO", Value = result.allData });
            localReport.EnableExternalImages = true;
            localReport.EnableHyperlinks = true;
            localReport.Refresh();
            mimeType = string.Empty;
            encoding = string.Empty;
            string extension = string.Empty;

            byte[] bytes = localReport.Render(requestdto.docType, null, out mimeType, out encoding, out extension, out streamIds, out Microsoft.Reporting.NETCore.Warning[] warnings);
            return new ReportPrintDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
        }

        //
        public async Task<long> AddTechnologyBank(TechnologyBank DTO)
        {
            try
            {
                await _unitOfWork.TechnologyBank.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();

               
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeleteTechnologyBank(long ID, EmployeeDTO employee)
        {
            try
            {
                TechnologyBank? obj = null;
                obj = await _unitOfWork.TechnologyBank.GetFirstOrDefaultAsync(x => x.Id == ID);
                var audittrailObj = new UtlAuditTrail()
                {
                    TableName = "TECHNOLOGY_BANK",
                    Action = "DELETE",
                    ActionBy = employee.DISPLAY_NAME + " " + employee.COMPANY_NUMBER,
                    ActionOn = System.DateTime.Today.ToString(),
                    Description = JsonSerializer.Serialize(obj),
                };
                if (obj != null)
                {

                    _unitOfWork.TechnologyBank.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    await _commonService.Log(audittrailObj);
                    return result > 0 ? result : 1;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateTechnologyBank(TechnologyBank DTO)
        {
            try
            {
                TechnologyBank? obj = null;
                obj = await _unitOfWork.TechnologyBank.GetFirstOrDefaultAsync(x => x.Id == DTO.Id);
                if (obj != null)
                {
                   
                    obj.Id = DTO.Id;
                    obj.Title=DTO.Title;
                    obj.Area = DTO.Area;
                    obj.Description = DTO.Description;
                    obj.ContactFp = DTO.ContactFp;
                    obj.ContactEmail = DTO.ContactEmail;
                    obj.Theme = DTO.Theme;
                    obj.SubTheme=DTO.SubTheme;
                    obj.Source = DTO.Source;
                    obj.UpdatedBy = DTO.UpdatedBy;
                    obj.UpdatedByRef = DTO.UpdatedByRef;
                    obj.UpdatedOn = DTO.UpdatedOn;
                    obj.Application = DTO.Application;
                    obj.AssetId=DTO.AssetId;
                    obj.ClusterId=DTO.ClusterId;
                  _unitOfWork.TechnologyBank.Update(obj);
                }
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
