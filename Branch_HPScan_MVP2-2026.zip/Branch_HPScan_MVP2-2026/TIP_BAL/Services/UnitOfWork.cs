﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using TIP_BAL.Interface;
using TIP_Core;
using TIP_CORE.Entities;
using TIP_DAL.Interface;
using TIP_DAL.Interface.Admin;
using TIP_DAL.Interface.Base;
using TIP_DAL.Repository;
using TIP_DAL.Repository.Admin;

namespace TIP_BAL.Services
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext dbContext;
        private readonly HtmlEncoder htmlEncoder;
        public UnitOfWork(AppDbContext dbContext,HtmlEncoder htmlEncoder, IConfiguration configuration)
        {
            this.dbContext = dbContext;
            this.htmlEncoder = htmlEncoder;
            Employee = new EmployeeRepository(dbContext);
            UserRole = new UserRoleRepository(dbContext);
            TypeCodeMaster = new TypeCodeMasterRepository(dbContext);
            TechnologyBank = new TechnologyBankRepository(dbContext);
            PainAreas = new PainAreasRepository(dbContext);
            BTMAssesment = new BTMAssesmentRepository(dbContext);
            ChallengeCheckList = new ChallengeCheckListRepository(dbContext);
            ChallengeRegistration = new ChallengeRegistrationRepository(dbContext,htmlEncoder,configuration);
            ChecklistChallengeLnk = new ChecklistChallengeLnkRepository(dbContext);
            ChallengeDetail = new ChallengeDetailRepository(dbContext);
            ChallengeSolutionReviewers = new ChallengeSolutionReviewersRepository(dbContext);
            ChallengeVendorScreening = new ChallengeVendorScreeningRepository(dbContext);
            EmailKeyword = new EmailKeywordRepository(dbContext);
            EmailTemplateConfiguration = new EmailTemplateConfigurationRepository(dbContext);
            ChallengeVOT = new ChallengeVOTRepository(dbContext);
            Configuration = new ConfigurationRepository(dbContext);
            AuditTrail = new AuditTrailRepository(dbContext);
            TrAuditLog = new TrAuditLogRepository(dbContext);
            ChallengeResponse = new ChallengeResponseRepository(dbContext);
            ChallengeResponseQuestion = new ChallengeResponseQuestionRepository(dbContext);
            ChallengeResponseTechnology = new ChallengeResponseTechnologyRepository(dbContext);
            ChallengeResponseReview = new ChallengeResponseReviewRepository(dbContext);
            EmailRepo = new EmailRepoRepository(dbContext);
            DocumentRepo = new DocumentRepoRepository(dbContext,htmlEncoder);
            ExternalUser = new VendorDetailRepository(dbContext);
            challengePublication = new ChallengePublicationRepository(dbContext);
            challengeSources = new ChallengeSourcesRepository(dbContext);
            Ctr = new CtrRepository(dbContext);
            TasksRepo = new TaskRepoRepository(dbContext);
            CtrTrialFp = new CtrTrialFpRepository(dbContext);
            RoleToUser = new RoleToUserRepository(dbContext);
            CtrAdditionalSolutions = new CtrAdditionalSolutionsRepository(dbContext);
            CtrVot = new CtrVotRepository(dbContext);
            CtrFlowHistory = new CtrFlowHistoryRepository(dbContext);
            CtrTrialRisk = new CtrTrialRiskRepository(dbContext);
            CtrApprovalList = new CtrApprovalListRepository(dbContext);
            CtrApprovalListHis = new CtrApprovalListHisRepository(dbContext);
            AdJobDataList = new AdJobDataRepository(dbContext);
            CtrSuccessCriterion = new CtrSuccessCriterionRepository(dbContext);
            CtrTrial = new CtrTrialRepository(dbContext);
            CtrTrialYear = new CtrTrialYearRepository(dbContext);
            CtrPotentialImpacted = new CtrPotentialImpactedRepository(dbContext);
            CtrBudget = new CtrBudgetRepository(dbContext);
            VendortoChrQuery = new VendortoChrQueryRepository(dbContext);
            VendorQueryResponse = new VendorQueryResponseRepository(dbContext);
            PDOtoVendorQuery = new PDOToVendorQuriesRepository(dbContext);
            PDOQueryResponse = new PDOToVendorQuryResponseRepository(dbContext);
            Pir = new PirRepository(dbContext);
            PirTrialFp = new PirTrialFpRepository(dbContext);
            PirFlowHistory = new PirFlowHistoryRepository(dbContext);
            PirSupportingMembers = new PirSupportingMembersRepository(dbContext);
            PirLessonLearnt = new PirLessonLearntRepository(dbContext);
            PirAssessmentTrialResult = new PirAssessmentTrialResultRepository(dbContext);
            PirTrialCandidate = new PirTrialCandidateRepository(dbContext);
			PirVot = new PirVotRepository(dbContext);
            PirImpactedExistingContract = new PirImpactedExistingContractsRepository(dbContext);
            PirDeploymentStaircase = new PirDeploymentStaircaseRepository(dbContext);
            PirActionPlan = new PirActionPlanRepository(dbContext);
            PirSummary = new PirSummaryRepository(dbContext);
            CtrDeploymentStaircase = new CtrDeploymentStaircaseRepository(dbContext);
			ChallengeResponseSr = new ChallengeResponseSrRepository(dbContext);		
            PirApprovalList =  new PirApprovalListRepository(dbContext);
            PirApprovalListHis = new PirApprovalListHisRepository(dbContext);
            DocLink = new DocLinkRepository(dbContext);
            RabitahVendor = new RabitahVendorsRepository(dbContext);
            TmRabitahContract = new RabitahContractRepository(dbContext);
            CtrSchedulePrice = new CtrSchedulePriceRepository(dbContext);
            execution = new ExecutionInitiationRepository(dbContext);
            budgetConfirmation = new ExecutionBudgetConfirmationRepository(dbContext);
            budgetCostCentre = new ExecutionBudgetCostCentreRepository(dbContext);
            CtrPercentageCompletion = new CtrPercentageCompletionRepository(dbContext);
			EmailEscalation = new EmailEscalationRepository(dbContext);
            executionTrialcandidate = new Exec_TrialCandiRepository(dbContext);
            executionTrialFp = new Exec_TrialfpsRepository(dbContext);
            executionPotentialValue = new ExecutionPotentialValueRepository(dbContext);
            AssetFP = new AssetFPRespository(dbContext);
            ClusterFP = new ClusterFPRespository(dbContext);
            executionplannedTimeline = new ExecutionPlannedTimelineRepository(dbContext);
            executionplanned = new ExecutionPlannedRepository(dbContext);
            ExeFlowHistory = new ExeFlowHistoryRepository(dbContext);
            actualplanned = new ExecutionActualPlanRepository(dbContext);
            ExeInvoice = new ExeInvoiceRepository(dbContext);
            ExeInvoiceFlowHistory = new ExeInvoiceFlowHistoryRepository(dbContext);
            ErroLog = new ErroLogRepository(dbContext);
            UserLogs = new UserLogRepository(dbContext);
            UserPaArchieve = new TmUserPaArchieveRepository(dbContext);
            ChlFlowHistory = new ChlFlowHistoryRepository(dbContext);
            SRFlowHistory = new SRFlowHistoryRepository(dbContext, htmlEncoder);
            CtrTrialCandidate = new CtrTrialCandidateRepository(dbContext);
            CTRTechConfig = new CtrTechConfigurationRepository(dbContext);
            CTRPlanDetails = new CTRPlanDetailsRepository(dbContext);
            CTRActualPlanDetails = new CTRActualPlanDetailsRepository(dbContext);
        	DepVot = new DepVotRepository(dbContext);
			DepInitiation = new DepInitiationRepository(dbContext);
		
            UserSettings = new UserSettingsEFRepository(dbContext);
            CtrPM = new CTRProjectMembersRepository(dbContext);
            TechnologyKpiConfig = new TechnologyKPIConfigRepository(dbContext);
        }
        public ITechnologyKpiConfigRepository TechnologyKpiConfig { get; }
        public ICtrTrialCandidateRepository CtrTrialCandidate { get; }
        public ICTRProjectMembersRepository CtrPM { get; }
        
        public IVendortoChrQueryRepository VendortoChrQuery { get; }
        public IVendorQueryResponseRepository VendorQueryResponse { get; }
        public IPDOToVendorQuriesRepository PDOtoVendorQuery { get; }
        public IPDOToVendorQuryResponseRepository PDOQueryResponse { get; }
        public IEmployeeRepository Employee { get; private set; }
        public IUserRoleRepository UserRole { get; private set; }

        public ITypeCodeMasterRepository TypeCodeMaster { get; private set; }
        public IBTMAssesmentRepository BTMAssesment { get; private set; }

        public ITechnologyBankRepository TechnologyBank { get; private set; }
        public IPainAreasRepository PainAreas { get; private set; }

        public IChallengeCheckListRepository ChallengeCheckList { get; private set; }

        public IChallengeRegistrationRepository ChallengeRegistration { get; private set; }

        public IChecklistChallengeLnkRepository ChecklistChallengeLnk { get; private set; }

        public IChallengeDetailRepository ChallengeDetail { get; private set; }

        public IChallengeSolutionReviewersRepository ChallengeSolutionReviewers { get; private set; }
        public IChallengeVendorScreeningRepository ChallengeVendorScreening { get; private set; }
        public IEmailKeywordRepository EmailKeyword { get; private set; }
        public IEmailTemplateConfigurationRepository EmailTemplateConfiguration { get; private set; }
        public IConfigurationRepository Configuration { get; private set; }

        public IAuditTrailRepository AuditTrail { get; private set; }
        public ITrAuditLogRepository TrAuditLog { get; private set; }
        public IChallengeVOTRepository ChallengeVOT { get; private set; }
        public IChallengeResponseRepository ChallengeResponse { get; private set; }
        public IChallengeResponseQuestionRepository ChallengeResponseQuestion { get; private set; }
        public IChallengeResponseTechnologyRepository ChallengeResponseTechnology { get; private set; }
        public IChallengeResponseReviewRepository ChallengeResponseReview { get; private set; }
        public IEmailRepoRepository EmailRepo { get; private set; }
        public IDocumentRepoRepository DocumentRepo { get; private set; }
        public ICtrRepository Ctr { get; private set; }

        public ITaskRepoRepository TasksRepo { get; private set; }

        public IVendorDetailRepository ExternalUser { get; private set; }
        public IChallengePublicationRepository challengePublication { get; private set; }

        public IChallengeSourcesRepository challengeSources { get; private set; }
        public ICtrTrialFpRepository CtrTrialFp { get; private set; }
        public IRoleToUserRepository RoleToUser { get; private set; }
        public ICtrAdditionalSolutionsRepository CtrAdditionalSolutions { get; private set; }
        public ICtrFlowHistoryRepository CtrFlowHistory { get; private set; }
        public ICtrVotRepository CtrVot { get; private set; }
        public ICtrTrialRiskRepository CtrTrialRisk { get; private set; }

        public ICtrApprovalListRepository CtrApprovalList { get; private set; }
        public ICtrApprovalListHisRepository CtrApprovalListHis { get; private set; }

        public IAdJobDataRepository AdJobDataList { get; private set; }
        public ICtrSuccessCriterionRepository CtrSuccessCriterion { get; private set; }
        public ICtrTrialRepository CtrTrial { get; private set; }
        public ICtrTrialYearRepository CtrTrialYear { get; private set; }

        public IUserSettingsEFRepository UserSettings { get; private set; }
        public IAssetFPRespository AssetFP { get; private set; }
        public IClusterFPRespository ClusterFP { get; private set; }
        public ICtrBudgetRepository CtrBudget { get; private set; }

        public ICtrPotentialImpactedRepository CtrPotentialImpacted { get; private set; }
        public IPirRepository Pir { get; private set; }
        public IPirTrialFpRepository PirTrialFp { get; private set; }
        public IPirFlowHistoryRepository PirFlowHistory { get; private set; }
        public IPirSupportingMembersRepository PirSupportingMembers { get; private set; }
        public IPirLessonLearntRepository PirLessonLearnt { get; }
        public IPirAssessmentTrialResultRepository PirAssessmentTrialResult { get; }
        public IPirTrialCandidateRepository PirTrialCandidate { get; }
		public IPirVotRepository PirVot { get; private set; }
		public IPirImpactedExistingContractsRepository PirImpactedExistingContract { get; private set; }
		public IPirDeploymentStaircaseRepository PirDeploymentStaircase { get; private set; }

		public IPirActionPlanRepository PirActionPlan { get; private set; }
		public IPirSummaryRepository PirSummary { get; private set; }

        public ICtrDeploymentStaircaseRepository CtrDeploymentStaircase { get; private set; }
        public IChallengeResponseSrRepository ChallengeResponseSr { get; private set; }
        public IPirApprovalListRepository PirApprovalList { get; private set; }
        public IPirApprovalListHisRepository PirApprovalListHis { get; private set; }

        public IDocLinkRepository DocLink { get; private set; }

        public IRabitahVendorsRepository RabitahVendor { get; private set; }
        public IRabitahContractRepository TmRabitahContract { get; private set; }
        public ICtrSchedulePriceRepository CtrSchedulePrice { get; private set; }
        public IExecutionInitiationRepository execution { get; private set; }
        public IExecutionBudgetConfirmationRepository budgetConfirmation { get; private set; }
        public IExecutionBudgetCostCentreRepository budgetCostCentre { get; private set; }
        public ICtrPercentageCompletionRepository CtrPercentageCompletion { get; }
        public IEmailEscalationRepository EmailEscalation { get; }
        public IExec_TrialCandiRepository executionTrialcandidate { get; private set; }
        public IExec_TrialfpsRepository executionTrialFp { get; private set; }
        public IExecutionPotentialValueRepository executionPotentialValue { get; private set; }
        public IExecutionPlannedTimelineRepository executionplannedTimeline { get; private set; }
        public IExecutionPlannedRepository executionplanned { get; private set; }
        public IExecutionActualPlanRepository actualplanned { get; private set; }
        
        public IExeFlowHistoryRepository ExeFlowHistory { get; private set; }
        public IExeInvoiceRepository ExeInvoice { get; private set; }
        public IExeInvoiceFlowHistoryRepository ExeInvoiceFlowHistory { get; private set; }
        public IErroLogRepository ErroLog { get; private set; }
        public IUserLogRepository UserLogs { get; private set; }
        public ITmUserPaArchieveRepository UserPaArchieve { get; private set; }

        public ICtrTechConfigurationRepository CTRTechConfig { get; private set; }

        public ICTRPlanDetailsRepository CTRPlanDetails { get; private set; }
        public ICTRActualPlanDetailsRepository CTRActualPlanDetails { get; private set; }



        public IChlFlowHistoryRepository ChlFlowHistory { get; private set; }
        public ISRFlowHistoryRepository SRFlowHistory { get; private set; }

        public IDepVotRepository DepVot { get; private set; }
		public IDepInitiationRepository DepInitiation { get; private set; }

		public void Dispose()
        {
            // AppDbContext is scoped and owned by DI — do not dispose it here.
            // Transient UnitOfWork instances share one scoped context; disposing it
            // from any UnitOfWork causes ObjectDisposedException for other consumers.
        }

        public async Task<int> SaveAsync()
        {
            return await dbContext.SaveChangesAsync();
        }
    }
}
