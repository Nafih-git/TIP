﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_BAL.Interface;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_BAL.Services
{
    public class ChallengeCheckListService: IChallengeCheckListService
    {
        private readonly IUnitOfWork _unitOfWork;
        public ChallengeCheckListService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<List<ChallengeChecklistDTO>> GetCheckLists()
        {
            return await _unitOfWork.ChallengeCheckList.GetCheckLists();
        }

        public async Task<long> AddNewChallenge(ChallengeRegistration challengeDTO)
        {
            try
            {
                challengeDTO.Id = 0;
                await _unitOfWork.ChallengeRegistration.AddAsync(challengeDTO);
                long result = await _unitOfWork.SaveAsync();
                if (result <= 0 || challengeDTO.Id <= 0)
                {
                    return 0;
                }

                var chrRole = await _unitOfWork.UserRole.GetFirstOrDefaultAsync(x => x.Param == "CHR");
                if (chrRole != null)
                {
                    var allowUser = await _unitOfWork.RoleToUser.GetAllAsync(x => x.UserId == challengeDTO.RequestedBy && x.RoleId == chrRole.RoleId);
                    if (allowUser == null || !allowUser.Any())
                    {
                        TmRoleToUserMapping newRtU = new TmRoleToUserMapping()
                        {
                            MapingId = 0,
                            UserId = challengeDTO.RequestedBy,
                            RoleId = chrRole.RoleId,
                            IsActive = 1,
                            CreatedBy = challengeDTO.RequestedBy,
                            CreatedOn = DateTime.Now
                        };
                        await _unitOfWork.RoleToUser.AddAsync(newRtU);
                    }
                }

                var obj = await _unitOfWork.ChallengeRegistration.GetFirstOrDefaultAsync(x => x.Id == challengeDTO.Id);
                if (obj != null)
                {
                    obj.ReferenceNo = "CH-" + challengeDTO.Id.ToString().PadLeft(6, '0');
                    _unitOfWork.ChallengeRegistration.Update(obj);
                }

                await _unitOfWork.SaveAsync();
                return challengeDTO.Id;
            }
            catch
            {
                throw;
            }
        }

        public async Task<long> AddChallengeCheckListLnks(List<ChecklistChallengeLnk> checklists)
        {
            try
            {
                await _unitOfWork.ChecklistChallengeLnk.AddRangeAsync(checklists);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch
            {
                throw;
            }
        }

		public async Task<long> AddOrUpdateQuestion(ChallengeChecklist challengeChecklist)
		{
			try
			{
				if (string.IsNullOrWhiteSpace(challengeChecklist.Question))
				{
					throw new ArgumentException("Question is required.");
				}

				if (challengeChecklist.Id > 0)
				{
					var obj = await _unitOfWork.ChallengeCheckList.GetFirstOrDefaultAsync(x => x.Id == challengeChecklist.Id);
					if (obj == null)
					{
						throw new InvalidOperationException("Question not found.");
					}

					obj.Question = challengeChecklist.Question;
					obj.UpdatedBy = challengeChecklist.UpdatedBy;
					obj.UpdatedRef = challengeChecklist.UpdatedRef;
					obj.UpdatedOn = challengeChecklist.UpdatedOn;
					_unitOfWork.ChallengeCheckList.Update(obj);
					await _unitOfWork.SaveAsync();
					return obj.Id;
				}

				challengeChecklist.Id = 0;
				await _unitOfWork.ChallengeCheckList.AddAsync(challengeChecklist);
				await _unitOfWork.SaveAsync();

				if (challengeChecklist.Id <= 0)
				{
					var saved = await _unitOfWork.ChallengeCheckList.GetFirstOrDefaultAsync(
						x => x.Question == challengeChecklist.Question && x.IsActive);
					return saved?.Id ?? 0;
				}

				return challengeChecklist.Id;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public async Task<long> DeleteQuestion(long id)
		{
			try
			{
                ChallengeChecklist obj = null;
                obj = await _unitOfWork.ChallengeCheckList.GetFirstOrDefaultAsync(x => x.Id == id);
                if (obj == null)
                {
                    throw new InvalidOperationException("Question not found.");
                }

			    obj.IsActive= false;
			    _unitOfWork.ChallengeCheckList.Update(obj);
			    long result = await _unitOfWork.SaveAsync();
                return obj.Id;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
