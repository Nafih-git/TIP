﻿using System.Collections.Generic;
using System;
using System.ComponentModel;
using System.Threading.Tasks;
using TIP_BAL.Interface;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_Common;
using TIP_Common.Admin;
using TIP_Common.Enum;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Repository;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using TIP_Core;
using static TIP_Common.Enum.Enum;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Reporting.Map.WebForms.BingMaps;
using System.Security;
using TIP_API.DTO.Admin;
using Microsoft.Reporting.NETCore;
using System.Reflection;
using System.Text;
using System.Xml.Linq;
using TIP_CORE.Admin;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using Microsoft.Exchange.WebServices.Data;

namespace TIP_BAL.Services
{
    public class ChallengeService : IChallengeService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICommonService _commonService;
        private readonly IBTMPainAreaService _painareaService;
        private readonly IConfiguration _configuration;

        public ChallengeService(IUnitOfWork unitOfWork, ICommonService commonService, IConfiguration configuration, IBTMPainAreaService painareaService)
        {
            _unitOfWork = unitOfWork;
            _commonService = commonService;
            _configuration = configuration;
            _painareaService = painareaService;
        }

        public async Task<long> ChallengeResistrationForm(ChallengeDetail challengeDetail)
        {
            try
            {
                if (challengeDetail.Id > 0)
                {
                    ChallengeDetail obj = null;
                    obj = await _unitOfWork.ChallengeDetail.GetFirstOrDefaultAsync(x => x.Id == challengeDetail.Id);
                    obj.ChallengeId = challengeDetail.ChallengeId;
                    obj.Title = challengeDetail.Title;
                    obj.ApplicationId = challengeDetail.ApplicationId;
                    obj.AreaId = challengeDetail.AreaId;
                    obj.Cfdh = challengeDetail.Cfdh;
                    obj.CurrentPractices = challengeDetail.CurrentPractices;
                    obj.KeyRequirments = challengeDetail.KeyRequirments;
                    obj.MaturityLevelId = challengeDetail.MaturityLevelId;
                    obj.OperatingEnvelopes = challengeDetail.OperatingEnvelopes;
                    obj.PotentialScoreForecast = challengeDetail.PotentialScoreForecast;
                    obj.ProblemStatement = challengeDetail.ProblemStatement;
                    obj.QueryLastdate = challengeDetail.QueryLastdate;
                    obj.ResponseLastdate = challengeDetail.ResponseLastdate;
                    obj.VendorSubmissionStartdate = challengeDetail.VendorSubmissionStartdate;
                    obj.ValueDrivers = challengeDetail.ValueDrivers;
                    obj.ThemeId = challengeDetail.ThemeId;
                    obj.SubThemeId = challengeDetail.SubThemeId;
                    obj.ScoutingKeywords = challengeDetail.ScoutingKeywords;
                    obj.TechnicalSpec = challengeDetail.TechnicalSpec;
                    obj.Hserisk = challengeDetail.Hserisk;
                    obj.Productionincrease = challengeDetail.Productionincrease;
                    obj.Costreduction = challengeDetail.Costreduction;
                    obj.Co2reduction = challengeDetail.Co2reduction;
                    obj.Overallscore = challengeDetail.Overallscore;
                    obj.RequestType = challengeDetail.RequestType;
                    obj.Pillar = challengeDetail.Pillar;
                    obj.ScoutingKeywords = challengeDetail.ScoutingKeywords;
                    obj.AssetId = challengeDetail.AssetId;
                    obj.ClusterId = challengeDetail.ClusterId;

                    _unitOfWork.ChallengeDetail.Update(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return obj.Id;
                }
                else
                {
                    challengeDetail.Id = 0;
                    await _unitOfWork.ChallengeDetail.AddAsync(challengeDetail);
                    long result = await _unitOfWork.SaveAsync();
                    return challengeDetail.Id;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<RequestorDTO> GetRequestorInfo(long challengeRegId)
        {
            try
            {
                return await _unitOfWork.ChallengeRegistration.GetRequestorInfo(challengeRegId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateChallengeResistrationStatus(string status, long challengeRegId, EmployeeDTO employeeDTO, string cfdh = "", string Comments = "")
        {
            try
            {
                TypeCodeMaster challengeStatus = null;
                challengeStatus = await _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type.ToUpper() == TypeCodes.ChallengeStatus && x.Param1.ToUpper() == status.ToUpper());
                ChallengeRegistration obj = null;
                obj = await _unitOfWork.ChallengeRegistration.GetFirstOrDefaultAsync(x => x.Id == challengeRegId);

                EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                emailSendConfigDTO.RecipientsNames = new List<string>();
                if (status == ChallengeStatus.Submitted)
                {
                    emailSendConfigDTO.moduleId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.EmailTemplate, EmailModules.BTICHL).Result.Id;// 76;
                    emailSendConfigDTO.templateId = 3;
                    emailSendConfigDTO.toRecipients = new List<string>();

                    

                    EmployeeDTO empdata = await _unitOfWork.Employee.GetByMuNumber(cfdh);
                    if (empdata != null)
                    {
                        emailSendConfigDTO.toRecipients.Add(empdata.EMAIL_ADDRESS);
                        emailSendConfigDTO.RecipientsNames.Add(empdata.DISPLAY_NAME);
                    }
                }
                else if (status == ChallengeStatus.Reviewed)
                {
                    emailSendConfigDTO.moduleId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.EmailTemplate, EmailModules.BTICHL).Result.Id; //76;
                    emailSendConfigDTO.templateId = 6;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    

                    EmployeeDTO empdata = await _unitOfWork.Employee.GetByMuNumber(obj.RequestedBy);
                    if (empdata != null)
                    {
                        emailSendConfigDTO.toRecipients.Add(empdata.EMAIL_ADDRESS);
                        emailSendConfigDTO.RecipientsNames.Add(empdata.DISPLAY_NAME);
                    }
                }
                else if (status == ChallengeStatus.SentBack && obj.StatusId == _commonService.GetMasterDataByParentAndParam1(TypeCodes.ChallengeStatus, ChallengeStatus.Submitted).Result.Id)
                {
                    emailSendConfigDTO.moduleId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.EmailTemplate, EmailModules.BTICHL).Result.Id; // 76;
                    emailSendConfigDTO.templateId = 8;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    

                    EmployeeDTO empdata = await _unitOfWork.Employee.GetByMuNumber(obj.RequestedBy);
                    if (empdata != null)
                    {
                        emailSendConfigDTO.toRecipients.Add(empdata.EMAIL_ADDRESS);
                        emailSendConfigDTO.RecipientsNames.Add(empdata.DISPLAY_NAME);
                    }
                }
                else if (status == ChallengeStatus.SentBack && obj.StatusId == _commonService.GetMasterDataByParentAndParam1(TypeCodes.ChallengeStatus, ChallengeStatus.Reviewed).Result.Id)
                {
                    emailSendConfigDTO.moduleId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.EmailTemplate, EmailModules.BTICHL).Result.Id; // 76;
                    emailSendConfigDTO.templateId = 10;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    
                    EmployeeDTO empdata = await _unitOfWork.Employee.GetByMuNumber(obj.RequestedBy);
                    if (empdata != null)
                    {
                        emailSendConfigDTO.toRecipients.Add(empdata.EMAIL_ADDRESS);
                        emailSendConfigDTO.RecipientsNames.Add(empdata.DISPLAY_NAME);
                    }
                }
                else if (status == ChallengeStatus.Rejected)
                {
                    emailSendConfigDTO.moduleId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.EmailTemplate, EmailModules.BTICHL).Result.Id; // 76;
                    emailSendConfigDTO.templateId = 12;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    
                    EmployeeDTO empdata = await _unitOfWork.Employee.GetByMuNumber(obj.RequestedBy);
                    if (empdata != null)
                    {
                        emailSendConfigDTO.toRecipients.Add(empdata.EMAIL_ADDRESS);
                        emailSendConfigDTO.RecipientsNames.Add(empdata.DISPLAY_NAME);
                    }
                }

                obj.StatusId = challengeStatus.Id;
                obj.UpdatedOn = DateTime.Now;
                obj.UpdatedBy = employeeDTO.COMPANY_NUMBER;
                obj.UpdatedByRef = employeeDTO.REFERENCE_INDICATOR;
                obj.UpdatedRoleId = employeeDTO.ACTIVE_R_ID;
                obj.ActionComment = Comments;
                _unitOfWork.ChallengeRegistration.Update(obj);
                await _unitOfWork.SaveAsync();

                EmailSendConfigDTO res = null;
                res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                await AddChlFlowHistoryAsync(challengeRegId, challengeStatus.Id, Comments, employeeDTO.ACTIVE_R_ID.Value, employeeDTO.DISPLAY_NAME + " " + challengeStatus.Name + " the Challenge", employeeDTO);
                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                    await MapChallengeForEmail(res, obj.Id);

                return obj.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private async System.Threading.Tasks.Task AddChlFlowHistoryAsync(long challengeId, long statusId, string comments, long currentRoleId, string descInfo, EmployeeDTO? LoggedInUser)
        {
            ChlFlowHistory obj = new ChlFlowHistory()
            {
                ChallengeId = challengeId,
                StatusId = statusId,
                Comments = comments,
                RoleId = currentRoleId,
                UserId = LoggedInUser?.COMPANY_NUMBER,
                CreatedOn = DateTime.Now,
                DescInfo = descInfo,
            };

            await AddChallengeFlowHistory(obj);
        }

        public async Task<List<ChallengeVendorScreeningDTO>> GetAllVendorScreening(long challengeId)
        {
            return await _unitOfWork.ChallengeVendorScreening.GetAllVendorScreening(challengeId);
        }
        public async Task<ChallengeVOT_DTO> GetChallengeVOT(long challengeId)
        {
            return await _unitOfWork.ChallengeVOT.GetVOTDetails(challengeId);
        }
        public async Task<List<ChallengeQuestionaire_DTO>> GetChallengeQuestionaire(long challengeId)
        {
            return await _unitOfWork.ChallengeVOT.GetChallengeQuestionaire(challengeId);
        }

        public async Task<long> UpdateChallengeUCTOwnership(long challengeRegId, EmployeeDTO employeeDTO)
        {
            try
            {

                ChallengeRegistration obj = null;
                obj = await _unitOfWork.ChallengeRegistration.GetFirstOrDefaultAsync(x => x.Id == challengeRegId);

                obj.UpdatedOn = DateTime.Now;
                obj.UpdatedBy = employeeDTO.COMPANY_NUMBER;
                obj.UpdatedByRef = employeeDTO.REFERENCE_INDICATOR;
                obj.UpdatedRoleId = employeeDTO.ACTIVE_R_ID;
                obj.ActionComment = "Taken Ownership";
                obj.UctFp = employeeDTO.COMPANY_NUMBER;
                _unitOfWork.ChallengeRegistration.Update(obj);
                long result = await _unitOfWork.SaveAsync();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
       public async Task<List<ConfigurationDTO>> GetVOTConfigurations()
        {
            var configurationDTO = await _unitOfWork.Configuration.GetConfigurationByType("vot");
            return configurationDTO;
        }

        public async Task<long> AddOrUpdateVOT(ChallengeVot challengeVOT)
        {
            
            await DeleteVOT(challengeVOT.ChallengeId);
            challengeVOT.Id = 0;
            await _unitOfWork.ChallengeVOT.AddAsync(challengeVOT);
            long result = await _unitOfWork.SaveAsync();
            if (result > 0)
            {
                return result;
            }

            return result;
        }


        public async Task<long> AddOrUpdateVendorScreening(List<ChallengeVendorScreening> challengeVendorScreenings, bool isEdit)
        {
            try
            {
                if (isEdit)
                    await DeleteVendorScreening(challengeVendorScreenings[0].ChallengeId, challengeVendorScreenings[0].ChallengeDetailId);
                foreach (var item in challengeVendorScreenings)
                {
                    item.Id = 0;
                }
                await _unitOfWork.ChallengeVendorScreening.AddRangeAsync(challengeVendorScreenings);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeleteVendorScreening(long challengeId, long challengeDetailId)
        {
            try
            {
                List<ChallengeVendorScreening> obj = null;
                obj = (List<ChallengeVendorScreening>)await _unitOfWork.ChallengeVendorScreening.GetAllAsync(x => x.ChallengeId == challengeId && x.ChallengeDetailId == challengeDetailId);
                if (obj.Count > 0 && obj != null)
                {
                    _unitOfWork.ChallengeVendorScreening.RemoveRange(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeleteVOT(long challengeId)
        {
            try
            {
                List<ChallengeVot> obj = null;
                obj = (List < ChallengeVot > )await _unitOfWork.ChallengeVOT.GetAllAsync(x => x.ChallengeId == challengeId);
                if (obj != null)
                {
                    _unitOfWork.ChallengeVOT.RemoveRange(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddVendorScreening(ChallengeVendorScreening challengeVendorScreening)
        {
            try
            {
                await _unitOfWork.ChallengeVendorScreening.AddAsync(challengeVendorScreening);
                long result = await _unitOfWork.SaveAsync();
                return challengeVendorScreening.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateVendorScreening(ChallengeVendorScreening challengeVendorScreening)
        {
            try
            {
                ChallengeVendorScreening obj = null;
                obj = await _unitOfWork.ChallengeVendorScreening.GetFirstOrDefaultAsync(x => x.Id == challengeVendorScreening.Id);
                obj.UpdatedBy = challengeVendorScreening.UpdatedBy;
                obj.UpdatedOn = challengeVendorScreening.UpdatedOn;
                obj.UpdatedByRef = challengeVendorScreening.UpdatedByRef;
                obj.ChallengeId = challengeVendorScreening.ChallengeId;
                obj.ChallengeDetailId = challengeVendorScreening.ChallengeDetailId;
                obj.Sequence = challengeVendorScreening.Sequence;
                obj.Question = challengeVendorScreening.Question;
                _unitOfWork.ChallengeVendorScreening.Update(obj);
                long result = await _unitOfWork.SaveAsync();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeleteVendorScreening(long id)
        {
            try
            {
                ChallengeVendorScreening obj = null;
                obj = await _unitOfWork.ChallengeVendorScreening.GetFirstOrDefaultAsync(x => x.Id == id);
                if (obj != null)
                {
                    _unitOfWork.ChallengeVendorScreening.Remove(obj);
                    int result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ChallengeRegistrationDetailDTO> GetChallengeRegistrationDetailDTO(EmployeeDTO muNo)
        {
            try
            {
                return await _unitOfWork.ChallengeRegistration.GetChallengeRegistrationDetailDTO(muNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ChallengeRegistrationDetailDTO> GetChallengeRegistrationDetailDTO()
        {
            try
            {
                return await _unitOfWork.ChallengeRegistration.GetChallengeRegistrationDetailDTO();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<ChallengeReviewDTO> GetChallengesForReview(long? RoleID, string userMU)
        {
            try
            {
                return await _unitOfWork.ChallengeRegistration.GetChallengesForReview(RoleID, userMU);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<LatestChallengeDTO>> LatestPublishChallenges()
        {
            try
            {
                return await _unitOfWork.ChallengeRegistration.LatestPublishChallenges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<ChallengesForExternalDTO> LatestPublishChallengesForExternal(long sourceId, long participant)
        {
            try
            {
                ChallengesForExternalDTO obj = new ChallengesForExternalDTO();
                obj.newChallenges = await _unitOfWork.ChallengeRegistration.LatestPublishChallengesForExternal(sourceId, participant);
                obj.participatedChallenges = await _unitOfWork.ChallengeRegistration.ParticipatedChallengesForExternal(sourceId, participant);
                return obj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<LatestChallengeForExternalDTO>> AllPublishedChallengesForExternal()
        {
            try
            {
                return await _unitOfWork.ChallengeRegistration.AllPublishedChallengesForExternal();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<QueryResponseDTO>> GetVendorQueryResponseForExternal(string cfcode)
        {
            try
            {
                List<QueryResponseDTO> obj = new List<QueryResponseDTO>();
                long responseId = (long)CryptoExtensions.Decrypt(cfcode).ToInt64();
                var chId = _unitOfWork.ChallengeResponse.GetAsync(responseId).Result.ChallengeRegistrationId;
                obj = await _unitOfWork.ChallengeRegistration.GetVendorQueryResponseForExternal(responseId, chId);
                return obj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<LocalSolutionDTO> GetLocalDetails(string cfcode)
        {
            try
            {
                LocalSolutionDTO obj = new LocalSolutionDTO();
                long responseId = (long)CryptoExtensions.Decrypt(cfcode).ToInt64();
                obj = await _unitOfWork.ChallengeRegistration.GetLocalDetails(responseId);
                var responseFiles = await _commonService.GetAllFilesByLinkId(responseId, "ChallengeResponse", false);
                var flowHistory = await GetSRHistoryById(responseId);
                if (flowHistory != null) flowHistory = flowHistory.Where(x => x.isExternal == true).OrderByDescending(x => x.CreatedOn).ToList();
                obj.responseFiles = responseFiles;
                obj.sRFlowHistories = flowHistory;
                return obj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<LatestChallengeForExternalDTO> ChallengeDetailsByResponseId(long responseID)
        {
            try
            {
                return await _unitOfWork.ChallengeRegistration.ChallengeDetailsByResponseId(responseID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<VendorResponseDetailsDTO> GetVendorResponseDetailsForExternal(string cfcode)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(cfcode))
                    throw new ArgumentException("cfcode is required.");

                // Strip accidental whitespace / URL artifacts before hex decrypt
                cfcode = Uri.UnescapeDataString(cfcode.Trim());

                if (!System.Text.RegularExpressions.Regex.IsMatch(cfcode, @"^[0-9A-Fa-f]+$") || cfcode.Length % 2 != 0)
                    throw new FormatException("Invalid cfcode format. Expected encrypted hex token.");

                VendorResponseDetailsDTO obj = new VendorResponseDetailsDTO();
                string decrypted = CryptoExtensions.Decrypt(cfcode);
                if (string.IsNullOrWhiteSpace(decrypted) || !long.TryParse(decrypted.Trim(), out long responseId))
                    throw new FormatException("Decrypted cfcode is not a valid response id.");

                obj = await _unitOfWork.ChallengeRegistration.GetVendorResponseDetailsForExternal(responseId);
                var challengeFiles = await _commonService.GetAllFilesByLinkId(Convert.ToInt64(obj.challengeDetails.challengeId), "Challenge Details", true);
                var flowHistory = await GetSRHistoryById(responseId);

                if (flowHistory != null) flowHistory = flowHistory.Where(x => x.isExternal == true).OrderByDescending(x => x.CreatedOn).ToList();
                var responseFiles = await _commonService.GetAllFilesByLinkId(responseId, "ChallengeResponse", false);
                obj.challengeFiles = challengeFiles;
                obj.responseFiles = responseFiles.OrderBy(x => x.description).ToList();
                obj.sRFlowHistories = flowHistory;
                return obj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<SolutionTechDetailsDTO>> SolutionTechDetailsByResponseId(string cfcode)
        {
            try
            {
                List<SolutionTechDetailsDTO> obj = new List<SolutionTechDetailsDTO>();
                long responseId = (long)CryptoExtensions.Decrypt(cfcode).ToInt64();
                obj = await _unitOfWork.ChallengeRegistration.SolutionTechDetailsByResponseId(responseId);

                return obj;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<LatestChallengeForExternalDTO>> ParticipatedChallengesForExternal(long sourceId, long participant)
        {
            try
            {
                return await _unitOfWork.ChallengeRegistration.ParticipatedChallengesForExternal(sourceId, participant);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<TechProposalQueries> TechProposalQueriesCount()
        {
            return await _unitOfWork.ChallengeRegistration.TechProposalQueriesCount();
        }
        public async Task<List<ChallengeStatusCountDTO>> GetCTRStatusCount()
        {
            return await _unitOfWork.ChallengeRegistration.GetCTRStatusCount();
        }
        public async Task<List<ChallengeStatusCountDTO>> GetChallengeStatusCount()
        {
            return await _unitOfWork.ChallengeRegistration.GetChallengeStatusCount();
        }
        public async Task<List<ChallengeStatusCountDTO>> GetPIRStatusCount()
        {
            return await _unitOfWork.ChallengeRegistration.GetPIRStatusCount();
        }

        public async Task<List<ChallengeStatusCountDTO>> GetChallengeResponseStatusCount()
        {
            return await _unitOfWork.ChallengeRegistration.GetChallengeResponseStatusCount();
        }

        public async Task<long> AddChallengeSolution(ChallengeResponse challengeResponse)
        {
            try
            {
                await _unitOfWork.ChallengeResponse.AddAsync(challengeResponse);
                long saveSolution = await _unitOfWork.SaveAsync();
                ChallengeResponse crObj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == challengeResponse.Id);
                
                crObj.ResReferenceNo = "RSP-" + crObj.Id.ToString().PadLeft(5, '0');
                _unitOfWork.ChallengeResponse.Update(crObj);
                long updateSolution = await _unitOfWork.SaveAsync();
                return challengeResponse.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateLocalSolution(ChallengeResponse challengeResponse)
        {
            try
            {
                ChallengeResponse crObj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == challengeResponse.Id);
                long oldstatus = crObj.StatusId.Value;
                crObj.CompanyId = challengeResponse.CompanyId;
                crObj.TechnologyName = challengeResponse.TechnologyName;
                crObj.TechnologyDescription = challengeResponse.TechnologyDescription;
                crObj.StatusId = challengeResponse.StatusId;
                _unitOfWork.ChallengeResponse.Update(crObj);
                long updateSolution = await _unitOfWork.SaveAsync();
                var SentbackStatus = _commonService.GetMasterDataByParentAndParam1(TypeCodes.ChallengeResponseStatus, ChallengeRspStatus.Sentback);
                var SubmittedStatus = _commonService.GetMasterDataByParentAndParam1(TypeCodes.ChallengeResponseStatus, ChallengeRspStatus.Submitted);
                var externaUser = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(x => x.Id == crObj.CreatedBy);
                if (challengeResponse.StatusId == SubmittedStatus.Result.Id)
                {
                    var status_text = "";
                    if (oldstatus == SentbackStatus.Result.Id)
                    {
                        status_text = "Re Submitted";
                        
                    }
                    else { status_text = "Submitted"; SendEmail_SolutionSubmitted(crObj); }
                    SrFlowHistory objSR = new SrFlowHistory()
                    {
                        ResponseId = challengeResponse.Id,//saving response id
                        StatusId = challengeResponse.StatusId.Value,
                        Comments = "",
                        CreatedOn = DateTime.Now,
                        DescInfo = "For " + externaUser.CompanyName + ", " + externaUser.FirstName + " " + externaUser.LastName + " " + status_text + " the Solution",
                        IsExternal = true,
                        ExternalUserId = crObj.CreatedBy,
                    };
                    await AddSRFlowHistory(objSR);
                }
                return challengeResponse.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateChallengeSolution(VendorResponseDTO challengeResponse, long responseID, long vendorId, long statusId)
        {

            ChallengeResponse crObj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == responseID);
            var SentbackStatus = _commonService.GetMasterDataByParentAndParam1(TypeCodes.ChallengeResponseStatus, ChallengeRspStatus.Sentback);
            long oldstatus = crObj.StatusId.Value;
            crObj.UpdatedBy = vendorId.ToString();
            crObj.UpdatedRole = "External";
            crObj.UpdatedOn = DateTime.Today;
            crObj.CreatedOn = DateTime.Now;

            crObj.TechnologyName = challengeResponse.technologyName;
            crObj.TechnologyDescription = challengeResponse.technologyDescription;
            crObj.StatusId = statusId;
            var externaUser = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(x => x.Id == crObj.CreatedBy);
            _unitOfWork.ChallengeResponse.Update(crObj);
            long result = await _unitOfWork.SaveAsync();
            var submittedId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.ChallengeResponseStatus, ChallengeResponseStatus.Submitted).Result.Id;
            if (statusId == submittedId)
            {
                var status_text = "";
                if (oldstatus == SentbackStatus.Result.Id)
                {
                    status_text = "Re Submitted";
                    
                }
                else { status_text = "Submitted"; SendEmail_SolutionSubmitted(crObj); }
                SrFlowHistory objSR = new SrFlowHistory()
                {
                    ResponseId = responseID,//saving response id
                    StatusId = statusId,
                    Comments = "",
                    CreatedOn = DateTime.Now,
                    DescInfo = "For " + externaUser.CompanyName + ", " + externaUser.FirstName + " " + externaUser.LastName + " " + status_text + " the Solution",
                    IsExternal = true,
                    ExternalUserId = crObj.CreatedBy,
                };
                await AddSRFlowHistory(objSR);
            }
            return crObj.Id;
        }
        public async Task<long> AddVendorQueries(string query, long responseID, bool hasattachment)
        {
            try
            {
                VendorToChrQuery vtcq = new VendorToChrQuery
                {
                    HasAttachment = hasattachment,
                    ResponseId = responseID,
                    Query = query,
                    CreatedOn = DateTime.Today,
                    IsPublic = false
                };
                await _unitOfWork.VendortoChrQuery.AddAsync(vtcq);
                long saveSolution = await _unitOfWork.SaveAsync();
                ChallengeResponse crObj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == responseID);
                SendEmail_VendersendQuery(crObj);

                return vtcq.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> AddVendorQueryResponse(string response, long queryId, bool hasattachment, EmployeeDTO emp)
        {
            try
            {

                VendorToChrQueryResponse vtcq = new VendorToChrQueryResponse
                {
                    HasAttachment = hasattachment,
                    QueryId = queryId,
                    Response = response,
                    CreatedOn = DateTime.Today,
                    CreatedBy = emp.COMPANY_NUMBER
                };
                await _unitOfWork.VendorQueryResponse.AddAsync(vtcq);
                long saveSolution = await _unitOfWork.SaveAsync();
                long? responseid = _unitOfWork.VendortoChrQuery.GetFirstOrDefaultAsync(x => x.Id == queryId).Result.ResponseId;
                ChallengeResponse crObj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == responseid);

                SendEmail_VendersendQueryResponse(crObj);
                return vtcq.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> UpdateVendorQueryResponse(string response, long responseId, bool hasattachment, long queryId, EmployeeDTO emp)
        {
            try
            {
                VendorToChrQueryResponse obj = new VendorToChrQueryResponse();
                obj = await _unitOfWork.VendorQueryResponse.GetFirstOrDefaultAsync(x => x.Id == responseId);
                if (obj != null)
                {
                    obj.CreatedOn = DateTime.Today;
                    obj.HasAttachment = hasattachment;
                    obj.QueryId = queryId;
                    obj.Response = response;
                    obj.CreatedBy = emp.COMPANY_NUMBER;
                }
                _unitOfWork.VendorQueryResponse.Update(obj);
                long saveSolution = await _unitOfWork.SaveAsync();
                long? responseid = _unitOfWork.VendortoChrQuery.GetFirstOrDefaultAsync(x => x.Id == queryId).Result.ResponseId;
                ChallengeResponse crObj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == responseid);
                SendEmail_VendersendQueryResponse(crObj);
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddPDOQueries(string query, long responseID, bool hasattachment, EmployeeDTO emp)
        {
            try
            {
                PdoToVendorQuery vtcq = new PdoToVendorQuery
                {
                    HasAttachment = hasattachment,
                    ResponseId = responseID,
                    Query = query,
                    CreatedOn = DateTime.Today,
                    IsPublic = false,
                    CreatedBy = emp.COMPANY_NUMBER,

                };
                await _unitOfWork.PDOtoVendorQuery.AddAsync(vtcq);
                long saveSolution = await _unitOfWork.SaveAsync();

                ChallengeResponse crObj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == responseID);
                SendEmail_PDOsendQuery(crObj, emp);
                return vtcq.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddPDOQueryResponse(string response, long queryId, bool hasattachment)
        {
            try
            {
                PdoToVendorQueryResponse vtcq = new PdoToVendorQueryResponse
                {
                    HasAttachment = hasattachment,
                    QueryId = queryId,
                    Response = response,
                    CreatedOn = DateTime.Today,
                };
                await _unitOfWork.PDOQueryResponse.AddAsync(vtcq);
                long saveSolution = await _unitOfWork.SaveAsync();
                PdoToVendorQuery obj = await _unitOfWork.PDOtoVendorQuery.GetFirstOrDefaultAsync(x => x.Id == queryId);
                SendEmail_PDOsendQueryResponse(obj.CreatedBy, obj.ResponseId);
                return vtcq.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> UpdatePDOQueryResponse(string response, long responseId, bool hasattachment, long queryId)
        {
            try
            {
                PdoToVendorQueryResponse obj = new PdoToVendorQueryResponse();
                obj = await _unitOfWork.PDOQueryResponse.GetFirstOrDefaultAsync(x => x.Id == responseId);
                if (obj != null)
                {
                    obj.CreatedOn = DateTime.Today;
                    obj.HasAttachment = hasattachment;
                    obj.QueryId = queryId;
                    obj.Response = response;
                }
                _unitOfWork.PDOQueryResponse.Update(obj);
                long saveSolution = await _unitOfWork.SaveAsync();
                var objQ = await _unitOfWork.PDOtoVendorQuery.GetFirstOrDefaultAsync(x => x.Id == queryId);
                var objResp = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == objQ.ResponseId);
                var objChallenge = await _unitOfWork.ChallengeRegistration.GetFirstOrDefaultAsync(x => x.Id == objResp.ChallengeRegistrationId);
                SendEmail_PDOsendQueryResponse(objChallenge.RequestedBy, objQ.ResponseId);
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        public async Task<long> AddOrUpdateVendorScreeningAnswers(List<ScreeningQuestionsDTO> Sqs, long responseID)
        {
            try
            {
                List<ChallengeResponseQuestion> obj = null;
                obj = (List<ChallengeResponseQuestion>)await _unitOfWork.ChallengeResponseQuestion.GetAllAsync(x => x.ChallengeResponseId == responseID);
                if (obj.Count > 0 && obj != null)
                {
                    _unitOfWork.ChallengeResponseQuestion.RemoveRange(obj);
                    await _unitOfWork.SaveAsync();

                }
                List<ChallengeResponseQuestion> lstQ = new List<ChallengeResponseQuestion>();
                foreach (var answer in Sqs)
                {
                    ChallengeResponseQuestion question = new ChallengeResponseQuestion()
                    {
                        ChallengeResponseId = responseID,
                        VendorQuestionId = answer.questionID,
                        Answer = answer.answer,
                        Status = answer.status,
                    };
                    lstQ.Add(question);

                }
                _unitOfWork.ChallengeResponseQuestion.AddRangeAsync(lstQ);
                long result = await _unitOfWork.SaveAsync();
                return 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<long> AddOrUpdateVendorTechDetailds(List<SolutionTechDetailsDTO> Sqs, long responseID)
        {
            try
            {
                List<ChallengeResponseTechnology> obj = null;
                obj = (List<ChallengeResponseTechnology>)await _unitOfWork.ChallengeResponseTechnology.GetAllAsync(x => x.ChallengeResponseId == responseID);
                if (obj.Count > 0 && obj != null)
                {
                    _unitOfWork.ChallengeResponseTechnology.RemoveRange(obj);
                    long result = await _unitOfWork.SaveAsync();

                }
                foreach (var answer in Sqs)
                {
                    ChallengeResponseTechnology question = new ChallengeResponseTechnology()
                    {
                        ChallengeResponseId = responseID,
                        TechnologyQuestion = Convert.ToInt64(answer.technologyQuestionId),
                        Description = answer.answer,

                    };
                    await _unitOfWork.ChallengeResponseTechnology.AddAsync(question);
                    await _unitOfWork.SaveAsync();
                }
                return 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public async Task<List<ChallengeRegistrationDTO>> FilterGetChallengeRegistration(ChallengeRegistrationDetailFilterDTO challengeRegistrationDetailFilterDTO)
        {
            try
            {
                return await _unitOfWork.ChallengeRegistration.FilterGetChallengeRegistration(challengeRegistrationDetailFilterDTO);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ChallengeDetailDTO> GetChallengeDetail(long challengeRegId)
        {
            return await _unitOfWork.ChallengeDetail.GetChallengeDetail(challengeRegId);
        }

        public async Task<ChallengeRegistrationDTO> GetChallengeRegistrationByRefNo(string challengeRegRefNo)
        {
            return await _unitOfWork.ChallengeDetail.GetChallengeRegistrationByRefNo(challengeRegRefNo);
        }
        public async Task<ChallengeRegistrationDTO> GetChallengeRegistrationFromOldTIPRef(string challengeRegRefNo)
        {
            return await _unitOfWork.ChallengeDetail.GetChallengeRegistrationFromOldTIPRef(challengeRegRefNo);
        }
        public async Task<challengePublishDetailsDTO> GetChallengePublication(long challengeRegId)
        {
            return await _unitOfWork.ChallengeDetail.GetChallengePublication(challengeRegId);
        }

        public async Task<List<QueryResponseDTO>> GetVendorQueryResponseForInternal(long ChallengeID)
        {
            return await _unitOfWork.ChallengeRegistration.GetVendorQueryResponseForInternal(ChallengeID);
        }

        public async Task<List<QueryResponseDTO>> GetAllVendorQueryAndResponseForInternal()
        {
            return await _unitOfWork.ChallengeRegistration.GetAllVendorQueryAndResponseForInternal();
        }

        public async Task<List<QueryResponseDTO>> GetPDOQueryResponseForInternal(long SolutionId)
        {
            return await _unitOfWork.ChallengeRegistration.GetPDOQueryResponseForInternal(SolutionId);
        }


        public async Task<List<SRFlowHistoryDTO>> GetSRHistoryById(long ChlId)
        {
            return await _unitOfWork.SRFlowHistory.GetHistoryById(ChlId);

        }

        public async Task<long> AddSRFlowHistory(SrFlowHistory DTO)
        {

            try
            {
                DTO.Id = 0;
                if (!string.IsNullOrEmpty(DTO.Comments) && DTO.Comments.Length > 1000)
                    DTO.Comments = DTO.Comments.Substring(0, 1000);
                if (!string.IsNullOrEmpty(DTO.DescInfo) && DTO.DescInfo.Length > 400)
                    DTO.DescInfo = DTO.DescInfo.Substring(0, 400);
                await _unitOfWork.SRFlowHistory.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<ChlFlowHistoryDTO>> GetChlHistoryById(long ChlId)
        {
            return await _unitOfWork.ChlFlowHistory.GetHistoryById(ChlId);

        }

        public async Task<List<SRFlowHistoryDTO>> GetSRFlowHistory(long solutionId)
        {
            return await _unitOfWork.SRFlowHistory.GetHistoryById(solutionId);
        }

        public async Task<long> AddChallengeFlowHistory(ChlFlowHistory DTO)
        {

            try
            {
                await _unitOfWork.ChlFlowHistory.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<int> UpdatepublishStatus(long challengeRegId)
        {

            ChallengeRegistration? obj = null;
            obj = await _unitOfWork.ChallengeRegistration.GetFirstOrDefaultAsync(x => x.Id == challengeRegId);
            if (obj != null)
            {
                TypeCodeMaster challengeStatus = null;
                challengeStatus = await _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type.ToUpper() == TypeCodes.ChallengeStatus && x.Param1 == ChallengeStatus.Accepted);
                obj.Publishreferenceno = "TPH-" + obj.Id + "-" + (DateTime.Now.ToString("ddMMyyyy"));

                obj.PublishDate = DateTime.Now;
                obj.StatusId = challengeStatus.Id;
                // add publish date in DB 
                _unitOfWork.ChallengeRegistration.Update(obj);
                await _unitOfWork.SaveAsync();
                return 1;
            }


            return 0;
        }

        public async Task<int> UpdateQueryIsPublic(long queryId, bool status)
        {
            VendorToChrQuery? obj = null;
            obj = await _unitOfWork.VendortoChrQuery.GetFirstOrDefaultAsync(x => x.Id == queryId);
            if (obj != null)
            {
                obj.IsPublic = status;
                _unitOfWork.VendortoChrQuery.Update(obj);
                await _unitOfWork.SaveAsync();
                return 1;
            }
            return 0;
        }
        public async Task<int> UpdateQueryAsRead(long queryId)
        {
            VendorToChrQuery? obj = null;
            obj = await _unitOfWork.VendortoChrQuery.GetFirstOrDefaultAsync(x => x.Id == queryId);
            if (obj != null)
            {
                obj.IsRead = true;
                _unitOfWork.VendortoChrQuery.Update(obj);
                await _unitOfWork.SaveAsync();
                return 1;
            }
            return 0;
        }
        public async Task<long> UpdatechallengePublication(challengePublishDetailsDTO DTO, bool publishBit, EmployeeDTO? emp)
        {
            try
            {
                var Id = (long)CryptoExtensions.Decrypt(DTO.challengeRegId).ToInt64();
                
                ChallengeDetail? obj = null;
                obj = await _unitOfWork.ChallengeDetail.GetFirstOrDefaultAsync(x => x.ChallengeId == Id);
                if (obj != null)
                {
                    obj.QueryLastdate = DTO.queryLD;
                    obj.ResponseLastdate = DTO.resLD;
                    obj.VendorSubmissionStartdate = DTO.venSubSD;
                    _unitOfWork.ChallengeDetail.Update(obj);
                    await _unitOfWork.SaveAsync();

                    if (publishBit)
                    {
                        ChallengeRegistration? objreg = null;
                        objreg = await _unitOfWork.ChallengeRegistration.GetFirstOrDefaultAsync(x => x.Id == Id);
                        if (objreg != null)
                        {
                            TypeCodeMaster challengeStatus = null;
                            challengeStatus = await _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type.ToUpper() == TypeCodes.ChallengeStatus && x.Param1 == ChallengeStatus.Published);
                            objreg.Publishreferenceno = "TPH-" + Id.ToString().PadLeft(6, '0');//"TPH-" + Id + "-" + (DateTime.Now.ToString("ddMMyyyy"));

                            objreg.PublishDate = DateTime.Now;
                            objreg.StatusId = challengeStatus.Id;
                            // add publish date in DB 
                            _unitOfWork.ChallengeRegistration.Update(objreg);
                            await _unitOfWork.SaveAsync();
                            await AddChlFlowHistoryAsync(Id, challengeStatus.Id, "", emp.ACTIVE_R_ID.Value, emp.DISPLAY_NAME + " Published/Extended the Challenge", emp);
                            //return 1;
                        }

                    }
                }
                else
                {






                }

                
                ChallengePublicationSource objsource = new ChallengePublicationSource();



                List<ChallengePublicationSource> objsourcelst = (List<ChallengePublicationSource>)await _unitOfWork.challengeSources.GetAllAsync(x => x.ChRegId == Id);




                
                if (objsourcelst.Count > 0 && objsourcelst != null)
                {
                    _unitOfWork.challengeSources.RemoveRange(objsourcelst);
                    await _unitOfWork.SaveAsync();

                }
                objsourcelst = new List<ChallengePublicationSource>();
                //GetAsync

                for (int i = 0; i < DTO.sources.Count; i++)
                {
                    objsource = new ChallengePublicationSource();
                    objsource.ChRegId = Id;
                    objsource.SourceId = DTO.sources[i];
                    if (publishBit)
                    {

                        List<ExternalUserDTO> email = await _unitOfWork.ChallengeResponse.SourcesEmail((long)objsource.SourceId);
                        foreach (var ema in email)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            var emailModule = await _commonService.GetMasterDataByParentAndParam1(TypeCodes.EmailTemplate, EmailModules.TMHPBC);
                            if (emailModule == null)
                                continue;

                            emailSendConfigDTO.moduleId = emailModule.Id;//70;
                            emailSendConfigDTO.templateId = 16;
                            emailSendConfigDTO = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                            emailSendConfigDTO.toRecipients = new List<string>();
                            emailSendConfigDTO.toRecipients.Add(ema.emailaddress);
                            // Must await — otherwise email SaveAsync runs on the same DbContext concurrently.
                            await MapPublishChallengeEmail(emailSendConfigDTO, Id);
                        }
                    }
                    
                    objsourcelst.Add(objsource);
                }

                await _unitOfWork.challengeSources.AddRangeAsync(objsourcelst);
                await _unitOfWork.SaveAsync();
                return 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<ChallengeRespondByTypeDTO> GetAllChallengeResponse(long roleId, string loggedMu)
        {
            return await _unitOfWork.ChallengeResponse.GetAllChallengeResponse(roleId, loggedMu);
        }


        public async Task<bool> SetConfirmTech(long Id, bool isConfirm, EmployeeDTO? loggedInUser)
        {
            try
            {
                ChallengeResponse obj = null;
                obj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == Id);
                obj.UpdatedBy = loggedInUser.COMPANY_NUMBER;
                obj.UpdatedByRef = loggedInUser.REFERENCE_INDICATOR;
                obj.UpdatedOn = DateTime.Now;
                obj.IsConfirm = isConfirm;
                _unitOfWork.ChallengeResponse.Update(obj);
                await _unitOfWork.SaveAsync();
                //add history lines.
                SrFlowHistory objSR = new SrFlowHistory()
                {
                    ResponseId = Id,//saving response id
                    StatusId = obj.StatusId.Value,
                    Comments = "",
                    RoleId = loggedInUser.ACTIVE_R_ID.Value,
                    UserId = loggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    DescInfo = loggedInUser.DISPLAY_NAME + "(Challenge Requestor) confirmed the technology value of the Solution",
                    IsExternal = false,
                };
                await AddSRFlowHistory(objSR);

                return isConfirm;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<ChallengeResponseQuestionDTO> ChallengeResponseQuestions(long responseId)
        {
            return await _unitOfWork.ChallengeResponseQuestion.ChallengeResponseQuestions(responseId);
        }

        public async Task<List<ChallengeResponseReviewDTO>> GetChallengeReview(long responseId, long roleId, EmployeeDTO? loggedInUser)
        {
            return await _unitOfWork.ChallengeResponseReview.GetChallengeReview(responseId, roleId, loggedInUser);
        }
        public async Task<List<ReviewDetailDTO>> GetReviewerDetail(long responseId)
        {
            return await _unitOfWork.ChallengeResponseReview.GetReviewerDetail(responseId);
        }


        public async Task<long> AddSoultionReview(List<ChallengeResponseReview> challengeResponseReview, EmployeeDTO? loggedInUser, string status, string formBy)
        {
            ChallengeResponse obj = null;
            obj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == challengeResponseReview[0].ChallengeResponseId);
            TypeCodeMaster typeCodeMaster = null;
            typeCodeMaster = await _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type.ToUpper() == "CRQS" && x.Param1.ToUpper() == status);
            ChallengeRegistration objReg = null;
            objReg = await _unitOfWork.ChallengeRegistration.GetFirstOrDefaultAsync(x => x.Id == obj.ChallengeRegistrationId);

            foreach (var review in challengeResponseReview)
            {
                review.Id = 0;
                if (!string.IsNullOrEmpty(review.Answer) && review.Answer.Length > 600)
                    review.Answer = review.Answer.Substring(0, 600);
                if (!string.IsNullOrEmpty(review.CreatedBy) && review.CreatedBy.Length > 20)
                    review.CreatedBy = review.CreatedBy.Substring(0, 20);
            }

            if (loggedInUser.ACTIVE_R_ID == Convert.ToInt64(UserRoleseEnum.SR))
            {
                ChallengeResponseSr crs = new ChallengeResponseSr();
                crs.Id = 0;
                crs.ChallengeResponseId = obj.Id;
                crs.ChallengeRegistrationId = obj.ChallengeRegistrationId;
                crs.ResReferenceNo = obj.ResReferenceNo;
                crs.TechnologyName = obj.TechnologyName;
                crs.TechnologyDescription = obj.TechnologyDescription;
                crs.SourceId = obj.SourceId;
                crs.StatusId = typeCodeMaster.Id;
                crs.CompanyId = obj.CompanyId;
                crs.CreatedOn = DateTime.Now;
                crs.CreatedBy = loggedInUser.COMPANY_NUMBER;
                await _unitOfWork.ChallengeResponseSr.AddAsync(crs);
                await _unitOfWork.ChallengeResponseReview.AddRangeAsync(challengeResponseReview);
                SrFlowHistory objSR = new SrFlowHistory()
                {
                    ResponseId = challengeResponseReview.FirstOrDefault().ChallengeResponseId,//saving response id
                    StatusId = typeCodeMaster.Id,
                    Comments = challengeResponseReview.FirstOrDefault().ReviewComment,
                    RoleId = loggedInUser.ACTIVE_R_ID.Value,
                    UserId = loggedInUser?.COMPANY_NUMBER,
                    CreatedOn = DateTime.Now,
                    DescInfo = loggedInUser.DISPLAY_NAME + "(Solution Reviewer) Reviewed.",
                    IsExternal = false,
                };
                await AddSRFlowHistory(objSR);
                ChallengeSolutionReviewer challengeSolutionReviewer = null;
                challengeSolutionReviewer = await _unitOfWork.ChallengeSolutionReviewers.GetFirstOrDefaultAsync(x => x.ChallengeId == obj.ChallengeRegistrationId && x.Reviewer == loggedInUser.COMPANY_NUMBER && x.IsReviewed == false);
                if (challengeSolutionReviewer != null)
                {
                    challengeSolutionReviewer.IsReviewed = true;
                    _unitOfWork.ChallengeSolutionReviewers.Update(challengeSolutionReviewer);
                }
                await _unitOfWork.SaveAsync();
                EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                emailSendConfigDTO.moduleId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.EmailTemplate, EmailModules.TMHPC).Result.Id; //216;
                emailSendConfigDTO.templateId = 40;
                emailSendConfigDTO.toRecipients = new List<string>();
                emailSendConfigDTO.ccRecipients = new List<string>();
                emailSendConfigDTO.RecipientsNames = new List<string>();

                EmployeeDTO empdata = await _unitOfWork.Employee.GetByMuNumber(objReg.RequestedBy);
                if (empdata != null)
                {
                    emailSendConfigDTO.toRecipients.Add(empdata.EMAIL_ADDRESS);
                    emailSendConfigDTO.RecipientsNames.Add(empdata.DISPLAY_NAME);
                    emailSendConfigDTO.ccRecipients.Add(loggedInUser.EMAIL_ADDRESS);
                }
                EmailSendConfigDTO res = null;
                res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                    await MapSolutionReviewEmail(res, obj.Id);
                return crs.Id;
            }
            else
            {
                await _unitOfWork.ChallengeResponseReview.AddRangeAsync(challengeResponseReview);
                obj.StatusId = typeCodeMaster.Id;
                obj.UpdatedBy = loggedInUser.COMPANY_NUMBER;
                obj.UpdatedByRef = loggedInUser.REFERENCE_INDICATOR;
                obj.UpdatedOn = DateTime.Now;
                obj.UpdatedRole = formBy;
                if (loggedInUser.ACTIVE_R_ID == Convert.ToInt64(UserRoleseEnum.CHR))
                {
                    obj.IsCr = true;
                    SrFlowHistory objSR = new SrFlowHistory()
                    {
                        ResponseId = challengeResponseReview.FirstOrDefault().ChallengeResponseId,//saving response id
                        StatusId = typeCodeMaster.Id,
                        Comments = challengeResponseReview.FirstOrDefault().ReviewComment,
                        RoleId = loggedInUser.ACTIVE_R_ID.Value,
                        UserId = loggedInUser?.COMPANY_NUMBER,
                        CreatedOn = DateTime.Now,
                        DescInfo = loggedInUser.DISPLAY_NAME + "(Challenge Requestor) Reviewed.",
                        IsExternal = false,
                    };
                    await AddSRFlowHistory(objSR);


                }

                EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                emailSendConfigDTO.moduleId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.EmailTemplate, EmailModules.TMHPC).Result.Id; //216;
                emailSendConfigDTO.templateId = 41;
                emailSendConfigDTO.toRecipients = new List<string>();
                emailSendConfigDTO.ccRecipients = new List<string>();
                emailSendConfigDTO.RecipientsNames = new List<string>();

                EmployeeDTO empdata = await _unitOfWork.Employee.GetByMuNumber(objReg.UctFp);
                if (empdata != null)
                {
                    emailSendConfigDTO.toRecipients.Add(empdata.EMAIL_ADDRESS);
                    emailSendConfigDTO.RecipientsNames.Add(empdata.DISPLAY_NAME);
                    emailSendConfigDTO.ccRecipients.Add(loggedInUser.EMAIL_ADDRESS);
                }

                EmailSendConfigDTO res = null;
                res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                    await MapSolutionReviewEmail(res, obj.Id);
                await _unitOfWork.SaveAsync();
                return obj.Id;
            }
        }

        public async Task<string> UpdateSoultionReviewStatus(EmployeeDTO? loggedInUser, long Id, string status, string comment)
        {
            TypeCodeMaster typeCodeMaster = null;
            ChallengeResponse obj = null;
            typeCodeMaster = await _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type.ToUpper() == TypeCodes.ChallengeResponseStatus && x.Param1.ToUpper() == status);
            obj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == Id);
            obj.StatusId = typeCodeMaster.Id;
            obj.StatusComment = comment;
            obj.UpdatedBy = loggedInUser.COMPANY_NUMBER;
            obj.UpdatedByRef = loggedInUser.REFERENCE_INDICATOR;
            obj.UpdatedOn = DateTime.Now;
            await _unitOfWork.SaveAsync();
            //add history lines also;
            SrFlowHistory objSR = new SrFlowHistory()
            {
                ResponseId = Id,//saving response id
                StatusId = typeCodeMaster.Id,
                Comments = comment,
                RoleId = loggedInUser.ACTIVE_R_ID.Value,
                UserId = loggedInUser?.COMPANY_NUMBER,
                CreatedOn = DateTime.Now,
                DescInfo = loggedInUser.DISPLAY_NAME + " " + typeCodeMaster.Name + " the Solution",
                IsExternal = true
            };
            await AddSRFlowHistory(objSR);
            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
            if (!string.IsNullOrEmpty(status) && loggedInUser.ACTIVE_R_ID == Convert.ToInt64(UserRoleseEnum.UCT))
            {
                emailSendConfigDTO.moduleId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.EmailTemplate, EmailModules.TMHPC).Result.Id; //216;
                emailSendConfigDTO.templateId = 15;
                emailSendConfigDTO.toRecipients = new List<string>();
                emailSendConfigDTO.ccRecipients = new List<string>();
                emailSendConfigDTO.RecipientsNames = new List<string>();

                ExternalUserDTO empdata = await _unitOfWork.ChallengeResponse.ExternalEmailwithName(obj.CreatedBy);
                if (empdata != null)
                {
                    emailSendConfigDTO.toRecipients.Add(empdata.emailaddress);
                    emailSendConfigDTO.RecipientsNames.Add(empdata.displayName);
                    emailSendConfigDTO.ccRecipients.Add(loggedInUser.EMAIL_ADDRESS);
                }

                EmailSendConfigDTO res = null;
                res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                var vendorName = await _unitOfWork.ExternalUser.GetAsync(obj.CreatedBy);

                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                    await MapSolutionReviewEmail(res, obj.Id);
                if (status != ChallengeResponseStatus.Sendback)
                {
                    var checkObj = await _unitOfWork.TechnologyBank.GetTechnologyBankByRefId(obj.ChallengeRegistrationId, obj.Id);
                    if (checkObj == null)
                    {
                        var challengeObj = await GetChallengeDetail(obj.ChallengeRegistrationId);
                        TechnologyBank technologyBank = new TechnologyBank()
                        {
                            Id = 0,
                            ChallengeId = obj.ChallengeRegistrationId,
                            ChallengeResponseId = obj.Id,
                            Title = obj.TechnologyName,
                            Description = obj.TechnologyDescription,
                            ContactFp = vendorName.FirstName + " " + vendorName.LastName,
                            Vendor = vendorName.CompanyName != null ? vendorName.CompanyName : "",
                            ContactEmail = empdata.emailaddress,
                            Area = challengeObj.araId,
                            Theme = challengeObj.theId,
                            SubTheme = challengeObj.sTheId,
                            Application = challengeObj.appId,
                            CreatedBy = loggedInUser.COMPANY_NUMBER,
                            CreatedOn = DateTime.Now,
                            CreatedByRef = loggedInUser.REFERENCE_INDICATOR
                        };
                        var vendorId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.ParticipationSource, ParticipationSources.Vendor).Result.Id;
                        var shellId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.ParticipationSource, ParticipationSources.Shell).Result.Id;
                        var iSId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.ParticipationSource, ParticipationSources.InternationalCompany).Result.Id;
                        var localId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.ParticipationSource, ParticipationSources.TSA).Result.Id;

                        if (obj.SourceId == vendorId)
                        {
                            var vSId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.SourceStatus, SolutionResponseStatus.VendorR).Result.Id;
                            technologyBank.Source = vSId;
                        }
                        else if (obj.SourceId == shellId)
                        {
                            var sId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.SourceStatus, SolutionResponseStatus.ShellR).Result.Id;
                            technologyBank.Source = sId;
                        }
                        else if (obj.SourceId == iSId)
                        {
                            var iId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.SourceStatus, SolutionResponseStatus.InternationalCR).Result.Id;
                            technologyBank.Source = iId;
                        }
                        else if (obj.SourceId == localId)
                        {
                            var lId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.SourceStatus, SolutionResponseStatus.LocalCR).Result.Id;
                            technologyBank.Source = lId;
                        }
                        await _unitOfWork.TechnologyBank.AddAsync(technologyBank);
                        long result = await _unitOfWork.SaveAsync();
                        if (status == ChallengeResponseStatus.Accepted)
                        {
                            var InActiveUser = await _unitOfWork.ChallengeResponse.GetExternalUserProposedSol(vendorName.Id);
                            if (InActiveUser)
                            {
                                vendorName.IsActive = false;
                                vendorName.Attempts = 0;
                                _unitOfWork.ExternalUser.Update(vendorName);
                                await _unitOfWork.SaveAsync();
                            }

                            return CryptoExtensions.Encrypt(technologyBank.Id.ToString());
                        }
                    }
                    else if (status == ChallengeResponseStatus.Accepted)
                    {
                        var InActiveUser = await _unitOfWork.ChallengeResponse.GetExternalUserProposedSol(vendorName.Id);
                        if (InActiveUser)
                        {
                            vendorName.IsActive = false;
                            vendorName.Attempts = 0;
                            await _unitOfWork.ExternalUser.AddAsync(vendorName);
                            await _unitOfWork.SaveAsync();
                        }
                        return CryptoExtensions.Encrypt(checkObj.id.ToString());
                    }
                }
                return CryptoExtensions.Encrypt(obj.Id.ToString());
            }

            
            return CryptoExtensions.Encrypt(obj.Id.ToString());
        }
        public async Task<string> UpdateSoultionMatrix(EmployeeDTO? loggedInUser, long Id, SolutionMatrixDTO solutionMatrixDTO)
        {
            ChallengeResponse obj = null;
            obj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == Id);
            obj.Complexity = solutionMatrixDTO.complexity;
            obj.Impact = solutionMatrixDTO.impact;
            obj.DecisionId = solutionMatrixDTO.decision;
            obj.UpdatedBy = loggedInUser.COMPANY_NUMBER;
            obj.UpdatedByRef = loggedInUser.REFERENCE_INDICATOR;
            obj.UpdatedOn = DateTime.Now;
            await _unitOfWork.SaveAsync();
            return CryptoExtensions.Encrypt(obj.Id.ToString());
        }

        public async Task<long> SendReminderEmails(string Module, string TemplateCode)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {
                    if (TemplateCode.Equals("TMH006"))
                    {
                        var emailEscConfig = await _unitOfWork.EmailEscalation.getEmailEscByCode(TemplateCode);
                        var reminderData = await _unitOfWork.ChallengeResponse.reminderEmail(emailEscConfig.days.Value);

                        if (reminderData != null && reminderData.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (var item in reminderData)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                emailSendConfigDTO.toRecipients.Add(item.emailAddress);

                                EmailSendConfigDTO emailConfig = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                                ChallengeResponse challengeResponse = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == item.id);
                                if (challengeResponse != null)
                                {
                                    challengeResponse.LastReminder = DateTime.Now;
                                    challengeResponse.UpdatedOn = DateTime.Now;

                                    challengeResponse.EscCount = emailEscConfig.escalCount > 0 ? challengeResponse.EscCount != null && challengeResponse.EscCount > 0 ? (challengeResponse.EscCount + 1) : 1 : 0;

                                    if (item.lastReminder != null && emailEscConfig.escalCount > 0 && emailEscConfig.escalCount == challengeResponse.EscCount && _configuration["ServerMode"] == "Prod")
                                    {
                                        var UctFp = await _unitOfWork.Employee.GetByMuNumber(item.uctFP);
                                        if (UctFp != null && UctFp.SUPERVISOR_ID != null)
                                        {
                                            emailSendConfigDTO.ccRecipients = new List<string>();
                                            var UctFpEmail = await _commonService.GetEmailBymuNO(UctFp.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                                            challengeResponse.EscCount = 0;
                                        }
                                    }
                                }

                                if (emailConfig.keywords.Count > 0 && !string.IsNullOrEmpty(emailConfig.body))
                                {
                                    var mapData = await MapSolutionReviewEmail(emailConfig, item.id.Value);
                                    if (mapData)
                                    {
                                        _unitOfWork.ChallengeResponse.Update(challengeResponse);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                    else if (TemplateCode.Equals("BTI0011"))
                    {
                        var WeeklyReminderList = await _unitOfWork.ChallengeRegistration.ReminderWhenChallengewithCFDH();
                        if (WeeklyReminderList != null && WeeklyReminderList.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (ChallengeDetailDTO pirApproval in WeeklyReminderList)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                var ReminderUser = await _commonService.GetEmailBymuNO(pirApproval.cfdh);
                                emailSendConfigDTO.toRecipients.Add(ReminderUser);

                                // Email Escalation Start
                                DateTime submittedDate = pirApproval.actionOn.Value;
                                DateTime today = DateTime.Today;

                                // Calculate the time elapsed between submitted date and today
                                TimeSpan timeElapsed = today - submittedDate;

                                // Set the interval between emails in days
                                long emailIntervalDays = await _unitOfWork.EmailEscalation.getEmailEscDays("BTI0011");

                                // Calculate the number of occurrences that have happened so far
                                long occurrences = (long)(timeElapsed.TotalDays / emailIntervalDays) + 1;

                                // Set the threshold for escalation
                                long escalationThreshold = await _unitOfWork.EmailEscalation.getEmailEscOccurunces("BTI0011");

                                // Check if escalation email should be sent
                                if (escalationThreshold > 0 && occurrences > escalationThreshold)
                                {
                                    // Send escalation email
                                    if (pirApproval.LastReminder != null && _configuration["ServerMode"] == "Prod")
                                    {
                                        var cfdh = await _unitOfWork.Employee.GetByMuNumber(pirApproval.cfdh);
                                        if (cfdh != null && cfdh.SUPERVISOR_ID != null)
                                        {
                                            emailSendConfigDTO.ccRecipients = new List<string>();
                                            var UctFpEmail = await _commonService.GetEmailBymuNO(cfdh.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                                        }
                                    }
                                }

                                ChallengeKeywordDTO pirObj = await _unitOfWork.ChallengeRegistration.MapChallengeForEmail((pirApproval.ChallengeId.Value));

                                EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                {
                                    var emailResult = await MapChallengeForEmail(emailSendConfigDTO, pirApproval.ChallengeId.Value);
                                    if (emailResult)
                                    {
                                        ChallengeRegistration updateItem = await _unitOfWork.ChallengeRegistration.GetAsync(pirApproval.ChallengeId.Value);
                                        updateItem.LastReminder = DateTime.Now.Date;
                                        _unitOfWork.ChallengeRegistration.Update(updateItem);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                    else if (TemplateCode.Equals("BTI0012"))
                    {
                        var WeeklyReminderList = await _unitOfWork.ChallengeRegistration.ReminderWhenChallengewithUCT();
                        if (WeeklyReminderList != null && WeeklyReminderList.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (ChallengeDetailDTO pirApproval in WeeklyReminderList)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                var ReminderUser = await _commonService.GetEmailBymuNO(pirApproval.uct);
                                emailSendConfigDTO.toRecipients.Add(ReminderUser);

                                // Email Escalation Start
                                DateTime submittedDate = pirApproval.actionOn.Value;
                                DateTime today = DateTime.Today;

                                // Calculate the time elapsed between submitted date and today
                                TimeSpan timeElapsed = today - submittedDate;

                                // Set the interval between emails in days
                                long emailIntervalDays = await _unitOfWork.EmailEscalation.getEmailEscDays("BTI0012");

                                // Calculate the number of occurrences that have happened so far
                                long occurrences = (long)(timeElapsed.TotalDays / emailIntervalDays) + 1;

                                // Set the threshold for escalation
                                long escalationThreshold = await _unitOfWork.EmailEscalation.getEmailEscOccurunces("BTI0012");

                                // Check if escalation email should be sent
                                if (escalationThreshold > 0 && occurrences > escalationThreshold)
                                {
                                    // Send escalation email
                                    if (pirApproval.LastReminder != null && _configuration["ServerMode"] == "Prod")
                                    {
                                        var cfdh = await _unitOfWork.Employee.GetByMuNumber(pirApproval.uct);
                                        if (cfdh != null && cfdh.SUPERVISOR_ID != null)
                                        {
                                            emailSendConfigDTO.ccRecipients = new List<string>();
                                            var UctFpEmail = await _commonService.GetEmailBymuNO(cfdh.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                                        }
                                    }
                                }

                                ChallengeKeywordDTO pirObj = await _unitOfWork.ChallengeRegistration.MapChallengeForEmail((pirApproval.ChallengeId.Value));

                                EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                {
                                    var emailResult = await MapChallengeForEmail(emailSendConfigDTO, pirApproval.ChallengeId.Value);
                                    if (emailResult)
                                    {
                                        ChallengeRegistration updateItem = await _unitOfWork.ChallengeRegistration.GetAsync(pirApproval.ChallengeId.Value);
                                        updateItem.LastReminder = DateTime.Now.Date;
                                        _unitOfWork.ChallengeRegistration.Update(updateItem);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                    else if (TemplateCode.Equals("BTIR04"))
                    {
                        var WeeklyReminderList = await _unitOfWork.ChallengeRegistration.ReminderWhenSolutionWithCHL();
                        if (WeeklyReminderList != null && WeeklyReminderList.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (ChallengeDetailDTO pirApproval in WeeklyReminderList)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                var ReminderUser = await _commonService.GetEmailBymuNO(pirApproval.chr);
                                emailSendConfigDTO.toRecipients.Add(ReminderUser);

                                // Email Escalation Start
                                DateTime submittedDate = pirApproval.actionOn.Value;
                                DateTime today = DateTime.Today;

                                // Calculate the time elapsed between submitted date and today
                                TimeSpan timeElapsed = today - submittedDate;

                                // Set the interval between emails in days
                                long emailIntervalDays = await _unitOfWork.EmailEscalation.getEmailEscDays("BTIR04");

                                // Calculate the number of occurrences that have happened so far
                                long occurrences = (long)(timeElapsed.TotalDays / emailIntervalDays) + 1;

                                // Set the threshold for escalation
                                long escalationThreshold = await _unitOfWork.EmailEscalation.getEmailEscOccurunces("BTIR04");

                                // Check if escalation email should be sent
                                if (escalationThreshold > 0 && occurrences > escalationThreshold)
                                {
                                    // Send escalation email
                                    if (pirApproval.LastReminder != null && _configuration["ServerMode"] == "Prod")
                                    {
                                        var cfdh = await _unitOfWork.Employee.GetByMuNumber(pirApproval.chr);
                                        if (cfdh != null && cfdh.SUPERVISOR_ID != null)
                                        {
                                            emailSendConfigDTO.ccRecipients = new List<string>();
                                            var UctFpEmail = await _commonService.GetEmailBymuNO(cfdh.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                                        }
                                    }
                                }

                                // ChallengeKeywordDTO pirObj = await _unitOfWork.ChallengeRegistration.MapChallengeForEmail((pirApproval.ChallengeId.Value));

                                EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                {
                                    var emailResult = await MapSolutionReviewEmail(emailSendConfigDTO, pirApproval.id);
                                    if (emailResult)
                                    {
                                        ChallengeResponse updateItem = await _unitOfWork.ChallengeResponse.GetAsync(pirApproval.id);
                                        updateItem.LastReminder = DateTime.Now.Date;
                                        _unitOfWork.ChallengeResponse.Update(updateItem);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                    else if (TemplateCode.Equals("BTIR05"))
                    {
                        var WeeklyReminderList = await _unitOfWork.ChallengeRegistration.ReminderWhenSolutionWithUCT();
                        if (WeeklyReminderList != null && WeeklyReminderList.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (ChallengeDetailDTO pirApproval in WeeklyReminderList)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                var ReminderUser = await _commonService.GetEmailBymuNO(pirApproval.uct);
                                emailSendConfigDTO.toRecipients.Add(ReminderUser);

                                // Email Escalation Start
                                DateTime submittedDate = pirApproval.actionOn.Value;
                                DateTime today = DateTime.Today;

                                // Calculate the time elapsed between submitted date and today
                                TimeSpan timeElapsed = today - submittedDate;

                                // Set the interval between emails in days
                                long emailIntervalDays = await _unitOfWork.EmailEscalation.getEmailEscDays("BTIR05");

                                // Calculate the number of occurrences that have happened so far
                                long occurrences = (long)(timeElapsed.TotalDays / emailIntervalDays) + 1;

                                // Set the threshold for escalation
                                long escalationThreshold = await _unitOfWork.EmailEscalation.getEmailEscOccurunces("BTIR05");

                                // Check if escalation email should be sent
                                if (escalationThreshold > 0 && occurrences > escalationThreshold)
                                {
                                    // Send escalation email
                                    if (pirApproval.LastReminder != null && _configuration["ServerMode"] == "Prod")
                                    {
                                        var cfdh = await _unitOfWork.Employee.GetByMuNumber(pirApproval.uct);
                                        if (cfdh != null && cfdh.SUPERVISOR_ID != null)
                                        {
                                            emailSendConfigDTO.ccRecipients = new List<string>();
                                            var UctFpEmail = await _commonService.GetEmailBymuNO(cfdh.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                                        }
                                    }
                                }

                                // ChallengeKeywordDTO pirObj = await _unitOfWork.ChallengeRegistration.MapChallengeForEmail((pirApproval.ChallengeId.Value));

                                EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                {
                                    var emailResult = await MapSolutionReviewEmail(emailSendConfigDTO, pirApproval.id);
                                    if (emailResult)
                                    {
                                        ChallengeResponse updateItem = await _unitOfWork.ChallengeResponse.GetAsync(pirApproval.id);
                                        updateItem.LastReminder = DateTime.Now.Date;
                                        _unitOfWork.ChallengeResponse.Update(updateItem);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                    else if (TemplateCode.Equals("BTIR06"))
                    {
                        var WeeklyReminderList = await _unitOfWork.ChallengeRegistration.ReminderWhenPainAreaWithAFP();
                        if (WeeklyReminderList != null && WeeklyReminderList.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (PainAreaDTO pirApproval in WeeklyReminderList)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                var muNosTo = await _unitOfWork.PainAreas.GetAllAssetsMuNo(pirApproval.assetId.Value);
                                for (int i = 0; i < muNosTo.Count; i++)
                                {
                                    EmployeeDTO empdata = await _unitOfWork.Employee.GetByMuNumber(muNosTo[i]);
                                    if (empdata != null)
                                    {
                                        emailSendConfigDTO.toRecipients.Add(empdata.EMAIL_ADDRESS);
                                        if (emailSendConfigDTO.RecipientsNames == null)
                                        {
                                            emailSendConfigDTO.RecipientsNames = new List<string>();
                                        }
                                        emailSendConfigDTO.RecipientsNames.Add(empdata.DISPLAY_NAME);
                                    }

                                    //string email = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(muNosTo[i]);

                                }


                                // Email Escalation Start
                                DateTime submittedDate = pirApproval.actionDate.Value;
                                DateTime today = DateTime.Today;

                                // Calculate the time elapsed between submitted date and today
                                TimeSpan timeElapsed = today - submittedDate;

                                // Set the interval between emails in days
                                long emailIntervalDays = await _unitOfWork.EmailEscalation.getEmailEscDays("BTIR06");

                                // Calculate the number of occurrences that have happened so far
                                long occurrences = (long)(timeElapsed.TotalDays / emailIntervalDays) + 1;

                                // Set the threshold for escalation
                                long escalationThreshold = await _unitOfWork.EmailEscalation.getEmailEscOccurunces("BTIR06");

                                // Check if escalation email should be sent
                                if (escalationThreshold > 0 && occurrences > escalationThreshold)
                                {
                                    // Send escalation email
                                    if (pirApproval.LastReminder != null && _configuration["ServerMode"] == "Prod")
                                    {
                                        for (int i = 0; i < muNosTo.Count; i++)
                                        {
                                            var cfdh = await _unitOfWork.Employee.GetByMuNumber(muNosTo[i]);
                                            if (cfdh != null && cfdh.SUPERVISOR_ID != null)
                                            {
                                                emailSendConfigDTO.ccRecipients = new List<string>();
                                                var UctFpEmail = await _commonService.GetEmailBymuNO(cfdh.SUPERVISOR_ID);
                                                emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                                            }
                                        }
                                    }
                                }

                                BTMAssessmentKeywordDTO btmObj = await _unitOfWork.BTMAssesment.GetBTMAssessmentByPainAreaId(pirApproval.id);

                                EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                {
                                    var emailResult = await _painareaService.MapBTMForEmail(emailSendConfigDTO, pirApproval.id, btmObj, "BTIR06");
                                    if (emailResult)
                                    {
                                        PainArea updateItem = await _unitOfWork.PainAreas.GetAsync(pirApproval.id);
                                        updateItem.LastReminder = DateTime.Now.Date;
                                        _unitOfWork.PainAreas.Update(updateItem);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return 0;
        }

        public async Task<List<SolutionReviewerListDTO>> SolutionReviewerList(long solId)
        {
            return await _unitOfWork.ChallengeResponse.SolutionReviewerList(solId);
        }

        public async Task<List<ChallengeReassignmentListDTO>> ChallengeReassignmentList(long roleId, string CompanyNumber)
        {
            return await _unitOfWork.ChallengeResponse.ChallengeReassignmentList(roleId, CompanyNumber);
        }

        public async Task<List<AllPDOUsersDTO>> SolutionReviewerByChaId(long chaId)
        {
            return await _unitOfWork.ChallengeResponse.SolutionReviewerByChaId(chaId);
        }

        public async Task<List<AllPDOUsersDTO>> CFDHByChaId(long chaId)
        {
            return await _unitOfWork.ChallengeResponse.CFDHByChaId(chaId);
        }
        public async Task<List<AllPDOUsersDTO>> getchallengeFP(long chaId)
        {
            return await _unitOfWork.ChallengeResponse.getCHFPChaId(chaId);
        }

        public async Task<ChallengeRegistration> GetChallengeForReAssignment(long Id)
        {
            return await _unitOfWork.ChallengeRegistration.GetFirstOrDefaultAsync(x => x.Id == Id);
        }

        public async Task<ChallengeDetail> GetChallengeDetailForReAssignment(long Id)
        {
            return await _unitOfWork.ChallengeDetail.GetFirstOrDefaultAsync(x => x.ChallengeId == Id);
        }


        public async Task<List<SolutionReviewerListDTO>> SolutionReviewerListByChaId(long chaId)
        {
            return await _unitOfWork.ChallengeResponse.SolutionReviewerListByChaId(chaId);
        }


        public async Task<long> UpdateChallengeForReAssignment(ChallengeRegistration obj)
        {
            try
            {
                _unitOfWork.ChallengeRegistration.Update(obj);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return obj.Id;
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public async Task<long> UpdateChallengeDetailsForReAssignment(ChallengeDetail obj)
        {
            try
            {
                _unitOfWork.ChallengeDetail.Update(obj);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return obj.Id;
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<long> AddChallengeReviewersForReAssignment(List<ChallengeSolutionReviewer> challengeSolutionReviewer, ChallengeReassignReviewerDTO recevingDTO, EmployeeDTO? LoggedInUser = null, List<SolutionReviewerListDTO>? OldSR = null)
        {
            try
            {
                if (challengeSolutionReviewer == null || challengeSolutionReviewer.Count == 0)
                    throw new ArgumentException("Solution reviewers are required.");

                long chaId = challengeSolutionReviewer[0].ChallengeId;
                var allSR = (await _unitOfWork.ChallengeSolutionReviewers.GetAllAsync(a => a.ChallengeId.Equals(chaId))).ToList();

                var listofUpdatedSR = recevingDTO.SolutionReviewers?
                    .Where(x => !string.IsNullOrWhiteSpace(x.PERSONNEL_NUMBER))
                    .Select(c => c.PERSONNEL_NUMBER.Trim())
                    .ToList() ?? new List<string>();

                var listofCurrentDBSR = OldSR?
                    .Where(x => !string.IsNullOrWhiteSpace(x.muNo))
                    .Select(c => c.muNo.Trim())
                    .ToList() ?? new List<string>();


                var NewAddedSR = listofUpdatedSR.Except(listofCurrentDBSR).ToList();
                var RemovedASR = listofCurrentDBSR.Except(listofUpdatedSR).ToList();


                foreach (var item in RemovedASR)
                {
                    var srEmp = await GetEmmployeeBymuNO(item);
                    await SendReassignEmail(recevingDTO.ChallengeId, EmailModules.TMHPC, "TMH017", recevingDTO.ChaRefNo, null, srEmp.EmailAddress, srEmp.EmployeeName, LoggedInUser, null);
                }



                foreach (var item in NewAddedSR)
                {
                    var srEmp = await GetEmmployeeBymuNO(item);

                    AllPDOUsersDTO user = new AllPDOUsersDTO() { EMAIL_ADDRESS = srEmp.EmailAddress, USER_DISPLAY = srEmp.EmployeeName };
                    await SendReassignEmail(recevingDTO.ChallengeId, EmailModules.TMHPC, "TMH016", recevingDTO.ChaRefNo, user, "", "", LoggedInUser, null);
                }


                if (allSR.Count > 0)
                {
                    _unitOfWork.ChallengeSolutionReviewers.RemoveRange(allSR);
                }

                foreach (var reviewer in challengeSolutionReviewer)
                {
                    reviewer.Id = 0;
                    if (!string.IsNullOrWhiteSpace(reviewer.Reviewer) && reviewer.Reviewer.Length > 10)
                        reviewer.Reviewer = reviewer.Reviewer.Substring(0, 10);
                }

                await _unitOfWork.ChallengeSolutionReviewers.AddRangeAsync(challengeSolutionReviewer);
                long result = await _unitOfWork.SaveAsync();
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private async Task<TmEmployee> GetEmmployeeBymuNO(string muNo)
        {
            return await _unitOfWork.Employee.GetFirstOrDefaultAsync(x => x.CompanyNumber == muNo);
        }

        #region Reports ~ Fazal, Rahim IDAP1X

        public async Task<OverAllReportResponseDTO> OverAllReport(OverAllReportRequestDTO overAllReportDTO, EmployeeDTO? LoggedInUser)
        {
            return await _unitOfWork.ChallengeDetail.OverAllReport(overAllReportDTO, LoggedInUser);
        }

        public async Task<ReportPrintDTO> OARPrint(OverAllReportRequestDTO overAllReportDTO)
        {
            OverAllReportResponseDTO result = new OverAllReportResponseDTO();
            result = await _unitOfWork.ChallengeDetail.OverAllReport(overAllReportDTO, null);
            string[] streamIds;
            string mimeType = string.Empty;
            string encoding = string.Empty;
            string filetype = string.Empty;
            string BaseURL = _configuration["ExternalApplicationPath"];
            foreach (var item in result.allData)
            {
                if (!String.IsNullOrEmpty(item.chaEncrptId))
                {
                    item.ChallengeReviewFormURL = ExtensionMethods.GetChallengeFormURL(BaseURL, item.chaEncrptId);
                }
                if (!String.IsNullOrEmpty(item.ctrEncrptId))
                {
                    item.TTAReviewFormURL = ExtensionMethods.GetTTAFormURL(BaseURL, item.ctrEncrptId);

                }
                if (!String.IsNullOrEmpty(item.pirEncrptId))
                {
                    item.PIRReviewFormURL = ExtensionMethods.GetPIRFormURL(BaseURL, item.pirEncrptId);

                }
                if (!String.IsNullOrEmpty(item.resEncrptId))
                {
                    item.SolutionReviewFormURL = ExtensionMethods.GetSolutionReviwerFormURL(BaseURL, item.resEncrptId, item.source, item.status);

                

                }

            }

            string fileName = string.Format("{0}.{1}", "OverAll Report" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());

            LocalReport localReport = new LocalReport();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Encoding.GetEncoding("windows-1252");
            string fileDirPath = Assembly.GetExecutingAssembly().Location.Replace("TIP_BAL.dll", string.Empty);
            string rdlcFilePath = "";
            rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "OverAllReport");
            localReport.ReportPath = rdlcFilePath;
            localReport.EnableExternalImages = true;
            localReport.EnableHyperlinks = true;
            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("ReportName", "Over All Report (Internal)") });
            localReport.DataSources.Add(new ReportDataSource() { Name = "OverAllDataDTO", Value = result.allData });
         
            localReport.Refresh();
            mimeType = string.Empty;
            encoding = string.Empty;
            string extension = string.Empty;

            byte[] bytes = localReport.Render(overAllReportDTO.docType, null, out mimeType, out encoding, out extension, out streamIds, out Microsoft.Reporting.NETCore.Warning[] warnings);
            return new ReportPrintDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
        }

        public async Task<TechKPIReportResponseDTO> TechKPIReport(TechKPIReportRequestDTO techKPIReportRequestDTO, EmployeeDTO? LoggedInUser)
        {
            return await _unitOfWork.ChallengeDetail.TechKPIReport(techKPIReportRequestDTO, LoggedInUser);
        }

        public async Task<ReportPrintDTO> TKRPrint(TechKPIReportRequestDTO techKPIReportRequestDTO)
        {
            TechKPIReportResponseDTO result = new TechKPIReportResponseDTO();
            result = await _unitOfWork.ChallengeDetail.TechKPIReport(techKPIReportRequestDTO, null);
            string kpiConfig = result.kpiConfig;

            string BaseURL = _configuration["ExternalApplicationPath"];
            foreach (var item in result.allData)
            {
                if (!String.IsNullOrEmpty(item.chaEncrptId))
                {
                    item.ChallengeReviewFormURL = ExtensionMethods.GetChallengeFormURL(BaseURL, item.chaEncrptId);
                }
                if (!String.IsNullOrEmpty(item.ctrEncrptId))
                {
                    item.TTAReviewFormURL = ExtensionMethods.GetTTAFormURL(BaseURL, item.ctrEncrptId);
                }
                if (!String.IsNullOrEmpty(item.pirEncrptId))
                {
                    item.PIRReviewFormURL = ExtensionMethods.GetPIRFormURL(BaseURL, item.pirEncrptId);
                }
             
             
            

            }
            string[] streamIds;
            string mimeType = string.Empty;
            string encoding = string.Empty;
            string filetype = string.Empty;
            string fileName = string.Format("{0}.{1}", "Technology KPI Report" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());

            LocalReport localReport = new LocalReport();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Encoding.GetEncoding("windows-1252");
            string fileDirPath = Assembly.GetExecutingAssembly().Location.Replace("TIP_BAL.dll", string.Empty);
            string rdlcFilePath = "";
            rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "TechKPIReport");
            localReport.ReportPath = rdlcFilePath;
            localReport.EnableExternalImages = true;
            localReport.EnableHyperlinks = true;
            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("ReportName", "Technology KPI Report (Internal)") });
            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("KpiConfig", kpiConfig) });
            localReport.DataSources.Add(new ReportDataSource() { Name = "TechKPIDataDTO", Value = result.allData });
         
            localReport.Refresh();
            mimeType = string.Empty;
            encoding = string.Empty;
            string extension = string.Empty;

            byte[] bytes = localReport.Render(techKPIReportRequestDTO.docType, null, out mimeType, out encoding, out extension, out streamIds, out Microsoft.Reporting.NETCore.Warning[] warnings);
            return new ReportPrintDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
        }

        public async Task<MasterReportResponseDTO> MasterReport(MasterReportRequestDTO masterReportDTO, EmployeeDTO? LoggedInUser)
        {
            return await _unitOfWork.ChallengeDetail.MasterReport(masterReportDTO, LoggedInUser);
        }

        public async Task<ReportPrintDTO> MasterReportPrint(MasterReportRequestDTO masterReportRequestDTO)
        {
            MasterReportResponseDTO result = new MasterReportResponseDTO();
            result = await _unitOfWork.ChallengeDetail.MasterReport(masterReportRequestDTO, null);

            string[] streamIds;
            string mimeType = string.Empty;
            string encoding = string.Empty;
            string filetype = string.Empty;
            string fileName = string.Format("{0}.{1}", "Master Sheet Report" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());

            LocalReport localReport = new LocalReport();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Encoding.GetEncoding("windows-1252");
            string fileDirPath = Assembly.GetExecutingAssembly().Location.Replace("TIP_BAL.dll", string.Empty);
            string rdlcFilePath = "";
            rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "MasterReport");
            localReport.ReportPath = rdlcFilePath;
            localReport.SetParameters(new List<ReportParameter> { new ReportParameter("ReportName", "Master Sheet Report (Internal)") });
            localReport.DataSources.Add(new ReportDataSource() { Name = "MasterSheetDataDTO", Value = result.allData });
            localReport.EnableExternalImages = true;
            localReport.EnableHyperlinks = true;
            localReport.Refresh();
            mimeType = string.Empty;
            encoding = string.Empty;
            string extension = string.Empty;

            byte[] bytes = localReport.Render(masterReportRequestDTO.docType, null, out mimeType, out encoding, out extension, out streamIds, out Microsoft.Reporting.NETCore.Warning[] warnings);
            return new ReportPrintDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
        }


        #endregion


        #region Map Reassignment Challenge Email ~ Fazal, Rahim IDAP1X

        public async Task<bool> SendReassignEmail(long Id, string Module, string TemplateCode, string RefNo, AllPDOUsersDTO? newUser = null, string? oldEmail = "", string? oldUserName = "", EmployeeDTO? loggedInUser = null, List<AllPDOUsersDTO>? newEmails = null)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                if (Template != null)
                {
                    emailSendConfigDTO.ccRecipients = new List<string>();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                    var senderEmail = await _commonService.GetEmailBymuNO(loggedInUser.COMPANY_NUMBER);
                    emailSendConfigDTO.ccRecipients.Add(senderEmail);

                    if (TemplateCode.Equals("TMH012")) // New UCT
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        emailSendConfigDTO.toRecipients.Add(newUser.EMAIL_ADDRESS);
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ResponseNumber", RefNo?.ToString());
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", newUser?.USER_DISPLAY?.ToString());
                        }
                    }

                    else if (TemplateCode.Equals("TMH013")) // Old UCT
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        emailSendConfigDTO.toRecipients.Add(oldEmail);
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ResponseNumber", RefNo?.ToString());
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", oldUserName?.ToString());
                        }
                    }

                    else if (TemplateCode.Equals("TMH014")) // New CR
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        emailSendConfigDTO.toRecipients.Add(newUser.EMAIL_ADDRESS);
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ResponseNumber", RefNo?.ToString());
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ChallengeFPName", newUser?.USER_DISPLAY?.ToString());
                        }
                    }

                    else if (TemplateCode.Equals("TMH015")) // Old CR
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        emailSendConfigDTO.toRecipients.Add(oldEmail);
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ResponseNumber", RefNo?.ToString());
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ChallengeFPName", oldUserName?.ToString());
                        }
                    }
                    else if (TemplateCode.Equals("TMH016")) // New SR
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        emailSendConfigDTO.toRecipients.Add(newUser.EMAIL_ADDRESS);
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ResponseNumber", RefNo?.ToString());
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SolutionFPName", newUser?.USER_DISPLAY?.ToString());
                        }
                    }

                    else if (TemplateCode.Equals("TMH017")) // Old SR
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        emailSendConfigDTO.toRecipients.Add(oldEmail);
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ResponseNumber", RefNo?.ToString());
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SolutionFPName", oldUserName?.ToString());
                        }
                    }
                    else if (TemplateCode.Equals("TMH018")) // New CFDH
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        emailSendConfigDTO.toRecipients.Add(newUser.EMAIL_ADDRESS);
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ResponseNumber", RefNo?.ToString());
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$CFDH", newUser?.USER_DISPLAY?.ToString().ToString());
                        }
                    }
                    else if (TemplateCode.Equals("TMH019")) // Old CFDH
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        emailSendConfigDTO.toRecipients.Add(oldEmail);
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ResponseNumber", RefNo?.ToString());
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$CFDH", oldUserName?.ToString());
                        }
                    }
                }

                return await _commonService.SendEmail(emailSendConfigDTO, loggedInUser);
            }
            return false;
        }

        #endregion

        #region Map Challenge Email ~ Fazal, Rahim IDAP1X
        public async Task<bool> MapChallengeForEmail(EmailSendConfigDTO emailSendConfigDTO, long chanlengeRegId)
        {
            ChallengeKeywordDTO obj = null;
            obj = await _unitOfWork.ChallengeRegistration.MapChallengeForEmail(chanlengeRegId);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ChallengeTitle", obj?.challengeTitle?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$MaturityLevel", obj?.maturityLevel?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Area", obj?.area?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Application", obj?.application?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Theme", obj?.theme?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SubTheme", obj?.subTheme?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$AllScore", obj?.allScore?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionStatus", obj?.actionStatus?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$StartDate", obj?.startDate?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionBy", obj?.actionBy?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionCompletionDate", obj?.actionCompletionDate?.ToString());
            if (emailSendConfigDTO.RecipientsNames != null && emailSendConfigDTO.RecipientsNames.Count > 0)
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ToUserNames", string.Join(',', emailSendConfigDTO.RecipientsNames));
            }
            else
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ToUserNames", "Recipient");
            }
            string host = _configuration["TIPApplicationPath"];
            EmployeeDTO? sender = _commonService.GetIdentityOfLoggedInUser("CORP\\" + obj?.sendrMU);

            if (emailSendConfigDTO.templateCode.Equals("BTI001"))
            {
                string link = host + "/#/bti/challenge-reveiew?r_c=CFDH";

                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view submitted Challanges : " + "<a href='" + link + "'>Link</a>";
                }
            }
            else if (emailSendConfigDTO.templateCode.Equals("BTI002"))
            {
                string link = host + "/#/bti/challenge-reveiew?r_c=CFDH";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view re-submitted Challanges : " + "<a href='" + link + "'>Link</a>";
                }
            }
            else if (emailSendConfigDTO.templateCode.Equals("BTI003"))
            {
                string link = host + "/#/bti/challenge-reveiew?r_c=UCT";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view re-submitted the Challange's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            else if (emailSendConfigDTO.templateCode.Equals("BTI004") || emailSendConfigDTO.templateCode.Equals("BTI005"))
            {
                string link = host + "/#/bti/manage-challenge-registrations?r_c=CHR";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view approved  Challanges : " + "<a href='" + link + "'>Link</a>";
                }
            }
            else if (emailSendConfigDTO.templateCode.Equals("BTI006"))
            {
                string link = host + "/#/bti/manage-challenge-registrations?r_c=CHR&s="+obj.challengeTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view send back Challanges : " + "<a href='" + link + "'>Link</a>";
                }
            }
            else if (emailSendConfigDTO.templateCode.Equals("BTI007"))
            {
                string link = host + "/#/bti/challenge-reveiew?r_c=UCT";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view selected Challange's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            else if (emailSendConfigDTO.templateCode.Equals("BTI008"))
            {
                string link = host + "/#/bti/manage-challenge-registrations?r_c=CHR&s=" + obj.challengeTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view send back Challange's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            else if (emailSendConfigDTO.templateCode.Equals("BTI009"))
            {
                string link = host + "/#/bti/manage-challenge-registrations?r_c=CHR&s=" + obj.challengeTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view published Challanges : " + "<a href='" + link + "'>Link</a>";
                }
            }
            else if (emailSendConfigDTO.templateCode.Equals("BTI0010"))
            {
                string link = host + "/#/bti/manage-challenge-registrations?r_c=CHR&s=" + obj.challengeTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view rejected Challange's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            else if (emailSendConfigDTO.templateCode.Equals("BTI0011"))
            {
                string link = host + "/#/bti/challenge-reveiew?r_c=CFDH";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view submitted Challanges : " + "<a href='" + link + "'>Link</a>";
                }
            }
            else if (emailSendConfigDTO.templateCode.Equals("BTI0012"))
            {
                string link = host + "/#/bti/challenge-reveiew?r_c=UCT";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view submitted Challanges : " + "<a href='" + link + "'>Link</a>";
                }
            }
            return await _commonService.SendEmail(emailSendConfigDTO, sender);
        }
        #endregion

        #region Map TMH Module Email ~ Fazal, Rahim IDAP1X
        public async Task<bool> MapSolutionReviewEmail(EmailSendConfigDTO emailSendConfigDTO, long chaResponseId)
        {
            ChallengeReviewKeywordDTO obj = null;
            obj = await _unitOfWork.ChallengeResponseReview.MapSolutionReviewEmail(chaResponseId);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Id", obj?.vendorQId?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ResponseNumber", obj?.responseNumber?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$TPHNumber", obj?.tphNumber?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SolutionTitle", obj?.solutionTitle?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$TechnologyTitle", obj?.technologyTitle?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Source", obj?.source?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$VendorName", obj?.vendorName?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$CompanyName", obj?.companyName?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionStatus", obj?.actionStatus?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionBy", obj?.actionBy?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Reason", obj?.comment?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionCompletionDate", obj?.actionCompletionDate?.ToString());
            if (emailSendConfigDTO.RecipientsNames != null && emailSendConfigDTO.RecipientsNames.Count > 0)
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ToUserNames", string.Join(',', emailSendConfigDTO.RecipientsNames));
            }
            else
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ToUserNames", "Recipient");
            }
            string host = _configuration["ExternalApplicationPath"];
            string hostInternal = _configuration["TIPApplicationPath"];
            if (emailSendConfigDTO.templateCode.Equals("TMH001"))
            {
                string link = host + "VendorParticipation/index";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view Published and Participated Challenges : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (emailSendConfigDTO.templateCode.Equals("TMH003") || emailSendConfigDTO.templateCode.Equals("TMH004") || emailSendConfigDTO.templateCode.Equals("TMH006"))
            {


                string link = hostInternal + "/#/tmh/solution-review";
                if (emailSendConfigDTO.templateCode.Equals("TMH003"))
                    link = link + "?r_c=CHR";
                else if (emailSendConfigDTO.templateCode.Equals("TMH004") || emailSendConfigDTO.templateCode.Equals("TMH006"))
                    link = link + "?r_C=UCT";
                link = link + "&s=" + obj.solutionTitle;

                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view external users challenge's solution : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (emailSendConfigDTO.templateCode.Equals("TMH007"))
            {
                string link = hostInternal + "/#/tmh/solution-review?r_c=CHR";
                link = link + "&s=" + obj.solutionTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to review solutions  : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (emailSendConfigDTO.templateCode.Equals("TMH008"))
            {
                string link = hostInternal + "/#//bti/manage-challenge-registrations?r_c=CHR";
                link = link + "&s=" + obj.challengeRef;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>To read and answer the query, click here : " + "<a href='" + link + "'>Link</a>";
                }
            }

            if (emailSendConfigDTO.templateCode.Equals("TMH009"))
            {
                string link = hostInternal + "/#/tmh/solution-review?r_c=CHR";
                link = link + "&s=" + obj.solutionTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>The vendor has respond the query, To take an action on this request, click here : " + "<a href='" + link + "'>Link</a>";
                }
            }

            if (emailSendConfigDTO.templateCode.Equals("TMH010"))
            {
                string link = host + "VendorParticipation/Solution?cfcode=" + CryptoExtensions.Encrypt(chaResponseId.ToString());
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>The PDO user has respond the query, To take an action on this request, click here : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (emailSendConfigDTO.templateCode.Equals("TMH011"))
            {
                string link = host + "VendorParticipation/Queries?cfcode=" + CryptoExtensions.Encrypt(chaResponseId.ToString());
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>The PDO user has submitted a query, To take an action on this request, click here : " + "<a href='" + link + "'>Link</a>";
                }
            }
            //BTIR04
            if (emailSendConfigDTO.templateCode.Equals("BTIR04"))
            {
                string link = hostInternal + "/#/tmh/solution-review?r_c=CHR";
                link = link + "&s=" + obj.solutionTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br> To take an action on this request, click here : " + "<a href='" + link + "'>Link</a>";
                }
            }
            //BTIR04
            if (emailSendConfigDTO.templateCode.Equals("BTIR05"))
            {
                string link = hostInternal + "/#/tmh/solution-review?r_c=UCT";
                link = link + "&s=" + obj.solutionTitle;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br> To take an action on this request, click here : " + "<a href='" + link + "'>Link</a>";
                }
            }

            return await _commonService.SendEmail(emailSendConfigDTO);
        }

        public async Task<bool> MapPublishChallengeEmail(EmailSendConfigDTO emailSendConfigDTO, long chanlengeRegId)
        {
            ChallengPublishKeywordDTO obj = null;
            obj = await _unitOfWork.ChallengeDetail.MapChallengePublishedEmail(chanlengeRegId);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$TPHNumber", obj?.tphNumber?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ChallengeTitle", obj?.challengeTitle?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$StartDate", obj?.startDate?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$LastDateForQuery", obj?.lastDateOfQuery?.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$LastDateForResponse", obj?.lastDataOfResponse?.ToString());
            string host = _configuration["ExternalApplicationPath"];
            if (emailSendConfigDTO.RecipientsNames != null && emailSendConfigDTO.RecipientsNames.Count > 0)
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ToUserNames", string.Join(',', emailSendConfigDTO.RecipientsNames));
            }
            else
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ToUserNames", "Recipient");
            }
            if (emailSendConfigDTO.templateCode.Equals("TMH002"))
            {
                string link = host;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view published Challanges : " + "<a href='" + link + "'>Link</a>";
                }
            }
            return await _commonService.SendEmail(emailSendConfigDTO);
        }


        #endregion

        #region TMH_Emails
        public async Task<bool> SendEmail_SolutionSubmitted(ChallengeResponse DTO)
        {
            ChallengeRegistration challengeRegistration = await _unitOfWork.ChallengeRegistration.GetFirstOrDefaultAsync(x => x.Id == DTO.ChallengeRegistrationId);
            IEnumerable<ChallengeSolutionReviewer> Srs = await _unitOfWork.ChallengeSolutionReviewers.GetAllAsync(x => x.ChallengeId == DTO.ChallengeRegistrationId);
            string TemplateCode = "TMH007";

            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, EmailModules.TMHPC);
            var result = false;
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                // CtrInitiationDTO ctrObj = await _unitOfWork.Ctr.CTREmailData(CTRId, TemplateCode);
                if (Template != null)
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    emailSendConfigDTO.ccRecipients = new List<string>();
                    string toEmail = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(challengeRegistration.RequestedBy);
                    emailSendConfigDTO.toRecipients.Add(toEmail);
                    foreach (var recipient in Srs)
                    {
                        toEmail = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(recipient.Reviewer);
                        emailSendConfigDTO.ccRecipients.Add(toEmail);
                    }
                    emailSendConfigDTO.subject = Template.MailSubject;
                    emailSendConfigDTO.body = Template.MailBody;
                    EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                   

                    if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        await MapSolutionReviewEmail(emailSendConfigDTO, DTO.Id);
                    result = true;
                    
                }
            }
            return result;
        }

        public async Task<bool> SendEmail_VendersendQuery(ChallengeResponse DTO)
        {
            ChallengeRegistration challengeRegistration = await _unitOfWork.ChallengeRegistration.GetFirstOrDefaultAsync(x => x.Id == DTO.ChallengeRegistrationId);

            string TemplateCode = "TMH008";
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, EmailModules.TMHPC);
            var result = false;
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                
                if (Template != null)
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    emailSendConfigDTO.ccRecipients = new List<string>();
                    string toEmail = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(challengeRegistration.RequestedBy);
                    emailSendConfigDTO.toRecipients.Add(toEmail);
                    string ccEmail = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(challengeRegistration.UctFp);
                    emailSendConfigDTO.ccRecipients.Add(ccEmail);
                    emailSendConfigDTO.subject = Template.MailSubject;
                    emailSendConfigDTO.body = Template.MailBody;
                    EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                    

                    if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        await MapSolutionReviewEmail(emailSendConfigDTO, DTO.Id);
                    result = true;
                }
            }
            return result;
        }

        public async Task<bool> SendEmail_VendersendQueryResponse(ChallengeResponse DTO)
        {

            string TemplateCode = "TMH010";
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, EmailModules.TMHPC);
            var result = false;
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                
                if (Template != null)
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    emailSendConfigDTO.ccRecipients = new List<string>();

                    string toEmail = await _unitOfWork.ChallengeResponse.ExternalEmail(DTO.CreatedBy);
                    emailSendConfigDTO.toRecipients.Add(toEmail);


                    string crMU = await _unitOfWork.ChallengeDetail.GetCRByResponseID(DTO.Id);
                    string crEmail = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(crMU);
                    emailSendConfigDTO.ccRecipients.Add(crEmail);
                    emailSendConfigDTO.subject = Template.MailSubject;
                    emailSendConfigDTO.body = Template.MailBody;
                    EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                    

                    if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        await MapSolutionReviewEmail(emailSendConfigDTO, DTO.Id);
                    result = true;
                }
            }
            return result;
        }

        public async Task<bool> SendEmail_PDOsendQuery(ChallengeResponse DTO, EmployeeDTO emp)
        {

            string TemplateCode = "TMH011";
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, EmailModules.TMHPC);
            var result = false;
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                
                if (Template != null)
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    emailSendConfigDTO.ccRecipients = new List<string>();
                    string toEmail = await _unitOfWork.ChallengeResponse.ExternalEmail(DTO.CreatedBy);
                    string ccEmail = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(emp.COMPANY_NUMBER);
                    string crMU = await _unitOfWork.ChallengeDetail.GetCRByResponseID(DTO.Id);
                    string crEmail = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(crMU);
                    emailSendConfigDTO.toRecipients.Add(toEmail);
                    emailSendConfigDTO.ccRecipients.Add(ccEmail);
                    emailSendConfigDTO.ccRecipients.Add(crEmail);
                    emailSendConfigDTO.subject = Template.MailSubject;
                    emailSendConfigDTO.body = Template.MailBody;
                    EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                    

                    if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        await MapSolutionReviewEmail(emailSendConfigDTO, DTO.Id);
                    result = true;
                    
                }
            }
            return result;
        }

        public async Task<bool> SendEmail_PDOsendQueryResponse(string MU, long responseId)
        {
            string TemplateCode = "TMH009";
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, EmailModules.TMHPC);
            var result = false;
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                
                if (Template != null)
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    emailSendConfigDTO.toRecipients = new List<string>();

                    string toEmail = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(MU);
                    emailSendConfigDTO.toRecipients.Add(toEmail);
                    emailSendConfigDTO.subject = Template.MailSubject;
                    emailSendConfigDTO.body = Template.MailBody;
                    EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                    

                    if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        await MapSolutionReviewEmail(emailSendConfigDTO, responseId);
                    result = true;
                }
            }
            return result;
        }

        public async Task<ChallengeResponseReport> GetChallengesResponseReport(ChallengeReportRequestDTO ChallengeReportRequestDTO, EmployeeDTO? LoggedInUser)
        {
            return await _unitOfWork.ChallengeResponse.GetChallengesResponseReport(ChallengeReportRequestDTO, LoggedInUser);
        }

        public async Task<ReportPrintDTO> PrintChallengesResponseReport(ChallengeReportRequestDTO ChallengeReportRequestDTO, EmployeeDTO? LoggedInUser)
        {
            try
            {
                ChallengeResponseReport result = new ChallengeResponseReport();
                result = await GetChallengesResponseReport(ChallengeReportRequestDTO, LoggedInUser);

                string BaseURL = _configuration["ExternalApplicationPath"];
                string BaseURLofApplication = BaseURL.Trim();
                string BaseURLofChallenge = "/bti/challenge-registration-crud?";
                string BaseURLOfSolution = "/tmh/review-form?";
                foreach (var item in result?.data)
                {
                    if (!String.IsNullOrEmpty(item.chaEncrptId))
                    {
                        item.ChallengeReviewFormURL = ExtensionMethods.GetChallengeFormURL(BaseURL, item.chaEncrptId);

                    }
                    if (!String.IsNullOrEmpty(item.resEncrptId))
                    {
                        item.SolutionReviewFormURL = ExtensionMethods.GetSolutionReviwerFormURL(BaseURL, item.resEncrptId, item.source, item.status);

                    }
                }
                string[] streamIds;
                string mimeType = string.Empty;
                string encoding = string.Empty;
                string filetype = string.Empty;
                string fileName = string.Format("{0}.{1}", "All Solutions Report" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());

                LocalReport localReport = new LocalReport();
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                Encoding.GetEncoding("windows-1252");
                string fileDirPath = Assembly.GetExecutingAssembly().Location.Replace("TIP_BAL.dll", string.Empty);
                string rdlcFilePath = "";
                rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "AllSolutionsReport");
                localReport.EnableHyperlinks = true;

                localReport.ReportPath = rdlcFilePath;
                localReport.SetParameters(new List<ReportParameter> { new ReportParameter("ReportName", "All Solutions Report (Internal)") });
                localReport.SetParameters(new List<ReportParameter> { new ReportParameter("BaseURLofChallenge", BaseURLofChallenge.ToString()) });
                localReport.SetParameters(new List<ReportParameter> { new ReportParameter("BaseURLOfSolution", BaseURLOfSolution.ToString()) });
                localReport.SetParameters(new List<ReportParameter> { new ReportParameter("BaseURLofApplication", BaseURLofApplication.ToString()) });


                localReport.DataSources.Add(new ReportDataSource() { Name = "AllSolutions", Value = result.data });
                localReport.EnableExternalImages = true;

                localReport.Refresh();
                mimeType = string.Empty;
                encoding = string.Empty;
                string extension = string.Empty;

                byte[] bytes = localReport.Render(ChallengeReportRequestDTO.docType, null, out mimeType, out encoding, out extension, out streamIds, out Microsoft.Reporting.NETCore.Warning[] warnings);
                return new ReportPrintDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }


        

        #endregion

    }
}
