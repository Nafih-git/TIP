﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_BAL.Interface;
using TIP_BAL.Interface.Admin;
using TIP_BusinessLogic.Interface;
using TIP_Core;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using static TIP_Common.Enum.Enum;

namespace TIP_BAL.Services.Admin
{
    public class UserSettingEFService: IUserSettingEFService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICommonService _commonService;

        public UserSettingEFService(IUnitOfWork unitOfWork, ICommonService commonService)
        {
            _unitOfWork = unitOfWork;
            _commonService = commonService;
        }


        public async Task<List<EmployeeDL>> GetApplicationUser()
        {
            try
            {
                return await _unitOfWork.UserSettings.GetApplicationUserDTO();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<UserRolesDTO>> GetPMRoles()
        {
            try
            {
                return await _unitOfWork.UserSettings.GetPMRoles();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<TmUserRole> GetUserRoleById(long roleID)
        {
            try
            {
                return await _unitOfWork.UserSettings.GetUserRoleById(roleID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<FPLinkEmployeeDL> GetApplicationFPDetailsDTO()
        {
            try
            {
                return await _unitOfWork.UserSettings.GetApplicationFPDetailsDTO();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<List<ExternalUserDTO>> GetExternalUser()
        {
            return _unitOfWork.ExternalUser.GetExternaluser();
        }

        public async Task<long> UpdateFocalPointLink(FocalpointDto FPLink)
        {
            try
            {
                if (FPLink == null || string.IsNullOrWhiteSpace(FPLink.userId))
                    throw new ArgumentException("Please select a valid user.");

                FPLink.LD ??= new List<Linking>();

                long result = 0;

                if (FPLink.type == TypeCodes.AssetFP)
                {
                    var userId = FPLink.userId.Trim();
                    if (userId.Length > 20)
                        userId = userId.Substring(0, 20);

                    var existingLinks = (await _unitOfWork.AssetFP.GetAllAsync(
                        x => x.FocalPoint != null && x.FocalPoint.ToLower() == userId.ToLower())).ToList();

                    if (existingLinks.Count > 0)
                    {
                        _unitOfWork.AssetFP.RemoveRange(existingLinks);
                        await _unitOfWork.SaveAsync();
                    }

                    if (FPLink.LD.Count > 0)
                    {
                        var newLinks = new List<AssetFpLnk>();
                        for (int i = 0; i < FPLink.LD.Count; i++)
                        {
                            if (FPLink.LD[i]?.id == null || FPLink.LD[i].id <= 0)
                                continue;

                            newLinks.Add(new AssetFpLnk
                            {
                                Id = 0,
                                AssetId = FPLink.LD[i].id.Value,
                                FocalPoint = userId
                            });
                        }

                        if (newLinks.Count > 0)
                        {
                            await _unitOfWork.AssetFP.AddRangeAsync(newLinks);
                            await _unitOfWork.SaveAsync();
                            result = 1;
                        }
                    }
                }

                return result > 0 ? result : 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async  Task<long> DeleteFocalPointLink(string userid)
        {
            List<AssetFpLnk> obj;
            obj =  _unitOfWork.AssetFP.GetAllAsync(x => x.FocalPoint == userid).Result.ToList();
            try {
                _unitOfWork.AssetFP.RemoveRange(obj);
                long result = await _unitOfWork.SaveAsync();
                return 1;
            } catch { return 0; }
        }
                
        public async Task<long> DeleteClusterFocalPointLink(string userid)
        {
            List<ClusterFpLnk> obj;
            obj = _unitOfWork.ClusterFP.GetAllAsync(x => x.FocalPoint == userid).Result.ToList();
            try
            {
                _unitOfWork.ClusterFP.RemoveRange(obj);
                long result = await _unitOfWork.SaveAsync();
                return 1;
            }
            catch { return 0; }
        }

        public async Task<long> UpdateClusterFocalPointLink(FocalpointDto FPLink)
        {
            try
            {
                if (FPLink == null || string.IsNullOrWhiteSpace(FPLink.userId))
                    throw new ArgumentException("Please select a valid user.");

                FPLink.LD ??= new List<Linking>();

                long result = 0;

                if (FPLink.type == TypeCodes.ClusterFP)
                {
                    var userId = FPLink.userId.Trim();
                    if (userId.Length > 20)
                        userId = userId.Substring(0, 20);

                    var existingLinks = (await _unitOfWork.ClusterFP.GetAllAsync(
                        x => x.FocalPoint != null && x.FocalPoint.ToLower() == userId.ToLower())).ToList();

                    if (existingLinks.Count > 0)
                    {
                        _unitOfWork.ClusterFP.RemoveRange(existingLinks);
                        await _unitOfWork.SaveAsync();
                    }

                    if (FPLink.LD.Count > 0)
                    {
                        var newLinks = new List<ClusterFpLnk>();
                        for (int i = 0; i < FPLink.LD.Count; i++)
                        {
                            if (FPLink.LD[i]?.id == null || FPLink.LD[i].id <= 0)
                                continue;

                            newLinks.Add(new ClusterFpLnk
                            {
                                Id = 0,
                                ClusterId = FPLink.LD[i].id.Value,
                                FocalPoint = userId,
                                Cluster = null
                            });
                        }

                        if (newLinks.Count > 0)
                        {
                            await _unitOfWork.ClusterFP.AddRangeAsync(newLinks);
                            await _unitOfWork.SaveAsync();
                            result = 1;
                        }
                    }
                }

                return result > 0 ? result : 1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<long> UpdateActiveRole(string userId,long roleID)
        {
            try
            {
                if (roleID > 0 && !string.IsNullOrWhiteSpace(userId))
                {
                    var userKey = userId.ToUpper();
                    var roles = (await _unitOfWork.RoleToUser.GetAllAsync(
                        x => x.UserId != null && x.UserId.ToUpper() == userKey)).ToList();
                    foreach (var role in roles)
                    {
                        role.DefaultRoleId = roleID;
                    }
                    _unitOfWork.RoleToUser.UpdateRange(roles);
                    await _unitOfWork.SaveAsync();
                }
                return 1;

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


    }
}
