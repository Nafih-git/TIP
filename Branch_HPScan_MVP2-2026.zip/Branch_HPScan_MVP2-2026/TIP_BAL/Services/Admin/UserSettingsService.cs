﻿using TIP_API.DTO.Admin;
using TIP_BAL.Interface.Admin;
using TIP_CORE;
using TIP_DAL.Interface;
using TIP_DAL.Interface.Admin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_BAL.Interface;
using TIP_CORE.Entities;
using TIP_DAL.Interface.Base;
using Microsoft.EntityFrameworkCore;
using TIP_Common;
using TIP_CORE.EntitiesDTO;
using TIP_BusinessLogic.Interface;
using TIP_CORE.Admin;
using Microsoft.Extensions.Configuration;
using static TIP_Common.Enum.Enum;
using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;
using TIP_Common.Admin;
using System.Text.Encodings.Web;
using System.Text.RegularExpressions;

namespace TIP_BAL.Services.Admin
{


    public class UserSettingsService : IUserSettingsService
    {
        private readonly IuserSettingsRepository userSettingsRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICommonService _commonService;
        private readonly IConfiguration _configuration;
        
        public UserSettingsService(IUnitOfWork unitOfWork, IuserSettingsRepository userSettingsRepository, ICommonService commonService, IConfiguration configuration, HtmlEncoder encoder)
        {
            _unitOfWork = unitOfWork;
            this.userSettingsRepository = userSettingsRepository;
            _commonService = commonService;
            _configuration = configuration;
        }
        
        public async Task<List<TIP_CORE.EntitiesDTO.UserRolesDTO>> GetUserRoles(bool onlyActivated)
        {
            return await _unitOfWork.UserRole.GetUserRoles(onlyActivated);
        }

        public async Task<long> AddUserRole(TmUserRole tmUserRole)
        {
            try
            {
                await _unitOfWork.UserRole.AddAsync(tmUserRole);
                long result = await _unitOfWork.SaveAsync();
                return tmUserRole.RoleId;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateUserRole(TmUserRole tmUserRole)
        {
            try
            {
                TmUserRole obj = null;
                obj = await _unitOfWork.UserRole.GetFirstOrDefaultAsync(x => x.RoleId == tmUserRole.RoleId);
                obj.UpdatedBy = tmUserRole.UpdatedBy;
                obj.UpdatedOn = tmUserRole.UpdatedOn;
                obj.Code = tmUserRole.Code;
                obj.RoleName = tmUserRole.RoleName;
                obj.IsActive = tmUserRole.IsActive;

                _unitOfWork.UserRole.Update(obj);
                long result = await _unitOfWork.SaveAsync();
                return obj.RoleId;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeleteUserRole(long RoleId)
        {
            try
            {
                var prepared = await _unitOfWork.UserRole.PrepareDeleteUserRoleAsync(RoleId);
                if (prepared == 0)
                    return 0;

                return await _unitOfWork.SaveAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> saveUserlog(long userId, string status)
        {
            try
            {
                var objLog = new TmUserloginLog
                {
                    UserId = userId,
                    Status = status,
                    Logindatetime = DateTime.Now
                };
                // New login row — Update() marks Modified and fails when ID is unset.
                await _unitOfWork.UserLogs.AddAsync(objLog);
                return await _unitOfWork.SaveAsync();
            }
            catch (Exception ex)
            {
                _commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + $" | saveUserlog | UserId={userId} | Status={status}",
                    "saveUserlog",
                    "UserSettingsService",
                    userId.ToString(),
                    string.Empty);
                throw;
            }
        }
        // 
        public async Task<long> ValidateVendorForPasswordCreation(string emailAddress, string pass, string cpb)
        {
            var result = 0;
            if (cpb == "1")
            {

                var dycrptData = CryptoExtensions.Decrypt(emailAddress);
                var splitData = dycrptData.Split("--");
                result = 3; // Issue with valid data
                if (splitData.Length > 0 && splitData.Length == 2)
                {
                    var id = (long)splitData[0].ToInt64();
                    var lemailAddress = (string)splitData[1];
                    result = 2; // not a valid user
                    var obj = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(x => x.EmailAddress.ToLower() == lemailAddress.ToLower() && x.Cpb == cpb);
                    if (obj != null)
                    {
                        result = 1;
                    }
                }

                return result;
            }
           

            return result;
        }

        public async Task<long> ValidateVendor(string emailAddress, string pass, string cpb)
        {
            var result = 0;
            if (cpb == "1")
            {
     
                var dycrptData = CryptoExtensions.Decrypt(emailAddress);
                var splitData = dycrptData.Split("--");
                result = 3; // Issue with valid data
                if (splitData.Length > 0 && splitData.Length == 2)
                {
                    var id = (long)splitData[0].ToInt64();
                    var lemailAddress = (string)splitData[1];
                    result = 2; // not a valid user
                    var obj = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(x => x.EmailAddress.ToLower() == lemailAddress.ToLower() && x.Cpb == cpb);
                    if (obj != null)
                    {
                        result = 1;
                    }
                }
             
                return result;
            }
            else 
            {
                var obj = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(x => x.EmailAddress == emailAddress && x.Password == pass && x.IsActive == true);
                if (obj != null)
                {
                    result = 1; // successfully Login
                    obj.Attempts = 0;
                    _unitOfWork.ExternalUser.Update(obj);


                    await _unitOfWork.SaveAsync();
                    return result;
                }
                else
                {
                    var emailobj = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(x => x.EmailAddress == emailAddress);
                    if (emailobj != null)
                    {
                        if ((bool)emailobj.IsActive)
                        {
                            emailobj.Attempts = emailobj.Attempts == null ? 1 : emailobj.Attempts + 1;
                            if (emailobj.Attempts >= 6)
                            {
                                // add critical Error`
                                emailobj.IsActive = false;
                                result = 2;// attempt More then 6
                            }
                            else
                            {
                                TmUserloginLog objLog = new TmUserloginLog();
                                objLog.UserId = emailobj.Id;
                                objLog.Status = UserLogStatus.LoginFailed;
                                objLog.Logindatetime = DateTime.Now;
                                await _unitOfWork.UserLogs.AddAsync(objLog);
                                await _unitOfWork.SaveAsync();

                                result = 0; // username or password not correct
                            }
                            _unitOfWork.ExternalUser.Update(emailobj);
                            await _unitOfWork.SaveAsync();
                        }
                        else
                        {
                            result = 3; // Not Active
                        }

                    }

                }
            }
            
            return result;
        }

        public async Task<List<EmployeeDTO>> getUCTEmail(long role)
        {

            var obj = await _unitOfWork.Employee.GetEmployeeByRole(role);

            return obj;
        }
        private async Task<ExternalUserDTO> mapExtrnalUser(ExternalUser exUser)
        {
            ExternalUserDTO externalUserDTO = new ExternalUserDTO();

            if (exUser != null)
            {
                string? sourceParam = null;
                if (exUser.SourceId.HasValue && exUser.SourceId.Value > 0)
                {
                    var vendor = await _commonService.GetMasterDataById(exUser.SourceId.Value);
                    sourceParam = vendor?.param1;
                }

                externalUserDTO = await userSettingsRepository.mapExtrnalUser(exUser, sourceParam);
            }

            return externalUserDTO;
        }
        //
        public async Task<ExternalUserDTO> GetExternalUser(string emailAddress)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(emailAddress))
                    return null;

                var email = emailAddress.Trim();
                var obj = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(
                    x => x.EmailAddress != null && x.EmailAddress.ToUpper() == email.ToUpper());
                if (obj != null)
                {
                    return await mapExtrnalUser(obj);
                }
                return null;
            }
            catch (Exception ex)
            {
                _commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + $" | GetExternalUser | Email={emailAddress}",
                    "GetExternalUser",
                    "UserSettingsService",
                    emailAddress ?? "External",
                    string.Empty);
                throw;
            }
        }

        public async Task<long> ValidateOTP(string emailAddress, int otpcode)
        {
            long result = 0;
            try
            {
                var email = (emailAddress ?? string.Empty).Trim();
                if (string.IsNullOrEmpty(email))
                {
                    return 0;
                }

                var normalizedEmail = email.ToUpperInvariant();
                var obj = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(
                    x => x.EmailAddress != null
                         && x.EmailAddress.ToUpper() == normalizedEmail
                         && x.OtpCode == otpcode);

                if (obj != null)
                {
                    var validateOTPTime = DateTime.Now.Subtract(Convert.ToDateTime(obj.OtpTime)).TotalMinutes >= 5;

                    if (!validateOTPTime)
                    {
                        result = 1;
                    }
                    else
                    {
                        result = 2; // Validate otp time
                    }

                }
                else
                {
                    var obj1 = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(
                        x => x.EmailAddress != null
                             && x.EmailAddress.ToUpper() == normalizedEmail
                             && x.OtpCode > 999999);
                    if (obj1 != null)
                    {
                        result = 3;// when user try to reused OTP
                    }
                    else
                    {
                        result = 0;// Error
                    }

                }
            }
            catch (Exception ex)
            {
                _commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + $" | ValidateOTP | Email={emailAddress} | OtpCode={otpcode}",
                    "ValidateOTP",
                    "UserSettingsService",
                    emailAddress ?? "External",
                    string.Empty);
                throw;
            }

            return result;
        }
        private ExternalUser MappingDTOtoTBLExternalUser(ExternalUserDTO externalUserDTO)
        {
            var createdBy = externalUserDTO.sourceId?.ToString() ?? string.Empty;
            if (createdBy.Length > 10)
                createdBy = createdBy.Substring(0, 10);

            ExternalUser objEx = new ExternalUser();
            objEx.FirstName = externalUserDTO.firstName;
            objEx.LastName = externalUserDTO.lastName;
            objEx.PhoneNumber = externalUserDTO.phoneNumber;
            objEx.CompanyName = externalUserDTO.companyName;
            objEx.Description = externalUserDTO.description;
            objEx.EmailAddress = externalUserDTO.emailaddress;
            objEx.CreatedDate = DateTime.Now;
            objEx.CreatedBy = createdBy;
            objEx.OtpCode = externalUserDTO.otpCODE;
            objEx.SourceId = externalUserDTO.sourceId;
            objEx.Password = externalUserDTO.pname ?? string.Empty;
            objEx.Manufacturername = externalUserDTO.manufacturername;
            objEx.CommercialregNo = externalUserDTO.commercialregNo;
            objEx.CommercialregExpDate = externalUserDTO.commercialregExpDate;
            objEx.Address = externalUserDTO.address;
            objEx.Companywebsite = externalUserDTO.companywebsite;
            objEx.Contactperson = externalUserDTO.contactperson;
            objEx.ContPerPhoneNumber = externalUserDTO.contPerPhoneNumber;
            objEx.Representation = externalUserDTO.representation;
            objEx.Type = externalUserDTO.type;
            objEx.UserCategory = externalUserDTO.UserCategory;
            objEx.Cpb = externalUserDTO.cpb;
            objEx.IsActive = externalUserDTO.isActive ?? false;
            objEx.Attempts = 0;

            return objEx;

        }
        public async Task<long> updateExternal_UserPA(ExternalUserDTO externaluser)
        {
            long result = 0;
            try
            {
                var dycrptData = CryptoExtensions.Decrypt(externaluser.emailaddress);
                var splitData = dycrptData.Split("--");
                if (splitData.Length > 0 && splitData.Length == 2)
                {
                    var id = (long)splitData[0].ToInt64();
                    var emailAddress = (string)splitData[1];
                    //var obj = await _unitOfWork.VendorDetails.GetFirstOrDefaultAsync(x => x.EmailAddress == emailAddress);+
                    var obj = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(x => x.EmailAddress == emailAddress && x.Id == id && x.Cpb == "1");


                    if (obj != null)
                    {
                        var objarch = _unitOfWork.UserPaArchieve.getPAArchieve(externaluser.pname, id);

                        if (objarch)
                        {
                            TmUserPaArchieve objarchieve = new TmUserPaArchieve();
                            objarchieve.PaEnc = externaluser.pname;
                            objarchieve.ExtUserid = obj.Id;
                            objarchieve.CreatedOn = DateTime.Now;
                            await _unitOfWork.UserPaArchieve.AddAsync(objarchieve);

                            obj.Password = externaluser.pname;
                            obj.IsActive = true;
                            obj.Cpb = "0";
                            _unitOfWork.ExternalUser.Update(obj);
                            result = await _unitOfWork.SaveAsync();
                            result = 1;
                        }
                        else { result = 2; }


                    }
                    else
                    {
                        result = 0;
                    }
                }
                else 
                {
                    result = 3; // issue in some data
                }
             
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
        public async Task<long> AddExternal_User(ExternalUserDTO externaluser, EmailSendConfigDTO emailSendConfigDTO)
        {
            long result = 0;
            try
            {
                if (externaluser == null || string.IsNullOrWhiteSpace(externaluser.emailaddress))
                    throw new ArgumentException("Email address is required.");

                var email = externaluser.emailaddress.Trim();
                var emailKey = email.ToLowerInvariant();
                var obj = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(
                    x => x.EmailAddress != null && x.EmailAddress.ToLower() == emailKey);

                if (obj == null)
                {
                    externaluser.cpb = "1"; // for creating password
                    externaluser.emailaddress = email;
                    await _unitOfWork.ExternalUser.AddAsync(MappingDTOtoTBLExternalUser(externaluser));
                    await _unitOfWork.SaveAsync();

                    try
                    {
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        if (string.IsNullOrWhiteSpace(res?.body))
                        {
                            result = 1;
                        }
                        else
                        {
                            var emailResult = await VendorRegistrationKeywordDTO(res, email);
                            result = emailResult ? 1 : 3;
                            if (!emailResult)
                            {
                                _commonService.SaveApplicationErrorLog(
                                    $"AddExternal_User registration email not queued (VendorRegistrationKeywordDTO returned false). | Email={email}",
                                    "AddExternal_User_Email",
                                    "UserSettingsService",
                                    email ?? "External",
                                    string.Empty);
                            }
                        }
                    }
                    catch (Exception emailEx)
                    {
                        _commonService.SaveApplicationErrorLog(
                            ExtensionMethods.GetExceptionMessage(emailEx) + $" | AddExternal_User registration email | Email={email}",
                            "AddExternal_User_Email",
                            "UserSettingsService",
                            email ?? "External",
                            string.Empty);
                        result = 3;// Email not send
                    }
                }
                else if (obj != null && externaluser.id > 0)
                {
                    var externalUserDTO = MappingDTOtoTBLExternalUser(externaluser);
                    obj.FirstName = externalUserDTO.FirstName;
                    obj.LastName = externalUserDTO.LastName;
                    obj.PhoneNumber = externalUserDTO.PhoneNumber;
                    obj.CompanyName = externalUserDTO.CompanyName;
                    obj.Description = externalUserDTO.Description;
                    obj.EmailAddress = externalUserDTO.EmailAddress;
                    obj.UpdatedOn = DateTime.Now;
                    obj.UpdatedBy = externalUserDTO.SourceId?.ToString() ?? string.Empty;
                    obj.OtpCode = externalUserDTO.OtpCode;
                    obj.SourceId = externalUserDTO.SourceId;
                    obj.Manufacturername = externalUserDTO.Manufacturername;
                    obj.CommercialregNo = externalUserDTO.CommercialregNo;
                    obj.CommercialregExpDate = externalUserDTO.CommercialregExpDate;
                    obj.Address = externalUserDTO.Address;
                    obj.Companywebsite = externalUserDTO.Companywebsite;
                    obj.Contactperson = externalUserDTO.Contactperson;
                    obj.ContPerPhoneNumber = externalUserDTO.ContPerPhoneNumber;
                    obj.Representation = externalUserDTO.Representation;
                    obj.Type = externalUserDTO.Type;
                    obj.UserCategory = externalUserDTO.UserCategory;
                    externaluser.cpb = "0"; // for creating password
                    _unitOfWork.ExternalUser.Update(obj);
                    result = await _unitOfWork.SaveAsync();

                    //EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                    //var emailResult = await VendorRegistrationKeywordDTO(res, externaluser.emailaddress);
                }
                else
                {
                    result = 2;// already exist
                }
            }
            catch (DbUpdateException ex) when (ex.InnerException?.Message?.Contains("ORA-00001", StringComparison.OrdinalIgnoreCase) == true)
            {
                result = 2;// already exist (duplicate key)
            }
            catch (Exception ex)
            {
                _commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + $" | AddExternal_User | Email={externaluser?.emailaddress}",
                    "AddExternal_User",
                    "UserSettingsService",
                    externaluser?.emailaddress ?? "External",
                    string.Empty);
                throw;
            }

            return result;
        }

        public async Task<long> SendForgetPa(EmailSendConfigDTO emailSendConfigDTO, string emailaddress)
        {
            long result = 0;
            try
            {

                //var obj = await _unitOfWork.VendorDetails.GetFirstOrDefaultAsync(x => x.EmailAddress == emailAddress);+
                ExternalUser obj;
                try
                {
                    var email = (emailaddress ?? string.Empty).Trim();
                    obj = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(
                        x => x.EmailAddress != null && x.EmailAddress.ToUpper() == email.ToUpper());
                }
                catch (Exception lookupEx)
                {
                    _commonService.SaveApplicationErrorLog(
                        ExtensionMethods.GetExceptionMessage(lookupEx) + $" | SendForgetPa GetFirstOrDefaultAsync | Email={emailaddress}",
                        "SendForgetPa_Lookup",
                        "UserSettingsService",
                        emailaddress ?? "External",
                        string.Empty);
                    throw;
                }

                if (obj != null)
                {
                    try
                    {
                        obj.Attempts = 0;
                        //obj.IsActive = true;
                        obj.Cpb = "1";
                        result = await _unitOfWork.SaveAsync();
                    }
                    catch (Exception saveEx)
                    {
                        _commonService.SaveApplicationErrorLog(
                            ExtensionMethods.GetExceptionMessage(saveEx) + $" | SendForgetPa SaveAsync | Email={emailaddress}",
                            "SendForgetPa_Save",
                            "UserSettingsService",
                            emailaddress ?? "External",
                            string.Empty);
                        throw;
                    }
                    EmailSendConfigDTO res;
                    try
                    {
                        res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                    }
                    catch (Exception templateEx)
                    {
                        _commonService.SaveApplicationErrorLog(
                            ExtensionMethods.GetExceptionMessage(templateEx) + $" | SendForgetPa GenericEmailTemplateBaseInfo | Email={emailaddress}",
                            "SendForgetPa_GenericEmailTemplateBaseInfo",
                            "UserSettingsService",
                            emailaddress ?? "External",
                            string.Empty);
                        throw;
                    }
                    if (string.IsNullOrWhiteSpace(res.subject) || string.IsNullOrWhiteSpace(res.body))
                    {
                        _commonService.SaveApplicationErrorLog(
                            $"SendForgetPa email template missing or empty after GenericEmailTemplateBaseInfo. | ModuleId={emailSendConfigDTO.moduleId} | TemplateId={emailSendConfigDTO.templateId} | Email={emailaddress}",
                            "SendForgetPa_EmptyTemplate",
                            "UserSettingsService",
                            emailaddress ?? "External",
                            string.Empty);
                        return 3;
                    }
                    res.RecipientsNames = new List<string>();
                    res.RecipientsNames.Add(string.Join(' ', new[] { obj.FirstName, obj.LastName }.Where(s => !string.IsNullOrWhiteSpace(s))));

                    var emailResult = await VendorForgetPassDTO(res, emailaddress);
                    if (emailResult)
                    {
                        result = 1;// 
                        _commonService.SaveApplicationErrorLog(
                            $"SendForgetPa forgot-password email queued successfully in EMAIL_REPO. | TemplateId={emailSendConfigDTO.templateId} | ModuleId={emailSendConfigDTO.moduleId} | Email={emailaddress}",
                            "SendForgetPa_Email_Success",
                            "UserSettingsService",
                            emailaddress ?? "External",
                            string.Empty);
                    }
                    else
                    {
                        result = 3;// Email not send
                        _commonService.SaveApplicationErrorLog(
                            $"SendForgetPa email not queued (VendorForgetPassDTO returned false). | Email={emailaddress}",
                            "SendForgetPa_Email",
                            "UserSettingsService",
                            emailaddress ?? "External",
                            string.Empty);
                    }
                }
                else
                {
                    _commonService.SaveApplicationErrorLog(
                        $"SendForgetPa: external user not found (return 4). | Email={emailaddress}",
                        "SendForgetPa_UserNotFound",
                        "UserSettingsService",
                        emailaddress ?? "External",
                        string.Empty);
                    return 4;
                }

            }
            catch (Exception ex)
            {
                _commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + $" | SendForgetPa | Email={emailaddress}",
                    "SendForgetPa",
                    "UserSettingsService",
                    emailaddress ?? "External",
                    string.Empty);
                throw;
            }

            return result;
        }





        public async Task<long> UpdateOTP(string emailAddress, int otpcode,int bit)// bit = 0 for Login other for Reset
        {
            long result = 0;
            try
            {

                var email = (emailAddress ?? string.Empty).Trim();
                var obj = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(
                    x => x.EmailAddress != null && x.EmailAddress.ToUpper() == email.ToUpper());
                if (obj != null)
                {
                    obj.LastLogin = DateTime.Now;
                    obj.OtpCode = otpcode;
                    obj.OtpTime = DateTime.Now;
                    if (bit != 0)
                    {
                        obj.IsActive = false;
                    }

                    _unitOfWork.ExternalUser.Update(obj);
                    result = await _unitOfWork.SaveAsync();
                }
                else
                {
                    result = 0;
                    _commonService.SaveApplicationErrorLog(
                        $"UpdateOTP: external user not found for email. | Email={emailAddress} | OtpCode={otpcode} | Bit={bit}",
                        "UpdateOTP_UserNotFound",
                        "UserSettingsService",
                        emailAddress ?? "External",
                        string.Empty);
                }
            }
            catch (Exception ex)
            {
                _commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + $" | OTP UpdateOTP | Email={emailAddress} | OtpCode={otpcode} | Bit={bit}",
                    "UpdateOTP",
                    "UserSettingsService",
                    emailAddress ?? "External",
                    string.Empty);
                throw;
            }

            return result;
        }




        public async Task<UserSettingsDTO> GetUserLogin()
        {
            return await userSettingsRepository.GetUserRoledata();
        }

        public async Task<UserSettingsDTO> GetUserRoledata()
        {
            return await userSettingsRepository.GetUserRoledata();
        }

        public async Task<List<AllPDOUsersDTO>> GetUsersWithfilter(string Filter)
        {
            return await userSettingsRepository.GetUsersWithfilter(Filter);
        }
        public async Task<List<AllPDOUsersDTO>> GetUserWithoutLoggedInUser(string Filter, string LoggedInUser)
        {
            return await userSettingsRepository.GetUserWithoutLoggedInUser(Filter, LoggedInUser);
        }
        public async Task<List<AllPDOUsersDTO>> GetUserWithoutUCTANDLoggedInUser(string Filter, string LoggedInUser)
        {
            return await userSettingsRepository.GetUserWithoutUCTANDLoggedInUser(Filter, LoggedInUser);
        }

        public async Task<string> SaveUserToRoleMapping(UserViewData ViewData)
        {
            return await userSettingsRepository.SaveUserToRoleMapping(ViewData);
        }

        public async Task<string> UpdateActiveRole(long Role_ID)
        {
            return await userSettingsRepository.UpdateActiveRole(Role_ID);
        }//UpdateActiveRole

        public async Task<string> UpdateActiveRoleByCode(string Role_Code)
        {
            var Role_ID = _unitOfWork.UserRole.GetFirstOrDefaultAsync(x => x.Param == Role_Code).Result.RoleId;
             await userSettingsRepository.UpdateActiveRole(Role_ID);
            return Role_ID.ToString();
        }
        public async Task<List<UserViewDataD>> loadUserRoleMapping()
        {
            return await userSettingsRepository.loadUserRoleMapping();
        }


        public async Task<List<AllPDOUsersDTO>> loadApplicationUser()
        {
            return await userSettingsRepository.loadApplicationUser();
        }
        public async Task<List<UserApplicationViewDataD>> loadUserAssetFocalPoint()
        {
            return await userSettingsRepository.loadUserAssetFocalPoint();
        }
        public async Task<List<UserApplicationViewDataD>> loadUserClusterFocalPoint()
        {
            return await userSettingsRepository.loadUserClusterFocalPoint();
        }
        public async Task<string> DeleteUserToRoleMapping(string UserId)
        {
            return await userSettingsRepository.DeleteUserToRoleMapping(UserId);
        }

        public async Task<RoleToMenuMappingDTO> LoadRoleMenuMapping(long ROLE_ID)
        {
            return await userSettingsRepository.LoadRoleMenuMapping(ROLE_ID);
        }

        public async Task<string> saveRoleMenuMapping(RoleToMenuMappingDTO ViewData)
        {
            return await userSettingsRepository.saveRoleMenuMapping(ViewData);
        }

        public async Task<bool> VendorLoginKeywordDTO(string Module, string TemplateCode, string otp, string emailAddress)
        {
            try
            {
                TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
                if (EmailModule != null)
                {
                    EmailTemplateConfiguration Template;
                    try
                    {
                        Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                    }
                    catch (Exception templateLoadEx)
                    {
                        _commonService.SaveApplicationErrorLog(
                            ExtensionMethods.GetExceptionMessage(templateLoadEx) + $" | VendorLoginKeywordDTO GetEmailTemplatebyTemplateCode | Module={Module} | TemplateCode={TemplateCode} | Email={emailAddress}",
                            "VendorLoginKeywordDTO_GetEmailTemplate",
                            "UserSettingsService",
                            emailAddress ?? "External",
                            string.Empty);
                        throw;
                    }
                    if (Template != null)
                    {
                        EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                        emailSendConfigDTO.moduleId = EmailModule.id;
                        emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                        try
                        {
                            emailSendConfigDTO = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        }
                        catch (Exception templateEx)
                        {
                            _commonService.SaveApplicationErrorLog(
                                ExtensionMethods.GetExceptionMessage(templateEx) + $" | VendorLoginKeywordDTO GenericEmailTemplateBaseInfo | Module={Module} | TemplateCode={TemplateCode} | Email={emailAddress}",
                                "VendorLoginKeywordDTO_GenericEmailTemplateBaseInfo",
                                "UserSettingsService",
                                emailAddress ?? "External",
                                string.Empty);
                            throw;
                        }
                        emailSendConfigDTO.toRecipients = new List<string>();
                        emailSendConfigDTO.toRecipients.Add(emailAddress);
                        if (emailSendConfigDTO != null)
                        {
                            if (string.IsNullOrWhiteSpace(emailSendConfigDTO.body) || string.IsNullOrWhiteSpace(emailSendConfigDTO.subject))
                            {
                                _commonService.SaveApplicationErrorLog(
                                    $"VendorLoginKeywordDTO OTP email template has no subject/body after GenericEmailTemplateBaseInfo. | Module={Module} | TemplateCode={TemplateCode} | TemplateId={emailSendConfigDTO.templateId} | Email={emailAddress}",
                                    "VendorLoginKeywordDTO_EmptyTemplate",
                                    "UserSettingsService",
                                    emailAddress ?? "External",
                                    string.Empty);
                                return false;
                            }

                            try
                            {
                                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$OTP", otp.ToString());
                            }
                            catch (Exception replaceEx)
                            {
                                _commonService.SaveApplicationErrorLog(
                                    ExtensionMethods.GetExceptionMessage(replaceEx) + $" | VendorLoginKeywordDTO Replace OTP token | Module={Module} | TemplateCode={TemplateCode} | Email={emailAddress}",
                                    "VendorLoginKeywordDTO_ReplaceOtp",
                                    "UserSettingsService",
                                    emailAddress ?? "External",
                                    string.Empty);
                                throw;
                            }

                            string host = _configuration["ExternalApplicationPath"];

                            try
                            {
                                if (string.Equals(emailSendConfigDTO.templateCode, "EX001", StringComparison.OrdinalIgnoreCase))
                                {
                                    string link = host + "";
                                    if (emailSendConfigDTO.body.Contains("$$Link"))
                                    {
                                        emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                                    }
                                    else
                                    {
                                        emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to login screen : " + "<a href='" + link + "'>Link</a>";
                                    }
                                }
                            }
                            catch (Exception linkEx)
                            {
                                _commonService.SaveApplicationErrorLog(
                                    ExtensionMethods.GetExceptionMessage(linkEx) + $" | VendorLoginKeywordDTO login link | Module={Module} | TemplateCode={TemplateCode} | Email={emailAddress}",
                                    "VendorLoginKeywordDTO_LoginLink",
                                    "UserSettingsService",
                                    emailAddress ?? "External",
                                    string.Empty);
                                throw;
                            }
                            try
                            {
                                var queued = await _commonService.SendEmail(emailSendConfigDTO);
                                if (queued)
                                {
                                    _commonService.SaveApplicationErrorLog(
                                        $"VendorLoginKeywordDTO OTP email queued successfully in EMAIL_REPO. | Module={Module} | TemplateCode={TemplateCode} | TemplateId={emailSendConfigDTO.templateId} | Email={emailAddress}",
                                        "VendorLoginKeywordDTO_SendEmail_Success",
                                        "UserSettingsService",
                                        emailAddress ?? "External",
                                        string.Empty);
                                }
                                else
                                {
                                    _commonService.SaveApplicationErrorLog(
                                        $"VendorLoginKeywordDTO SendEmail returned false (OTP login email not queued). | Module={Module} | TemplateCode={TemplateCode} | Email={emailAddress}",
                                        "VendorLoginKeywordDTO_SendEmail",
                                        "UserSettingsService",
                                        emailAddress ?? "External",
                                        string.Empty);
                                }
                                return queued;
                            }
                            catch (Exception sendEx)
                            {
                                _commonService.SaveApplicationErrorLog(
                                    ExtensionMethods.GetExceptionMessage(sendEx) + $" | VendorLoginKeywordDTO SendEmail | Module={Module} | TemplateCode={TemplateCode} | Email={emailAddress}",
                                    "VendorLoginKeywordDTO_SendEmail",
                                    "UserSettingsService",
                                    emailAddress ?? "External",
                                    string.Empty);
                                throw;
                            }
                        }
                    }
                }
                _commonService.SaveApplicationErrorLog(
                    $"VendorLoginKeywordDTO returned false (template/module missing or inactive). | Module={Module} | TemplateCode={TemplateCode} | Email={emailAddress}",
                    "VendorLoginKeywordDTO",
                    "UserSettingsService",
                    emailAddress ?? "External",
                    string.Empty);
                return false;
            }
            catch (Exception ex)
            {
                _commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + $" | OTP VendorLoginKeywordDTO | Module={Module} | TemplateCode={TemplateCode} | Email={emailAddress}",
                    "VendorLoginKeywordDTO",
                    "UserSettingsService",
                    emailAddress ?? "External",
                    string.Empty);
                throw;
            }
        }
        bool IsValidEmail(string email)
        {
            var trimmedEmail = email.Trim();

            if (trimmedEmail.EndsWith("."))
            {
                return false;
            }
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == trimmedEmail;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> AutoReplyContactUs(ExternalContactUs obj, string Module, string TemplateCode)
        {

            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                    if (TemplateCode.Equals("EX003"))
                    {
                        if (IsValidEmail(obj.emailAddress))
                        {
                            emailSendConfigDTO.toRecipients = new List<string>();
                            emailSendConfigDTO.toRecipients.Add(obj.emailAddress);

                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            {
                                res.body = res.body.Replace("$$FirstName", obj.firstName == null ? "" : obj.firstName.ToString());
                                res.body = res.body.Replace("$$LastName", obj.lastName == null ? "" : obj.lastName.ToString());
                                return await _commonService.SendEmail(res);
                            }
                        }

                    }
                    else if (TemplateCode.Equals("EX004"))
                    {
                        TypeCodeMaster? ContactUs = await _commonService.GetMasterDataByParentAndParam1(TypeCodes.Configuration, "CTE");

                        emailSendConfigDTO.toRecipients = new List<string>();
                        if (ContactUs != null && !string.IsNullOrEmpty(ContactUs.Param2))
                        {
                            string[] ContactUsMus = ContactUs.Param2.Split(',').Select(sValue => sValue.Trim()).ToArray();
                            List<string> ContactUsMuNames = new List<string>();
                            foreach (string MuNumber in ContactUsMus)
                            {
                                TmEmployee MuObj = await _commonService.GetMuDetails(MuNumber);
                                emailSendConfigDTO.toRecipients.Add(MuObj.EmailAddress);
                                ContactUsMuNames.Add(MuObj.EmployeeName);
                            }

                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body) && ContactUsMuNames.Count > 0)
                            {
                                res.body = res.body.Replace("$$ContactUsCustodianNames", string.Join(",", ContactUsMuNames));
                                res.body = res.body.Replace("$$FirstName", obj.firstName == null ? "" : obj.firstName.ToString());
                                res.body = res.body.Replace("$$LastName", obj.lastName == null ? "" : obj.lastName.ToString());
                                res.body = res.body.Replace("$$ContactPersonEmail", obj.emailAddress == null ? "" : obj.emailAddress.ToString());
                                res.body = res.body.Replace("$$Message", obj.message == null ? "" : obj.message.ToString());
                                return await _commonService.SendEmail(res);
                            }
                        }
                    }
                }
            }
            return true;
        }


        public async Task<ChallengeRegistrationDetailDTO> GetAssetFocalPointDTO()
        {
            try
            {
                return await _unitOfWork.ChallengeRegistration.GetChallengeRegistrationDetailDTO();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<ChallengeRegistrationDetailDTO> GetClusterFocalPoint()
        {
            try
            {
                return await _unitOfWork.ChallengeRegistration.GetChallengeRegistrationDetailDTO();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public async Task<bool> VendorForgetPassDTO(EmailSendConfigDTO emailSendConfigDTO, string emailaddress)
        {
            try
            {
                string host = _configuration["ExternalApplicationPath"];
                ExternalUserDTO obj = null;
                //https://localhost:7042/Login/CreatePassword?ExternalPass=4739ee3bd29e4f415da8ba9298a087e0fdc9c61378420ba8fbbab298bd74c4df&emailAddress=lachurk09@gmail.com
                try
                {
                    obj = await _unitOfWork.ExternalUser.MapVendorRegistrationEmail(emailaddress);
                }
                catch (Exception mapEx)
                {
                    _commonService.SaveApplicationErrorLog(
                        ExtensionMethods.GetExceptionMessage(mapEx) + $" | VendorForgetPassDTO MapVendorRegistrationEmail | Email={emailaddress}",
                        "VendorForgetPassDTO_MapVendorRegistrationEmail",
                        "UserSettingsService",
                        emailaddress ?? "External",
                        string.Empty);
                    throw;
                }
                if (obj == null)
                {
                    _commonService.SaveApplicationErrorLog(
                        $"VendorForgetPassDTO: external user not found for email. | Email={emailaddress}",
                        "VendorForgetPassDTO_UserNotFound",
                        "UserSettingsService",
                        emailaddress ?? "External",
                        string.Empty);
                    return false;
                }

                emailSendConfigDTO.body ??= string.Empty;
                emailSendConfigDTO.templateCode ??= string.Empty;

                obj.createpaLink = host + "Login/CreatePassword?refData=" + CryptoExtensions.Encrypt(obj.id + "--" + obj.emailaddress);
                //obj.createpaLink = host + "Login/CreatePassword?ExternalPass=" + obj.pname + "&emailAddress=" + obj.emailaddress;

                try
                {
                    if (emailSendConfigDTO.RecipientsNames != null && emailSendConfigDTO.RecipientsNames.Count > 0)
                    {
                        emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ToUserNames", string.Join(',', emailSendConfigDTO.RecipientsNames));
                    }
                    else
                    {
                        emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ToUserNames", "Recipient");
                    }

                    if (emailSendConfigDTO.templateCode.Equals("TMH005", StringComparison.OrdinalIgnoreCase))
                    {
                        if (emailSendConfigDTO.body.Contains("$$Link"))
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + obj.createpaLink.ToString() + "'>Link</a>");
                        }
                        else
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to retrive your password : " + "<a href='" + obj.createpaLink.ToString() + "'>Link</a>";
                        }
                    }
                }
                catch (Exception templateBodyEx)
                {
                    _commonService.SaveApplicationErrorLog(
                        ExtensionMethods.GetExceptionMessage(templateBodyEx) + $" | VendorForgetPassDTO template body | Email={emailaddress}",
                        "VendorForgetPassDTO_TemplateBody",
                        "UserSettingsService",
                        emailaddress ?? "External",
                        string.Empty);
                    throw;
                }
                try
                {
                    var queued = await _commonService.SendEmail(emailSendConfigDTO);
                    if (queued)
                    {
                        _commonService.SaveApplicationErrorLog(
                            $"VendorForgetPassDTO forgot-password email queued successfully in EMAIL_REPO. | TemplateCode={emailSendConfigDTO.templateCode} | TemplateId={emailSendConfigDTO.templateId} | Email={emailaddress}",
                            "VendorForgetPassDTO_SendEmail_Success",
                            "UserSettingsService",
                            emailaddress ?? "External",
                            string.Empty);
                    }
                    else
                    {
                        _commonService.SaveApplicationErrorLog(
                            $"VendorForgetPassDTO SendEmail returned false (forgot-password email not queued). | Email={emailaddress}",
                            "VendorForgetPassDTO_SendEmail",
                            "UserSettingsService",
                            emailaddress ?? "External",
                            string.Empty);
                    }
                    return queued;
                }
                catch (Exception sendEx)
                {
                    _commonService.SaveApplicationErrorLog(
                        ExtensionMethods.GetExceptionMessage(sendEx) + $" | VendorForgetPassDTO SendEmail | Email={emailaddress}",
                        "VendorForgetPassDTO_SendEmail",
                        "UserSettingsService",
                        emailaddress ?? "External",
                        string.Empty);
                    throw;
                }
            }
            catch (Exception ex)
            {
                _commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + $" | VendorForgetPassDTO | Email={emailaddress}",
                    "VendorForgetPassDTO",
                    "UserSettingsService",
                    emailaddress ?? "External",
                    string.Empty);
                throw;
            }
        }


        public async Task<bool> VendorRegistrationKeywordDTO(EmailSendConfigDTO emailSendConfigDTO, string emailaddress)
        {
            try
            {
                if (emailSendConfigDTO == null || string.IsNullOrWhiteSpace(emailaddress))
                {
                    _commonService.SaveApplicationErrorLog(
                        "VendorRegistrationKeywordDTO aborted: missing template config or email address.",
                        "VendorRegistrationKeywordDTO_InvalidInput",
                        "UserSettingsService",
                        emailaddress ?? "External",
                        string.Empty);
                    return false;
                }

                string host = _configuration["ExternalApplicationPath"] ?? string.Empty;
                ExternalUserDTO obj;
                try
                {
                    obj = await _unitOfWork.ExternalUser.MapVendorRegistrationEmail(emailaddress);
                }
                catch (Exception mapEx)
                {
                    _commonService.SaveApplicationErrorLog(
                        ExtensionMethods.GetExceptionMessage(mapEx) + $" | VendorRegistrationKeywordDTO MapVendorRegistrationEmail | Email={emailaddress}",
                        "VendorRegistrationKeywordDTO_MapVendor",
                        "UserSettingsService",
                        emailaddress ?? "External",
                        string.Empty);
                    throw;
                }

                if (obj == null)
                {
                    _commonService.SaveApplicationErrorLog(
                        $"VendorRegistrationKeywordDTO: external user not found for email. | Email={emailaddress}",
                        "VendorRegistrationKeywordDTO_UserNotFound",
                        "UserSettingsService",
                        emailaddress ?? "External",
                        string.Empty);
                    return false;
                }

                emailSendConfigDTO.body ??= string.Empty;
                emailSendConfigDTO.templateCode ??= string.Empty;

                obj.createpaLink = host + "Login/CreatePassword?refData=" + CryptoExtensions.Encrypt(obj.id + "--" + obj.emailaddress);
                try
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$VendorCategory", obj.UserCategory ?? string.Empty);
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Type", obj.type ?? string.Empty);
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Representation", obj.representation ?? string.Empty);
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ManufacturerName", obj.manufacturername ?? string.Empty);
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$CountryOrigin", obj.countryorign ?? string.Empty);
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$TelNumber", obj.phoneNumber ?? string.Empty);
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Address", obj.address ?? string.Empty);
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$CompanyName", obj.companyName ?? string.Empty);
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$CompanyWebsite", obj.companywebsite ?? string.Empty);
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ContactPerson", obj.contactperson ?? string.Empty);
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ContactPersonNumber", obj.contPerPhoneNumber ?? string.Empty);
                    emailSendConfigDTO.attachment = "\\\\musnas06\\web_applications\\TIP\\Production\\TIP User Guide.pdf";
                    emailSendConfigDTO.attachmentname = "User_Guide." + Path.GetExtension(emailSendConfigDTO.attachment);
                    if (emailSendConfigDTO.templateCode.Equals("EX002", StringComparison.OrdinalIgnoreCase))
                    {
                        if (emailSendConfigDTO.body.Contains("$$Link"))
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + obj.createpaLink + "'>Link</a>");
                        }
                        else
                        {
                            emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to complete the registration : " + "<a href='" + obj.createpaLink + "'>Link</a>";
                        }
                    }
                }
                catch (Exception replaceEx)
                {
                    _commonService.SaveApplicationErrorLog(
                        ExtensionMethods.GetExceptionMessage(replaceEx) + $" | VendorRegistrationKeywordDTO template body | Email={emailaddress}",
                        "VendorRegistrationKeywordDTO_TemplateBody",
                        "UserSettingsService",
                        emailaddress ?? "External",
                        string.Empty);
                    throw;
                }

                try
                {
                    var queued = await _commonService.SendEmail(emailSendConfigDTO);
                    if (!queued)
                    {
                        _commonService.SaveApplicationErrorLog(
                            $"VendorRegistrationKeywordDTO SendEmail returned false (registration email not queued). | Email={emailaddress}",
                            "VendorRegistrationKeywordDTO_SendEmail",
                            "UserSettingsService",
                            emailaddress ?? "External",
                            string.Empty);
                    }
                    return queued;
                }
                catch (Exception sendEx)
                {
                    _commonService.SaveApplicationErrorLog(
                        ExtensionMethods.GetExceptionMessage(sendEx) + $" | VendorRegistrationKeywordDTO SendEmail | Email={emailaddress}",
                        "VendorRegistrationKeywordDTO_SendEmail",
                        "UserSettingsService",
                        emailaddress ?? "External",
                        string.Empty);
                    throw;
                }
            }
            catch (Exception ex)
            {
                _commonService.SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + $" | VendorRegistrationKeywordDTO | Email={emailaddress}",
                    "VendorRegistrationKeywordDTO",
                    "UserSettingsService",
                    emailaddress ?? "External",
                    string.Empty);
                throw;
            }
        }




        public async Task<long> UpdateUserLogin(ExternalUserDTO externaluser)
        {
            long result = 0;
            try
            {
                var objexisting = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(x => x.Id != externaluser.id && (x.PhoneNumber == externaluser.phoneNumber || x.EmailAddress == externaluser.emailaddress)); // email already used for another user                 
                if (objexisting == null)
                {
                    var obj = await _unitOfWork.ExternalUser.GetFirstOrDefaultAsync(x => x.Id == externaluser.id);
                    if (obj != null)
                    {
                        obj.EmailAddress = externaluser.emailaddress;
                        obj.PhoneNumber = externaluser.phoneNumber;
                        obj.UpdatedOn = DateTime.Now;
                        _unitOfWork.ExternalUser.Update(obj);
                        result = await _unitOfWork.SaveAsync();
                    }
                    else
                    {
                        result = 2;// not exist
                    }
                }
                else
                {
                    result = 3;// already exist
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
    }
}
