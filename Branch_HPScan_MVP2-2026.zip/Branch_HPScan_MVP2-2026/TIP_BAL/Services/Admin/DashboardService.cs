﻿using TIP_API.DTO.Admin;
using TIP_BAL.Interface.Admin;
using TIP_CORE;
using TIP_CORE.Admin;
using TIP_DAL.Interface;
using TIP_DAL.Interface.Admin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Repository;

namespace TIP_BAL.Services.Admin
{
    public class DashboardService:IDashboardService
    {
        private readonly IDashboardRepository DashboardRepository;
      
        public DashboardService(IDashboardRepository _commonRepository)
        {
            DashboardRepository = _commonRepository;
            
        }
        public async Task<BaseDTO> getBaseData(int RoleId,string userName)
        {
            return await DashboardRepository.getBaseData(RoleId, userName);//getBaseData_LoginRoles
        }

        public async Task<BaseDTO> getBaseData_LoginRoles(string userName)
        {
            return await DashboardRepository.getBaseData_LoginRoles(userName);//
        }

        
    }
}
