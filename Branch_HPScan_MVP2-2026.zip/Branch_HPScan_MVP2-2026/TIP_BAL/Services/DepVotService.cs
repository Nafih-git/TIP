﻿using TIP_BusinessLogic.Interface;
using TIP_Common;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using Microsoft.EntityFrameworkCore;
using TIP_Common.Enum;
using Microsoft.Reporting.NETCore;
using static TIP_Common.Enum.Enum;
using System.Reflection;
using System.Text;
using TIP_Core;
using Microsoft.AspNetCore.Http;
using System.Net.Sockets;
using System.Net;
using TIP_Common.Helpers;
using System.Numerics;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace TIP_BusinessLogic.Services
{
	public class DepVotService : IDepVotService
	{
		private readonly IUnitOfWork _unitOfWork;
		private readonly ICommonService _commonService;
		private readonly IConfiguration _configuration;

		public DepVotService(IUnitOfWork unitOfWork, ICommonService commonService, IConfiguration configuration)
		{
			this._unitOfWork = unitOfWork;
			_commonService = commonService;
			_configuration = configuration;
		}

		public async Task<long> AssignCH(DepInitiation DTO)
		{
			try
			{
				if (DTO.Id > 0)
				{
					DepInitiation obj = null;
					obj = await _unitOfWork.DepInitiation.GetFirstOrDefaultAsync(x => x.Id == DTO.Id);
					obj.Chfp = DTO.Chfp;
					obj.UpdatedBy = DTO.UpdatedBy;
					obj.UpdatedByRef = DTO.UpdatedByRef;
					obj.UpdatedOn = DTO.UpdatedOn;

					_unitOfWork.DepInitiation.Update(obj);
					long result = await _unitOfWork.SaveAsync();
					return obj.Id;
				}
				else
				{
					DTO.Id = 0;
					await _unitOfWork.DepInitiation.AddAsync(DTO);
					await _unitOfWork.SaveAsync();
					return DTO.Id;
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public async Task<string> DeploymentPlan(DepVot depVot, string status, long PirId)
		{
			TypeCodeMaster deploymentStatus = null;
			deploymentStatus = await _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Type.ToUpper() == TypeCodes.DeploymentStatus.ToUpper() && x.Param1.ToUpper() == status.ToUpper());
			depVot.StatusId = deploymentStatus.Id;
			TypeCodeMaster DeleteStatus = await _commonService.GetMasterDataByParentAndParam1(TypeCodes.DeploymentStatus, DeploymentStatus.Deleted);

			if (depVot.Id > 0)
			{
				DepVot obj = null;
				obj = await _unitOfWork.DepVot.GetFirstOrDefaultAsync(x => x.Id == depVot.Id && x.StatusId != DeleteStatus.Id);
				if (obj == null) return "";
				else
				{
					obj.QYear = depVot.QYear;
					obj.DeployedTo = depVot.DeployedTo;
					obj.ScopeCountQtr = depVot.ScopeCountQtr;
					obj.IncrmntlOilGain = depVot.IncrmntlOilGain;
					obj.DefermentAvoidance = depVot.DefermentAvoidance;
					obj.CostSavingUnitQtr = depVot.CostSavingUnitQtr;
					obj.PowerSaving = depVot.PowerSaving;
					obj.Co2Reduction = depVot.Co2Reduction;
					obj.TechnologyCost = depVot.TechnologyCost;
					obj.OtherCostQtr = depVot.OtherCostQtr;
					obj.TotalVotQtr = depVot.TotalVotQtr;
					obj.FinalComments = depVot.FinalComments;
					obj.UpdatedBy = depVot.UpdatedBy;
					obj.UpdatedByRef = depVot.UpdatedByRef;
					obj.UpdatedOn = depVot.UpdatedOn;
					obj.StatusId = depVot.StatusId;
					obj.SubmittedOn = depVot.SubmittedOn;

					_unitOfWork.DepVot.Update(obj);
					long result = await _unitOfWork.SaveAsync();
					return CryptoExtensions.Encrypt("PIR-" + PirId) + " -" + obj.Id;
				}
			}
			else
			{

				DepVot obj = null;
				obj = await _unitOfWork.DepVot.GetFirstOrDefaultAsync(x => x.QYear == depVot.QYear && x.DepId == depVot.DepId && x.StatusId != DeleteStatus.Id);
				if (obj != null) return "";
				await _unitOfWork.DepVot.AddAsync(depVot);
				await _unitOfWork.SaveAsync();
				return CryptoExtensions.Encrypt("PIR-" + PirId) + " -" + depVot.Id;
			}
		}


		public async Task<List<DepVotDTO>> GetDeployment(long roleId, string loggedMu, long pirId)
		{
			return await _unitOfWork.DepVot.GetDeployment(roleId, loggedMu, pirId);
		}
		public async Task<DepVotDTO> GetDeploymentById(long Id)
		{
			return await _unitOfWork.DepVot.GetDeploymentById(Id);
		}

		public async Task<DepVotDTO> GetDeploymentByPirId(long Id)
		{
			return await _unitOfWork.DepVot.GetDeploymentByPirId(Id);
		}

		public async Task<long> DeleteDeploymentPlan(long Id)
		{
			try
			{
				DepVot obj = null;
				TypeCodeMaster DeleteStatus = await _commonService.GetMasterDataByParentAndParam1(TypeCodes.DeploymentStatus, DeploymentStatus.Deleted);
				obj = await _unitOfWork.DepVot.GetFirstOrDefaultAsync(x => x.Id == Id);
				if (obj != null)
				{
					obj.StatusId = DeleteStatus.Id;

					_unitOfWork.DepVot.Update(obj);
					long result = await _unitOfWork.SaveAsync();
					return result;
				}
				return 0;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}


		public async Task<long> SendDeploymentEmail(long Id, string Module, string TemplateCode, EmployeeDTO loggedInUser, long? votId = 0, string? currentMU = "", string? previousMU = "")
		{
			TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
			if (EmailModule != null)
			{
				EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
				if (Template != null)
				{
					DepVotEmailDTO DepObj = await _unitOfWork.DepVot.DeploymentEmailData(Id, votId, currentMU, previousMU);
					EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
					emailSendConfigDTO.ccRecipients = new List<string>();
					emailSendConfigDTO.moduleId = EmailModule.id;
					emailSendConfigDTO.templateId = Template.UniqueTemplateId;
					
						var senderEmail = await _commonService.GetEmailBymuNO(loggedInUser.COMPANY_NUMBER);
						emailSendConfigDTO.ccRecipients.Add(senderEmail);
					

					if (TemplateCode.Equals("DEV001"))
					{
						emailSendConfigDTO.toRecipients = new List<string>();
						var fpEmail = await _commonService.GetEmailBymuNO(previousMU);
						emailSendConfigDTO.toRecipients.Add(fpEmail);

						EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
						if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
							await MapDepolymentForEmail(res, DepObj, TemplateCode, employee: loggedInUser);
					}
					else if (TemplateCode.Equals("DEV002"))
					{
						emailSendConfigDTO.toRecipients = new List<string>();
						var fpEmail = await _commonService.GetEmailBymuNO(currentMU);
						emailSendConfigDTO.toRecipients.Add(fpEmail);

						EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
						if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
							await MapDepolymentForEmail(res, DepObj, TemplateCode, employee: loggedInUser);
					}
					else if (TemplateCode.Equals("DEV003"))
					{
						emailSendConfigDTO.toRecipients = new List<string>();
						var fpEmail = await _commonService.GetEmailBymuNO(previousMU);
						emailSendConfigDTO.toRecipients.Add(fpEmail);

						EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
						if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
							await MapDepolymentForEmail(res, DepObj, TemplateCode, employee: loggedInUser);
					}
					else if (TemplateCode.Equals("DEV004"))
					{
						emailSendConfigDTO.toRecipients = new List<string>();
						var fpEmail = await _commonService.GetEmailBymuNO(currentMU);
						emailSendConfigDTO.toRecipients.Add(fpEmail);

						EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
						if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
							await MapDepolymentForEmail(res, DepObj, TemplateCode, employee: loggedInUser);
					}
					else if (TemplateCode.Equals("DEV005"))
					{
						emailSendConfigDTO.toRecipients = new List<string>();
						string fpEmail = "";
						if ((long)loggedInUser.ACTIVE_R_ID == Convert.ToInt64(UserRoleseEnum.UCT))
							fpEmail = await _commonService.GetEmailBymuNO(previousMU);
						else if((long)loggedInUser.ACTIVE_R_ID == Convert.ToInt64(UserRoleseEnum.CH))
							fpEmail = await _commonService.GetEmailBymuNO(currentMU);

						emailSendConfigDTO.toRecipients.Add(fpEmail);

						EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
						if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
							await MapDepolymentForEmail(res, DepObj, TemplateCode, employee: loggedInUser);
					}
					else if (TemplateCode.Equals("DEV006"))
					{
						emailSendConfigDTO.toRecipients = new List<string>();
						var fpEmail = await _commonService.GetEmailBymuNO(currentMU);
						emailSendConfigDTO.toRecipients.Add(fpEmail);

						EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
						if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
							await MapDepolymentForEmail(res, DepObj, TemplateCode, employee: loggedInUser);
					}
				}
			}
			return 0;
		}


		public async Task<long> SendReminderEmails(string Module, string TemplateCode)
		{
			TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
			if (EmailModule != null)
			{
				EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
				if (Template != null)
				{
					var emailEscConfig = await _unitOfWork.EmailEscalation.getEmailEscByCode(TemplateCode);
					var reminderData = await _unitOfWork.DepVot.reminderEmail(emailEscConfig.days.Value);

					if (reminderData != null && reminderData.Count > 0)
					{
						EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
						emailSendConfigDTO.moduleId = EmailModule.id;
						emailSendConfigDTO.templateId = Template.UniqueTemplateId;
						foreach (var item in reminderData)
						{
							emailSendConfigDTO.toRecipients = new List<string>();
							emailSendConfigDTO.ccRecipients = new List<string>();
							emailSendConfigDTO.toRecipients.Add(item.uctDetails.EMAIL_ADDRESS);
							emailSendConfigDTO.ccRecipients.Add(item.contractHolderDetails.EMAIL_ADDRESS);

							EmailSendConfigDTO emailConfig = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
							DepVot depVOT = await _unitOfWork.DepVot.GetFirstOrDefaultAsync(x => x.Id == item.id);
							if (depVOT != null)
							{
								depVOT.LastReminder = DateTime.Now;
								depVOT.UpdatedOn = DateTime.Now;

								depVOT.EscCount = emailEscConfig.escalCount > 0 ? depVOT.EscCount != null && depVOT.EscCount > 0 ? (depVOT.EscCount + 1) : 1 : 0;

								if (item.lastReminder != null && emailEscConfig.escalCount > 0 && emailEscConfig.escalCount == depVOT.EscCount && _configuration["ServerMode"] == "Prod")
								{
									var UctFp = await _unitOfWork.Employee.GetByMuNumber(item.uctDetails.PERSONNEL_NUMBER);
									if (UctFp != null && UctFp.SUPERVISOR_ID != null)
									{
										var UctFpEmail = await _commonService.GetEmailBymuNO(UctFp.SUPERVISOR_ID);
										emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
										depVOT.EscCount = 0;
									}
								}
							}
							if (emailConfig.keywords.Count > 0 && !string.IsNullOrEmpty(emailConfig.body))
							{
								var mapData = await MapDepolymentForEmail(emailConfig, item, TemplateCode);
								if (mapData)
								{
									_unitOfWork.DepVot.Update(depVOT);
									await _unitOfWork.SaveAsync();
								}
							}
						}
					}
				}
			}
			return 0;
		}

		public async Task<bool> MapDepolymentForEmail(EmailSendConfigDTO emailSendConfigDTO, DepVotEmailDTO DepObj, string TemplateCode, EmployeeDTO? employee = null)
		{
			string host = _configuration["TIPApplicationPath"];
			if (!string.IsNullOrEmpty(DepObj?.oldContractHolderDetails?.USER_DISPLAY) && (TemplateCode.Equals("DEV005") && (long)employee.ACTIVE_R_ID == Convert.ToInt64(UserRoleseEnum.CH)))
				emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", DepObj?.uctDetails.USER_DISPLAY);
			else if (!string.IsNullOrEmpty(DepObj?.uctDetails?.USER_DISPLAY) && (TemplateCode.Equals("DEV005") && (long)employee.ACTIVE_R_ID == Convert.ToInt64(UserRoleseEnum.UCT)))
				emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", DepObj?.oldContractHolderDetails.USER_DISPLAY);
			else if(!string.IsNullOrEmpty(DepObj?.uctDetails?.USER_DISPLAY))
				emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", DepObj?.uctDetails.USER_DISPLAY);
			if (TemplateCode.Equals("DEV001") && !string.IsNullOrEmpty(DepObj?.oldContractHolderDetails?.USER_DISPLAY))
				emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ContractHolder", DepObj?.oldContractHolderDetails.USER_DISPLAY);
			else if (!string.IsNullOrEmpty(DepObj?.contractHolderDetails?.USER_DISPLAY))
				emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ContractHolder", DepObj?.contractHolderDetails.USER_DISPLAY);


			emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ReferenceNo", DepObj?.pirRefNo);
			emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$TechName", DepObj?.techName);
			emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionCompletionDate", DepObj?.actionCompletionDate);
			emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionBy", DepObj?.actionBy);
			emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Quarter", DepObj?.quarter);

			if (TemplateCode.Equals("DEV005"))
			{
				string link = "";
				if ((long)employee.ACTIVE_R_ID == Convert.ToInt64(UserRoleseEnum.UCT)) {
					link = host + "/#/dep/vot?r_c=CH&Code=" + DepObj?.pirCode; 
				}
				else if ((long)employee.ACTIVE_R_ID == Convert.ToInt64(UserRoleseEnum.CH)) {
					link = host + "/#/dep/vot?r_c=UCT&Code=" + DepObj?.pirCode;
				}
				if (emailSendConfigDTO.body.Contains("$$Link"))
				{
					emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
				}
				else
				{
					emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view all the plans: " + "<a href='" + link + "'>Link</a>";
				}
			}
			else if (TemplateCode.Equals("DEV007"))
			{
				string link = host + "/#/dep/vot?r_c=UCT&Code=" + DepObj?.pirCode;
				if (emailSendConfigDTO.body.Contains("$$Link"))
				{
					emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
				}
				else
				{
					emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view all the plans waiting for your actual VOT: " + "<a href='" + link + "'>Link</a>";
				}
			}

			return await _commonService.SendEmail(emailSendConfigDTO);
		}


		public async Task<List<DepReassignmentDTO>> GetAllDeploymentforReAssignment(long roleId, string CompanyNumber)
		{
			return await _unitOfWork.DepVot.GetAllDeploymentforReAssignment(roleId, CompanyNumber);
		}
		public async Task<DeploymentTrialfpsDTO> GetCHFPForDeploymentbyId(long id)
		{
			return await _unitOfWork.DepVot.GetCHFPForDeploymentbyId(id);
		}
		public async Task<DeploymentTrialfpsDTO> GetUCTFPForDeploymentbyId(string CompanyNumber)
		{
			return await _unitOfWork.DepVot.GetUCTFPForDeploymentbyId(CompanyNumber);
		}

		public async Task<DepInitiation> GetDeploymentReAssignment(long Id)
		{
			return await _unitOfWork.DepVot.GetDeploymentDBObj(Id);
		}
		public async Task<long> UpdateDeploymentReAssignment(DepInitiation DTO)
		{
			try
			{
				_unitOfWork.DepInitiation.Update(DTO);
				long result = await _unitOfWork.SaveAsync();
				if (result > 0)
				{
					return DTO.Id;
				}
				return result;

			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

	}

}
