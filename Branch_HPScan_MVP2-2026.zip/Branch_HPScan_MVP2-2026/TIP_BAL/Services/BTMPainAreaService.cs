﻿using Microsoft.Extensions.Configuration;
using Microsoft.Reporting.Map.WebForms.BingMaps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface;
using TIP_BusinessLogic.Interface;
using TIP_BusinessLogic.Services;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Repository;
using static TIP_Common.Enum.Enum;

namespace TIP_BAL.Services
{
    public class BTMPainAreaService: IBTMPainAreaService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICommonService _commonService;
        private readonly IBTMAssesmentService _bTMAssesmentService;
        private readonly IConfiguration _configuration;
        public BTMPainAreaService(IUnitOfWork unitOfWork, ICommonService commonService, IBTMAssesmentService bTMAssesmentService,IConfiguration configuration)
        {
            this._unitOfWork = unitOfWork;
            _commonService = commonService;
            _bTMAssesmentService = bTMAssesmentService;
            _configuration = configuration;
        }

        public Task<List<BTMAssessmentDTO>> GetAssessmentsForRanking(string MU)
        {
            return _unitOfWork.PainAreas.GetAssessmentsForRanking(MU);
        }

        public Task<List<BTMAssessmentDTO>> GetFilterAssessmentsForRanking(BTMAssessmentFilterDTO btmAssessmentIP_DTO)
        {
            return _unitOfWork.PainAreas.GetFilterAssessmentsForRanking(btmAssessmentIP_DTO);
        }

        public Task<List<PainAreaDTO>> GetPainAreasByAssessmentId(long AssessmentId,EmployeeDTO employee)
        {
            return _unitOfWork.PainAreas.GetPainAreasByAssessmentId(AssessmentId,employee);
        }

        public Task<List<RankPainAreaDTO>> GetPainAreasForRanking(long AssessmentId)
        {
            return _unitOfWork.PainAreas.GetPainAreasForRanking(AssessmentId);
        }

        public Task<List<RankPainAreaDTO>> GetFilterPainAreasForRanking(RankPainAreaFilterDTO rankPainAreaFilterDTO)
        {
            return _unitOfWork.PainAreas.GetFilterPainAreasForRanking(rankPainAreaFilterDTO);
        }

        public async Task<long> UpdateRank(PainArea recObj)
        {
            try
            {
                PainArea? obj = null;
                obj = await _unitOfWork.PainAreas.GetFirstOrDefaultAsync(x => x.Id == recObj.Id);
                obj.UpdatedBy = recObj.UpdatedBy;
                obj.UpdatedOn = recObj.UpdatedOn;
                obj.Rank= recObj.Rank;
                _unitOfWork.PainAreas.Update(obj);
                long result = await _unitOfWork.SaveAsync();
                return result;
            }
            catch
            {
                throw;
            }
        }

        public async Task<BtmAssessment> GetAssessmentById(long AssessmentId)
        {
            try
            {
                return await _unitOfWork.BTMAssesment.GetFirstOrDefaultAsync(x => x.Id == AssessmentId);
            }
            catch
            {
                throw;
            }
        }
        public async Task<PainArea> GetPainAreabyId(long id)
        {
            try
            {
                return await _unitOfWork.PainAreas.GetFirstOrDefaultAsync(x => x.Id == id);
            }
            catch
            {
                throw;
            }
        }
        public async Task<long> SubmitAssessment(BtmAssessment obj)
        {
            try
            {
                _unitOfWork.BTMAssesment.Update(obj);
                long result = await _unitOfWork.SaveAsync();
                var muNos = new List<string>();
                var submittedId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.BTIAssessmentStatus, BTIAssessment.Submitted).Result.Id;
                var reviewedId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.BTIAssessmentStatus, BTIAssessment.Reviewed).Result.Id;

				if (obj.StatusId == submittedId)
                    muNos = await _unitOfWork.PainAreas.GetAllAssetsMuNo(obj.AssetId);
               
                if (muNos.Count > 0)
                {
                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = _commonService.GetMasterDataByParentAndParam1(TypeCodes.EmailTemplate, EmailModules.BTIAS).Result.Id;
                    if (obj.StatusId == submittedId)
                        emailSendConfigDTO.templateId = 1;
                    if (obj.StatusId == reviewedId)
                        emailSendConfigDTO.templateId = 2;
                    emailSendConfigDTO.toRecipients = new List<string>();
                    emailSendConfigDTO.ccRecipients = new List<string>();

                    for (int i = 0; i < muNos.Count; i++)
                    {
                        string email = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(muNos[i]);
                        emailSendConfigDTO.toRecipients.Add(email);                       
                    }
                    EmployeeDTO? loggedinuser = _commonService.GetIdentityOfLoggedInUser("CORP\\"+obj.UpdatedBy);
                    EmailSendConfigDTO res = null;
                    res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                    if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                        await _bTMAssesmentService.MapBTMForEmail(res, obj.Id,loggedinuser);
                }
                return result;
            }
            catch
            {
                throw;
            }
        }


        public async Task<long> SendBTMEmail(long painAreaId, string Module, string TemplateCode,EmployeeDTO employee)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {


                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {
                    BTMAssessmentKeywordDTO btmObj = await _unitOfWork.BTMAssesment.GetBTMAssessmentByPainAreaId(painAreaId);

                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;
                    var muNosTo = new List<string>();
                    var muNosCC = new List<string>();
                    if (TemplateCode.Equals("BTMP01")) // pain area submitted
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();                        
                        emailSendConfigDTO.ccRecipients = new List<string>();
                        emailSendConfigDTO.RecipientsNames = new List<string>();

                        muNosTo = await _unitOfWork.PainAreas.GetAllAssetsMuNo(btmObj.assetId);
                        muNosCC = await _unitOfWork.PainAreas.GetAllCustorsMuNo((long) btmObj.clusterId);
                        for (int i = 0; i < muNosTo.Count; i++)
                        {
                            EmployeeDTO empdata = await _unitOfWork.Employee.GetByMuNumber(muNosTo[i]);
                            if (empdata != null)
                            {
                                emailSendConfigDTO.toRecipients.Add(empdata.EMAIL_ADDRESS);
                                emailSendConfigDTO.RecipientsNames.Add(empdata.DISPLAY_NAME);
                            }

                            

                        }

                        for (int i = 0; i < muNosCC.Count; i++)
                        {
                            string email = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(muNosCC[i]);
                            emailSendConfigDTO.ccRecipients.Add(email);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapBTMForEmail(res, painAreaId, btmObj, TemplateCode,employee);
                    }
                    if (TemplateCode.Equals("BTMP02")) // pain area reviewed
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        emailSendConfigDTO.ccRecipients = new List<string>();
                        emailSendConfigDTO.RecipientsNames = new List<string>();

                        muNosTo = await _unitOfWork.PainAreas.GetAllCustorsMuNo((long)btmObj.clusterId);
                        muNosCC = await _unitOfWork.PainAreas.GetAllAssetsMuNo(btmObj.assetId);
                        for (int i = 0; i < muNosTo.Count; i++)
                        {
                            EmployeeDTO empdata = await _unitOfWork.Employee.GetByMuNumber(muNosTo[i]);
                            if (empdata != null)
                            {
                                emailSendConfigDTO.toRecipients.Add(empdata.EMAIL_ADDRESS);
                                emailSendConfigDTO.RecipientsNames.Add(empdata.DISPLAY_NAME);
                            }

                           
                        }

                        for (int i = 0; i < muNosCC.Count; i++)
                        {
                            string email = await _unitOfWork.ChallengeDetail.GetEmailBymuNO(muNosCC[i]);
                            emailSendConfigDTO.ccRecipients.Add(email);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapBTMForEmail(res, painAreaId, btmObj, TemplateCode,employee);
                    }
                }
            }
            return 0;
        }

        public async Task<bool> MapBTMForEmail(EmailSendConfigDTO emailSendConfigDTO, long painAreaId, BTMAssessmentKeywordDTO obj, string TemplateCode,EmployeeDTO? employee=null)
        {
            string host = _configuration["TIPApplicationPath"];
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Year", obj.year.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Asset", obj.asset.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Cluster", obj.cluster.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Department", obj.department.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$WorkshopDate", obj.workshopDate.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionStatus", obj.actionStatus.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionBy", obj.actionBy.ToString());
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ActionCompletionDate", obj.actionDate.ToString());

            if (emailSendConfigDTO.RecipientsNames != null && emailSendConfigDTO.RecipientsNames.Count > 0)
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ToUserNames", string.Join(',', emailSendConfigDTO.RecipientsNames));
            }
            else
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ToUserNames", "Recipient");
            }


            string link = host + "/#/bti/manage-assessment?r_c";
            if (TemplateCode == "BTMP01")
                link = link + "=AFP";
            else if(TemplateCode == "BTMP02")
                link = link + "=CFP";
            if (emailSendConfigDTO.body.Contains("$$Link"))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
            }
            else
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view/take action : " + "<a href='" + link + "'>Link</a>";
            }
            return await _commonService.SendEmail(emailSendConfigDTO,employee);
        }
        public bool CheckIfAssessmentCanBeReviewed(long AssessmentId)
        {
            if(_unitOfWork.PainAreas.GetAllAsync(a => a.AssessmentId == AssessmentId && (a.Rank == null|| a.Rank==0)).Result.Count()==0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public async Task<long> AddPainArea(PainArea DTO)
        {
            try
            {
                BtmAssessment obj= await _unitOfWork.BTMAssesment.GetFirstOrDefaultAsync(x => x.Id ==DTO.AssessmentId);
                string refrno = "BT-" + obj.Id + "-";
                DTO.Reference = refrno +( (obj.UpdatedOn == null) ? obj.CreatedOn.ToString("ddMMyyyy") : obj.UpdatedOn?.ToString("ddMMyyyy"));
                //BT-xx-ddmmyy
                await _unitOfWork.PainAreas.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<long> DeletePainArea(long ID,EmployeeDTO employee)
        {
            try
            {
                PainArea? obj = null;
                obj = await _unitOfWork.PainAreas.GetFirstOrDefaultAsync(x => x.Id == ID);
                var audittrailObj = new UtlAuditTrail()
                {
                    TableName = "PAIN_AREAS",
                    Action = "DELETE",
                    ActionBy = employee.DISPLAY_NAME + " " + employee.COMPANY_NUMBER,
                    ActionOn = System.DateTime.Today.ToString(),
                    Description = JsonSerializer.Serialize(obj),
                };
                if (obj != null)
                {
                    _unitOfWork.PainAreas.Remove(obj);
                }
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdatePainArea(PainArea DTO)
        {
            try
            {
                PainArea? obj = null;
                obj = await _unitOfWork.PainAreas.GetFirstOrDefaultAsync(x => x.Id == DTO.Id);
                if (obj != null)
                {
                    obj.Description = DTO.Description;
                    obj.Deferment= DTO.Deferment;   
                    obj.Emission= DTO.Emission; 
                    obj.Remarks= DTO.Remarks;   
                    obj.TechDescription= DTO.TechDescription;
                    obj.TechFp= DTO.TechFp;
                    obj.UctFp= DTO.UctFp;
                    obj.Cost= DTO.Cost;
                    obj.Hsse= DTO.Hsse;
                    obj.NtCatalogSolution= DTO.NtCatalogSolution;
                    obj.NtSolution= DTO.NtSolution; 
                    obj.Status= DTO.Status;
                    obj.Rank= DTO.Rank;
                    obj.UpdatedBy= DTO.UpdatedBy;
                    obj.UpdatedOn= DTO.UpdatedOn;  
                    obj.ClusterId=DTO.ClusterId;
                    obj.NtSource= DTO.NtSource;
                    _unitOfWork.PainAreas.Update(obj);
                }
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
