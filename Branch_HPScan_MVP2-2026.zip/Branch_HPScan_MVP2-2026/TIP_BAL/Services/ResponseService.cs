﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_BAL.Interface;
using TIP_CORE.Entities;

namespace TIP_BAL.Services
{
    internal class ResponseService : IResponseService
    {
        private readonly IUnitOfWork _unitOfWork;
        public ResponseService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public async Task<long> AddNewChallengeResponse(ChallengeResponse challengeDTO)
        {
            try
            {
                await _unitOfWork.ChallengeResponse.AddAsync(challengeDTO);
                long result = await _unitOfWork.SaveAsync();
                var obj = await _unitOfWork.ChallengeResponse.GetFirstOrDefaultAsync(x => x.Id == challengeDTO.Id);
                if (obj != null)
                {
                    obj.ResReferenceNo = "CH-" + challengeDTO.Id + "-" + DateTime.Today.ToString("ddMMyyyy");
                    _unitOfWork.ChallengeResponse.Update(obj);
                }
                if (result > 0)
                {
                    return challengeDTO.Id;// or Id if table id exist
                }

                return result;
            }
            catch
            {
                throw;
            }
        }
    }
}
