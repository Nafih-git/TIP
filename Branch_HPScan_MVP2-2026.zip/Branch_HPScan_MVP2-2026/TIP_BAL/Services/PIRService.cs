﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Reporting.NETCore;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using TIP_API.DTO.Admin;
using TIP_BAL.Interface;
using TIP_BusinessLogic.Interface;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using static TIP_Common.Enum.Enum;

namespace TIP_BAL.Services
{
    public class PIRService : IPIRService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICommonService _commonService;
        private readonly IConfiguration _configuration;
        public PIRService(IUnitOfWork unitOfWork, ICommonService commonService, IConfiguration configuration)
        {
            this._unitOfWork = unitOfWork;
            _commonService = commonService;
            _configuration = configuration;
        }

        public async Task<List<ApprovedCtrDTO>> GetApprovedCtr(string CompanyNumber)
        {
            return await _unitOfWork.Ctr.GetApprovedCtr(CompanyNumber);
        }
        public async Task<List<ApprovedCtrDTO>> GetPirToReview(string CompanyNumber)
        {
            return await _unitOfWork.Ctr.GetApprovedCtr(CompanyNumber);
        }
        public async Task<List<ApprovedCtrDTO>> GetPirForApproval(string CompanyNumber)
        {
            return await _unitOfWork.Ctr.GetPirForApproval(CompanyNumber);
        }


        public async Task<PirCtrInitDTO> GetCtrPriData(long CtrId, long PirId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.Ctr.GetCtrPriData(CtrId, PirId, roleid, CompanyNumber);
        }

        public async Task<long> InitiatePir(PirInitiation DTO)
        {

            try
            {
                DTO.Id = 0;
                await _unitOfWork.Pir.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();

                PirInitiation obj = await _unitOfWork.Pir.GetFirstOrDefaultAsync(x => x.Id == DTO.Id);
                CtrInitiation ctr = await _unitOfWork.Ctr.GetFirstOrDefaultAsync(x => x.Id == obj.CtrId);
                obj.DsAssumptionMode = ctr.DsAssumptionMode;
                obj.DsComments = ctr.DsComment;

                string refrno = "PIR-" + obj.Id.ToString().PadLeft(5, '0');
                obj.RefNo = refrno;

              
                _unitOfWork.Pir.Update(obj);

                long result1 = await _unitOfWork.SaveAsync();
                if (result1 > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result1;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddTrialFp(List<PirTrialFp> DTO)
        {
            try
            {

                long PirId = DTO.FirstOrDefault(x => x.IsMandatory.Equals(true)).PirId;

                _unitOfWork.PirTrialFp.RemoveRange(_unitOfWork.PirTrialFp.GetAllAsync(a => a.PirId.Equals(PirId)).Result);

                foreach (var item in DTO)
                {
                    item.Id = 0;
                }

                await _unitOfWork.PirTrialFp.AddRangeAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<long> AddFlowHistory(PirFlowHistory DTO)
        {

            try
            {
                DTO.Id = 0;
                await _unitOfWork.PirFlowHistory.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<PirFlowHistoryDTO>> GetAllFlowHistory(long PirId)
        {
            return await _unitOfWork.PirFlowHistory.GetHistoryById(PirId);
        }

        public async Task<List<PirFlowHistoryDTO>> GetAllFlowHistoryDetail(long PirId)
        {
            return await _unitOfWork.PirFlowHistory.GetAllFlowHistoryDetail(PirId);
        }


        #region PirCrud

        public async Task<PirInitiation> GetById(long Id)
        {
            return await _unitOfWork.Pir.GetAsync(Id);
        }

        public async Task<PirInitiationDTO> GetPirDataByRefNo(string RefNo)
        {
            return await _unitOfWork.Pir.GetPirDataByRefNo(RefNo);
        }
     
        public async Task<PirWorkFlowDTO> GetPirWorkFlowData(long PirId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.Pir.GetPirWorkFlowData(PirId, roleid, CompanyNumber);
        }
        public async Task<PirGeneralInformationDTO> GetPirData(long PirId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.Pir.GetPirData(PirId, roleid, CompanyNumber);
        }

        public async Task<PirTrialDetailsDTO> GetPirTrialDetailsData(long PirId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.Pir.GetPirTrialDetailsData(PirId, roleid, CompanyNumber);
        }

        public async Task<long> UpdatePir(PirInitiation DTO)
        {
            try
            {
                _unitOfWork.Pir.Update(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

      



        public async Task<long> UpdatePirGeneralInformation(PirInitiation DTO)
        {
            try
            {
                _unitOfWork.Pir.Update(DTO);
                long result = await _unitOfWork.SaveAsync();

               

                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdatePirTrialDetails(PirInitiation DTO)
        {
            try
            {
                _unitOfWork.Pir.Update(DTO);
                long result = await _unitOfWork.SaveAsync();

               

                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddSupportingMemebers(List<PirSupportingMember> DTO)
        {
            try
            {

                long PirId = DTO.FirstOrDefault().PirId;

                _unitOfWork.PirSupportingMembers.RemoveRange(_unitOfWork.PirSupportingMembers.GetAllAsync(a => a.PirId.Equals(PirId)).Result);

                foreach (var member in DTO)
                {
                    member.Id = 0;
                }

                await _unitOfWork.PirSupportingMembers.AddRangeAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region Assessment of Trial Candidates
        public async Task<List<PirTrialCandidateDTO>> GetAllTrialCandidates(long PirId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.PirTrialCandidate.GetAllTrialCandidates(PirId, roleid, CompanyNumber);
        }

        public async Task<long> AddTrialCandidates(PirTrialCandidate pirTrialCandidate)
        {
            try
            {
                pirTrialCandidate.Id = 0;
                await _unitOfWork.PirTrialCandidate.AddAsync(pirTrialCandidate);
                long result = await _unitOfWork.SaveAsync();

                if (result > 0)
                {
                    return pirTrialCandidate.Id;
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> UpdateTrialCandidates(PirTrialCandidate obj)
        {
            try
            {
                PirTrialCandidate dbObj = await _unitOfWork.PirTrialCandidate.GetFirstOrDefaultAsync(x => x.Id == obj.Id);

                if (dbObj != null)
                {

                    dbObj.TypeId = obj.TypeId;
                    dbObj.Name = obj.Name;
                    dbObj.Cost = obj.Cost;
                    dbObj.CommencementDate = obj.CommencementDate;
                    dbObj.ConclusionDate = obj.ConclusionDate;
                    dbObj.ChallengeDescription = obj.ChallengeDescription;
                    dbObj.Comments = obj.Comments;
                    dbObj.UpdatedBy = obj.UpdatedBy;
                    dbObj.UpdatedByRef = obj.UpdatedByRef;
                    dbObj.UpdatedOn = obj.UpdatedOn;

                    _unitOfWork.PirTrialCandidate.Update(dbObj);
                    long result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return dbObj.Id;
                    }
                    return result;
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> DeleteTrialCandidates(long id)
        {
            try
            {
                PirTrialCandidate? obj = null;
                obj = await _unitOfWork.PirTrialCandidate.GetFirstOrDefaultAsync(x => x.Id == id);

                if (obj != null)
                {
                    _unitOfWork.PirTrialCandidate.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    if (result > 0)
                    {
                        return result;
                    }
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Assessment of Trial Results
        public async Task<List<PirAssessmentTrialResultDTO>> GetAllAssessmentTrialResults(long PirId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.PirAssessmentTrialResult.GetAllAssessmentTrialResults(PirId, roleid, CompanyNumber);
        }

        public async Task<long> AddAssessmentTrialResult(PirAssessmentTrialResult pirAssessment)
        {
            try
            {
                await _unitOfWork.PirAssessmentTrialResult.AddAsync(pirAssessment);
                long result = await _unitOfWork.SaveAsync();

                if (result > 0)
                {
                    return pirAssessment.Id;
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> UpdateAssessmentTrialResult(PirAssessmentTrialResult obj)
        {
            try
            {
                PirAssessmentTrialResult dbObj = await _unitOfWork.PirAssessmentTrialResult.GetFirstOrDefaultAsync(x => x.Id == obj.Id);

                if (dbObj != null)
                {

                    dbObj.Parameter = obj.Parameter;
                    dbObj.Target = obj.Target;
                    dbObj.ConclusionId = obj.ConclusionId;
                    dbObj.Comments = obj.Comments;
                    dbObj.PirId = obj.PirId;
                    dbObj.UpdatedBy = obj.UpdatedBy;
                    dbObj.UpdatedByRef = obj.UpdatedByRef;
                    dbObj.UpdatedOn = obj.UpdatedOn;


                    _unitOfWork.PirAssessmentTrialResult.Update(dbObj);
                    long result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return dbObj.Id;
                    }
                    return result;
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> DeleteAssessmentTrial(long id)
        {
            try
            {
                PirAssessmentTrialResult? obj = null;
                obj = await _unitOfWork.PirAssessmentTrialResult.GetFirstOrDefaultAsync(x => x.Id == id);

                if (obj != null)
                {
                    _unitOfWork.PirAssessmentTrialResult.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    if (result > 0)
                    {
                        return result;
                    }
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region Lesson Learnt
        public async Task<List<PirLessonLearntDTO>> GetAllLessonLearnt(long PirId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.PirLessonLearnt.GetAllLessonLearnt(PirId, roleid, CompanyNumber);
        }

        public async Task<long> AddLessonLearnt(PirLessonLearnt pirLessonLearnt)
        {
            try
            {
                pirLessonLearnt.Id = 0;
                await _unitOfWork.PirLessonLearnt.AddAsync(pirLessonLearnt);
                long result = await _unitOfWork.SaveAsync();

                if (result > 0)
                {
                    return pirLessonLearnt.Id;
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> UpdateLessonLearnt(PirLessonLearnt obj)
        {
            try
            {
                PirLessonLearnt dbObj = await _unitOfWork.PirLessonLearnt.GetFirstOrDefaultAsync(x => x.Id == obj.Id);

                if (dbObj != null)
                {

                    dbObj.Description = obj.Description;
                    dbObj.CorrectiveMeasures = obj.CorrectiveMeasures;
                    dbObj.PirId = obj.PirId;
                    dbObj.UpdatedBy = obj.UpdatedBy;
                    dbObj.UpdatedByRef = obj.UpdatedByRef;
                    dbObj.UpdatedOn = obj.UpdatedOn;


                    _unitOfWork.PirLessonLearnt.Update(dbObj);
                    long result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return dbObj.Id;
                    }
                    return result;
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> DeleteLessonLearnt(long id)
        {
            try
            {
                PirLessonLearnt? obj = null;
                obj = await _unitOfWork.PirLessonLearnt.GetFirstOrDefaultAsync(x => x.Id == id);

                if (obj != null)
                {
                    _unitOfWork.PirLessonLearnt.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    if (result > 0)
                    {
                        return result;
                    }
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Impacted Existing Contracts
        public async Task<List<PirImpactedExistingContractDTO>> GetAllImpactedContracts(long PirId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.PirImpactedExistingContract.GetAllContracts(PirId, roleid, CompanyNumber);
        }
        public async Task<long> AddContractsFromCtr(long PirId, EmployeeDTO? LoggedInUser)
        {
            try
            {
                long result = 0;
                PirInitiation pir = await _unitOfWork.Pir.GetAsync(PirId);

                List<CtrPotentialImpactedDTO>? lst = await _unitOfWork.CtrPotentialImpacted.GetCtrPotentialImpacted(pir.CtrId);

                List<PirImpactedExistingContract> newlst = new List<PirImpactedExistingContract>();

                if (lst != null && lst.Count > 0)
                {
                    foreach (CtrPotentialImpactedDTO c in lst)
                    {
                        PirImpactedExistingContract newObj = new PirImpactedExistingContract()
                        {
                            Id = 0,
                            ContractNo = c.no,
                            ContractTitle = c.title + " - Imported from TTA",
                            Contractor = c.provider,
                            Impact = c.impact,
                            PirId = PirId,
                            CreatedBy = LoggedInUser.COMPANY_NUMBER,
                            CreatedByRef = LoggedInUser.REFERENCE_INDICATOR,
                            CreatedOn = DateTime.Now
                        };
                        newlst.Add(newObj);
                    }
                }

                if (newlst != null && newlst.Any())
                {
                    await _unitOfWork.PirImpactedExistingContract.AddRangeAsync(newlst);
                    result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return result;
                    }
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> AddImpactedContracts(PirImpactedExistingContract pirImpactedExisting)
        {
            try
            {
                pirImpactedExisting.Id = 0;
                await _unitOfWork.PirImpactedExistingContract.AddAsync(pirImpactedExisting);
                long result = await _unitOfWork.SaveAsync();

                if (result > 0)
                {
                    return pirImpactedExisting.Id;
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> UpdateImpactedContracts(PirImpactedExistingContract obj)
        {
            try
            {
                PirImpactedExistingContract dbObj = await _unitOfWork.PirImpactedExistingContract.GetFirstOrDefaultAsync(x => x.Id == obj.Id);

                if (dbObj != null)
                {

                    dbObj.ContractNo = obj.ContractNo;
                    dbObj.ContractTitle = obj.ContractTitle;
                    dbObj.Contractor = obj.Contractor;
                    dbObj.Impact = obj.Impact;

                    dbObj.UpdatedBy = obj.UpdatedBy;
                    dbObj.UpdatedByRef = obj.UpdatedByRef;
                    dbObj.UpdatedOn = obj.UpdatedOn;


                    _unitOfWork.PirImpactedExistingContract.Update(dbObj);
                    long result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return dbObj.Id;
                    }
                    return result;
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> DeleteImpactedContracts(long id)
        {
            try
            {
                PirImpactedExistingContract? obj = null;
                obj = await _unitOfWork.PirImpactedExistingContract.GetFirstOrDefaultAsync(x => x.Id == id);

                if (obj != null)
                {
                    _unitOfWork.PirImpactedExistingContract.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    if (result > 0)
                    {
                        return result;
                    }
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Deployment Staircase

        public async Task<long> AddDeploymentStaircaseFromCtr(long PirId, EmployeeDTO? LoggedInUser)
        {
            try
            {
                long result = 0;
                PirInitiation pir = await _unitOfWork.Pir.GetAsync(PirId);

                List<CtrDeploymentStaircaseDTO>? lst = await _unitOfWork.CtrDeploymentStaircase.GetCtrDeploymentStaircase(pir.CtrId);

                List<PirDeploymentStaircase> newlst = new List<PirDeploymentStaircase>();

                if (lst != null && lst.Count > 0)
                {
                    foreach (CtrDeploymentStaircaseDTO c in lst)
                    {
                        PirDeploymentStaircase newObj = new PirDeploymentStaircase()
                        {
                            FeildStationName = c.station,
                            Year = (long)c.year,
                            NoOfWells = (long)c.noofwells,
                            EstimatedVot = (decimal)c.estimatedvot,
                            PirId = PirId,
                            Comments = "Imported from TTA",
                            CreatedBy = LoggedInUser.COMPANY_NUMBER,
                            CreatedByRef = LoggedInUser.REFERENCE_INDICATOR,
                            CreatedOn = DateTime.Now
                        };
                        newlst.Add(newObj);
                    }
                }

                if (newlst != null && newlst.Any())
                {
                    await _unitOfWork.PirDeploymentStaircase.AddRangeAsync(newlst);
                    result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return result;
                    }
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PirDeploymentStaircaseDetailsDTO> GetPirDeploymentStaircaseData(long PirId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.Pir.GetPirDeploymentStaircaseData(PirId, roleid, CompanyNumber);
        }


        public async Task<long> UpdatePirDeploymentStaircaseData(PirInitiation DTO)
        {
            try
            {
                _unitOfWork.Pir.Update(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<PirDeploymentStaircaseDTO>> GetAllDeploymentStaircase(long PirId, long roleid, string CompanyNumber)
        {
            return await _unitOfWork.PirDeploymentStaircase.GetAllDeploymentStaircase(PirId, roleid, CompanyNumber);
        }

        public async Task<long> AddDeploymentStaircase(PirDeploymentStaircase deploymentStaircase)
        {
            try
            {
                await _unitOfWork.PirDeploymentStaircase.AddAsync(deploymentStaircase);
                long result = await _unitOfWork.SaveAsync();

                if (result > 0)
                {
                    return deploymentStaircase.Id;
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> UpdateDeploymentStaircase(PirDeploymentStaircase obj)
        {
            try
            {
                PirDeploymentStaircase dbObj = await _unitOfWork.PirDeploymentStaircase.GetFirstOrDefaultAsync(x => x.Id == obj.Id);

                if (dbObj != null)
                {


                    dbObj.FeildStationName = obj.FeildStationName;
                    dbObj.WellType = obj.WellType;
                    dbObj.Year = obj.Year;
                    dbObj.NoOfWells = obj.NoOfWells;
                    dbObj.EstimatedVot = obj.EstimatedVot;
                    dbObj.AssumptionMode = obj.AssumptionMode;
                    dbObj.Comments = obj.Comments;

                    dbObj.UpdatedBy = obj.UpdatedBy;
                    dbObj.UpdatedByRef = obj.UpdatedByRef;
                    dbObj.UpdatedOn = obj.UpdatedOn;


                    _unitOfWork.PirDeploymentStaircase.Update(dbObj);
                    long result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return dbObj.Id;
                    }
                    return result;
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> DeleteDeploymentStaircase(long id)
        {
            try
            {
                PirDeploymentStaircase? obj = null;
                obj = await _unitOfWork.PirDeploymentStaircase.GetFirstOrDefaultAsync(x => x.Id == id);

                if (obj != null)
                {
                    _unitOfWork.PirDeploymentStaircase.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    if (result > 0)
                    {
                        return result;
                    }
                }

                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #endregion

        #region PIR VOT
        public async Task<PirVotDTO> GetPirVOT(long pirId)
        {
            return await _unitOfWork.PirVot.GetVOTDetails(pirId);
        }

        public async Task<long> AddOrUpdateVOT(PirVot pirVot, bool isEdit)
        {            
                await DeleteVOT(pirVot.PirId);
                pirVot.Id = 0;
           
            await _unitOfWork.PirVot.AddAsync(pirVot);
            long result = await _unitOfWork.SaveAsync();
            return pirVot.Id;
        }
        public async Task<long> AddOrUpdateDepStaircase(List<PirDeploymentStaircase> depStairs)
        {

            await DeleteDepStairs(depStairs[0].PirId);
            await _unitOfWork.PirDeploymentStaircase.AddRangeAsync(depStairs);
            long result = await _unitOfWork.SaveAsync();
            return 1;
        }

        public async Task<long> DeleteDepStairs(long id)
        {
            try
            {

                var obj = await _unitOfWork.PirDeploymentStaircase.GetAllAsync(x => x.PirId == id);
                if (obj != null)
                {
                    _unitOfWork.PirDeploymentStaircase.RemoveRange(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> DeleteVOT(long id)
        {
            try
            {
                
               var obj = await _unitOfWork.PirVot.GetAllAsync(x => x.PirId == id);
                if (obj != null)
                {
                    _unitOfWork.PirVot.RemoveRange(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        public async Task<List<PirActionPlanDTO>> GetPirActionPlan(long pirId)
        {
            try
            {
                return await _unitOfWork.PirActionPlan.GetPirActionPlans(pirId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddPirActionPlan(PirActionPlan pirActionPlan)
        {
            try
            {
                await _unitOfWork.PirActionPlan.AddAsync(pirActionPlan);
                await _unitOfWork.SaveAsync();
                return pirActionPlan.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdatePirActionPlan(PirActionPlan pirActionPlan)
        {
            PirActionPlan obj = null;
            obj = await _unitOfWork.PirActionPlan.GetFirstOrDefaultAsync(x => x.Id == pirActionPlan.Id);
            obj.Title = pirActionPlan.Title;
            obj.Party = pirActionPlan.Party;
            obj.Target = pirActionPlan.Target;
            obj.UpdatedBy = pirActionPlan.UpdatedBy;
            obj.UpdatedByRef = pirActionPlan.UpdatedByRef;
            obj.UpdatedOn = pirActionPlan.UpdatedOn;

            _unitOfWork.PirActionPlan.Update(obj);
            await _unitOfWork.SaveAsync();
            return pirActionPlan.Id;
        }

        public async Task<long> DeletePirActionPlan(long id)
        {
            try
            {
                PirActionPlan obj = null;
                obj = await _unitOfWork.PirActionPlan.GetFirstOrDefaultAsync(x => x.Id == id);
                if (obj != null)
                {
                    _unitOfWork.PirActionPlan.Remove(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PirSummaryDTO> GetPirSummary(long pirId)
        {
            try
            {
                return await _unitOfWork.PirSummary.GetPirSummary(pirId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddPirSummary(PirSummary pirSummary)
        {
            try
            {
                pirSummary.Id = 0;
                await _unitOfWork.PirSummary.AddAsync(pirSummary);
                await _unitOfWork.SaveAsync();
                return pirSummary.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdatePirSummary(PirSummary pirSummary)
        {
            PirSummary obj = null;
            obj = await _unitOfWork.PirSummary.GetFirstOrDefaultAsync(x => x.Id == pirSummary.Id);
            obj.TrialId = pirSummary.TrialId;
            obj.Summary = pirSummary.Summary;
            obj.UpdatedBy = pirSummary.UpdatedBy;
            obj.UpdatedByRef = pirSummary.UpdatedByRef;
            obj.UpdatedOn = pirSummary.UpdatedOn;

            _unitOfWork.PirSummary.Update(obj);
            await _unitOfWork.SaveAsync();
            return pirSummary.Id;
        }

        #region Emails

        public async Task<long> SendEmail(long PIRId, string Module, string TemplateCode, string? Comment,EmployeeDTO? employee=null)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {


                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {
                    PirEmailDTO pirObj = await _unitOfWork.Pir.GetEmailData(PIRId, TemplateCode);

                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                    if (TemplateCode.Equals("PIR001")) // PIR Initiated
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        foreach (AllPDOUsersDTO mtfp in pirObj.MandatoryTP)
                        {
                            var fpEmail = await _commonService.GetEmailBymuNO(mtfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(fpEmail);
                        }


                        emailSendConfigDTO.ccRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Otfp in pirObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }

                        var UCTfpEmail = await _commonService.GetEmailBymuNO(pirObj.UctFp);
                        emailSendConfigDTO.ccRecipients.Add(UCTfpEmail);
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);
                        
                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapPirForEmail(res, PIRId, pirObj, TemplateCode);
                    }
                    else if (TemplateCode.Equals("PIR002") || TemplateCode.Equals("PIR003")) //Submit Ctr && Re Submit Ctr
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var UctFpEmail = await _commonService.GetEmailBymuNO(pirObj.UctFp);
                        emailSendConfigDTO.toRecipients.Add(UctFpEmail);
                        emailSendConfigDTO.ccRecipients = new List<string>();
                        foreach (AllPDOUsersDTO mtfp in pirObj.MandatoryTP)
                        {
                            var fpEmail = await _commonService.GetEmailBymuNO(mtfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(fpEmail);
                        }


                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapPirForEmail(res, PIRId, pirObj, TemplateCode);
                    }
                    else if (TemplateCode.Equals("PIR005")) //Sent Back
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        foreach (AllPDOUsersDTO mtfp in pirObj.MandatoryTP)
                        {
                            var fpEmail = await _commonService.GetEmailBymuNO(mtfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(fpEmail);
                        }

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        var UCTfpEmail = await _commonService.GetEmailBymuNO(pirObj.UctFp);
                        emailSendConfigDTO.toRecipients.Add(UCTfpEmail);
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapPirForEmail(res, PIRId, pirObj, TemplateCode, Comment);
                    }
                    else if (TemplateCode.Equals("PIR007")) //Next lvel approve email
                    {
                        List<PirApprovalList> currentApproverList = (List<PirApprovalList>)await _unitOfWork.PirApprovalList.GetAllAsync(x =>
                        x.PirId.Equals(PIRId) &&
                        x.Seq.Equals(pirObj.CurrentApprovalSeq) &&
                        x.Status.Equals(PIRApprovalStatus.UnderApproval) &&
                        x.ActionRequiredBy != null);

                        if (currentApproverList != null)
                        {
                           

                            emailSendConfigDTO.toRecipients = new List<string>();
                            foreach (PirApprovalList cpl in currentApproverList)
                            {
                                var fpEmail = await _commonService.GetEmailBymuNO(cpl.ActionRequiredBy);
                                emailSendConfigDTO.toRecipients.Add(fpEmail);
                            }

                            emailSendConfigDTO.ccRecipients = new List<string>();
                            foreach (AllPDOUsersDTO Mfp in pirObj.MandatoryTP)
                            {
                                var MfpEmail = await _commonService.GetEmailBymuNO(Mfp.PERSONNEL_NUMBER);
                                emailSendConfigDTO.ccRecipients.Add(MfpEmail);
                            }

                            var UctFpEmail = await _commonService.GetEmailBymuNO(pirObj.UctFp);
                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);


                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                await MapPirForEmail(res, PIRId, pirObj, TemplateCode);

                        }
                    }
                    else if (TemplateCode.Equals("PIR008")) //UCT Rejected
                    {

                        emailSendConfigDTO.toRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Mfp in pirObj.MandatoryTP)
                        {
                            var MfpEmail = await _commonService.GetEmailBymuNO(Mfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(MfpEmail);
                        }

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Otfp in pirObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }
                        var fpEmail = await _commonService.GetEmailBymuNO(pirObj.UctFp);
                        emailSendConfigDTO.toRecipients.Add(fpEmail);
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapPirForEmail(res, PIRId, pirObj, TemplateCode, Comment);
                    }
                    else if (TemplateCode.Equals("PIR009")) //Sentback from Approver
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Mfp in pirObj.MandatoryTP)
                        {
                            var MfpEmail = await _commonService.GetEmailBymuNO(Mfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(MfpEmail);
                        }

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        var UctFpEmail = await _commonService.GetEmailBymuNO(pirObj.UctFp);
                        emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                        if (employee != null)
                        {
                            emailSendConfigDTO.ccRecipients.Add(employee.EMAIL_ADDRESS);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapPirForEmail(res, PIRId, pirObj, TemplateCode, Comment);
                    }
                    else if (TemplateCode.Equals("PIR011") || TemplateCode.Equals("PIR011N")) //Approved Email //N means new Seq 
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Mfp in pirObj.MandatoryTP)
                        {
                            var MfpEmail = await _commonService.GetEmailBymuNO(Mfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(MfpEmail);
                        }

                        var UctFpEmail = await _commonService.GetEmailBymuNO(pirObj.UctFp);
                        emailSendConfigDTO.toRecipients.Add(UctFpEmail);

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        if (employee != null)
                        {
                            emailSendConfigDTO.ccRecipients.Add(employee.EMAIL_ADDRESS);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);



                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapPirForEmail(res, PIRId, pirObj, TemplateCode);

                    }
                    else if (TemplateCode.Equals("PIR012")) //Fully Approved
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Mfp in pirObj.MandatoryTP)
                        {
                            var MfpEmail = await _commonService.GetEmailBymuNO(Mfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(MfpEmail);
                        }

                        var UctFpEmail = await _commonService.GetEmailBymuNO(pirObj.UctFp);
                        emailSendConfigDTO.toRecipients.Add(UctFpEmail);
                        emailSendConfigDTO.ccRecipients = new List<string>();
                        if (employee != null)
                        {
                            emailSendConfigDTO.ccRecipients.Add(employee.EMAIL_ADDRESS);
                        }
                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapPirForEmail(res, PIRId, pirObj, TemplateCode);
                    }



                }

            }


            return 0;

        }

        public async Task<bool> MapPirForEmail(EmailSendConfigDTO emailSendConfigDTO, long PirId, PirEmailDTO ctrObj, string TemplateCode, string Comment = "")
        {
            string host = _configuration["TIPApplicationPath"];

            if (!string.IsNullOrEmpty(ctrObj.OldUctFpName))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", ctrObj.OldUctFpName);
            }
            if (!string.IsNullOrEmpty(ctrObj.OldMandatoryFpName))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$MTrailFpName", ctrObj.OldMandatoryFpName);
            }
            if (!string.IsNullOrEmpty(ctrObj.NewMandatoryFpName))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$MTrailFpName", ctrObj.NewMandatoryFpName);
            }

            if (!string.IsNullOrEmpty(ctrObj.DeletedApproverName))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ApproverName", ctrObj.DeletedApproverName);
            }
            if (!string.IsNullOrEmpty(ctrObj.ApproverName))
            {
                emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ApproverName", ctrObj.ApproverName);
            }

            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$MTrailFpNames", (ctrObj.MandatoryTP != null && ctrObj.MandatoryTP.Count > 0) ? string.Join(" ; ", ctrObj.MandatoryTP.Select(x => x.USER_DISPLAY)) : "None");
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$OTrialFpNames", (ctrObj.OtherTP != null && ctrObj.OtherTP.Count > 0) ? string.Join(" ; ", ctrObj.OtherTP.Select(x => x.USER_DISPLAY)) : "None");

            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ReferenceNo", ctrObj.ReferenceNumber);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$UCTFPName", ctrObj.UctFpName);

            
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ApproverNames", string.Join(" ; ", ctrObj.CurrentApprovers.Select(x => x.USER_DISPLAY)));
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ApproverName", ctrObj.ApproverName);

            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Reason", Comment);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SentBackDate", ctrObj.SentbackDate);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$RejectionDate", ctrObj.UpdatedOn);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$SubmissionDate", ctrObj.SubmissionDate);

            if (TemplateCode.Equals("PIR001"))
            {
                string link = host + "/#/tmct/manage-pir?r_c=TP";
                link = link + "&s=" + ctrObj.ReferenceNumber;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view PIRS's to be Completed : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("PIR002") || TemplateCode.Equals("PIR003"))
            {
                string link = host + "/#/tmct/review-pir?r_c=UCT";
                link = link + "&s=" + ctrObj.ReferenceNumber;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view submitted PIR's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("PIR004"))
            {
                string link = host + "/#/tmct/review-pir?r_c=UCT";
                link = link + "&s=" + ctrObj.ReferenceNumber;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view submitted PIR's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("PIR005"))
            {
                string link = host + "/#/tmct/manage-pir?r_c=TP";
                link = link + "&s=" + ctrObj.ReferenceNumber;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view PIR's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("PIR006"))
            {
                string link = host + "/#/tmct/manage-pir?r_c=TP";
                link = link + "&s=" + ctrObj.ReferenceNumber;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view PIR's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("PIR007"))
            {
                string link = host + "/#/tmct/approve-pir?r_c=PIRA";
                link = link + "&s=" + ctrObj.ReferenceNumber;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view all PIR's waiting for your approval : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("PIR008"))
            {
                // No Link for Rejection, since no place to see.
            }
            if (TemplateCode.Equals("PIR009"))
            {
                string link = host + "/#/tmct/manage-pir?r_c=TP";
                link = link + "&s=" + ctrObj.ReferenceNumber;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view PIR's : " + "<a href='" + link + "'>Link</a>";
                }
            }
            if (TemplateCode.Equals("PIR011") || TemplateCode.Equals("PIR011N"))
            {
                // No Link for partially approved.
            }
            if (TemplateCode.Equals("PIR012"))
            {
                // No Link for fully approved.
            }
            if (TemplateCode.Equals("PIR019"))
            {
                string link = host + "/#/tmct/approve-pir?r_c=PIRA";
                link = link + "&s=" + ctrObj.ReferenceNumber;
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view all PIR's waiting for your approval : " + "<a href='" + link + "'>Link</a>";
                }
            }
            return await _commonService.SendEmail(emailSendConfigDTO);
        }

        public async Task<long> SendReassignEmail(long PIRId, string Module, string TemplateCode, string newdataset, string olddataset, string changedby)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {
                    PirEmailDTO pirObj = await _unitOfWork.Pir.GetEmailData(PIRId, TemplateCode);


                    EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                    emailSendConfigDTO.moduleId = EmailModule.id;
                    emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                    if (TemplateCode.Equals("PIR013")) // New UCT
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        var newUCT = await _commonService.GetEmailBymuNO(newdataset);
                        emailSendConfigDTO.toRecipients.Add(newUCT);

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapPirForEmail(res, PIRId, pirObj, TemplateCode);
                    }
                    if (TemplateCode.Equals("PIR014")) // OLD UCT
                    {
                        var olduct = await _unitOfWork.Employee.GetByMuNumber(olddataset);

                        if (olduct != null)
                        {
                            pirObj.OldUctFpName = olduct.DISPLAY_NAME;
                            emailSendConfigDTO.toRecipients = new List<string>();
                            var OldUCT = await _commonService.GetEmailBymuNO(olddataset);
                            emailSendConfigDTO.toRecipients.Add(OldUCT);

                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                await MapPirForEmail(res, PIRId, pirObj, TemplateCode);
                        }
                    }
                    if (TemplateCode.Equals("PIR015")) // Mandatory FP Changed - New Mandatory Email
                    {

                        var newmfp =  await _unitOfWork.Employee.GetByMuNumber(newdataset);

                        emailSendConfigDTO.toRecipients = new List<string>();
                        var newMFp = await _commonService.GetEmailBymuNO(newdataset);
                        emailSendConfigDTO.toRecipients.Add(newMFp);

                        pirObj.NewMandatoryFpName = newmfp.DISPLAY_NAME;

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Otfp in pirObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapPirForEmail(res, PIRId, pirObj, TemplateCode);
                    }
                    if (TemplateCode.Equals("PIR016")) // Mandatory FP Changed - Old Mandatory Email
                    {
                        var oldmfp = await _unitOfWork.Employee.GetByMuNumber(olddataset);

                        if (oldmfp != null)
                        {
                            pirObj.OldMandatoryFpName = oldmfp.DISPLAY_NAME;
                            emailSendConfigDTO.toRecipients = new List<string>();
                            var oldMFp = await _commonService.GetEmailBymuNO(olddataset);
                            emailSendConfigDTO.toRecipients.Add(oldMFp);

                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                await MapPirForEmail(res, PIRId, pirObj, TemplateCode);
                        }
                    }
                    if (TemplateCode.Equals("PIR017")) // Other Focal Point changed
                    {
                        emailSendConfigDTO.toRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Mfp in pirObj.MandatoryTP)
                        {
                            var newMFp = await _commonService.GetEmailBymuNO(Mfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.toRecipients.Add(newMFp);
                        }

                        emailSendConfigDTO.ccRecipients = new List<string>();
                        foreach (AllPDOUsersDTO Otfp in pirObj.OtherTP)
                        {
                            var ofpEmail = await _commonService.GetEmailBymuNO(Otfp.PERSONNEL_NUMBER);
                            emailSendConfigDTO.ccRecipients.Add(ofpEmail);
                        }

                        EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                        if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                            await MapPirForEmail(res, PIRId, pirObj, TemplateCode);
                    }
                    if (TemplateCode.Equals("PIR018")) // Approver Deleted
                    {
                        var DeletedApproverName = await _unitOfWork.Employee.GetByMuNumber(olddataset);
                        if (DeletedApproverName != null)
                        {
                            pirObj.DeletedApproverName = DeletedApproverName.DISPLAY_NAME;

                            emailSendConfigDTO.toRecipients = new List<string>();
                            var deletingUser = await _commonService.GetEmailBymuNO(olddataset);
                            emailSendConfigDTO.toRecipients.Add(deletingUser);

                            emailSendConfigDTO.ccRecipients = new List<string>();

                            foreach (AllPDOUsersDTO Mfp in pirObj.MandatoryTP)
                            {
                                var newMFp = await _commonService.GetEmailBymuNO(Mfp.PERSONNEL_NUMBER);
                                emailSendConfigDTO.toRecipients.Add(newMFp);
                            }

                            var UctFp = await _commonService.GetEmailBymuNO(pirObj.UctFp);
                            emailSendConfigDTO.ccRecipients.Add(UctFp);

                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                await MapPirForEmail(res, PIRId, pirObj, TemplateCode);
                        }
                    }
                    if (TemplateCode.Equals("PIR019")) // Approver Added or Updated Seq 
                    {
                        var ApproverName = await _unitOfWork.Employee.GetByMuNumber(newdataset);
                        if (ApproverName != null)
                        {
                            pirObj.ApproverName = ApproverName.DISPLAY_NAME;

                            emailSendConfigDTO.toRecipients = new List<string>();
                            var deletingUser = await _commonService.GetEmailBymuNO(newdataset);
                            emailSendConfigDTO.toRecipients.Add(deletingUser);

                            emailSendConfigDTO.ccRecipients = new List<string>();
                            foreach (AllPDOUsersDTO Mfp in pirObj.MandatoryTP)
                            {
                                var newMFp = await _commonService.GetEmailBymuNO(Mfp.PERSONNEL_NUMBER);
                                emailSendConfigDTO.ccRecipients.Add(newMFp);
                            }

                            var UctFpEmail = await _commonService.GetEmailBymuNO(pirObj.UctFp);
                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);

                            EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                            if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                await MapPirForEmail(res, PIRId, pirObj, TemplateCode);
                        }
                    }

                }

            }

            return 0;
        }

        #endregion

        #region Workflow

        public async Task<List<PirApprovalListDTO>> GetAllApprovalListByPirId(long PirId)
        {
            return await _unitOfWork.PirApprovalList.GetAllApprovalListByPirId(PirId);
        }

        public async Task<bool> AddDefaultApprovalList(List<PirApprovalList> lst)
        {
            try
            {
                foreach (var item in lst)
                {
                    item.Id = 0;
                }
                await _unitOfWork.PirApprovalList.AddRangeAsync(lst);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return true;// or Id if table id exist
                }
                return false;


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PirApprovalListDTO> GetApprovalListFormData(long Id)
        {
            return await _unitOfWork.PirApprovalList.GetApprovalListFormData(Id);
        }

        public async Task<PirApprovalList> GetApprovalListById(long Id)
        {
            return await _unitOfWork.PirApprovalList.GetAsync(Id);
        }

        public async Task<long> UpdateApprovalList(PirApprovalList DTO)
        {
            try
            {
                _unitOfWork.PirApprovalList.Update(DTO);
                long result = await _unitOfWork.SaveAsync();

                if (result > 0)
                {
                    return DTO.Id;// or Id if table id exist
                }
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> UpdateApprovalList(List<PirApprovalList> list)
        {
            try
            {
                _unitOfWork.PirApprovalList.UpdateRange(list);
                long result = await _unitOfWork.SaveAsync();
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> AddPirApprovalList(PirApprovalList obj)
        {
            try
            {
                obj.Id = 0;
                await _unitOfWork.PirApprovalList.AddAsync(obj);
                long result = await _unitOfWork.SaveAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeletePirApprovalList(long id)
        {
            try
            {
                var DefaultJobCodes = new string[] { "HNT", "LM", "TL", "CFDH", "DCO" };

                PirApprovalList obj = null;
                obj = await _unitOfWork.PirApprovalList.GetFirstOrDefaultAsync(x => x.Id.Equals(id));
                if (obj != null)
                {
                    if (DefaultJobCodes.Contains(obj.JobCode))
                    {
                        obj.Seq = 0;
                        obj.ActionRequiredBy = null;
                        obj.Status = PIRApprovalStatus.Drafted;
                        obj.ActionAssingedDate = null;
                        obj.ActionCompletionDate = null;
                        obj.Comments = "";
                        _unitOfWork.PirApprovalList.Update(obj);

                    }
                    else
                    {
                        _unitOfWork.PirApprovalList.Remove(obj);
                    }

                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> ResetPirApproval(long PirId)
        {
            List<PirApprovalList> pirApprovalList = (List<PirApprovalList>?)await _unitOfWork.PirApprovalList.GetAllAsync(a => a.PirId.Equals(PirId));
            List<PirApprovalListHsty> pirApprovalListHsties = new List<PirApprovalListHsty>();


            if (pirApprovalList != null)
            {
                List<PirApprovalListHsty> checkVersion = (List<PirApprovalListHsty>)await _unitOfWork.PirApprovalListHis.GetAllAsync(a => a.PirId.Equals(PirId));
                long version = checkVersion.DistinctBy(x => x.Version).Count();

                foreach (PirApprovalList obj in pirApprovalList)
                {
                    PirApprovalListHsty newobj = new PirApprovalListHsty()
                    {
                        Id = 0,
                        PirId = obj.PirId,
                        JobTitle = obj.JobTitle,
                        JobCode = obj.JobCode,
                        Seq = obj.Seq,
                        Comments = obj.Comments,
                        ActionAssingedDate = obj.ActionAssingedDate,
                        ActionCompletionDate = obj.ActionCompletionDate,
                        CreatedBy = obj.CreatedBy,
                        CreatedByRef = obj.CreatedByRef,
                        CreatedOn = obj.CreatedOn,
                        HistoryCreatedOn = DateTime.Now,
                        Status = obj.Status,
                        Version = version + 1,
                    };
                    pirApprovalListHsties.Add(newobj);
                }
                if (pirApprovalListHsties.Any())
                {
                    await _unitOfWork.PirApprovalListHis.AddRangeAsync(pirApprovalListHsties);
                    long result = await _unitOfWork.SaveAsync();
                    _unitOfWork.PirApprovalList.RemoveRange(pirApprovalList);
                    result = await _unitOfWork.SaveAsync();
                    return result;
                }
            }
            return 0;
        }

        public async Task<long> UpdatePirAprovalList(long PirId, long CurrentApprovalSeq, bool firstRoundofApprovals)
        {
            try
            {
                List<PirApprovalList> lst = (List<PirApprovalList>)await _unitOfWork.PirApprovalList.GetAllAsync(x => x.PirId.Equals(PirId) && x.Seq > 0 && x.ActionRequiredBy != null);
                if (lst != null)
                {
                    if (firstRoundofApprovals)
                    {
                        lst.Where(z => z.Seq.Equals(1)).ToList().ForEach(z => z.ActionAssingedDate = DateTime.Now);
                        lst.ForEach(z => z.Status = PIRApprovalStatus.UnderApproval);
                    }
                    else
                    {
                        
                        lst.Where(z => z.Seq.Equals(CurrentApprovalSeq) && z.Status.Equals(PIRApprovalStatus.SentBack)).ToList()
                            .ForEach((z) =>
                            {
                                z.ActionCompletionDate = null;
                                z.Status = PIRApprovalStatus.UnderApproval;
                                z.ActionAssingedDate = DateTime.Now;
                                z.Comments = "";
                            });
                    }

                    _unitOfWork.PirApprovalList.UpdateRange(lst);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<PirApprovalList> GetApprovalListBySeq(long Seq, long PirId, string CompanyNumber)
        {
            return await _unitOfWork.PirApprovalList.GetFirstOrDefaultAsync(x => x.Seq.Equals(Seq) && x.PirId.Equals(PirId) && x.ActionRequiredBy.Equals(CompanyNumber));
        }

        public async Task<List<PirApprovalList>> GetApprovalListBySeq(long Seq, long PirId)
        {
            return (List<PirApprovalList>)await _unitOfWork.PirApprovalList.GetAllAsync(x => x.Seq.Equals(Seq) && x.PirId.Equals(PirId));
        }
        public async Task<List<PirApprovalList>> GetApprovalListsByPirId(long PirId)
        {
            return (List<PirApprovalList>)await _unitOfWork.PirApprovalList.GetAllAsync(x => x.PirId.Equals(PirId));
        }

        #endregion

        #region Reassignment 

        public async Task<List<ApprovedCtrDTO>> GetAllPirforReAssignmentAdmin(string CompanyNumber)
        {
            return await _unitOfWork.Pir.GetAllPirforReAssignmentAdmin(CompanyNumber);
        }
        public async Task<List<ApprovedCtrDTO>> GetAllPirforReAssignmentUCT(string CompanyNumber)
        {
            return await _unitOfWork.Pir.GetAllPirforReAssignmentUCT(CompanyNumber);
        }

        public async Task<List<PirTrialFp>> GetAllPirTrialFpbyPirId(long PirId)
        {
            try
            {
                return (List<PirTrialFp>)await _unitOfWork.PirTrialFp.GetAllAsync(x => x.PirId.Equals(PirId));

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region PIR Reminder
        public async Task<long> SendReminderEmails(string Module, string TemplateCode)
        {
            TypeCodeMasterDTO EmailModule = await _unitOfWork.TypeCodeMaster.GetDataByType(TypeCodes.EmailTemplate, Module);
            if (EmailModule != null)
            {
                EmailTemplateConfiguration Template = await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplatebyTemplateCode(EmailModule.id, TemplateCode);
                if (Template != null)
                {


                    if (TemplateCode.Equals("PIR004")) // Weekly Reminder when PIR is with New Technology Advisor 
                    {
                        var WeeklyReminderList = await _unitOfWork.Pir.ReminderWhenPIRwithUCT();
                        if (WeeklyReminderList != null && WeeklyReminderList.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (PirApprovalReminderDTO pirApproval in WeeklyReminderList)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                var ReminderUser = await _commonService.GetEmailBymuNO(pirApproval.UctFp);
                                emailSendConfigDTO.toRecipients.Add(ReminderUser);

                               // Email Escalation Start
                                DateTime submittedDate = pirApproval.SubmittedOn.Value;
                                DateTime today = DateTime.Today;

                                // Calculate the time elapsed between submitted date and today
                                TimeSpan timeElapsed = today - submittedDate;

                                // Set the interval between emails in days
                                long emailIntervalDays = await _unitOfWork.EmailEscalation.getEmailEscDays("PIR004");

                                // Calculate the number of occurrences that have happened so far
                                long occurrences = (long)(timeElapsed.TotalDays / emailIntervalDays) + 1;

                                // Set the threshold for escalation
                                long escalationThreshold = await _unitOfWork.EmailEscalation.getEmailEscOccurunces("PIR004");

                                // Check if escalation email should be sent
                                if (escalationThreshold > 0 && occurrences > escalationThreshold)
                                {
                                    // Send escalation email
                                    if (pirApproval.LastReminder != null && _configuration["ServerMode"] == "Prod")
                                    {
                                        var UctFp = await _unitOfWork.Employee.GetByMuNumber(pirApproval.UctFp);
                                        if (UctFp != null && UctFp.SUPERVISOR_ID != null)
                                        {
                                            emailSendConfigDTO.ccRecipients = new List<string>();
                                            var UctFpEmail = await _commonService.GetEmailBymuNO(UctFp.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                                        }
                                    }
                                }

                                PirEmailDTO pirObj = await _unitOfWork.Pir.GetEmailData(pirApproval.PirId, TemplateCode);

                                EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                {
                                    var emailResult = await MapPirForEmail(res, pirApproval.PirId, pirObj, TemplateCode);
                                    if (emailResult)
                                    {
                                        PirInitiation updateItem = await _unitOfWork.Pir.GetAsync(pirApproval.PirId);
                                        updateItem.LastReminder = DateTime.Now.Date;
                                        _unitOfWork.Pir.Update(updateItem);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                    if (TemplateCode.Equals("PIR006")) // Weekly Reminder when PIR is with Trial Focal Point
                    {
                        var WeeklyReminderList = await _unitOfWork.Pir.ReminderWhenPIRwithTFP();
                        if (WeeklyReminderList != null && WeeklyReminderList.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (PirApprovalReminderDTO pirApproval in WeeklyReminderList)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                var ReminderUser = await _commonService.GetEmailBymuNO(pirApproval.MandatoryFp);
                                emailSendConfigDTO.toRecipients.Add(ReminderUser);

                                // Email Escalation Start
                                DateTime sentbackOn = pirApproval.SentbackOn.Value;
                                DateTime today = DateTime.Today;

                                // Calculate the time elapsed between sentback date and today
                                TimeSpan timeElapsed = today - sentbackOn;


                                // Set the interval between emails in days
                                long emailIntervalDays = await _unitOfWork.EmailEscalation.getEmailEscDays("PIR006");

                                // Calculate the number of occurrences that have happened so far
                                long occurrences = (long)(timeElapsed.TotalDays / emailIntervalDays) + 1;

                                // Set the threshold for escalation
                                long escalationThreshold = await _unitOfWork.EmailEscalation.getEmailEscOccurunces("PIR006");

                                // Check if escalation email should be sent
                                if (escalationThreshold > 0 && occurrences > escalationThreshold)
                                {
                                    //Escalation 
                                    if (pirApproval.LastReminder != null && _configuration["ServerMode"] == "Prod")
                                    {
                                        var UctFp = await _unitOfWork.Employee.GetByMuNumber(pirApproval.MandatoryFp);
                                        if (UctFp != null && UctFp.SUPERVISOR_ID != null)
                                        {
                                            emailSendConfigDTO.ccRecipients = new List<string>();
                                            var UctFpEmail = await _commonService.GetEmailBymuNO(UctFp.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(UctFpEmail);
                                        }
                                    }
                                }

                                

                                PirEmailDTO pirObj = await _unitOfWork.Pir.GetEmailData(pirApproval.PirId, TemplateCode);

                                EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                {
                                    var emailResult = await MapPirForEmail(res, pirApproval.PirId, pirObj, TemplateCode);
                                    if (emailResult)
                                    {
                                        PirInitiation updateItem = await _unitOfWork.Pir.GetAsync(pirApproval.PirId);
                                        updateItem.LastReminder = DateTime.Now.Date;
                                        _unitOfWork.Pir.Update(updateItem);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                    if (TemplateCode.Equals("PIR010")) // Daily Reminder for approver, if not approved
                    {
                        var DailyReminderList = await _unitOfWork.PirApprovalList.ReminderEmailForApprovers();
                        if (DailyReminderList != null && DailyReminderList.Count > 0)
                        {
                            EmailSendConfigDTO emailSendConfigDTO = new EmailSendConfigDTO();
                            emailSendConfigDTO.moduleId = EmailModule.id;
                            emailSendConfigDTO.templateId = Template.UniqueTemplateId;

                            foreach (PirApprovalReminderDTO pirApproval in DailyReminderList)
                            {
                                emailSendConfigDTO.toRecipients = new List<string>();
                                var ReminderUser = await _commonService.GetEmailBymuNO(pirApproval.Approver);
                                emailSendConfigDTO.toRecipients.Add(ReminderUser);

                                emailSendConfigDTO.ccRecipients = new List<string>();
                                var UctFpEmail = await _commonService.GetEmailBymuNO(pirApproval.UctFp);
                                emailSendConfigDTO.ccRecipients.Add(UctFpEmail);

                                // Email Escalation Start
                                DateTime ActionAssingedDate = pirApproval.ActionAssingedDate.Value;
                                DateTime today = DateTime.Today;

                                // Calculate the time elapsed between Action Assinged date and today
                                TimeSpan timeElapsed = today - ActionAssingedDate;


                                // Set the interval between emails in days
                                long emailIntervalDays = await _unitOfWork.EmailEscalation.getEmailEscDays("PIR010");

                                // Calculate the number of occurrences that have happened so far
                                long occurrences = (long)(timeElapsed.TotalDays / emailIntervalDays) + 1;

                                // Set the threshold for escalation
                                long escalationThreshold = await _unitOfWork.EmailEscalation.getEmailEscOccurunces("PIR010");

                                // Check if escalation email should be sent
                                if (escalationThreshold > 0 && occurrences > escalationThreshold)
                                {
                                    //Escalation 
                                    if (pirApproval.LastReminder != null && _configuration["ServerMode"] == "Prod")
                                    {
                                        var supervisor = await _unitOfWork.Employee.GetByMuNumber(pirApproval.Approver);
                                        if (supervisor != null && supervisor.SUPERVISOR_ID != null)
                                        {
                                            var supervisorEmail = await _commonService.GetEmailBymuNO(supervisor.SUPERVISOR_ID);
                                            emailSendConfigDTO.ccRecipients.Add(supervisorEmail);
                                        }
                                    }
                                }

                                EmailSendConfigDTO res = await _commonService.GenericEmailTemplateBaseInfo(emailSendConfigDTO);

                                var ApproverName = await _unitOfWork.Employee.GetByMuNumber(pirApproval.Approver);
                                pirApproval.ApproverName = ApproverName.DISPLAY_NAME;

                                if (res.keywords.Count > 0 && !string.IsNullOrEmpty(res.body))
                                {
                                    var emailResult = await MapPIRForReminderEmail(res, pirApproval.PirId, pirApproval, TemplateCode);
                                    if (emailResult)
                                    {
                                        PirApprovalList updateItem = await _unitOfWork.PirApprovalList.GetAsync(pirApproval.Id);
                                        updateItem.LastReminder = DateTime.Now.Date;
                                        _unitOfWork.PirApprovalList.Update(updateItem);
                                        await _unitOfWork.SaveAsync();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return 0;
        }

        public async Task<bool> MapPIRForReminderEmail(EmailSendConfigDTO emailSendConfigDTO, long PirId, PirApprovalReminderDTO pirApproval, string TemplateCode, string Comment = "")
        {
            string host = _configuration["TIPApplicationPath"];


            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ReferenceNo", pirApproval.ReferenceNumber);
            emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$ApproverName", pirApproval.ApproverName);

            if (TemplateCode.Equals("PIR010"))
            {
                string link = host + "/#/tmct/approve-pir?r_c=PIRA";
                if (emailSendConfigDTO.body.Contains("$$Link"))
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body.Replace("$$Link", "<a href='" + link + "'>Link</a>");
                }
                else
                {
                    emailSendConfigDTO.body = emailSendConfigDTO.body + "<br>Please click on the link below to view all PIR's waiting for your approval : " + "<a href='" + link + "'>Link</a>";
                }
            }

            return await _commonService.SendEmail(emailSendConfigDTO);
        }
        #endregion

		public async Task<PrintDTO> GetPirPrint(long Id, long roleid, string CompanyNumber, string docType)
		{
			try
			{
				var id = Id;
				var RoleId = roleid;                               
                List<PirGeneralInformationDTO> general = new List<PirGeneralInformationDTO>();
				general.Add(await _unitOfWork.Pir.GetPirData(id, RoleId, CompanyNumber));
                List<PirTrialDetailsDTO> trialDetail = new List<PirTrialDetailsDTO>();
				trialDetail.Add(await _unitOfWork.Pir.GetPirTrialDetailsData(id, RoleId, CompanyNumber));
                List<PirSummaryDTO> summary = new List<PirSummaryDTO>();
				summary.Add(await _unitOfWork.PirSummary.GetPirSummary(id));
                var trialCandidate = await _unitOfWork.PirTrialCandidate.GetAllTrialCandidates(id, RoleId, CompanyNumber);
                var trialResult = await _unitOfWork.PirAssessmentTrialResult.GetAllAssessmentTrialResults(id, RoleId, CompanyNumber);
                var learnt = await _unitOfWork.PirLessonLearnt.GetAllLessonLearnt(id, RoleId, CompanyNumber);
                var impact = await _unitOfWork.PirImpactedExistingContract.GetAllContracts(id, RoleId, CompanyNumber);
                var deploy = await _unitOfWork.PirDeploymentStaircase.GetAllDeploymentStaircase(id, RoleId, CompanyNumber);
				var GetAllFilesByLinkId = await _commonService.GetAllFilesById(id, "PIR Form", false);
				var AllFlowHistory = await _unitOfWork.PirApprovalList.GetApproverListByPir(id);

				Dictionary<string, string> parameters = new Dictionary<string, string>();				
				Warning[] warnings;
				string[] streamIds;
				string mimeType = string.Empty;
				string encoding = string.Empty;
				string filetype = string.Empty;
				string fileName = string.Format("{0}.{1}", "PIR Number" + DateTime.Now.Ticks.ToString(), PrintType.doc.ToString());
																																   
				LocalReport localReport = new LocalReport();
				Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
				Encoding.GetEncoding("windows-1252");
				string fileDirPath = Assembly.GetExecutingAssembly().Location.Replace("TIP_BAL.dll", string.Empty);
				string rdlcFilePath = string.Format("{0}RDLC\\{1}.rdlc", fileDirPath, "PIRPrint");
				
                localReport.ReportPath = rdlcFilePath;				
				localReport.DataSources.Add(new ReportDataSource() { Name = "PIRGeneral", Value = general });
				localReport.DataSources.Add(new ReportDataSource() { Name = "PIRTrialDetail", Value = trialDetail });
				localReport.DataSources.Add(new ReportDataSource() { Name = "PIRSummary", Value = summary });
				localReport.DataSources.Add(new ReportDataSource() { Name = "PIRTrialCandidate", Value = trialCandidate});
				localReport.DataSources.Add(new ReportDataSource() { Name = "PIRTrialResult", Value = trialResult });
				localReport.DataSources.Add(new ReportDataSource() { Name = "PIRLearnt", Value = learnt });
				localReport.DataSources.Add(new ReportDataSource() { Name = "PIRImpact", Value = impact });
				localReport.DataSources.Add(new ReportDataSource() { Name = "PIRDeploy", Value = deploy });
				localReport.DataSources.Add(new ReportDataSource() { Name = "AllFilesByLinkId", Value = GetAllFilesByLinkId });
				localReport.DataSources.Add(new ReportDataSource() { Name = "AllFlowHistory", Value = AllFlowHistory });
				localReport.EnableExternalImages = true;
				localReport.EnableHyperlinks = true;
				localReport.Refresh();

				byte[] bytes = localReport.Render(docType, null, out mimeType, out encoding, out filetype, out streamIds, out warnings);
				return new PrintDTO { FileBytes = bytes, FileName = fileName, Type = mimeType };
			}
			catch (Exception ex)
			{
				throw ex;
			}

		}

        public async Task<List<PirApproverListDTO>> GetApproverListByPir(long Id)
        {
            return await _unitOfWork.PirApprovalList.GetApproverListByPir(Id);
        }

		public async Task<long> AddTrialCandidateFromCtr(long PirId, EmployeeDTO? LoggedInUser)
		{
			try
			{
				long result = 0;
				PirInitiation pir = await _unitOfWork.Pir.GetAsync(PirId);
                List<CtrTrialCandidateDTO>? lst = await _unitOfWork.CtrTrialCandidate.GetCtrTrialCandidate(pir.CtrId);
                List<PirTrialCandidate> newlst = new List<PirTrialCandidate>();

                if (lst != null && lst.Count > 0)
                {
                    foreach (CtrTrialCandidateDTO c in lst)
                    {
                        PirTrialCandidate newObj = new PirTrialCandidate()
                        {
                            Id = 0,
                            TypeId = c.TypeId,
                            Name = c.Name + " - Imported from TTA",
                            Cost = c.Cst,
                            CommencementDate = c.CommencementDate,
                            ConclusionDate = c.ConclusionDate,
                            PirId = PirId,
                            CreatedBy = LoggedInUser.COMPANY_NUMBER,
                            CreatedByRef = LoggedInUser.REFERENCE_INDICATOR,
                            CreatedOn = DateTime.Now
                        };
                        newlst.Add(newObj);
                    }
                }

                if (newlst != null && newlst.Any())
                {
                    await _unitOfWork.PirTrialCandidate.AddRangeAsync(newlst);
                    result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return result;
                    }
                }
                return result;

			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public async Task<List<ApprovedPirDTO>> GetApprovedPir(string CompanyNumber, long roleId)
        {
            return await _unitOfWork.Pir.GetApprovedPir(CompanyNumber, roleId);
		}

	}
}
