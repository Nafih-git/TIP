﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_BAL.Interface;
using TIP_CORE.Entities;

namespace TIP_BAL.Services
{
    public class ChallengeSolutionReviewersService : IChallengeSolutionReviewersService
    {
        private readonly IUnitOfWork _unitOfWork;
        public ChallengeSolutionReviewersService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<long> AddOrUpdateReviewers(List<ChallengeSolutionReviewer> challengeSolutionReviewers, bool isEdit)
        {
            try
            {
                if (challengeSolutionReviewers == null || challengeSolutionReviewers.Count == 0)
                    return 1;

                if (isEdit)
                    await DeleteExistingReviewers(challengeSolutionReviewers[0].ChallengeId, challengeSolutionReviewers[0].ChallengeDetailId);
                foreach (var reviewer in challengeSolutionReviewers)
                {
                    reviewer.Id = 0;
                }
                await _unitOfWork.ChallengeSolutionReviewers.AddRangeAsync(challengeSolutionReviewers);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;
                }

                return result;
            }
            catch
            {
                throw;
            }
        }

        public async Task<long> DeleteExistingReviewers(long challengeId, long challengeDetailId)
        {
            try
            {
                List<ChallengeSolutionReviewer> obj = null;
                obj = (List<ChallengeSolutionReviewer>)await _unitOfWork.ChallengeSolutionReviewers.GetAllAsync(x => x.ChallengeId == challengeId && x.ChallengeDetailId == challengeDetailId);
                if (obj.Count > 0 && obj != null)
                {
                    _unitOfWork.ChallengeSolutionReviewers.RemoveRange(obj);
                    long result = await _unitOfWork.SaveAsync();
                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
