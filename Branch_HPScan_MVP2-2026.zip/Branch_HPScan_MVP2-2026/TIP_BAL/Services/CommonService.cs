﻿using TIP_BusinessLogic.Interface;
using TIP_Common;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_BAL.Interface;
using TIP_BAL.Services;
using Microsoft.EntityFrameworkCore;
using TIP_Common.Enum;
using Microsoft.Reporting.NETCore;
using static TIP_Common.Enum.Enum;
using System.Reflection;
using System.Text;
using TIP_Core;
using Microsoft.AspNetCore.Http;
using System.Net.Sockets;
using System.Net;
using TIP_Common.Helpers;
using TIP_Common.Admin;

namespace TIP_BusinessLogic.Services
{
    public class CommonService : ICommonService
    {
        private readonly IUnitOfWork _unitOfWork;


        public CommonService(IUnitOfWork unitOfWork)
        {
            this._unitOfWork = unitOfWork;

        }

      
        public async Task<FileUploadDTO> GetFileById(long Id)
        {
            return await _unitOfWork.DocumentRepo.GetDocumentById(Id);
        }

        public async Task<List<FileUploadDTO>> GetAllFilesByLinkId(long linkId, string linktype, bool external)
        {
            return await _unitOfWork.DocumentRepo.GetDocumentsByLinkId(linkId, linktype, external);
        }

        public async Task<List<FileUploadDTO>> GetDocumentsByLinkType(string linkType)
        {
            return await _unitOfWork.DocumentRepo.GetDocumentsByLinkType(linkType);
        }
        public async Task<List<FileUploadDTO>> GetAllFilesById(long linkId, string linktype, bool external)
        {
            return await _unitOfWork.DocumentRepo.GetAllFilesById(linkId, linktype, external);
        }
        public async Task<List<TypeCodeMasterDTO>> GetMasterDataByType(string Type)
        {
            return await _unitOfWork.TypeCodeMaster.GetMasterDataByType(Type);
        }



        public async Task<List<TypeCodeMasterDTO>> GetAssetByMU(string Mu)
        {
            return await _unitOfWork.TypeCodeMaster.GetAssetByMU(Mu);
        }
        public async Task<List<TypeCodeMasterDTO>> GetClusterByAssetIdAndMU(long Assetid, string Mu)
        {
            return await _unitOfWork.TypeCodeMaster.GetClusterByAssetIdAndMU(Assetid,Mu);
        }
        public async Task<List<TypeCodeMasterDTO>> GetClusterByMU(EmployeeDTO employee, long assessmentid)
        {
            return await _unitOfWork.TypeCodeMaster.GetClusterByMU(employee,assessmentid);
        }
        public async Task<List<TypeCodeMasterDTO>> GetMasterDataByTypeInternal(string Type)
        {
            return await _unitOfWork.TypeCodeMaster.GetMasterDataByTypeInternal(Type);
        }
        public async Task<List<TypeCodeMasterDTO>> GetMasterDataByTypeConfiguration(string Type)
        {
            return await _unitOfWork.TypeCodeMaster.GetMasterDataByTypeConfiguration(Type);
        }


        public async Task<List<EmployeeDTO>> GetAllUsersByRole(string rolecode)
        {
            return await _unitOfWork.TypeCodeMaster.GetAllUsersByRole(rolecode);
        }
        public async Task<List<TypeCodeMasterDTO>> GetMasterDataByParentId(long pid)
        {
            return await _unitOfWork.TypeCodeMaster.GetMasterDataByParentId(pid);
        }
        public async Task<List<TypeCodeMasterDetailDTO>> GetMasterDataByParam2(string Param2)
        {
            return await _unitOfWork.TypeCodeMaster.GetMasterDataByParam2(Param2);
        }

        public async Task<List<TypeCodeMasterDetailDTO>> GetMasterDetailByType(string type)
        {
            return await _unitOfWork.TypeCodeMaster.GetMasterDetailByType(type);
        }


        public async Task<List<CtrTechConfigurationDTO>> GetCtrTechConfiguration()
        {
            return await _unitOfWork.TypeCodeMaster.GetCtrTechConfiguration();
        }
        public async Task<List<CTRPlanDetailsDTO>> GetCtrplandetailsByCtrID(long ctrId,string phase)
        {
            return await _unitOfWork.TypeCodeMaster.GetCtrplandetailsByCtrID(ctrId,phase);
        }
        public async Task<List<TechnologyKPIDTO>> GetTechKPIByYear(long year)
        {
            return await _unitOfWork.TypeCodeMaster.GetTechKPIByYear(year);
        }

        public async Task<long> AddTechKPI(List<TechnologyKpiConfig> kPIList)
        {
            try
            {
                await _unitOfWork.TechnologyKpiConfig.AddRangeAsync(kPIList);
                long result = await _unitOfWork.SaveAsync();
                return 1;
            }
            catch { return 0; }
        }

        public async Task<long> DeleteTechKPI(long year)
        {
            try
            {
                var obj = await _unitOfWork.TechnologyKpiConfig.GetAllAsync(x => x.Year == year);
                if (obj != null)
                {
                    _unitOfWork.TechnologyKpiConfig.RemoveRange(obj);
                    long result = await _unitOfWork.SaveAsync();
                    if (result > 0)
                    {
                        return result;// or Id if table id exist
                    }

                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<VTipTechnologyPlanDTO>> GetCtrViewplandetailsByCtrID(long ctrId)
        {
            return await _unitOfWork.TypeCodeMaster.GetCtrViewplandetailsByCtrID(ctrId);
        }


        public async Task<long> AddNewSubType(TypeCodeMaster typeCodeMaster)
        {
            try
            {
                if (typeCodeMaster == null)
                    throw new ArgumentException("Invalid sub type data.");

                if (string.IsNullOrWhiteSpace(typeCodeMaster.Name))
                    throw new ArgumentException("Name is required.");

                if (string.IsNullOrWhiteSpace(typeCodeMaster.Type))
                    throw new ArgumentException("Type is required.");

                await _unitOfWork.TypeCodeMaster.AddAsync(typeCodeMaster);
                await _unitOfWork.SaveAsync();
                return typeCodeMaster.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdateNewSubType(TypeCodeMaster typeCodeMaster)
        {
            try
            {
                TypeCodeMaster obj = null;
                obj = await _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Id == typeCodeMaster.Id);
                if (obj != null)
                {
                    obj.UpdatedBy = typeCodeMaster.UpdatedBy;
                    obj.UpdatedOn = typeCodeMaster.UpdatedOn;
                    obj.UpdatedByRef = typeCodeMaster.UpdatedByRef;
                    obj.Name = typeCodeMaster.Name;
                    obj.Description = typeCodeMaster.Description;                    
                    obj.ParentId = typeCodeMaster.ParentId;
                }
                _unitOfWork.TypeCodeMaster.Update(obj);
                await _unitOfWork.SaveAsync();
                return obj.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> DeleteSubType(long id, EmployeeDTO employeeDTO)
        {
            TypeCodeMaster obj = null;
            obj = await _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Id == id);
            if (obj != null)
            {
                obj.UpdatedBy = employeeDTO.COMPANY_NUMBER;
                obj.UpdatedByRef = employeeDTO.REFERENCE_INDICATOR;
                obj.UpdatedOn = DateTime.Now;
                obj.Status = "D";
            }
            _unitOfWork.TypeCodeMaster.Update(obj);
            await _unitOfWork.SaveAsync();
            return obj.Id;
        }

        public async Task<List<TypeCodeMasterDTO>> GetMasterDataByTypeAndParentID(string Type, int ParentID)
        {
            return await _unitOfWork.TypeCodeMaster.GetMasterDataByTypeAndParentID(Type, ParentID);
        }

        public async Task<List<RabitahContractDTO>> GetContractData()
        {
            return await _unitOfWork.TmRabitahContract.GetContractData();
        }

        public async Task<RabitahContractDTO> GetContractDataByContID(string contractID)
        {
            return await _unitOfWork.TmRabitahContract.GetContractDataByContID(contractID);
        }



        public async Task<TypeCodeMaster> GetMasterDataByParentAndParam1(string type, string param)
        {
            TypeCodeMaster typeCode = await _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(a => a.Type == type && a.Param1 == param);
            if (typeCode != null)
            {
                return typeCode;
            }
            return null;
        }

        public async Task<decimal> Log(UtlAuditTrail obj)
        {
            await _unitOfWork.AuditTrail.AddAsync(obj);
            await _unitOfWork.SaveAsync();
            return obj.Id;
        }



        public EmployeeDTO? GetIdentityOfLoggedInUser(string CompanyNumber)
        {
            try
            {
                //Check if MU only
                //var isNumeric = int.TryParse(CompanyNumber.ToUpper().Split("MU")[1], out int n);

                //if (isNumeric || CompanyNumber.Split("\\")[1].ToUpper().StartsWith("MUC"))
                //{
                   // EmployeeDTO? perso = _unitOfWork.UserRole.GetPerson(CompanyNumber.Split("\\")[1]);
                    EmployeeDTO? perso = _unitOfWork.UserRole.GetPerson(CompanyNumber.Split("\\")[1]);

                    return perso;
                //}
                //else
                //{
                //    return null;
                //}

            }
            catch
            {
                throw;
            }
        }

        public async Task<List<EmailKeywordDTO>> GetEmailKeywordByType(long id)
        {
            return await _unitOfWork.EmailKeyword.GetEmailKeywordByType(id);
        }

        public async Task<List<EmailTemplateConfigurationDTO>> GetEmailTemplateConfigByModule(long id)
        {
            return await _unitOfWork.EmailTemplateConfiguration.GetEmailTemplateConfigByModule(id);
        }

        public async Task<long> AddOrUpdateEmailTemplate(EmailTemplateConfiguration emailTemplateConfiguration)
        {
            try
            {
                EmailTemplateConfiguration obj = null;
                if (emailTemplateConfiguration.Id > 0)
                {
                    obj = await _unitOfWork.EmailTemplateConfiguration.GetFirstOrDefaultAsync(x => x.Id == emailTemplateConfiguration.Id);
                    if (obj != null)
                    {
                        obj.UpdatedBy = emailTemplateConfiguration.UpdatedBy;
                        obj.UpdatedOn = emailTemplateConfiguration.UpdatedOn;
                        obj.TemplateName = emailTemplateConfiguration.TemplateName;
                        obj.MailBody = emailTemplateConfiguration.MailBody;
                        obj.MailSubject = emailTemplateConfiguration.MailSubject;
                    }
                    _unitOfWork.EmailTemplateConfiguration.Update(obj);
                    await _unitOfWork.SaveAsync();
                    return obj.Id;
                }
                else
                {
                    await _unitOfWork.EmailTemplateConfiguration.AddAsync(emailTemplateConfiguration);
                    await _unitOfWork.SaveAsync();
                    return emailTemplateConfiguration.Id;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region  Document Upload / download  ~ Fazal, Rahim IDAP1X 
        public async Task<List<DocumentRepoDTO>> DocumentRepoList(long linkId, string linkType, bool external = false)
        {
            return await _unitOfWork.DocumentRepo.DocumentRepoList(linkId, linkType, external);
        }

        public async Task<DocumentRepoDTO> DocumentRepo(long id)
        {
            return await _unitOfWork.DocumentRepo.DocumentRepo(id);
        }
        #endregion

        #region Generic Email Integration Template Base ~ Fazal, Rahim IDAP1X
        public async Task<EmailSendConfigDTO> GenericEmailTemplateBaseInfo(EmailSendConfigDTO emailSendConfigDTO)
        {
            try
            {
                EmailTemplateConfiguration obj = null;
                obj = await _unitOfWork.EmailTemplateConfiguration.GetFirstOrDefaultAsync(x => x.ModuleId == emailSendConfigDTO.moduleId && x.UniqueTemplateId == emailSendConfigDTO.templateId);
                if (obj != null)
                {
                    emailSendConfigDTO.subject = obj.MailSubject;
                    emailSendConfigDTO.body = obj.MailBody;
                    emailSendConfigDTO.templateCode = obj.TemplateCode;
                }
                List<EmailKeyword> keywordObj = null;
                keywordObj = (List<EmailKeyword>)await _unitOfWork.EmailKeyword.GetAllAsync(x => x.ModuleId == emailSendConfigDTO.moduleId);
                if (keywordObj != null)
                    emailSendConfigDTO.keywords = keywordObj.Select(x => x.Keyword).ToList();

                return emailSendConfigDTO;
            }
            catch (Exception ex)
            {
                SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + $" | GenericEmailTemplateBaseInfo | ModuleId={emailSendConfigDTO?.moduleId} | TemplateId={emailSendConfigDTO?.templateId}",
                    "GenericEmailTemplateBaseInfo",
                    "CommonService",
                    "System",
                    string.Empty);
                throw;
            }
        }

        #endregion

        #region Generic method for Send Email ~ Fazal, Rahim IDAP1X

        private static bool IsLoginOtpOrForgotPasswordTemplate(EmailSendConfigDTO? emailSendConfigDTO)
        {
            if (emailSendConfigDTO == null || string.IsNullOrWhiteSpace(emailSendConfigDTO.templateCode))
                return false;

            return string.Equals(emailSendConfigDTO.templateCode, "EX001", StringComparison.OrdinalIgnoreCase)
                || string.Equals(emailSendConfigDTO.templateCode, "TMH005", StringComparison.OrdinalIgnoreCase);
        }

        public async Task<bool> SendEmail(EmailSendConfigDTO emailSendConfigDTO,EmployeeDTO? employee=null)
        {
            try
            {
                if (emailSendConfigDTO?.toRecipients == null || emailSendConfigDTO.toRecipients.Count == 0
                    || emailSendConfigDTO.toRecipients.All(string.IsNullOrWhiteSpace))
                {
                    SaveApplicationErrorLog(
                        "SendEmail aborted: no recipients.",
                        "SendEmail_NoRecipients",
                        "CommonService",
                        "System",
                        string.Empty);
                    return false;
                }

                if (string.IsNullOrWhiteSpace(emailSendConfigDTO.subject) || string.IsNullOrWhiteSpace(emailSendConfigDTO.body))
                {
                    SaveApplicationErrorLog(
                        $"SendEmail aborted: missing subject or body. | TemplateId={emailSendConfigDTO?.templateId} | To={string.Join(",", emailSendConfigDTO.toRecipients)}",
                        "SendEmail_MissingContent",
                        "CommonService",
                        "System",
                        string.Empty);
                    return false;
                }

                EmailRepo emailRepo = new EmailRepo();

                emailRepo.MailBody = emailSendConfigDTO.body;
                emailRepo.MailSubject = emailSendConfigDTO.subject;
                emailRepo.ToRecipients = string.Join(",", emailSendConfigDTO.toRecipients);

                if (emailSendConfigDTO.ccRecipients != null)
                {
                  if(employee!=null)
                    emailSendConfigDTO.ccRecipients.Add(employee.EMAIL_ADDRESS);
                    emailRepo.CcRecipients = string.Join(",", emailSendConfigDTO.ccRecipients);
                }
                else
                {
                    if(employee != null)
                        emailRepo.CcRecipients =employee.EMAIL_ADDRESS;
                }
                emailRepo.LoggedDate = DateTime.Now;
                emailRepo.EmailedDate = null;

                // Template may be missing for the given templateId — never call .Result on a null entity.
                var emailTemplate = await _unitOfWork.EmailTemplateConfiguration
                    .GetFirstOrDefaultAsync(x => x.UniqueTemplateId == emailSendConfigDTO.templateId
                        && x.ModuleId == emailSendConfigDTO.moduleId);
                bool canSend = emailTemplate != null && emailTemplate.IsActive == true;
                emailRepo.EmailedYn = canSend ? "N" : "S";
                if (!canSend)
                {
                    var recipientHintInactive = string.Join(",", emailSendConfigDTO.toRecipients);
                    SaveApplicationErrorLog(
                        $"SendEmail not queued for delivery (template missing or inactive). | TemplateId={emailSendConfigDTO.templateId} | ModuleId={emailSendConfigDTO.moduleId} | To={recipientHintInactive}",
                        "SendEmail_TemplateInactive",
                        "CommonService",
                        "System",
                        string.Empty);
                }

                emailRepo.Attachment = emailSendConfigDTO.attachment;
                emailRepo.AttachmentName = emailSendConfigDTO.attachmentname;
                emailRepo.ModuleId = emailSendConfigDTO.moduleId;
                emailRepo.TemplateId = emailSendConfigDTO.templateId;
                try
                {
                    await _unitOfWork.EmailRepo.AddAsync(emailRepo);
                    await _unitOfWork.SaveAsync();
                }
                catch (Exception persistEx)
                {
                    var recipientHintOnPersist = string.Join(",", emailSendConfigDTO.toRecipients);
                    SaveApplicationErrorLog(
                        ExtensionMethods.GetExceptionMessage(persistEx) + $" | SendEmail persist | TemplateId={emailSendConfigDTO?.templateId} | To={recipientHintOnPersist}",
                        "SendEmail_Persist",
                        "CommonService",
                        "System",
                        string.Empty);
                    throw;
                }

                if (canSend && IsLoginOtpOrForgotPasswordTemplate(emailSendConfigDTO))
                {
                    var recipientHintSuccess = string.Join(",", emailSendConfigDTO.toRecipients);
                    SaveApplicationErrorLog(
                        $"SendEmail queued successfully for Login OTP / Forgot Password processing. | TemplateCode={emailSendConfigDTO.templateCode} | TemplateId={emailSendConfigDTO.templateId} | ModuleId={emailSendConfigDTO.moduleId} | To={recipientHintSuccess} | EmailRepoId={emailRepo.Id}",
                        "SendEmail_Success",
                        "CommonService",
                        recipientHintSuccess,
                        string.Empty);
                }

                return canSend;
            }
            catch (Exception ex)
            {
                var recipientHint = emailSendConfigDTO?.toRecipients != null
                    ? string.Join(",", emailSendConfigDTO.toRecipients)
                    : string.Empty;
                SaveApplicationErrorLog(
                    ExtensionMethods.GetExceptionMessage(ex) + $" | TemplateId={emailSendConfigDTO?.templateId} | To={recipientHint}",
                    "SendEmail",
                    "CommonService",
                    "System",
                    string.Empty);
                return false;
            }
        }


      

        #endregion


        public async Task<IList<TaskRepoDTO>> GetAllTasksForUser(string CompanyNumber)
        {
            try
            {
                IEnumerable<TaskRepoDTO> list = _unitOfWork.TasksRepo.GetAllTasksForUser(CompanyNumber);
                if (list != null)
                {
                    return list.ToList();
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return null;
        }

        public async Task<PrecisedTaskReportMasterDTO> GetAllTasks(ActiionTaskRequestDTO requestdto)
        {
            try
            {
                return await _unitOfWork.TasksRepo.GetAllTasks(requestdto);

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return null;
        }
        public async Task<IList<PrecisedTaskDTO>> GetAllTasksCountForUser(EmployeeDTO employee)
        {
            try
            {
                IEnumerable<PrecisedTaskDTO> list = _unitOfWork.TasksRepo.GetAllTasksCountForUser(employee);
                if (list != null)
                {
                    return list.ToList();
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return null;
        }

        public async Task<long> AddTask(TaskRepo DTO)
        {

            try
            {
                await _unitOfWork.TasksRepo.AddAsync(DTO);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> AddDocument(DocumentRepo docRepo)
        {
            try
            {
                docRepo.Id = 0;
                await _unitOfWork.DocumentRepo.AddAsync(docRepo);
                long result = await _unitOfWork.SaveAsync();
                if (result > 0)
                {
                    return result;// or Id if table id exist
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> DeleteDocument(long LinkId, string Linktype)
        {
            try
            {
                var obj = await _unitOfWork.DocumentRepo.GetAllAsync(x => x.LinkId == LinkId && x.LimkType == Linktype);
                if (obj != null)
                {
                    _unitOfWork.DocumentRepo.RemoveRange(obj);
                    long result = await _unitOfWork.SaveAsync();
                    if (result > 0)
                    {
                        return result;// or Id if table id exist
                    }

                    return result;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<bool> CheckIfUserHasRole(long RoleId, string UserId)
        {
            try
            {
                TmRoleToUserMapping userRole = null;
                userRole = await _unitOfWork.RoleToUser.GetFirstOrDefaultAsync(t => t.RoleId == RoleId && t.UserId == UserId, isTracking: false);

                if (userRole != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<string> GetEmailBymuNO(string muNo)
        {
            var query = _unitOfWork.Employee.GetFirstOrDefaultAsync(x => x.CompanyNumber == muNo).Result.EmailAddress.ToString();
            return query;
        }
        public Task<TmEmployee> GetMuDetails(string muNo)
        {
            var query = _unitOfWork.Employee.GetFirstOrDefaultAsync(x => x.CompanyNumber == muNo);
            return query;
        }
        //
        public async Task<string> GetEmailByVendorCode(string vendorcode)
        {
            var query = _unitOfWork.RabitahVendor.GetFirstOrDefaultAsync(x => x.VendorCode == vendorcode).Result.VendorEmail.ToString();
            return query;
        }

        public async Task<FileUploadDTO> GetDDFormatPath()
        {
           
            try { return _unitOfWork.DocumentRepo.GetDocumentsByLinkType("TTA DD format").Result.FirstOrDefault(); }
            catch { return null; }
        }

        public async Task<List<DocumentRepoDTO>> GetDocumentsById(long id)
        {
            return await _unitOfWork.DocumentRepo.GetDocumentsById(id);
        }


        public async Task<FileUploadDTO> GetTTAFormatPath(long id)
        {
            
            try { return _unitOfWork.DocumentRepo.GetDocumentsByLinkId(id, "TTA", false).Result.FirstOrDefault(); }
            catch { return null; }
             
        }

		public async Task<List<DocLinkDTO>> GetDocLink()
        {
            return await _unitOfWork.DocLink.GetDocLink();
        }

        public async Task<TypeCodeMaster> CheckIfPaymentMilestone(long Id)
        {
            return await _unitOfWork.TypeCodeMaster.GetFirstOrDefaultAsync(x => x.Id == Id);

        }

		public async Task<List<EmailEscalationDTO>> GetAllEmailsData()
		{
			return await _unitOfWork.EmailEscalation.getAllEmailsData();
		}

        public async Task<TypeCodeMasterDetailDTO> GetMasterDataById(long Id)
        {
            return await _unitOfWork.TypeCodeMaster.GetMasterDataById(Id);
        }


        public async Task<long> UpdateEmailEsc(EmailEscalation emailEscalation)
        {
            try
            {
                EmailEscalation obj = null;
                obj = await _unitOfWork.EmailEscalation.GetFirstOrDefaultAsync(x => x.Id == emailEscalation.Id);
                if (obj != null)
                {
                    obj.Id = emailEscalation.Id;
                    obj.EscalEmail = emailEscalation.EscalEmail;
                    obj.Frequency= emailEscalation.Frequency;
                    obj.FrequencyNo= emailEscalation.FrequencyNo;
                    obj.EmailCode= emailEscalation.EmailCode;
                    obj.EscalNo= emailEscalation.EscalNo;
					obj.UpdatedBy = emailEscalation.UpdatedBy;
					obj.UpdatedOn = emailEscalation.UpdatedOn;
				}
				_unitOfWork.EmailEscalation.Update(obj);
                await _unitOfWork.SaveAsync();
                return obj.Id;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }


        public void SaveApplicationErrorLog(string errorMessage, string Action, string Controller, string UserName, string IPAddress,Guid GId = default)
        {
            try
            {
                if (GId == default)
                {
                    GId = Guid.NewGuid();
                }
                _unitOfWork.ErroLog.AddAsync(new ErrorLog()
                {
                    ErrorId = GId.ToString(),
                    UserName = UserName,
                    IpAddress = IPAddress,
                    ActionName = Action,
                    ControllerName = Controller,
                    ErrorMsg = errorMessage,
                    CreatedOn = DateTime.Now
                }).GetAwaiter().GetResult();
                _unitOfWork.SaveAsync().GetAwaiter().GetResult();
            }
            catch
            {
                // Swallow logging failures so they never tear down the request pipeline.
            }
        }




        public async Task<long> AddPlanTech(CtrTechConfiguration ctrTechConfig)
        {
            try
            {

                var validate = await _unitOfWork.CTRTechConfig.GetFirstOrDefaultAsync(t => t.StageId == ctrTechConfig.StageId);
                if (validate == null)
                {
                    await _unitOfWork.CTRTechConfig.AddAsync(ctrTechConfig);
                    await _unitOfWork.SaveAsync();
                    return ctrTechConfig.Id;
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<long> UpdatePlanTech(CtrTechConfiguration ctrTechConfig)
        {
            try
            {
                

              
                var validate = await _unitOfWork.CTRTechConfig.GetAllAsync(t => t.Id != ctrTechConfig.Id && t.StageId == ctrTechConfig.StageId);
                if (validate.Count() == 0) {
                    CtrTechConfiguration obj = null;
                    obj = await _unitOfWork.CTRTechConfig.GetFirstOrDefaultAsync(x => x.Id == ctrTechConfig.Id);
                    if (obj != null)
                    {
                        obj.UpdatedBy = ctrTechConfig.UpdatedBy;
                        obj.UpdatedOn = ctrTechConfig.UpdatedOn;
                        obj.UpdatedByRef = ctrTechConfig.UpdatedByRef;
                        obj.Phase = ctrTechConfig.Phase;
                        obj.Stage = ctrTechConfig.Stage;
                        obj.Planneddays = ctrTechConfig.Planneddays;
                        //obj.Sequence = ctrTechConfig.Sequence;
                        obj.PhaseId = ctrTechConfig.PhaseId;
                        _unitOfWork.CTRTechConfig.Update(obj);
                        await _unitOfWork.SaveAsync();
                    }

                    return obj.Id;

                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<long> DeletePlanTech(long id, EmployeeDTO employeeDTO)
        {
            CtrTechConfiguration obj = null;
            obj = await _unitOfWork.CTRTechConfig.GetFirstOrDefaultAsync(x => x.Id == id);
            if (obj != null)
            {

                _unitOfWork.CTRTechConfig.Remove(obj);
                long result = await _unitOfWork.SaveAsync();
                return 1;
            }
            return 0;
        }

        public async Task<List<FileUploadDTO>> GetSolution_Query_Docs_ByRESP_Id(long resp_Id)
        {
            return await _unitOfWork.DocumentRepo.GetSolution_Query_Docs_ByRESP_Id(resp_Id);
        }

    }

}
