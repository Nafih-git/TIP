﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IExecutionActualPlanRepository : IRepository<ExecutionActualplannedtimline>
    {
        #region Invoice Register
        Task<List<InvoiceRequestDTO>> LoadInvoiceRequests(long ActiveRole, string MuNumber);
        Task<List<InvoiceRequestDetailsDTO>> LoadInvoiceRequestDetails(long ActiveRole, string MuNumber, long ExecutionId);
        #endregion
    }
}
