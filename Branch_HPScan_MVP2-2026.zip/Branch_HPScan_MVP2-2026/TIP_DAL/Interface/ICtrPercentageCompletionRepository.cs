﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface ICtrPercentageCompletionRepository : IRepository<CtrPercentageCompletion>
    {
        Task<List<CtrPercentageCompletionDTO>> GetAllList(long CtrId);
        Task<CtrPercentageCompletionDTO> GetFormData(long id);
    }
}
