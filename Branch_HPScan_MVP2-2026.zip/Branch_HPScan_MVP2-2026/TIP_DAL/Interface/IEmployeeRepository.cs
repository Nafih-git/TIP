﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IEmployeeRepository : IRepository<TmEmployee>
    {
        public Task<EmployeeDTO?> GetByMuNumber(string MuNumber);
        public Task<List<SubthemeCfdhLnkDTO>> GetCFDH(long subThemeId);

        public Task<List<EmployeeDL?>>GetEmployeeByRoleId(long roleId);
        Task<List<EmployeeDTO?>> GetEmployeeByRole(long roleId);
    }
}
