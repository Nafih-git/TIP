﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IPirApprovalListRepository : IRepository<PirApprovalList>
    {
        Task<List<PirApprovalListDTO>> GetAllApprovalListByPirId(long PirId);
        Task<PirApprovalListDTO> GetApprovalListFormData(long Id);

        Task<List<PirApproverListDTO>> GetApproverListByPir(long Id);

        #region PIR Reminder
        Task<List<PirApprovalReminderDTO>> ReminderEmailForApprovers();
        #endregion
    }
}

