﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_DAL.Interface.Admin
{
    public interface IUserSettingsEFRepository
    {
        public  Task<List<EmployeeDL>> GetApplicationUserDTO();

        public Task<FPLinkEmployeeDL> GetApplicationFPDetailsDTO();

        public Task<List<ExternalUserDTO>> GetExternaluser();
        public Task<List<UserRolesDTO>> GetPMRoles();
        public Task<TmUserRole> GetUserRoleById(long roleID);
    }
}
