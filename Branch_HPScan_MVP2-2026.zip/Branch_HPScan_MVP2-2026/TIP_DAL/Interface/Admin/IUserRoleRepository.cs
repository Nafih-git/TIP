﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface.Admin
{
    public interface IUserRoleRepository : IRepository<TmUserRole>
    {
        public Task<List<UserRolesDTO>> GetUserRoles(bool onlyActivated);

        EmployeeDTO? GetPerson(string CompanyNumber);

        /// <summary>
        /// Removes role dependencies and marks the role for deletion.
        /// Returns 0 if not found, 1 if hard-delete prepared, 2 if soft-delete (deactivated) prepared.
        /// </summary>
        Task<int> PrepareDeleteUserRoleAsync(long roleId);

    }
}
