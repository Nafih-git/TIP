﻿using TIP_API.DTO.Admin;
using TIP_CORE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_DAL.Interface.Admin
{
    public interface IuserSettingsRepository
    {   
        public Task<UserSettingsDTO> GetUserRoledata();
        public Task<ExternalUserDTO> mapExtrnalUser(ExternalUser exUser,string param1);
        public Task<List<AllPDOUsersDTO>> GetUsersWithfilter(string Filter);
        public Task<List<AllPDOUsersDTO>> GetUserWithoutLoggedInUser(string Filter, string LoggedInUser);
        public Task<List<AllPDOUsersDTO>> GetUserWithoutUCTANDLoggedInUser(string Filter, string LoggedInUser);
        public Task<string> SaveUserToRoleMapping(UserViewData ViewData);
        public Task<string> UpdateActiveRole(long Role_ID);
        
        public Task<List<UserViewDataD>> loadUserRoleMapping();
        public Task<string> DeleteUserToRoleMapping(string UserId);
        public Task<RoleToMenuMappingDTO> LoadRoleMenuMapping(long ROLE_ID);
        public Task<string> saveRoleMenuMapping(RoleToMenuMappingDTO ViewData);
        public Task<List<UserApplicationViewDataD>> loadUserAssetFocalPoint();
        public Task<List<AllPDOUsersDTO>> loadApplicationUser();
        public Task<List<UserApplicationViewDataD>> loadUserClusterFocalPoint();
    }
}
