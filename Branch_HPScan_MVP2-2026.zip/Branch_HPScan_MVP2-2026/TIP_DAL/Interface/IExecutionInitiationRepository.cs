﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IExecutionInitiationRepository : IRepository<ExecutionInitiation>
    {
        Task<ExecutionIntiationDTO> GetCtrFormDataForExec(long ctrid, long roleid, string CompanyNumber, long execId);
        Task<List<ExecutionPotentialValue>> GetPot_valForExec(long ctrId);
        Task<List<ExecutionTrialfpsDTO>> GetTrialFPForExec(long ctrId);
        Task<ExecutionTrialfpsDTO> GetTrialFPForExecbyId(long exeId);
        Task<List<ExecutionPotentialValueDTO>> GetAllExecPotentialValue(long ctrId);

        Task<List<ExecutionPlannedTimelinesDTO>> GetConfig_MilestoneBYExecId(long execId, bool IsCreated, long roleid);
        Task<List<InitiatedTrialForExecDTO>> GetinitiatedTrialForExecution(string CompanyNumber);

        Task<List<TypeCodeMasterDetailDTO>> GetStagesDataByexec(long execid);

        Task<List<TypeCodeMasterDTO>> GetSortStagesByexec(long execId);
        Task<List<TypeCodeMasterDTO>> GetSortActivity(long execId);
        Task<ExecutionEmailDTO> ExecutionEmailData(long ExecId, string TemplateCode, string? oldMu = "",long? planId=0,long? InvId=0);
        Task<ExecutionPlannedDTO> GetExecutionPlannedById(long execId, long roleid, string CompanyNumber, bool Is_Created);
        Task<List<ExecutionReAssisgnDTO>> GetAllExecutionforReAssignment(long roleId, string CompanyNumber);
        Task<List<ApprovedExecutionPlannedDTO>> GetActualPlanGrid(string CompanyNumber);
        Task<List<ExecutionActualPlannedTimelineDTO>> GetActualPlannedTimeline(bool is_created, long execId, long roleid, string CompanyNumber);
        Task<List<TypeCodeMasterDTO>> GetOverallProgress();
        Task<List<ExecutionEscDTO>> reminderEmail(long days);
        Task<List<ExecutionPlannedTimeline>> Getplantimelinestage(long plantimelineId, long execId);
        Task<ExecutionPlannedTimeline> Getplantimelinealeardystageexist(string Stage, long execId);

        Task<TrialPlanReportResponseDTO> TrailPlanReport(TrialPlanReportDRequestDTO trialPlanReportDTORequestDTO, EmployeeDTO? LoggedInUser);

        Task<List<ExecutionActualPlannedTimelineDTO>> GetActualTimelines(long ExecutionId);

        public Task<long> ValidateExcecutionISCompleted(long exec_id);

        public Task<ExecutionInitiation> GetExecutionById(long execid);

    }
}
