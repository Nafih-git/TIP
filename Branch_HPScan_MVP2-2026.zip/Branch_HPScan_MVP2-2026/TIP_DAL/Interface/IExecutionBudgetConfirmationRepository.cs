﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IExecutionBudgetConfirmationRepository : IRepository<ExecutionBudgetConfirmation>
    {
        Task<ExecutionBudgetConfirmationDTO> GetCtrFormDataForBudget(long ctrid, long roleid, string CompanyNumber, string ContractId, long budgetId);
    }
}
