﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IChallengeVendorScreeningRepository: IRepository<ChallengeVendorScreening>
    {
        public Task<List<ChallengeVendorScreeningDTO>> GetAllVendorScreening(long challengeId);
    }
}
