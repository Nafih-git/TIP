﻿using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;


namespace TIP_DAL.Interface
{
    public interface IChallengeRegistrationRepository : IRepository<ChallengeRegistration>
    {
        public Task<RequestorDTO> GetRequestorInfo(long challengeRegId);
        public Task<ChallengeRegistrationDetailDTO> GetChallengeRegistrationDetailDTO(EmployeeDTO employee);
        public Task<ChallengeRegistrationDetailDTO> GetChallengeRegistrationDetailDTO();
        public Task<ChallengeReviewDTO> GetChallengesForReview(long? RoleID, string userMU);
        public Task<List<ChallengeRegistrationDTO>> FilterGetChallengeRegistration(ChallengeRegistrationDetailFilterDTO challengeRegistrationDetailFilterDTO);
        public Task<ChallengeKeywordDTO> MapChallengeForEmail(long id);
        public Task<List<ChallengeDetailDTO>> ReminderWhenChallengewithCFDH();
        public Task<List<ChallengeDetailDTO>> ReminderWhenChallengewithUCT();
        public Task<List<ChallengeDetailDTO>> ReminderWhenSolutionWithCHL();
        public Task<List<ChallengeDetailDTO>> ReminderWhenSolutionWithUCT();
        public Task<List<PainAreaDTO>> ReminderWhenPainAreaWithAFP();
        public Task<List<LatestChallengeForExternalDTO>> LatestPublishChallengesForExternal(long sourceId,long participant);
        public Task<List<LatestChallengeForExternalDTO>> ParticipatedChallengesForExternal(long sourceId, long participant);
        public Task<List<LatestChallengeDTO>> LatestPublishChallenges();

        public Task<List<LatestChallengeForExternalDTO>> AllPublishedChallengesForExternal();

        public Task<LatestChallengeForExternalDTO> ChallengeDetailsByResponseId(long responseID);
        public Task<List<ScreeningQuestionsDTO>> ScreeningQuestionsByResponseId(long responseID);
        public Task<VendorResponseDTO> VendorResponseByResponseId(long responseID);
		public Task<LocalSolutionDTO> GetLocalDetails(long responseID);

		public Task<VendorResponseDetailsDTO> GetVendorResponseDetailsForExternal(long responseID);
        public Task<List<QueryResponseDTO>> GetVendorQueryResponseForExternal(long responseID, long ChallengeID);
        public Task<List<QueryResponseDTO>> GetVendorQueryResponseForInternal(long ChallengeID);
        public Task<List<QueryResponseDTO>> GetAllVendorQueryAndResponseForInternal();
        public Task<List<QueryResponseDTO>> GetPDOQueryResponseForInternal(long SolutionId);
        public Task<List<SolutionTechDetailsDTO>> SolutionTechDetailsByResponseId(long responseID);
        public Task<TechProposalQueries> TechProposalQueriesCount();
        public Task<List<ChallengeStatusCountDTO>> GetCTRStatusCount();
        public Task<List<ChallengeStatusCountDTO>> GetChallengeStatusCount();
        public Task<List<ChallengeStatusCountDTO>> GetPIRStatusCount();
        public Task<List<ChallengeStatusCountDTO>> GetChallengeResponseStatusCount();

        //public Task<List<>> GetChallengeFilesForExternal(string refNo);
    }
}
