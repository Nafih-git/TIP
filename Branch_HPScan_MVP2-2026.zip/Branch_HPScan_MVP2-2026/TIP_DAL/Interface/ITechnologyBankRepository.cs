﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface ITechnologyBankRepository: IRepository<TechnologyBank>
    {
        public Task<List<TechnologyBankDTO>> GetTechnologyBanks(EmployeeDTO LoggedInUser);
        public Task<List<TechnologyBankDTO>> GetFilterTechnologyBanks(TechnologyBankFilterDTO technologyBankFilterDTO);
		public Task<TechnologyBankDTO> GetTechnologyBankByRefId(long challengeId, long challengeRefId);

	}
}
