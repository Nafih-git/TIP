using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface ITrAuditLogRepository : IRepository<TrAuditLog>
    {
        Task<AuditLogReportResponseDto> GetAuditLogsAsync(AuditLogSearchRequestDto request, bool includeJsonFields = false);
        Task<AuditLogDto> GetAuditLogByIdAsync(decimal auditId);
        Task<int> ClearAuditLogsAsync(AuditLogClearRequestDto request);
    }
}
