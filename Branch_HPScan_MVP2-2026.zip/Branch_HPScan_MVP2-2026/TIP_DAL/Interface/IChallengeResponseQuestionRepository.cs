﻿using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IChallengeResponseQuestionRepository: IRepository<ChallengeResponseQuestion>
    {
        public Task<ChallengeResponseQuestionDTO> ChallengeResponseQuestions(long responseId);
    }
}
