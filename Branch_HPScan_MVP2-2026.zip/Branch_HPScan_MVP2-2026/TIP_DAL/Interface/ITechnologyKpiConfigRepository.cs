﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface ITechnologyKpiConfigRepository : IRepository<TechnologyKpiConfig>
    {
    }
}
