﻿using TIP_Core;
using TIP_CORE;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_DAL.Interface
{
    public interface ICommonRepository
    {
        //public Task<UserDetail> GetUserDetail();
        //public Task<UserMenu> GetUserMenu();
       
    }
}
