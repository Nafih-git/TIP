﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IExeFlowHistoryRepository : IRepository<ExeFlowHistory>
    {
        Task<List<ExeFlowHistoryDTO>> GetHistoryById(long ExeId);
        Task<List<ExeFlowHistoryDTO>> GetAllFlowHistoryDetail(long ExeId);
        Task<List<ExeFlowHistoryDTO>> GetHistoryByPlanId(long plan);
        Task<List<ExeFlowHistoryDTO>> GetHistoryByApprovedPlanId(long plan);
    }
}
