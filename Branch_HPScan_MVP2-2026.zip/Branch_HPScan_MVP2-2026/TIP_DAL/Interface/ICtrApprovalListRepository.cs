﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface ICtrApprovalListRepository : IRepository<CtrApprovalList>
    {
        Task<List<CtrApprovalListDTO>> GetAllApprovalListByCtrId(long CtrId);
        Task<CtrApprovalListDTO> GetApprovalListFormData(long Id);
        Task<List<CtrApproverListDTO>> GetApproverListByCtr(long Id);

        #region CTR Reminder
        Task<List<CtrApprovalReminderDTO>> GetAllForDailyReminder();
        #endregion
    }
}
