﻿using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;

namespace TIP_DAL.Interface.Base
{
    public interface IConfigurationRepository : IRepository<Configuration>
    {
        public Task<List<ConfigurationDTO>> GetConfigurationByType(string type);
    }
}
