﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IRabitahContractRepository : IRepository<TmRabitahContract>
    {
        public Task<List<RabitahContractDTO>> GetContractData();
        public Task<RabitahContractDTO> GetContractDataByContID(string Cont_ID);
        public Task<RabitahContractDTO> GetContractDataRDLC(string Cont_ID);		
        public Task<string> GetContractID(long Id);
	}
}
