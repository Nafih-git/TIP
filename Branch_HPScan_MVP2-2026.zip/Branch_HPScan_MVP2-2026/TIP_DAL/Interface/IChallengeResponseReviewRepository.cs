﻿using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IChallengeResponseReviewRepository: IRepository<ChallengeResponseReview>
    {
        public Task<List<ChallengeResponseReviewDTO>> GetChallengeReview(long responseId, long roleId, EmployeeDTO? loggedInUser);
		public Task<List<ReviewDetailDTO>> GetReviewerDetail(long responseId);

		public Task<ChallengeReviewKeywordDTO> MapSolutionReviewEmail(long id);
    }
}
