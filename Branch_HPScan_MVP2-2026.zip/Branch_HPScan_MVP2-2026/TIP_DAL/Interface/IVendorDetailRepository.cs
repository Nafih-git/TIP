﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IVendorDetailRepository : IRepository<ExternalUser>
    {
        public Task<List<ExternalUser>> VendorDetailRepoList(string emailAddress, string pass);
        public Task<ExternalUserDTO> MapVendorRegistrationEmail(string emailAddress);
        public Task<List<ExternalUserDTO>> GetExternaluser();
    }
}
