﻿using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IPirVotRepository : IRepository<PirVot>
    {
        public Task<PirVotDTO> GetVOTDetails(long pirId);
    }
}
