﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IPainAreasRepository : IRepository<PainArea>
    {
        public Task<List<BTMAssessmentDTO>> GetAssessmentsForRanking(string MU);
        public Task<List<BTMAssessmentDTO>> GetFilterAssessmentsForRanking(BTMAssessmentFilterDTO btmAssessmentIP_DTO);
        public Task<List<RankPainAreaDTO>> GetPainAreasForRanking(long AssessmentId);

        public Task<List<PainAreaDTO>> GetPainAreasByAssessmentId(long AssessmentId, EmployeeDTO employee);
        public Task<List<RankPainAreaDTO>> GetFilterPainAreasForRanking(RankPainAreaFilterDTO rankPainAreaFilterDTO);
        public Task<List<string>> GetAllCustorsMuNo(long clusterId);
        public Task<List<string>> GetAllAssetsMuNo(long assetId);
    }
}
