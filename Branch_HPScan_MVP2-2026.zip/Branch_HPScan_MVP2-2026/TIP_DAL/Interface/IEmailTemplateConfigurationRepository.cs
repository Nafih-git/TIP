﻿using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IEmailTemplateConfigurationRepository : IRepository<EmailTemplateConfiguration>
    {
        public Task<List<EmailTemplateConfigurationDTO>> GetEmailTemplateConfigByModule(long id);
        public Task<EmailTemplateConfiguration> GetEmailTemplatebyTemplateCode(long ModuleId, string code);
    }
}
