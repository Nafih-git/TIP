﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace TIP_DAL.Interface.Base
{
    public interface IRepository<T> where T : class
    {
        Task<T> GetAsync(long id);

        Task<IEnumerable<T>> GetAllAsync(
            Expression<Func<T, bool>> filter = null,
            Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null,
            string includeProperties = null, bool noTracking = false, bool useSP = false
        );

        Task<T> GetFirstOrDefaultAsync(
            Expression<Func<T, bool>> filter = null,
            string includeProperties = null, bool useSP = false, bool isTracking = true
        );

        Task AddAsync(T entity, bool useSP = false);

        Task AddRangeAsync(IEnumerable<T> entity, bool useSP = false);

        void Update(T entity, bool useSP = false);
        void UpdateRange(IEnumerable<T> entity, bool useSP = false);

        void Remove(T entity, bool useSP = false);

        void RemoveRange(IEnumerable<T> entity, bool useSP = false);

    }
}
