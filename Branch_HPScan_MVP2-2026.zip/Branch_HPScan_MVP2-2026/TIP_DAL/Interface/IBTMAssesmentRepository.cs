﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IBTMAssesmentRepository : IRepository<BtmAssessment>
    {
        public Task<List<BTMAssessmentDTO>> GetBTMAssessments(EmployeeDTO MU);
        public Task<BTMAssessmentKeywordDTO> GetBTMAssessmentById(long id);
        public Task<BTMAssessmentKeywordDTO> GetBTMAssessmentByPainAreaId(long id);
    }
}
