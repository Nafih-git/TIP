﻿using TIP_Core;

namespace TIP_DAL.Interface
{
    public interface IMasterRepository
    {
        #region Module
        public Task<List<Module>> GetModule(int Id = 0);
        public Task<Response> SaveModule(Module model);
        #endregion
    }
}
