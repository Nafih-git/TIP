﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface ICTRActualPlanDetailsRepository : IRepository<CtrActualPlanDetail>
    {
        Task<TechnologyStatusReportDTO> TechnologyStatusReport(long tech);
        Task<List<TechnologyBankDTO>> TechnologyStatusTitle(string? search, long? areaId, long? applicationId, long? themeId, string? UCT_FP, long? maturationPhase, bool? isFilter);
        Task<TechnologyHeatMapReportDTO> TechnologyHeatMAPReport(TechnologyStatusRequestDTO technologyheatmapreportdto);
    }
}
