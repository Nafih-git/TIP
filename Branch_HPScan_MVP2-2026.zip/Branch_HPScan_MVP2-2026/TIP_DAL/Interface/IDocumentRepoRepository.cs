﻿using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IDocumentRepoRepository : IRepository<DocumentRepo>
    {
        public Task<List<DocumentRepoDTO>> DocumentRepoList(long linkId, string linkType, bool external = false);
        public Task<DocumentRepoDTO> DocumentRepo(long id); 
        public Task<List<FileUploadDTO>>GetDocumentsByLinkId(long linkId, string linkType,bool external);
        public Task<List<FileUploadDTO>> GetDocumentsByLinkType(string linkType);
        public Task<FileUploadDTO> GetDocumentById(long Id);
		public Task<List<DocumentRepoDTO>> GetDocumentsById(long id);
	
        Task<List<FileUploadDTO>> GetAllFilesById(long linkId, string linkType, bool external);
        Task<List<FileUploadDTO>> GetSolution_Query_Docs_ByRESP_Id(long resp_Id);
    }
}
