﻿using TIP_API.DTO.Admin;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IChallengeResponseRepository: IRepository<ChallengeResponse>
    {
        public Task<ChallengeRespondByTypeDTO> GetAllChallengeResponse(long roleId, string loggedMu);
        public Task<string> ExternalEmail(long id);
        public Task<ExternalUserDTO> ExternalEmailwithName(long id);

        public Task<List<ExternalUserDTO>> SourcesEmail(long sourceid);
        public Task<List<string>> allEmail();

        public Task<List<ChallengeEscDTO>> reminderEmail(long days);
        public Task<List<SolutionReviewerListDTO>> SolutionReviewerList(long solId);
        public Task<List<ChallengeReassignmentListDTO>> ChallengeReassignmentList(long roleId, string CompanyNumber);
        public Task<List<AllPDOUsersDTO>> SolutionReviewerByChaId(long chaId);
        public Task<List<AllPDOUsersDTO>> CFDHByChaId(long chaId);
        public Task<List<AllPDOUsersDTO>> getCHFPChaId(long chaId);
        public Task<List<SolutionReviewerListDTO>> SolutionReviewerListByChaId(long chaId);
        public Task<bool> GetExternalUserProposedSol(long id);

        public Task<ChallengeResponseReport> GetChallengesResponseReport(ChallengeReportRequestDTO ChallengeReportDTO, EmployeeDTO? LoggedInUser);
        
          

    }
}
