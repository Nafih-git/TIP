﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
	public interface IEmailEscalationRepository : IRepository<EmailEscalation>
	{
		public Task<List<EmailEscalationDTO>> getAllEmailsData();
		public Task<long> getEmailEscDays(string emailCode);
		public Task<EmailEscalationDTO> getEmailEscByCode(string code);

        public Task<long> getEmailEscOccurunces(string emailCode);

    }
}
