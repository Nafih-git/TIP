﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface ITaskRepoRepository : IRepository<TaskRepo>
    {
        IEnumerable<TaskRepoDTO> GetAllTasksForUser(string CompanyNumber);
        List<PrecisedTaskDTO> GetAllTasksCountForUser(EmployeeDTO employee);

        public Task<PrecisedTaskReportMasterDTO> GetAllTasks(ActiionTaskRequestDTO requestdto);
    }
}
