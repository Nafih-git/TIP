﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IChallengeDetailRepository : IRepository<ChallengeDetail>
    {
        public Task<ChallengeDetailDTO> GetChallengeDetail(long challengeRegId);
        public Task<ChallengeRegistrationDTO> GetChallengeRegistrationByRefNo(string challengeRegRefNo);
        public Task<ChallengeRegistrationDTO> GetChallengeRegistrationFromOldTIPRef(string challengeRegRefNo);
        public Task<string> GetEmailBymuNO(string muNo);
        public Task<string> GetCRByResponseID(long responseID);

        public Task<ChallengPublishKeywordDTO> MapChallengePublishedEmail(long id);

        public Task<challengePublishDetailsDTO> GetChallengePublication(long challengeRegId);

		public Task<OverAllReportResponseDTO> OverAllReport(OverAllReportRequestDTO overAllReportDTO, EmployeeDTO? LoggedInUser);
		public Task<TechKPIReportResponseDTO> TechKPIReport(TechKPIReportRequestDTO techKPIReportDTO, EmployeeDTO? LoggedInUser);
		public Task<MasterReportResponseDTO> MasterReport(MasterReportRequestDTO masterReportDTO, EmployeeDTO? LoggedInUser);
	}
}
