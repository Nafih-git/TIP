﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_Core;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IPirRepository : IRepository<PirInitiation>
    {
        Task<PirWorkFlowDTO> GetPirWorkFlowData(long PirId, long roleid, string CompanyNumber);
        Task<PirGeneralInformationDTO> GetPirData(long PirId, long roleid, string CompanyNumber);

        Task<PirInitiationDTO> GetPirDataByRefNo(string RefNo);
        Task<PirTrialDetailsDTO> GetPirTrialDetailsData(long PirId, long roleid, string CompanyNumber);
        Task<PirDeploymentStaircaseDetailsDTO> GetPirDeploymentStaircaseData(long PirId, long roleid, string CompanyNumber);

        Task<PirEmailDTO> GetEmailData(long Id, string TemplateCode);

        #region Re Assignemnt 

        Task<List<ApprovedCtrDTO>> GetAllPirforReAssignmentAdmin(string CompanyNumber);
        Task<List<ApprovedCtrDTO>> GetAllPirforReAssignmentUCT(string CompanyNumber);

        #endregion

        #region PIR Reminder
        Task<List<PirApprovalReminderDTO>> ReminderWhenPIRwithTFP();
        Task<List<PirApprovalReminderDTO>> ReminderWhenPIRwithUCT();
        #endregion

        Task<List<ApprovedPirDTO>> GetApprovedPir(string CompanyNumber, long roleId);

	}
}
