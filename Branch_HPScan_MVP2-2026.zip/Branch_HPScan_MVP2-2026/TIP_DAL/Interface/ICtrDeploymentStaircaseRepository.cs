﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface ICtrDeploymentStaircaseRepository : IRepository<CtrDeploymentStaircase>
    {
        public Task<List<CtrDeploymentStaircaseDTO>> GetCtrDeploymentStaircase(long ctrId);
        public Task<CtrFinalDeploymentStaircaseDTO> GetCtrDeploymentStaircaseDetail(long ctrId);
        public Task<List<CtrDeploymentStaircaseDTO>> GetCtrDeploymentStaircaseByYearly(long ctrId);


    }
}
