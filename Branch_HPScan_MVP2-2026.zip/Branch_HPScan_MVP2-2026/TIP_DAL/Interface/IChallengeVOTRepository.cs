﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IChallengeVOTRepository : IRepository<ChallengeVot>
    {
        public Task<ChallengeVOT_DTO> GetVOTDetails(long ChallengeId);
        public Task<List<ChallengeQuestionaire_DTO>> GetChallengeQuestionaire(long ChallengeId); 

    }
   
}
