﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface ITypeCodeMasterRepository : IRepository<TypeCodeMaster>
    {
        public Task<List<TypeCodeMasterDTO>> GetMasterDataByTypeAndParentID(string Type, int ParentID);
        public Task<List<TypeCodeMasterDTO>> GetMasterDataByType(string Type);
        public Task<List<TypeCodeMasterDTO>> GetAssetByMU(string Mu);
        public Task<List<TypeCodeMasterDTO>> GetClusterByAssetIdAndMU(long Assetid, string Mu);
        public Task<List<TypeCodeMasterDTO>> GetClusterByMU(EmployeeDTO employee, long assessmentid); 
        public Task<List<TypeCodeMasterDTO>> GetMasterDataByTypeInternal(string Type);
        public Task<List<EmployeeDTO>> GetAllUsersByRole(string rolecode);
        public Task<List<TypeCodeMasterDetailDTO>> GetMasterDetailByType(string type);
        public Task<TypeCodeMasterDTO> GetDataByType(string Type,string Param1);

        public Task<List<TypeCodeMasterDetailDTO>> GetMasterDataByParam2(string param2);
        public Task<TypeCodeMasterDetailDTO> GetMasterDataById(long Id);
        public Task<List<TypeCodeMasterDTO>> GetMasterDataByParentId(long pid);

        public Task<List<CtrTechConfigurationDTO>> GetCtrTechConfiguration();
        public Task<List<CTRPlanDetailsDTO>> GetCtrplandetailsByCtrID(long ctrId, string phase);

        public Task<List<VTipTechnologyPlanDTO>> GetCtrViewplandetailsByCtrID(long ctrId);

        public Task<List<TypeCodeMasterDTO>> GetMasterDataByTypeConfiguration(string Type);
        
        
        public Task<List<TechnologyKPIDTO>> GetTechKPIByYear(long year);
    }
}
