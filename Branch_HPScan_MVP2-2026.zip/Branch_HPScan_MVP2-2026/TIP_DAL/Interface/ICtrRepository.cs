﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface ICtrRepository : IRepository<CtrInitiation>
    {
        Task<List<CtrInitiationDTO>> GetAllCtr(string CompanyNumber);
        Task<CtrInitiationDTO> GetCtrByRefNo(string RefNo);
        Task<List<CtrInitiationDTO>> GetAllCtrForTTA(string CompanyNumber);
        public Task<string> GetDDFormat();
        Task<List<CtrInitiationDTO>> GetAllCTRforReview(string CompanyNumber);
        Task<CtrInitiationDTO> GetCtrFormData(long id, long roleid, string CompanyNumber);
        Task<CtrViewPlanDetailsDTO> GetCtrFormDataforViewPlan(long id);
        Task<List<CtrInitiationDTO>> GetCtrFormDataForRDLC(long id, long roleid, string CompanyNumber);
        Task<Boolean> ValidateVendor(string ttaref, string vendor_code);
        Task<string> ValidateCTR(long id);
        
        Task<List<TTAPaymentDTO>> ctrPayment(long ctrId);
        #region Re Assignemnt 

        Task<List<CtrInitiationDTO>> GetAllCTRforReAssignmentAdmin(string CompanyNumber);
        Task<List<CtrInitiationDTO>> GetAllCTRforReAssignmentUCT(string CompanyNumber);

        #endregion

        #region CTREmail

        Task<CtrInitiationDTO> CTREmailData(long CtrId,string TemplateCode);

        #endregion

        #region CTR Reminder
        Task<List<CtrApprovalReminderDTO>> GetAllForWeeklyReminderTFP();
        Task<List<CtrApprovalReminderDTO>> GetAllForWeeklyReminderUCT();
        #endregion

        #region Pir Related

        Task<List<ApprovedCtrDTO>> GetApprovedCtr(string CompanyNumber);
        Task<List<ApprovedCtrDTO>> GetPirToReview(string CompanyNumber);
        Task<List<ApprovedCtrDTO>> GetPirForApproval(string CompanyNumber);

        Task<PirCtrInitDTO> GetCtrPriData(long CtrId, long PirId, long roleid, string CompanyNumber);
        #endregion

        #region Execution Related
        Task<List<ApprovedCtrForExecDTO>> GetApprovedCtrForExec(string CompanyNumber);
		#endregion

		Task<GetAllStatusDTO> GetAllStatusByCtr(long ctrId);

        Task<List<TypeCodeMasterDTO>> GetOverallProgress();
        Task<List<CtrPlanDetail>> GetCTRTechnology(long Id);
        Task<CTRActualPlanDetailsDTO> CTRPlanEmailData(long ctrid, long actualid);

    }
}
