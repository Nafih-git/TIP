﻿using TIP_CORE.Entities;
using TIP_CORE.EntitiesDTO;
using TIP_DAL.Interface.Base;

namespace TIP_DAL.Interface
{
    public interface IDepVotRepository : IRepository<DepVot>
    {
		public Task<List<DepVotDTO>> GetDeployment(long roleId, string loggedMu, long pirId);
		public Task<DepVotDTO> GetDeploymentById(long Id);
		//public Task<DepVotEmailDTO> DeploymentEmailData(long Id, string? currentMU = "", string? previousMU = "");
        public Task<List<DepReassignmentDTO>> GetAllDeploymentforReAssignment(long roleId, string CompanyNumber);
        public Task<DeploymentTrialfpsDTO> GetCHFPForDeploymentbyId(long id);
        Task<DepInitiation> GetDeploymentDBObj(long id);
        public Task<DepVotEmailDTO> DeploymentEmailData(long Id, long? votId = 0, string? currentMU = "", string? previousMU = "");
        public Task<DepVotDTO> GetDeploymentByPirId(long Id);
        public Task<List<DepVotEmailDTO>> reminderEmail(long days);
        Task<DeploymentTrialfpsDTO> GetUCTFPForDeploymentbyId(string mu);
    }
}
