﻿using TIP_API.DTO.Admin;
using System.Net.NetworkInformation;

namespace TIP_DAL
{
    public static class DBConstants
    {
        #region Input Parameters
        public static class Input
        {
            public const string P_MU_NUMBER = "p_mu_id";
            public const string P_ID = "P_ID";
            public const string P_DIRECTORATE_ID = "p_directorate_id";
            public const string P_DIRECTORATE_NAME = "p_directorate_name";
            public const string P_ELEMENT_ID = "p_element_id";
            public const string P_CLUSTER_ID = "p_cluster_id";
            public const string P_CLUSTER_NAME = "p_cluster_name";
            public const string P_CORPORATE_ID = "p_corporate_id";
            public const string P_ELEMENT_TYPE_ID = "p_element_type_id";
            public const string P_GROUP_ID = "p_group_id";
            public const string P_STATUS = "p_status";
            public const string P_USER_ID= "p_user_id";
            public const string P_MODULE= "p_module";
            public const string P_NAME = "P_NAME";
            public const string P_DESCRIPTION = "P_DESCRIPTION";
            public const string P_ORDER_NO = "P_ORDER_NO";
            public const string P_ISACTIVE = "P_ISACTIVE";
            public const string P_ICON = "P_ICON";
            public const string P_CREATED_BY = "P_CREATED_BY";
            public const string P_ELEMENT_NAME = "p_element_name";
            public const string P_COLOR = "p_color";
            public const string P_IS_COMMENT = "p_is_comment";
            public const string P_FILTER = "P_FILTER";
            public const string P_U_REF = "P_U_REF";

            public const string P_CHL_ID = "P_CHL_ID";

        }
        #endregion

        #region Output Parameters
        public static class Output
        {
            public const string P_RESPONSE = "P_RESPONSE";
            public const string P_MODULE = "P_MODULE";
            public const string P_USER_DATA = "P_USER_DATA";
            public const string P_SCREENS = "P_SCREENS";
            public const string P_ROLES = "P_ROLES";
            public const string P_ASSETS = "P_ASSETS";
            public const string P_CUR = "P_CUR";
            public const string P_MSG = "P_MSG";
        }
        #endregion

        #region Stored Procedures
        public static class Procedures
        {


            #region Lijina 
                //User Settings
                public const string SP_GET_USER_ROLES = "PKG_USER_MGMT.SP_GET_USER_ROLES";
                public const string SP_GET_USERS_WITH_FILTER = "PKG_USER_MGMT.SP_GET_USERS_WITH_FILTER";
                public const string SP_GET_USERS_WITHOUT_UCT_FILTER = "PKG_USER_MGMT.SP_GET_USERS_WITHOUT_UCT_FILTER";
                public const string SP_SAVE_USERS_TO_ROLE_MAPPING = "PKG_USER_MGMT.SP_SAVE_USERS_TO_ROLE_MAPPING";
                public const string SP_SELECT_USERS_TO_ROLE_MAPPING = "PKG_USER_MGMT.SP_SELECT_USERS_TO_ROLE_MAPPING";
                public const string SP_DELETE_USERS_TO_ROLE_MAPPING = "PKG_USER_MGMT.SP_DELETE_USERS_TO_ROLE_MAPPING";
                public const string SP_SELECT_ROLE_TO_MENU_TO_ELEMENT = "PKG_USER_MGMT.SP_SELECT_ROLE_TO_MENU_TO_ELEMENT";
                public const string SP_SAVE_ROLE_TO_MENU_TO_ELEMENT = "PKG_USER_MGMT.SP_SAVE_ROLE_TO_MENU_TO_ELEMENT";
                public const string SP_GET_BASEDATA = "PKG_USER_MGMT.SP_GET_BASEDATA";
                public const string SP_GET_LoginBASEDATA = "PKG_USER_MGMT.SP_GET_BASEDATA_ROLES_USER";
                public const string SP_UPDATE_ACTIVE_ROLE = "PKG_USER_MGMT.SP_UPDATE_ACTIVE_ROLE";
            public const string SP_INT_SELECT_USERS_TO_FOCAL = "PKG_USER_MGMT.SP_INT_SELECT_USERS_TO_FOCAL";
            public const string SP_INT_SELECT_APPLICAION_USERS = "PKG_USER_MGMT.SP_INT_SELECT_APPLICAION_USERS";
            public const string SP_INT_SELECT_APPLICAION_ClusterUSERS = "PKG_USER_MGMT.SP_INT_SELECT_APPLICAION_ClusterUSERS";
            public const string SP_GET_VQR_INTERNL = "PKG_USER_MGMT.SP_GET_VQR_INTERNL";
            #endregion
        }
        #endregion
    }
}
