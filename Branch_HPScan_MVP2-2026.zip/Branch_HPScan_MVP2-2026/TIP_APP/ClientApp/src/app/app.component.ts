import { AfterViewInit, Component } from '@angular/core';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import { ToastrService } from 'ngx-toastr';
import { ApiService } from './common/services/api.service';
import { UtilityService } from './common/services/utility.service';
import {SessionStorageService} from 'ngx-webstorage';
import { forkJoin, Observable } from 'rxjs';
import {Location} from '@angular/common';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  title = 'KeyFigures';
  ENABLEOVERLAY=false;
  BaseD:any={};
  AuthData:any={};
  empRoleList:any=[];
  empMenuList:any=[];
  parentMenuList=[];
  configuration=false;
  usersettings=false;
  admin=true;
  target=false;
  lowhighlights=false;
  activeRole={};

  constructor(
    private route:Router,
    private _apiService:ApiService,
    private _utils:UtilityService,
    private _toast:ToastrService,
    private _storage:SessionStorageService,
    private _location:Location,
    ) {}
    ngOnInit(): void {

      this.getBaseData();

  }

  ngAfterViewInit(): void {
    const adminlte = (window as any).adminlte;
    if (typeof adminlte?.initialize === 'function') {
      adminlte.initialize();
    }
  }

  getBaseData(){

    this.ENABLEOVERLAY=true;

    this.getData('Dashboard/getBaseData',{}).subscribe(

      (responseList: any) => {

        if (responseList[0].status === 1) {

          var response=responseList[0];

          this.BaseD=response.TResponse.employeeData[0];

          this.empRoleList=response.TResponse.empRoleList;

          this.empMenuList=response.TResponse.empMenuList;

          this.manageSideMenu();

          this._storage.clear('BASEDATA');

          this._storage.store('BASEDATA', this.BaseD);

          this.ENABLEOVERLAY=false;

        }

        else{

          this.ENABLEOVERLAY=false;

        }

      });

  }

  manageSideMenu(){
    if(this.empMenuList.length==0){
      this.gotoAccessdenied();
    }
    else{
        var i=0,count=this.empMenuList.length;
        for(;i<count;i++){
          var item=this.empMenuList[i];
          if(item.PARENT_MENU_ID==0){
            this.parentMenuList.push(item);
          }
        }
        this.gotoDashboard();
    }
    if(this.empRoleList.length>0){
      this.activeRole=this.empRoleList[0];
    }
    setTimeout(() => {
      this.activeFunc(1);
    }, 500);

  }







  parentMenu(event: Event) {
    event.preventDefault();
    const link = event.currentTarget as HTMLElement;
    const item = link.closest('.nav-item');
    const submenu = item?.querySelector(':scope > .nav-treeview') as HTMLElement | null;
    const open = link.classList.contains('menu-is-opening');
    if (open) {
      item?.classList.remove('menu-is-opening', 'menu-open');
      link.classList.remove('menu-is-opening', 'menu-open');
      submenu?.classList.remove('show-menu');
      submenu?.classList.add('close-menu');
      link.classList.add('bg-transparent');
    } else {
      link.classList.remove('bg-transparent');
      submenu?.classList.remove('close-menu');
      item?.classList.add('menu-is-opening', 'menu-open');
      link.classList.add('menu-is-opening', 'menu-open');
      submenu?.classList.add('show-menu');
    }
  }

filterMenuList(id) {
  var list = this.empMenuList.filter((t) => t.PARENT_MENU_ID == id);
  return list;
}


activeFunc(item:any){
  let selectedmenu=document.getElementById(item);
  let navList: any = document.getElementsByClassName('kfsidelink');
  if(navList.length>0){
    let i=0,count=navList.length;
    for(;i<count;i++){
      let elem=navList[i];
      elem.classList.remove('active');
      elem.classList.remove('kf-active-link');
    }
  }
  selectedmenu.classList.add('kf-active-link');
}

    manageAdmin(){
      var i=0,count=this.empRoleList.length;
      for(;i<count;i++){
        var item=this.empRoleList[i];
        if(item.ROLE_NAME.toLowerCase()=="admin"){
          this.admin=true;
        }
      }

    }
  gotoDashboard(){
    this.route.navigate(['/dashboard']);
  }
  gotoAccessdenied(){
    const sidebar = this._utils.getElement("DIV","sidebar");
    const topnav = this._utils.getElement("DIV","topnav");
    if(sidebar!=null){
      sidebar.style.display='none';
    }
    if(topnav!=null){
      topnav.style.display='none';
    }
    this.route.navigate(['/accessdenied']);
  }
  getData(url:any, options = {}): Observable<any[]> {
    const response = this._apiService.get(url, options);
    return forkJoin([response]);
  }

}
