import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [{ path: 'dashboard', loadChildren: () => import('./forms/dashboard/dashboard.module').then(m => m.DashboardModule) },

{ path: 'usersettings', loadChildren: () => import('./forms/admin/usersettings/usersettings.module').then(m => m.UsersettingsModule) },

{ path: 'accessdenied', loadChildren: () => import('./forms/accessdenied/accessdenied.module').then(m => m.AccessdeniedModule) },

{ path: 'configuration', loadChildren: () => import('./forms/admin/configuration/configuration.module').then(m => m.ConfigurationModule) },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
