import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConfigurationRoutingModule } from './configuration-routing.module';
import { ConfigurationComponent } from './configuration.component';

import { ToastrService } from 'ngx-toastr';
import { ApiService } from '../../../common/services/api.service';
import { UtilityService } from '../../../common/services/utility.service';
import {SessionStorageService} from 'ngx-webstorage';
import { forkJoin, Observable } from 'rxjs';
import {Location} from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    ConfigurationComponent
  ],
  imports: [
    CommonModule,
    ConfigurationRoutingModule,FormsModule, ReactiveFormsModule,
  ]
})
export class ConfigurationModule {

  constructor() {
  }

  ngOnInit() {
  }
  deleteContact(row) {
    const dialogData = { action: 'Confirm Action', message: 'Are you sure you want to remove this row?' };
  }
}
