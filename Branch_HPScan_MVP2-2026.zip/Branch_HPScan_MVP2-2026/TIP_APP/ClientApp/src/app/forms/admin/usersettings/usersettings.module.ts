import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsersettingsRoutingModule } from './usersettings-routing.module';
import { UsersettingsComponent } from './usersettings.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ConfirmationPopoverModule } from 'angular-confirmation-popover';

import { NgSelectModule } from '@ng-select/ng-select';

import {MatTableModule} from '@angular/material/table';
import {MatSortModule} from '@angular/material/sort';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatIconModule} from '@angular/material/icon';
import {MatPaginatorModule} from '@angular/material/paginator';

import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule, MAT_DATE_LOCALE } from '@angular/material/core';
import {MatCardModule} from '@angular/material/card';
import {MatChipsModule} from '@angular/material/chips';
import {MatSelectModule} from '@angular/material/select';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatMenuModule} from '@angular/material/menu';

@NgModule({
  declarations: [
    UsersettingsComponent
  ],
  imports: [
    CommonModule,
    UsersettingsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule,
    ConfirmationPopoverModule.forRoot({
      confirmButtonType: 'danger', // set defaults here
    }),

    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatPaginatorModule,
    MatChipsModule,
    MatSelectModule,
    MatMenuModule

  ],
  providers: [],
})
export class UsersettingsModule { }
