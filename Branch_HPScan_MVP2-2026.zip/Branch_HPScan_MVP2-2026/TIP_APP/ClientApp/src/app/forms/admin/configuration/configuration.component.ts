import { HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';


import { ToastrService } from 'ngx-toastr';
import { forkJoin, Observable } from 'rxjs';
import { ApiService } from '../../../common/services/api.service';
import { UtilityService } from '../../../common/services/utility.service';
import {FormBuilder, FormControl, FormGroup, Validators,ReactiveFormsModule} from '@angular/forms';
@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.css']
})
export class ConfigurationComponent {

  statusList:any[];

  assets:any[];
  clusters:any[];
  elements:any[];
  removedMsg:any;
  ENABLEOVERLAY: boolean;
assetFormGroup = this._formBuilder.group({

  AssetName:[''],
    assetId:[''],
    status:['']

  });
  constructor(private _apiService:ApiService,private _formBuilder:FormBuilder) {

  }
  ngOnInit(): void {
  this.GetAllAssets();
  this.GetAllClusters();
  this.GetAllElements();
    //this.getBaseData();
}
  GetAllAssets(){
    this.getData('Common/GetAsset',{DirectorateId:0,Status:1}).subscribe((responseList: any) => {
        if (responseList.message =='success') {
          this.assets = responseList.TResponse;
        }
        else{
          this.ENABLEOVERLAY=false;
        }
      });
  }
  getData(url:any, options = {}): Observable<any> {
    const response = this._apiService.get(url, options);
    return response;
  }
  removeData(url:any, options = {}){
    const response = this._apiService.post(url, options);
    return response;
  }
  AddAsset()
  {

  }
  GetElement(_elementId)
  {
    let rowitem: {};

    this.getData('Common/GetElement',{elementId:_elementId,elementTypeId:0,groupId:0,status:1}).subscribe((responseList: any) => {
      if (responseList.message =='success') {
        this.elements = responseList.TResponse[0];
      }
      else{
        this.ENABLEOVERLAY=false;
      }
    });
  }
  GetAsset(_directorateId)
  {
    this.getData('Common/GetAsset',{directorateId:_directorateId,elementTypeId:0,groupId:0,status:1}).subscribe((responseList: any) => {
      if (responseList.message =='success') {
        this.elements = responseList.TResponse[1];


this.assetFormGroup.patchValue({
  AssetName:responseList.TResponse[1].DirectorateName,
  assetId:responseList.TResponse[1].DirectorateId,
  status:responseList.TResponse[1].Status,
});


      }
      else{
        this.ENABLEOVERLAY=false;
      }
    });
  }
  GetCluster(_clusterId)
  {
    this.getData('Common/GetCluster',{clusterId:_clusterId,elementTypeId:0,groupId:0,status:1}).subscribe((responseList: any) => {
      if (responseList.message =='success') {
        //this.elements = responseList.TResponse[0];
      }
      else{
        this.ENABLEOVERLAY=false;
      }
    });
  }
  GetAllElements()
  {
    this.getData('Common/GetElement',{elementId:0,elementTypeId:0,groupId:0,status:1}).subscribe((responseList: any) => {
      if (responseList.message =='success') {
        this.elements = responseList.TResponse;
      }
      else{
        this.ENABLEOVERLAY=false;
      }
    });
  }
    GetAllClusters()
    {
      this.getData('Common/GetCluster',{clusterId:0,directorateId:0,status:1}).subscribe((responseList: any) => {
        if (responseList.message =='success') {
          this.clusters = responseList.TResponse;
        }
        else{
          this.ENABLEOVERLAY=false;
        }
      });
   }
   RemoveAsset(_directorateId)
   {
    if(confirm("Are you sure to delete ")) {
      this.removeData('Common/Asset',{directorateId:_directorateId}).subscribe((responseList: any) => {
        if (responseList.message =='success') {
          this.removedMsg = responseList.TResponse;
          this._apiService.sendToasterMessage(responseList.message,this.removedMsg);
          this.GetAllAssets();
        }
        else{
          this.ENABLEOVERLAY=false;
          this._apiService.sendToasterMessage(responseList.message,this.removedMsg);
        }
      });
    }
   }
   RemoveCluster(_clusterId)
   {
    if(confirm("Are you sure to delete ")) {
      this.removeData('Common/Cluster',{clusterId:_clusterId}).subscribe((responseList: any) => {
      if (responseList.message =='success') {
        this.removedMsg = responseList.TResponse;
        this._apiService.sendToasterMessage(responseList.message,this.removedMsg);
        this.GetAllClusters();
      }
      else{
        this.ENABLEOVERLAY=false;
        this._apiService.sendToasterMessage(responseList.message,this.removedMsg);
      }
    });
  }
   }
   RemoveElement(_elementId)
   {
    if(confirm("Are you sure to delete ")) {
      this.removeData('Common/Element',{elementId:_elementId}).subscribe((responseList: any) => {
      if (responseList.message =='success') {
        this.removedMsg = responseList.TResponse;
        this._apiService.sendToasterMessage(responseList.message,this.removedMsg);
        this.GetAllElements();
      }
      else{
        this.ENABLEOVERLAY=false;
        this._apiService.sendToasterMessage(responseList.message,this.removedMsg);
      }
    });}
   }
}
