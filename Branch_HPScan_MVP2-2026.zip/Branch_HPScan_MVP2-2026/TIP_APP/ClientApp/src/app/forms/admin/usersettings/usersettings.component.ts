import { Component, OnInit, ViewChild } from '@angular/core';

import { Router } from '@angular/router';
import * as $ from 'jquery';
import { ToastrService } from 'ngx-toastr';
import { ApiService } from '../../../common/services/api.service';
import { UtilityService } from '../../../common/services/utility.service';
import {SessionStorageService} from 'ngx-webstorage';
import { catchError, concat, delay, distinctUntilChanged, forkJoin, map, Observable, of, startWith, Subject, switchMap, tap } from 'rxjs';
import {Location} from '@angular/common';
import { FormBuilder, FormControl } from '@angular/forms';

import { MatTableDataSource } from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';



export interface User {
  PERSONNEL_NUMBER: string;
  NAME: string;
  REFERENCE_INDICATOR: string;
  EMAIL_ADDRESS: string;
  USER_DISPLAY: string;
}

export interface UserData {
  selectedUser: {
    USER_DISPLAY:string;
  };
  selectedroleName: any;
  ROW_ID: any;
  IS_ACTIVE:any;
}

/** Constants used to fill up our data base. */

@Component({
  selector: 'app-usersettings',
  templateUrl: './usersettings.component.html',
  styleUrls: ['./usersettings.component.css']
})

export class UsersettingsComponent implements OnInit {

  ENABLEOVERLAY=false;
  popoverTitle="Confirm";
  popoverMessage="Are you sure do you want to delete this row ?";

  displayedColumns: string[] = ['username', 'rolename',  'edit','delete'];
  dataSource: MatTableDataSource<UserData>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  title = 'User Roles';
  pdoUsersList:any=[];
  userRoleNames:any=[];
  userRoleTypes:any=[];
  directorateList:any=[];

  userToRoleMappingList:any=[];

  viewData={
    selectedUser:{},
    selectedroleName:[],
    ROW_ID:-1,
    IS_ACTIVE:1
  }

  constructor( private route:Router,
    private _apiService:ApiService,
    private _utils:UtilityService,
    private _toast:ToastrService,
    private _storage:SessionStorageService,
    private _location:Location,
    private _formBuilder: FormBuilder) {
    }

    applyFilter(event: Event) {
      const filterValue = (event.target as HTMLInputElement).value;
      this.dataSource.filter = filterValue.trim().toLowerCase();

      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    }


    filteredUserList: Observable<any[]>;
    userControl = new FormControl('');

    pdoUsersListBuffer = [];
    bufferSize = 50;
    numberOfItemsFromEndBeforeFetchingMore = 10;
    loading = false;


  ngOnInit(): void {
    this.loadpageData();
    this.loadUserRoleMapping();
    this.loadPeople();
    this.treeviewFun();

  }
  loadpageData(){
    this.ENABLEOVERLAY=true;
    this.getData('UserSettings/GetUserRoleData',{}).subscribe(
      (responseList: any) => {
        var response=responseList[0]
        if (response.status === 1) {

          this.userRoleNames=response.TResponse.userRoleNames;

          this.ENABLEOVERLAY=false;
        }
        else{
          this.ENABLEOVERLAY=false;
        }
      });
  }

  save(){

      this.ENABLEOVERLAY=true;
      this.postData('UserSettings/SaveUserToRoleMapping',{
        viewData:this.viewData
      }).subscribe(
        (responseList: any) => {
          if (responseList[0].status === 1) {
            this.ENABLEOVERLAY=false;
            this._toast.success("Saved Successfully","success");
            this.loadUserRoleMapping();
            this.reset();
          }
          else{
            this.ENABLEOVERLAY=false;
          }
        });

  }
  loadUserRoleMapping(){
    this.ENABLEOVERLAY=true;
    this.getData('UserSettings/loadUserRoleMapping',{}).subscribe(
      (responseList: any) => {
        var response=responseList[0]
        if (response.status === 1) {
            this.userToRoleMappingList=response.TResponse;
            this.dataSource = new MatTableDataSource(this.userToRoleMappingList);
            this.dataSource.filterPredicate = (data: UserData, filter: string) => {
              return data.selectedUser.USER_DISPLAY.toLocaleLowerCase().includes(filter);

            }
            this.dataSource.paginator = this.paginator;
            this.dataSource.sortingDataAccessor = (item, property) => {
              switch(property) {
                case 'username': return item.selectedUser.USER_DISPLAY;

                default: return item[property];
              }
            };
            this.dataSource.sort = this.sort;

          this.ENABLEOVERLAY=false;
        }
        else{
          this.ENABLEOVERLAY=false;
        }
      });
  }
  deleteSelectedDocument(Item,index){
    this.ENABLEOVERLAY=true;
    var UserId=Item.selectedUser.PERSONNEL_NUMBER;
    this.getData('UserSettings/DeleteUserToRoleMapping',{UserId:UserId}).subscribe(
      (responseList: any) => {
        var response=responseList[0]
        if (response.status === 1) {
          this._toast.success("Item Removed Successfully","success");
          this.loadUserRoleMapping();
          this.reset();
          this.ENABLEOVERLAY=false;
        }
        else{
          this.ENABLEOVERLAY=false;
        }
      });
  }
  docDeleteCancelled(){

  }
  editUserRole(Item){
    var data=Item;
    this.viewData=data;
  }
  reset(){
     this.viewData={
      selectedUser:{},
      selectedroleName:[],


      ROW_ID:-1,
      IS_ACTIVE:1
    };
    this.SelectClear('A',2);
  }

  getData(url:any, options = {}): Observable<any[]> {
    const response = this._apiService.get(url, options);
    //return response;
    return forkJoin([response]);
  }
  postData(url:any, data:any): Observable<any[]> {
    const response = this._apiService.post(url, data);
    return forkJoin([response]);
  }

  // initDatatable(){
  //   $("#example1").DataTable({
  //     "responsive": true, "lengthChange": false, "autoWidth": false,
  //     "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
  //   }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
  //   $('#example2').DataTable({
  //     "paging": true,
  //     "lengthChange": false,
  //     "searching": false,
  //     "ordering": true,
  //     "info": true,
  //     "autoWidth": false,
  //     "responsive": true,
  //   });
  // }

  validateUserRoleMapping(){
    var user=this.viewData.selectedUser,
    Roles=this.viewData.selectedroleName;

    var result=true;

    if(user==null||user==undefined||user==null){
      this._toast.warning("Please select a valid user ","warning");
      result=false;
    }
    else if(Roles==null||Roles==undefined||Roles==null){
      this._toast.warning("Please select a valid Role ","warning");
      result=false;
    }

    return result;
  }

  people$: Observable<any[]>;
  peopleLoading = false;
  peopleInput$ = new Subject<string>();

trackByFn(item: User) {
  return item.PERSONNEL_NUMBER;
}
getUserDataList(term){

    this.getData('UserSettings/GetUsersWithfilter',{Filter:term}).subscribe(
      (responseList: any) => {
        var response=responseList[0]
        if (response.status === 1) {
          this.pdoUsersList=response.TResponse;
          return this.pdoUsersList;
        }
        else{
          this.ENABLEOVERLAY=false;
        }
      });
      return this.pdoUsersList;
}
private loadPeople() {
  this.people$ = concat(
      of([]), // default items
      this.peopleInput$.pipe(
          distinctUntilChanged(),
          tap(() => this.peopleLoading = true),
          switchMap(term => this.getPeople(term).pipe(
              catchError(() => of([])), // empty list on error
              tap(() => this.peopleLoading = false)
          ))
      )
  );
}

getPeople(term: string = null): Observable<User[]> {
  let items = this.getUserDataList(term);
  console.log(items);
  if (term && items!=undefined) {
      items = items.filter(x => x.USER_DISPLAY.toLocaleLowerCase().indexOf(term.toLocaleLowerCase()) > -1);
  }
  return of(items).pipe(delay(500));
}



// USER TO MENU MAPPING
//#region USER TO MENU MAPPING

roleToMenuMappingList:any=[];

selectedRoleToMenu=[];
selectedRoleToElement=[];

viewData_UserToMenuToElement={
  selectedroleName:{
    ROLE_ID:-1,
    ROLE_NAME:""
  }
}


LoadRoleToMenuToElement(){
  var RoleID=this.viewData_UserToMenuToElement.selectedroleName.ROLE_ID;

    this.getData('UserSettings/LoadRoleToMenuToElement',{ROLE_ID:RoleID}).subscribe(
      (responseList: any) => {
        var response=responseList[0]
        if (response.status === 1) {
            this.roleToMenuMappingList=response.TResponse.roleToMenuMappingList;
        }
        else{
          this.ENABLEOVERLAY=false;
        }
      });
  }



saveRoleToMenuTolElement(){
  var RoleID=this.viewData_UserToMenuToElement.selectedroleName.ROLE_ID;
  if(RoleID==null||RoleID==-1||RoleID==undefined){
    this._toast.warning("Please select a valid Role ","warning");
    return;
  }

  this.getselectedMenuMaping();
  var data={
    roleToMenuMappingList:this.selectedRoleToMenu,
    SelectedRole:this.viewData_UserToMenuToElement.selectedroleName
  }
  this.ENABLEOVERLAY=true;
  this.postData('UserSettings/saveRoleToMenuTolElement',{
    viewData:data
  }).subscribe(
    (responseList: any) => {
      if (responseList[0].status === 1) {
        this.ENABLEOVERLAY=false;
        this._toast.success("Saved Successfully","success");

        this.resetRoleToMenuTolElement();
        this.LoadRoleToMenuToElement();
      }
      else{
        this.ENABLEOVERLAY=false;
      }
    });

}
getselectedMenuMaping(){
  var i=0,count=this.roleToMenuMappingList.length;
  for(;i<count;i++){
    var Item=this.roleToMenuMappingList[i];
    if(Item.IS_SELECTED==true){
      this.selectedRoleToMenu.push(Item);
    }
  }
}



resetRoleToMenuTolElement(){
  this.viewData_UserToMenuToElement.selectedroleName={ROLE_ID:-1,ROLE_NAME:""};
  this.SelectClear("A",3);
  this.LoadRoleToMenuToElement();
}


//#endregion


//#region COMMON
SelectClear(control,index){
  var elems= document.getElementsByClassName("ng-input");
  for (var i=0;i<elems.length;i++){
    var item=elems[i];
    if(i==index){
      if(control=="R"){
        item.classList.remove("kf-nodisplay");
      }
      else if(control=="A"){
        item.classList.add("kf-nodisplay");
      }
    }
  }
}

//#endregion

treeviewFun(){
  var toggler = document.getElementsByClassName("caret");
  var i;

for (i = 0; i < toggler.length; i++) {
  toggler[i].addEventListener("click", function() {
    this.parentElement.querySelector(".nested").classList.toggle("active");
    this.classList.toggle("caret-down");
  });
}
}


// filterMenuList(id) {
//   var list = this.roleToMenuMappingList.filter((t) => t.moduleID == id);
//   return list;
// }



}





/** Builds and returns a new User. */
// function createNewUser(id: number): UserData {
//   const name =
//     NAMES[Math.round(Math.random() * (NAMES.length - 1))] +
//     ' ' +
//     NAMES[Math.round(Math.random() * (NAMES.length - 1))].charAt(0) +
//     '.';

//   return {
//     id: id.toString(),
//     name: name,
//     progress: Math.round(Math.random() * 100).toString(),
//     fruit: FRUITS[Math.round(Math.random() * (FRUITS.length - 1))],
//   };
// }
