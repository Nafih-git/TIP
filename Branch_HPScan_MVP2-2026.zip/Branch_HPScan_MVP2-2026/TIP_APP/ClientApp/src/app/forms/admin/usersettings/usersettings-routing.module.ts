import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsersettingsComponent } from './usersettings.component';

const routes: Routes = [{ path: '', component: UsersettingsComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersettingsRoutingModule { }
