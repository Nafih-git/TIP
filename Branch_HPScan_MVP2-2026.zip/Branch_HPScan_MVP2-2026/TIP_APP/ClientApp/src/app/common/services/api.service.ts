
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { ToastrService } from 'ngx-toastr';
import { Observable, throwError } from 'rxjs';
import { LocalStorageService } from 'ngx-webstorage';
import { catchError } from 'rxjs/operators';
import { map } from 'rxjs/operators';

@Injectable()
export class ApiService {

  public host = environment.api;
  requestOptions:any;
  formDatas:any;

  redirectOptions = {
    redirecttab: '',
    fromlink: '',
    ShipmentData: {}
  };

  constructor(
    private http: HttpClient,
    private toastrService: ToastrService,
    private localStorage: LocalStorageService
  ) { }

  setToken() {
    //const user = this.localStorage.retrieve('currentUser');
    this.requestOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
        //'Authorization': 'Bearer ' + user.token
      }),
      withCredentials: true
    };
  }


  private encodeQueryData(data:any) {
    const ret = [];
    for (const d in data) {
      ret.push(encodeURIComponent(d) + '=' + encodeURIComponent(data[d]));
    }
    return ret.join('&');
  }

  public sendToasterMessage(type:any, message:any) {
    if (message !== null && message !== null && message !== undefined) {
      if (type === 'success' || type == 1) {
        this.toastrService.success(message, 'Success!', {
          timeOut: 4000
        });
      }
      if (type === 'error' || type == 0 || type == 2) {
        this.toastrService.error(message, 'Error!', {
          timeOut: 4000
        });
      }
      if (type === 'info' || type == 3) {
        this.toastrService.info(message, 'Message', {
          timeOut: 4000
        });
      }
      if (type === 'warning' || type == 4) {
        this.toastrService.warning(message, 'warning!', {
          timeOut: 4000
        });
      }
    }
  }

  uploadFile(docFile:any, token:any) {
    const fd = new FormData();
    fd.append('file', docFile);
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + token
      })
    };
    return this.http.post(this.host + '/upload_ServiceEntryfile', fd);
  }
  uploadImageFile(docFile:any, token:any) {
    const fd = new FormData();
    fd.append('image', docFile);
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + token
      })
    };
    return this.http.post(this.host + '/FileUpload', fd);
  }

  upload_MultipleFile(url,docFile:any) {
    const fd = new FormData();
    for (let i = 0; i < docFile.length; i++) {
      fd.append('file[]', docFile[i]);
    }
    //fd.append('DetailData',details)

    // const httpOptions = {
    //   headers: new HttpHeaders({
    //     'Authorization': 'Bearer ' + token
    //   })
    // };
    return this.http.post(this.host + url, fd);
  }

  get(path: string, options: Object = {}): Observable<any> {
    this.setToken();
    const query_options = this.encodeQueryData(options);
    if (query_options) {
      path = path + '?' + query_options;
    }
    return this.http.get(this.host + path, this.requestOptions)
      .pipe(map((response: any) => {
        if (response.status === 1) {
          return response;
        }
        if (response.status === 0 || response.status === 2) {
          this.sendToasterMessage('error', response.message);
          return response;
        }
        if (response.status === 3) {
          this.sendToasterMessage('info', response.message);
          return response;
        }
        if (response.status === 4) {
          this.sendToasterMessage('warning', response.message);
          return response;
        }
      }), catchError((error: any) => {
        // this.sendToasterMessage('error', error.message);

        if (error.status == 0) {
          this.sendToasterMessage('error', 'Unable to establish the network connection.');
        }
        else {
          this.sendToasterMessage('error', error.statusText);
        }
        console.log(error);

        return throwError(error);
      }));
  }

  post(path: string, data: any): Observable<any> {
    this.setToken();
    return this.http.post(this.host + path, data, this.requestOptions)
      .pipe(map((response: any) => {
        if (response.status === 1) {
         // this.sendToasterMessage('success', response.message);
          return response;
        }
        else if (response.status === 0 || response.status === 2) {
          this.sendToasterMessage('error', response.message);
          return response;
        }
        else if (response.status === 3) {
          this.sendToasterMessage('info', response.message);
          return response;
        }
        else if (response.status === 4) {
          this.sendToasterMessage('warning', response.message);
          return response;
        }
      }), catchError((error: any) => {
        //this.sendToasterMessage('error', error.error.message);
        if (error.status == 0) {
          this.sendToasterMessage('error', 'Unable to establish the network connection.');
          return "";
        }
        else {
          this.sendToasterMessage('error', error.statusText);
          return "";
        }
        console.log(error);
        // return throwError(error);
      }));
  }

  upload_file(path, docFile, user_id, token): Observable<any> {
    const fd = new FormData();
    fd.append('user_id', user_id);
    fd.append('file', docFile);
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + token
      })
    };
    return this.http.post(this.host + path, fd, httpOptions)
      .pipe(map((response: any) => {
        if (response.status === 1) {
          this.sendToasterMessage('success', response.message);
          return response;
        }
        if (response.status === 0 || response.status === 2) {
          this.sendToasterMessage('error', response.message);
          return response;
        }
        if (response.status === 3) {
          this.sendToasterMessage('info', response.message);
          return response;
        }
        if (response.status === 4) {
          this.sendToasterMessage('warning', response.message);
          return response;
        }
      }), catchError((error: any) => {
        this.sendToasterMessage('error', error.error.message);
        return throwError(error);
      }));
  }

  setRedirectOptions(tab, fromlink, ShipmentData) {
    this.redirectOptions = {
      redirecttab: tab,
      fromlink: fromlink,
      ShipmentData: ShipmentData
    };
  }
  getRedirectOptions() {
    return this.redirectOptions;
  }
  setFormdata(FormDatas) {
    this.formDatas = FormDatas;
  }
  getFormData() {
    return this.formDatas;
  }


  imageUpload(file: File,BaseData:any): Observable<any> {

    var formData: any = new FormData();
    formData.append("file", file);
    formData.append("BaseD", BaseData);
    return this.http.post(this.host+'/uploadFiles', formData, {
      reportProgress: true,
      observe: 'events',
      params:{"BaseD":JSON.stringify(BaseData)}
    })
    .pipe(
      catchError(this.errorMgmt)
    )
  }
  errorMgmt(error: HttpErrorResponse) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;

      console.log(error);
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }



  showToast(type, message) {
    if (type === 'success') {
      this.toastrService.success(message, 'Analyse App Says, SUCCESS', {
        timeOut: 4000
      });
    }
    if (type === 'error') {
      this.toastrService.error(message, 'Analyse App Says, ERROR!! ', {
        timeOut: 4000
      });
    }
    if (type === 'info') {
      this.toastrService.info(message, 'Analyse App Says', {
        timeOut: 4000
      });
    }
    if (type === 'warning') {
      this.toastrService.warning(message, 'Analyse App Says, WARNING!', {
        timeOut: 4000
      });
    }
  }
}



// import { Injectable } from '@angular/core';
// import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { environment } from '../../../environments/environment';
// import { ToastrService } from 'ngx-toastr';
// import { Observable, throwError } from 'rxjs';
// //import {LocalStorageService} from 'ngx-webstorage';
// import { catchError,retry } from 'rxjs/operators';
// import { map } from 'rxjs/operators';

// @Injectable()
// export class ApiService {

//   public host = environment.api;
//   requestOptions:any;
//   formDatas:any;


//   redirectOptions={
//     redirecttab:'',
//     fromlink:'',
//     ShipmentData:{}
//   };


//   constructor(
//     private http: HttpClient,
//     private toastrService: ToastrService,
//     //private localStorage: LocalStorageService
//   ) { }

//   // setToken() {
//   //   const user = {
//   //     token:"1234"
//   //   };
//   //   //this.localStorage.retrieve('currentUser');

//   //   this.requestOptions = {
//   //     headers: new HttpHeaders({
//   //       'Content-Type': 'application/json',
//   //       'Authorization': 'Bearer ' + user.token
//   //     })
//   //   };
//   // }


//   private encodeQueryData(data:any) {
//     const ret = [];
//     for (const d in data) {
//       ret.push(encodeURIComponent(d) + '=' + encodeURIComponent(data[d]));
//     }
//     return ret.join('&');
//   }

//   public sendToasterMessage(type:any, message:any) {
//     if(message!==null &&message!==null&&message!==undefined){
//       if (type === 'success') {
//         // this.toastrService.success(message, 'Success!', {
//         //   timeOut: 4000
//         // });
//       }
//       if (type === 'error') {
//         // this.toastrService.error(message, 'Error!', {
//         //   timeOut: 4000
//         // });
//       }
//       if (type === 'warning') {
//         // this.toastrService.error(message, 'warning!', {
//         //   timeOut: 4000
//         // });
//       }
//     }
//   }

//   uploadFile(docFile:any, token:any) {
//     const fd = new FormData();
//     fd.append('file', docFile);
//     const httpOptions = {
//       headers: new HttpHeaders({
//         'Authorization': 'Bearer ' + token
//       })
//     };
//     return this.http.post(this.host + '/document/upload_file', fd, httpOptions);
//   }



// // upload_MultipleFile(docFile:any, token:any) {
// //     const fd = new FormData();
// //     for (let i = 0; i < docFile.length; i++)
// //     {
// //      fd.append('file[]', docFile[i]);
// //     }

// //     const httpOptions = {
// //       headers: new HttpHeaders({
// //         'Authorization': 'Bearer ' + token
// //       })
// //     };
// //     return this.http.post(this.host + '/document/multiple_upload_file', fd, httpOptions);
// //   }


//   get(path: string, options: Object = {}): Observable<any> {
//     //this.setToken();
//     const query_options = this.encodeQueryData(options);
//     if (query_options) {
//       path = path + '?' + query_options;
//     }
//     return this.http.get(this.host + path, this.requestOptions)
//       .pipe(map((response: any) => {
//         if (response.status === 1) {
//           return response;
//         }
//         if (response.status === 0 || response.status === 2) {
//           //this.sendToasterMessage('error', response.message);
//           return response;
//         }
//       }), catchError((error: any) => {
//             //this.sendToasterMessage('error', error.error.message);
//             return throwError(error);
//       }));
//   }

//   post(path: string, data: any): Observable<any> {
//     //this.setToken();
//     return this.http.post(this.host + path, data, this.requestOptions)
//       .pipe(map((response: any) => {
//         if (response.status === 1) {
//           //this.sendToasterMessage('success', response.message);
//           return response;
//         }
//         if (response.status === 0 || response.status === 2) {
//           //this.sendToasterMessage('error', response.message);
//           return response;
//         }
//       }), catchError((error: any) => {
//            // this.sendToasterMessage('error', error.error.message);

//             return throwError(error);
//       }));
//   }

//   // upload_file(path, docFile, user_id, token): Observable<any> {
//   //   const fd = new FormData();
//   //   fd.append('user_id', user_id);
//   //   fd.append('file', docFile);
//   //   const httpOptions = {
//   //     headers: new HttpHeaders({
//   //       'Authorization': 'Bearer ' + token
//   //     })
//   //   };
//   //   return this.http.post(this.host + path, fd, httpOptions)
//   //     .pipe(map((response: any) => {
//   //       if (response.status === 1) {
//   //         this.sendToasterMessage('success', response.message);
//   //         return response;
//   //       }
//   //       if (response.status === 0 || response.status === 2) {
//   //         this.sendToasterMessage('error', response.message);
//   //         return response;
//   //       }
//   //     }), catchError((error: any) => {
//   //           this.sendToasterMessage('error', error.error.message);
//   //           return throwError(error);
//   //     }));
//   // }

//   // setRedirectOptions(tab,fromlink,ShipmentData){
//   //   this.redirectOptions={
//   //       redirecttab:tab,
//   //       fromlink:fromlink,
//   //       ShipmentData:ShipmentData
//   //   };
//   // }
//   // getRedirectOptions(){
//   //   return this.redirectOptions;
//   // }
//   // setFormdata(FormDatas){
//   // this.formDatas=FormDatas;
//   // }
//   // getFormData(){
//   //   return this.formDatas;
//   // }


//   showToast(type:any, message:any){
//     if (type === 'success') {
//       // this.toastrService.success(message, 'CTReport App Says, SUCCESS', {
//       //   timeOut: 4000
//       // });
//     }
//     if (type === 'error') {
//       // this.toastrService.error(message, 'CTReport App Says, ERROR!! ', {
//       //   timeOut: 4000
//       // });
//     }
//     if (type === 'info') {
//       // this.toastrService.info(message, 'CTReport App Says', {
//       //   timeOut: 4000
//       // });
//     }
//     if (type === 'warning') {
//       // this.toastrService.warning(message, 'CTReport App Says, WARNING!', {
//       //   timeOut: 4000
//       // });
//     }
//   }
// }
