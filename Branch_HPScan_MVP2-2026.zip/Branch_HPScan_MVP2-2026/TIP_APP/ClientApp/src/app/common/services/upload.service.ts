
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class ImageUploadService {
  public host = environment.api;
  constructor(private http: HttpClient) { }

  imageUpload(file: File,BaseData:any): Observable<any> {

    var formData: any = new FormData();
    formData.append("file", file);
    formData.append("BaseD", BaseData);
    return this.http.post(this.host+'/uploadFiles', formData, {
      reportProgress: true,
      observe: 'events',
      params:{"BaseD":JSON.stringify(BaseData)}
    })
    .pipe(

      catchError(this.errorMgmt)
    )
  }

  errorMgmt(error: HttpErrorResponse) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;

      console.log(error);
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }
}
