import { Injectable } from '@angular/core';
import alasql from 'alasql';
import * as XLSX from "xlsx";
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UtilityService {
  public imgPath = environment.imagePath;
  constructor() { }

  getElement(elemType,ElemId){

    if(elemType=="TEXT"){
      return <HTMLInputElement>document.querySelector("#"+ElemId);
    }
    if(elemType=="DIV"){
      return <HTMLDivElement>document.querySelector("#"+ElemId);
    }
  }
  focusElement(elemType,ElemId){
    if(elemType=="TEXT"){
      let elem= <HTMLInputElement>document.querySelector("#"+ElemId);
      elem.focus();
    }
    if(elemType=="TEXTAREA"){
      let elem= <HTMLTextAreaElement>document.querySelector("#"+ElemId);
      elem.focus();
    }
    if(elemType=="SELECT"){
      let elem= <HTMLSelectElement>document.querySelector("#"+ElemId);
      elem.focus();
    }

  }
  dateToDBformat(datestr){
    var options = {
      weekday: "short",
      year: "numeric",
      month: "2-digit",
      day: "numeric"
  };
    if(datestr!=null&&datestr!=undefined&&datestr!=""){
      return new Date(datestr).toLocaleString("en-GB");
    }
    else{
      return new Date('01/01/1991').toLocaleString('en-GB');
    }
  }
  getFormatedDate(datestr){
    if(datestr.includes("1991-01-01")||datestr.includes("01/01/1991")){
      return "";
    }
    else if(datestr!=null&&datestr!=undefined&&datestr!=""){
      return new Date(datestr);
    }
    else{
      return "";
    }
  }
  getImageUrlPath(url){
    return this.imgPath+url;
  }
  toProperCase(str) {
    return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
  };

  convertToExcel(DataObj,Sheetname){
    var opts = [{ sheeitd: "Sheet 1", header: true, column: {style:{Font:{Bold:"1"}}},
    rows: {1:{style:{Font:{Color:"#FF0077"}}}},
    cells: {1:{1:{
      style: {Font:{Color:"#00FFFF"}}}}} }];
    alasql("SELECT INTO XLSX ('"+Sheetname+"',?) FROM ?", [opts, [DataObj]]);

  //This piece of code will download excel sheet with two sheets
   // alasql("SELECT TOP 2 Name as [Student Name], Mark as [Subject Marks] INTO XLSX ('Marks.xlsx',{headers:true}) FROM ?", );
   //var opts = [{ sheeitd: "Sheet 1", header: true }, { sheeitd: "Sheet 2", header: true }]
  //This piece of code will download excel sheet with one sheet, and if you notice here we could change the column name also.
  }

   exportTableToExcel(tableId: string, name?: string) {
    let timeSpan = new Date().toISOString();
    let prefix = name || "ExportResult";
    let fileName = `${prefix}-${timeSpan}`;
    let targetTableElm = document.getElementById(tableId);
    let wb = XLSX.utils.table_to_book(targetTableElm, <XLSX.Table2SheetOpts>{ sheet: prefix });

    XLSX.writeFile(wb, `${fileName}.xlsx`);

  }

  exportExcel(tableid,name) {
    var DataObj = this.done();
    var opts = [{ sheeitd: "Sheet 1", header: true, column: {style:{Font:{Bold:"1"}}},
    rows: {1:{style:{Font:{Color:"#FF0077"}}}},
    cells: {1:{1:{
      style: {Font:{Color:"#00FFFF"}}}}} }];
    alasql("SELECT INTO XLSX ('"+name+"',?) FROM ?", [opts, [DataObj]])
    //alasql('SELECT * INTO XLSX("'+name+'.xlsx",{headers:true}) FROM HTML("#'+tableid+'",{headers:true})');
}

done() {

  let canvas = document.getElementById('pdfTable') as HTMLCanvasElement;
  var url=canvas.toDataURL();
  return url;
  // let img = document.getElementById('GraphImage') as HTMLImageElement;
  // img.src=url;
}






}
