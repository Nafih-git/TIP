﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;

namespace TIP_Common.Admin
{
    public static class ExtensionMethods_Admin
    {
        public static T? ToNullable<T>(this T source) where T : struct => source.IsNull(default(T)) ? (T?)null : source;

        public static T? ToNullable<T>(this T source, T @default) where T : struct => source.IsNull(@default) ? (T?)null : source;

        public static T DefaultIfNull<T>(this T? source, T @default) where T : struct => source ?? @default;

        public static T DefaultIfNull<T>(this T? source) where T : struct => DefaultIfNull(source, default(T));

        public static bool IsNull<T>(this T source, T t) where T : struct => source.Equals(default(T));

        public static bool IsNull<T>(this T source) where T : struct => source.Equals(default(T));
        public static Int16? ToInt16(this object value)
        {
            if (value == null) return 0;
            return Convert.ToInt16(value);
        }

        public static Int32? ToInt32(this object value)
        {
            if (value == null) return 0;
            return Convert.ToInt32(value);
        }

        public static Int64? ToInt64(this object value)
        {
            if (value == null) return 0;
            return Convert.ToInt64(value);
        }

        public static decimal? ToDecimal(this object value)
        {
            if (value == null) return 0;
            return Convert.ToDecimal(value);
        }

        public static double? ToDouble(this object value)
        {
            if (value == null) return 0;
            return Convert.ToDouble(value);
        }

        public static DateTime? ToDateTime(this object value)
        {
            if (value == null) return null;
            return Convert.ToDateTime(value);
        }

        public static int GetQuarter(this DateTime date)
        {
            //date = date.AddDays( - 10);
            if (date.Month >= 4 && date.Month <= 6)
                return 2;
            else if (date.Month >= 7 && date.Month <= 9)
                return 3;
            else if (date.Month >= 10 && date.Month <= 12)
                return 4;
            else
                return 1;
        }

        public static DataTable ToDataTable<T>(this List<T> iList)
        {
            DataTable dataTable = new DataTable();
            PropertyDescriptorCollection propertyDescriptorCollection =
                TypeDescriptor.GetProperties(typeof(T));
            for (int i = 0; i < propertyDescriptorCollection.Count; i++)
            {
                PropertyDescriptor propertyDescriptor = propertyDescriptorCollection[i];
                Type type = propertyDescriptor.PropertyType;

                if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
                    type = Nullable.GetUnderlyingType(type);


                dataTable.Columns.Add(propertyDescriptor.Name, type);
            }
            object[] values = new object[propertyDescriptorCollection.Count];
            foreach (T iListItem in iList)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = propertyDescriptorCollection[i].GetValue(iListItem);
                }
                dataTable.Rows.Add(values);
            }
            return dataTable;
        }
        public static List<T> DataTableToList<T>(this DataTable dt) 
        {
            try
            {
           
            const BindingFlags flags = BindingFlags.Public | BindingFlags.Instance;
            var columnNames = dt.Columns.Cast<DataColumn>()
                .Select(c => c.ColumnName.ToUpper())
                .ToList();
            var objectProperties = typeof(T).GetProperties(flags);
            var targetList = dt.AsEnumerable().Select(dataRow =>
            {
                var instanceOfT = Activator.CreateInstance<T>();

                foreach (var properties in objectProperties.Where(properties => columnNames.Contains(properties.Name.ToUpper()) && dataRow[properties.Name.ToUpper()] != DBNull.Value))
                {
                    if (properties.PropertyType.FullName.Equals("System.Int32"))
                    {
                        properties.SetValue(instanceOfT, dataRow[properties.Name].ToInt32(), null);
                    }
                    else if (properties.PropertyType.FullName.Contains("System.Double"))
                    {
                        properties.SetValue(instanceOfT, dataRow[properties.Name].ToDouble(), null);
                    }
                    else if (properties.PropertyType.FullName.Equals("System.Boolean"))
                    {
                        properties.SetValue(instanceOfT, Convert.ToBoolean(dataRow[properties.Name]), null);
                    }
                    else if (properties.PropertyType.FullName.Equals("System.Decimal"))
                    {
                        properties.SetValue(instanceOfT, dataRow[properties.Name].ToDouble(), null);
                    }
                    else if (properties.PropertyType.FullName.Contains("System.DateTime"))
                    {
                        properties.SetValue(instanceOfT, dataRow[properties.Name].ToDateTime(), null);
                    }
                    else
                    {
                        properties.SetValue(instanceOfT, dataRow[properties.Name].ToString(), null);
                    }

                }
                return instanceOfT;
            }).ToList();

            return targetList;
            }
            catch (Exception ex )
            {

                throw ex;
            }
        }
        public static T ToObject<T>(this DataTable dt)
        {
            var list = dt.DataTableToList<T>();
            if (list.Any())
                return list.FirstOrDefault();
            else
                return Activator.CreateInstance<T>();
        }
        public static bool IsUrl(this string str)
        {
            Uri uriResult;
            bool result = Uri.TryCreate(str, UriKind.Absolute, out uriResult) && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);
            return result;
        }

        public static string IntMonthToString(int Month)
        {
            switch (Month)
            {
                case 1:
                    return "January";
                case 2:
                    return "February";
                case 3:
                    return "March";
                case 4:
                    return "April";
                case 5:
                    return "May";
                case 6:
                    return "June";
                case 7:
                    return "July";
                case 8:
                    return "August";
                case 9:
                    return "September";
                case 10:
                    return "October";
                case 11:
                    return "November";
                case 12:
                    return "December";
                default:
                    return "";
            }
        }

        #region "-----------------------------------------------------------Methods-----------------------------------------------------------------------------------------------------------------"
        /// <summary>
        /// The key
        /// </summary>
      //  private static byte[] key = { };
        //public static string ENCRYPT_KEY = "EMS";

        /// <summary>
        /// The iv
        /// </summary>

     
        public static string GetBatchId()
        {
            StringBuilder builder = new StringBuilder();
            Enumerable
               .Range(65, 26)
                .Select(e => ((char)e).ToString())
                .Concat(Enumerable.Range(97, 26).Select(e => ((char)e).ToString()))
                .Concat(Enumerable.Range(0, 10).Select(e => e.ToString()))
                .OrderBy(e => Guid.NewGuid())
                .Take(11)
                .ToList().ForEach(e => builder.Append(e));
            return builder.ToString();
        }
        #endregion

    }
}
