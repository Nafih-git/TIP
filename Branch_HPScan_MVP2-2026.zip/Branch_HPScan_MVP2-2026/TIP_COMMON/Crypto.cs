﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace TIP_Common
{
    public static class Crypto
    {
        /*the same key is used oracle database to follow the same encryption and decryption*/
        private const string Key = "76HSN8*DHS%JDN93VNJ&DSM$";
        private const string IV = "45@G9HN*";
        
        public static string Encrypt(this string textToEncrypt)
        {
            try
            {
                string cipherText = string.Empty;
                byte[] clearBytes = textToEncrypt.StringToByteArray();
                
                TripleDES TripleDES = TripleDES.Create();
                TripleDES.Mode = CipherMode.CBC;
                TripleDES.Padding = PaddingMode.Zeros;
                TripleDES.Key = Key.StringToByteArray();
                TripleDES.IV = IV.StringToByteArray();

                ICryptoTransform cryptoTransform = TripleDES.CreateEncryptor();
                byte[] encryptedDataBytes = cryptoTransform.TransformFinalBlock(clearBytes, 0, clearBytes.Length);
                TripleDES.Dispose();
                return encryptedDataBytes.ByteToHex();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static string Decrypt(this string cipherText)
        {
            try
            {
                TripleDES TripleDES = TripleDES.Create();
                TripleDES.Mode = CipherMode.CBC;
                TripleDES.Padding = PaddingMode.Zeros;
                TripleDES.Key = Key.StringToByteArray();
                TripleDES.IV = IV.StringToByteArray();

                ICryptoTransform cryptoTransform = TripleDES.CreateDecryptor();
                byte[] EncryptDataBytes = cipherText.StringHexToByteArray();
                byte[] plainDataBytes = cryptoTransform.TransformFinalBlock(EncryptDataBytes, 0, EncryptDataBytes.Length);
                TripleDES.Dispose();
                return Encoding.UTF8.GetString(plainDataBytes).TrimEnd('\0');
            }
            catch(Exception)
            {
                throw;
            }
        }
    }
}
