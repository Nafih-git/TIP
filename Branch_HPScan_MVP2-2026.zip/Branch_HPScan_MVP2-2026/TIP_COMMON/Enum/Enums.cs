﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace TIP_Common.Enum
{
    public enum UserRoleseEnum
    {
        UCT = 62,
        AFP = 41,
        CFP = 61,
        SA = 21,
        Administrator = 1,
        CFDH = 64,
        CHR = 63,
        SR = 141,
        CH = 603
	}


    public enum OChallengeStatus
    {
        Accepted = 73,
        Submitted = 57,
        Published=506
    }



    public static class Enum
    {
        public static class PDOSMS
        {
            public static string SMSLoginOTPMessageFP = "Your One Time Password (OTP): ";
            public static string SMSLoginOTPMessageLP = " for Technology Innovation Portal. Please do not share it with anyone as it is confidential.";

        }
        public static class UserRolesParam
        {
            public static string Administrator = "ADM";
            public static string SystemAdmin = "SA";
            public static string UCT = "UCT";
            public static string AssetFP = "AFP";
            public static string CluserFP = "CFP";
            public static string CFDH = "CFDH";
            public static string ChallengeRequestor = "CHR";
            public static string CompayOwner = "CO";
            public static string TrialFP = "TP";
            public static string CTRApprover = "CTRA";
            public static string PIRApprover = "PIRA";
            public static string SolutionReviewer = "SR";
            public static string InvoiceReviewer = "IR";
            public static string SAPSustainer = "SS";

            public static string ContractEngineer = "CE";
            public static string ContractOwner = "CO";
            public static string HSEAdvisor = "HSEA";
        
            public static string ContractHolder = "CH";
		}

        public static class TaskLink
        {
            public static string TaskBTIAssessment = "BAS";
            public static string TaskChallenge = "CHA";
        }

        public static class TypeCodes
        {
            public static string BTIAssessmentStatus = "ASMST";
            public static string ChallengeStatus = "CT";
            public static string CTRStatus = "CTRS";
            public static string ParticipationSource = "PS";
            public static string Configuration = "CNFG";
            public static string AssetFP = "AST";
            public static string ClusterFP = "CLS";
            public static string SubThemeFP = "TCM";
            public static string EmailTemplate = "ETM";
            public static string PIRStatus = "PIRS";
            public static string EXECStatus = "EXEC";
            public static string ChallengeResponseStatus = "CRQS";
            public static string master = "TCM";
            public static string ExecutionPlanned = "EEPS";
            public static string ExecutionActualplanned = "EXAP";
            public static string ExecutionActualplannedStatus = "EXAPS";
            public static string ExecutionInvoiceStatus = "EXIN";
			public static string SourceStatus = "SR";
            public static string PainAreaStatus = "PAST";
            public static string DeploymentStatus = "DPS";
            public static string CTRActualPlan = "CTRAP";
            public static string CTRPlanStatus = "CTRPS";
            public static string ExecutionType = "PTC";
            public static string PhaseType = "PTC";
			public static string StageType = "PCS";
		}

        public static class EmailModules
        {
            public static string CTR_FRONT_END_LOADING = "CTRFE";
            public static string PIR_MATURATION_CONTROL_TOWER = "PIRMC";
            public static string TMHVR = "TMHVR";
            public static string TMHPC = "TMHPC";
            public static string BTICHL = "BTICHL";
            public static string TMHPBC = "TMHPBC";
            public static string BTIAS = "BTIAS";
            public static string EXEC = "EXEC";
            public static string DEP = "DEP";
		}



        public static class BTIAssessment
        {
            public static string Drafted = "D";
            public static string Submitted = "S";
            public static string Reviewed = "R";
        }

        public static class ChallengeStatus
        {
            public static string Drafted = "D";
            public static string Submitted = "S";
            public static string SentBack = "IP";
            public static string Rejected = "R";
            public static string Accept = "P";
            public static string Reviewed = "A";
            public static string Accepted = "P";
            public static string Published = "PUB";
        }

        public static class CTRStatus
        {
            public static string Drafted = "D";
            public static string Submitted = "S";
            public static string SentBack = "SB";
            public static string Shelved = "SV";
            public static string Deleted = "X";
            public static string Rejected = "R";
            public static string UnderApproval = "UA";
            public static string Approved = "A";
            public static string InActive = "IA";
        }
        public static class PIRStatus
        {
            public static string Drafted = "D";
            public static string Submitted = "S";
            public static string SentBack = "SB";
            public static string Shelved = "SV";
            public static string Deleted = "X";
            public static string Rejected = "R";
            public static string UnderApproval = "UA";
            public static string Approved = "A";
        }

        public static class ExecutionStatus
        {
            public static string Drafted = "D";
            //public static string SentBack = "SB";
            public static string PreDraft = "PD";
            public static string Initiated = "I";
            public static string InActive = "IA";
        }
        public static class ExecutionConfig
        {
            public static string stages = "EPTS";
            public static string activity = "EPTA";
        }

        public static class ExecutionPlannedStatus
        {
            public static string Sentback = "SB";
            public static string Submitted = "S";
            public static string Drafted = "D";
            public static string Approved = "AP";
        }
        public static class ExecutionOverAllProgress
        {
            public static string Completed = "C";
            public static string Escalated = "E";
            public static string Delayed = "D";
            public static string InProgress = "IP";
            public static string Planned = "P";
        }

        public static class ExecutionActualStatus
        {
            public static string Drafted = "D";
            public static string Save = "S";
            public static string Submit = "SB";
        }


        public static class ExecutionInvoiceStatus
        {
            public static string Drafted = "D";
            public static string Requested = "RQ";
            public static string Reviewed = "R";
            public static string Sentback = "SB";
            public static string Completed = "C";
        }

        //EPTS

        public static class ChallengeRspStatus
        {
            public static string Accepted = "A";            
            public static string DetailedEvaluation = "DE";
            public static string Drafted = "D";
            public static string Rejected = "R";
            public static string Shelved = "SH";
            public static string Submitted = "S";
            public static string Sentback = "SB";
        }

        public static class CTRApprovalStatus
        {
            public static string Drafted = "D";
            public static string UnderApproval = "UA";
            public static string Approved = "A";
            public static string SentBack = "SB";
            public static string Rejected = "R";
        }
        public static class PIRApprovalStatus
        {
            public static string Drafted = "D";
            public static string UnderApproval = "UA";
            public static string Approved = "A";
            public static string SentBack = "SB";
            public static string Rejected = "R";
        }
        public static class ParticipationSources
        {
            public static string Vendor = "V";
            public static string Shell = "S";
            public static string MKIP = "MIP";
            public static string TSA = "TS";
            public static string TechBank = "TB";
            public static string InternationalCompany = "M";
		}
        public static class MilestoneType
        {
            public static long DeliveryStoneType = 1;
            public static long PaymentMilestoneType = 2;
            public static long Both = 3;
        }

        public static class SolutionReviewer
        {
            public static string Internal_User = "Internal";
            public static string External_User = "External";
        }

        public static class ChallengeResponseStatus
        {
            public static string Drafted = "D";
            public static string Submitted = "S";
            public static string DetailedEvaluation = "DE";
            public static string FinalDecisionGate = "FDG";
            public static string Accepted = "A";
            public static string Rejected = "R";
            public static string Shelved = "SH";
            public static string Sendback = "SB";
        }

		public static class SolutionResponseStatus
		{
			public static string VendorR = "V";
			public static string InternationalCR = "IC";
			public static string ShellR = "SOG";
			public static string LocalCR = "LC";			
			public static string MarketIntelligenceProposal = "MIP";
			public static string TSA = "TSA";			
			public static string Others = "O";
		}

        public static class PainAreaStatus
        {
			public static string Drafted = "D";
			public static string Submitted = "S";
			public static string Reviewed = "R";
		}

		public static class DeploymentStatus
		{
			public static string Drafted = "D";
			public static string Submitted = "S";
			public static string Deleted = "X";
		}

		public static class PhaseTypeStatus
        {
			public static string PRETTA = "PTTA";
			public static string TTA = "TTA";
			public static string IP = "PO";
			public static string Execution = "EXEC";
			public static string PIR = "PIR";
			public static string Deployment = "DEP";
		}

        public static class PhasesName
        {
            public static string PreTTA = "PRE-TTA";
            public static string TMH = "TMH";
            public static string TTA = "TTA";
            public static string PIR = "PIR";
            public static string Execution = "Execution";
            public static string Deployment = "Deployment";
            public static string Issuinginpo = "ISSUING IN PO";
        }
		public static class StageTypeStatus
		{
			public static string CSubmitted = "CHAS";			
			public static string CReviewed = "CHAR";			
			public static string CPublished = "CHAP";			
			public static string TReviewed = "TMHSR";			
			public static string TRespond = "TMHR";
			public static string TDrafted = "TTAD";			
			public static string TApproved = "TTAP";
			public static string PDrafted = "PIRD";
			public static string PApproved = "PIRP";
		}		

		public static class ExecutionType
        {
            public static string Execution = "EXEC";
        }
        public enum PrintType
        {
            [Description("Excel")]
            xls,
            [Description("PDF")]
            pdf,
            [Description("WORD")]
            WORD,
            [Description("doc")]
            doc,
        }
    
            public static string ToDescription(this PrintType val)
            {
                DescriptionAttribute[] attributes = (DescriptionAttribute[])val
                   .GetType()
                   .GetField(val.ToString())
                   .GetCustomAttributes(typeof(DescriptionAttribute), false);
                return attributes.Length > 0 ? attributes[0].Description : string.Empty;
            }

        public static class UserLogStatus 
        {
            public static string LoginSuccess = "LS";
            public static string LoginFailed = "LF";
            public static string ForgetPa = "FP";
        }
    }
}
