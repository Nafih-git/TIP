﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_Common
{
public class Normalize
    {
        private Normalize()

        {

        }



        /**

         * Remove invalid characters in the string

         *

         * @param  input The string with variables entered by users

         * @return       The clean string

         */

        public static String parse(String input)

        {



            StringBuilder output = new StringBuilder();



            if (input != null)

            {

                for (int i = 0; i < input.Length; ++i)

                {

                    output.Append(Normalize.parse(input[i]));

                }

            }



            return output.ToString();

        }



        public static char parse(char input)

        {



            int digit = (int)input;

            char output = '\0';



            // All

            // for (int i = 32; i <= 126; ++i) {

            // if (digit == i) {

            //     output = (char) i;

            //   }

            // }



            if ((digit == 38) || (digit == 61) || (digit == 63) || (digit == 65))

            {

                output = (char)digit;

            }



            // From 0 to 9 and :

            for (int i = 48; i <= 58; ++i)

            {

                if (digit == i)

                {

                    output = (char)i;

                }

            }



            // @ and From A to Z

            for (int i = 64; i <= 90; ++i)

            {

                if (digit == i)

                {

                    output = (char)i;

                }

            }



            // From a to z

            for (int i = 97; i <= 122; ++i)

            {

                if (digit == i)

                {

                    output = (char)i;

                }

            }



            // - . /

            for (int i = 45; i <= 47; ++i)

            {

                if (digit == i)

                {

                    output = (char)i;

                }

            }



            // \

            if (digit == 92)

            {

                output = (char)92;

            }



            // _

            if (digit == 95)

            {

                output = (char)95;

            }



            // space

            if (digit == 32)

            {

                output = (char)32;

            }



            return output;

        }



        public static String parseforURL(String input)

        {



            StringBuilder output = new StringBuilder();



            if (input != null)

            {

                for (int i = 0; i < input.Length; ++i)

                {

                    output.Append(Normalize.parseforURL(input[i]));

                }

            }



            return output.ToString();

        }



        /**

         * Replace the character with a valid character

         *

         * @param  input The character for checking

         * @return       The clean character

         */

        public static char parseforURL(char input)

        {



            int digit = (int)input;

            char output = '\0';



            // All

            // for (int i = 32; i <= 126; ++i) {

            // if (digit == i) {

            //     output = (char) i;

            //   }

            // }



            if ((digit == 38) || (digit == 61) || (digit == 63) || (digit == 65))

            {

                output = (char)digit;

            }



            // From 0 to 9 and :

            for (int i = 48; i <= 58; ++i)

            {

                if (digit == i)

                {

                    output = (char)i;

                }

            }



            // @ and From A to Z

            for (int i = 64; i <= 90; ++i)

            {

                if (digit == i)

                {

                    output = (char)i;

                }

            }



            // From a to z

            for (int i = 97; i <= 122; ++i)

            {

                if (digit == i)

                {

                    output = (char)i;

                }

            }



            // - . /

            for (int i = 45; i <= 47; ++i)

            {

                if (digit == i)

                {

                    output = (char)i;

                }

            }



            // \

            if (digit == 92)

            {

                output = (char)92;

            }



            // _

            if (digit == 95)

            {

                output = (char)95;

            }



            // space

            if (digit == 32)

            {

                output = (char)32;

            }



            return output;

        }

    }
}
