﻿
using PDOTIPSMS;
using System;
using System.Net;
using System.ServiceModel;
using System.Security.Principal;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace TIP_Common.PDOSMS
{
    public static class TIPSMS
    {
        // Configuration declaration INSIDE the class
        private static IConfiguration? _configuration;

        // Initialize configuration
        public static void Initialize(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public static async Task<string> SendSMS(
            string Message,
            string PhoneNumber)
        {
            BulkPushSoapClient objj = null;

            try
            {
                if (_configuration == null)
                {
                    throw new InvalidOperationException(
                        "TIPSMS configuration is not initialized.");
                }

                string username = _configuration["SMS:Username"];
                string password = _configuration["SMS:Password"];
                string domain = _configuration["SMS:Domain"];
                string apiPassword = _configuration["SMS:APIPassword"];
                string gatewayUrl = _configuration["SMS:GatewayUrl"];

                var binding = new BasicHttpBinding(
                    BasicHttpSecurityMode.Transport);

                binding.Security.Transport.ClientCredentialType =
                    HttpClientCredentialType.Windows;

                var endpoint = new EndpointAddress(gatewayUrl);

                objj = new BulkPushSoapClient(binding, endpoint);

                objj.ClientCredentials.Windows.ClientCredential =
                    new NetworkCredential(username, password, domain);

                objj.ClientCredentials.Windows.AllowedImpersonationLevel =
                    TokenImpersonationLevel.Impersonation;

                PDOTIPSMS.SendSMSResponse smsResp =
                    await objj.SendSMSAsync(
                        "TIPpROJECT",
                        apiPassword,
                        Message,
                        1,
                        "",
                        "UCT",
                        "123",
                        "SMSOTP",
                        PhoneNumber);

                string statusResp =
                    smsResp?.Body?.SendSMSResult?.StatusCode ?? "9999";

                objj.Close();

                return statusResp;
            }
            catch (Exception ex)
            {
                if (objj != null)
                {
                    objj.Abort();
                }

                throw new Exception(
                    $"OTP SMS send failed for PhoneNumber={PhoneNumber}. {ex.Message}",
                    ex);
            }
        }
    }
}


