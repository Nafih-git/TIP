﻿using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace TIP_Common
{
    public static partial class CryptoExtensions
    {
        private const string Key = "76HSN8*DHS%JDN93VNJ&DSM$";
        private const string IV = "0rG@n1$@ti0NaL%2";

        public static string Encrypt(this string plainText)
        {
            // Get bytes of plaintext string
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            byte[] _key = Encoding.UTF8.GetBytes(Key);



            // Get parameter sizes
            int nonceSize = AesGcm.NonceByteSizes.MaxSize;
            int tagSize = AesGcm.TagByteSizes.MaxSize;
            int cipherSize = plainBytes.Length;



            // We write everything into one big array for easier encoding
            int encryptedDataLength = 4 + nonceSize + 4 + tagSize + cipherSize;
            Span<byte> encryptedData = encryptedDataLength < 1024 ? stackalloc byte[encryptedDataLength] : new byte[encryptedDataLength].AsSpan();



            // Copy parameters
            BinaryPrimitives.WriteInt32LittleEndian(encryptedData.Slice(0, 4), nonceSize);
            BinaryPrimitives.WriteInt32LittleEndian(encryptedData.Slice(4 + nonceSize, 4), tagSize);
            var nonce = encryptedData.Slice(4, nonceSize);
            var tag = encryptedData.Slice(4 + nonceSize + 4, tagSize);
            var cipherBytes = encryptedData.Slice(4 + nonceSize + 4 + tagSize, cipherSize);



            // Generate secure nonce
            RandomNumberGenerator.Fill(nonce);


            // Encrypt (tagSizeInBytes required since .NET 8; MaxSize preserves existing ciphertext format)
            using var aes = new AesGcm(_key, tagSizeInBytes: AesGcm.TagByteSizes.MaxSize);
            aes.Encrypt(nonce, plainBytes.AsSpan(), cipherBytes, tag);


            // Encode for transmission
            // return Convert.ToBase64String(encryptedData);
            return ByteArrayToString(encryptedData.ToArray());

        }

        private static string ByteArrayToString(byte[] ba)
        {
            string hex = BitConverter.ToString(ba);
            return hex.Replace("-", "");
        }
        public static byte[] StringToByteArray(String hex)
        {
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            return bytes;
        }


        public static string Decrypt(this string cipher)
        {

            // Decode
            Span<byte> encryptedData = StringToByteArray(cipher).AsSpan<byte>(); //Convert.FromBase64String(cipher).AsSpan();
            byte[] _key = Encoding.UTF8.GetBytes(Key);



            // Extract parameter sizes
            int nonceSize = BinaryPrimitives.ReadInt32LittleEndian(encryptedData.Slice(0, 4));
            int tagSize = BinaryPrimitives.ReadInt32LittleEndian(encryptedData.Slice(4 + nonceSize, 4));
            int cipherSize = encryptedData.Length - 4 - nonceSize - 4 - tagSize;



            // Extract parameters
            var nonce = encryptedData.Slice(4, nonceSize);
            var tag = encryptedData.Slice(4 + nonceSize + 4, tagSize);
            var cipherBytes = encryptedData.Slice(4 + nonceSize + 4 + tagSize, cipherSize);



            // Decrypt
            Span<byte> plainBytes = cipherSize < 1024
                                  ? stackalloc byte[cipherSize]
                                  : new byte[cipherSize];
            using var aes = new AesGcm(_key, tagSizeInBytes: AesGcm.TagByteSizes.MaxSize);
            aes.Decrypt(nonce, cipherBytes, tag, plainBytes);



            // Convert plain bytes back into string
            return Encoding.UTF8.GetString(plainBytes);
        }
    }
}
