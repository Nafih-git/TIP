﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace TIP_Common.Helpers
{
    public class AccountHelper
    {
        public static string GetWinAuthAccount(HttpContext context)
        {
            IPrincipal p = context.User;
            return p.Identity?.Name ?? "";
        }

        public static string GetWinAuthIPForLogs(HttpContext context)
        {
            return context.Connection.RemoteIpAddress.ToString(); 
        }
    }
}
