﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TIP_Common.Helpers
{
    public class CheckerHelper
    {
        public static bool IsValidName(string Name, int category)

        {

            var invlaidCharList = System.IO.Path.GetInvalidPathChars().ToList();



            if (category == 1)

                invlaidCharList = System.IO.Path.GetInvalidFileNameChars().ToList();



            invlaidCharList.AddRange(new List<Char>() { '<', '>', ':', '"', '/', '|', '?', '*' });



            if (Name.IndexOfAny(invlaidCharList.ToArray()) >= 0)

                return false;

            else

                return true;

        }
    }
}
