﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIP_Common.Helpers;

namespace TIP_Common
{
    public class Global
    {
        private static IHttpContextAccessor? httpContextAccessor;
        public static void SetHttpContextAccessor(IHttpContextAccessor _httpContextAccessor)
        {
            httpContextAccessor = _httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
        }

        public static class User
        {

            public static string MuNumber => AccountHelper.GetWinAuthAccount(httpContextAccessor.HttpContext).Trim().ToUpper();

            //public static string MuNumber => httpContextAccessor?.HttpContext?.User?.Identity?.Name.Substring(httpContextAccessor.HttpContext.User.Identity.Name.LastIndexOf(@"\") + 1).ToUpper();
        }
    }
}
