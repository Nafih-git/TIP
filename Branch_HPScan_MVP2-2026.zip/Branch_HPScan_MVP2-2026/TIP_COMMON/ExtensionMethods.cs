﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using System.Web;
using TIP_Common.Helpers;

namespace TIP_Common
{
    public static class ExtensionMethods
    {
        public static string MUNumber(this string EmployeeNumber)
        {
            if (!String.IsNullOrEmpty(EmployeeNumber))
            {
                return EmployeeNumber.Split("\\")[1];
            }
            return String.Empty;
        }

        public static bool IsValidFileType(this string FileName)
        {
            List<string> ValidExtensions = new List<string>() { "pdf", "docx", "xlsx", "msg" };
            if (!string.IsNullOrEmpty(FileName))
            {
                string extension = Path.GetExtension(FileName);
                return ValidExtensions.Any(x => x == extension);
            }
            return false;
        }
        public static bool IsValidFileType(this string FileName, string AllowedFileTypes)
        {
            if (!String.IsNullOrEmpty(FileName))
            {
                string extension = Path.GetExtension(FileName);
                bool result = AllowedFileTypes.Contains(extension.ToLower());
                return result;
            }
            return false;
        }
        public static bool ContainsInvalidChar(this string Path)
        {
            List<string> invalidCharactes = new List<string>() { "..", ":", "./", @"..\\", @"..\" };
            return invalidCharactes.Any(x => Path.Contains(x));
        }

        private static string GetDetailedErrorMessage(Exception ex, HashSet<Exception> processedExceptions = null)
        {
            if (ex == null)
            {
                return "No exception provided.";
            }

            if (processedExceptions == null)
            {
                processedExceptions = new HashSet<Exception>();
            }

            if (processedExceptions.Contains(ex))
            {
                return "Recursive exception encountered.";
            }

            processedExceptions.Add(ex);

            string errorMessage = $"Exception Type: {ex.GetType().FullName}\n";
            errorMessage += $"Message: {ex.Message}\n";
            errorMessage += $"Source: {ex.Source}\n";
            errorMessage += $"Stack Trace:\n{ex.StackTrace}\n";

            if (ex.InnerException != null)
            {
                errorMessage += "\nInner Exception:\n";
                errorMessage += GetDetailedErrorMessage(ex.InnerException, processedExceptions);
            }

            return errorMessage;
        }

        public static string GetExceptionMessage(Exception ex)
        {


            string errorMessage = string.Empty;

            if (ex == null)
            {
                errorMessage = "No exception provided.";
            }
            else
            {
                errorMessage = $"Exception Type: {ex.GetType().FullName}\n";
                errorMessage += $"Message: {ex.Message}\n";
                errorMessage += $"Source: {ex.Source}\n";
                errorMessage += $"Stack Trace:\n{ex.StackTrace}\n";

                if (ex.InnerException != null)
                {
                    errorMessage += "\nInner Exception:\n";
                    errorMessage += GetDetailedErrorMessage(ex.InnerException);
                }
            }

            return errorMessage;


        }

        //public static string GetSolutionReviwerFormURL(string BaseURL, string encryptedId, string source, string status, int IsOtherUCT = 2)
        //{
        //    string URl = BaseURL + "#/tmh/review-form?";
        //    string result =  "reviewCode=" +String.Format("{0}&{1}&{2}&{3}",encryptedId.Trim(), source.Trim(), status.Trim(), IsOtherUCT.ToString().Trim());

        //    //return result;
        //    return URl + HttpUtility.HtmlEncode(result);

        //}

        public static string GetSolutionReviwerFormURL(string baseUrl, string solutionId, string source, string status)
        {
            string Parastring = $"reviewCode={Uri.EscapeDataString(solutionId)}&source={Uri.EscapeDataString(source)}&status={Uri.EscapeDataString(status)}";
            // Encode only the required parts of the URL
            return $"{baseUrl}Home/SolutionReviewer?{Parastring}";
        }


        public static string GetChallengeFormURL (string baseUrl, string encryptedId)
        {
            string Parastring = $"CFCode={Uri.EscapeDataString(encryptedId)}&isEdit=view&isTMH=false";

            return $"{baseUrl}Home/Challenge?{Parastring}";

        }
        public static string GetTTAFormURL(string baseUrl, string encryptedId)
        {
            string Parastring = $"Code={Uri.EscapeDataString(encryptedId)}";

            return $"{baseUrl}Home/TTA?{Parastring}";

        }
        public static string GetPIRFormURL(string baseUrl, string encryptedId)
        {
            string Parastring = $"Code={Uri.EscapeDataString(encryptedId)}";

            return $"{baseUrl}Home/PIR?{Parastring}";

        }



        //public static string GetChallengeFormURL(string BaseURL, string encryptedId)
        //{
        //    string URl = BaseURL.Trim() + "#/bti/challenge-registration-crud?".Trim();


        //    string result =  "CFCode=" +String.Format("{0}&isEdit={1}&isTMH={2}", encryptedId.Trim(), "view", false.ToString()) ;

        //    string hyperlinkAddress = $"{URl}#{result}";
        //    string encodedHyperlink = HttpUtility.UrlEncode(hyperlinkAddress);
        //    return URl + HttpUtility.HtmlEncode(result);
        //}


    }
}
